big_immediates(i0)
     0 : mov       i1, 4096         
     1 : store.u64 i0, i1           
     2 : add       i0, i0, 8        
     3 : mov       i2, 8191         
     4 : store.u64 i0, i2           
     5 : add       i0, i0, 8        
     6 : mov       i3, 2147482282   
     7 : store.u64 i0, i3           
     8 : add       i0, i0, 8        
     9 : mov       i4, 0            
    10 : store.u64 i0, i4           
    11 : add       i0, i0, 8        
    12 : mov       i5, -1           
    13 : store.u64 i0, i5           
    14 : add       i0, i0, 8        
    15 : mov       i6, -1431655766  
    16 : store.u64 i0, i6           
    17 : add       i0, i0, 8        
    18 : mov       i7, 65535        
    19 : store.u64 i0, i7           
    20 : add       i0, i0, 8        
    21 : mov       i8, 65536        
    22 : store.u64 i0, i8           
    23 : add       i0, i0, 8        
    24 : mov       i9, -32768       
    25 : store.i64 i0, i9           
    26 : add       i0, i0, 8        
    27 : mov       i10, -32769      
    28 : store.i64 i0, i10          
    29 : add       i0, i0, 8        
    30 : mov       i11, 1597463007  
    31 : store.u64 i0, i11          
    32 : add       i0, i0, 8        
    33 : mov       i12, -1961601175 
    34 : store.u64 i0, i12          
    35 : add       i0, i0, 8        
    36 : ret                        
