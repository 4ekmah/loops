sibling_loops(i0, i1, i2)
     0 : mov                    i3, 0           
     1 : mov                    i4, 0           
     2 : annotation:whilecstart 0               
     3 : cmp                    i3, i1          
     4 : jmp_ge                 __loops_label_2 
     5 : annotation:whilecend                   
     6 : load.i32               i5, i0, i3      
     7 : add                    i4, i4, i5      
     8 : add                    i3, i3, 4       
     9 : annotation:endwhile    0, 2            
    10 : mov                    i6, 0           
    11 : annotation:whilecstart 3               
    12 : cmp                    i3, 0           
    13 : jmp_le                 __loops_label_5 
    14 : annotation:whilecend                   
    15 : add                    i6, i6, 1       
    16 : sub                    i3, i3, 4       
    17 : annotation:endwhile    3, 5            
    18 : store.i32              i2, i4          
    19 : store.i32              i2, 4, i6       
    20 : mov                    iR, 0           
    21 : ret                                    
