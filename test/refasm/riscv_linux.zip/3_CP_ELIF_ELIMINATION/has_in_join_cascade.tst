has_in_join_cascade(i0, i1, i2)
     0 : mov                    i3, 0            
     1 : load.i64               i4, i0, 16       
     2 : load.i64               i5, i0, 0        
     3 : load.i64               i6, i0, 8        
     4 : annotation:whilecstart 0                
     5 : mov                    i19, 0           
     6 : cmp                    i4, i19          
     7 : jmp_le                 __loops_label_2  
     8 : annotation:whilecend                    
     9 : load.i32               i7, i5           
    10 : add                    i5, i5, 4        
    11 : load.i32               i8, i6           
    12 : add                    i6, i6, 4        
    13 : sub                    i4, i4, 1        
    14 : load.i64               i9, i0, 40       
    15 : load.i64               i10, i0, 24      
    16 : load.i64               i11, i0, 32      
    17 : annotation:whilecstart 3                
    18 : mov                    i20, 0           
    19 : cmp                    i9, i20          
    20 : jmp_le                 __loops_label_5  
    21 : annotation:whilecend                    
    22 : load.i32               i12, i10         
    23 : add                    i10, i10, 4      
    24 : load.i32               i13, i11         
    25 : add                    i11, i11, 4      
    26 : sub                    i9, i9, 1        
    27 : annotation:ifcstart                     
    28 : cmp                    i13, i7          
    29 : jmp_le                 __loops_label_7  
    30 : annotation:ifcend                       
    31 : annotation:break       3                
    32 : annotation:else        7, 8             
    33 : annotation:ifcstart                     
    34 : cmp                    i13, i7          
    35 : jmp_ne                 __loops_label_10 
    36 : annotation:ifcend                       
    37 : load.i64               i14, i0, 64      
    38 : load.i64               i15, i0, 48      
    39 : load.i64               i16, i0, 56      
    40 : annotation:whilecstart 11               
    41 : mov                    i21, 0           
    42 : cmp                    i14, i21         
    43 : jmp_le                 __loops_label_13 
    44 : annotation:whilecend                    
    45 : load.i32               i17, i15         
    46 : add                    i15, i15, 4      
    47 : load.i32               i18, i16         
    48 : add                    i16, i16, 4      
    49 : sub                    i14, i14, 1      
    50 : annotation:ifcstart                     
    51 : cmp                    i17, i8          
    52 : jmp_le                 __loops_label_15 
    53 : annotation:ifcend                       
    54 : annotation:break       11               
    55 : annotation:else        15, 16           
    56 : annotation:ifcstart                     
    57 : cmp                    i17, i8          
    58 : jmp_ne                 __loops_label_18 
    59 : cmp                    i12, i1          
    60 : jmp_ne                 __loops_label_18 
    61 : cmp                    i18, i2          
    62 : jmp_ne                 __loops_label_18 
    63 : annotation:ifcend                       
    64 : mov                    i3, 1            
    65 : annotation:break       2                
    66 : annotation:endif       16               
    67 : annotation:endif       18               
    68 : annotation:endwhile    11, 13           
    69 : annotation:endif       8                
    70 : annotation:endif       10               
    71 : annotation:endwhile    3, 5             
    72 : annotation:endwhile    0, 2             
    73 : mov                    iR, i3           
    74 : ret                                     
