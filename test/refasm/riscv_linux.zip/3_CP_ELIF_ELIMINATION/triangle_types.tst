triangle_types(i0, i1, i2)
     0 : annotation:ifcstart                  
     1 : mov                 i30, 0           
     2 : cmp                 i0, i30          
     3 : jmp_le              __loops_label_0  
     4 : mov                 i31, 0           
     5 : cmp                 i1, i31          
     6 : jmp_le              __loops_label_0  
     7 : mov                 i32, 0           
     8 : cmp                 i2, i32          
     9 : jmp_gt              __loops_label_1  
    10 : __loops_label_0:                     
    11 : annotation:ifcend                    
    12 : mov                 iR, 0            
    13 : ret                                  
    14 : annotation:else     1, 2             
    15 : annotation:ifcstart                  
    16 : add                 i3, i1, i2       
    17 : cmp                 i0, i3           
    18 : jmp_gt              __loops_label_3  
    19 : add                 i4, i0, i2       
    20 : cmp                 i1, i4           
    21 : jmp_gt              __loops_label_3  
    22 : add                 i5, i0, i1       
    23 : cmp                 i2, i5           
    24 : jmp_le              __loops_label_4  
    25 : __loops_label_3:                     
    26 : annotation:ifcend                    
    27 : mov                 iR, 0            
    28 : ret                                  
    29 : annotation:else     4, 5             
    30 : annotation:ifcstart                  
    31 : cmp                 i0, i1           
    32 : jmp_ne              __loops_label_7  
    33 : cmp                 i0, i2           
    34 : jmp_ne              __loops_label_7  
    35 : annotation:ifcend                    
    36 : mov                 iR, 2            
    37 : ret                                  
    38 : annotation:else     7, 8             
    39 : annotation:ifcstart                  
    40 : cmp                 i0, i1           
    41 : jmp_eq              __loops_label_9  
    42 : cmp                 i0, i2           
    43 : jmp_eq              __loops_label_9  
    44 : cmp                 i1, i2           
    45 : jmp_ne              __loops_label_10 
    46 : __loops_label_9:                     
    47 : annotation:ifcend                    
    48 : mov                 iR, 3            
    49 : ret                                  
    50 : annotation:else     10, 11           
    51 : annotation:ifcstart                  
    52 : mul                 i6, i0, i0       
    53 : mul                 i8, i1, i1       
    54 : mul                 i9, i2, i2       
    55 : add                 i7, i8, i9       
    56 : cmp                 i6, i7           
    57 : jmp_eq              __loops_label_12 
    58 : mul                 i10, i1, i1      
    59 : mul                 i12, i0, i0      
    60 : mul                 i13, i2, i2      
    61 : add                 i11, i12, i13    
    62 : cmp                 i10, i11         
    63 : jmp_eq              __loops_label_12 
    64 : mul                 i14, i2, i2      
    65 : mul                 i16, i0, i0      
    66 : mul                 i17, i1, i1      
    67 : add                 i15, i16, i17    
    68 : cmp                 i14, i15         
    69 : jmp_ne              __loops_label_13 
    70 : __loops_label_12:                    
    71 : annotation:ifcend                    
    72 : mov                 iR, 1            
    73 : ret                                  
    74 : annotation:else     13, 14           
    75 : annotation:ifcstart                  
    76 : mul                 i18, i0, i0      
    77 : mul                 i20, i1, i1      
    78 : mul                 i21, i2, i2      
    79 : add                 i19, i20, i21    
    80 : cmp                 i18, i19         
    81 : jmp_gt              __loops_label_15 
    82 : mul                 i22, i1, i1      
    83 : mul                 i24, i0, i0      
    84 : mul                 i25, i2, i2      
    85 : add                 i23, i24, i25    
    86 : cmp                 i22, i23         
    87 : jmp_gt              __loops_label_15 
    88 : mul                 i26, i2, i2      
    89 : mul                 i28, i0, i0      
    90 : mul                 i29, i1, i1      
    91 : add                 i27, i28, i29    
    92 : cmp                 i26, i27         
    93 : jmp_le              __loops_label_16 
    94 : __loops_label_15:                    
    95 : annotation:ifcend                    
    96 : mov                 iR, 5            
    97 : ret                                  
    98 : annotation:else     16, 17           
    99 : mov                 iR, 4            
   100 : ret                                  
   101 : annotation:endif    2                
   102 : annotation:endif    5                
   103 : annotation:endif    8                
   104 : annotation:endif    11               
   105 : annotation:endif    14               
   106 : annotation:endif    17               
