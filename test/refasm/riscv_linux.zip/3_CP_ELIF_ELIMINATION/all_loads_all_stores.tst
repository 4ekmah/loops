all_loads_all_stores(i0, i1, i2, i3, i4)
     0 : mov                    i5, 0            
     1 : mov                    i6, 0            
     2 : mov                    i7, 0            
     3 : mov                    i8, 2            
     4 : mov                    i9, 1            
     5 : mov                    i19, 1           
     6 : cmp                    i1, i19          
     7 : select_gt              i10, i8, i9      
     8 : mov                    i11, 4           
     9 : mov                    i20, 3           
    10 : cmp                    i1, i20          
    11 : select_gt              i10, i11, i10    
    12 : mov                    i12, 8           
    13 : mov                    i21, 5           
    14 : cmp                    i1, i21          
    15 : select_gt              i10, i12, i10    
    16 : mov                    i13, 2           
    17 : mov                    i14, 1           
    18 : mov                    i22, 1           
    19 : cmp                    i3, i22          
    20 : select_gt              i15, i13, i14    
    21 : mov                    i16, 4           
    22 : mov                    i23, 3           
    23 : cmp                    i3, i23          
    24 : select_gt              i15, i16, i15    
    25 : mov                    i17, 8           
    26 : mov                    i24, 5           
    27 : cmp                    i3, i24          
    28 : select_gt              i15, i17, i15    
    29 : annotation:whilecstart 0                
    30 : cmp                    i5, i4           
    31 : jmp_ge                 __loops_label_2  
    32 : annotation:whilecend                    
    33 : def                    i18              
    34 : annotation:ifcstart                     
    35 : mov                    i25, 0           
    36 : cmp                    i1, i25          
    37 : jmp_ne                 __loops_label_4  
    38 : annotation:ifcend                       
    39 : load.u8                i18, i0, i6      
    40 : annotation:else        4, 5             
    41 : annotation:ifcstart                     
    42 : mov                    i26, 1           
    43 : cmp                    i1, i26          
    44 : jmp_ne                 __loops_label_7  
    45 : annotation:ifcend                       
    46 : load.i8                i18, i0, i6      
    47 : annotation:else        7, 8             
    48 : annotation:ifcstart                     
    49 : mov                    i27, 2           
    50 : cmp                    i1, i27          
    51 : jmp_ne                 __loops_label_10 
    52 : annotation:ifcend                       
    53 : load.u16               i18, i0, i6      
    54 : annotation:else        10, 11           
    55 : annotation:ifcstart                     
    56 : mov                    i28, 3           
    57 : cmp                    i1, i28          
    58 : jmp_ne                 __loops_label_13 
    59 : annotation:ifcend                       
    60 : load.i16               i18, i0, i6      
    61 : annotation:else        13, 14           
    62 : annotation:ifcstart                     
    63 : mov                    i29, 4           
    64 : cmp                    i1, i29          
    65 : jmp_ne                 __loops_label_16 
    66 : annotation:ifcend                       
    67 : load.u32               i18, i0, i6      
    68 : annotation:else        16, 17           
    69 : annotation:ifcstart                     
    70 : mov                    i30, 5           
    71 : cmp                    i1, i30          
    72 : jmp_ne                 __loops_label_19 
    73 : annotation:ifcend                       
    74 : load.i32               i18, i0, i6      
    75 : annotation:else        19, 20           
    76 : annotation:ifcstart                     
    77 : mov                    i31, 6           
    78 : cmp                    i1, i31          
    79 : jmp_ne                 __loops_label_22 
    80 : annotation:ifcend                       
    81 : load.u64               i18, i0, i6      
    82 : annotation:else        22, 23           
    83 : load.i64               i18, i0, i6      
    84 : annotation:endif       5                
    85 : annotation:endif       8                
    86 : annotation:endif       11               
    87 : annotation:endif       14               
    88 : annotation:endif       17               
    89 : annotation:endif       20               
    90 : annotation:endif       23               
    91 : annotation:ifcstart                     
    92 : mov                    i32, 0           
    93 : cmp                    i3, i32          
    94 : jmp_ne                 __loops_label_25 
    95 : annotation:ifcend                       
    96 : store.u8               i2, i7, i18      
    97 : annotation:else        25, 26           
    98 : annotation:ifcstart                     
    99 : mov                    i33, 1           
   100 : cmp                    i3, i33          
   101 : jmp_ne                 __loops_label_28 
   102 : annotation:ifcend                       
   103 : store.i8               i2, i7, i18      
   104 : annotation:else        28, 29           
   105 : annotation:ifcstart                     
   106 : mov                    i34, 2           
   107 : cmp                    i3, i34          
   108 : jmp_ne                 __loops_label_31 
   109 : annotation:ifcend                       
   110 : store.u16              i2, i7, i18      
   111 : annotation:else        31, 32           
   112 : annotation:ifcstart                     
   113 : mov                    i35, 3           
   114 : cmp                    i3, i35          
   115 : jmp_ne                 __loops_label_34 
   116 : annotation:ifcend                       
   117 : store.i16              i2, i7, i18      
   118 : annotation:else        34, 35           
   119 : annotation:ifcstart                     
   120 : mov                    i36, 4           
   121 : cmp                    i3, i36          
   122 : jmp_ne                 __loops_label_37 
   123 : annotation:ifcend                       
   124 : store.u32              i2, i7, i18      
   125 : annotation:else        37, 38           
   126 : annotation:ifcstart                     
   127 : mov                    i37, 5           
   128 : cmp                    i3, i37          
   129 : jmp_ne                 __loops_label_40 
   130 : annotation:ifcend                       
   131 : store.i32              i2, i7, i18      
   132 : annotation:else        40, 41           
   133 : annotation:ifcstart                     
   134 : mov                    i38, 6           
   135 : cmp                    i3, i38          
   136 : jmp_ne                 __loops_label_43 
   137 : annotation:ifcend                       
   138 : store.u64              i2, i7, i18      
   139 : annotation:else        43, 44           
   140 : store.i64              i2, i7, i18      
   141 : annotation:endif       26               
   142 : annotation:endif       29               
   143 : annotation:endif       32               
   144 : annotation:endif       35               
   145 : annotation:endif       38               
   146 : annotation:endif       41               
   147 : annotation:endif       44               
   148 : add                    i6, i6, i10      
   149 : add                    i7, i7, i15      
   150 : add                    i5, i5, 1        
   151 : annotation:endwhile    0, 2             
