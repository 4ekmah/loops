area_sum(i0, i1)
     0 : sub                    i2, i2, 208               
     1 : spill                  21, i24                   
     2 : spill                  22, i25                   
     3 : spill                  24, i8                    
     4 : spill                  25, i1                    
     5 : mov                    i25, 0                    
     6 : spill                  16, i25                   
     7 : annotation:whilecstart 0                         
     8 : mov                    i13, 0                    
     9 : jmp_le                 i11, i13, __loops_label_2 
    10 : annotation:whilecend                             
    11 : load.i8                i25, i10                  
    12 : spill                  17, i25                   
    13 : mov                    i24, 43                   
    14 : shl                    i24, i24, 32              
    15 : rv_lui                 i12, 850105               
    16 : add                    i12, i12, -1436           
    17 : add                    i25, i24, i12             
    18 : spill                  18, i25                   
    19 : mov                    i24, 43                   
    20 : shl                    i24, i24, 32              
    21 : rv_lui                 i13, 850105               
    22 : add                    i13, i13, -1242           
    23 : add                    i13, i24, i13             
    24 : mov                    i24, 43                   
    25 : shl                    i24, i24, 32              
    26 : rv_lui                 i12, 850105               
    27 : add                    i12, i12, -1098           
    28 : add                    i12, i24, i12             
    29 : mov                    i24, 1                    
    30 : unspill                i25, 17                   
    31 : sub                    i24, i25, i24             
    32 : iverson_eq             i24, i24, 0               
    33 : sub                    i13, i13, i12             
    34 : sub                    i24, 0, i24               
    35 : and                    i13, i24, i13             
    36 : add                    i12, i12, i13             
    37 : mov                    i13, 0                    
    38 : unspill                i25, 17                   
    39 : sub                    i13, i25, i13             
    40 : iverson_eq             i13, i13, 0               
    41 : unspill                i25, 18                   
    42 : sub                    i24, i25, i12             
    43 : sub                    i13, 0, i13               
    44 : and                    i13, i13, i24             
    45 : add                    i25, i12, i13             
    46 : spill                  19, i25                   
    47 : mov                    i13, 43                   
    48 : shl                    i13, i13, 32              
    49 : rv_lui                 i24, 850105               
    50 : add                    i24, i24, -1728           
    51 : add                    i25, i13, i24             
    52 : spill                  20, i25                   
    53 : mov                    i24, 43                   
    54 : shl                    i24, i24, 32              
    55 : rv_lui                 i12, 850105               
    56 : add                    i12, i12, -1632           
    57 : add                    i12, i24, i12             
    58 : mov                    i24, 43                   
    59 : shl                    i24, i24, 32              
    60 : rv_lui                 i13, 850105               
    61 : add                    i13, i13, -1570           
    62 : add                    i13, i24, i13             
    63 : mov                    i24, 1                    
    64 : unspill                i25, 17                   
    65 : sub                    i24, i25, i24             
    66 : iverson_eq             i24, i24, 0               
    67 : sub                    i12, i12, i13             
    68 : sub                    i24, 0, i24               
    69 : and                    i12, i24, i12             
    70 : add                    i12, i13, i12             
    71 : mov                    i13, 0                    
    72 : unspill                i25, 17                   
    73 : sub                    i13, i25, i13             
    74 : iverson_eq             i13, i13, 0               
    75 : unspill                i25, 20                   
    76 : sub                    i24, i25, i12             
    77 : sub                    i13, 0, i13               
    78 : and                    i13, i13, i24             
    79 : add                    i12, i12, i13             
    80 : unspill                i25, 19                   
    81 : call_noret             [i25](i10)                
    82 : call                   [i12](i12, i10)           
    83 : mov                    i13, 43                   
    84 : shl                    i13, i13, 32              
    85 : rv_lui                 i24, 850105               
    86 : add                    i24, i24, -1796           
    87 : add                    i13, i13, i24             
    88 : unspill                i25, 16                   
    89 : call                   [i13](i12, i25, i12)      
    90 : mov                    i25, i12                  
    91 : spill                  16, i25                   
    92 : add                    i10, i10, 56              
    93 : sub                    i11, i11, 1               
    94 : annotation:endwhile    0, 2                      
    95 : unspill                i25, 16                   
    96 : mov                    i10, i25                  
    97 : ret                                              
    98 : unspill                i8, 24                    
    99 : unspill                i1, 25                    
   100 : unspill                i24, 21                   
   101 : unspill                i25, 22                   
   102 : add                    i2, i2, 208               
