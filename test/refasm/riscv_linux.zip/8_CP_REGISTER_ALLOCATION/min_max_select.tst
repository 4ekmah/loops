min_max_select(i0, i1, i2, i3)
     0 : sub                    i2, i2, 128               
     1 : spill                  11, i24                   
     2 : spill                  12, i25                   
     3 : spill                  13, i26                   
     4 : spill                  14, i27                   
     5 : mov                    i25, 0                    
     6 : spill                  5, i25                    
     7 : mov                    i25, 0                    
     8 : spill                  0, i25                    
     9 : mov                    i25, 0                    
    10 : spill                  1, i25                    
    11 : load.i32               i25, i10                  
    12 : spill                  2, i25                    
    13 : unspill                i25, 2                    
    14 : mov                    i26, i25                  
    15 : spill                  3, i26                    
    16 : shl                    i25, i11, 2               
    17 : spill                  4, i25                    
    18 : annotation:whilecstart 0                         
    19 : unspill                i26, 4                    
    20 : unspill                i25, 5                    
    21 : jmp_ge                 i25, i26, __loops_label_2 
    22 : annotation:whilecend                             
    23 : unspill                i25, 5                    
    24 : add                    i24, i10, i25             
    25 : load.i32               i25, i24                  
    26 : spill                  6, i25                    
    27 : unspill                i26, 2                    
    28 : unspill                i25, 6                    
    29 : iverson_gt             i24, i25, i26             
    30 : unspill                i25, 5                    
    31 : unspill                i26, 0                    
    32 : sub                    i27, i25, i26             
    33 : spill                  7, i27                    
    34 : sub                    i24, 0, i24               
    35 : unspill                i25, 7                    
    36 : and                    i24, i24, i25             
    37 : unspill                i25, 0                    
    38 : add                    i25, i25, i24             
    39 : spill                  0, i25                    
    40 : unspill                i26, 2                    
    41 : unspill                i25, 6                    
    42 : iverson_gt             i24, i25, i26             
    43 : unspill                i26, 2                    
    44 : unspill                i25, 6                    
    45 : sub                    i27, i25, i26             
    46 : spill                  8, i27                    
    47 : sub                    i24, 0, i24               
    48 : unspill                i25, 8                    
    49 : and                    i24, i24, i25             
    50 : unspill                i25, 2                    
    51 : add                    i25, i25, i24             
    52 : spill                  2, i25                    
    53 : unspill                i26, 3                    
    54 : unspill                i25, 6                    
    55 : iverson_gt             i24, i25, i26             
    56 : unspill                i25, 5                    
    57 : unspill                i26, 1                    
    58 : sub                    i27, i25, i26             
    59 : spill                  9, i27                    
    60 : sub                    i24, 0, i24               
    61 : unspill                i25, 9                    
    62 : and                    i24, i24, i25             
    63 : unspill                i25, 1                    
    64 : add                    i25, i25, i24             
    65 : spill                  1, i25                    
    66 : unspill                i26, 3                    
    67 : unspill                i25, 6                    
    68 : iverson_gt             i24, i25, i26             
    69 : unspill                i25, 3                    
    70 : unspill                i26, 6                    
    71 : sub                    i27, i25, i26             
    72 : spill                  10, i27                   
    73 : sub                    i24, 0, i24               
    74 : unspill                i25, 10                   
    75 : and                    i24, i24, i25             
    76 : unspill                i25, 6                    
    77 : add                    i26, i25, i24             
    78 : spill                  3, i26                    
    79 : unspill                i25, 5                    
    80 : add                    i25, i25, 4               
    81 : spill                  5, i25                    
    82 : annotation:endwhile    0, 2                      
    83 : unspill                i25, 0                    
    84 : sar                    i25, i25, 2               
    85 : spill                  0, i25                    
    86 : unspill                i25, 1                    
    87 : sar                    i25, i25, 2               
    88 : spill                  1, i25                    
    89 : unspill                i25, 0                    
    90 : store.i32              i12, i25                  
    91 : unspill                i25, 1                    
    92 : store.i32              i13, i25                  
    93 : mov                    i10, 0                    
    94 : ret                                              
    95 : unspill                i24, 11                   
    96 : unspill                i25, 12                   
    97 : unspill                i26, 13                   
    98 : unspill                i27, 14                   
    99 : add                    i2, i2, 128               
