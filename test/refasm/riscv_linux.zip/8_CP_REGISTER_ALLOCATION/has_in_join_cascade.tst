has_in_join_cascade(i0, i1, i2)
     0 : sub                    i2, i2, 128                
     1 : spill                  13, i24                    
     2 : spill                  14, i25                    
     3 : spill                  15, i26                    
     4 : mov                    i25, 0                     
     5 : spill                  5, i25                     
     6 : load.i64               i25, i10, 16               
     7 : spill                  6, i25                     
     8 : load.i64               i25, i10, 0                
     9 : spill                  7, i25                     
    10 : load.i64               i25, i10, 8                
    11 : spill                  8, i25                     
    12 : annotation:whilecstart 0                          
    13 : mov                    i13, 0                     
    14 : unspill                i25, 6                     
    15 : jmp_le                 i25, i13, __loops_label_2  
    16 : annotation:whilecend                              
    17 : unspill                i25, 7                     
    18 : load.i32               i26, i25                   
    19 : spill                  9, i26                     
    20 : unspill                i25, 7                     
    21 : add                    i25, i25, 4                
    22 : spill                  7, i25                     
    23 : unspill                i25, 8                     
    24 : load.i32               i26, i25                   
    25 : spill                  4, i26                     
    26 : unspill                i25, 8                     
    27 : add                    i25, i25, 4                
    28 : spill                  8, i25                     
    29 : unspill                i25, 6                     
    30 : sub                    i25, i25, 1                
    31 : spill                  6, i25                     
    32 : load.i64               i25, i10, 40               
    33 : spill                  10, i25                    
    34 : load.i64               i25, i10, 24               
    35 : spill                  11, i25                    
    36 : load.i64               i25, i10, 32               
    37 : spill                  12, i25                    
    38 : annotation:whilecstart 3                          
    39 : mov                    i13, 0                     
    40 : unspill                i25, 10                    
    41 : jmp_le                 i25, i13, __loops_label_5  
    42 : annotation:whilecend                              
    43 : unspill                i25, 11                    
    44 : load.i32               i26, i25                   
    45 : spill                  0, i26                     
    46 : unspill                i25, 11                    
    47 : add                    i25, i25, 4                
    48 : spill                  11, i25                    
    49 : unspill                i25, 12                    
    50 : load.i32               i13, i25                   
    51 : unspill                i25, 12                    
    52 : add                    i25, i25, 4                
    53 : spill                  12, i25                    
    54 : unspill                i25, 10                    
    55 : sub                    i25, i25, 1                
    56 : spill                  10, i25                    
    57 : annotation:ifcstart                               
    58 : unspill                i25, 9                     
    59 : jmp_le                 i13, i25, __loops_label_7  
    60 : annotation:ifcend                                 
    61 : annotation:continue    0                          
    62 : annotation:else        7, 8                       
    63 : annotation:ifcstart                               
    64 : unspill                i25, 9                     
    65 : jmp_ne                 i13, i25, __loops_label_10 
    66 : annotation:ifcend                                 
    67 : load.i64               i25, i10, 64               
    68 : spill                  1, i25                     
    69 : load.i64               i25, i10, 48               
    70 : spill                  2, i25                     
    71 : load.i64               i25, i10, 56               
    72 : spill                  3, i25                     
    73 : annotation:whilecstart 11                         
    74 : mov                    i24, 0                     
    75 : unspill                i25, 1                     
    76 : jmp_le                 i25, i24, __loops_label_13 
    77 : annotation:whilecend                              
    78 : unspill                i25, 2                     
    79 : load.i32               i24, i25                   
    80 : unspill                i25, 2                     
    81 : add                    i25, i25, 4                
    82 : spill                  2, i25                     
    83 : unspill                i25, 3                     
    84 : load.i32               i13, i25                   
    85 : unspill                i25, 3                     
    86 : add                    i25, i25, 4                
    87 : spill                  3, i25                     
    88 : unspill                i25, 1                     
    89 : sub                    i25, i25, 1                
    90 : spill                  1, i25                     
    91 : annotation:ifcstart                               
    92 : unspill                i25, 4                     
    93 : jmp_le                 i24, i25, __loops_label_15 
    94 : annotation:ifcend                                 
    95 : annotation:continue    0                          
    96 : annotation:else        15, 16                     
    97 : annotation:ifcstart                               
    98 : unspill                i25, 4                     
    99 : jmp_ne                 i24, i25, __loops_label_18 
   100 : unspill                i25, 0                     
   101 : jmp_ne                 i25, i11, __loops_label_18 
   102 : jmp_ne                 i13, i12, __loops_label_18 
   103 : annotation:ifcend                                 
   104 : mov                    i25, 1                     
   105 : spill                  5, i25                     
   106 : annotation:break       2                          
   107 : annotation:endif       16                         
   108 : annotation:endif       18                         
   109 : annotation:endwhile    11, 13                     
   110 : annotation:endif       8                          
   111 : annotation:endif       10                         
   112 : annotation:endwhile    3, 5                       
   113 : annotation:endwhile    0, 2                       
   114 : unspill                i25, 5                     
   115 : mov                    i10, i25                   
   116 : ret                                               
   117 : unspill                i24, 13                    
   118 : unspill                i25, 14                    
   119 : unspill                i26, 15                    
   120 : add                    i2, i2, 128                
