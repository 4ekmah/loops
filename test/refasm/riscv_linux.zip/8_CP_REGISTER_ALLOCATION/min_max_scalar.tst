min_max_scalar(i0, i1, i2, i3)
     0 : sub                    i2, i2, 112               
     1 : spill                  10, i24                   
     2 : spill                  11, i25                   
     3 : spill                  12, i26                   
     4 : mov                    i25, 0                    
     5 : spill                  9, i25                    
     6 : mov                    i25, 0                    
     7 : spill                  4, i25                    
     8 : mov                    i25, 0                    
     9 : spill                  5, i25                    
    10 : load.i32               i25, i10                  
    11 : spill                  6, i25                    
    12 : unspill                i25, 6                    
    13 : mov                    i26, i25                  
    14 : spill                  7, i26                    
    15 : mov                    i24, 4                    
    16 : mul                    i11, i11, i24             
    17 : spill                  8, i11                    
    18 : annotation:whilecstart 0                         
    19 : unspill                i26, 8                    
    20 : unspill                i25, 9                    
    21 : jmp_ge                 i25, i26, __loops_label_2 
    22 : annotation:whilecend                             
    23 : unspill                i25, 9                    
    24 : add                    i24, i10, i25             
    25 : load.i32               i24, i24                  
    26 : annotation:ifcstart                              
    27 : unspill                i25, 6                    
    28 : jmp_ge                 i24, i25, __loops_label_4 
    29 : annotation:ifcend                                
    30 : mov                    i25, i24                  
    31 : spill                  6, i25                    
    32 : unspill                i25, 9                    
    33 : mov                    i26, i25                  
    34 : spill                  4, i26                    
    35 : annotation:endif       4                         
    36 : annotation:ifcstart                              
    37 : unspill                i25, 7                    
    38 : jmp_le                 i24, i25, __loops_label_6 
    39 : annotation:ifcend                                
    40 : mov                    i25, i24                  
    41 : spill                  7, i25                    
    42 : unspill                i25, 9                    
    43 : mov                    i26, i25                  
    44 : spill                  5, i26                    
    45 : annotation:endif       6                         
    46 : unspill                i25, 9                    
    47 : add                    i25, i25, 4               
    48 : spill                  9, i25                    
    49 : annotation:endwhile    0, 2                      
    50 : mov                    i10, 4                    
    51 : unspill                i25, 4                    
    52 : div                    i11, i25, i10             
    53 : unspill                i25, 5                    
    54 : div                    i10, i25, i10             
    55 : store.i32              i12, i11                  
    56 : store.i32              i13, i10                  
    57 : mov                    i10, 0                    
    58 : ret                                              
    59 : unspill                i24, 10                   
    60 : unspill                i25, 11                   
    61 : unspill                i26, 12                   
    62 : add                    i2, i2, 112               
