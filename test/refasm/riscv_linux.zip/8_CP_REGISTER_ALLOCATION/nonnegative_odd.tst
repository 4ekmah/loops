nonnegative_odd(i0, i1)
     0 : sub                    i2, i2, 64                
     1 : spill                  6, i24                    
     2 : spill                  7, i25                    
     3 : mov                    i12, 0                    
     4 : mov                    i25, -4                   
     5 : spill                  5, i25                    
     6 : mov                    i13, 4                    
     7 : mul                    i11, i11, i13             
     8 : spill                  4, i11                    
     9 : annotation:whilecstart 0                         
    10 : unspill                i25, 4                    
    11 : jmp_ge                 i12, i25, __loops_label_2 
    12 : annotation:whilecend                             
    13 : add                    i24, i10, i12             
    14 : load.i32               i24, i24                  
    15 : annotation:ifcstart                              
    16 : mov                    i13, 0                    
    17 : jmp_ge                 i24, i13, __loops_label_4 
    18 : annotation:ifcend                                
    19 : add                    i12, i12, 4               
    20 : annotation:continue    0                         
    21 : annotation:endif       4                         
    22 : mov                    i13, 2                    
    23 : mod                    i13, i24, i13             
    24 : annotation:ifcstart                              
    25 : mov                    i24, 0                    
    26 : jmp_eq                 i13, i24, __loops_label_6 
    27 : annotation:ifcend                                
    28 : mov                    i25, i12                  
    29 : spill                  5, i25                    
    30 : annotation:break       2                         
    31 : annotation:endif       6                         
    32 : add                    i12, i12, 4               
    33 : annotation:endwhile    0, 2                      
    34 : mov                    i10, 4                    
    35 : unspill                i25, 5                    
    36 : div                    i10, i25, i10             
    37 : mov                    i10, i10                  
    38 : ret                                              
    39 : unspill                i24, 6                    
    40 : unspill                i25, 7                    
    41 : add                    i2, i2, 64                
