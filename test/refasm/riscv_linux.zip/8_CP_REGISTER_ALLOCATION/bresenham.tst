bresenham(i0, i1, i2, i3, i4, i5, i6)
     0 : sub                    i2, i2, 128                
     1 : spill                  11, i24                    
     2 : spill                  12, i25                    
     3 : spill                  13, i26                    
     4 : spill                  14, i27                    
     5 : sub                    i25, i14, i12              
     6 : spill                  5, i25                     
     7 : unspill                i25, 5                     
     8 : iverson_gt             i24, 0, i25                
     9 : sub                    i24, 0, i24                
    10 : unspill                i25, 5                     
    11 : and                    i26, i24, i25              
    12 : spill                  6, i26                     
    13 : unspill                i25, 5                     
    14 : sub                    i24, 0, i25                
    15 : unspill                i25, 6                     
    16 : add                    i24, i24, i25              
    17 : unspill                i25, 6                     
    18 : add                    i26, i24, i25              
    19 : spill                  4, i26                     
    20 : sub                    i24, i14, i12              
    21 : iverson_gt             i25, i24, 0                
    22 : spill                  7, i25                     
    23 : iverson_gt             i24, 0, i24                
    24 : unspill                i25, 7                     
    25 : sub                    i26, i24, i25              
    26 : spill                  0, i26                     
    27 : sub                    i25, i15, i13              
    28 : spill                  8, i25                     
    29 : unspill                i25, 8                     
    30 : iverson_gt             i24, 0, i25                
    31 : sub                    i24, 0, i24                
    32 : unspill                i25, 8                     
    33 : and                    i26, i24, i25              
    34 : spill                  9, i26                     
    35 : unspill                i25, 8                     
    36 : sub                    i24, 0, i25                
    37 : unspill                i25, 9                     
    38 : add                    i24, i24, i25              
    39 : unspill                i25, 9                     
    40 : add                    i24, i24, i25              
    41 : neg                    i25, i24                   
    42 : spill                  1, i25                     
    43 : sub                    i24, i15, i13              
    44 : iverson_gt             i25, i24, 0                
    45 : spill                  10, i25                    
    46 : iverson_gt             i24, 0, i24                
    47 : unspill                i25, 10                    
    48 : sub                    i26, i24, i25              
    49 : spill                  2, i26                     
    50 : unspill                i25, 4                     
    51 : unspill                i26, 1                     
    52 : add                    i27, i25, i26              
    53 : spill                  3, i27                     
    54 : annotation:whilecstart 0                          
    55 : mov                    i24, 0                     
    56 : jmp_eq                 i10, i24, __loops_label_2  
    57 : annotation:whilecend                              
    58 : mul                    i24, i13, i11              
    59 : add                    i24, i24, i12              
    60 : add                    i24, i10, i24              
    61 : store.u8               i24, i16                   
    62 : annotation:ifcstart                               
    63 : jmp_ne                 i12, i14, __loops_label_4  
    64 : jmp_ne                 i13, i15, __loops_label_4  
    65 : annotation:ifcend                                 
    66 : annotation:break       2                          
    67 : annotation:endif       4                          
    68 : unspill                i25, 3                     
    69 : shl                    i24, i25, 1                
    70 : annotation:ifcstart                               
    71 : unspill                i25, 1                     
    72 : jmp_gt                 i24, i25, __loops_label_6  
    73 : annotation:ifcend                                 
    74 : annotation:ifcstart                               
    75 : jmp_ne                 i12, i14, __loops_label_8  
    76 : annotation:ifcend                                 
    77 : annotation:break       2                          
    78 : annotation:endif       8                          
    79 : unspill                i26, 1                     
    80 : unspill                i25, 3                     
    81 : add                    i25, i25, i26              
    82 : spill                  3, i25                     
    83 : unspill                i25, 0                     
    84 : add                    i12, i12, i25              
    85 : annotation:endif       6                          
    86 : annotation:ifcstart                               
    87 : unspill                i25, 4                     
    88 : jmp_gt                 i24, i25, __loops_label_10 
    89 : annotation:ifcend                                 
    90 : annotation:ifcstart                               
    91 : jmp_ne                 i13, i15, __loops_label_12 
    92 : annotation:ifcend                                 
    93 : annotation:break       2                          
    94 : annotation:endif       12                         
    95 : unspill                i26, 4                     
    96 : unspill                i25, 3                     
    97 : add                    i25, i25, i26              
    98 : spill                  3, i25                     
    99 : unspill                i25, 2                     
   100 : add                    i13, i13, i25              
   101 : annotation:endif       10                         
   102 : annotation:endwhile    0, 2                       
   103 : ret                                               
   104 : unspill                i24, 11                    
   105 : unspill                i25, 12                    
   106 : unspill                i26, 13                    
   107 : unspill                i27, 14                    
   108 : add                    i2, i2, 128                
