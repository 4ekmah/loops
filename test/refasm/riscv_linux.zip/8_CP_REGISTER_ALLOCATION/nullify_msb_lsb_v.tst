nullify_msb_lsb_v(i0, i1, i2, i3)
     0 : mov                    i14, 0                    
     1 : mov                    i16, 4                    
     2 : mul                    i15, i13, i16             
     3 : rv_vsetvli             i13, 0, 144               
     4 : broadcast.u32          v0, 1                     
     5 : annotation:whilecstart 0                         
     6 : jmp_ge                 i14, i15, __loops_label_2 
     7 : annotation:whilecend                             
     8 : add                    i16, i10, i14             
     9 : vld.u32                v1, i16                   
    10 : rv_vsetvli             i16, 0, 144               
    11 : shr.u32                v2, v1, 1                 
    12 : or                     v2, v1, v2                
    13 : shr.u32                v3, v2, 2                 
    14 : or                     v2, v2, v3                
    15 : shr.u32                v3, v2, 4                 
    16 : or                     v2, v2, v3                
    17 : shr.u32                v3, v2, 8                 
    18 : or                     v2, v2, v3                
    19 : shr.u32                v3, v2, 16                
    20 : or                     v2, v2, v3                
    21 : add.u32                v2, v2, v0                
    22 : shr.u32                v2, v2, 1                 
    23 : xor                    v2, v2, v1                
    24 : add                    i16, i11, i14             
    25 : vst.u32                i16, v2                   
    26 : sub.u32                v2, v1, v0                
    27 : not                    v2, v2                    
    28 : and                    v2, v1, v2                
    29 : xor                    v1, v2, v1                
    30 : add                    i16, i12, i14             
    31 : vst.u32                i16, v1                   
    32 : add                    i14, i14, 32              
    33 : annotation:endwhile    0, 2                      
    34 : ret                                              
