sibling_loops(i0, i1, i2)
     0 : sub                    i2, i2, 64                
     1 : spill                  6, i24                    
     2 : spill                  7, i25                    
     3 : mov                    i13, 0                    
     4 : mov                    i25, 0                    
     5 : spill                  4, i25                    
     6 : annotation:whilecstart 0                         
     7 : jmp_ge                 i13, i11, __loops_label_2 
     8 : annotation:whilecend                             
     9 : add                    i24, i10, i13             
    10 : load.i32               i24, i24                  
    11 : unspill                i25, 4                    
    12 : add                    i25, i25, i24             
    13 : spill                  4, i25                    
    14 : add                    i13, i13, 4               
    15 : annotation:endwhile    0, 2                      
    16 : mov                    i10, 0                    
    17 : spill                  5, i10                    
    18 : annotation:whilecstart 3                         
    19 : mov                    i24, 0                    
    20 : jmp_le                 i13, i24, __loops_label_5 
    21 : annotation:whilecend                             
    22 : unspill                i25, 5                    
    23 : add                    i25, i25, 1               
    24 : spill                  5, i25                    
    25 : sub                    i13, i13, 4               
    26 : annotation:endwhile    3, 5                      
    27 : unspill                i10, 5                    
    28 : unspill                i25, 4                    
    29 : store.i32              i12, i25                  
    30 : store.i32              i12, 4, i10               
    31 : mov                    i10, 0                    
    32 : ret                                              
    33 : unspill                i24, 6                    
    34 : unspill                i25, 7                    
    35 : add                    i2, i2, 64                
