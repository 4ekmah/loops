conditionpainter(i0)
     0 : sub                    i2, i2, 64                
     1 : spill                  5, i24                    
     2 : spill                  6, i25                    
     3 : mov                    i25, -5                   
     4 : spill                  2, i25                    
     5 : annotation:whilecstart 0                         
     6 : mov                    i11, 5                    
     7 : unspill                i25, 2                    
     8 : jmp_gt                 i25, i11, __loops_label_2 
     9 : annotation:whilecend                             
    10 : unspill                i25, 2                    
    11 : add                    i11, i25, 5               
    12 : mov                    i12, 11                   
    13 : mul                    i11, i11, i12             
    14 : mov                    i12, 8                    
    15 : mul                    i25, i11, i12             
    16 : spill                  1, i25                    
    17 : mov                    i25, -5                   
    18 : spill                  0, i25                    
    19 : annotation:whilecstart 3                         
    20 : mov                    i24, 5                    
    21 : unspill                i25, 0                    
    22 : jmp_gt                 i25, i24, __loops_label_5 
    23 : annotation:whilecend                             
    24 : unspill                i25, 0                    
    25 : add                    i24, i25, 3               
    26 : unspill                i25, 2                    
    27 : iverson_gt             i24, i25, i24             
    28 : neg                    i24, i24                  
    29 : add                    i24, i24, 1               
    30 : mov                    i13, 4                    
    31 : unspill                i25, 2                    
    32 : iverson_gt             i13, i25, i13             
    33 : neg                    i13, i13                  
    34 : add                    i13, i13, 1               
    35 : and                    i13, i24, i13             
    36 : mov                    i24, -2                   
    37 : unspill                i25, 0                    
    38 : iverson_gt             i24, i25, i24             
    39 : neg                    i24, i24                  
    40 : add                    i24, i24, 1               
    41 : and                    i13, i13, i24             
    42 : mov                    i24, 0                    
    43 : unspill                i25, 0                    
    44 : iverson_gt             i24, i25, i24             
    45 : neg                    i24, i24                  
    46 : add                    i24, i24, 1               
    47 : and                    i13, i13, i24             
    48 : unspill                i25, 0                    
    49 : sub                    i24, i25, 1               
    50 : unspill                i25, 2                    
    51 : iverson_gt             i24, i25, i24             
    52 : neg                    i24, i24                  
    53 : add                    i24, i24, 1               
    54 : mov                    i12, 0                    
    55 : unspill                i25, 0                    
    56 : iverson_gt             i12, i25, i12             
    57 : neg                    i12, i12                  
    58 : add                    i12, i12, 1               
    59 : and                    i12, i24, i12             
    60 : mov                    i24, 0                    
    61 : unspill                i25, 2                    
    62 : iverson_gt             i24, i25, i24             
    63 : neg                    i24, i24                  
    64 : add                    i24, i24, 1               
    65 : and                    i12, i12, i24             
    66 : unspill                i25, 0                    
    67 : mul                    i24, i25, i25             
    68 : unspill                i25, 2                    
    69 : mul                    i11, i25, i25             
    70 : add                    i11, i24, i11             
    71 : mov                    i24, 9                    
    72 : iverson_gt             i11, i11, i24             
    73 : neg                    i11, i11                  
    74 : add                    i11, i11, 1               
    75 : and                    i11, i12, i11             
    76 : or                     i25, i13, i11             
    77 : spill                  3, i25                    
    78 : mov                    i12, 2                    
    79 : mov                    i25, 0                    
    80 : spill                  4, i25                    
    81 : mov                    i24, 2                    
    82 : unspill                i25, 0                    
    83 : iverson_gt             i24, i25, i24             
    84 : neg                    i24, i24                  
    85 : add                    i24, i24, 1               
    86 : mov                    i11, 4                    
    87 : unspill                i25, 0                    
    88 : iverson_gt             i11, i25, i11             
    89 : neg                    i11, i11                  
    90 : add                    i11, i11, 1               
    91 : and                    i11, i24, i11             
    92 : mov                    i24, 1                    
    93 : unspill                i25, 2                    
    94 : iverson_gt             i24, i25, i24             
    95 : neg                    i24, i24                  
    96 : add                    i24, i24, 1               
    97 : mov                    i13, 3                    
    98 : unspill                i25, 2                    
    99 : iverson_gt             i13, i25, i13             
   100 : neg                    i13, i13                  
   101 : add                    i13, i13, 1               
   102 : and                    i13, i24, i13             
   103 : or                     i11, i11, i13             
   104 : unspill                i25, 0                    
   105 : mul                    i13, i25, i25             
   106 : unspill                i25, 2                    
   107 : mul                    i24, i25, i25             
   108 : add                    i13, i13, i24             
   109 : mov                    i24, 16                   
   110 : iverson_gt             i13, i13, i24             
   111 : neg                    i13, i13                  
   112 : add                    i13, i13, 1               
   113 : and                    i11, i11, i13             
   114 : mov                    i13, 0                    
   115 : sub                    i11, i11, i13             
   116 : iverson_ne             i11, i11, 0               
   117 : unspill                i25, 4                    
   118 : sub                    i12, i12, i25             
   119 : sub                    i11, 0, i11               
   120 : and                    i11, i11, i12             
   121 : unspill                i25, 4                    
   122 : add                    i11, i25, i11             
   123 : unspill                i25, 3                    
   124 : add                    i11, i25, i11             
   125 : annotation:ifcstart                              
   126 : mov                    i12, 2                    
   127 : unspill                i25, 2                    
   128 : mul                    i12, i25, i12             
   129 : unspill                i25, 0                    
   130 : jmp_gt                 i12, i25, __loops_label_8 
   131 : unspill                i25, 0                    
   132 : add                    i12, i25, 3               
   133 : neg                    i12, i12                  
   134 : unspill                i25, 0                    
   135 : add                    i13, i25, 3               
   136 : mul                    i12, i12, i13             
   137 : unspill                i25, 2                    
   138 : jmp_le                 i25, i12, __loops_label_9 
   139 : __loops_label_8:                                 
   140 : mov                    i12, 2                    
   141 : unspill                i25, 0                    
   142 : mul                    i12, i25, i12             
   143 : unspill                i25, 2                    
   144 : jmp_gt                 i25, i12, __loops_label_7 
   145 : unspill                i25, 0                    
   146 : add                    i12, i25, 3               
   147 : neg                    i12, i12                  
   148 : unspill                i25, 0                    
   149 : add                    i13, i25, 3               
   150 : mul                    i12, i12, i13             
   151 : unspill                i25, 2                    
   152 : jmp_gt                 i25, i12, __loops_label_7 
   153 : __loops_label_9:                                 
   154 : mov                    i12, 0                    
   155 : unspill                i25, 0                    
   156 : jmp_gt                 i25, i12, __loops_label_7 
   157 : annotation:ifcend                                
   158 : add                    i11, i11, 3               
   159 : annotation:endif       7                         
   160 : unspill                i25, 0                    
   161 : add                    i12, i25, 5               
   162 : shl                    i12, i12, 3               
   163 : unspill                i25, 1                    
   164 : add                    i12, i25, i12             
   165 : add                    i12, i10, i12             
   166 : store.i64              i12, i11                  
   167 : unspill                i25, 0                    
   168 : add                    i25, i25, 1               
   169 : spill                  0, i25                    
   170 : annotation:endwhile    3, 5                      
   171 : unspill                i25, 2                    
   172 : add                    i25, i25, 1               
   173 : spill                  2, i25                    
   174 : annotation:endwhile    0, 2                      
   175 : ret                                              
   176 : unspill                i24, 5                    
   177 : unspill                i25, 6                    
   178 : add                    i2, i2, 64                
