fixed_power_v_int32_t_0(i0, i1, i2)
     0 : mov                    i13, 0                    
     1 : mov                    i15, 4                    
     2 : mul                    i14, i12, i15             
     3 : annotation:whilecstart 0                         
     4 : jmp_ge                 i13, i14, __loops_label_2 
     5 : annotation:whilecend                             
     6 : add                    i15, i10, i13             
     7 : vld.i32                v0, i15                   
     8 : rv_vsetvli             i15, 0, 144               
     9 : broadcast.i32          v0, 1                     
    10 : add                    i15, i11, i13             
    11 : vst.i32                i15, v0                   
    12 : add                    i13, i13, 32              
    13 : annotation:endwhile    0, 2                      
    14 : mov                    i10, 0                    
    15 : ret                                              
