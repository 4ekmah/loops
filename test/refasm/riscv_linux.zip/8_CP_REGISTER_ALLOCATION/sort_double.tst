sort_double(i0, i1)
     0 : sub                    i2, i2, 224               
     1 : spill                  22, i24                   
     2 : spill                  23, i25                   
     3 : spill                  24, i26                   
     4 : spill                  26, i8                    
     5 : spill                  27, i1                    
     6 : shl                    i25, i11, 3               
     7 : spill                  18, i25                   
     8 : unspill                i25, 18                   
     9 : sub                    i26, i25, 8               
    10 : spill                  20, i26                   
    11 : mov                    i25, 0                    
    12 : spill                  21, i25                   
    13 : annotation:whilecstart 0                         
    14 : unspill                i26, 20                   
    15 : unspill                i25, 21                   
    16 : jmp_ge                 i25, i26, __loops_label_2 
    17 : annotation:whilecend                             
    18 : unspill                i25, 21                   
    19 : mov                    i26, i25                  
    20 : spill                  17, i26                   
    21 : unspill                i25, 17                   
    22 : add                    i26, i25, 8               
    23 : spill                  16, i26                   
    24 : annotation:whilecstart 3                         
    25 : unspill                i26, 18                   
    26 : unspill                i25, 16                   
    27 : jmp_ge                 i25, i26, __loops_label_5 
    28 : annotation:whilecend                             
    29 : annotation:ifcstart                              
    30 : unspill                i25, 16                   
    31 : add                    i24, i10, i25             
    32 : load.fp64              i24, i24                  
    33 : unspill                i25, 17                   
    34 : add                    i13, i10, i25             
    35 : load.fp64              i25, i13                  
    36 : spill                  19, i25                   
    37 : mov                    i12, 43                   
    38 : shl                    i12, i12, 32              
    39 : rv_lui                 i13, 850104               
    40 : add                    i13, i13, -1614           
    41 : add                    i12, i12, i13             
    42 : unspill                i25, 19                   
    43 : call                   [i12](i12, i24, i25)      
    44 : mov                    i13, 0                    
    45 : jmp_eq                 i12, i13, __loops_label_7 
    46 : annotation:ifcend                                
    47 : unspill                i25, 16                   
    48 : mov                    i26, i25                  
    49 : spill                  17, i26                   
    50 : annotation:endif       7                         
    51 : unspill                i25, 16                   
    52 : add                    i25, i25, 8               
    53 : spill                  16, i25                   
    54 : annotation:endwhile    3, 5                      
    55 : annotation:ifcstart                              
    56 : unspill                i26, 21                   
    57 : unspill                i25, 17                   
    58 : jmp_eq                 i25, i26, __loops_label_9 
    59 : annotation:ifcend                                
    60 : unspill                i25, 21                   
    61 : add                    i12, i10, i25             
    62 : load.fp64              i12, i12                  
    63 : unspill                i25, 17                   
    64 : add                    i13, i10, i25             
    65 : load.fp64              i13, i13                  
    66 : unspill                i25, 17                   
    67 : add                    i24, i10, i25             
    68 : store.fp64             i24, i12                  
    69 : unspill                i25, 21                   
    70 : add                    i12, i10, i25             
    71 : store.fp64             i12, i13                  
    72 : annotation:endif       9                         
    73 : unspill                i25, 21                   
    74 : add                    i25, i25, 8               
    75 : spill                  21, i25                   
    76 : annotation:endwhile    0, 2                      
    77 : ret                                              
    78 : unspill                i8, 26                    
    79 : unspill                i1, 27                    
    80 : unspill                i24, 22                   
    81 : unspill                i25, 23                   
    82 : unspill                i26, 24                   
    83 : add                    i2, i2, 224               
