snake(i0, i1, i2)
     0 : sub                    i2, i2, 256               
     1 : spill                  27, i24                   
     2 : spill                  28, i25                   
     3 : spill                  29, i26                   
     4 : spill                  30, i8                    
     5 : spill                  31, i1                    
     6 : add                    i13, i11, i12             
     7 : sub                    i25, i13, 1               
     8 : spill                  21, i25                   
     9 : mov                    i25, 0                    
    10 : spill                  20, i25                   
    11 : mov                    i25, 1                    
    12 : spill                  19, i25                   
    13 : unspill                i25, 19                   
    14 : neg                    i26, i25                  
    15 : spill                  16, i26                   
    16 : mov                    i25, 0                    
    17 : spill                  22, i25                   
    18 : annotation:whilecstart 0                         
    19 : unspill                i26, 21                   
    20 : unspill                i25, 22                   
    21 : jmp_ge                 i25, i26, __loops_label_2 
    22 : annotation:whilecend                             
    23 : mov                    i25, 0                    
    24 : spill                  17, i25                   
    25 : mov                    i25, 0                    
    26 : spill                  18, i25                   
    27 : annotation:ifcstart                              
    28 : unspill                i25, 22                   
    29 : and                    i13, i25, 1               
    30 : mov                    i24, 0                    
    31 : jmp_eq                 i13, i24, __loops_label_4 
    32 : annotation:ifcend                                
    33 : sub                    i25, i12, 1               
    34 : spill                  23, i25                   
    35 : unspill                i26, 22                   
    36 : unspill                i25, 23                   
    37 : iverson_gt             i24, i25, i26             
    38 : unspill                i26, 22                   
    39 : unspill                i25, 23                   
    40 : sub                    i13, i25, i26             
    41 : sub                    i24, 0, i24               
    42 : and                    i13, i24, i13             
    43 : unspill                i25, 22                   
    44 : add                    i26, i25, i13             
    45 : spill                  17, i26                   
    46 : unspill                i25, 22                   
    47 : unspill                i26, 23                   
    48 : sub                    i13, i25, i26             
    49 : mov                    i25, 0                    
    50 : spill                  24, i25                   
    51 : unspill                i25, 22                   
    52 : unspill                i26, 23                   
    53 : iverson_gt             i24, i25, i26             
    54 : unspill                i25, 24                   
    55 : sub                    i13, i13, i25             
    56 : sub                    i24, 0, i24               
    57 : and                    i13, i24, i13             
    58 : unspill                i25, 24                   
    59 : add                    i26, i25, i13             
    60 : spill                  18, i26                   
    61 : annotation:else        4, 5                      
    62 : sub                    i25, i11, 1               
    63 : spill                  25, i25                   
    64 : unspill                i25, 22                   
    65 : unspill                i26, 25                   
    66 : sub                    i24, i25, i26             
    67 : mov                    i25, 0                    
    68 : spill                  26, i25                   
    69 : unspill                i25, 22                   
    70 : unspill                i26, 25                   
    71 : iverson_gt             i13, i25, i26             
    72 : unspill                i25, 26                   
    73 : sub                    i24, i24, i25             
    74 : sub                    i13, 0, i13               
    75 : and                    i13, i13, i24             
    76 : unspill                i25, 26                   
    77 : add                    i26, i25, i13             
    78 : spill                  17, i26                   
    79 : unspill                i26, 22                   
    80 : unspill                i25, 25                   
    81 : iverson_gt             i13, i25, i26             
    82 : unspill                i26, 22                   
    83 : unspill                i25, 25                   
    84 : sub                    i24, i25, i26             
    85 : sub                    i13, 0, i13               
    86 : and                    i13, i13, i24             
    87 : unspill                i25, 22                   
    88 : add                    i26, i25, i13             
    89 : spill                  18, i26                   
    90 : annotation:endif       5                         
    91 : annotation:whilecstart 6                         
    92 : mov                    i24, 0                    
    93 : unspill                i25, 17                   
    94 : jmp_gt                 i25, i24, __loops_label_8 
    95 : unspill                i25, 17                   
    96 : jmp_ge                 i25, i12, __loops_label_8 
    97 : mov                    i24, 0                    
    98 : unspill                i25, 18                   
    99 : jmp_gt                 i25, i24, __loops_label_8 
   100 : unspill                i25, 18                   
   101 : jmp_ge                 i25, i11, __loops_label_8 
   102 : annotation:whilecend                             
   103 : mov                    i24, 43                   
   104 : shl                    i24, i24, 32              
   105 : rv_lui                 i13, 850102               
   106 : add                    i13, i13, 286             
   107 : add                    i13, i24, i13             
   108 : unspill                i25, 17                   
   109 : unspill                i26, 18                   
   110 : call_noret             [i13](i25, i26)           
   111 : unspill                i25, 18                   
   112 : mul                    i13, i25, i12             
   113 : unspill                i25, 17                   
   114 : add                    i13, i13, i25             
   115 : add                    i13, i10, i13             
   116 : unspill                i25, 20                   
   117 : store.u8               i13, i25                  
   118 : unspill                i25, 20                   
   119 : add                    i25, i25, 1               
   120 : spill                  20, i25                   
   121 : unspill                i26, 19                   
   122 : unspill                i25, 17                   
   123 : add                    i25, i25, i26             
   124 : spill                  17, i25                   
   125 : unspill                i26, 16                   
   126 : unspill                i25, 18                   
   127 : add                    i25, i25, i26             
   128 : spill                  18, i25                   
   129 : annotation:endwhile    6, 8                      
   130 : unspill                i25, 19                   
   131 : neg                    i25, i25                  
   132 : spill                  19, i25                   
   133 : unspill                i25, 16                   
   134 : neg                    i25, i25                  
   135 : spill                  16, i25                   
   136 : unspill                i25, 22                   
   137 : add                    i25, i25, 1               
   138 : spill                  22, i25                   
   139 : annotation:endwhile    0, 2                      
   140 : ret                                              
   141 : unspill                i8, 30                    
   142 : unspill                i1, 31                    
   143 : unspill                i24, 27                   
   144 : unspill                i25, 28                   
   145 : unspill                i26, 29                   
   146 : add                    i2, i2, 256               
