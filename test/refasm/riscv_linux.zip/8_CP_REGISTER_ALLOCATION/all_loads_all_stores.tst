all_loads_all_stores(i0, i1, i2, i3, i4)
     0 : sub                    i2, i2, 224                
     1 : spill                  24, i24                    
     2 : spill                  25, i25                    
     3 : spill                  26, i26                    
     4 : spill                  27, i27                    
     5 : mov                    i25, 0                     
     6 : spill                  4, i25                     
     7 : mov                    i25, 0                     
     8 : spill                  0, i25                     
     9 : mov                    i25, 0                     
    10 : spill                  1, i25                     
    11 : mov                    i25, 2                     
    12 : spill                  7, i25                     
    13 : mov                    i25, 1                     
    14 : spill                  6, i25                     
    15 : mov                    i24, 1                     
    16 : iverson_gt             i24, i11, i24              
    17 : unspill                i25, 7                     
    18 : unspill                i26, 6                     
    19 : sub                    i27, i25, i26              
    20 : spill                  8, i27                     
    21 : sub                    i24, 0, i24                
    22 : unspill                i25, 8                     
    23 : and                    i24, i24, i25              
    24 : unspill                i25, 6                     
    25 : add                    i26, i25, i24              
    26 : spill                  9, i26                     
    27 : mov                    i25, 4                     
    28 : spill                  10, i25                    
    29 : mov                    i24, 3                     
    30 : iverson_gt             i24, i11, i24              
    31 : unspill                i26, 9                     
    32 : unspill                i25, 10                    
    33 : sub                    i27, i25, i26              
    34 : spill                  11, i27                    
    35 : sub                    i24, 0, i24                
    36 : unspill                i25, 11                    
    37 : and                    i24, i24, i25              
    38 : unspill                i25, 9                     
    39 : add                    i26, i25, i24              
    40 : spill                  12, i26                    
    41 : mov                    i25, 8                     
    42 : spill                  13, i25                    
    43 : mov                    i24, 5                     
    44 : iverson_gt             i24, i11, i24              
    45 : unspill                i26, 12                    
    46 : unspill                i25, 13                    
    47 : sub                    i27, i25, i26              
    48 : spill                  14, i27                    
    49 : sub                    i24, 0, i24                
    50 : unspill                i25, 14                    
    51 : and                    i24, i24, i25              
    52 : unspill                i25, 12                    
    53 : add                    i26, i25, i24              
    54 : spill                  2, i26                     
    55 : mov                    i25, 2                     
    56 : spill                  16, i25                    
    57 : mov                    i25, 1                     
    58 : spill                  15, i25                    
    59 : mov                    i24, 1                     
    60 : iverson_gt             i24, i13, i24              
    61 : unspill                i25, 16                    
    62 : unspill                i26, 15                    
    63 : sub                    i27, i25, i26              
    64 : spill                  17, i27                    
    65 : sub                    i24, 0, i24                
    66 : unspill                i25, 17                    
    67 : and                    i24, i24, i25              
    68 : unspill                i25, 15                    
    69 : add                    i26, i25, i24              
    70 : spill                  18, i26                    
    71 : mov                    i25, 4                     
    72 : spill                  19, i25                    
    73 : mov                    i24, 3                     
    74 : iverson_gt             i24, i13, i24              
    75 : unspill                i26, 18                    
    76 : unspill                i25, 19                    
    77 : sub                    i27, i25, i26              
    78 : spill                  20, i27                    
    79 : sub                    i24, 0, i24                
    80 : unspill                i25, 20                    
    81 : and                    i24, i24, i25              
    82 : unspill                i25, 18                    
    83 : add                    i26, i25, i24              
    84 : spill                  21, i26                    
    85 : mov                    i25, 8                     
    86 : spill                  22, i25                    
    87 : mov                    i24, 5                     
    88 : iverson_gt             i24, i13, i24              
    89 : unspill                i26, 21                    
    90 : unspill                i25, 22                    
    91 : sub                    i27, i25, i26              
    92 : spill                  23, i27                    
    93 : sub                    i24, 0, i24                
    94 : unspill                i25, 23                    
    95 : and                    i24, i24, i25              
    96 : unspill                i25, 21                    
    97 : add                    i26, i25, i24              
    98 : spill                  3, i26                     
    99 : annotation:whilecstart 0                          
   100 : unspill                i25, 4                     
   101 : jmp_ge                 i25, i14, __loops_label_2  
   102 : annotation:whilecend                              
   103 : def                    i25                        
   104 : spill                  5, i25                     
   105 : annotation:ifcstart                               
   106 : mov                    i24, 0                     
   107 : jmp_ne                 i11, i24, __loops_label_4  
   108 : annotation:ifcend                                 
   109 : unspill                i25, 0                     
   110 : add                    i24, i10, i25              
   111 : load.u8                i25, i24                   
   112 : spill                  5, i25                     
   113 : annotation:else        4, 5                       
   114 : annotation:ifcstart                               
   115 : mov                    i24, 1                     
   116 : jmp_ne                 i11, i24, __loops_label_7  
   117 : annotation:ifcend                                 
   118 : unspill                i25, 0                     
   119 : add                    i24, i10, i25              
   120 : load.i8                i25, i24                   
   121 : spill                  5, i25                     
   122 : annotation:else        7, 8                       
   123 : annotation:ifcstart                               
   124 : mov                    i24, 2                     
   125 : jmp_ne                 i11, i24, __loops_label_10 
   126 : annotation:ifcend                                 
   127 : unspill                i25, 0                     
   128 : add                    i24, i10, i25              
   129 : load.u16               i25, i24                   
   130 : spill                  5, i25                     
   131 : annotation:else        10, 11                     
   132 : annotation:ifcstart                               
   133 : mov                    i24, 3                     
   134 : jmp_ne                 i11, i24, __loops_label_13 
   135 : annotation:ifcend                                 
   136 : unspill                i25, 0                     
   137 : add                    i24, i10, i25              
   138 : load.i16               i25, i24                   
   139 : spill                  5, i25                     
   140 : annotation:else        13, 14                     
   141 : annotation:ifcstart                               
   142 : mov                    i24, 4                     
   143 : jmp_ne                 i11, i24, __loops_label_16 
   144 : annotation:ifcend                                 
   145 : unspill                i25, 0                     
   146 : add                    i24, i10, i25              
   147 : load.u32               i25, i24                   
   148 : spill                  5, i25                     
   149 : annotation:else        16, 17                     
   150 : annotation:ifcstart                               
   151 : mov                    i24, 5                     
   152 : jmp_ne                 i11, i24, __loops_label_19 
   153 : annotation:ifcend                                 
   154 : unspill                i25, 0                     
   155 : add                    i24, i10, i25              
   156 : load.i32               i25, i24                   
   157 : spill                  5, i25                     
   158 : annotation:else        19, 20                     
   159 : annotation:ifcstart                               
   160 : mov                    i24, 6                     
   161 : jmp_ne                 i11, i24, __loops_label_22 
   162 : annotation:ifcend                                 
   163 : unspill                i25, 0                     
   164 : add                    i24, i10, i25              
   165 : load.u64               i25, i24                   
   166 : spill                  5, i25                     
   167 : annotation:else        22, 23                     
   168 : unspill                i25, 0                     
   169 : add                    i24, i10, i25              
   170 : load.i64               i25, i24                   
   171 : spill                  5, i25                     
   172 : annotation:endif       5                          
   173 : annotation:endif       8                          
   174 : annotation:endif       11                         
   175 : annotation:endif       14                         
   176 : annotation:endif       17                         
   177 : annotation:endif       20                         
   178 : annotation:endif       23                         
   179 : annotation:ifcstart                               
   180 : mov                    i24, 0                     
   181 : jmp_ne                 i13, i24, __loops_label_25 
   182 : annotation:ifcend                                 
   183 : unspill                i25, 1                     
   184 : add                    i24, i12, i25              
   185 : unspill                i25, 5                     
   186 : store.u8               i24, i25                   
   187 : annotation:else        25, 26                     
   188 : annotation:ifcstart                               
   189 : mov                    i24, 1                     
   190 : jmp_ne                 i13, i24, __loops_label_28 
   191 : annotation:ifcend                                 
   192 : unspill                i25, 1                     
   193 : add                    i24, i12, i25              
   194 : unspill                i25, 5                     
   195 : store.i8               i24, i25                   
   196 : annotation:else        28, 29                     
   197 : annotation:ifcstart                               
   198 : mov                    i24, 2                     
   199 : jmp_ne                 i13, i24, __loops_label_31 
   200 : annotation:ifcend                                 
   201 : unspill                i25, 1                     
   202 : add                    i24, i12, i25              
   203 : unspill                i25, 5                     
   204 : store.u16              i24, i25                   
   205 : annotation:else        31, 32                     
   206 : annotation:ifcstart                               
   207 : mov                    i24, 3                     
   208 : jmp_ne                 i13, i24, __loops_label_34 
   209 : annotation:ifcend                                 
   210 : unspill                i25, 1                     
   211 : add                    i24, i12, i25              
   212 : unspill                i25, 5                     
   213 : store.i16              i24, i25                   
   214 : annotation:else        34, 35                     
   215 : annotation:ifcstart                               
   216 : mov                    i24, 4                     
   217 : jmp_ne                 i13, i24, __loops_label_37 
   218 : annotation:ifcend                                 
   219 : unspill                i25, 1                     
   220 : add                    i24, i12, i25              
   221 : unspill                i25, 5                     
   222 : store.u32              i24, i25                   
   223 : annotation:else        37, 38                     
   224 : annotation:ifcstart                               
   225 : mov                    i24, 5                     
   226 : jmp_ne                 i13, i24, __loops_label_40 
   227 : annotation:ifcend                                 
   228 : unspill                i25, 1                     
   229 : add                    i24, i12, i25              
   230 : unspill                i25, 5                     
   231 : store.i32              i24, i25                   
   232 : annotation:else        40, 41                     
   233 : annotation:ifcstart                               
   234 : mov                    i24, 6                     
   235 : jmp_ne                 i13, i24, __loops_label_43 
   236 : annotation:ifcend                                 
   237 : unspill                i25, 1                     
   238 : add                    i24, i12, i25              
   239 : unspill                i25, 5                     
   240 : store.u64              i24, i25                   
   241 : annotation:else        43, 44                     
   242 : unspill                i25, 1                     
   243 : add                    i24, i12, i25              
   244 : unspill                i25, 5                     
   245 : store.i64              i24, i25                   
   246 : annotation:endif       26                         
   247 : annotation:endif       29                         
   248 : annotation:endif       32                         
   249 : annotation:endif       35                         
   250 : annotation:endif       38                         
   251 : annotation:endif       41                         
   252 : annotation:endif       44                         
   253 : unspill                i25, 0                     
   254 : unspill                i26, 2                     
   255 : add                    i25, i25, i26              
   256 : spill                  0, i25                     
   257 : unspill                i25, 1                     
   258 : unspill                i26, 3                     
   259 : add                    i25, i25, i26              
   260 : spill                  1, i25                     
   261 : unspill                i25, 4                     
   262 : add                    i25, i25, 1                
   263 : spill                  4, i25                     
   264 : annotation:endwhile    0, 2                       
   265 : unspill                i24, 24                    
   266 : unspill                i25, 25                    
   267 : unspill                i26, 26                    
   268 : unspill                i27, 27                    
   269 : add                    i2, i2, 224                
