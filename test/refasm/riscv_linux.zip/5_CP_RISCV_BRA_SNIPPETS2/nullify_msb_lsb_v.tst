nullify_msb_lsb_v(i0, i1, i2, i3)
     0 : mov                    i4, 0                   
     1 : mov                    i5, 4                   
     2 : mul                    i3, i3, i5              
     3 : rv_vsetvli             i6, 0, 144              
     4 : broadcast.u32          v0, 1                   
     5 : annotation:whilecstart 0                       
     6 : jmp_ge                 i4, i3, __loops_label_2 
     7 : annotation:whilecend                           
     8 : add                    i7, i0, i4              
     9 : vld.u32                v1, i7                  
    10 : rv_vsetvli             i8, 0, 144              
    11 : shr.u32                v3, v1, 1               
    12 : or                     v2, v1, v3              
    13 : shr.u32                v4, v2, 2               
    14 : or                     v2, v2, v4              
    15 : shr.u32                v5, v2, 4               
    16 : or                     v2, v2, v5              
    17 : shr.u32                v6, v2, 8               
    18 : or                     v2, v2, v6              
    19 : shr.u32                v7, v2, 16              
    20 : or                     v2, v2, v7              
    21 : add.u32                v2, v2, v0              
    22 : shr.u32                v2, v2, 1               
    23 : xor                    v2, v2, v1              
    24 : add                    i9, i1, i4              
    25 : vst.u32                i9, v2                  
    26 : sub.u32                v10, v1, v0             
    27 : not                    v9, v10                 
    28 : and                    v8, v1, v9              
    29 : xor                    v8, v8, v1              
    30 : add                    i10, i2, i4             
    31 : vst.u32                i10, v8                 
    32 : add                    i4, i4, 32              
    33 : annotation:endwhile    0, 2                    
    34 : ret                                            
