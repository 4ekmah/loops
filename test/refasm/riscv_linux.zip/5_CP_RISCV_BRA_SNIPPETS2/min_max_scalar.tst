min_max_scalar(i0, i1, i2, i3)
     0 : mov                    i4, 0                   
     1 : mov                    i5, 0                   
     2 : mov                    i6, 0                   
     3 : load.i32               i7, i0                  
     4 : mov                    i8, i7                  
     5 : mov                    i11, 4                  
     6 : mul                    i1, i1, i11             
     7 : annotation:whilecstart 0                       
     8 : jmp_ge                 i4, i1, __loops_label_2 
     9 : annotation:whilecend                           
    10 : add                    i12, i0, i4             
    11 : load.i32               i9, i12                 
    12 : annotation:ifcstart                            
    13 : jmp_ge                 i9, i7, __loops_label_4 
    14 : annotation:ifcend                              
    15 : mov                    i7, i9                  
    16 : mov                    i5, i4                  
    17 : annotation:endif       4                       
    18 : annotation:ifcstart                            
    19 : jmp_le                 i9, i8, __loops_label_6 
    20 : annotation:ifcend                              
    21 : mov                    i8, i9                  
    22 : mov                    i6, i4                  
    23 : annotation:endif       6                       
    24 : add                    i4, i4, 4               
    25 : annotation:endwhile    0, 2                    
    26 : mov                    i10, 4                  
    27 : div                    i5, i5, i10             
    28 : div                    i6, i6, i10             
    29 : store.i32              i2, i5                  
    30 : store.i32              i3, i6                  
    31 : mov                    iR, 0                   
    32 : ret                                            
