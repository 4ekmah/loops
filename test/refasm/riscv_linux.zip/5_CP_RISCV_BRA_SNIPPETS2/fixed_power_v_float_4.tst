fixed_power_v_float_4(i0, i1, i2)
     0 : mov                    i3, 0                   
     1 : mov                    i4, 4                   
     2 : mul                    i2, i2, i4              
     3 : annotation:whilecstart 0                       
     4 : jmp_ge                 i3, i2, __loops_label_2 
     5 : annotation:whilecend                           
     6 : add                    i5, i0, i3              
     7 : vld.fp32               v0, i5                  
     8 : rv_vsetvli             i6, 0, 144              
     9 : rv_csrrwi              i7, 2, 0                
    10 : mul.fp32               v2, v0, v0              
    11 : mul.fp32               v1, v2, v2              
    12 : add                    i8, i1, i3              
    13 : vst.fp32               i8, v1                  
    14 : add                    i3, i3, 32              
    15 : annotation:endwhile    0, 2                    
    16 : mov                    iR, 0                   
    17 : ret                                            
