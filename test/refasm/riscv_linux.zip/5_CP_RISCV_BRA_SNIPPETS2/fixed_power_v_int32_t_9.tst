fixed_power_v_int32_t_9(i0, i1, i2)
     0 : mov                    i3, 0                   
     1 : mov                    i4, 4                   
     2 : mul                    i2, i2, i4              
     3 : annotation:whilecstart 0                       
     4 : jmp_ge                 i3, i2, __loops_label_2 
     5 : annotation:whilecend                           
     6 : add                    i5, i0, i3              
     7 : vld.i32                v0, i5                  
     8 : rv_vsetvli             i6, 0, 144              
     9 : mul.i32                v4, v0, v0              
    10 : mul.i32                v3, v4, v4              
    11 : mul.i32                v2, v3, v3              
    12 : mul.i32                v1, v0, v2              
    13 : add                    i7, i1, i3              
    14 : vst.i32                i7, v1                  
    15 : add                    i3, i3, 32              
    16 : annotation:endwhile    0, 2                    
    17 : mov                    iR, 0                   
    18 : ret                                            
