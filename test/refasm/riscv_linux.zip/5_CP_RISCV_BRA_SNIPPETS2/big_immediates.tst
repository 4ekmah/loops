big_immediates(i0)
     0 : rv_lui    i1, 1           
     1 : add       i1, i1, 0       
     2 : store.u64 i0, i1          
     3 : add       i0, i0, 8       
     4 : rv_lui    i2, 2           
     5 : add       i2, i2, -1      
     6 : store.u64 i0, i2          
     7 : add       i0, i0, 8       
     8 : rv_lui    i3, 524288      
     9 : xor       i3, i3, -1366   
    10 : store.u64 i0, i3          
    11 : add       i0, i0, 8       
    12 : mov       i4, 1           
    13 : shl       i4, i4, 32      
    14 : mov       i13, 0          
    15 : add       i4, i4, i13     
    16 : store.u64 i0, i4          
    17 : add       i0, i0, 8       
    18 : mov       i5, 2           
    19 : shl       i5, i5, 32      
    20 : mov       i14, -1         
    21 : add       i5, i5, i14     
    22 : store.u64 i0, i5          
    23 : add       i0, i0, 8       
    24 : mov       i6, 1           
    25 : shl       i6, i6, 63      
    26 : rv_lui    i15, 699051     
    27 : add       i15, i15, -1366 
    28 : xor       i6, i6, i15     
    29 : store.u64 i0, i6          
    30 : add       i0, i0, 8       
    31 : rv_lui    i7, 16          
    32 : add       i7, i7, -1      
    33 : store.u64 i0, i7          
    34 : add       i0, i0, 8       
    35 : rv_lui    i8, 16          
    36 : add       i8, i8, 0       
    37 : store.u64 i0, i8          
    38 : add       i0, i0, 8       
    39 : rv_lui    i9, 1048568     
    40 : add       i9, i9, 0       
    41 : store.i64 i0, i9          
    42 : add       i0, i0, 8       
    43 : rv_lui    i10, 1048568    
    44 : add       i10, i10, -1    
    45 : store.i64 i0, i10         
    46 : add       i0, i0, 8       
    47 : rv_lui    i11, 390006     
    48 : add       i11, i11, -1569 
    49 : store.u64 i0, i11         
    50 : add       i0, i0, 8       
    51 : rv_lui    i12, 262236     
    52 : add       i12, i12, -245  
    53 : shl       i12, i12, 32    
    54 : rv_lui    i16, 569669     
    55 : add       i16, i16, 1897  
    56 : add       i12, i12, i16   
    57 : store.u64 i0, i12         
    58 : add       i0, i0, 8       
    59 : ret                       
