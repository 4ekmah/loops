snake(i0, i1, i2)
     0 : add                    i4, i1, i2                
     1 : sub                    i3, i4, 1                 
     2 : mov                    i5, 0                     
     3 : mov                    i6, 1                     
     4 : neg                    i7, i6                    
     5 : mov                    i8, 0                     
     6 : annotation:whilecstart 0                         
     7 : jmp_ge                 i8, i3, __loops_label_2   
     8 : annotation:whilecend                             
     9 : mov                    i9, 0                     
    10 : mov                    i10, 0                    
    11 : annotation:ifcstart                              
    12 : and                    i11, i8, 1                
    13 : mov                    i20, 0                    
    14 : jmp_eq                 i11, i20, __loops_label_4 
    15 : annotation:ifcend                                
    16 : sub                    i12, i2, 1                
    17 : iverson_gt             i24, i12, i8              
    18 : sub                    i25, i12, i8              
    19 : sub                    i24, 0, i24               
    20 : and                    i24, i24, i25             
    21 : add                    i9, i8, i24               
    22 : sub                    i13, i8, i12              
    23 : mov                    i14, 0                    
    24 : iverson_gt             i26, i8, i12              
    25 : sub                    i27, i13, i14             
    26 : sub                    i26, 0, i26               
    27 : and                    i26, i26, i27             
    28 : add                    i10, i14, i26             
    29 : annotation:else        4, 5                      
    30 : sub                    i15, i1, 1                
    31 : sub                    i16, i8, i15              
    32 : mov                    i17, 0                    
    33 : iverson_gt             i28, i8, i15              
    34 : sub                    i29, i16, i17             
    35 : sub                    i28, 0, i28               
    36 : and                    i28, i28, i29             
    37 : add                    i9, i17, i28              
    38 : iverson_gt             i30, i15, i8              
    39 : sub                    i31, i15, i8              
    40 : sub                    i30, 0, i30               
    41 : and                    i30, i30, i31             
    42 : add                    i10, i8, i30              
    43 : annotation:endif       5                         
    44 : annotation:whilecstart 6                         
    45 : mov                    i21, 0                    
    46 : jmp_gt                 i9, i21, __loops_label_8  
    47 : jmp_ge                 i9, i2, __loops_label_8   
    48 : mov                    i22, 0                    
    49 : jmp_gt                 i10, i22, __loops_label_8 
    50 : jmp_ge                 i10, i1, __loops_label_8  
    51 : annotation:whilecend                             
    52 : mov                    i23, 43                   
    53 : shl                    i23, i23, 32              
    54 : rv_lui                 i32, 707046               
    55 : add                    i32, i32, -1518           
    56 : add                    i23, i23, i32             
    57 : call_noret             [i23](i9, i10)            
    58 : mul                    i19, i10, i2              
    59 : add                    i18, i19, i9              
    60 : add                    i33, i0, i18              
    61 : store.u8               i33, i5                   
    62 : add                    i5, i5, 1                 
    63 : add                    i9, i9, i6                
    64 : add                    i10, i10, i7              
    65 : annotation:endwhile    6, 8                      
    66 : neg                    i6, i6                    
    67 : neg                    i7, i7                    
    68 : add                    i8, i8, 1                 
    69 : annotation:endwhile    0, 2                      
    70 : ret                                              
