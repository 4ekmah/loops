fixed_power_v_uint32_t_0(i0, i1, i2)
     0 : mov                    i3, 0                   
     1 : mov                    i4, 4                   
     2 : mul                    i2, i2, i4              
     3 : annotation:whilecstart 0                       
     4 : jmp_ge                 i3, i2, __loops_label_2 
     5 : annotation:whilecend                           
     6 : add                    i5, i0, i3              
     7 : vld.u32                v0, i5                  
     8 : rv_vsetvli             i6, 0, 144              
     9 : broadcast.u32          v1, 1                   
    10 : add                    i7, i1, i3              
    11 : vst.u32                i7, v1                  
    12 : add                    i3, i3, 32              
    13 : annotation:endwhile    0, 2                    
    14 : mov                    iR, 0                   
    15 : ret                                            
