conditionpainter(i0)
     0 : mov                    i1, -5                   
     1 : annotation:whilecstart 0                        
     2 : mov                    i54, 5                   
     3 : jmp_gt                 i1, i54, __loops_label_2 
     4 : annotation:whilecend                            
     5 : add                    i4, i1, 5                
     6 : mov                    i55, 11                  
     7 : mul                    i3, i4, i55              
     8 : mov                    i56, 8                   
     9 : mul                    i2, i3, i56              
    10 : mov                    i5, -5                   
    11 : annotation:whilecstart 3                        
    12 : mov                    i57, 5                   
    13 : jmp_gt                 i5, i57, __loops_label_5 
    14 : annotation:whilecend                            
    15 : add                    i10, i5, 3               
    16 : iverson_gt             i11, i1, i10             
    17 : neg                    i11, i11                 
    18 : add                    i11, i11, 1              
    19 : mov                    i58, 4                   
    20 : iverson_gt             i12, i1, i58             
    21 : neg                    i12, i12                 
    22 : add                    i12, i12, 1              
    23 : and                    i9, i11, i12             
    24 : mov                    i59, -2                  
    25 : iverson_gt             i13, i5, i59             
    26 : neg                    i13, i13                 
    27 : add                    i13, i13, 1              
    28 : and                    i8, i9, i13              
    29 : mov                    i60, 0                   
    30 : iverson_gt             i14, i5, i60             
    31 : neg                    i14, i14                 
    32 : add                    i14, i14, 1              
    33 : and                    i7, i8, i14              
    34 : sub                    i18, i5, 1               
    35 : iverson_gt             i19, i1, i18             
    36 : neg                    i19, i19                 
    37 : add                    i19, i19, 1              
    38 : mov                    i61, 0                   
    39 : iverson_gt             i20, i5, i61             
    40 : neg                    i20, i20                 
    41 : add                    i20, i20, 1              
    42 : and                    i17, i19, i20            
    43 : mov                    i62, 0                   
    44 : iverson_gt             i21, i1, i62             
    45 : neg                    i21, i21                 
    46 : add                    i21, i21, 1              
    47 : and                    i16, i17, i21            
    48 : mul                    i23, i5, i5              
    49 : mul                    i24, i1, i1              
    50 : add                    i22, i23, i24            
    51 : mov                    i63, 9                   
    52 : iverson_gt             i25, i22, i63            
    53 : neg                    i25, i25                 
    54 : add                    i25, i25, 1              
    55 : and                    i15, i16, i25            
    56 : or                     i6, i7, i15              
    57 : mov                    i26, 2                   
    58 : mov                    i27, 0                   
    59 : mov                    i64, 2                   
    60 : iverson_gt             i31, i5, i64             
    61 : neg                    i31, i31                 
    62 : add                    i31, i31, 1              
    63 : mov                    i65, 4                   
    64 : iverson_gt             i32, i5, i65             
    65 : neg                    i32, i32                 
    66 : add                    i32, i32, 1              
    67 : and                    i30, i31, i32            
    68 : mov                    i66, 1                   
    69 : iverson_gt             i34, i1, i66             
    70 : neg                    i34, i34                 
    71 : add                    i34, i34, 1              
    72 : mov                    i67, 3                   
    73 : iverson_gt             i35, i1, i67             
    74 : neg                    i35, i35                 
    75 : add                    i35, i35, 1              
    76 : and                    i33, i34, i35            
    77 : or                     i29, i30, i33            
    78 : mul                    i37, i5, i5              
    79 : mul                    i38, i1, i1              
    80 : add                    i36, i37, i38            
    81 : mov                    i68, 16                  
    82 : iverson_gt             i39, i36, i68            
    83 : neg                    i39, i39                 
    84 : add                    i39, i39, 1              
    85 : and                    i28, i29, i39            
    86 : mov                    i69, 0                   
    87 : sub                    i73, i28, i69            
    88 : iverson_ne             i73, i73, 0              
    89 : sub                    i74, i26, i27            
    90 : sub                    i73, 0, i73              
    91 : and                    i73, i73, i74            
    92 : add                    i40, i27, i73            
    93 : add                    i6, i6, i40              
    94 : annotation:ifcstart                             
    95 : mov                    i70, 2                   
    96 : mul                    i41, i1, i70             
    97 : jmp_gt                 i41, i5, __loops_label_8 
    98 : add                    i44, i5, 3               
    99 : neg                    i43, i44                 
   100 : add                    i45, i5, 3               
   101 : mul                    i42, i43, i45            
   102 : jmp_le                 i1, i42, __loops_label_9 
   103 : __loops_label_8:                                
   104 : mov                    i71, 2                   
   105 : mul                    i46, i5, i71             
   106 : jmp_gt                 i1, i46, __loops_label_7 
   107 : add                    i49, i5, 3               
   108 : neg                    i48, i49                 
   109 : add                    i50, i5, 3               
   110 : mul                    i47, i48, i50            
   111 : jmp_gt                 i1, i47, __loops_label_7 
   112 : __loops_label_9:                                
   113 : mov                    i72, 0                   
   114 : jmp_gt                 i5, i72, __loops_label_7 
   115 : annotation:ifcend                               
   116 : add                    i6, i6, 3                
   117 : annotation:endif       7                        
   118 : add                    i53, i5, 5               
   119 : shl                    i52, i53, 3              
   120 : add                    i51, i2, i52             
   121 : add                    i75, i0, i51             
   122 : store.i64              i75, i6                  
   123 : add                    i5, i5, 1                
   124 : annotation:endwhile    3, 5                     
   125 : add                    i1, i1, 1                
   126 : annotation:endwhile    0, 2                     
   127 : ret                                             
