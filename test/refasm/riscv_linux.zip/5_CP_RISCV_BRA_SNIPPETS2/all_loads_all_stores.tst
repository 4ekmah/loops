all_loads_all_stores(i0, i1, i2, i3, i4)
     0 : mov                    i5, 0                     
     1 : mov                    i6, 0                     
     2 : mov                    i7, 0                     
     3 : mov                    i8, 2                     
     4 : mov                    i9, 1                     
     5 : mov                    i19, 1                    
     6 : iverson_gt             i39, i1, i19              
     7 : sub                    i40, i8, i9               
     8 : sub                    i39, 0, i39               
     9 : and                    i39, i39, i40             
    10 : add                    i10, i9, i39              
    11 : mov                    i11, 4                    
    12 : mov                    i20, 3                    
    13 : iverson_gt             i41, i1, i20              
    14 : sub                    i42, i11, i10             
    15 : sub                    i41, 0, i41               
    16 : and                    i41, i41, i42             
    17 : add                    i10, i10, i41             
    18 : mov                    i12, 8                    
    19 : mov                    i21, 5                    
    20 : iverson_gt             i43, i1, i21              
    21 : sub                    i44, i12, i10             
    22 : sub                    i43, 0, i43               
    23 : and                    i43, i43, i44             
    24 : add                    i10, i10, i43             
    25 : mov                    i13, 2                    
    26 : mov                    i14, 1                    
    27 : mov                    i22, 1                    
    28 : iverson_gt             i45, i3, i22              
    29 : sub                    i46, i13, i14             
    30 : sub                    i45, 0, i45               
    31 : and                    i45, i45, i46             
    32 : add                    i15, i14, i45             
    33 : mov                    i16, 4                    
    34 : mov                    i23, 3                    
    35 : iverson_gt             i47, i3, i23              
    36 : sub                    i48, i16, i15             
    37 : sub                    i47, 0, i47               
    38 : and                    i47, i47, i48             
    39 : add                    i15, i15, i47             
    40 : mov                    i17, 8                    
    41 : mov                    i24, 5                    
    42 : iverson_gt             i49, i3, i24              
    43 : sub                    i50, i17, i15             
    44 : sub                    i49, 0, i49               
    45 : and                    i49, i49, i50             
    46 : add                    i15, i15, i49             
    47 : annotation:whilecstart 0                         
    48 : jmp_ge                 i5, i4, __loops_label_2   
    49 : annotation:whilecend                             
    50 : def                    i18                       
    51 : annotation:ifcstart                              
    52 : mov                    i25, 0                    
    53 : jmp_ne                 i1, i25, __loops_label_4  
    54 : annotation:ifcend                                
    55 : add                    i51, i0, i6               
    56 : load.u8                i18, i51                  
    57 : annotation:else        4, 5                      
    58 : annotation:ifcstart                              
    59 : mov                    i26, 1                    
    60 : jmp_ne                 i1, i26, __loops_label_7  
    61 : annotation:ifcend                                
    62 : add                    i52, i0, i6               
    63 : load.i8                i18, i52                  
    64 : annotation:else        7, 8                      
    65 : annotation:ifcstart                              
    66 : mov                    i27, 2                    
    67 : jmp_ne                 i1, i27, __loops_label_10 
    68 : annotation:ifcend                                
    69 : add                    i53, i0, i6               
    70 : load.u16               i18, i53                  
    71 : annotation:else        10, 11                    
    72 : annotation:ifcstart                              
    73 : mov                    i28, 3                    
    74 : jmp_ne                 i1, i28, __loops_label_13 
    75 : annotation:ifcend                                
    76 : add                    i54, i0, i6               
    77 : load.i16               i18, i54                  
    78 : annotation:else        13, 14                    
    79 : annotation:ifcstart                              
    80 : mov                    i29, 4                    
    81 : jmp_ne                 i1, i29, __loops_label_16 
    82 : annotation:ifcend                                
    83 : add                    i55, i0, i6               
    84 : load.u32               i18, i55                  
    85 : annotation:else        16, 17                    
    86 : annotation:ifcstart                              
    87 : mov                    i30, 5                    
    88 : jmp_ne                 i1, i30, __loops_label_19 
    89 : annotation:ifcend                                
    90 : add                    i56, i0, i6               
    91 : load.i32               i18, i56                  
    92 : annotation:else        19, 20                    
    93 : annotation:ifcstart                              
    94 : mov                    i31, 6                    
    95 : jmp_ne                 i1, i31, __loops_label_22 
    96 : annotation:ifcend                                
    97 : add                    i57, i0, i6               
    98 : load.u64               i18, i57                  
    99 : annotation:else        22, 23                    
   100 : add                    i58, i0, i6               
   101 : load.i64               i18, i58                  
   102 : annotation:endif       5                         
   103 : annotation:endif       8                         
   104 : annotation:endif       11                        
   105 : annotation:endif       14                        
   106 : annotation:endif       17                        
   107 : annotation:endif       20                        
   108 : annotation:endif       23                        
   109 : annotation:ifcstart                              
   110 : mov                    i32, 0                    
   111 : jmp_ne                 i3, i32, __loops_label_25 
   112 : annotation:ifcend                                
   113 : add                    i59, i2, i7               
   114 : store.u8               i59, i18                  
   115 : annotation:else        25, 26                    
   116 : annotation:ifcstart                              
   117 : mov                    i33, 1                    
   118 : jmp_ne                 i3, i33, __loops_label_28 
   119 : annotation:ifcend                                
   120 : add                    i60, i2, i7               
   121 : store.i8               i60, i18                  
   122 : annotation:else        28, 29                    
   123 : annotation:ifcstart                              
   124 : mov                    i34, 2                    
   125 : jmp_ne                 i3, i34, __loops_label_31 
   126 : annotation:ifcend                                
   127 : add                    i61, i2, i7               
   128 : store.u16              i61, i18                  
   129 : annotation:else        31, 32                    
   130 : annotation:ifcstart                              
   131 : mov                    i35, 3                    
   132 : jmp_ne                 i3, i35, __loops_label_34 
   133 : annotation:ifcend                                
   134 : add                    i62, i2, i7               
   135 : store.i16              i62, i18                  
   136 : annotation:else        34, 35                    
   137 : annotation:ifcstart                              
   138 : mov                    i36, 4                    
   139 : jmp_ne                 i3, i36, __loops_label_37 
   140 : annotation:ifcend                                
   141 : add                    i63, i2, i7               
   142 : store.u32              i63, i18                  
   143 : annotation:else        37, 38                    
   144 : annotation:ifcstart                              
   145 : mov                    i37, 5                    
   146 : jmp_ne                 i3, i37, __loops_label_40 
   147 : annotation:ifcend                                
   148 : add                    i64, i2, i7               
   149 : store.i32              i64, i18                  
   150 : annotation:else        40, 41                    
   151 : annotation:ifcstart                              
   152 : mov                    i38, 6                    
   153 : jmp_ne                 i3, i38, __loops_label_43 
   154 : annotation:ifcend                                
   155 : add                    i65, i2, i7               
   156 : store.u64              i65, i18                  
   157 : annotation:else        43, 44                    
   158 : add                    i66, i2, i7               
   159 : store.i64              i66, i18                  
   160 : annotation:endif       26                        
   161 : annotation:endif       29                        
   162 : annotation:endif       32                        
   163 : annotation:endif       35                        
   164 : annotation:endif       38                        
   165 : annotation:endif       41                        
   166 : annotation:endif       44                        
   167 : add                    i6, i6, i10               
   168 : add                    i7, i7, i15               
   169 : add                    i5, i5, 1                 
   170 : annotation:endwhile    0, 2                      
