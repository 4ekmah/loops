helloworld_call()
     0 : mov        i0, 43      
     1 : shl        i0, i0, 32  
     2 : rv_lui     i1, 707045  
     3 : add        i1, i1, 946 
     4 : add        i0, i0, i1  
     5 : call_noret [i0]()      
     6 : ret                    
