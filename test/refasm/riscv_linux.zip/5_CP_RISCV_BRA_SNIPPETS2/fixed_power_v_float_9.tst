fixed_power_v_float_9(i0, i1, i2)
     0 : mov                    i3, 0                   
     1 : mov                    i4, 4                   
     2 : mul                    i2, i2, i4              
     3 : annotation:whilecstart 0                       
     4 : jmp_ge                 i3, i2, __loops_label_2 
     5 : annotation:whilecend                           
     6 : add                    i5, i0, i3              
     7 : vld.fp32               v0, i5                  
     8 : rv_vsetvli             i6, 0, 144              
     9 : rv_csrrwi              i7, 2, 0                
    10 : mul.fp32               v4, v0, v0              
    11 : mul.fp32               v3, v4, v4              
    12 : mul.fp32               v2, v3, v3              
    13 : mul.fp32               v1, v0, v2              
    14 : add                    i8, i1, i3              
    15 : vst.fp32               i8, v1                  
    16 : add                    i3, i3, 32              
    17 : annotation:endwhile    0, 2                    
    18 : mov                    iR, 0                   
    19 : ret                                            
