nonnegative_odd(i0, i1)
     0 : mov                    i2, 0                   
     1 : mov                    i3, -4                  
     2 : mov                    i6, 4                   
     3 : mul                    i1, i1, i6              
     4 : annotation:whilecstart 0                       
     5 : jmp_ge                 i2, i1, __loops_label_2 
     6 : annotation:whilecend                           
     7 : add                    i11, i0, i2             
     8 : load.i32               i4, i11                 
     9 : annotation:ifcstart                            
    10 : mov                    i7, 0                   
    11 : jmp_ge                 i4, i7, __loops_label_4 
    12 : annotation:ifcend                              
    13 : add                    i2, i2, 4               
    14 : annotation:break       0                       
    15 : annotation:endif       4                       
    16 : mov                    i8, 2                   
    17 : mod                    i5, i4, i8              
    18 : annotation:ifcstart                            
    19 : mov                    i9, 0                   
    20 : jmp_eq                 i5, i9, __loops_label_6 
    21 : annotation:ifcend                              
    22 : mov                    i3, i2                  
    23 : annotation:break       2                       
    24 : annotation:endif       6                       
    25 : add                    i2, i2, 4               
    26 : annotation:endwhile    0, 2                    
    27 : mov                    i10, 4                  
    28 : div                    i3, i3, i10             
    29 : mov                    iR, i3                  
    30 : ret                                            
