triangle_types(i0, i1, i2)
     0 : annotation:ifcstart                            
     1 : mov                 i30, 0                     
     2 : jmp_le              i0, i30, __loops_label_0   
     3 : mov                 i31, 0                     
     4 : jmp_le              i1, i31, __loops_label_0   
     5 : mov                 i32, 0                     
     6 : jmp_gt              i2, i32, __loops_label_1   
     7 : __loops_label_0:                               
     8 : annotation:ifcend                              
     9 : mov                 iR, 0                      
    10 : ret                                            
    11 : annotation:else     1, 2                       
    12 : annotation:ifcstart                            
    13 : add                 i3, i1, i2                 
    14 : jmp_gt              i0, i3, __loops_label_3    
    15 : add                 i4, i0, i2                 
    16 : jmp_gt              i1, i4, __loops_label_3    
    17 : add                 i5, i0, i1                 
    18 : jmp_le              i2, i5, __loops_label_4    
    19 : __loops_label_3:                               
    20 : annotation:ifcend                              
    21 : mov                 iR, 0                      
    22 : ret                                            
    23 : annotation:else     4, 5                       
    24 : annotation:ifcstart                            
    25 : jmp_ne              i0, i1, __loops_label_7    
    26 : jmp_ne              i0, i2, __loops_label_7    
    27 : annotation:ifcend                              
    28 : mov                 iR, 2                      
    29 : ret                                            
    30 : annotation:else     7, 8                       
    31 : annotation:ifcstart                            
    32 : jmp_eq              i0, i1, __loops_label_9    
    33 : jmp_eq              i0, i2, __loops_label_9    
    34 : jmp_ne              i1, i2, __loops_label_10   
    35 : __loops_label_9:                               
    36 : annotation:ifcend                              
    37 : mov                 iR, 3                      
    38 : ret                                            
    39 : annotation:else     10, 11                     
    40 : annotation:ifcstart                            
    41 : mul                 i6, i0, i0                 
    42 : mul                 i8, i1, i1                 
    43 : mul                 i9, i2, i2                 
    44 : add                 i7, i8, i9                 
    45 : jmp_eq              i6, i7, __loops_label_12   
    46 : mul                 i10, i1, i1                
    47 : mul                 i12, i0, i0                
    48 : mul                 i13, i2, i2                
    49 : add                 i11, i12, i13              
    50 : jmp_eq              i10, i11, __loops_label_12 
    51 : mul                 i14, i2, i2                
    52 : mul                 i16, i0, i0                
    53 : mul                 i17, i1, i1                
    54 : add                 i15, i16, i17              
    55 : jmp_ne              i14, i15, __loops_label_13 
    56 : __loops_label_12:                              
    57 : annotation:ifcend                              
    58 : mov                 iR, 1                      
    59 : ret                                            
    60 : annotation:else     13, 14                     
    61 : annotation:ifcstart                            
    62 : mul                 i18, i0, i0                
    63 : mul                 i20, i1, i1                
    64 : mul                 i21, i2, i2                
    65 : add                 i19, i20, i21              
    66 : jmp_gt              i18, i19, __loops_label_15 
    67 : mul                 i22, i1, i1                
    68 : mul                 i24, i0, i0                
    69 : mul                 i25, i2, i2                
    70 : add                 i23, i24, i25              
    71 : jmp_gt              i22, i23, __loops_label_15 
    72 : mul                 i26, i2, i2                
    73 : mul                 i28, i0, i0                
    74 : mul                 i29, i1, i1                
    75 : add                 i27, i28, i29              
    76 : jmp_le              i26, i27, __loops_label_16 
    77 : __loops_label_15:                              
    78 : annotation:ifcend                              
    79 : mov                 iR, 5                      
    80 : ret                                            
    81 : annotation:else     16, 17                     
    82 : mov                 iR, 4                      
    83 : ret                                            
    84 : annotation:endif    2                          
    85 : annotation:endif    5                          
    86 : annotation:endif    8                          
    87 : annotation:endif    11                         
    88 : annotation:endif    14                         
    89 : annotation:endif    17                         
