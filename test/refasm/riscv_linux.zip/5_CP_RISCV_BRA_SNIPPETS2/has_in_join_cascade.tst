has_in_join_cascade(i0, i1, i2)
     0 : mov                    i3, 0                      
     1 : load.i64               i4, i0, 16                 
     2 : load.i64               i5, i0, 0                  
     3 : load.i64               i6, i0, 8                  
     4 : annotation:whilecstart 0                          
     5 : mov                    i19, 0                     
     6 : jmp_le                 i4, i19, __loops_label_2   
     7 : annotation:whilecend                              
     8 : load.i32               i7, i5                     
     9 : add                    i5, i5, 4                  
    10 : load.i32               i8, i6                     
    11 : add                    i6, i6, 4                  
    12 : sub                    i4, i4, 1                  
    13 : load.i64               i9, i0, 40                 
    14 : load.i64               i10, i0, 24                
    15 : load.i64               i11, i0, 32                
    16 : annotation:whilecstart 3                          
    17 : mov                    i20, 0                     
    18 : jmp_le                 i9, i20, __loops_label_5   
    19 : annotation:whilecend                              
    20 : load.i32               i12, i10                   
    21 : add                    i10, i10, 4                
    22 : load.i32               i13, i11                   
    23 : add                    i11, i11, 4                
    24 : sub                    i9, i9, 1                  
    25 : annotation:ifcstart                               
    26 : jmp_le                 i13, i7, __loops_label_7   
    27 : annotation:ifcend                                 
    28 : annotation:break       3                          
    29 : annotation:else        7, 8                       
    30 : annotation:ifcstart                               
    31 : jmp_ne                 i13, i7, __loops_label_10  
    32 : annotation:ifcend                                 
    33 : load.i64               i14, i0, 64                
    34 : load.i64               i15, i0, 48                
    35 : load.i64               i16, i0, 56                
    36 : annotation:whilecstart 11                         
    37 : mov                    i21, 0                     
    38 : jmp_le                 i14, i21, __loops_label_13 
    39 : annotation:whilecend                              
    40 : load.i32               i17, i15                   
    41 : add                    i15, i15, 4                
    42 : load.i32               i18, i16                   
    43 : add                    i16, i16, 4                
    44 : sub                    i14, i14, 1                
    45 : annotation:ifcstart                               
    46 : jmp_le                 i17, i8, __loops_label_15  
    47 : annotation:ifcend                                 
    48 : annotation:break       11                         
    49 : annotation:else        15, 16                     
    50 : annotation:ifcstart                               
    51 : jmp_ne                 i17, i8, __loops_label_18  
    52 : jmp_ne                 i12, i1, __loops_label_18  
    53 : jmp_ne                 i18, i2, __loops_label_18  
    54 : annotation:ifcend                                 
    55 : mov                    i3, 1                      
    56 : annotation:break       2                          
    57 : annotation:endif       16                         
    58 : annotation:endif       18                         
    59 : annotation:endwhile    11, 13                     
    60 : annotation:endif       8                          
    61 : annotation:endif       10                         
    62 : annotation:endwhile    3, 5                       
    63 : annotation:endwhile    0, 2                       
    64 : mov                    iR, i3                     
    65 : ret                                               
