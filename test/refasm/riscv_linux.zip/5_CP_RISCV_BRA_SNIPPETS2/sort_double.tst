sort_double(i0, i1)
     0 : shl                    i1, i1, 3                
     1 : sub                    i2, i1, 8                
     2 : mov                    i3, 0                    
     3 : annotation:whilecstart 0                        
     4 : jmp_ge                 i3, i2, __loops_label_2  
     5 : annotation:whilecend                            
     6 : mov                    i4, i3                   
     7 : add                    i5, i4, 8                
     8 : annotation:whilecstart 3                        
     9 : jmp_ge                 i5, i1, __loops_label_5  
    10 : annotation:whilecend                            
    11 : annotation:ifcstart                             
    12 : add                    i13, i0, i5              
    13 : load.fp64              i7, i13                  
    14 : add                    i14, i0, i4              
    15 : load.fp64              i8, i14                  
    16 : mov                    i11, 43                  
    17 : shl                    i11, i11, 32             
    18 : rv_lui                 i15, 707047              
    19 : add                    i15, i15, 678            
    20 : add                    i11, i11, i15            
    21 : call                   [i11](i6, i7, i8)        
    22 : mov                    i12, 0                   
    23 : jmp_eq                 i6, i12, __loops_label_7 
    24 : annotation:ifcend                               
    25 : mov                    i4, i5                   
    26 : annotation:endif       7                        
    27 : add                    i5, i5, 8                
    28 : annotation:endwhile    3, 5                     
    29 : annotation:ifcstart                             
    30 : jmp_eq                 i4, i3, __loops_label_9  
    31 : annotation:ifcend                               
    32 : add                    i16, i0, i3              
    33 : load.fp64              i9, i16                  
    34 : add                    i17, i0, i4              
    35 : load.fp64              i10, i17                 
    36 : add                    i18, i0, i4              
    37 : store.fp64             i18, i9                  
    38 : add                    i19, i0, i3              
    39 : store.fp64             i19, i10                 
    40 : annotation:endif       9                        
    41 : add                    i3, i3, 8                
    42 : annotation:endwhile    0, 2                     
    43 : ret                                             
