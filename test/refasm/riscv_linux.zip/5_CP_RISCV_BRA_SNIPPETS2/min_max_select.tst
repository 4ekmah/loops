min_max_select(i0, i1, i2, i3)
     0 : mov                    i4, 0                   
     1 : mov                    i5, 0                   
     2 : mov                    i6, 0                   
     3 : load.i32               i7, i0                  
     4 : mov                    i8, i7                  
     5 : shl                    i1, i1, 2               
     6 : annotation:whilecstart 0                       
     7 : jmp_ge                 i4, i1, __loops_label_2 
     8 : annotation:whilecend                           
     9 : add                    i18, i0, i4             
    10 : load.i32               i9, i18                 
    11 : iverson_gt             i10, i9, i7             
    12 : sub                    i11, i4, i5             
    13 : sub                    i10, 0, i10             
    14 : and                    i10, i10, i11           
    15 : add                    i5, i5, i10             
    16 : iverson_gt             i12, i9, i7             
    17 : sub                    i13, i9, i7             
    18 : sub                    i12, 0, i12             
    19 : and                    i12, i12, i13           
    20 : add                    i7, i7, i12             
    21 : iverson_gt             i14, i9, i8             
    22 : sub                    i15, i4, i6             
    23 : sub                    i14, 0, i14             
    24 : and                    i14, i14, i15           
    25 : add                    i6, i6, i14             
    26 : iverson_gt             i16, i9, i8             
    27 : sub                    i17, i8, i9             
    28 : sub                    i16, 0, i16             
    29 : and                    i16, i16, i17           
    30 : add                    i8, i9, i16             
    31 : add                    i4, i4, 4               
    32 : annotation:endwhile    0, 2                    
    33 : sar                    i5, i5, 2               
    34 : sar                    i6, i6, 2               
    35 : store.i32              i2, i5                  
    36 : store.i32              i3, i6                  
    37 : mov                    iR, 0                   
    38 : ret                                            
