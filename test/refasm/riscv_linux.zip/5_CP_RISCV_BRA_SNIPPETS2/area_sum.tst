area_sum(i0, i1)
     0 : mov                    i2, 0                    
     1 : annotation:whilecstart 0                        
     2 : mov                    i16, 0                   
     3 : jmp_le                 i1, i16, __loops_label_2 
     4 : annotation:whilecend                            
     5 : load.i8                i3, i0                   
     6 : mov                    i4, 43                   
     7 : shl                    i4, i4, 32               
     8 : rv_lui                 i30, 707048              
     9 : add                    i30, i30, 856            
    10 : add                    i4, i4, i30              
    11 : mov                    i5, 43                   
    12 : shl                    i5, i5, 32               
    13 : rv_lui                 i31, 707048              
    14 : add                    i31, i31, 1050           
    15 : add                    i5, i5, i31              
    16 : mov                    i6, 43                   
    17 : shl                    i6, i6, 32               
    18 : rv_lui                 i32, 707048              
    19 : add                    i32, i32, 1194           
    20 : add                    i6, i6, i32              
    21 : mov                    i17, 1                   
    22 : sub                    i22, i3, i17             
    23 : iverson_eq             i22, i22, 0              
    24 : sub                    i23, i5, i6              
    25 : sub                    i22, 0, i22              
    26 : and                    i22, i22, i23            
    27 : add                    i7, i6, i22              
    28 : mov                    i18, 0                   
    29 : sub                    i24, i3, i18             
    30 : iverson_eq             i24, i24, 0              
    31 : sub                    i25, i4, i7              
    32 : sub                    i24, 0, i24              
    33 : and                    i24, i24, i25            
    34 : add                    i8, i7, i24              
    35 : mov                    i9, 43                   
    36 : shl                    i9, i9, 32               
    37 : rv_lui                 i33, 707048              
    38 : add                    i33, i33, 564            
    39 : add                    i9, i9, i33              
    40 : mov                    i10, 43                  
    41 : shl                    i10, i10, 32             
    42 : rv_lui                 i34, 707048              
    43 : add                    i34, i34, 660            
    44 : add                    i10, i10, i34            
    45 : mov                    i11, 43                  
    46 : shl                    i11, i11, 32             
    47 : rv_lui                 i35, 707048              
    48 : add                    i35, i35, 722            
    49 : add                    i11, i11, i35            
    50 : mov                    i19, 1                   
    51 : sub                    i26, i3, i19             
    52 : iverson_eq             i26, i26, 0              
    53 : sub                    i27, i10, i11            
    54 : sub                    i26, 0, i26              
    55 : and                    i26, i26, i27            
    56 : add                    i12, i11, i26            
    57 : mov                    i20, 0                   
    58 : sub                    i28, i3, i20             
    59 : iverson_eq             i28, i28, 0              
    60 : sub                    i29, i9, i12             
    61 : sub                    i28, 0, i28              
    62 : and                    i28, i28, i29            
    63 : add                    i13, i12, i28            
    64 : call_noret             [i8](i0)                 
    65 : call                   [i13](i14, i0)           
    66 : mov                    i21, 43                  
    67 : shl                    i21, i21, 32             
    68 : rv_lui                 i36, 707048              
    69 : add                    i36, i36, 496            
    70 : add                    i21, i21, i36            
    71 : call                   [i21](i15, i2, i14)      
    72 : mov                    i2, i15                  
    73 : add                    i0, i0, 56               
    74 : sub                    i1, i1, 1                
    75 : annotation:endwhile    0, 2                     
    76 : mov                    iR, i2                   
    77 : ret                                             
