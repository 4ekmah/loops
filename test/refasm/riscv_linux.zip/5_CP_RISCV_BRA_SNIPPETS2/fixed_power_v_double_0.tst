fixed_power_v_double_0(i0, i1, i2)
     0 : mov                    i3, 0                   
     1 : mov                    i4, 8                   
     2 : mul                    i2, i2, i4              
     3 : annotation:whilecstart 0                       
     4 : jmp_ge                 i3, i2, __loops_label_2 
     5 : annotation:whilecend                           
     6 : add                    i5, i0, i3              
     7 : vld.fp64               v0, i5                  
     8 : rv_vsetvli             i6, 0, 152              
     9 : rv_lui                 i7, 261888              
    10 : add                    i7, i7, 0               
    11 : shl                    i7, i7, 32              
    12 : mov                    i8, 0                   
    13 : add                    i7, i7, i8              
    14 : broadcast.fp64         v1, i7                  
    15 : add                    i9, i1, i3              
    16 : vst.fp64               i9, v1                  
    17 : add                    i3, i3, 32              
    18 : annotation:endwhile    0, 2                    
    19 : mov                    iR, 0                   
    20 : ret                                            
