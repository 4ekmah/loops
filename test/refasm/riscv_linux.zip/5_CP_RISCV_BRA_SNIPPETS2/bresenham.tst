bresenham(i0, i1, i2, i3, i4, i5, i6)
     0 : sub                    i8, i4, i2                
     1 : iverson_gt             i21, 0, i8                
     2 : sub                    i21, 0, i21               
     3 : and                    i21, i21, i8              
     4 : sub                    i7, 0, i8                 
     5 : add                    i7, i7, i21               
     6 : add                    i7, i7, i21               
     7 : sub                    i10, i4, i2               
     8 : iverson_gt             i22, i10, 0               
     9 : iverson_gt             i23, 0, i10               
    10 : sub                    i9, i23, i22              
    11 : sub                    i13, i5, i3               
    12 : iverson_gt             i24, 0, i13               
    13 : sub                    i24, 0, i24               
    14 : and                    i24, i24, i13             
    15 : sub                    i12, 0, i13               
    16 : add                    i12, i12, i24             
    17 : add                    i12, i12, i24             
    18 : neg                    i11, i12                  
    19 : sub                    i15, i5, i3               
    20 : iverson_gt             i25, i15, 0               
    21 : iverson_gt             i26, 0, i15               
    22 : sub                    i14, i26, i25             
    23 : add                    i16, i7, i11              
    24 : annotation:whilecstart 0                         
    25 : mov                    i20, 0                    
    26 : jmp_eq                 i0, i20, __loops_label_2  
    27 : annotation:whilecend                             
    28 : mul                    i18, i3, i1               
    29 : add                    i17, i18, i2              
    30 : add                    i27, i0, i17              
    31 : store.u8               i27, i6                   
    32 : annotation:ifcstart                              
    33 : jmp_ne                 i2, i4, __loops_label_4   
    34 : jmp_ne                 i3, i5, __loops_label_4   
    35 : annotation:ifcend                                
    36 : annotation:break       2                         
    37 : annotation:endif       4                         
    38 : shl                    i19, i16, 1               
    39 : annotation:ifcstart                              
    40 : jmp_gt                 i19, i11, __loops_label_6 
    41 : annotation:ifcend                                
    42 : annotation:ifcstart                              
    43 : jmp_ne                 i2, i4, __loops_label_8   
    44 : annotation:ifcend                                
    45 : annotation:break       2                         
    46 : annotation:endif       8                         
    47 : add                    i16, i16, i11             
    48 : add                    i2, i2, i9                
    49 : annotation:endif       6                         
    50 : annotation:ifcstart                              
    51 : jmp_gt                 i19, i7, __loops_label_10 
    52 : annotation:ifcend                                
    53 : annotation:ifcstart                              
    54 : jmp_ne                 i3, i5, __loops_label_12  
    55 : annotation:ifcend                                
    56 : annotation:break       2                         
    57 : annotation:endif       12                        
    58 : add                    i16, i16, i7              
    59 : add                    i3, i3, i14               
    60 : annotation:endif       10                        
    61 : annotation:endwhile    0, 2                      
    62 : ret                                              
