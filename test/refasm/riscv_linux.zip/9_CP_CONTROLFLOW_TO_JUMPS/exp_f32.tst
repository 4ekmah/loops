exp_f32(i0, i1, i2)
     0 : rv_vsetvli       i13, 0, 144               
     1 : rv_lui           i13, 797452               
     2 : add              i13, i13, 165             
     3 : broadcast.fp32   v0, i13                   
     4 : rv_lui           i13, 273164               
     5 : add              i13, i13, 165             
     6 : broadcast.fp32   v1, i13                   
     7 : rv_lui           i13, 258048               
     8 : add              i13, i13, 0               
     9 : broadcast.fp32   v2, i13                   
    10 : rv_lui           i13, 260096               
    11 : add              i13, i13, 0               
    12 : broadcast.fp32   v3, i13                   
    13 : rv_lui           i13, 261003               
    14 : add              i13, i13, -1477           
    15 : broadcast.fp32   v4, i13                   
    16 : rv_lui           i13, 783128               
    17 : add              i13, i13, 0               
    18 : broadcast.fp32   v5, i13                   
    19 : rv_lui           i13, 234984               
    20 : add              i13, i13, 131             
    21 : broadcast.fp32   v6, i13                   
    22 : rv_lui           i13, 234759               
    23 : add              i13, i13, -1689           
    24 : broadcast.fp32   v7, i13                   
    25 : rv_lui           i13, 240500               
    26 : add              i13, i13, 974             
    27 : broadcast.fp32   v8, i13                   
    28 : rv_lui           i13, 245897               
    29 : add              i13, i13, -1784           
    30 : broadcast.fp32   v9, i13                   
    31 : rv_lui           i13, 250539               
    32 : add              i13, i13, -1599           
    33 : broadcast.fp32   v10, i13                  
    34 : rv_lui           i13, 254635               
    35 : add              i13, i13, -1366           
    36 : broadcast.fp32   v11, i13                  
    37 : rv_lui           i13, 258048               
    38 : add              i13, i13, 0               
    39 : broadcast.fp32   v12, i13                  
    40 : mov              i13, 127                  
    41 : broadcast.i32    v13, i13                  
    42 : mov              i13, 0                    
    43 : __loops_label_0:                           
    44 : mov              i14, 0                    
    45 : jmp_le           i12, i14, __loops_label_2 
    46 : add              i14, i11, i13             
    47 : vld.fp32         v14, i14                  
    48 : rv_vsetvli       i14, 0, 144               
    49 : min.fp32         v14, v14, v1              
    50 : max.fp32         v14, v14, v0              
    51 : rv_csrrwi        i14, 2, 0                 
    52 : mov              v15, v2                   
    53 : fma.fp32         v15, v15, v14, v4         
    54 : rv_csrrwi        i14, 2, 2                 
    55 : floor.fp32_i32   v15, v15                  
    56 : rv_csrrwi        i14, 2, 0                 
    57 : cast.i32_fp32    v16, v15                  
    58 : mov              v14, v14                  
    59 : fma.fp32         v14, v14, v16, v5         
    60 : mov              v14, v14                  
    61 : fma.fp32         v14, v14, v16, v6         
    62 : mov              v16, v8                   
    63 : fma.fp32         v16, v16, v14, v7         
    64 : mov              v17, v9                   
    65 : fma.fp32         v17, v17, v16, v14        
    66 : mov              v16, v10                  
    67 : fma.fp32         v16, v16, v17, v14        
    68 : mov              v17, v11                  
    69 : fma.fp32         v17, v17, v16, v14        
    70 : mov              v16, v12                  
    71 : fma.fp32         v16, v16, v17, v14        
    72 : mul.fp32         v17, v14, v14             
    73 : mov              v14, v14                  
    74 : fma.fp32         v14, v14, v16, v17        
    75 : add.fp32         v14, v14, v3              
    76 : add.i32          v15, v15, v13             
    77 : sal.i32          v15, v15, 23              
    78 : mul.fp32         v14, v14, v15             
    79 : add              i14, i10, i13             
    80 : vst.fp32         i14, v14                  
    81 : add              i13, i13, 32              
    82 : sub              i12, i12, 8               
    83 : jmp              0                         
    84 : __loops_label_2:                           
    85 : ret                                        
