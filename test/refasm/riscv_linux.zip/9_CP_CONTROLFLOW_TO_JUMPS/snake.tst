snake(i0, i1, i2)
     0 : sub              i2, i2, 256               
     1 : spill            27, i24                   
     2 : spill            28, i25                   
     3 : spill            29, i26                   
     4 : spill            30, i8                    
     5 : spill            31, i1                    
     6 : add              i13, i11, i12             
     7 : sub              i25, i13, 1               
     8 : spill            21, i25                   
     9 : mov              i25, 0                    
    10 : spill            20, i25                   
    11 : mov              i25, 1                    
    12 : spill            19, i25                   
    13 : unspill          i25, 19                   
    14 : neg              i26, i25                  
    15 : spill            16, i26                   
    16 : mov              i25, 0                    
    17 : spill            22, i25                   
    18 : __loops_label_0:                           
    19 : unspill          i26, 21                   
    20 : unspill          i25, 22                   
    21 : jmp_ge           i25, i26, __loops_label_2 
    22 : mov              i25, 0                    
    23 : spill            17, i25                   
    24 : mov              i25, 0                    
    25 : spill            18, i25                   
    26 : unspill          i25, 22                   
    27 : and              i13, i25, 1               
    28 : mov              i24, 0                    
    29 : jmp_eq           i13, i24, __loops_label_4 
    30 : sub              i25, i12, 1               
    31 : spill            23, i25                   
    32 : unspill          i26, 22                   
    33 : unspill          i25, 23                   
    34 : iverson_gt       i24, i25, i26             
    35 : unspill          i26, 22                   
    36 : unspill          i25, 23                   
    37 : sub              i13, i25, i26             
    38 : sub              i24, 0, i24               
    39 : and              i13, i24, i13             
    40 : unspill          i25, 22                   
    41 : add              i26, i25, i13             
    42 : spill            17, i26                   
    43 : unspill          i25, 22                   
    44 : unspill          i26, 23                   
    45 : sub              i13, i25, i26             
    46 : mov              i25, 0                    
    47 : spill            24, i25                   
    48 : unspill          i25, 22                   
    49 : unspill          i26, 23                   
    50 : iverson_gt       i24, i25, i26             
    51 : unspill          i25, 24                   
    52 : sub              i13, i13, i25             
    53 : sub              i24, 0, i24               
    54 : and              i13, i24, i13             
    55 : unspill          i25, 24                   
    56 : add              i26, i25, i13             
    57 : spill            18, i26                   
    58 : jmp              5                         
    59 : __loops_label_4:                           
    60 : sub              i25, i11, 1               
    61 : spill            25, i25                   
    62 : unspill          i25, 22                   
    63 : unspill          i26, 25                   
    64 : sub              i24, i25, i26             
    65 : mov              i25, 0                    
    66 : spill            26, i25                   
    67 : unspill          i25, 22                   
    68 : unspill          i26, 25                   
    69 : iverson_gt       i13, i25, i26             
    70 : unspill          i25, 26                   
    71 : sub              i24, i24, i25             
    72 : sub              i13, 0, i13               
    73 : and              i13, i13, i24             
    74 : unspill          i25, 26                   
    75 : add              i26, i25, i13             
    76 : spill            17, i26                   
    77 : unspill          i26, 22                   
    78 : unspill          i25, 25                   
    79 : iverson_gt       i13, i25, i26             
    80 : unspill          i26, 22                   
    81 : unspill          i25, 25                   
    82 : sub              i24, i25, i26             
    83 : sub              i13, 0, i13               
    84 : and              i13, i13, i24             
    85 : unspill          i25, 22                   
    86 : add              i26, i25, i13             
    87 : spill            18, i26                   
    88 : __loops_label_5:                           
    89 : __loops_label_6:                           
    90 : mov              i24, 0                    
    91 : unspill          i25, 17                   
    92 : jmp_gt           i25, i24, __loops_label_8 
    93 : unspill          i25, 17                   
    94 : jmp_ge           i25, i12, __loops_label_8 
    95 : mov              i24, 0                    
    96 : unspill          i25, 18                   
    97 : jmp_gt           i25, i24, __loops_label_8 
    98 : unspill          i25, 18                   
    99 : jmp_ge           i25, i11, __loops_label_8 
   100 : mov              i24, 43                   
   101 : shl              i24, i24, 32              
   102 : rv_lui           i13, 850102               
   103 : add              i13, i13, 286             
   104 : add              i13, i24, i13             
   105 : unspill          i25, 17                   
   106 : unspill          i26, 18                   
   107 : call_noret       [i13](i25, i26)           
   108 : unspill          i25, 18                   
   109 : mul              i13, i25, i12             
   110 : unspill          i25, 17                   
   111 : add              i13, i13, i25             
   112 : add              i13, i10, i13             
   113 : unspill          i25, 20                   
   114 : store.u8         i13, i25                  
   115 : unspill          i25, 20                   
   116 : add              i25, i25, 1               
   117 : spill            20, i25                   
   118 : unspill          i26, 19                   
   119 : unspill          i25, 17                   
   120 : add              i25, i25, i26             
   121 : spill            17, i25                   
   122 : unspill          i26, 16                   
   123 : unspill          i25, 18                   
   124 : add              i25, i25, i26             
   125 : spill            18, i25                   
   126 : jmp              6                         
   127 : __loops_label_8:                           
   128 : unspill          i25, 19                   
   129 : neg              i25, i25                  
   130 : spill            19, i25                   
   131 : unspill          i25, 16                   
   132 : neg              i25, i25                  
   133 : spill            16, i25                   
   134 : unspill          i25, 22                   
   135 : add              i25, i25, 1               
   136 : spill            22, i25                   
   137 : jmp              0                         
   138 : __loops_label_2:                           
   139 : unspill          i8, 30                    
   140 : unspill          i1, 31                    
   141 : unspill          i24, 27                   
   142 : unspill          i25, 28                   
   143 : unspill          i26, 29                   
   144 : add              i2, i2, 256               
   145 : ret                                        
