sort_double(i0, i1)
     0 : sub              i2, i2, 224               
     1 : spill            22, i24                   
     2 : spill            23, i25                   
     3 : spill            24, i26                   
     4 : spill            26, i8                    
     5 : spill            27, i1                    
     6 : shl              i25, i11, 3               
     7 : spill            18, i25                   
     8 : unspill          i25, 18                   
     9 : sub              i26, i25, 8               
    10 : spill            20, i26                   
    11 : mov              i25, 0                    
    12 : spill            21, i25                   
    13 : __loops_label_0:                           
    14 : unspill          i26, 20                   
    15 : unspill          i25, 21                   
    16 : jmp_ge           i25, i26, __loops_label_2 
    17 : unspill          i25, 21                   
    18 : mov              i26, i25                  
    19 : spill            17, i26                   
    20 : unspill          i25, 17                   
    21 : add              i26, i25, 8               
    22 : spill            16, i26                   
    23 : __loops_label_3:                           
    24 : unspill          i26, 18                   
    25 : unspill          i25, 16                   
    26 : jmp_ge           i25, i26, __loops_label_5 
    27 : unspill          i25, 16                   
    28 : add              i24, i10, i25             
    29 : load.fp64        i24, i24                  
    30 : unspill          i25, 17                   
    31 : add              i13, i10, i25             
    32 : load.fp64        i25, i13                  
    33 : spill            19, i25                   
    34 : mov              i12, 43                   
    35 : shl              i12, i12, 32              
    36 : rv_lui           i13, 850104               
    37 : add              i13, i13, -1614           
    38 : add              i12, i12, i13             
    39 : unspill          i25, 19                   
    40 : call             [i12](i12, i24, i25)      
    41 : mov              i13, 0                    
    42 : jmp_eq           i12, i13, __loops_label_7 
    43 : unspill          i25, 16                   
    44 : mov              i26, i25                  
    45 : spill            17, i26                   
    46 : __loops_label_7:                           
    47 : unspill          i25, 16                   
    48 : add              i25, i25, 8               
    49 : spill            16, i25                   
    50 : jmp              3                         
    51 : __loops_label_5:                           
    52 : unspill          i26, 21                   
    53 : unspill          i25, 17                   
    54 : jmp_eq           i25, i26, __loops_label_9 
    55 : unspill          i25, 21                   
    56 : add              i12, i10, i25             
    57 : load.fp64        i12, i12                  
    58 : unspill          i25, 17                   
    59 : add              i13, i10, i25             
    60 : load.fp64        i13, i13                  
    61 : unspill          i25, 17                   
    62 : add              i24, i10, i25             
    63 : store.fp64       i24, i12                  
    64 : unspill          i25, 21                   
    65 : add              i12, i10, i25             
    66 : store.fp64       i12, i13                  
    67 : __loops_label_9:                           
    68 : unspill          i25, 21                   
    69 : add              i25, i25, 8               
    70 : spill            21, i25                   
    71 : jmp              0                         
    72 : __loops_label_2:                           
    73 : unspill          i8, 26                    
    74 : unspill          i1, 27                    
    75 : unspill          i24, 22                   
    76 : unspill          i25, 23                   
    77 : unspill          i26, 24                   
    78 : add              i2, i2, 224               
    79 : ret                                        
