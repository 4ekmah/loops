area_sum(i0, i1)
     0 : sub              i2, i2, 208               
     1 : spill            21, i24                   
     2 : spill            22, i25                   
     3 : spill            24, i8                    
     4 : spill            25, i1                    
     5 : mov              i25, 0                    
     6 : spill            16, i25                   
     7 : __loops_label_0:                           
     8 : mov              i13, 0                    
     9 : jmp_le           i11, i13, __loops_label_2 
    10 : load.i8          i25, i10                  
    11 : spill            17, i25                   
    12 : mov              i24, 43                   
    13 : shl              i24, i24, 32              
    14 : rv_lui           i12, 850105               
    15 : add              i12, i12, -1436           
    16 : add              i25, i24, i12             
    17 : spill            18, i25                   
    18 : mov              i24, 43                   
    19 : shl              i24, i24, 32              
    20 : rv_lui           i13, 850105               
    21 : add              i13, i13, -1242           
    22 : add              i13, i24, i13             
    23 : mov              i24, 43                   
    24 : shl              i24, i24, 32              
    25 : rv_lui           i12, 850105               
    26 : add              i12, i12, -1098           
    27 : add              i12, i24, i12             
    28 : mov              i24, 1                    
    29 : unspill          i25, 17                   
    30 : sub              i24, i25, i24             
    31 : iverson_eq       i24, i24, 0               
    32 : sub              i13, i13, i12             
    33 : sub              i24, 0, i24               
    34 : and              i13, i24, i13             
    35 : add              i12, i12, i13             
    36 : mov              i13, 0                    
    37 : unspill          i25, 17                   
    38 : sub              i13, i25, i13             
    39 : iverson_eq       i13, i13, 0               
    40 : unspill          i25, 18                   
    41 : sub              i24, i25, i12             
    42 : sub              i13, 0, i13               
    43 : and              i13, i13, i24             
    44 : add              i25, i12, i13             
    45 : spill            19, i25                   
    46 : mov              i13, 43                   
    47 : shl              i13, i13, 32              
    48 : rv_lui           i24, 850105               
    49 : add              i24, i24, -1728           
    50 : add              i25, i13, i24             
    51 : spill            20, i25                   
    52 : mov              i24, 43                   
    53 : shl              i24, i24, 32              
    54 : rv_lui           i12, 850105               
    55 : add              i12, i12, -1632           
    56 : add              i12, i24, i12             
    57 : mov              i24, 43                   
    58 : shl              i24, i24, 32              
    59 : rv_lui           i13, 850105               
    60 : add              i13, i13, -1570           
    61 : add              i13, i24, i13             
    62 : mov              i24, 1                    
    63 : unspill          i25, 17                   
    64 : sub              i24, i25, i24             
    65 : iverson_eq       i24, i24, 0               
    66 : sub              i12, i12, i13             
    67 : sub              i24, 0, i24               
    68 : and              i12, i24, i12             
    69 : add              i12, i13, i12             
    70 : mov              i13, 0                    
    71 : unspill          i25, 17                   
    72 : sub              i13, i25, i13             
    73 : iverson_eq       i13, i13, 0               
    74 : unspill          i25, 20                   
    75 : sub              i24, i25, i12             
    76 : sub              i13, 0, i13               
    77 : and              i13, i13, i24             
    78 : add              i12, i12, i13             
    79 : unspill          i25, 19                   
    80 : call_noret       [i25](i10)                
    81 : call             [i12](i12, i10)           
    82 : mov              i13, 43                   
    83 : shl              i13, i13, 32              
    84 : rv_lui           i24, 850105               
    85 : add              i24, i24, -1796           
    86 : add              i13, i13, i24             
    87 : unspill          i25, 16                   
    88 : call             [i13](i12, i25, i12)      
    89 : mov              i25, i12                  
    90 : spill            16, i25                   
    91 : add              i10, i10, 56              
    92 : sub              i11, i11, 1               
    93 : jmp              0                         
    94 : __loops_label_2:                           
    95 : unspill          i25, 16                   
    96 : mov              i10, i25                  
    97 : unspill          i8, 24                    
    98 : unspill          i1, 25                    
    99 : unspill          i24, 21                   
   100 : unspill          i25, 22                   
   101 : add              i2, i2, 208               
   102 : ret                                        
