helloworld_call()
     0 : sub        i2, i2, 144     
     1 : spill      16, i8          
     2 : spill      17, i1          
     3 : mov        i10, 43         
     4 : shl        i10, i10, 32    
     5 : rv_lui     i11, 850102     
     6 : add        i11, i11, -1346 
     7 : add        i10, i10, i11   
     8 : call_noret [i10]()         
     9 : unspill    i8, 16          
    10 : unspill    i1, 17          
    11 : add        i2, i2, 144     
    12 : ret                        
