fixed_power_v_double_4(i0, i1, i2)
     0 : mov                    i4, 0                   
     1 : mov                    i5, 8                   
     2 : mul                    i3, i2, i5              
     3 : annotation:whilecstart 0                       
     4 : jmp_ge                 i4, i3, __loops_label_2 
     5 : annotation:whilecend                           
     6 : add                    i6, i0, i4              
     7 : vld.fp64               v0, i6                  
     8 : rv_vsetvli             i7, 0, 152              
     9 : rv_csrrwi              i8, 2, 0                
    10 : mul.fp64               v2, v0, v0              
    11 : mul.fp64               v1, v2, v2              
    12 : add                    i9, i1, i4              
    13 : vst.fp64               i9, v1                  
    14 : add                    i4, i4, 32              
    15 : annotation:endwhile    0, 2                    
    16 : mov                    iR, 0                   
    17 : ret                                            
