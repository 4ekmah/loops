min_max_scalar(i0, i1, i2, i3)
     0 : mov                    i5, 0                     
     1 : mov                    i6, 0                     
     2 : mov                    i8, 0                     
     3 : load.i32               i10, i0                   
     4 : mov                    i11, i10                  
     5 : mov                    i14, 4                    
     6 : mul                    i4, i1, i14               
     7 : annotation:whilecstart 0                         
     8 : jmp_ge                 i5, i4, __loops_label_2   
     9 : annotation:whilecend                             
    10 : add                    i15, i0, i5               
    11 : load.i32               i12, i15                  
    12 : annotation:ifcstart                              
    13 : jmp_ge                 i12, i10, __loops_label_4 
    14 : annotation:ifcend                                
    15 : mov                    i10, i12                  
    16 : mov                    i6, i5                    
    17 : annotation:endif       4                         
    18 : annotation:ifcstart                              
    19 : jmp_le                 i12, i11, __loops_label_6 
    20 : annotation:ifcend                                
    21 : mov                    i11, i12                  
    22 : mov                    i8, i5                    
    23 : annotation:endif       6                         
    24 : add                    i5, i5, 4                 
    25 : annotation:endwhile    0, 2                      
    26 : mov                    i13, 4                    
    27 : div                    i7, i6, i13               
    28 : div                    i9, i8, i13               
    29 : store.i32              i2, i7                    
    30 : store.i32              i3, i9                    
    31 : mov                    iR, 0                     
    32 : ret                                              
