fixed_power_v_int32_t_0(i0, i1, i2)
     0 : mov                    i4, 0                   
     1 : mov                    i5, 4                   
     2 : mul                    i3, i2, i5              
     3 : annotation:whilecstart 0                       
     4 : jmp_ge                 i4, i3, __loops_label_2 
     5 : annotation:whilecend                           
     6 : add                    i6, i0, i4              
     7 : vld.i32                v0, i6                  
     8 : rv_vsetvli             i7, 0, 144              
     9 : broadcast.i32          v1, 1                   
    10 : add                    i8, i1, i4              
    11 : vst.i32                i8, v1                  
    12 : add                    i4, i4, 32              
    13 : annotation:endwhile    0, 2                    
    14 : mov                    iR, 0                   
    15 : ret                                            
