conditionpainter(i0)
     0 : mov                    i1, -5                   
     1 : annotation:whilecstart 0                        
     2 : mov                    i81, 5                   
     3 : jmp_gt                 i1, i81, __loops_label_2 
     4 : annotation:whilecend                            
     5 : add                    i4, i1, 5                
     6 : mov                    i82, 11                  
     7 : mul                    i3, i4, i82              
     8 : mov                    i83, 8                   
     9 : mul                    i2, i3, i83              
    10 : mov                    i5, -5                   
    11 : annotation:whilecstart 3                        
    12 : mov                    i84, 5                   
    13 : jmp_gt                 i5, i84, __loops_label_5 
    14 : annotation:whilecend                            
    15 : add                    i11, i5, 3               
    16 : iverson_gt             i12, i1, i11             
    17 : neg                    i13, i12                 
    18 : add                    i14, i13, 1              
    19 : mov                    i85, 4                   
    20 : iverson_gt             i15, i1, i85             
    21 : neg                    i16, i15                 
    22 : add                    i17, i16, 1              
    23 : and                    i10, i14, i17            
    24 : mov                    i86, -2                  
    25 : iverson_gt             i18, i5, i86             
    26 : neg                    i19, i18                 
    27 : add                    i20, i19, 1              
    28 : and                    i9, i10, i20             
    29 : mov                    i87, 0                   
    30 : iverson_gt             i21, i5, i87             
    31 : neg                    i22, i21                 
    32 : add                    i23, i22, 1              
    33 : and                    i8, i9, i23              
    34 : sub                    i27, i5, 1               
    35 : iverson_gt             i28, i1, i27             
    36 : neg                    i29, i28                 
    37 : add                    i30, i29, 1              
    38 : mov                    i88, 0                   
    39 : iverson_gt             i31, i5, i88             
    40 : neg                    i32, i31                 
    41 : add                    i33, i32, 1              
    42 : and                    i26, i30, i33            
    43 : mov                    i89, 0                   
    44 : iverson_gt             i34, i1, i89             
    45 : neg                    i35, i34                 
    46 : add                    i36, i35, 1              
    47 : and                    i25, i26, i36            
    48 : mul                    i38, i5, i5              
    49 : mul                    i39, i1, i1              
    50 : add                    i37, i38, i39            
    51 : mov                    i90, 9                   
    52 : iverson_gt             i40, i37, i90            
    53 : neg                    i41, i40                 
    54 : add                    i42, i41, 1              
    55 : and                    i24, i25, i42            
    56 : or                     i6, i8, i24              
    57 : mov                    i43, 2                   
    58 : mov                    i44, 0                   
    59 : mov                    i91, 2                   
    60 : iverson_gt             i48, i5, i91             
    61 : neg                    i49, i48                 
    62 : add                    i50, i49, 1              
    63 : mov                    i92, 4                   
    64 : iverson_gt             i51, i5, i92             
    65 : neg                    i52, i51                 
    66 : add                    i53, i52, 1              
    67 : and                    i47, i50, i53            
    68 : mov                    i93, 1                   
    69 : iverson_gt             i55, i1, i93             
    70 : neg                    i56, i55                 
    71 : add                    i57, i56, 1              
    72 : mov                    i94, 3                   
    73 : iverson_gt             i58, i1, i94             
    74 : neg                    i59, i58                 
    75 : add                    i60, i59, 1              
    76 : and                    i54, i57, i60            
    77 : or                     i46, i47, i54            
    78 : mul                    i62, i5, i5              
    79 : mul                    i63, i1, i1              
    80 : add                    i61, i62, i63            
    81 : mov                    i95, 16                  
    82 : iverson_gt             i64, i61, i95            
    83 : neg                    i65, i64                 
    84 : add                    i66, i65, 1              
    85 : and                    i45, i46, i66            
    86 : mov                    i96, 0                   
    87 : sub                    i100, i45, i96           
    88 : iverson_ne             i101, i100, 0            
    89 : sub                    i104, i43, i44           
    90 : sub                    i102, 0, i101            
    91 : and                    i103, i102, i104         
    92 : add                    i67, i44, i103           
    93 : add                    i7, i6, i67              
    94 : annotation:ifcstart                             
    95 : mov                    i97, 2                   
    96 : mul                    i68, i1, i97             
    97 : jmp_gt                 i68, i5, __loops_label_8 
    98 : add                    i71, i5, 3               
    99 : neg                    i70, i71                 
   100 : add                    i72, i5, 3               
   101 : mul                    i69, i70, i72            
   102 : jmp_le                 i1, i69, __loops_label_9 
   103 : __loops_label_8:                                
   104 : mov                    i98, 2                   
   105 : mul                    i73, i5, i98             
   106 : jmp_gt                 i1, i73, __loops_label_7 
   107 : add                    i76, i5, 3               
   108 : neg                    i75, i76                 
   109 : add                    i77, i5, 3               
   110 : mul                    i74, i75, i77            
   111 : jmp_gt                 i1, i74, __loops_label_7 
   112 : __loops_label_9:                                
   113 : mov                    i99, 0                   
   114 : jmp_gt                 i5, i99, __loops_label_7 
   115 : annotation:ifcend                               
   116 : add                    i7, i7, 3                
   117 : annotation:endif       7                        
   118 : add                    i80, i5, 5               
   119 : shl                    i79, i80, 3              
   120 : add                    i78, i2, i79             
   121 : add                    i105, i0, i78            
   122 : store.i64              i105, i7                 
   123 : add                    i5, i5, 1                
   124 : annotation:endwhile    3, 5                     
   125 : add                    i1, i1, 1                
   126 : annotation:endwhile    0, 2                     
   127 : ret                                             
