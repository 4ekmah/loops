sort_double(i0, i1)
     0 : shl                    i2, i1, 3                
     1 : sub                    i3, i2, 8                
     2 : mov                    i4, 0                    
     3 : annotation:whilecstart 0                        
     4 : jmp_ge                 i4, i3, __loops_label_2  
     5 : annotation:whilecend                            
     6 : mov                    i5, i4                   
     7 : add                    i6, i5, 8                
     8 : annotation:whilecstart 3                        
     9 : jmp_ge                 i6, i2, __loops_label_5  
    10 : annotation:whilecend                            
    11 : annotation:ifcstart                             
    12 : add                    i16, i0, i6              
    13 : load.fp64              i8, i16                  
    14 : add                    i17, i0, i5              
    15 : load.fp64              i9, i17                  
    16 : mov                    i12, 43                  
    17 : shl                    i13, i12, 32             
    18 : rv_lui                 i18, 707047              
    19 : add                    i19, i18, 678            
    20 : add                    i14, i13, i19            
    21 : call                   [i14](i7, i8, i9)        
    22 : mov                    i15, 0                   
    23 : jmp_eq                 i7, i15, __loops_label_7 
    24 : annotation:ifcend                               
    25 : mov                    i5, i6                   
    26 : annotation:endif       7                        
    27 : add                    i6, i6, 8                
    28 : annotation:endwhile    3, 5                     
    29 : annotation:ifcstart                             
    30 : jmp_eq                 i5, i4, __loops_label_9  
    31 : annotation:ifcend                               
    32 : add                    i20, i0, i4              
    33 : load.fp64              i10, i20                 
    34 : add                    i21, i0, i5              
    35 : load.fp64              i11, i21                 
    36 : add                    i22, i0, i5              
    37 : store.fp64             i22, i10                 
    38 : add                    i23, i0, i4              
    39 : store.fp64             i23, i11                 
    40 : annotation:endif       9                        
    41 : add                    i4, i4, 8                
    42 : annotation:endwhile    0, 2                     
    43 : ret                                             
