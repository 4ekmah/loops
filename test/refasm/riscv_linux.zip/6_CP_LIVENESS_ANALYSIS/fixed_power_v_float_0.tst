fixed_power_v_float_0(i0, i1, i2)
     0 : mov                    i4, 0                   
     1 : mov                    i5, 4                   
     2 : mul                    i3, i2, i5              
     3 : annotation:whilecstart 0                       
     4 : jmp_ge                 i4, i3, __loops_label_2 
     5 : annotation:whilecend                           
     6 : add                    i6, i0, i4              
     7 : vld.fp32               v0, i6                  
     8 : rv_vsetvli             i7, 0, 144              
     9 : rv_lui                 i8, 260096              
    10 : add                    i9, i8, 0               
    11 : broadcast.fp32         v1, i9                  
    12 : add                    i10, i1, i4             
    13 : vst.fp32               i10, v1                 
    14 : add                    i4, i4, 32              
    15 : annotation:endwhile    0, 2                    
    16 : mov                    iR, 0                   
    17 : ret                                            
