bresenham(i0, i1, i2, i3, i4, i5, i6)
     0 : sub                    i10, i4, i2               
     1 : iverson_gt             i25, 0, i10               
     2 : sub                    i26, 0, i25               
     3 : and                    i27, i26, i10             
     4 : sub                    i7, 0, i10                
     5 : add                    i8, i7, i27               
     6 : add                    i9, i8, i27               
     7 : sub                    i12, i4, i2               
     8 : iverson_gt             i28, i12, 0               
     9 : iverson_gt             i29, 0, i12               
    10 : sub                    i11, i29, i28             
    11 : sub                    i17, i5, i3               
    12 : iverson_gt             i30, 0, i17               
    13 : sub                    i31, 0, i30               
    14 : and                    i32, i31, i17             
    15 : sub                    i14, 0, i17               
    16 : add                    i15, i14, i32             
    17 : add                    i16, i15, i32             
    18 : neg                    i13, i16                  
    19 : sub                    i19, i5, i3               
    20 : iverson_gt             i33, i19, 0               
    21 : iverson_gt             i34, 0, i19               
    22 : sub                    i18, i34, i33             
    23 : add                    i20, i9, i13              
    24 : annotation:whilecstart 0                         
    25 : mov                    i24, 0                    
    26 : jmp_eq                 i0, i24, __loops_label_2  
    27 : annotation:whilecend                             
    28 : mul                    i22, i3, i1               
    29 : add                    i21, i22, i2              
    30 : add                    i35, i0, i21              
    31 : store.u8               i35, i6                   
    32 : annotation:ifcstart                              
    33 : jmp_ne                 i2, i4, __loops_label_4   
    34 : jmp_ne                 i3, i5, __loops_label_4   
    35 : annotation:ifcend                                
    36 : annotation:break       2                         
    37 : annotation:endif       4                         
    38 : shl                    i23, i20, 1               
    39 : annotation:ifcstart                              
    40 : jmp_gt                 i23, i13, __loops_label_6 
    41 : annotation:ifcend                                
    42 : annotation:ifcstart                              
    43 : jmp_ne                 i2, i4, __loops_label_8   
    44 : annotation:ifcend                                
    45 : annotation:break       2                         
    46 : annotation:endif       8                         
    47 : add                    i20, i20, i13             
    48 : add                    i2, i2, i11               
    49 : annotation:endif       6                         
    50 : annotation:ifcstart                              
    51 : jmp_gt                 i23, i9, __loops_label_10 
    52 : annotation:ifcend                                
    53 : annotation:ifcstart                              
    54 : jmp_ne                 i3, i5, __loops_label_12  
    55 : annotation:ifcend                                
    56 : annotation:break       2                         
    57 : annotation:endif       12                        
    58 : add                    i20, i20, i9              
    59 : add                    i3, i3, i18               
    60 : annotation:endif       10                        
    61 : annotation:endwhile    0, 2                      
    62 : ret                                              
