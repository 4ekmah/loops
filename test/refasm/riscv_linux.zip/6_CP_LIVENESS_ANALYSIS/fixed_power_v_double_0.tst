fixed_power_v_double_0(i0, i1, i2)
     0 : mov                    i4, 0                   
     1 : mov                    i5, 8                   
     2 : mul                    i3, i2, i5              
     3 : annotation:whilecstart 0                       
     4 : jmp_ge                 i4, i3, __loops_label_2 
     5 : annotation:whilecend                           
     6 : add                    i6, i0, i4              
     7 : vld.fp64               v0, i6                  
     8 : rv_vsetvli             i7, 0, 152              
     9 : rv_lui                 i8, 261888              
    10 : add                    i9, i8, 0               
    11 : shl                    i10, i9, 32             
    12 : mov                    i12, 0                  
    13 : add                    i11, i10, i12           
    14 : broadcast.fp64         v1, i11                 
    15 : add                    i13, i1, i4             
    16 : vst.fp64               i13, v1                 
    17 : add                    i4, i4, 32              
    18 : annotation:endwhile    0, 2                    
    19 : mov                    iR, 0                   
    20 : ret                                            
