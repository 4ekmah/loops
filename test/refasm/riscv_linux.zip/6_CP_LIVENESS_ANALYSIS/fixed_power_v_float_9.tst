fixed_power_v_float_9(i0, i1, i2)
     0 : mov                    i4, 0                   
     1 : mov                    i5, 4                   
     2 : mul                    i3, i2, i5              
     3 : annotation:whilecstart 0                       
     4 : jmp_ge                 i4, i3, __loops_label_2 
     5 : annotation:whilecend                           
     6 : add                    i6, i0, i4              
     7 : vld.fp32               v0, i6                  
     8 : rv_vsetvli             i7, 0, 144              
     9 : rv_csrrwi              i8, 2, 0                
    10 : mul.fp32               v4, v0, v0              
    11 : mul.fp32               v3, v4, v4              
    12 : mul.fp32               v2, v3, v3              
    13 : mul.fp32               v1, v0, v2              
    14 : add                    i9, i1, i4              
    15 : vst.fp32               i9, v1                  
    16 : add                    i4, i4, 32              
    17 : annotation:endwhile    0, 2                    
    18 : mov                    iR, 0                   
    19 : ret                                            
