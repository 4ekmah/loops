all_loads_all_stores(i0, i1, i2, i3, i4)
     0 : mov                    i5, 0                     
     1 : mov                    i6, 0                     
     2 : mov                    i7, 0                     
     3 : mov                    i8, 2                     
     4 : mov                    i9, 1                     
     5 : mov                    i23, 1                    
     6 : iverson_gt             i43, i1, i23              
     7 : sub                    i46, i8, i9               
     8 : sub                    i44, 0, i43               
     9 : and                    i45, i44, i46             
    10 : add                    i10, i9, i45              
    11 : mov                    i13, 4                    
    12 : mov                    i24, 3                    
    13 : iverson_gt             i47, i1, i24              
    14 : sub                    i50, i13, i10             
    15 : sub                    i48, 0, i47               
    16 : and                    i49, i48, i50             
    17 : add                    i11, i10, i49             
    18 : mov                    i14, 8                    
    19 : mov                    i25, 5                    
    20 : iverson_gt             i51, i1, i25              
    21 : sub                    i54, i14, i11             
    22 : sub                    i52, 0, i51               
    23 : and                    i53, i52, i54             
    24 : add                    i12, i11, i53             
    25 : mov                    i15, 2                    
    26 : mov                    i16, 1                    
    27 : mov                    i26, 1                    
    28 : iverson_gt             i55, i3, i26              
    29 : sub                    i58, i15, i16             
    30 : sub                    i56, 0, i55               
    31 : and                    i57, i56, i58             
    32 : add                    i17, i16, i57             
    33 : mov                    i20, 4                    
    34 : mov                    i27, 3                    
    35 : iverson_gt             i59, i3, i27              
    36 : sub                    i62, i20, i17             
    37 : sub                    i60, 0, i59               
    38 : and                    i61, i60, i62             
    39 : add                    i18, i17, i61             
    40 : mov                    i21, 8                    
    41 : mov                    i28, 5                    
    42 : iverson_gt             i63, i3, i28              
    43 : sub                    i66, i21, i18             
    44 : sub                    i64, 0, i63               
    45 : and                    i65, i64, i66             
    46 : add                    i19, i18, i65             
    47 : annotation:whilecstart 0                         
    48 : jmp_ge                 i5, i4, __loops_label_2   
    49 : annotation:whilecend                             
    50 : def                    i22                       
    51 : annotation:ifcstart                              
    52 : mov                    i29, 0                    
    53 : jmp_ne                 i1, i29, __loops_label_4  
    54 : annotation:ifcend                                
    55 : add                    i67, i0, i6               
    56 : load.u8                i22, i67                  
    57 : annotation:else        4, 5                      
    58 : annotation:ifcstart                              
    59 : mov                    i30, 1                    
    60 : jmp_ne                 i1, i30, __loops_label_7  
    61 : annotation:ifcend                                
    62 : add                    i68, i0, i6               
    63 : load.i8                i22, i68                  
    64 : annotation:else        7, 8                      
    65 : annotation:ifcstart                              
    66 : mov                    i31, 2                    
    67 : jmp_ne                 i1, i31, __loops_label_10 
    68 : annotation:ifcend                                
    69 : add                    i69, i0, i6               
    70 : load.u16               i22, i69                  
    71 : annotation:else        10, 11                    
    72 : annotation:ifcstart                              
    73 : mov                    i32, 3                    
    74 : jmp_ne                 i1, i32, __loops_label_13 
    75 : annotation:ifcend                                
    76 : add                    i70, i0, i6               
    77 : load.i16               i22, i70                  
    78 : annotation:else        13, 14                    
    79 : annotation:ifcstart                              
    80 : mov                    i33, 4                    
    81 : jmp_ne                 i1, i33, __loops_label_16 
    82 : annotation:ifcend                                
    83 : add                    i71, i0, i6               
    84 : load.u32               i22, i71                  
    85 : annotation:else        16, 17                    
    86 : annotation:ifcstart                              
    87 : mov                    i34, 5                    
    88 : jmp_ne                 i1, i34, __loops_label_19 
    89 : annotation:ifcend                                
    90 : add                    i72, i0, i6               
    91 : load.i32               i22, i72                  
    92 : annotation:else        19, 20                    
    93 : annotation:ifcstart                              
    94 : mov                    i35, 6                    
    95 : jmp_ne                 i1, i35, __loops_label_22 
    96 : annotation:ifcend                                
    97 : add                    i73, i0, i6               
    98 : load.u64               i22, i73                  
    99 : annotation:else        22, 23                    
   100 : add                    i74, i0, i6               
   101 : load.i64               i22, i74                  
   102 : annotation:endif       5                         
   103 : annotation:endif       8                         
   104 : annotation:endif       11                        
   105 : annotation:endif       14                        
   106 : annotation:endif       17                        
   107 : annotation:endif       20                        
   108 : annotation:endif       23                        
   109 : annotation:ifcstart                              
   110 : mov                    i36, 0                    
   111 : jmp_ne                 i3, i36, __loops_label_25 
   112 : annotation:ifcend                                
   113 : add                    i75, i2, i7               
   114 : store.u8               i75, i22                  
   115 : annotation:else        25, 26                    
   116 : annotation:ifcstart                              
   117 : mov                    i37, 1                    
   118 : jmp_ne                 i3, i37, __loops_label_28 
   119 : annotation:ifcend                                
   120 : add                    i76, i2, i7               
   121 : store.i8               i76, i22                  
   122 : annotation:else        28, 29                    
   123 : annotation:ifcstart                              
   124 : mov                    i38, 2                    
   125 : jmp_ne                 i3, i38, __loops_label_31 
   126 : annotation:ifcend                                
   127 : add                    i77, i2, i7               
   128 : store.u16              i77, i22                  
   129 : annotation:else        31, 32                    
   130 : annotation:ifcstart                              
   131 : mov                    i39, 3                    
   132 : jmp_ne                 i3, i39, __loops_label_34 
   133 : annotation:ifcend                                
   134 : add                    i78, i2, i7               
   135 : store.i16              i78, i22                  
   136 : annotation:else        34, 35                    
   137 : annotation:ifcstart                              
   138 : mov                    i40, 4                    
   139 : jmp_ne                 i3, i40, __loops_label_37 
   140 : annotation:ifcend                                
   141 : add                    i79, i2, i7               
   142 : store.u32              i79, i22                  
   143 : annotation:else        37, 38                    
   144 : annotation:ifcstart                              
   145 : mov                    i41, 5                    
   146 : jmp_ne                 i3, i41, __loops_label_40 
   147 : annotation:ifcend                                
   148 : add                    i80, i2, i7               
   149 : store.i32              i80, i22                  
   150 : annotation:else        40, 41                    
   151 : annotation:ifcstart                              
   152 : mov                    i42, 6                    
   153 : jmp_ne                 i3, i42, __loops_label_43 
   154 : annotation:ifcend                                
   155 : add                    i81, i2, i7               
   156 : store.u64              i81, i22                  
   157 : annotation:else        43, 44                    
   158 : add                    i82, i2, i7               
   159 : store.i64              i82, i22                  
   160 : annotation:endif       26                        
   161 : annotation:endif       29                        
   162 : annotation:endif       32                        
   163 : annotation:endif       35                        
   164 : annotation:endif       38                        
   165 : annotation:endif       41                        
   166 : annotation:endif       44                        
   167 : add                    i6, i6, i12               
   168 : add                    i7, i7, i19               
   169 : add                    i5, i5, 1                 
   170 : annotation:endwhile    0, 2                      
