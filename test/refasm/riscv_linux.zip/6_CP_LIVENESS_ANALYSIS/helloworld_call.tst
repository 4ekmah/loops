helloworld_call()
     0 : mov        i0, 43      
     1 : shl        i1, i0, 32  
     2 : rv_lui     i3, 707045  
     3 : add        i4, i3, 946 
     4 : add        i2, i1, i4  
     5 : call_noret [i2]()      
     6 : ret                    
