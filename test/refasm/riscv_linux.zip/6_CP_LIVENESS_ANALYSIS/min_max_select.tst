min_max_select(i0, i1, i2, i3)
     0 : mov                    i5, 0                   
     1 : mov                    i6, 0                   
     2 : mov                    i8, 0                   
     3 : load.i32               i10, i0                 
     4 : mov                    i11, i10                
     5 : shl                    i4, i1, 2               
     6 : annotation:whilecstart 0                       
     7 : jmp_ge                 i5, i4, __loops_label_2 
     8 : annotation:whilecend                           
     9 : add                    i29, i0, i5             
    10 : load.i32               i12, i29                
    11 : iverson_gt             i13, i12, i10           
    12 : sub                    i16, i5, i6             
    13 : sub                    i14, 0, i13             
    14 : and                    i15, i14, i16           
    15 : add                    i6, i6, i15             
    16 : iverson_gt             i17, i12, i10           
    17 : sub                    i20, i12, i10           
    18 : sub                    i18, 0, i17             
    19 : and                    i19, i18, i20           
    20 : add                    i10, i10, i19           
    21 : iverson_gt             i21, i12, i11           
    22 : sub                    i24, i5, i8             
    23 : sub                    i22, 0, i21             
    24 : and                    i23, i22, i24           
    25 : add                    i8, i8, i23             
    26 : iverson_gt             i25, i12, i11           
    27 : sub                    i28, i11, i12           
    28 : sub                    i26, 0, i25             
    29 : and                    i27, i26, i28           
    30 : add                    i11, i12, i27           
    31 : add                    i5, i5, 4               
    32 : annotation:endwhile    0, 2                    
    33 : sar                    i7, i6, 2               
    34 : sar                    i9, i8, 2               
    35 : store.i32              i2, i7                  
    36 : store.i32              i3, i9                  
    37 : mov                    iR, 0                   
    38 : ret                                            
