min_max_select(i0, i1, i2, i3)
     0 : mov                    i5, 0                   
     1 : mov                    i6, 0                   
     2 : mov                    i7, 0                   
     3 : load.i32               i8, i0                  
     4 : mov                    i9, i8                  
     5 : shl                    i4, i1, 2               
     6 : annotation:whilecstart 0                       
     7 : jmp_ge                 i5, i4, __loops_label_2 
     8 : annotation:whilecend                           
     9 : add                    i27, i0, i5             
    10 : load.i32               i10, i27                
    11 : iverson_gt             i11, i10, i8            
    12 : sub                    i14, i5, i6             
    13 : sub                    i12, 0, i11             
    14 : and                    i13, i12, i14           
    15 : add                    i6, i6, i13             
    16 : iverson_gt             i15, i10, i8            
    17 : sub                    i18, i10, i8            
    18 : sub                    i16, 0, i15             
    19 : and                    i17, i16, i18           
    20 : add                    i8, i8, i17             
    21 : iverson_gt             i19, i10, i9            
    22 : sub                    i22, i5, i7             
    23 : sub                    i20, 0, i19             
    24 : and                    i21, i20, i22           
    25 : add                    i7, i7, i21             
    26 : iverson_gt             i23, i10, i9            
    27 : sub                    i26, i9, i10            
    28 : sub                    i24, 0, i23             
    29 : and                    i25, i24, i26           
    30 : add                    i9, i10, i25            
    31 : add                    i5, i5, 4               
    32 : annotation:endwhile    0, 2                    
    33 : sar                    i6, i6, 2               
    34 : sar                    i7, i7, 2               
    35 : store.i32              i2, i6                  
    36 : store.i32              i3, i7                  
    37 : mov                    iR, 0                   
    38 : ret                                            
