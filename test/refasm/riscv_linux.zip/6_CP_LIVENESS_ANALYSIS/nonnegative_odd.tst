nonnegative_odd(i0, i1)
     0 : mov                    i3, 0                    
     1 : mov                    i4, -4                   
     2 : mov                    i8, 4                    
     3 : mul                    i2, i1, i8               
     4 : annotation:whilecstart 0                        
     5 : jmp_ge                 i3, i2, __loops_label_2  
     6 : annotation:whilecend                            
     7 : add                    i13, i0, i3              
     8 : load.i32               i6, i13                  
     9 : annotation:ifcstart                             
    10 : mov                    i9, 0                    
    11 : jmp_ge                 i6, i9, __loops_label_4  
    12 : annotation:ifcend                               
    13 : add                    i3, i3, 4                
    14 : annotation:break       0                        
    15 : annotation:endif       4                        
    16 : mov                    i10, 2                   
    17 : mod                    i7, i6, i10              
    18 : annotation:ifcstart                             
    19 : mov                    i11, 0                   
    20 : jmp_eq                 i7, i11, __loops_label_6 
    21 : annotation:ifcend                               
    22 : mov                    i4, i3                   
    23 : annotation:break       2                        
    24 : annotation:endif       6                        
    25 : add                    i3, i3, 4                
    26 : annotation:endwhile    0, 2                     
    27 : mov                    i12, 4                   
    28 : div                    i5, i4, i12              
    29 : mov                    iR, i5                   
    30 : ret                                             
