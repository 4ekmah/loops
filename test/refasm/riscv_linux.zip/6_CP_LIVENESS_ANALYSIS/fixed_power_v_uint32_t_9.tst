fixed_power_v_uint32_t_9(i0, i1, i2)
     0 : mov                    i4, 0                   
     1 : mov                    i5, 4                   
     2 : mul                    i3, i2, i5              
     3 : annotation:whilecstart 0                       
     4 : jmp_ge                 i4, i3, __loops_label_2 
     5 : annotation:whilecend                           
     6 : add                    i6, i0, i4              
     7 : vld.u32                v0, i6                  
     8 : rv_vsetvli             i7, 0, 144              
     9 : mul.u32                v4, v0, v0              
    10 : mul.u32                v3, v4, v4              
    11 : mul.u32                v2, v3, v3              
    12 : mul.u32                v1, v0, v2              
    13 : add                    i8, i1, i4              
    14 : vst.u32                i8, v1                  
    15 : add                    i4, i4, 32              
    16 : annotation:endwhile    0, 2                    
    17 : mov                    iR, 0                   
    18 : ret                                            
