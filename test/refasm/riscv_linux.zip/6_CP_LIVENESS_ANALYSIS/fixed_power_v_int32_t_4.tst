fixed_power_v_int32_t_4(i0, i1, i2)
     0 : mov                    i4, 0                   
     1 : mov                    i5, 4                   
     2 : mul                    i3, i2, i5              
     3 : annotation:whilecstart 0                       
     4 : jmp_ge                 i4, i3, __loops_label_2 
     5 : annotation:whilecend                           
     6 : add                    i6, i0, i4              
     7 : vld.i32                v0, i6                  
     8 : rv_vsetvli             i7, 0, 144              
     9 : mul.i32                v2, v0, v0              
    10 : mul.i32                v1, v2, v2              
    11 : add                    i8, i1, i4              
    12 : vst.i32                i8, v1                  
    13 : add                    i4, i4, 32              
    14 : annotation:endwhile    0, 2                    
    15 : mov                    iR, 0                   
    16 : ret                                            
