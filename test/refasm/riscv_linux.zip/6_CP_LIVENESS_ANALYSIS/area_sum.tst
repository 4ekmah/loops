area_sum(i0, i1)
     0 : mov                    i2, 0                    
     1 : annotation:whilecstart 0                        
     2 : mov                    i28, 0                   
     3 : jmp_le                 i1, i28, __loops_label_2 
     4 : annotation:whilecend                            
     5 : load.i8                i3, i0                   
     6 : mov                    i4, 43                   
     7 : shl                    i5, i4, 32               
     8 : rv_lui                 i56, 707048              
     9 : add                    i57, i56, 856            
    10 : add                    i6, i5, i57              
    11 : mov                    i7, 43                   
    12 : shl                    i8, i7, 32               
    13 : rv_lui                 i58, 707048              
    14 : add                    i59, i58, 1050           
    15 : add                    i9, i8, i59              
    16 : mov                    i10, 43                  
    17 : shl                    i11, i10, 32             
    18 : rv_lui                 i60, 707048              
    19 : add                    i61, i60, 1194           
    20 : add                    i12, i11, i61            
    21 : mov                    i29, 1                   
    22 : sub                    i36, i3, i29             
    23 : iverson_eq             i37, i36, 0              
    24 : sub                    i40, i9, i12             
    25 : sub                    i38, 0, i37              
    26 : and                    i39, i38, i40            
    27 : add                    i13, i12, i39            
    28 : mov                    i30, 0                   
    29 : sub                    i41, i3, i30             
    30 : iverson_eq             i42, i41, 0              
    31 : sub                    i45, i6, i13             
    32 : sub                    i43, 0, i42              
    33 : and                    i44, i43, i45            
    34 : add                    i14, i13, i44            
    35 : mov                    i15, 43                  
    36 : shl                    i16, i15, 32             
    37 : rv_lui                 i62, 707048              
    38 : add                    i63, i62, 564            
    39 : add                    i17, i16, i63            
    40 : mov                    i18, 43                  
    41 : shl                    i19, i18, 32             
    42 : rv_lui                 i64, 707048              
    43 : add                    i65, i64, 660            
    44 : add                    i20, i19, i65            
    45 : mov                    i21, 43                  
    46 : shl                    i22, i21, 32             
    47 : rv_lui                 i66, 707048              
    48 : add                    i67, i66, 722            
    49 : add                    i23, i22, i67            
    50 : mov                    i31, 1                   
    51 : sub                    i46, i3, i31             
    52 : iverson_eq             i47, i46, 0              
    53 : sub                    i50, i20, i23            
    54 : sub                    i48, 0, i47              
    55 : and                    i49, i48, i50            
    56 : add                    i24, i23, i49            
    57 : mov                    i32, 0                   
    58 : sub                    i51, i3, i32             
    59 : iverson_eq             i52, i51, 0              
    60 : sub                    i55, i17, i24            
    61 : sub                    i53, 0, i52              
    62 : and                    i54, i53, i55            
    63 : add                    i25, i24, i54            
    64 : call_noret             [i14](i0)                
    65 : call                   [i25](i26, i0)           
    66 : mov                    i33, 43                  
    67 : shl                    i34, i33, 32             
    68 : rv_lui                 i68, 707048              
    69 : add                    i69, i68, 496            
    70 : add                    i35, i34, i69            
    71 : call                   [i35](i27, i2, i26)      
    72 : mov                    i2, i27                  
    73 : add                    i0, i0, 56               
    74 : sub                    i1, i1, 1                
    75 : annotation:endwhile    0, 2                     
    76 : mov                    iR, i2                   
    77 : ret                                             
