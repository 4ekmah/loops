big_immediates(i0)
     0 : rv_lui    i13, 1          
     1 : add       i14, i13, 0     
     2 : store.u64 i0, i14         
     3 : add       i1, i0, 8       
     4 : rv_lui    i15, 2          
     5 : add       i16, i15, -1    
     6 : store.u64 i1, i16         
     7 : add       i2, i1, 8       
     8 : rv_lui    i17, 524288     
     9 : xor       i18, i17, -1366 
    10 : store.u64 i2, i18         
    11 : add       i3, i2, 8       
    12 : mov       i19, 1          
    13 : shl       i20, i19, 32    
    14 : mov       i42, 0          
    15 : add       i21, i20, i42   
    16 : store.u64 i3, i21         
    17 : add       i4, i3, 8       
    18 : mov       i22, 2          
    19 : shl       i23, i22, 32    
    20 : mov       i43, -1         
    21 : add       i24, i23, i43   
    22 : store.u64 i4, i24         
    23 : add       i5, i4, 8       
    24 : mov       i25, 1          
    25 : shl       i26, i25, 63    
    26 : rv_lui    i44, 699051     
    27 : add       i45, i44, -1366 
    28 : xor       i27, i26, i45   
    29 : store.u64 i5, i27         
    30 : add       i6, i5, 8       
    31 : rv_lui    i28, 16         
    32 : add       i29, i28, -1    
    33 : store.u64 i6, i29         
    34 : add       i7, i6, 8       
    35 : rv_lui    i30, 16         
    36 : add       i31, i30, 0     
    37 : store.u64 i7, i31         
    38 : add       i8, i7, 8       
    39 : rv_lui    i32, 1048568    
    40 : add       i33, i32, 0     
    41 : store.i64 i8, i33         
    42 : add       i9, i8, 8       
    43 : rv_lui    i34, 1048568    
    44 : add       i35, i34, -1    
    45 : store.i64 i9, i35         
    46 : add       i10, i9, 8      
    47 : rv_lui    i36, 390006     
    48 : add       i37, i36, -1569 
    49 : store.u64 i10, i37        
    50 : add       i11, i10, 8     
    51 : rv_lui    i38, 262236     
    52 : add       i39, i38, -245  
    53 : shl       i40, i39, 32    
    54 : rv_lui    i46, 569669     
    55 : add       i47, i46, 1897  
    56 : add       i41, i40, i47   
    57 : store.u64 i11, i41        
    58 : add       i12, i11, 8     
    59 : ret                       
