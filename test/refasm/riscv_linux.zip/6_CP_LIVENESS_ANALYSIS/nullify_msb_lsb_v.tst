nullify_msb_lsb_v(i0, i1, i2, i3)
     0 : mov                    i5, 0                   
     1 : mov                    i6, 4                   
     2 : mul                    i4, i3, i6              
     3 : rv_vsetvli             i7, 0, 144              
     4 : broadcast.u32          v0, 1                   
     5 : annotation:whilecstart 0                       
     6 : jmp_ge                 i5, i4, __loops_label_2 
     7 : annotation:whilecend                           
     8 : add                    i8, i0, i5              
     9 : vld.u32                v1, i8                  
    10 : rv_vsetvli             i9, 0, 144              
    11 : shr.u32                v10, v1, 1              
    12 : or                     v2, v1, v10             
    13 : shr.u32                v11, v2, 2              
    14 : or                     v3, v2, v11             
    15 : shr.u32                v12, v3, 4              
    16 : or                     v4, v3, v12             
    17 : shr.u32                v13, v4, 8              
    18 : or                     v5, v4, v13             
    19 : shr.u32                v14, v5, 16             
    20 : or                     v6, v5, v14             
    21 : add.u32                v7, v6, v0              
    22 : shr.u32                v8, v7, 1               
    23 : xor                    v9, v8, v1              
    24 : add                    i10, i1, i5             
    25 : vst.u32                i10, v9                 
    26 : sub.u32                v18, v1, v0             
    27 : not                    v17, v18                
    28 : and                    v15, v1, v17            
    29 : xor                    v16, v15, v1            
    30 : add                    i11, i2, i5             
    31 : vst.u32                i11, v16                
    32 : add                    i5, i5, 32              
    33 : annotation:endwhile    0, 2                    
    34 : ret                                            
