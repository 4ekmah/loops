exp_f32(i0, i1, i2)
     0 : vsetvli     a3, zero, e32, m1, tu, ma ; d7 76 00 09  
     1 : lui         a3, 0xc2b0c               ; b7 c6 b0 c2  
     2 : addi        a3, a3, 0xa5              ; 93 86 56 0a  
     3 : vmv.v.x     v0, a3                    ; 57 c0 06 5e  
     4 : lui         a3, 0x42b0c               ; b7 c6 b0 42  
     5 : addi        a3, a3, 0xa5              ; 93 86 56 0a  
     6 : vmv.v.x     v1, a3                    ; d7 c0 06 5e  
     7 : lui         a3, 0x3f000               ; b7 06 00 3f  
     8 : addi        a3, a3, 0                 ; 93 86 06 00  
     9 : vmv.v.x     v2, a3                    ; 57 c1 06 5e  
    10 : lui         a3, 0x3f800               ; b7 06 80 3f  
    11 : addi        a3, a3, 0                 ; 93 86 06 00  
    12 : vmv.v.x     v3, a3                    ; d7 c1 06 5e  
    13 : lui         a3, 0x3fb8b               ; b7 b6 b8 3f  
    14 : addi        a3, a3, -0x5c5            ; 93 86 b6 a3  
    15 : vmv.v.x     v4, a3                    ; 57 c2 06 5e  
    16 : lui         a3, 0xbf318               ; b7 86 31 bf  
    17 : addi        a3, a3, 0                 ; 93 86 06 00  
    18 : vmv.v.x     v5, a3                    ; d7 c2 06 5e  
    19 : lui         a3, 0x395e8               ; b7 86 5e 39  
    20 : addi        a3, a3, 0x83              ; 93 86 36 08  
    21 : vmv.v.x     v6, a3                    ; 57 c3 06 5e  
    22 : lui         a3, 0x39507               ; b7 76 50 39  
    23 : addi        a3, a3, -0x699            ; 93 86 76 96  
    24 : vmv.v.x     v7, a3                    ; d7 c3 06 5e  
    25 : lui         a3, 0x3ab74               ; b7 46 b7 3a  
    26 : addi        a3, a3, 0x3ce             ; 93 86 e6 3c  
    27 : vmv.v.x     v8, a3                    ; 57 c4 06 5e  
    28 : lui         a3, 0x3c089               ; b7 96 08 3c  
    29 : addi        a3, a3, -0x6f8            ; 93 86 86 90  
    30 : vmv.v.x     v9, a3                    ; d7 c4 06 5e  
    31 : lui         a3, 0x3d2ab               ; b7 b6 2a 3d  
    32 : addi        a3, a3, -0x63f            ; 93 86 16 9c  
    33 : vmv.v.x     v10, a3                   ; 57 c5 06 5e  
    34 : lui         a3, 0x3e2ab               ; b7 b6 2a 3e  
    35 : addi        a3, a3, -0x556            ; 93 86 a6 aa  
    36 : vmv.v.x     v11, a3                   ; d7 c5 06 5e  
    37 : lui         a3, 0x3f000               ; b7 06 00 3f  
    38 : addi        a3, a3, 0                 ; 93 86 06 00  
    39 : vmv.v.x     v12, a3                   ; 57 c6 06 5e  
    40 : addi        a3, zero, 0x7f            ; 93 06 f0 07  
    41 : vmv.v.x     v13, a3                   ; d7 c6 06 5e  
    42 : mv          a3, zero                  ; 93 06 00 00  
    43 :             __loops_label_0:          ;              
    44 : mv          a4, zero                  ; 13 07 00 00  
    45 : bge         a4, a2, __loops_label_2   ; 63 58 c7 08  
    46 : add         a4, a1, a3                ; 33 87 d5 00  
    47 : vl1re8.v    v14, (a4)                 ; 07 07 87 02  
    48 : vsetvli     a4, zero, e32, m1, tu, ma ; 57 77 00 09  
    49 : vfmin.vv    v14, v14, v1              ; 57 97 e0 12  
    50 : vfmax.vv    v14, v14, v0              ; 57 17 e0 1a  
    51 : csrrwi      a4, 0x02, 0               ; 73 57 20 00  
    52 : vmv1r.v     v15, v2                   ; d7 37 20 9e  
    53 : vfmacc.vv   v15, v14, v4              ; d7 17 47 b2  
    54 : csrrwi      a4, 0x02, 0x02            ; 73 57 21 00  
    55 : vfcvt.x.f.v v15, v15                  ; d7 97 f0 4a  
    56 : csrrwi      a4, 0x02, 0               ; 73 57 20 00  
    57 : vfcvt.f.x.v v16, v15                  ; 57 98 f1 4a  
    58 : vfmacc.vv   v14, v16, v5              ; 57 17 58 b2  
    59 : vfmacc.vv   v14, v16, v6              ; 57 17 68 b2  
    60 : vmv1r.v     v16, v8                   ; 57 38 80 9e  
    61 : vfmacc.vv   v16, v14, v7              ; 57 18 77 b2  
    62 : vmv1r.v     v17, v9                   ; d7 38 90 9e  
    63 : vfmacc.vv   v17, v16, v14             ; d7 18 e8 b2  
    64 : vmv1r.v     v16, v10                  ; 57 38 a0 9e  
    65 : vfmacc.vv   v16, v17, v14             ; 57 98 e8 b2  
    66 : vmv1r.v     v17, v11                  ; d7 38 b0 9e  
    67 : vfmacc.vv   v17, v16, v14             ; d7 18 e8 b2  
    68 : vmv1r.v     v16, v12                  ; 57 38 c0 9e  
    69 : vfmacc.vv   v16, v17, v14             ; 57 98 e8 b2  
    70 : vfmul.vv    v17, v14, v14             ; d7 18 e7 92  
    71 : vfmacc.vv   v14, v16, v17             ; 57 17 18 b3  
    72 : vfadd.vv    v14, v14, v3              ; 57 97 e1 02  
    73 : vadd.vv     v15, v15, v13             ; d7 87 f6 02  
    74 : vsll.vi     v15, v15, 0x17            ; d7 b7 fb 96  
    75 : vfmul.vv    v14, v14, v15             ; 57 97 e7 92  
    76 : add         a4, a0, a3                ; 33 07 d5 00  
    77 : vs1r.v      v14, (a4)                 ; 27 07 87 02  
    78 : addi        a3, a3, 0x20              ; 93 86 06 02  
    79 : addi        a2, a2, -0x08             ; 13 06 86 ff  
    80 : j           __loops_label_0           ; 6f f0 1f f7  
    81 :             __loops_label_2:          ;              
    82 : ret                                   ; 67 80 00 00  
