sibling_loops(i0, i1, i2)
     0 : addi sp, sp, -0x40           ; 13 01 01 fc  
     1 : sd   s8, 0x30(sp)            ; 23 38 81 03  
     2 : sd   s9, 0x38(sp)            ; 23 3c 91 03  
     3 : mv   a3, zero                ; 93 06 00 00  
     4 : mv   s9, zero                ; 93 0c 00 00  
     5 : sd   s9, 0x20(sp)            ; 23 30 91 03  
     6 :      __loops_label_0:        ;              
     7 : bge  a3, a1, __loops_label_2 ; 63 d0 b6 02  
     8 : add  s8, a0, a3              ; 33 0c d5 00  
     9 : lw   s8, 0(s8)               ; 03 2c 0c 00  
    10 : ld   s9, 0x20(sp)            ; 83 3c 01 02  
    11 : add  s9, s9, s8              ; b3 8c 8c 01  
    12 : sd   s9, 0x20(sp)            ; 23 30 91 03  
    13 : addi a3, a3, 0x04            ; 93 86 46 00  
    14 : j    __loops_label_0         ; 6f f0 5f fe  
    15 :      __loops_label_2:        ;              
    16 : mv   a0, zero                ; 13 05 00 00  
    17 : sd   a0, 0x28(sp)            ; 23 34 a1 02  
    18 :      __loops_label_3:        ;              
    19 : mv   s8, zero                ; 13 0c 00 00  
    20 : bge  s8, a3, __loops_label_5 ; 63 5c dc 00  
    21 : ld   s9, 0x28(sp)            ; 83 3c 81 02  
    22 : addi s9, s9, 0x01            ; 93 8c 1c 00  
    23 : sd   s9, 0x28(sp)            ; 23 34 91 03  
    24 : addi a3, a3, -0x04           ; 93 86 c6 ff  
    25 : j    __loops_label_3         ; 6f f0 9f fe  
    26 :      __loops_label_5:        ;              
    27 : ld   a0, 0x28(sp)            ; 03 35 81 02  
    28 : ld   s9, 0x20(sp)            ; 83 3c 01 02  
    29 : sw   s9, 0(a2)               ; 23 20 96 01  
    30 : sw   a0, 0x04(a2)            ; 23 22 a6 00  
    31 : mv   a0, zero                ; 13 05 00 00  
    32 : ld   s8, 0x30(sp)            ; 03 3c 01 03  
    33 : ld   s9, 0x38(sp)            ; 83 3c 81 03  
    34 : addi sp, sp, 0x40            ; 13 01 01 04  
    35 : ret                          ; 67 80 00 00  
