instruction_set_test()
     0 : mv               zero, zero                   ; 13 00 00 00  
     1 : mv               t0, zero                     ; 93 02 00 00  
     2 : mv               t6, zero                     ; 93 0f 00 00  
     3 : mv               zero, t6                     ; 13 80 0f 00  
     4 : mv               zero, zero                   ; 13 00 00 00  
     5 : mv               t6, zero                     ; 93 0f 00 00  
     6 : addi             zero, zero, 0x01             ; 13 00 10 00  
     7 : addi             t6, zero, 0x01               ; 93 0f 10 00  
     8 : addi             zero, zero, 0x7ff            ; 13 00 f0 7f  
     9 : addi             zero, zero, -0x800           ; 13 00 00 80  
    10 : lui              zero, 0                      ; 37 00 00 00  
    11 : lui              t6, 0                        ; b7 0f 00 00  
    12 : lui              zero, 0xfffff                ; 37 f0 ff ff  
    13 : add              zero, zero, zero             ; 33 00 00 00  
    14 : add              t6, zero, zero               ; b3 0f 00 00  
    15 : add              zero, t6, zero               ; 33 80 0f 00  
    16 : add              zero, zero, t6               ; 33 00 f0 01  
    17 : addi             zero, zero, 0                ; 13 00 00 00  
    18 : addi             t6, zero, 0                  ; 93 0f 00 00  
    19 : addi             zero, t6, 0                  ; 13 80 0f 00  
    20 : addi             zero, zero, 0x7ff            ; 13 00 f0 7f  
    21 : addi             zero, zero, -0x800           ; 13 00 00 80  
    22 : sub              zero, zero, zero             ; 33 00 00 40  
    23 : sub              t6, zero, zero               ; b3 0f 00 40  
    24 : sub              zero, t6, zero               ; 33 80 0f 40  
    25 : sub              zero, zero, t6               ; 33 00 f0 41  
    26 : addi             zero, zero, 0                ; 13 00 00 00  
    27 : addi             t6, zero, 0                  ; 93 0f 00 00  
    28 : addi             zero, t6, 0                  ; 13 80 0f 00  
    29 : addi             zero, zero, -0x800           ; 13 00 00 80  
    30 : addi             zero, zero, 0x7ff            ; 13 00 f0 7f  
    31 : neg              zero, zero                   ; 33 00 00 40  
    32 : neg              t6, zero                     ; b3 0f 00 40  
    33 : neg              zero, t6                     ; 33 00 f0 41  
    34 : sll              zero, zero, zero             ; 33 10 00 00  
    35 : sll              t6, zero, zero               ; b3 1f 00 00  
    36 : sll              zero, t6, zero               ; 33 90 0f 00  
    37 : sll              zero, zero, t6               ; 33 10 f0 01  
    38 : slli             zero, zero, 0                ; 13 10 00 00  
    39 : slli             t6, zero, 0                  ; 93 1f 00 00  
    40 : slli             zero, t6, 0                  ; 13 90 0f 00  
    41 : slli             zero, zero, 0x3f             ; 13 10 f0 03  
    42 : srl              zero, zero, zero             ; 33 50 00 00  
    43 : srl              t6, zero, zero               ; b3 5f 00 00  
    44 : srl              zero, t6, zero               ; 33 d0 0f 00  
    45 : srl              zero, zero, t6               ; 33 50 f0 01  
    46 : srli             zero, zero, 0                ; 13 50 00 00  
    47 : srli             t6, zero, 0                  ; 93 5f 00 00  
    48 : srli             zero, t6, 0                  ; 13 d0 0f 00  
    49 : srli             zero, zero, 0x3f             ; 13 50 f0 03  
    50 : sra              zero, zero, zero             ; 33 50 00 40  
    51 : sra              t6, zero, zero               ; b3 5f 00 40  
    52 : sra              zero, t6, zero               ; 33 d0 0f 40  
    53 : sra              zero, zero, t6               ; 33 50 f0 41  
    54 : srai             zero, zero, 0                ; 13 50 00 40  
    55 : srai             t6, zero, 0                  ; 93 5f 00 40  
    56 : srai             zero, t6, 0                  ; 13 d0 0f 40  
    57 : srai             zero, zero, 0x3f             ; 13 50 f0 43  
    58 : mul              zero, zero, zero             ; 33 00 00 02  
    59 : mul              t6, zero, zero               ; b3 0f 00 02  
    60 : mul              zero, t6, zero               ; 33 80 0f 02  
    61 : mul              zero, zero, t6               ; 33 00 f0 03  
    62 : div              zero, zero, zero             ; 33 40 00 02  
    63 : div              t6, zero, zero               ; b3 4f 00 02  
    64 : div              zero, t6, zero               ; 33 c0 0f 02  
    65 : div              zero, zero, t6               ; 33 40 f0 03  
    66 : rem              zero, zero, zero             ; 33 60 00 02  
    67 : rem              t6, zero, zero               ; b3 6f 00 02  
    68 : rem              zero, t6, zero               ; 33 e0 0f 02  
    69 : rem              zero, zero, t6               ; 33 60 f0 03  
    70 : xor              zero, zero, zero             ; 33 40 00 00  
    71 : xor              t6, zero, zero               ; b3 4f 00 00  
    72 : xor              zero, t6, zero               ; 33 c0 0f 00  
    73 : xor              zero, zero, t6               ; 33 40 f0 01  
    74 : xori             zero, zero, 0                ; 13 40 00 00  
    75 : xori             t6, zero, 0                  ; 93 4f 00 00  
    76 : xori             zero, t6, 0                  ; 13 c0 0f 00  
    77 : xori             zero, zero, 0x7ff            ; 13 40 f0 7f  
    78 : xori             zero, zero, -0x800           ; 13 40 00 80  
    79 : or               zero, zero, zero             ; 33 60 00 00  
    80 : or               t6, zero, zero               ; b3 6f 00 00  
    81 : or               zero, t6, zero               ; 33 e0 0f 00  
    82 : or               zero, zero, t6               ; 33 60 f0 01  
    83 : ori              zero, zero, 0                ; 13 60 00 00  
    84 : ori              t6, zero, 0                  ; 93 6f 00 00  
    85 : ori              zero, t6, 0                  ; 13 e0 0f 00  
    86 : ori              zero, zero, 0x7ff            ; 13 60 f0 7f  
    87 : ori              zero, zero, -0x800           ; 13 60 00 80  
    88 : and              zero, zero, zero             ; 33 70 00 00  
    89 : and              t6, zero, zero               ; b3 7f 00 00  
    90 : and              zero, t6, zero               ; 33 f0 0f 00  
    91 : and              zero, zero, t6               ; 33 70 f0 01  
    92 : andi             zero, zero, 0                ; 13 70 00 00  
    93 : andi             t6, zero, 0                  ; 93 7f 00 00  
    94 : andi             zero, t6, 0                  ; 13 f0 0f 00  
    95 : andi             zero, zero, 0x7ff            ; 13 70 f0 7f  
    96 : andi             zero, zero, -0x800           ; 13 70 00 80  
    97 : not              zero, zero                   ; 13 40 f0 ff  
    98 : not              t6, zero                     ; 93 4f f0 ff  
    99 : not              zero, t6                     ; 13 c0 ff ff  
   100 : lb               zero, 0(zero)                ; 03 00 00 00  
   101 : lb               t6, 0(zero)                  ; 83 0f 00 00  
   102 : lb               zero, 0(t6)                  ; 03 80 0f 00  
   103 : lb               zero, 0(zero)                ; 03 00 00 00  
   104 : lb               t6, 0(zero)                  ; 83 0f 00 00  
   105 : lb               zero, 0(t6)                  ; 03 80 0f 00  
   106 : lb               zero, 0x7ff(zero)            ; 03 00 f0 7f  
   107 : lb               zero, -0x800(zero)           ; 03 00 00 80  
   108 : lbu              zero, 0(zero)                ; 03 40 00 00  
   109 : lbu              t6, 0(zero)                  ; 83 4f 00 00  
   110 : lbu              zero, 0(t6)                  ; 03 c0 0f 00  
   111 : lbu              zero, 0(zero)                ; 03 40 00 00  
   112 : lbu              t6, 0(zero)                  ; 83 4f 00 00  
   113 : lbu              zero, 0(t6)                  ; 03 c0 0f 00  
   114 : lbu              zero, 0x7ff(zero)            ; 03 40 f0 7f  
   115 : lbu              zero, -0x800(zero)           ; 03 40 00 80  
   116 : lh               zero, 0(zero)                ; 03 10 00 00  
   117 : lh               t6, 0(zero)                  ; 83 1f 00 00  
   118 : lh               zero, 0(t6)                  ; 03 90 0f 00  
   119 : lh               zero, 0(zero)                ; 03 10 00 00  
   120 : lh               t6, 0(zero)                  ; 83 1f 00 00  
   121 : lh               zero, 0(t6)                  ; 03 90 0f 00  
   122 : lh               zero, 0x7ff(zero)            ; 03 10 f0 7f  
   123 : lh               zero, -0x800(zero)           ; 03 10 00 80  
   124 : lhu              zero, 0(zero)                ; 03 50 00 00  
   125 : lhu              t6, 0(zero)                  ; 83 5f 00 00  
   126 : lhu              zero, 0(t6)                  ; 03 d0 0f 00  
   127 : lhu              zero, 0(zero)                ; 03 50 00 00  
   128 : lhu              t6, 0(zero)                  ; 83 5f 00 00  
   129 : lhu              zero, 0(t6)                  ; 03 d0 0f 00  
   130 : lhu              zero, 0x7ff(zero)            ; 03 50 f0 7f  
   131 : lhu              zero, -0x800(zero)           ; 03 50 00 80  
   132 : lw               zero, 0(zero)                ; 03 20 00 00  
   133 : lw               t6, 0(zero)                  ; 83 2f 00 00  
   134 : lw               zero, 0(t6)                  ; 03 a0 0f 00  
   135 : lw               zero, 0(zero)                ; 03 20 00 00  
   136 : lw               t6, 0(zero)                  ; 83 2f 00 00  
   137 : lw               zero, 0(t6)                  ; 03 a0 0f 00  
   138 : lw               zero, 0x7ff(zero)            ; 03 20 f0 7f  
   139 : lw               zero, -0x800(zero)           ; 03 20 00 80  
   140 : lwu              zero, 0(zero)                ; 03 60 00 00  
   141 : lwu              t6, 0(zero)                  ; 83 6f 00 00  
   142 : lwu              zero, 0(t6)                  ; 03 e0 0f 00  
   143 : lwu              zero, 0(zero)                ; 03 60 00 00  
   144 : lwu              t6, 0(zero)                  ; 83 6f 00 00  
   145 : lwu              zero, 0(t6)                  ; 03 e0 0f 00  
   146 : lwu              zero, 0x7ff(zero)            ; 03 60 f0 7f  
   147 : lwu              zero, -0x800(zero)           ; 03 60 00 80  
   148 : ld               zero, 0(zero)                ; 03 30 00 00  
   149 : ld               t6, 0(zero)                  ; 83 3f 00 00  
   150 : ld               zero, 0(t6)                  ; 03 b0 0f 00  
   151 : ld               zero, 0(zero)                ; 03 30 00 00  
   152 : ld               t6, 0(zero)                  ; 83 3f 00 00  
   153 : ld               zero, 0(t6)                  ; 03 b0 0f 00  
   154 : ld               zero, 0x7ff(zero)            ; 03 30 f0 7f  
   155 : ld               zero, -0x800(zero)           ; 03 30 00 80  
   156 : sb               zero, 0(zero)                ; 23 00 00 00  
   157 : sb               zero, 0(t6)                  ; 23 80 0f 00  
   158 : sb               t6, 0(zero)                  ; 23 00 f0 01  
   159 : sb               zero, 0(zero)                ; 23 00 00 00  
   160 : sb               zero, 0(t6)                  ; 23 80 0f 00  
   161 : sb               t6, 0(zero)                  ; 23 00 f0 01  
   162 : sb               zero, 0x7ff(zero)            ; a3 0f 00 7e  
   163 : sb               zero, -0x800(zero)           ; 23 00 00 80  
   164 : sh               zero, 0(zero)                ; 23 10 00 00  
   165 : sh               zero, 0(t6)                  ; 23 90 0f 00  
   166 : sh               t6, 0(zero)                  ; 23 10 f0 01  
   167 : sh               zero, 0(zero)                ; 23 10 00 00  
   168 : sh               zero, 0(t6)                  ; 23 90 0f 00  
   169 : sh               t6, 0(zero)                  ; 23 10 f0 01  
   170 : sh               zero, 0x7ff(zero)            ; a3 1f 00 7e  
   171 : sh               zero, -0x800(zero)           ; 23 10 00 80  
   172 : sw               zero, 0(zero)                ; 23 20 00 00  
   173 : sw               zero, 0(t6)                  ; 23 a0 0f 00  
   174 : sw               t6, 0(zero)                  ; 23 20 f0 01  
   175 : sw               zero, 0(zero)                ; 23 20 00 00  
   176 : sw               zero, 0(t6)                  ; 23 a0 0f 00  
   177 : sw               t6, 0(zero)                  ; 23 20 f0 01  
   178 : sw               zero, 0x7ff(zero)            ; a3 2f 00 7e  
   179 : sw               zero, -0x800(zero)           ; 23 20 00 80  
   180 : sd               zero, 0(zero)                ; 23 30 00 00  
   181 : sd               zero, 0(t6)                  ; 23 b0 0f 00  
   182 : sd               t6, 0(zero)                  ; 23 30 f0 01  
   183 : sd               zero, 0(zero)                ; 23 30 00 00  
   184 : sd               zero, 0(t6)                  ; 23 b0 0f 00  
   185 : sd               t6, 0(zero)                  ; 23 30 f0 01  
   186 : sd               zero, 0x7ff(zero)            ; a3 3f 00 7e  
   187 : sd               zero, -0x800(zero)           ; 23 30 00 80  
   188 : slt              zero, zero, zero             ; 33 20 00 00  
   189 : slt              t6, zero, zero               ; b3 2f 00 00  
   190 : slt              zero, t6, zero               ; 33 a0 0f 00  
   191 : slt              zero, zero, t6               ; 33 20 f0 01  
   192 : sltu             zero, zero, zero             ; 33 30 00 00  
   193 : sltu             t6, zero, zero               ; b3 3f 00 00  
   194 : sltu             zero, zero, t6               ; 33 30 f0 01  
   195 : sltu             zero, t6, zero               ; 33 b0 0f 00  
   196 : seqz             zero, zero                   ; 13 30 10 00  
   197 : seqz             t6, zero                     ; 93 3f 10 00  
   198 : seqz             zero, t6                     ; 13 b0 1f 00  
   199 : snez             zero, zero                   ; 33 30 00 00  
   200 : snez             t6, zero                     ; b3 3f 00 00  
   201 : snez             zero, t6                     ; 33 30 f0 01  
   202 : jalr             zero                         ; e7 00 00 00  
   203 : jalr             t6                           ; e7 80 0f 00  
   204 : vsetvli          zero, zero, e8, m1, tu, mu   ; 57 70 00 00  
   205 : vsetvli          t6, zero, e8, m1, tu, mu     ; d7 7f 00 00  
   206 : vsetvli          zero, t6, e8, m1, tu, mu     ; 57 f0 0f 00  
   207 : vsetvli          zero, zero, e16, m4, ta, mu  ; 57 70 a0 04  
   208 : vsetvli          zero, zero, e32, m1, tu, ma  ; 57 70 00 09  
   209 : vsetvli          zero, zero, e64, mf8, tu, ma ; 57 70 d0 09  
   210 : vsetvli          zero, zero, 0x7ff            ; 57 70 f0 7f  
   211 : vl1re8.v         v0, (zero)                   ; 07 00 80 02  
   212 : vl1re8.v         v31, (zero)                  ; 87 0f 80 02  
   213 : vl1re8.v         v0, (t6)                     ; 07 80 8f 02  
   214 : vl1re8.v         v0, (zero)                   ; 07 00 80 02  
   215 : vl1re8.v         v31, (zero)                  ; 87 0f 80 02  
   216 : vl1re8.v         v0, (t6)                     ; 07 80 8f 02  
   217 : vl1re8.v         v0, (zero)                   ; 07 00 80 02  
   218 : vl1re8.v         v31, (zero)                  ; 87 0f 80 02  
   219 : vl1re8.v         v0, (t6)                     ; 07 80 8f 02  
   220 : vl1re8.v         v0, (zero)                   ; 07 00 80 02  
   221 : vl1re8.v         v31, (zero)                  ; 87 0f 80 02  
   222 : vl1re8.v         v0, (t6)                     ; 07 80 8f 02  
   223 : vs1r.v           v0, (zero)                   ; 27 00 80 02  
   224 : vs1r.v           v31, (zero)                  ; a7 0f 80 02  
   225 : vs1r.v           v0, (t6)                     ; 27 80 8f 02  
   226 : vs1r.v           v0, (zero)                   ; 27 00 80 02  
   227 : vs1r.v           v31, (zero)                  ; a7 0f 80 02  
   228 : vs1r.v           v0, (t6)                     ; 27 80 8f 02  
   229 : vs1r.v           v0, (zero)                   ; 27 00 80 02  
   230 : vs1r.v           v31, (zero)                  ; a7 0f 80 02  
   231 : vs1r.v           v0, (t6)                     ; 27 80 8f 02  
   232 : vs1r.v           v0, (zero)                   ; 27 00 80 02  
   233 : vs1r.v           v31, (zero)                  ; a7 0f 80 02  
   234 : vs1r.v           v0, (t6)                     ; 27 80 8f 02  
   235 : vlseg2e8.v       v0, (zero)                   ; 07 00 00 22  
   236 : vlseg2e8.v       v30, (zero)                  ; 07 0f 00 22  
   237 : vlseg2e8.v       v0, (t6)                     ; 07 80 0f 22  
   238 : vlseg2e16.v      v0, (zero)                   ; 07 50 00 22  
   239 : vlseg2e16.v      v30, (zero)                  ; 07 5f 00 22  
   240 : vlseg2e16.v      v0, (t6)                     ; 07 d0 0f 22  
   241 : vlseg2e32.v      v0, (zero)                   ; 07 60 00 22  
   242 : vlseg2e32.v      v30, (zero)                  ; 07 6f 00 22  
   243 : vlseg2e32.v      v0, (t6)                     ; 07 e0 0f 22  
   244 : vlseg2e64.v      v0, (zero)                   ; 07 70 00 22  
   245 : vlseg2e64.v      v30, (zero)                  ; 07 7f 00 22  
   246 : vlseg2e64.v      v0, (t6)                     ; 07 f0 0f 22  
   247 : vmv1r.v          v0, v0                       ; 57 30 00 9e  
   248 : vmv1r.v          v31, v0                      ; d7 3f 00 9e  
   249 : vmv1r.v          v0, v31                      ; 57 30 f0 9f  
   250 : vmv.v.x          v0, zero                     ; 57 40 00 5e  
   251 : vmv.v.x          v31, zero                    ; d7 4f 00 5e  
   252 : vmv.v.x          v0, t6                       ; 57 c0 0f 5e  
   253 : vmv.v.i          v0, 0                        ; 57 30 00 5e  
   254 : vmv.v.i          v31, 0                       ; d7 3f 00 5e  
   255 : vmv.v.i          v0, 0x0f                     ; 57 b0 07 5e  
   256 : vrgather.vx      v0, v0, zero                 ; 57 40 00 32  
   257 : vrgather.vx      v31, v0, zero                ; d7 4f 00 32  
   258 : vrgather.vx      v0, v31, zero                ; 57 40 f0 33  
   259 : vrgather.vx      v0, v0, t6                   ; 57 c0 0f 32  
   260 : vrgather.vi      v0, v0, 0                    ; 57 30 00 32  
   261 : vrgather.vi      v31, v0, 0                   ; d7 3f 00 32  
   262 : vrgather.vi      v0, v31, 0                   ; 57 30 f0 33  
   263 : vrgather.vi      v0, v0, 0x1f                 ; 57 b0 0f 32  
   264 : vslideup.vx      v0, v0, zero                 ; 57 40 00 3a  
   265 : vslideup.vx      v31, v0, zero                ; d7 4f 00 3a  
   266 : vslideup.vx      v0, v31, zero                ; 57 40 f0 3b  
   267 : vslideup.vx      v0, v0, t6                   ; 57 c0 0f 3a  
   268 : vslideup.vi      v0, v0, 0                    ; 57 30 00 3a  
   269 : vslideup.vi      v31, v0, 0                   ; d7 3f 00 3a  
   270 : vslideup.vi      v0, v31, 0                   ; 57 30 f0 3b  
   271 : vslideup.vi      v0, v0, 0x1f                 ; 57 b0 0f 3a  
   272 : vslidedown.vx    v0, v0, zero                 ; 57 40 00 3e  
   273 : vslidedown.vx    v31, v0, zero                ; d7 4f 00 3e  
   274 : vslidedown.vx    v0, v31, zero                ; 57 40 f0 3f  
   275 : vslidedown.vx    v0, v0, t6                   ; 57 c0 0f 3e  
   276 : vslidedown.vi    v0, v0, 0                    ; 57 30 00 3e  
   277 : vslidedown.vi    v31, v0, 0                   ; d7 3f 00 3e  
   278 : vslidedown.vi    v0, v31, 0                   ; 57 30 f0 3f  
   279 : vslidedown.vi    v0, v0, 0x1f                 ; 57 b0 0f 3e  
   280 : vmv.x.s          zero, v0                     ; 57 20 00 42  
   281 : vmv.x.s          t6, v0                       ; d7 2f 00 42  
   282 : vmv.x.s          zero, v31                    ; 57 20 f0 43  
   283 : vmv.s.x          v0, zero                     ; 57 60 00 42  
   284 : vmv.s.x          v31, zero                    ; d7 6f 00 42  
   285 : vmv.s.x          v0, t6                       ; 57 e0 0f 42  
   286 : vmerge.vvm       v0, v0, v0, v0               ; 57 00 00 5c  
   287 : vmerge.vvm       v31, v0, v0, v0              ; d7 0f 00 5c  
   288 : vmerge.vvm       v0, v0, v31, v0              ; 57 80 0f 5c  
   289 : vmerge.vvm       v0, v31, v0, v0              ; 57 00 f0 5d  
   290 : vmerge.vxm       v0, v0, zero, v0             ; 57 40 00 5c  
   291 : vmerge.vxm       v31, v0, zero, v0            ; d7 4f 00 5c  
   292 : vmerge.vxm       v0, v31, zero, v0            ; 57 40 f0 5d  
   293 : vmerge.vxm       v0, v0, t6, v0               ; 57 c0 0f 5c  
   294 : vmerge.vim       v0, v0, 0, v0                ; 57 30 00 5c  
   295 : vmerge.vim       v31, v0, 0, v0               ; d7 3f 00 5c  
   296 : vmerge.vim       v0, v31, 0, v0               ; 57 30 f0 5d  
   297 : vmerge.vim       v0, v0, 0x0f, v0             ; 57 b0 07 5c  
   298 : vmsne.vi         v0, v0, 0                    ; 57 30 00 66  
   299 : vmsne.vi         v31, v0, 0                   ; d7 3f 00 66  
   300 : vmsne.vi         v0, v31, 0                   ; 57 30 f0 67  
   301 : vmsne.vi         v0, v0, 0x0f                 ; 57 b0 07 66  
   302 : vmseq.vi         v0, v0, 0                    ; 57 30 00 62  
   303 : vmseq.vi         v31, v0, 0                   ; d7 3f 00 62  
   304 : vmseq.vi         v0, v31, 0                   ; 57 30 f0 63  
   305 : vmseq.vi         v0, v0, 0x0f                 ; 57 b0 07 62  
   306 : vmsle.vi         v0, v0, 0x0f                 ; 57 b0 07 76  
   307 : vmsle.vi         v31, v0, 0x0f                ; d7 bf 07 76  
   308 : vmsle.vi         v0, v31, 0x0f                ; 57 b0 f7 77  
   309 : vmsle.vi         v0, v0, 0x0f                 ; 57 b0 07 76  
   310 : vmsle.vi         v31, v0, 0x0f                ; d7 bf 07 76  
   311 : vmsle.vi         v0, v31, 0x0f                ; 57 b0 f7 77  
   312 : vmsleu.vi        v0, v0, 0x0f                 ; 57 b0 07 72  
   313 : vmsleu.vi        v0, v0, 0x0f                 ; 57 b0 07 72  
   314 : vmsne.vv         v0, v0, v0                   ; 57 00 00 66  
   315 : vmseq.vv         v0, v0, v0                   ; 57 00 00 62  
   316 : vmseq.vv         v31, v0, v0                  ; d7 0f 00 62  
   317 : vmseq.vv         v0, v31, v0                  ; 57 00 f0 63  
   318 : vmseq.vv         v0, v0, v31                  ; 57 80 0f 62  
   319 : vmsne.vv         v0, v0, v0                   ; 57 00 00 66  
   320 : vmsne.vv         v31, v0, v0                  ; d7 0f 00 66  
   321 : vmsne.vv         v0, v31, v0                  ; 57 00 f0 67  
   322 : vmsne.vv         v0, v0, v31                  ; 57 80 0f 66  
   323 : vmslt.vv         v0, v0, v0                   ; 57 00 00 6e  
   324 : vmslt.vv         v31, v0, v0                  ; d7 0f 00 6e  
   325 : vmslt.vv         v0, v31, v0                  ; 57 00 f0 6f  
   326 : vmslt.vv         v0, v0, v31                  ; 57 80 0f 6e  
   327 : vmsltu.vv        v0, v0, v0                   ; 57 00 00 6a  
   328 : vmsltu.vv        v31, v0, v0                  ; d7 0f 00 6a  
   329 : vmsltu.vv        v0, v31, v0                  ; 57 00 f0 6b  
   330 : vmsltu.vv        v0, v0, v31                  ; 57 80 0f 6a  
   331 : vmsle.vv         v0, v0, v0                   ; 57 00 00 76  
   332 : vmsle.vv         v31, v0, v0                  ; d7 0f 00 76  
   333 : vmsle.vv         v0, v31, v0                  ; 57 00 f0 77  
   334 : vmsle.vv         v0, v0, v31                  ; 57 80 0f 76  
   335 : vmsleu.vv        v0, v0, v0                   ; 57 00 00 72  
   336 : vmsleu.vv        v31, v0, v0                  ; d7 0f 00 72  
   337 : vmsleu.vv        v0, v31, v0                  ; 57 00 f0 73  
   338 : vmsleu.vv        v0, v0, v31                  ; 57 80 0f 72  
   339 : vmfeq.vv         v0, v0, v0                   ; 57 10 00 62  
   340 : vmfeq.vv         v31, v0, v0                  ; d7 1f 00 62  
   341 : vmfeq.vv         v0, v31, v0                  ; 57 10 f0 63  
   342 : vmfeq.vv         v0, v0, v31                  ; 57 90 0f 62  
   343 : vmfne.vv         v0, v0, v0                   ; 57 10 00 72  
   344 : vmfne.vv         v31, v0, v0                  ; d7 1f 00 72  
   345 : vmfne.vv         v0, v31, v0                  ; 57 10 f0 73  
   346 : vmfne.vv         v0, v0, v31                  ; 57 90 0f 72  
   347 : vmflt.vv         v0, v0, v0                   ; 57 10 00 6e  
   348 : vmflt.vv         v31, v0, v0                  ; d7 1f 00 6e  
   349 : vmflt.vv         v0, v31, v0                  ; 57 10 f0 6f  
   350 : vmflt.vv         v0, v0, v31                  ; 57 90 0f 6e  
   351 : vmfle.vv         v0, v0, v0                   ; 57 10 00 66  
   352 : vmfle.vv         v31, v0, v0                  ; d7 1f 00 66  
   353 : vmfle.vv         v0, v31, v0                  ; 57 10 f0 67  
   354 : vmfle.vv         v0, v0, v31                  ; 57 90 0f 66  
   355 : vmslt.vv         v0, v0, v0                   ; 57 00 00 6e  
   356 : vmslt.vv         v31, v0, v0                  ; d7 0f 00 6e  
   357 : vmslt.vv         v0, v0, v31                  ; 57 80 0f 6e  
   358 : vmslt.vv         v0, v31, v0                  ; 57 00 f0 6f  
   359 : vmsltu.vv        v0, v0, v0                   ; 57 00 00 6a  
   360 : vmsltu.vv        v0, v0, v31                  ; 57 80 0f 6a  
   361 : vmsltu.vv        v0, v31, v0                  ; 57 00 f0 6b  
   362 : vmflt.vv         v0, v0, v0                   ; 57 10 00 6e  
   363 : vmflt.vv         v0, v31, v0                  ; 57 10 f0 6f  
   364 : vmsle.vv         v0, v0, v0                   ; 57 00 00 76  
   365 : vmsle.vv         v31, v0, v0                  ; d7 0f 00 76  
   366 : vmsle.vv         v0, v0, v31                  ; 57 80 0f 76  
   367 : vmsle.vv         v0, v31, v0                  ; 57 00 f0 77  
   368 : vmsleu.vv        v0, v0, v0                   ; 57 00 00 72  
   369 : vmsleu.vv        v0, v0, v31                  ; 57 80 0f 72  
   370 : vmsleu.vv        v0, v31, v0                  ; 57 00 f0 73  
   371 : vmfle.vv         v0, v0, v0                   ; 57 10 00 66  
   372 : vmfle.vv         v0, v31, v0                  ; 57 10 f0 67  
   373 : vadd.vv          v0, v0, v0                   ; 57 00 00 02  
   374 : vadd.vv          v31, v0, v0                  ; d7 0f 00 02  
   375 : vadd.vv          v0, v31, v0                  ; 57 00 f0 03  
   376 : vadd.vv          v0, v0, v31                  ; 57 80 0f 02  
   377 : vsub.vv          v0, v0, v0                   ; 57 00 00 0a  
   378 : vsub.vv          v31, v0, v0                  ; d7 0f 00 0a  
   379 : vsub.vv          v0, v31, v0                  ; 57 00 f0 0b  
   380 : vsub.vv          v0, v0, v31                  ; 57 80 0f 0a  
   381 : vrsub.vx         v0, v0, zero                 ; 57 40 00 0e  
   382 : vrsub.vx         v31, v0, zero                ; d7 4f 00 0e  
   383 : vrsub.vx         v0, v0, t6                   ; 57 c0 0f 0e  
   384 : vrsub.vx         v0, v31, zero                ; 57 40 f0 0f  
   385 : vmul.vv          v0, v0, v0                   ; 57 20 00 96  
   386 : vmul.vv          v31, v0, v0                  ; d7 2f 00 96  
   387 : vmul.vv          v0, v31, v0                  ; 57 20 f0 97  
   388 : vmul.vv          v0, v0, v31                  ; 57 a0 0f 96  
   389 : vmin.vv          v0, v0, v0                   ; 57 00 00 16  
   390 : vmin.vv          v31, v0, v0                  ; d7 0f 00 16  
   391 : vmin.vv          v0, v31, v0                  ; 57 00 f0 17  
   392 : vmin.vv          v0, v0, v31                  ; 57 80 0f 16  
   393 : vminu.vv         v0, v0, v0                   ; 57 00 00 12  
   394 : vminu.vv         v31, v0, v0                  ; d7 0f 00 12  
   395 : vminu.vv         v0, v31, v0                  ; 57 00 f0 13  
   396 : vminu.vv         v0, v0, v31                  ; 57 80 0f 12  
   397 : vmax.vv          v0, v0, v0                   ; 57 00 00 1e  
   398 : vmax.vv          v31, v0, v0                  ; d7 0f 00 1e  
   399 : vmax.vv          v0, v31, v0                  ; 57 00 f0 1f  
   400 : vmax.vv          v0, v0, v31                  ; 57 80 0f 1e  
   401 : vmaxu.vv         v0, v0, v0                   ; 57 00 00 1a  
   402 : vmaxu.vv         v31, v0, v0                  ; d7 0f 00 1a  
   403 : vmaxu.vv         v0, v31, v0                  ; 57 00 f0 1b  
   404 : vmaxu.vv         v0, v0, v31                  ; 57 80 0f 1a  
   405 : vsll.vv          v0, v0, v0                   ; 57 00 00 96  
   406 : vsll.vv          v31, v0, v0                  ; d7 0f 00 96  
   407 : vsll.vv          v0, v31, v0                  ; 57 00 f0 97  
   408 : vsll.vv          v0, v0, v31                  ; 57 80 0f 96  
   409 : vsll.vx          v0, v0, zero                 ; 57 40 00 96  
   410 : vsll.vx          v31, v0, zero                ; d7 4f 00 96  
   411 : vsll.vx          v0, v31, zero                ; 57 40 f0 97  
   412 : vsll.vx          v0, v0, t6                   ; 57 c0 0f 96  
   413 : vsll.vi          v0, v0, 0                    ; 57 30 00 96  
   414 : vsll.vi          v31, v0, 0                   ; d7 3f 00 96  
   415 : vsll.vi          v0, v31, 0                   ; 57 30 f0 97  
   416 : vsll.vi          v0, v0, 0x1f                 ; 57 b0 0f 96  
   417 : vsrl.vv          v0, v0, v0                   ; 57 00 00 a2  
   418 : vsrl.vv          v31, v0, v0                  ; d7 0f 00 a2  
   419 : vsrl.vv          v0, v31, v0                  ; 57 00 f0 a3  
   420 : vsrl.vv          v0, v0, v31                  ; 57 80 0f a2  
   421 : vsrl.vx          v0, v0, zero                 ; 57 40 00 a2  
   422 : vsrl.vx          v31, v0, zero                ; d7 4f 00 a2  
   423 : vsrl.vx          v0, v31, zero                ; 57 40 f0 a3  
   424 : vsrl.vx          v0, v0, t6                   ; 57 c0 0f a2  
   425 : vsrl.vi          v0, v0, 0                    ; 57 30 00 a2  
   426 : vsrl.vi          v31, v0, 0                   ; d7 3f 00 a2  
   427 : vsrl.vi          v0, v31, 0                   ; 57 30 f0 a3  
   428 : vsrl.vi          v0, v0, 0x1f                 ; 57 b0 0f a2  
   429 : vsra.vv          v0, v0, v0                   ; 57 00 00 a6  
   430 : vsra.vv          v31, v0, v0                  ; d7 0f 00 a6  
   431 : vsra.vv          v0, v31, v0                  ; 57 00 f0 a7  
   432 : vsra.vv          v0, v0, v31                  ; 57 80 0f a6  
   433 : vsra.vx          v0, v0, zero                 ; 57 40 00 a6  
   434 : vsra.vx          v31, v0, zero                ; d7 4f 00 a6  
   435 : vsra.vx          v0, v31, zero                ; 57 40 f0 a7  
   436 : vsra.vx          v0, v0, t6                   ; 57 c0 0f a6  
   437 : vsra.vi          v0, v0, 0                    ; 57 30 00 a6  
   438 : vsra.vi          v31, v0, 0                   ; d7 3f 00 a6  
   439 : vsra.vi          v0, v31, 0                   ; 57 30 f0 a7  
   440 : vsra.vi          v0, v0, 0x1f                 ; 57 b0 0f a6  
   441 : vand.vv          v0, v0, v0                   ; 57 00 00 26  
   442 : vand.vv          v31, v0, v0                  ; d7 0f 00 26  
   443 : vand.vv          v0, v31, v0                  ; 57 00 f0 27  
   444 : vand.vv          v0, v0, v31                  ; 57 80 0f 26  
   445 : vor.vv           v0, v0, v0                   ; 57 00 00 2a  
   446 : vor.vv           v31, v0, v0                  ; d7 0f 00 2a  
   447 : vor.vv           v0, v31, v0                  ; 57 00 f0 2b  
   448 : vor.vv           v0, v0, v31                  ; 57 80 0f 2a  
   449 : vxor.vv          v0, v0, v0                   ; 57 00 00 2e  
   450 : vxor.vv          v31, v0, v0                  ; d7 0f 00 2e  
   451 : vxor.vv          v0, v31, v0                  ; 57 00 f0 2f  
   452 : vxor.vv          v0, v0, v31                  ; 57 80 0f 2e  
   453 : vxor.vi          v0, v0, 0                    ; 57 30 00 2e  
   454 : vxor.vi          v31, v0, 0                   ; d7 3f 00 2e  
   455 : vxor.vi          v0, v31, 0                   ; 57 30 f0 2f  
   456 : vxor.vi          v0, v0, 0x0f                 ; 57 b0 07 2e  
   457 : vfadd.vv         v0, v0, v0                   ; 57 10 00 02  
   458 : vfadd.vv         v31, v0, v0                  ; d7 1f 00 02  
   459 : vfadd.vv         v0, v31, v0                  ; 57 10 f0 03  
   460 : vfadd.vv         v0, v0, v31                  ; 57 90 0f 02  
   461 : vfsub.vv         v0, v0, v0                   ; 57 10 00 0a  
   462 : vfsub.vv         v31, v0, v0                  ; d7 1f 00 0a  
   463 : vfsub.vv         v0, v31, v0                  ; 57 10 f0 0b  
   464 : vfsub.vv         v0, v0, v31                  ; 57 90 0f 0a  
   465 : vfmul.vv         v0, v0, v0                   ; 57 10 00 92  
   466 : vfmul.vv         v31, v0, v0                  ; d7 1f 00 92  
   467 : vfmul.vv         v0, v31, v0                  ; 57 10 f0 93  
   468 : vfmul.vv         v0, v0, v31                  ; 57 90 0f 92  
   469 : vfdiv.vv         v0, v0, v0                   ; 57 10 00 82  
   470 : vfdiv.vv         v31, v0, v0                  ; d7 1f 00 82  
   471 : vfdiv.vv         v0, v31, v0                  ; 57 10 f0 83  
   472 : vfdiv.vv         v0, v0, v31                  ; 57 90 0f 82  
   473 : vfmacc.vv        v0, v0, v0                   ; 57 10 00 b2  
   474 : vfmacc.vv        v31, v0, v0                  ; d7 1f 00 b2  
   475 : vfmacc.vv        v0, v31, v0                  ; 57 90 0f b2  
   476 : vfmacc.vv        v0, v0, v31                  ; 57 10 f0 b3  
   477 : vfmin.vv         v0, v0, v0                   ; 57 10 00 12  
   478 : vfmin.vv         v31, v0, v0                  ; d7 1f 00 12  
   479 : vfmin.vv         v0, v31, v0                  ; 57 10 f0 13  
   480 : vfmin.vv         v0, v0, v31                  ; 57 90 0f 12  
   481 : vfmax.vv         v0, v0, v0                   ; 57 10 00 1a  
   482 : vfmax.vv         v31, v0, v0                  ; d7 1f 00 1a  
   483 : vfmax.vv         v0, v31, v0                  ; 57 10 f0 1b  
   484 : vfmax.vv         v0, v0, v31                  ; 57 90 0f 1a  
   485 : vfsgnjn.vv       v0, v0, v0                   ; 57 10 00 26  
   486 : vfsgnjn.vv       v31, v0, v0                  ; d7 1f 00 26  
   487 : vfsgnjn.vv       v0, v31, v31                 ; 57 90 ff 27  
   488 : vfcvt.rtz.x.f.v  v0, v0                       ; 57 90 03 4a  
   489 : vfcvt.rtz.x.f.v  v31, v0                      ; d7 9f 03 4a  
   490 : vfcvt.rtz.x.f.v  v0, v31                      ; 57 90 f3 4b  
   491 : vfcvt.rtz.xu.f.v v0, v0                       ; 57 10 03 4a  
   492 : vfcvt.rtz.xu.f.v v31, v0                      ; d7 1f 03 4a  
   493 : vfcvt.rtz.xu.f.v v0, v31                      ; 57 10 f3 4b  
   494 : vfcvt.xu.f.v     v0, v0                       ; 57 10 00 4a  
   495 : vfcvt.xu.f.v     v31, v0                      ; d7 1f 00 4a  
   496 : vfcvt.xu.f.v     v0, v31                      ; 57 10 f0 4b  
   497 : vfcvt.f.x.v      v0, v0                       ; 57 90 01 4a  
   498 : vfcvt.f.x.v      v31, v0                      ; d7 9f 01 4a  
   499 : vfcvt.f.x.v      v0, v31                      ; 57 90 f1 4b  
   500 : vfcvt.f.xu.v     v0, v0                       ; 57 10 01 4a  
   501 : vfcvt.f.xu.v     v31, v0                      ; d7 1f 01 4a  
   502 : vfcvt.f.xu.v     v0, v31                      ; 57 10 f1 4b  
   503 : vfcvt.rtz.x.f.v  v0, v0                       ; 57 90 03 4a  
   504 : vfcvt.rtz.x.f.v  v31, v0                      ; d7 9f 03 4a  
   505 : vfcvt.rtz.x.f.v  v0, v31                      ; 57 90 f3 4b  
   506 : vfcvt.rtz.xu.f.v v0, v0                       ; 57 10 03 4a  
   507 : vfcvt.rtz.xu.f.v v31, v0                      ; d7 1f 03 4a  
   508 : vfcvt.rtz.xu.f.v v0, v31                      ; 57 10 f3 4b  
   509 : vfncvt.x.f.w     v0, v0                       ; 57 90 08 4a  
   510 : vfncvt.x.f.w     v31, v0                      ; d7 9f 08 4a  
   511 : vfncvt.x.f.w     v0, v31                      ; 57 90 f8 4b  
   512 : vfncvt.f.f.w     v0, v0                       ; 57 10 0a 4a  
   513 : vfncvt.f.f.w     v31, v0                      ; d7 1f 0a 4a  
   514 : vfncvt.f.f.w     v0, v31                      ; 57 10 fa 4b  
   515 : vredmax.vs       v0, v0, v0                   ; 57 20 00 1e  
   516 : vredmax.vs       v31, v0, v0                  ; d7 2f 00 1e  
   517 : vredmax.vs       v0, v31, v31                 ; 57 a0 ff 1f  
   518 : vredmaxu.vs      v0, v0, v0                   ; 57 20 00 1a  
   519 : vredmaxu.vs      v31, v0, v0                  ; d7 2f 00 1a  
   520 : vredmaxu.vs      v0, v31, v31                 ; 57 a0 ff 1b  
   521 : vfredmax.vs      v0, v0, v0                   ; 57 10 00 1e  
   522 : vfredmax.vs      v31, v0, v0                  ; d7 1f 00 1e  
   523 : vfredmax.vs      v0, v31, v31                 ; 57 90 ff 1f  
   524 : vredmin.vs       v0, v0, v0                   ; 57 20 00 16  
   525 : vredmin.vs       v31, v0, v0                  ; d7 2f 00 16  
   526 : vredmin.vs       v0, v31, v31                 ; 57 a0 ff 17  
   527 : vredminu.vs      v0, v0, v0                   ; 57 20 00 12  
   528 : vredminu.vs      v31, v0, v0                  ; d7 2f 00 12  
   529 : vredminu.vs      v0, v31, v31                 ; 57 a0 ff 13  
   530 : vfredmin.vs      v0, v0, v0                   ; 57 10 00 16  
   531 : vfredmin.vs      v31, v0, v0                  ; d7 1f 00 16  
   532 : vfredmin.vs      v0, v31, v31                 ; 57 90 ff 17  
   533 : vredsum.vs       v0, v0, v0                   ; 57 20 00 02  
   534 : vredsum.vs       v31, v0, v0                  ; d7 2f 00 02  
   535 : vredsum.vs       v0, v31, v0                  ; 57 20 f0 03  
   536 : vredsum.vs       v0, v0, v31                  ; 57 a0 0f 02  
   537 : vfredusum.vs     v0, v0, v0                   ; 57 10 00 06  
   538 : vfredusum.vs     v31, v0, v0                  ; d7 1f 00 06  
   539 : vfredusum.vs     v0, v31, v0                  ; 57 10 f0 07  
   540 : vfredusum.vs     v0, v0, v31                  ; 57 90 0f 06  
   541 : vwredsum.vs      v0, v0, v0                   ; 57 00 00 c6  
   542 : vwredsum.vs      v31, v0, v0                  ; d7 0f 00 c6  
   543 : vwredsum.vs      v0, v31, v0                  ; 57 00 f0 c7  
   544 : vwredsum.vs      v0, v0, v31                  ; 57 80 0f c6  
   545 : vwredsumu.vs     v0, v0, v0                   ; 57 00 00 c2  
   546 : vwredsumu.vs     v31, v0, v0                  ; d7 0f 00 c2  
   547 : vwredsumu.vs     v0, v31, v0                  ; 57 00 f0 c3  
   548 : vwredsumu.vs     v0, v0, v31                  ; 57 80 0f c2  
   549 : csrrwi           zero, 0, 0                   ; 73 50 00 00  
   550 : csrrwi           t6, 0, 0                     ; f3 5f 00 00  
   551 : csrrwi           zero, 0xfff, 0               ; 73 50 f0 ff  
   552 : csrrwi           zero, 0, 0x1f                ; 73 d0 0f 00  
