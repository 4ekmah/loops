conditionpainter(i0)
     0 : addi sp, sp, -0x40           ; 13 01 01 fc  
     1 : sd   s8, 0x28(sp)            ; 23 34 81 03  
     2 : sd   s9, 0x30(sp)            ; 23 38 91 03  
     3 : addi s9, zero, -0x05         ; 93 0c b0 ff  
     4 : sd   s9, 0x10(sp)            ; 23 38 91 01  
     5 :      __loops_label_0:        ;              
     6 : addi a1, zero, 0x05          ; 93 05 50 00  
     7 : ld   s9, 0x10(sp)            ; 83 3c 01 01  
     8 : blt  a1, s9, __loops_label_2 ; 63 ce 95 27  
     9 : ld   s9, 0x10(sp)            ; 83 3c 01 01  
    10 : addi a1, s9, 0x05            ; 93 85 5c 00  
    11 : addi a2, zero, 0x0b          ; 13 06 b0 00  
    12 : mul  a1, a1, a2              ; b3 85 c5 02  
    13 : addi a2, zero, 0x08          ; 13 06 80 00  
    14 : mul  s9, a1, a2              ; b3 8c c5 02  
    15 : sd   s9, 0x08(sp)            ; 23 34 91 01  
    16 : addi s9, zero, -0x05         ; 93 0c b0 ff  
    17 : sd   s9, 0(sp)               ; 23 30 91 01  
    18 :      __loops_label_3:        ;              
    19 : addi s8, zero, 0x05          ; 13 0c 50 00  
    20 : ld   s9, 0(sp)               ; 83 3c 01 00  
    21 : blt  s8, s9, __loops_label_5 ; 63 4e 9c 23  
    22 : ld   s9, 0(sp)               ; 83 3c 01 00  
    23 : addi s8, s9, 0x03            ; 13 8c 3c 00  
    24 : ld   s9, 0x10(sp)            ; 83 3c 01 01  
    25 : slt  s8, s9, s8              ; 33 ac 8c 01  
    26 : neg  s8, s8                  ; 33 0c 80 41  
    27 : addi s8, s8, 0x01            ; 13 0c 1c 00  
    28 : addi a3, zero, 0x04          ; 93 06 40 00  
    29 : ld   s9, 0x10(sp)            ; 83 3c 01 01  
    30 : slt  a3, a3, s9              ; b3 a6 96 01  
    31 : neg  a3, a3                  ; b3 06 d0 40  
    32 : addi a3, a3, 0x01            ; 93 86 16 00  
    33 : and  a3, s8, a3              ; b3 76 dc 00  
    34 : addi s8, zero, -0x02         ; 13 0c e0 ff  
    35 : ld   s9, 0(sp)               ; 83 3c 01 00  
    36 : slt  s8, s9, s8              ; 33 ac 8c 01  
    37 : neg  s8, s8                  ; 33 0c 80 41  
    38 : addi s8, s8, 0x01            ; 13 0c 1c 00  
    39 : and  a3, a3, s8              ; b3 f6 86 01  
    40 : mv   s8, zero                ; 13 0c 00 00  
    41 : ld   s9, 0(sp)               ; 83 3c 01 00  
    42 : slt  s8, s8, s9              ; 33 2c 9c 01  
    43 : neg  s8, s8                  ; 33 0c 80 41  
    44 : addi s8, s8, 0x01            ; 13 0c 1c 00  
    45 : and  a3, a3, s8              ; b3 f6 86 01  
    46 : ld   s9, 0(sp)               ; 83 3c 01 00  
    47 : addi s8, s9, -0x01           ; 13 8c fc ff  
    48 : ld   s9, 0x10(sp)            ; 83 3c 01 01  
    49 : slt  s8, s8, s9              ; 33 2c 9c 01  
    50 : neg  s8, s8                  ; 33 0c 80 41  
    51 : addi s8, s8, 0x01            ; 13 0c 1c 00  
    52 : mv   a2, zero                ; 13 06 00 00  
    53 : ld   s9, 0(sp)               ; 83 3c 01 00  
    54 : slt  a2, s9, a2              ; 33 a6 cc 00  
    55 : neg  a2, a2                  ; 33 06 c0 40  
    56 : addi a2, a2, 0x01            ; 13 06 16 00  
    57 : and  a2, s8, a2              ; 33 76 cc 00  
    58 : mv   s8, zero                ; 13 0c 00 00  
    59 : ld   s9, 0x10(sp)            ; 83 3c 01 01  
    60 : slt  s8, s8, s9              ; 33 2c 9c 01  
    61 : neg  s8, s8                  ; 33 0c 80 41  
    62 : addi s8, s8, 0x01            ; 13 0c 1c 00  
    63 : and  a2, a2, s8              ; 33 76 86 01  
    64 : ld   s9, 0(sp)               ; 83 3c 01 00  
    65 : mul  s8, s9, s9              ; 33 8c 9c 03  
    66 : ld   s9, 0x10(sp)            ; 83 3c 01 01  
    67 : mul  a1, s9, s9              ; b3 85 9c 03  
    68 : add  a1, s8, a1              ; b3 05 bc 00  
    69 : addi s8, zero, 0x09          ; 13 0c 90 00  
    70 : slt  a1, s8, a1              ; b3 25 bc 00  
    71 : neg  a1, a1                  ; b3 05 b0 40  
    72 : addi a1, a1, 0x01            ; 93 85 15 00  
    73 : and  a1, a2, a1              ; b3 75 b6 00  
    74 : or   s9, a3, a1              ; b3 ec b6 00  
    75 : sd   s9, 0x18(sp)            ; 23 3c 91 01  
    76 : addi a2, zero, 0x02          ; 13 06 20 00  
    77 : mv   s9, zero                ; 93 0c 00 00  
    78 : sd   s9, 0x20(sp)            ; 23 30 91 03  
    79 : addi s8, zero, 0x02          ; 13 0c 20 00  
    80 : ld   s9, 0(sp)               ; 83 3c 01 00  
    81 : slt  s8, s9, s8              ; 33 ac 8c 01  
    82 : neg  s8, s8                  ; 33 0c 80 41  
    83 : addi s8, s8, 0x01            ; 13 0c 1c 00  
    84 : addi a1, zero, 0x04          ; 93 05 40 00  
    85 : ld   s9, 0(sp)               ; 83 3c 01 00  
    86 : slt  a1, a1, s9              ; b3 a5 95 01  
    87 : neg  a1, a1                  ; b3 05 b0 40  
    88 : addi a1, a1, 0x01            ; 93 85 15 00  
    89 : and  a1, s8, a1              ; b3 75 bc 00  
    90 : addi s8, zero, 0x01          ; 13 0c 10 00  
    91 : ld   s9, 0x10(sp)            ; 83 3c 01 01  
    92 : slt  s8, s9, s8              ; 33 ac 8c 01  
    93 : neg  s8, s8                  ; 33 0c 80 41  
    94 : addi s8, s8, 0x01            ; 13 0c 1c 00  
    95 : addi a3, zero, 0x03          ; 93 06 30 00  
    96 : ld   s9, 0x10(sp)            ; 83 3c 01 01  
    97 : slt  a3, a3, s9              ; b3 a6 96 01  
    98 : neg  a3, a3                  ; b3 06 d0 40  
    99 : addi a3, a3, 0x01            ; 93 86 16 00  
   100 : and  a3, s8, a3              ; b3 76 dc 00  
   101 : or   a1, a1, a3              ; b3 e5 d5 00  
   102 : ld   s9, 0(sp)               ; 83 3c 01 00  
   103 : mul  a3, s9, s9              ; b3 86 9c 03  
   104 : ld   s9, 0x10(sp)            ; 83 3c 01 01  
   105 : mul  s8, s9, s9              ; 33 8c 9c 03  
   106 : add  a3, a3, s8              ; b3 86 86 01  
   107 : addi s8, zero, 0x10          ; 13 0c 00 01  
   108 : slt  a3, s8, a3              ; b3 26 dc 00  
   109 : neg  a3, a3                  ; b3 06 d0 40  
   110 : addi a3, a3, 0x01            ; 93 86 16 00  
   111 : and  a1, a1, a3              ; b3 f5 d5 00  
   112 : mv   a3, zero                ; 93 06 00 00  
   113 : sub  a1, a1, a3              ; b3 85 d5 40  
   114 : snez a1, a1                  ; b3 35 b0 00  
   115 : ld   s9, 0x20(sp)            ; 83 3c 01 02  
   116 : sub  a2, a2, s9              ; 33 06 96 41  
   117 : sub  a1, zero, a1            ; b3 05 b0 40  
   118 : and  a1, a1, a2              ; b3 f5 c5 00  
   119 : ld   s9, 0x20(sp)            ; 83 3c 01 02  
   120 : add  a1, s9, a1              ; b3 85 bc 00  
   121 : ld   s9, 0x18(sp)            ; 83 3c 81 01  
   122 : add  a1, s9, a1              ; b3 85 bc 00  
   123 : addi a2, zero, 0x02          ; 13 06 20 00  
   124 : ld   s9, 0x10(sp)            ; 83 3c 01 01  
   125 : mul  a2, s9, a2              ; 33 86 cc 02  
   126 : ld   s9, 0(sp)               ; 83 3c 01 00  
   127 : blt  a2, s9, __loops_label_8 ; 63 42 96 03  
   128 : ld   s9, 0(sp)               ; 83 3c 01 00  
   129 : addi a2, s9, 0x03            ; 13 86 3c 00  
   130 : neg  a2, a2                  ; 33 06 c0 40  
   131 : ld   s9, 0(sp)               ; 83 3c 01 00  
   132 : addi a3, s9, 0x03            ; 93 86 3c 00  
   133 : mul  a2, a2, a3              ; 33 06 d6 02  
   134 : ld   s9, 0x10(sp)            ; 83 3c 01 01  
   135 : bge  a2, s9, __loops_label_9 ; 63 5c 96 03  
   136 :      __loops_label_8:        ;              
   137 : addi a2, zero, 0x02          ; 13 06 20 00  
   138 : ld   s9, 0(sp)               ; 83 3c 01 00  
   139 : mul  a2, s9, a2              ; 33 86 cc 02  
   140 : ld   s9, 0x10(sp)            ; 83 3c 01 01  
   141 : blt  a2, s9, __loops_label_7 ; 63 4a 96 03  
   142 : ld   s9, 0(sp)               ; 83 3c 01 00  
   143 : addi a2, s9, 0x03            ; 13 86 3c 00  
   144 : neg  a2, a2                  ; 33 06 c0 40  
   145 : ld   s9, 0(sp)               ; 83 3c 01 00  
   146 : addi a3, s9, 0x03            ; 93 86 3c 00  
   147 : mul  a2, a2, a3              ; 33 06 d6 02  
   148 : ld   s9, 0x10(sp)            ; 83 3c 01 01  
   149 : blt  s9, a2, __loops_label_7 ; 63 ca cc 00  
   150 :      __loops_label_9:        ;              
   151 : mv   a2, zero                ; 13 06 00 00  
   152 : ld   s9, 0(sp)               ; 83 3c 01 00  
   153 : blt  a2, s9, __loops_label_7 ; 63 44 96 01  
   154 : addi a1, a1, 0x03            ; 93 85 35 00  
   155 :      __loops_label_7:        ;              
   156 : ld   s9, 0(sp)               ; 83 3c 01 00  
   157 : addi a2, s9, 0x05            ; 13 86 5c 00  
   158 : slli a2, a2, 0x03            ; 13 16 36 00  
   159 : ld   s9, 0x08(sp)            ; 83 3c 81 00  
   160 : add  a2, s9, a2              ; 33 86 cc 00  
   161 : add  a2, a0, a2              ; 33 06 c5 00  
   162 : sd   a1, 0(a2)               ; 23 30 b6 00  
   163 : ld   s9, 0(sp)               ; 83 3c 01 00  
   164 : addi s9, s9, 0x01            ; 93 8c 1c 00  
   165 : sd   s9, 0(sp)               ; 23 30 91 01  
   166 : j    __loops_label_3         ; 6f f0 1f dc  
   167 :      __loops_label_5:        ;              
   168 : ld   s9, 0x10(sp)            ; 83 3c 01 01  
   169 : addi s9, s9, 0x01            ; 93 8c 1c 00  
   170 : sd   s9, 0x10(sp)            ; 23 38 91 01  
   171 : j    __loops_label_0         ; 6f f0 1f d8  
   172 :      __loops_label_2:        ;              
   173 : ld   s8, 0x28(sp)            ; 03 3c 81 02  
   174 : ld   s9, 0x30(sp)            ; 83 3c 01 03  
   175 : addi sp, sp, 0x40            ; 13 01 01 04  
   176 : ret                          ; 67 80 00 00  
