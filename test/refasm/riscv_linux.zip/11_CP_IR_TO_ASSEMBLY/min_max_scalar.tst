min_max_scalar(i0, i1, i2, i3)
     0 : addi sp, sp, -0x70            ; 13 01 01 f9  
     1 : sd   s8, 0x50(sp)             ; 23 38 81 05  
     2 : sd   s9, 0x58(sp)             ; 23 3c 91 05  
     3 : sd   s10, 0x60(sp)            ; 23 30 a1 07  
     4 : mv   s9, zero                 ; 93 0c 00 00  
     5 : sd   s9, 0x48(sp)             ; 23 34 91 05  
     6 : mv   s9, zero                 ; 93 0c 00 00  
     7 : sd   s9, 0x20(sp)             ; 23 30 91 03  
     8 : mv   s9, zero                 ; 93 0c 00 00  
     9 : sd   s9, 0x28(sp)             ; 23 34 91 03  
    10 : lw   s9, 0(a0)                ; 83 2c 05 00  
    11 : sd   s9, 0x30(sp)             ; 23 38 91 03  
    12 : ld   s9, 0x30(sp)             ; 83 3c 01 03  
    13 : mv   s10, s9                  ; 13 8d 0c 00  
    14 : sd   s10, 0x38(sp)            ; 23 3c a1 03  
    15 : addi s8, zero, 0x04           ; 13 0c 40 00  
    16 : mul  a1, a1, s8               ; b3 85 85 03  
    17 : sd   a1, 0x40(sp)             ; 23 30 b1 04  
    18 :      __loops_label_0:         ;              
    19 : ld   s10, 0x40(sp)            ; 03 3d 01 04  
    20 : ld   s9, 0x48(sp)             ; 83 3c 81 04  
    21 : bge  s9, s10, __loops_label_2 ; 63 dc ac 05  
    22 : ld   s9, 0x48(sp)             ; 83 3c 81 04  
    23 : add  s8, a0, s9               ; 33 0c 95 01  
    24 : lw   s8, 0(s8)                ; 03 2c 0c 00  
    25 : ld   s9, 0x30(sp)             ; 83 3c 01 03  
    26 : bge  s8, s9, __loops_label_4  ; 63 5c 9c 01  
    27 : mv   s9, s8                   ; 93 0c 0c 00  
    28 : sd   s9, 0x30(sp)             ; 23 38 91 03  
    29 : ld   s9, 0x48(sp)             ; 83 3c 81 04  
    30 : mv   s10, s9                  ; 13 8d 0c 00  
    31 : sd   s10, 0x20(sp)            ; 23 30 a1 03  
    32 :      __loops_label_4:         ;              
    33 : ld   s9, 0x38(sp)             ; 83 3c 81 03  
    34 : bge  s9, s8, __loops_label_6  ; 63 dc 8c 01  
    35 : mv   s9, s8                   ; 93 0c 0c 00  
    36 : sd   s9, 0x38(sp)             ; 23 3c 91 03  
    37 : ld   s9, 0x48(sp)             ; 83 3c 81 04  
    38 : mv   s10, s9                  ; 13 8d 0c 00  
    39 : sd   s10, 0x28(sp)            ; 23 34 a1 03  
    40 :      __loops_label_6:         ;              
    41 : ld   s9, 0x48(sp)             ; 83 3c 81 04  
    42 : addi s9, s9, 0x04             ; 93 8c 4c 00  
    43 : sd   s9, 0x48(sp)             ; 23 34 91 05  
    44 : j    __loops_label_0          ; 6f f0 5f fa  
    45 :      __loops_label_2:         ;              
    46 : addi a0, zero, 0x04           ; 13 05 40 00  
    47 : ld   s9, 0x20(sp)             ; 83 3c 01 02  
    48 : div  a1, s9, a0               ; b3 c5 ac 02  
    49 : ld   s9, 0x28(sp)             ; 83 3c 81 02  
    50 : div  a0, s9, a0               ; 33 c5 ac 02  
    51 : sw   a1, 0(a2)                ; 23 20 b6 00  
    52 : sw   a0, 0(a3)                ; 23 a0 a6 00  
    53 : mv   a0, zero                 ; 13 05 00 00  
    54 : ld   s8, 0x50(sp)             ; 03 3c 01 05  
    55 : ld   s9, 0x58(sp)             ; 83 3c 81 05  
    56 : ld   s10, 0x60(sp)            ; 03 3d 01 06  
    57 : addi sp, sp, 0x70             ; 13 01 01 07  
    58 : ret                           ; 67 80 00 00  
