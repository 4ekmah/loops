all_loads_all_stores(i0, i1, i2, i3, i4)
     0 : addi sp, sp, -0xe0            ; 13 01 01 f2  
     1 : sd   s8, 0xc0(sp)             ; 23 30 81 0d  
     2 : sd   s9, 0xc8(sp)             ; 23 34 91 0d  
     3 : sd   s10, 0xd0(sp)            ; 23 38 a1 0d  
     4 : sd   s11, 0xd8(sp)            ; 23 3c b1 0d  
     5 : mv   s9, zero                 ; 93 0c 00 00  
     6 : sd   s9, 0x20(sp)             ; 23 30 91 03  
     7 : mv   s9, zero                 ; 93 0c 00 00  
     8 : sd   s9, 0(sp)                ; 23 30 91 01  
     9 : mv   s9, zero                 ; 93 0c 00 00  
    10 : sd   s9, 0x08(sp)             ; 23 34 91 01  
    11 : addi s9, zero, 0x02           ; 93 0c 20 00  
    12 : sd   s9, 0x38(sp)             ; 23 3c 91 03  
    13 : addi s9, zero, 0x01           ; 93 0c 10 00  
    14 : sd   s9, 0x30(sp)             ; 23 38 91 03  
    15 : addi s8, zero, 0x01           ; 13 0c 10 00  
    16 : slt  s8, s8, a1               ; 33 2c bc 00  
    17 : ld   s9, 0x38(sp)             ; 83 3c 81 03  
    18 : ld   s10, 0x30(sp)            ; 03 3d 01 03  
    19 : sub  s11, s9, s10             ; b3 8d ac 41  
    20 : sd   s11, 0x40(sp)            ; 23 30 b1 05  
    21 : sub  s8, zero, s8             ; 33 0c 80 41  
    22 : ld   s9, 0x40(sp)             ; 83 3c 01 04  
    23 : and  s8, s8, s9               ; 33 7c 9c 01  
    24 : ld   s9, 0x30(sp)             ; 83 3c 01 03  
    25 : add  s10, s9, s8              ; 33 8d 8c 01  
    26 : sd   s10, 0x48(sp)            ; 23 34 a1 05  
    27 : addi s9, zero, 0x04           ; 93 0c 40 00  
    28 : sd   s9, 0x50(sp)             ; 23 38 91 05  
    29 : addi s8, zero, 0x03           ; 13 0c 30 00  
    30 : slt  s8, s8, a1               ; 33 2c bc 00  
    31 : ld   s10, 0x48(sp)            ; 03 3d 81 04  
    32 : ld   s9, 0x50(sp)             ; 83 3c 01 05  
    33 : sub  s11, s9, s10             ; b3 8d ac 41  
    34 : sd   s11, 0x58(sp)            ; 23 3c b1 05  
    35 : sub  s8, zero, s8             ; 33 0c 80 41  
    36 : ld   s9, 0x58(sp)             ; 83 3c 81 05  
    37 : and  s8, s8, s9               ; 33 7c 9c 01  
    38 : ld   s9, 0x48(sp)             ; 83 3c 81 04  
    39 : add  s10, s9, s8              ; 33 8d 8c 01  
    40 : sd   s10, 0x60(sp)            ; 23 30 a1 07  
    41 : addi s9, zero, 0x08           ; 93 0c 80 00  
    42 : sd   s9, 0x68(sp)             ; 23 34 91 07  
    43 : addi s8, zero, 0x05           ; 13 0c 50 00  
    44 : slt  s8, s8, a1               ; 33 2c bc 00  
    45 : ld   s10, 0x60(sp)            ; 03 3d 01 06  
    46 : ld   s9, 0x68(sp)             ; 83 3c 81 06  
    47 : sub  s11, s9, s10             ; b3 8d ac 41  
    48 : sd   s11, 0x70(sp)            ; 23 38 b1 07  
    49 : sub  s8, zero, s8             ; 33 0c 80 41  
    50 : ld   s9, 0x70(sp)             ; 83 3c 01 07  
    51 : and  s8, s8, s9               ; 33 7c 9c 01  
    52 : ld   s9, 0x60(sp)             ; 83 3c 01 06  
    53 : add  s10, s9, s8              ; 33 8d 8c 01  
    54 : sd   s10, 0x10(sp)            ; 23 38 a1 01  
    55 : addi s9, zero, 0x02           ; 93 0c 20 00  
    56 : sd   s9, 0x80(sp)             ; 23 30 91 09  
    57 : addi s9, zero, 0x01           ; 93 0c 10 00  
    58 : sd   s9, 0x78(sp)             ; 23 3c 91 07  
    59 : addi s8, zero, 0x01           ; 13 0c 10 00  
    60 : slt  s8, s8, a3               ; 33 2c dc 00  
    61 : ld   s9, 0x80(sp)             ; 83 3c 01 08  
    62 : ld   s10, 0x78(sp)            ; 03 3d 81 07  
    63 : sub  s11, s9, s10             ; b3 8d ac 41  
    64 : sd   s11, 0x88(sp)            ; 23 34 b1 09  
    65 : sub  s8, zero, s8             ; 33 0c 80 41  
    66 : ld   s9, 0x88(sp)             ; 83 3c 81 08  
    67 : and  s8, s8, s9               ; 33 7c 9c 01  
    68 : ld   s9, 0x78(sp)             ; 83 3c 81 07  
    69 : add  s10, s9, s8              ; 33 8d 8c 01  
    70 : sd   s10, 0x90(sp)            ; 23 38 a1 09  
    71 : addi s9, zero, 0x04           ; 93 0c 40 00  
    72 : sd   s9, 0x98(sp)             ; 23 3c 91 09  
    73 : addi s8, zero, 0x03           ; 13 0c 30 00  
    74 : slt  s8, s8, a3               ; 33 2c dc 00  
    75 : ld   s10, 0x90(sp)            ; 03 3d 01 09  
    76 : ld   s9, 0x98(sp)             ; 83 3c 81 09  
    77 : sub  s11, s9, s10             ; b3 8d ac 41  
    78 : sd   s11, 0xa0(sp)            ; 23 30 b1 0b  
    79 : sub  s8, zero, s8             ; 33 0c 80 41  
    80 : ld   s9, 0xa0(sp)             ; 83 3c 01 0a  
    81 : and  s8, s8, s9               ; 33 7c 9c 01  
    82 : ld   s9, 0x90(sp)             ; 83 3c 01 09  
    83 : add  s10, s9, s8              ; 33 8d 8c 01  
    84 : sd   s10, 0xa8(sp)            ; 23 34 a1 0b  
    85 : addi s9, zero, 0x08           ; 93 0c 80 00  
    86 : sd   s9, 0xb0(sp)             ; 23 38 91 0b  
    87 : addi s8, zero, 0x05           ; 13 0c 50 00  
    88 : slt  s8, s8, a3               ; 33 2c dc 00  
    89 : ld   s10, 0xa8(sp)            ; 03 3d 81 0a  
    90 : ld   s9, 0xb0(sp)             ; 83 3c 01 0b  
    91 : sub  s11, s9, s10             ; b3 8d ac 41  
    92 : sd   s11, 0xb8(sp)            ; 23 3c b1 0b  
    93 : sub  s8, zero, s8             ; 33 0c 80 41  
    94 : ld   s9, 0xb8(sp)             ; 83 3c 81 0b  
    95 : and  s8, s8, s9               ; 33 7c 9c 01  
    96 : ld   s9, 0xa8(sp)             ; 83 3c 81 0a  
    97 : add  s10, s9, s8              ; 33 8d 8c 01  
    98 : sd   s10, 0x18(sp)            ; 23 3c a1 01  
    99 :      __loops_label_0:         ;              
   100 : ld   s9, 0x20(sp)             ; 83 3c 01 02  
   101 : bge  s9, a4, __loops_label_2  ; 63 d0 ec 1e  
   102 : sd   s9, 0x28(sp)             ; 23 34 91 03  
   103 : mv   s8, zero                 ; 13 0c 00 00  
   104 : bne  a1, s8, __loops_label_4  ; 63 9c 85 01  
   105 : ld   s9, 0(sp)                ; 83 3c 01 00  
   106 : add  s8, a0, s9               ; 33 0c 95 01  
   107 : lbu  s9, 0(s8)                ; 83 4c 0c 00  
   108 : sd   s9, 0x28(sp)             ; 23 34 91 03  
   109 : j    __loops_label_23         ; 6f 00 c0 0b  
   110 :      __loops_label_4:         ;              
   111 : addi s8, zero, 0x01           ; 13 0c 10 00  
   112 : bne  a1, s8, __loops_label_7  ; 63 9c 85 01  
   113 : ld   s9, 0(sp)                ; 83 3c 01 00  
   114 : add  s8, a0, s9               ; 33 0c 95 01  
   115 : lb   s9, 0(s8)                ; 83 0c 0c 00  
   116 : sd   s9, 0x28(sp)             ; 23 34 91 03  
   117 : j    __loops_label_23         ; 6f 00 00 0a  
   118 :      __loops_label_7:         ;              
   119 : addi s8, zero, 0x02           ; 13 0c 20 00  
   120 : bne  a1, s8, __loops_label_10 ; 63 9c 85 01  
   121 : ld   s9, 0(sp)                ; 83 3c 01 00  
   122 : add  s8, a0, s9               ; 33 0c 95 01  
   123 : lhu  s9, 0(s8)                ; 83 5c 0c 00  
   124 : sd   s9, 0x28(sp)             ; 23 34 91 03  
   125 : j    __loops_label_23         ; 6f 00 40 08  
   126 :      __loops_label_10:        ;              
   127 : addi s8, zero, 0x03           ; 13 0c 30 00  
   128 : bne  a1, s8, __loops_label_13 ; 63 9c 85 01  
   129 : ld   s9, 0(sp)                ; 83 3c 01 00  
   130 : add  s8, a0, s9               ; 33 0c 95 01  
   131 : lh   s9, 0(s8)                ; 83 1c 0c 00  
   132 : sd   s9, 0x28(sp)             ; 23 34 91 03  
   133 : j    __loops_label_23         ; 6f 00 80 06  
   134 :      __loops_label_13:        ;              
   135 : addi s8, zero, 0x04           ; 13 0c 40 00  
   136 : bne  a1, s8, __loops_label_16 ; 63 9c 85 01  
   137 : ld   s9, 0(sp)                ; 83 3c 01 00  
   138 : add  s8, a0, s9               ; 33 0c 95 01  
   139 : lwu  s9, 0(s8)                ; 83 6c 0c 00  
   140 : sd   s9, 0x28(sp)             ; 23 34 91 03  
   141 : j    __loops_label_23         ; 6f 00 c0 04  
   142 :      __loops_label_16:        ;              
   143 : addi s8, zero, 0x05           ; 13 0c 50 00  
   144 : bne  a1, s8, __loops_label_19 ; 63 9c 85 01  
   145 : ld   s9, 0(sp)                ; 83 3c 01 00  
   146 : add  s8, a0, s9               ; 33 0c 95 01  
   147 : lw   s9, 0(s8)                ; 83 2c 0c 00  
   148 : sd   s9, 0x28(sp)             ; 23 34 91 03  
   149 : j    __loops_label_23         ; 6f 00 00 03  
   150 :      __loops_label_19:        ;              
   151 : addi s8, zero, 0x06           ; 13 0c 60 00  
   152 : bne  a1, s8, __loops_label_22 ; 63 9c 85 01  
   153 : ld   s9, 0(sp)                ; 83 3c 01 00  
   154 : add  s8, a0, s9               ; 33 0c 95 01  
   155 : ld   s9, 0(s8)                ; 83 3c 0c 00  
   156 : sd   s9, 0x28(sp)             ; 23 34 91 03  
   157 : j    __loops_label_23         ; 6f 00 40 01  
   158 :      __loops_label_22:        ;              
   159 : ld   s9, 0(sp)                ; 83 3c 01 00  
   160 : add  s8, a0, s9               ; 33 0c 95 01  
   161 : ld   s9, 0(s8)                ; 83 3c 0c 00  
   162 : sd   s9, 0x28(sp)             ; 23 34 91 03  
   163 :      __loops_label_5:         ;              
   164 :      __loops_label_8:         ;              
   165 :      __loops_label_11:        ;              
   166 :      __loops_label_14:        ;              
   167 :      __loops_label_17:        ;              
   168 :      __loops_label_20:        ;              
   169 :      __loops_label_23:        ;              
   170 : mv   s8, zero                 ; 13 0c 00 00  
   171 : bne  a3, s8, __loops_label_25 ; 63 9c 86 01  
   172 : ld   s9, 0x08(sp)             ; 83 3c 81 00  
   173 : add  s8, a2, s9               ; 33 0c 96 01  
   174 : ld   s9, 0x28(sp)             ; 83 3c 81 02  
   175 : sb   s9, 0(s8)                ; 23 00 9c 01  
   176 : j    __loops_label_44         ; 6f 00 c0 0b  
   177 :      __loops_label_25:        ;              
   178 : addi s8, zero, 0x01           ; 13 0c 10 00  
   179 : bne  a3, s8, __loops_label_28 ; 63 9c 86 01  
   180 : ld   s9, 0x08(sp)             ; 83 3c 81 00  
   181 : add  s8, a2, s9               ; 33 0c 96 01  
   182 : ld   s9, 0x28(sp)             ; 83 3c 81 02  
   183 : sb   s9, 0(s8)                ; 23 00 9c 01  
   184 : j    __loops_label_44         ; 6f 00 00 0a  
   185 :      __loops_label_28:        ;              
   186 : addi s8, zero, 0x02           ; 13 0c 20 00  
   187 : bne  a3, s8, __loops_label_31 ; 63 9c 86 01  
   188 : ld   s9, 0x08(sp)             ; 83 3c 81 00  
   189 : add  s8, a2, s9               ; 33 0c 96 01  
   190 : ld   s9, 0x28(sp)             ; 83 3c 81 02  
   191 : sh   s9, 0(s8)                ; 23 10 9c 01  
   192 : j    __loops_label_44         ; 6f 00 40 08  
   193 :      __loops_label_31:        ;              
   194 : addi s8, zero, 0x03           ; 13 0c 30 00  
   195 : bne  a3, s8, __loops_label_34 ; 63 9c 86 01  
   196 : ld   s9, 0x08(sp)             ; 83 3c 81 00  
   197 : add  s8, a2, s9               ; 33 0c 96 01  
   198 : ld   s9, 0x28(sp)             ; 83 3c 81 02  
   199 : sh   s9, 0(s8)                ; 23 10 9c 01  
   200 : j    __loops_label_44         ; 6f 00 80 06  
   201 :      __loops_label_34:        ;              
   202 : addi s8, zero, 0x04           ; 13 0c 40 00  
   203 : bne  a3, s8, __loops_label_37 ; 63 9c 86 01  
   204 : ld   s9, 0x08(sp)             ; 83 3c 81 00  
   205 : add  s8, a2, s9               ; 33 0c 96 01  
   206 : ld   s9, 0x28(sp)             ; 83 3c 81 02  
   207 : sw   s9, 0(s8)                ; 23 20 9c 01  
   208 : j    __loops_label_44         ; 6f 00 c0 04  
   209 :      __loops_label_37:        ;              
   210 : addi s8, zero, 0x05           ; 13 0c 50 00  
   211 : bne  a3, s8, __loops_label_40 ; 63 9c 86 01  
   212 : ld   s9, 0x08(sp)             ; 83 3c 81 00  
   213 : add  s8, a2, s9               ; 33 0c 96 01  
   214 : ld   s9, 0x28(sp)             ; 83 3c 81 02  
   215 : sw   s9, 0(s8)                ; 23 20 9c 01  
   216 : j    __loops_label_44         ; 6f 00 00 03  
   217 :      __loops_label_40:        ;              
   218 : addi s8, zero, 0x06           ; 13 0c 60 00  
   219 : bne  a3, s8, __loops_label_43 ; 63 9c 86 01  
   220 : ld   s9, 0x08(sp)             ; 83 3c 81 00  
   221 : add  s8, a2, s9               ; 33 0c 96 01  
   222 : ld   s9, 0x28(sp)             ; 83 3c 81 02  
   223 : sd   s9, 0(s8)                ; 23 30 9c 01  
   224 : j    __loops_label_44         ; 6f 00 40 01  
   225 :      __loops_label_43:        ;              
   226 : ld   s9, 0x08(sp)             ; 83 3c 81 00  
   227 : add  s8, a2, s9               ; 33 0c 96 01  
   228 : ld   s9, 0x28(sp)             ; 83 3c 81 02  
   229 : sd   s9, 0(s8)                ; 23 30 9c 01  
   230 :      __loops_label_26:        ;              
   231 :      __loops_label_29:        ;              
   232 :      __loops_label_32:        ;              
   233 :      __loops_label_35:        ;              
   234 :      __loops_label_38:        ;              
   235 :      __loops_label_41:        ;              
   236 :      __loops_label_44:        ;              
   237 : ld   s9, 0(sp)                ; 83 3c 01 00  
   238 : ld   s10, 0x10(sp)            ; 03 3d 01 01  
   239 : add  s9, s9, s10              ; b3 8c ac 01  
   240 : sd   s9, 0(sp)                ; 23 30 91 01  
   241 : ld   s9, 0x08(sp)             ; 83 3c 81 00  
   242 : ld   s10, 0x18(sp)            ; 03 3d 81 01  
   243 : add  s9, s9, s10              ; b3 8c ac 01  
   244 : sd   s9, 0x08(sp)             ; 23 34 91 01  
   245 : ld   s9, 0x20(sp)             ; 83 3c 01 02  
   246 : addi s9, s9, 0x01             ; 93 8c 1c 00  
   247 : sd   s9, 0x20(sp)             ; 23 30 91 03  
   248 : j    __loops_label_0          ; 6f f0 1f e2  
   249 :      __loops_label_2:         ;              
   250 : ld   s8, 0xc0(sp)             ; 03 3c 01 0c  
   251 : ld   s9, 0xc8(sp)             ; 83 3c 81 0c  
   252 : ld   s10, 0xd0(sp)            ; 03 3d 01 0d  
   253 : ld   s11, 0xd8(sp)            ; 83 3d 81 0d  
   254 : addi sp, sp, 0xe0             ; 13 01 01 0e  
   255 : ret                           ; 67 80 00 00  
