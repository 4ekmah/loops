snake(i0, i1, i2)
     0 : addi sp, sp, -0x100           ; 13 01 01 f0  
     1 : sd   s8, 0xd8(sp)             ; 23 3c 81 0d  
     2 : sd   s9, 0xe0(sp)             ; 23 30 91 0f  
     3 : sd   s10, 0xe8(sp)            ; 23 34 a1 0f  
     4 : sd   fp, 0xf0(sp)             ; 23 38 81 0e  
     5 : sd   ra, 0xf8(sp)             ; 23 3c 11 0e  
     6 : add  a3, a1, a2               ; b3 86 c5 00  
     7 : addi s9, a3, -0x01            ; 93 8c f6 ff  
     8 : sd   s9, 0xa8(sp)             ; 23 34 91 0b  
     9 : mv   s9, zero                 ; 93 0c 00 00  
    10 : sd   s9, 0xa0(sp)             ; 23 30 91 0b  
    11 : addi s9, zero, 0x01           ; 93 0c 10 00  
    12 : sd   s9, 0x98(sp)             ; 23 3c 91 09  
    13 : ld   s9, 0x98(sp)             ; 83 3c 81 09  
    14 : neg  s10, s9                  ; 33 0d 90 41  
    15 : sd   s10, 0x80(sp)            ; 23 30 a1 09  
    16 : mv   s9, zero                 ; 93 0c 00 00  
    17 : sd   s9, 0xb0(sp)             ; 23 38 91 0b  
    18 :      __loops_label_0:         ;              
    19 : ld   s10, 0xa8(sp)            ; 03 3d 81 0a  
    20 : ld   s9, 0xb0(sp)             ; 83 3c 01 0b  
    21 : bge  s9, s10, __loops_label_2 ; 63 de ac 23  
    22 : mv   s9, zero                 ; 93 0c 00 00  
    23 : sd   s9, 0x88(sp)             ; 23 34 91 09  
    24 : mv   s9, zero                 ; 93 0c 00 00  
    25 : sd   s9, 0x90(sp)             ; 23 38 91 09  
    26 : ld   s9, 0xb0(sp)             ; 83 3c 01 0b  
    27 : andi a3, s9, 0x01             ; 93 f6 1c 00  
    28 : mv   s8, zero                 ; 13 0c 00 00  
    29 : beq  a3, s8, __loops_label_4  ; 63 8c 86 07  
    30 : addi s9, a2, -0x01            ; 93 0c f6 ff  
    31 : sd   s9, 0xb8(sp)             ; 23 3c 91 0b  
    32 : ld   s10, 0xb0(sp)            ; 03 3d 01 0b  
    33 : ld   s9, 0xb8(sp)             ; 83 3c 81 0b  
    34 : slt  s8, s9, s10              ; 33 ac ac 01  
    35 : ld   s10, 0xb0(sp)            ; 03 3d 01 0b  
    36 : ld   s9, 0xb8(sp)             ; 83 3c 81 0b  
    37 : sub  a3, s9, s10              ; b3 86 ac 41  
    38 : sub  s8, zero, s8             ; 33 0c 80 41  
    39 : and  a3, s8, a3               ; b3 76 dc 00  
    40 : ld   s9, 0xb0(sp)             ; 83 3c 01 0b  
    41 : add  s10, s9, a3              ; 33 8d dc 00  
    42 : sd   s10, 0x88(sp)            ; 23 34 a1 09  
    43 : ld   s9, 0xb0(sp)             ; 83 3c 01 0b  
    44 : ld   s10, 0xb8(sp)            ; 03 3d 81 0b  
    45 : sub  a3, s9, s10              ; b3 86 ac 41  
    46 : mv   s9, zero                 ; 93 0c 00 00  
    47 : sd   s9, 0xc0(sp)             ; 23 30 91 0d  
    48 : ld   s9, 0xb0(sp)             ; 83 3c 01 0b  
    49 : ld   s10, 0xb8(sp)            ; 03 3d 81 0b  
    50 : slt  s8, s10, s9              ; 33 2c 9d 01  
    51 : ld   s9, 0xc0(sp)             ; 83 3c 01 0c  
    52 : sub  a3, a3, s9               ; b3 86 96 41  
    53 : sub  s8, zero, s8             ; 33 0c 80 41  
    54 : and  a3, s8, a3               ; b3 76 dc 00  
    55 : ld   s9, 0xc0(sp)             ; 83 3c 01 0c  
    56 : add  s10, s9, a3              ; 33 8d dc 00  
    57 : sd   s10, 0x90(sp)            ; 23 38 a1 09  
    58 : j    __loops_label_6          ; 6f 00 40 07  
    59 :      __loops_label_4:         ;              
    60 : addi s9, a1, -0x01            ; 93 8c f5 ff  
    61 : sd   s9, 0xc8(sp)             ; 23 34 91 0d  
    62 : ld   s9, 0xb0(sp)             ; 83 3c 01 0b  
    63 : ld   s10, 0xc8(sp)            ; 03 3d 81 0c  
    64 : sub  s8, s9, s10              ; 33 8c ac 41  
    65 : mv   s9, zero                 ; 93 0c 00 00  
    66 : sd   s9, 0xd0(sp)             ; 23 38 91 0d  
    67 : ld   s9, 0xb0(sp)             ; 83 3c 01 0b  
    68 : ld   s10, 0xc8(sp)            ; 03 3d 81 0c  
    69 : slt  a3, s10, s9              ; b3 26 9d 01  
    70 : ld   s9, 0xd0(sp)             ; 83 3c 01 0d  
    71 : sub  s8, s8, s9               ; 33 0c 9c 41  
    72 : sub  a3, zero, a3             ; b3 06 d0 40  
    73 : and  a3, a3, s8               ; b3 f6 86 01  
    74 : ld   s9, 0xd0(sp)             ; 83 3c 01 0d  
    75 : add  s10, s9, a3              ; 33 8d dc 00  
    76 : sd   s10, 0x88(sp)            ; 23 34 a1 09  
    77 : ld   s10, 0xb0(sp)            ; 03 3d 01 0b  
    78 : ld   s9, 0xc8(sp)             ; 83 3c 81 0c  
    79 : slt  a3, s9, s10              ; b3 a6 ac 01  
    80 : ld   s10, 0xb0(sp)            ; 03 3d 01 0b  
    81 : ld   s9, 0xc8(sp)             ; 83 3c 81 0c  
    82 : sub  s8, s9, s10              ; 33 8c ac 41  
    83 : sub  a3, zero, a3             ; b3 06 d0 40  
    84 : and  a3, a3, s8               ; b3 f6 86 01  
    85 : ld   s9, 0xb0(sp)             ; 83 3c 01 0b  
    86 : add  s10, s9, a3              ; 33 8d dc 00  
    87 : sd   s10, 0x90(sp)            ; 23 38 a1 09  
    88 :      __loops_label_5:         ;              
    89 :      __loops_label_6:         ;              
    90 : mv   s8, zero                 ; 13 0c 00 00  
    91 : ld   s9, 0x88(sp)             ; 83 3c 81 08  
    92 : blt  s9, s8, __loops_label_8  ; 63 c2 8c 11  
    93 : ld   s9, 0x88(sp)             ; 83 3c 81 08  
    94 : bge  s9, a2, __loops_label_8  ; 63 de cc 0e  
    95 : mv   s8, zero                 ; 13 0c 00 00  
    96 : ld   s9, 0x90(sp)             ; 83 3c 01 09  
    97 : blt  s9, s8, __loops_label_8  ; 63 c8 8c 0f  
    98 : ld   s9, 0x90(sp)             ; 83 3c 01 09  
    99 : bge  s9, a1, __loops_label_8  ; 63 d4 bc 0e  
   100 : addi s8, zero, 0x2b           ; 13 0c b0 02  
   101 : slli s8, s8, 0x20             ; 13 1c 0c 02  
   102 : lui  a3, 0xcf8b6              ; b7 66 8b cf  
   103 : addi a3, a3, 0x11e            ; 93 86 e6 11  
   104 : add  a3, s8, a3               ; b3 06 dc 00  
   105 : ld   s9, 0x88(sp)             ; 83 3c 81 08  
   106 : ld   s10, 0x90(sp)            ; 03 3d 01 09  
   107 : sd   t1, 0(sp)                ; 23 30 61 00  
   108 : sd   t2, 0x08(sp)             ; 23 34 71 00  
   109 : sd   a0, 0x10(sp)             ; 23 38 a1 00  
   110 : sd   a1, 0x18(sp)             ; 23 3c b1 00  
   111 : sd   a2, 0x20(sp)             ; 23 30 c1 02  
   112 : sd   a3, 0x28(sp)             ; 23 34 d1 02  
   113 : sd   a4, 0x30(sp)             ; 23 38 e1 02  
   114 : sd   a5, 0x38(sp)             ; 23 3c f1 02  
   115 : sd   a6, 0x40(sp)             ; 23 30 01 05  
   116 : sd   a7, 0x48(sp)             ; 23 34 11 05  
   117 : sd   t3, 0x50(sp)             ; 23 38 c1 05  
   118 : sd   t4, 0x58(sp)             ; 23 3c d1 05  
   119 : sd   t5, 0x60(sp)             ; 23 30 e1 07  
   120 : sd   t6, 0x68(sp)             ; 23 34 f1 07  
   121 : mv   a0, s9                   ; 13 85 0c 00  
   122 : mv   a1, s10                  ; 93 05 0d 00  
   123 : jalr a3                       ; e7 80 06 00  
   124 : ld   t1, 0(sp)                ; 03 33 01 00  
   125 : ld   t2, 0x08(sp)             ; 83 33 81 00  
   126 : ld   a0, 0x10(sp)             ; 03 35 01 01  
   127 : ld   a1, 0x18(sp)             ; 83 35 81 01  
   128 : ld   a2, 0x20(sp)             ; 03 36 01 02  
   129 : ld   a3, 0x28(sp)             ; 83 36 81 02  
   130 : ld   a4, 0x30(sp)             ; 03 37 01 03  
   131 : ld   a5, 0x38(sp)             ; 83 37 81 03  
   132 : ld   a6, 0x40(sp)             ; 03 38 01 04  
   133 : ld   a7, 0x48(sp)             ; 83 38 81 04  
   134 : ld   t3, 0x50(sp)             ; 03 3e 01 05  
   135 : ld   t4, 0x58(sp)             ; 83 3e 81 05  
   136 : ld   t5, 0x60(sp)             ; 03 3f 01 06  
   137 : ld   t6, 0x68(sp)             ; 83 3f 81 06  
   138 : ld   s9, 0x90(sp)             ; 83 3c 01 09  
   139 : mul  a3, s9, a2               ; b3 86 cc 02  
   140 : ld   s9, 0x88(sp)             ; 83 3c 81 08  
   141 : add  a3, a3, s9               ; b3 86 96 01  
   142 : add  a3, a0, a3               ; b3 06 d5 00  
   143 : ld   s9, 0xa0(sp)             ; 83 3c 01 0a  
   144 : sb   s9, 0(a3)                ; 23 80 96 01  
   145 : ld   s9, 0xa0(sp)             ; 83 3c 01 0a  
   146 : addi s9, s9, 0x01             ; 93 8c 1c 00  
   147 : sd   s9, 0xa0(sp)             ; 23 30 91 0b  
   148 : ld   s10, 0x98(sp)            ; 03 3d 81 09  
   149 : ld   s9, 0x88(sp)             ; 83 3c 81 08  
   150 : add  s9, s9, s10              ; b3 8c ac 01  
   151 : sd   s9, 0x88(sp)             ; 23 34 91 09  
   152 : ld   s10, 0x80(sp)            ; 03 3d 01 08  
   153 : ld   s9, 0x90(sp)             ; 83 3c 01 09  
   154 : add  s9, s9, s10              ; b3 8c ac 01  
   155 : sd   s9, 0x90(sp)             ; 23 38 91 09  
   156 : j    __loops_label_6          ; 6f f0 9f ef  
   157 :      __loops_label_8:         ;              
   158 : ld   s9, 0x98(sp)             ; 83 3c 81 09  
   159 : neg  s9, s9                   ; b3 0c 90 41  
   160 : sd   s9, 0x98(sp)             ; 23 3c 91 09  
   161 : ld   s9, 0x80(sp)             ; 83 3c 01 08  
   162 : neg  s9, s9                   ; b3 0c 90 41  
   163 : sd   s9, 0x80(sp)             ; 23 30 91 09  
   164 : ld   s9, 0xb0(sp)             ; 83 3c 01 0b  
   165 : addi s9, s9, 0x01             ; 93 8c 1c 00  
   166 : sd   s9, 0xb0(sp)             ; 23 38 91 0b  
   167 : j    __loops_label_0          ; 6f f0 1f dc  
   168 :      __loops_label_2:         ;              
   169 : ld   fp, 0xf0(sp)             ; 03 34 01 0f  
   170 : ld   ra, 0xf8(sp)             ; 83 30 81 0f  
   171 : ld   s8, 0xd8(sp)             ; 03 3c 81 0d  
   172 : ld   s9, 0xe0(sp)             ; 83 3c 01 0e  
   173 : ld   s10, 0xe8(sp)            ; 03 3d 81 0e  
   174 : addi sp, sp, 0x100            ; 13 01 01 10  
   175 : ret                           ; 67 80 00 00  
