nonnegative_odd(i0, i1)
     0 : addi sp, sp, -0x40           ; 13 01 01 fc  
     1 : sd   s8, 0x30(sp)            ; 23 38 81 03  
     2 : sd   s9, 0x38(sp)            ; 23 3c 91 03  
     3 : mv   a2, zero                ; 13 06 00 00  
     4 : addi s9, zero, -0x04         ; 93 0c c0 ff  
     5 : sd   s9, 0x28(sp)            ; 23 34 91 03  
     6 : addi a3, zero, 0x04          ; 93 06 40 00  
     7 : mul  a1, a1, a3              ; b3 85 d5 02  
     8 : sd   a1, 0x20(sp)            ; 23 30 b1 02  
     9 :      __loops_label_0:        ;              
    10 : ld   s9, 0x20(sp)            ; 83 3c 01 02  
    11 : bge  a2, s9, __loops_label_2 ; 63 50 96 05  
    12 : add  s8, a0, a2              ; 33 0c c5 00  
    13 : lw   s8, 0(s8)               ; 03 2c 0c 00  
    14 : mv   a3, zero                ; 93 06 00 00  
    15 : bge  s8, a3, __loops_label_4 ; 63 56 dc 00  
    16 : addi a2, a2, 0x04            ; 13 06 46 00  
    17 : j    __loops_label_0         ; 6f f0 5f fe  
    18 :      __loops_label_4:        ;              
    19 : addi a3, zero, 0x02          ; 93 06 20 00  
    20 : rem  a3, s8, a3              ; b3 66 dc 02  
    21 : mv   s8, zero                ; 13 0c 00 00  
    22 : beq  a3, s8, __loops_label_6 ; 63 88 86 01  
    23 : mv   s9, a2                  ; 93 0c 06 00  
    24 : sd   s9, 0x28(sp)            ; 23 34 91 03  
    25 : j    __loops_label_2         ; 6f 00 c0 00  
    26 :      __loops_label_6:        ;              
    27 : addi a2, a2, 0x04            ; 13 06 46 00  
    28 : j    __loops_label_0         ; 6f f0 1f fc  
    29 :      __loops_label_2:        ;              
    30 : addi a0, zero, 0x04          ; 13 05 40 00  
    31 : ld   s9, 0x28(sp)            ; 83 3c 81 02  
    32 : div  a0, s9, a0              ; 33 c5 ac 02  
    33 : ld   s8, 0x30(sp)            ; 03 3c 01 03  
    34 : ld   s9, 0x38(sp)            ; 83 3c 81 03  
    35 : addi sp, sp, 0x40            ; 13 01 01 04  
    36 : ret                          ; 67 80 00 00  
