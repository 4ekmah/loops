fixed_power_v_uint32_t_0(i0, i1, i2)
     0 : mv       a3, zero                  ; 93 06 00 00  
     1 : addi     a5, zero, 0x04            ; 93 07 40 00  
     2 : mul      a4, a2, a5                ; 33 07 f6 02  
     3 :          __loops_label_0:          ;              
     4 : bge      a3, a4, __loops_label_2   ; 63 d2 e6 02  
     5 : add      a5, a0, a3                ; b3 07 d5 00  
     6 : vl1re8.v v0, (a5)                  ; 07 80 87 02  
     7 : vsetvli  a5, zero, e32, m1, tu, ma ; d7 77 00 09  
     8 : vmv.v.i  v0, 0x01                  ; 57 b0 00 5e  
     9 : add      a5, a1, a3                ; b3 87 d5 00  
    10 : vs1r.v   v0, (a5)                  ; 27 80 87 02  
    11 : addi     a3, a3, 0x20              ; 93 86 06 02  
    12 : j        __loops_label_0           ; 6f f0 1f fe  
    13 :          __loops_label_2:          ;              
    14 : mv       a0, zero                  ; 13 05 00 00  
    15 : ret                                ; 67 80 00 00  
