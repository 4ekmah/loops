area_sum(i0, i1)
     0 : addi sp, sp, -0xd0           ; 13 01 01 f3  
     1 : sd   s8, 0xa8(sp)            ; 23 34 81 0b  
     2 : sd   s9, 0xb0(sp)            ; 23 38 91 0b  
     3 : sd   fp, 0xc0(sp)            ; 23 30 81 0c  
     4 : sd   ra, 0xc8(sp)            ; 23 34 11 0c  
     5 : mv   s9, zero                ; 93 0c 00 00  
     6 : sd   s9, 0x80(sp)            ; 23 30 91 09  
     7 :      __loops_label_0:        ;              
     8 : mv   a3, zero                ; 93 06 00 00  
     9 : bge  a3, a1, __loops_label_2 ; 63 d6 b6 2a  
    10 : lb   s9, 0(a0)               ; 83 0c 05 00  
    11 : sd   s9, 0x88(sp)            ; 23 34 91 09  
    12 : addi s8, zero, 0x2b          ; 13 0c b0 02  
    13 : slli s8, s8, 0x20            ; 13 1c 0c 02  
    14 : lui  a2, 0xcf8b9             ; 37 96 8b cf  
    15 : addi a2, a2, -0x59c          ; 13 06 46 a6  
    16 : add  s9, s8, a2              ; b3 0c cc 00  
    17 : sd   s9, 0x90(sp)            ; 23 38 91 09  
    18 : addi s8, zero, 0x2b          ; 13 0c b0 02  
    19 : slli s8, s8, 0x20            ; 13 1c 0c 02  
    20 : lui  a3, 0xcf8b9             ; b7 96 8b cf  
    21 : addi a3, a3, -0x4da          ; 93 86 66 b2  
    22 : add  a3, s8, a3              ; b3 06 dc 00  
    23 : addi s8, zero, 0x2b          ; 13 0c b0 02  
    24 : slli s8, s8, 0x20            ; 13 1c 0c 02  
    25 : lui  a2, 0xcf8b9             ; 37 96 8b cf  
    26 : addi a2, a2, -0x44a          ; 13 06 66 bb  
    27 : add  a2, s8, a2              ; 33 06 cc 00  
    28 : addi s8, zero, 0x01          ; 13 0c 10 00  
    29 : ld   s9, 0x88(sp)            ; 83 3c 81 08  
    30 : sub  s8, s9, s8              ; 33 8c 8c 41  
    31 : seqz s8, s8                  ; 13 3c 1c 00  
    32 : sub  a3, a3, a2              ; b3 86 c6 40  
    33 : sub  s8, zero, s8            ; 33 0c 80 41  
    34 : and  a3, s8, a3              ; b3 76 dc 00  
    35 : add  a2, a2, a3              ; 33 06 d6 00  
    36 : mv   a3, zero                ; 93 06 00 00  
    37 : ld   s9, 0x88(sp)            ; 83 3c 81 08  
    38 : sub  a3, s9, a3              ; b3 86 dc 40  
    39 : seqz a3, a3                  ; 93 b6 16 00  
    40 : ld   s9, 0x90(sp)            ; 83 3c 01 09  
    41 : sub  s8, s9, a2              ; 33 8c cc 40  
    42 : sub  a3, zero, a3            ; b3 06 d0 40  
    43 : and  a3, a3, s8              ; b3 f6 86 01  
    44 : add  s9, a2, a3              ; b3 0c d6 00  
    45 : sd   s9, 0x98(sp)            ; 23 3c 91 09  
    46 : addi a3, zero, 0x2b          ; 93 06 b0 02  
    47 : slli a3, a3, 0x20            ; 93 96 06 02  
    48 : lui  s8, 0xcf8b9             ; 37 9c 8b cf  
    49 : addi s8, s8, -0x6c0          ; 13 0c 0c 94  
    50 : add  s9, a3, s8              ; b3 8c 86 01  
    51 : sd   s9, 0xa0(sp)            ; 23 30 91 0b  
    52 : addi s8, zero, 0x2b          ; 13 0c b0 02  
    53 : slli s8, s8, 0x20            ; 13 1c 0c 02  
    54 : lui  a2, 0xcf8b9             ; 37 96 8b cf  
    55 : addi a2, a2, -0x660          ; 13 06 06 9a  
    56 : add  a2, s8, a2              ; 33 06 cc 00  
    57 : addi s8, zero, 0x2b          ; 13 0c b0 02  
    58 : slli s8, s8, 0x20            ; 13 1c 0c 02  
    59 : lui  a3, 0xcf8b9             ; b7 96 8b cf  
    60 : addi a3, a3, -0x622          ; 93 86 e6 9d  
    61 : add  a3, s8, a3              ; b3 06 dc 00  
    62 : addi s8, zero, 0x01          ; 13 0c 10 00  
    63 : ld   s9, 0x88(sp)            ; 83 3c 81 08  
    64 : sub  s8, s9, s8              ; 33 8c 8c 41  
    65 : seqz s8, s8                  ; 13 3c 1c 00  
    66 : sub  a2, a2, a3              ; 33 06 d6 40  
    67 : sub  s8, zero, s8            ; 33 0c 80 41  
    68 : and  a2, s8, a2              ; 33 76 cc 00  
    69 : add  a2, a3, a2              ; 33 86 c6 00  
    70 : mv   a3, zero                ; 93 06 00 00  
    71 : ld   s9, 0x88(sp)            ; 83 3c 81 08  
    72 : sub  a3, s9, a3              ; b3 86 dc 40  
    73 : seqz a3, a3                  ; 93 b6 16 00  
    74 : ld   s9, 0xa0(sp)            ; 83 3c 01 0a  
    75 : sub  s8, s9, a2              ; 33 8c cc 40  
    76 : sub  a3, zero, a3            ; b3 06 d0 40  
    77 : and  a3, a3, s8              ; b3 f6 86 01  
    78 : add  a2, a2, a3              ; 33 06 d6 00  
    79 : ld   s9, 0x98(sp)            ; 83 3c 81 09  
    80 : sd   t1, 0(sp)               ; 23 30 61 00  
    81 : sd   t2, 0x08(sp)            ; 23 34 71 00  
    82 : sd   a0, 0x10(sp)            ; 23 38 a1 00  
    83 : sd   a1, 0x18(sp)            ; 23 3c b1 00  
    84 : sd   a2, 0x20(sp)            ; 23 30 c1 02  
    85 : sd   a3, 0x28(sp)            ; 23 34 d1 02  
    86 : sd   a4, 0x30(sp)            ; 23 38 e1 02  
    87 : sd   a5, 0x38(sp)            ; 23 3c f1 02  
    88 : sd   a6, 0x40(sp)            ; 23 30 01 05  
    89 : sd   a7, 0x48(sp)            ; 23 34 11 05  
    90 : sd   t3, 0x50(sp)            ; 23 38 c1 05  
    91 : sd   t4, 0x58(sp)            ; 23 3c d1 05  
    92 : sd   t5, 0x60(sp)            ; 23 30 e1 07  
    93 : sd   t6, 0x68(sp)            ; 23 34 f1 07  
    94 : jalr s9                      ; e7 80 0c 00  
    95 : ld   t1, 0(sp)               ; 03 33 01 00  
    96 : ld   t2, 0x08(sp)            ; 83 33 81 00  
    97 : ld   a0, 0x10(sp)            ; 03 35 01 01  
    98 : ld   a1, 0x18(sp)            ; 83 35 81 01  
    99 : ld   a2, 0x20(sp)            ; 03 36 01 02  
   100 : ld   a3, 0x28(sp)            ; 83 36 81 02  
   101 : ld   a4, 0x30(sp)            ; 03 37 01 03  
   102 : ld   a5, 0x38(sp)            ; 83 37 81 03  
   103 : ld   a6, 0x40(sp)            ; 03 38 01 04  
   104 : ld   a7, 0x48(sp)            ; 83 38 81 04  
   105 : ld   t3, 0x50(sp)            ; 03 3e 01 05  
   106 : ld   t4, 0x58(sp)            ; 83 3e 81 05  
   107 : ld   t5, 0x60(sp)            ; 03 3f 01 06  
   108 : ld   t6, 0x68(sp)            ; 83 3f 81 06  
   109 : sd   t1, 0(sp)               ; 23 30 61 00  
   110 : sd   t2, 0x08(sp)            ; 23 34 71 00  
   111 : sd   a0, 0x10(sp)            ; 23 38 a1 00  
   112 : sd   a1, 0x18(sp)            ; 23 3c b1 00  
   113 : sd   a2, 0x20(sp)            ; 23 30 c1 02  
   114 : sd   a3, 0x28(sp)            ; 23 34 d1 02  
   115 : sd   a4, 0x30(sp)            ; 23 38 e1 02  
   116 : sd   a5, 0x38(sp)            ; 23 3c f1 02  
   117 : sd   a6, 0x40(sp)            ; 23 30 01 05  
   118 : sd   a7, 0x48(sp)            ; 23 34 11 05  
   119 : sd   t3, 0x50(sp)            ; 23 38 c1 05  
   120 : sd   t4, 0x58(sp)            ; 23 3c d1 05  
   121 : sd   t5, 0x60(sp)            ; 23 30 e1 07  
   122 : sd   t6, 0x68(sp)            ; 23 34 f1 07  
   123 : jalr a2                      ; e7 00 06 00  
   124 : mv   a2, a0                  ; 13 06 05 00  
   125 : ld   t1, 0(sp)               ; 03 33 01 00  
   126 : ld   t2, 0x08(sp)            ; 83 33 81 00  
   127 : ld   a0, 0x10(sp)            ; 03 35 01 01  
   128 : ld   a1, 0x18(sp)            ; 83 35 81 01  
   129 : ld   a3, 0x28(sp)            ; 83 36 81 02  
   130 : ld   a4, 0x30(sp)            ; 03 37 01 03  
   131 : ld   a5, 0x38(sp)            ; 83 37 81 03  
   132 : ld   a6, 0x40(sp)            ; 03 38 01 04  
   133 : ld   a7, 0x48(sp)            ; 83 38 81 04  
   134 : ld   t3, 0x50(sp)            ; 03 3e 01 05  
   135 : ld   t4, 0x58(sp)            ; 83 3e 81 05  
   136 : ld   t5, 0x60(sp)            ; 03 3f 01 06  
   137 : ld   t6, 0x68(sp)            ; 83 3f 81 06  
   138 : addi a3, zero, 0x2b          ; 93 06 b0 02  
   139 : slli a3, a3, 0x20            ; 93 96 06 02  
   140 : lui  s8, 0xcf8b9             ; 37 9c 8b cf  
   141 : addi s8, s8, -0x704          ; 13 0c cc 8f  
   142 : add  a3, a3, s8              ; b3 86 86 01  
   143 : ld   s9, 0x80(sp)            ; 83 3c 01 08  
   144 : sd   t1, 0(sp)               ; 23 30 61 00  
   145 : sd   t2, 0x08(sp)            ; 23 34 71 00  
   146 : sd   a0, 0x10(sp)            ; 23 38 a1 00  
   147 : sd   a1, 0x18(sp)            ; 23 3c b1 00  
   148 : sd   a2, 0x20(sp)            ; 23 30 c1 02  
   149 : sd   a3, 0x28(sp)            ; 23 34 d1 02  
   150 : sd   a4, 0x30(sp)            ; 23 38 e1 02  
   151 : sd   a5, 0x38(sp)            ; 23 3c f1 02  
   152 : sd   a6, 0x40(sp)            ; 23 30 01 05  
   153 : sd   a7, 0x48(sp)            ; 23 34 11 05  
   154 : sd   t3, 0x50(sp)            ; 23 38 c1 05  
   155 : sd   t4, 0x58(sp)            ; 23 3c d1 05  
   156 : sd   t5, 0x60(sp)            ; 23 30 e1 07  
   157 : sd   t6, 0x68(sp)            ; 23 34 f1 07  
   158 : mv   a0, s9                  ; 13 85 0c 00  
   159 : mv   a1, a2                  ; 93 05 06 00  
   160 : jalr a3                      ; e7 80 06 00  
   161 : mv   a2, a0                  ; 13 06 05 00  
   162 : ld   t1, 0(sp)               ; 03 33 01 00  
   163 : ld   t2, 0x08(sp)            ; 83 33 81 00  
   164 : ld   a0, 0x10(sp)            ; 03 35 01 01  
   165 : ld   a1, 0x18(sp)            ; 83 35 81 01  
   166 : ld   a3, 0x28(sp)            ; 83 36 81 02  
   167 : ld   a4, 0x30(sp)            ; 03 37 01 03  
   168 : ld   a5, 0x38(sp)            ; 83 37 81 03  
   169 : ld   a6, 0x40(sp)            ; 03 38 01 04  
   170 : ld   a7, 0x48(sp)            ; 83 38 81 04  
   171 : ld   t3, 0x50(sp)            ; 03 3e 01 05  
   172 : ld   t4, 0x58(sp)            ; 83 3e 81 05  
   173 : ld   t5, 0x60(sp)            ; 03 3f 01 06  
   174 : ld   t6, 0x68(sp)            ; 83 3f 81 06  
   175 : mv   s9, a2                  ; 93 0c 06 00  
   176 : sd   s9, 0x80(sp)            ; 23 30 91 09  
   177 : addi a0, a0, 0x38            ; 13 05 85 03  
   178 : addi a1, a1, -0x01           ; 93 85 f5 ff  
   179 : j    __loops_label_0         ; 6f f0 5f d5  
   180 :      __loops_label_2:        ;              
   181 : ld   s9, 0x80(sp)            ; 83 3c 01 08  
   182 : mv   a0, s9                  ; 13 85 0c 00  
   183 : ld   fp, 0xc0(sp)            ; 03 34 01 0c  
   184 : ld   ra, 0xc8(sp)            ; 83 30 81 0c  
   185 : ld   s8, 0xa8(sp)            ; 03 3c 81 0a  
   186 : ld   s9, 0xb0(sp)            ; 83 3c 01 0b  
   187 : addi sp, sp, 0xd0            ; 13 01 01 0d  
   188 : ret                          ; 67 80 00 00  
