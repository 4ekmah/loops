nullify_msb_lsb_v(i0, i1, i2, i3)
     0 : mv       a4, zero                  ; 13 07 00 00  
     1 : addi     a6, zero, 0x04            ; 13 08 40 00  
     2 : mul      a5, a3, a6                ; b3 87 06 03  
     3 : vsetvli  a3, zero, e32, m1, tu, ma ; d7 76 00 09  
     4 : vmv.v.i  v0, 0x01                  ; 57 b0 00 5e  
     5 :          __loops_label_0:          ;              
     6 : bge      a4, a5, __loops_label_2   ; 63 56 f7 06  
     7 : add      a6, a0, a4                ; 33 08 e5 00  
     8 : vl1re8.v v1, (a6)                  ; 87 00 88 02  
     9 : vsetvli  a6, zero, e32, m1, tu, ma ; 57 78 00 09  
    10 : vsrl.vi  v2, v1, 0x01              ; 57 b1 10 a2  
    11 : vor.vv   v2, v1, v2                ; 57 01 11 2a  
    12 : vsrl.vi  v3, v2, 0x02              ; d7 31 21 a2  
    13 : vor.vv   v2, v2, v3                ; 57 81 21 2a  
    14 : vsrl.vi  v3, v2, 0x04              ; d7 31 22 a2  
    15 : vor.vv   v2, v2, v3                ; 57 81 21 2a  
    16 : vsrl.vi  v3, v2, 0x08              ; d7 31 24 a2  
    17 : vor.vv   v2, v2, v3                ; 57 81 21 2a  
    18 : vsrl.vi  v3, v2, 0x10              ; d7 31 28 a2  
    19 : vor.vv   v2, v2, v3                ; 57 81 21 2a  
    20 : vadd.vv  v2, v2, v0                ; 57 01 20 02  
    21 : vsrl.vi  v2, v2, 0x01              ; 57 b1 20 a2  
    22 : vxor.vv  v2, v2, v1                ; 57 81 20 2e  
    23 : add      a6, a1, a4                ; 33 88 e5 00  
    24 : vs1r.v   v2, (a6)                  ; 27 01 88 02  
    25 : vsub.vv  v2, v1, v0                ; 57 01 10 0a  
    26 : vxor.vi  v2, v2, -0x01             ; 57 b1 2f 2e  
    27 : vand.vv  v2, v1, v2                ; 57 01 11 26  
    28 : vxor.vv  v1, v2, v1                ; d7 80 20 2e  
    29 : add      a6, a2, a4                ; 33 08 e6 00  
    30 : vs1r.v   v1, (a6)                  ; a7 00 88 02  
    31 : addi     a4, a4, 0x20              ; 13 07 07 02  
    32 : j        __loops_label_0           ; 6f f0 9f f9  
    33 :          __loops_label_2:          ;              
    34 : ret                                ; 67 80 00 00  
