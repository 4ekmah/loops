fixed_power_v_double_0(i0, i1, i2)
     0 : mv       a3, zero                  ; 93 06 00 00  
     1 : addi     a5, zero, 0x08            ; 93 07 80 00  
     2 : mul      a4, a2, a5                ; 33 07 f6 02  
     3 :          __loops_label_0:          ;              
     4 : bge      a3, a4, __loops_label_2   ; 63 dc e6 02  
     5 : add      a5, a0, a3                ; b3 07 d5 00  
     6 : vl1re8.v v0, (a5)                  ; 07 80 87 02  
     7 : vsetvli  a5, zero, e64, m1, tu, ma ; d7 77 80 09  
     8 : lui      a5, 0x3ff00               ; b7 07 f0 3f  
     9 : addi     a5, a5, 0                 ; 93 87 07 00  
    10 : slli     a5, a5, 0x20              ; 93 97 07 02  
    11 : mv       a6, zero                  ; 13 08 00 00  
    12 : add      a5, a5, a6                ; b3 87 07 01  
    13 : vmv.v.x  v0, a5                    ; 57 c0 07 5e  
    14 : add      a5, a1, a3                ; b3 87 d5 00  
    15 : vs1r.v   v0, (a5)                  ; 27 80 87 02  
    16 : addi     a3, a3, 0x20              ; 93 86 06 02  
    17 : j        __loops_label_0           ; 6f f0 df fc  
    18 :          __loops_label_2:          ;              
    19 : mv       a0, zero                  ; 13 05 00 00  
    20 : ret                                ; 67 80 00 00  
