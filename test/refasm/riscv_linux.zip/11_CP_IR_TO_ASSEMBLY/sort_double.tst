sort_double(i0, i1)
     0 : addi sp, sp, -0xe0            ; 13 01 01 f2  
     1 : sd   s8, 0xb0(sp)             ; 23 38 81 0b  
     2 : sd   s9, 0xb8(sp)             ; 23 3c 91 0b  
     3 : sd   s10, 0xc0(sp)            ; 23 30 a1 0d  
     4 : sd   fp, 0xd0(sp)             ; 23 38 81 0c  
     5 : sd   ra, 0xd8(sp)             ; 23 3c 11 0c  
     6 : slli s9, a1, 0x03             ; 93 9c 35 00  
     7 : sd   s9, 0x90(sp)             ; 23 38 91 09  
     8 : ld   s9, 0x90(sp)             ; 83 3c 01 09  
     9 : addi s10, s9, -0x08           ; 13 8d 8c ff  
    10 : sd   s10, 0xa0(sp)            ; 23 30 a1 0b  
    11 : mv   s9, zero                 ; 93 0c 00 00  
    12 : sd   s9, 0xa8(sp)             ; 23 34 91 0b  
    13 :      __loops_label_0:         ;              
    14 : ld   s10, 0xa0(sp)            ; 03 3d 01 0a  
    15 : ld   s9, 0xa8(sp)             ; 83 3c 81 0a  
    16 : bge  s9, s10, __loops_label_2 ; 63 d4 ac 15  
    17 : ld   s9, 0xa8(sp)             ; 83 3c 81 0a  
    18 : mv   s10, s9                  ; 13 8d 0c 00  
    19 : sd   s10, 0x88(sp)            ; 23 34 a1 09  
    20 : ld   s9, 0x88(sp)             ; 83 3c 81 08  
    21 : addi s10, s9, 0x08            ; 13 8d 8c 00  
    22 : sd   s10, 0x80(sp)            ; 23 30 a1 09  
    23 :      __loops_label_3:         ;              
    24 : ld   s10, 0x90(sp)            ; 03 3d 01 09  
    25 : ld   s9, 0x80(sp)             ; 83 3c 01 08  
    26 : bge  s9, s10, __loops_label_5 ; 63 dc ac 0d  
    27 : ld   s9, 0x80(sp)             ; 83 3c 01 08  
    28 : add  s8, a0, s9               ; 33 0c 95 01  
    29 : ld   s8, 0(s8)                ; 03 3c 0c 00  
    30 : ld   s9, 0x88(sp)             ; 83 3c 81 08  
    31 : add  a3, a0, s9               ; b3 06 95 01  
    32 : ld   s9, 0(a3)                ; 83 bc 06 00  
    33 : sd   s9, 0x98(sp)             ; 23 3c 91 09  
    34 : addi a2, zero, 0x2b           ; 13 06 b0 02  
    35 : slli a2, a2, 0x20             ; 13 16 06 02  
    36 : lui  a3, 0xcf8b8              ; b7 86 8b cf  
    37 : addi a3, a3, -0x64e           ; 93 86 26 9b  
    38 : add  a2, a2, a3               ; 33 06 d6 00  
    39 : ld   s9, 0x98(sp)             ; 83 3c 81 09  
    40 : sd   t1, 0(sp)                ; 23 30 61 00  
    41 : sd   t2, 0x08(sp)             ; 23 34 71 00  
    42 : sd   a0, 0x10(sp)             ; 23 38 a1 00  
    43 : sd   a1, 0x18(sp)             ; 23 3c b1 00  
    44 : sd   a2, 0x20(sp)             ; 23 30 c1 02  
    45 : sd   a3, 0x28(sp)             ; 23 34 d1 02  
    46 : sd   a4, 0x30(sp)             ; 23 38 e1 02  
    47 : sd   a5, 0x38(sp)             ; 23 3c f1 02  
    48 : sd   a6, 0x40(sp)             ; 23 30 01 05  
    49 : sd   a7, 0x48(sp)             ; 23 34 11 05  
    50 : sd   t3, 0x50(sp)             ; 23 38 c1 05  
    51 : sd   t4, 0x58(sp)             ; 23 3c d1 05  
    52 : sd   t5, 0x60(sp)             ; 23 30 e1 07  
    53 : sd   t6, 0x68(sp)             ; 23 34 f1 07  
    54 : mv   a0, s8                   ; 13 05 0c 00  
    55 : mv   a1, s9                   ; 93 85 0c 00  
    56 : jalr a2                       ; e7 00 06 00  
    57 : mv   a2, a0                   ; 13 06 05 00  
    58 : ld   t1, 0(sp)                ; 03 33 01 00  
    59 : ld   t2, 0x08(sp)             ; 83 33 81 00  
    60 : ld   a0, 0x10(sp)             ; 03 35 01 01  
    61 : ld   a1, 0x18(sp)             ; 83 35 81 01  
    62 : ld   a3, 0x28(sp)             ; 83 36 81 02  
    63 : ld   a4, 0x30(sp)             ; 03 37 01 03  
    64 : ld   a5, 0x38(sp)             ; 83 37 81 03  
    65 : ld   a6, 0x40(sp)             ; 03 38 01 04  
    66 : ld   a7, 0x48(sp)             ; 83 38 81 04  
    67 : ld   t3, 0x50(sp)             ; 03 3e 01 05  
    68 : ld   t4, 0x58(sp)             ; 83 3e 81 05  
    69 : ld   t5, 0x60(sp)             ; 03 3f 01 06  
    70 : ld   t6, 0x68(sp)             ; 83 3f 81 06  
    71 : mv   a3, zero                 ; 93 06 00 00  
    72 : beq  a2, a3, __loops_label_7  ; 63 08 d6 00  
    73 : ld   s9, 0x80(sp)             ; 83 3c 01 08  
    74 : mv   s10, s9                  ; 13 8d 0c 00  
    75 : sd   s10, 0x88(sp)            ; 23 34 a1 09  
    76 :      __loops_label_7:         ;              
    77 : ld   s9, 0x80(sp)             ; 83 3c 01 08  
    78 : addi s9, s9, 0x08             ; 93 8c 8c 00  
    79 : sd   s9, 0x80(sp)             ; 23 30 91 09  
    80 : j    __loops_label_3          ; 6f f0 5f f2  
    81 :      __loops_label_5:         ;              
    82 : ld   s10, 0xa8(sp)            ; 03 3d 81 0a  
    83 : ld   s9, 0x88(sp)             ; 83 3c 81 08  
    84 : beq  s9, s10, __loops_label_9 ; 63 8a ac 03  
    85 : ld   s9, 0xa8(sp)             ; 83 3c 81 0a  
    86 : add  a2, a0, s9               ; 33 06 95 01  
    87 : ld   a2, 0(a2)                ; 03 36 06 00  
    88 : ld   s9, 0x88(sp)             ; 83 3c 81 08  
    89 : add  a3, a0, s9               ; b3 06 95 01  
    90 : ld   a3, 0(a3)                ; 83 b6 06 00  
    91 : ld   s9, 0x88(sp)             ; 83 3c 81 08  
    92 : add  s8, a0, s9               ; 33 0c 95 01  
    93 : sd   a2, 0(s8)                ; 23 30 cc 00  
    94 : ld   s9, 0xa8(sp)             ; 83 3c 81 0a  
    95 : add  a2, a0, s9               ; 33 06 95 01  
    96 : sd   a3, 0(a2)                ; 23 30 d6 00  
    97 :      __loops_label_9:         ;              
    98 : ld   s9, 0xa8(sp)             ; 83 3c 81 0a  
    99 : addi s9, s9, 0x08             ; 93 8c 8c 00  
   100 : sd   s9, 0xa8(sp)             ; 23 34 91 0b  
   101 : j    __loops_label_0          ; 6f f0 5f eb  
   102 :      __loops_label_2:         ;              
   103 : ld   fp, 0xd0(sp)             ; 03 34 01 0d  
   104 : ld   ra, 0xd8(sp)             ; 83 30 81 0d  
   105 : ld   s8, 0xb0(sp)             ; 03 3c 01 0b  
   106 : ld   s9, 0xb8(sp)             ; 83 3c 81 0b  
   107 : ld   s10, 0xc0(sp)            ; 03 3d 01 0c  
   108 : addi sp, sp, 0xe0             ; 13 01 01 0e  
   109 : ret                           ; 67 80 00 00  
