bresenham(i0, i1, i2, i3, i4, i5, i6)
     0 : addi sp, sp, -0x80            ; 13 01 01 f8  
     1 : sd   s8, 0x58(sp)             ; 23 3c 81 05  
     2 : sd   s9, 0x60(sp)             ; 23 30 91 07  
     3 : sd   s10, 0x68(sp)            ; 23 34 a1 07  
     4 : sd   s11, 0x70(sp)            ; 23 38 b1 07  
     5 : sub  s9, a4, a2               ; b3 0c c7 40  
     6 : sd   s9, 0x28(sp)             ; 23 34 91 03  
     7 : ld   s9, 0x28(sp)             ; 83 3c 81 02  
     8 : slt  s8, zero, s9             ; 33 2c 90 01  
     9 : sub  s8, zero, s8             ; 33 0c 80 41  
    10 : ld   s9, 0x28(sp)             ; 83 3c 81 02  
    11 : and  s10, s8, s9              ; 33 7d 9c 01  
    12 : sd   s10, 0x30(sp)            ; 23 38 a1 03  
    13 : ld   s9, 0x28(sp)             ; 83 3c 81 02  
    14 : sub  s8, zero, s9             ; 33 0c 90 41  
    15 : ld   s9, 0x30(sp)             ; 83 3c 01 03  
    16 : add  s8, s8, s9               ; 33 0c 9c 01  
    17 : ld   s9, 0x30(sp)             ; 83 3c 01 03  
    18 : add  s10, s8, s9              ; 33 0d 9c 01  
    19 : sd   s10, 0x20(sp)            ; 23 30 a1 03  
    20 : sub  s8, a4, a2               ; 33 0c c7 40  
    21 : slt  s9, s8, zero             ; b3 2c 0c 00  
    22 : sd   s9, 0x38(sp)             ; 23 3c 91 03  
    23 : slt  s8, zero, s8             ; 33 2c 80 01  
    24 : ld   s9, 0x38(sp)             ; 83 3c 81 03  
    25 : sub  s10, s8, s9              ; 33 0d 9c 41  
    26 : sd   s10, 0(sp)               ; 23 30 a1 01  
    27 : sub  s9, a5, a3               ; b3 8c d7 40  
    28 : sd   s9, 0x40(sp)             ; 23 30 91 05  
    29 : ld   s9, 0x40(sp)             ; 83 3c 01 04  
    30 : slt  s8, zero, s9             ; 33 2c 90 01  
    31 : sub  s8, zero, s8             ; 33 0c 80 41  
    32 : ld   s9, 0x40(sp)             ; 83 3c 01 04  
    33 : and  s10, s8, s9              ; 33 7d 9c 01  
    34 : sd   s10, 0x48(sp)            ; 23 34 a1 05  
    35 : ld   s9, 0x40(sp)             ; 83 3c 01 04  
    36 : sub  s8, zero, s9             ; 33 0c 90 41  
    37 : ld   s9, 0x48(sp)             ; 83 3c 81 04  
    38 : add  s8, s8, s9               ; 33 0c 9c 01  
    39 : ld   s9, 0x48(sp)             ; 83 3c 81 04  
    40 : add  s8, s8, s9               ; 33 0c 9c 01  
    41 : neg  s9, s8                   ; b3 0c 80 41  
    42 : sd   s9, 0x08(sp)             ; 23 34 91 01  
    43 : sub  s8, a5, a3               ; 33 8c d7 40  
    44 : slt  s9, s8, zero             ; b3 2c 0c 00  
    45 : sd   s9, 0x50(sp)             ; 23 38 91 05  
    46 : slt  s8, zero, s8             ; 33 2c 80 01  
    47 : ld   s9, 0x50(sp)             ; 83 3c 01 05  
    48 : sub  s10, s8, s9              ; 33 0d 9c 41  
    49 : sd   s10, 0x10(sp)            ; 23 38 a1 01  
    50 : ld   s9, 0x20(sp)             ; 83 3c 01 02  
    51 : ld   s10, 0x08(sp)            ; 03 3d 81 00  
    52 : add  s11, s9, s10             ; b3 8d ac 01  
    53 : sd   s11, 0x18(sp)            ; 23 3c b1 01  
    54 :      __loops_label_0:         ;              
    55 : mv   s8, zero                 ; 13 0c 00 00  
    56 : beq  a0, s8, __loops_label_2  ; 63 0e 85 07  
    57 : mul  s8, a3, a1               ; 33 8c b6 02  
    58 : add  s8, s8, a2               ; 33 0c cc 00  
    59 : add  s8, a0, s8               ; 33 0c 85 01  
    60 : sb   a6, 0(s8)                ; 23 00 0c 01  
    61 : bne  a2, a4, __loops_label_4  ; 63 16 e6 00  
    62 : bne  a3, a5, __loops_label_4  ; 63 94 f6 00  
    63 : j    __loops_label_2          ; 6f 00 00 06  
    64 :      __loops_label_4:         ;              
    65 : ld   s9, 0x18(sp)             ; 83 3c 81 01  
    66 : slli s8, s9, 0x01             ; 13 9c 1c 00  
    67 : ld   s9, 0x08(sp)             ; 83 3c 81 00  
    68 : blt  s8, s9, __loops_label_6  ; 63 42 9c 03  
    69 : bne  a2, a4, __loops_label_8  ; 63 14 e6 00  
    70 : j    __loops_label_2          ; 6f 00 80 04  
    71 :      __loops_label_8:         ;              
    72 : ld   s10, 0x08(sp)            ; 03 3d 81 00  
    73 : ld   s9, 0x18(sp)             ; 83 3c 81 01  
    74 : add  s9, s9, s10              ; b3 8c ac 01  
    75 : sd   s9, 0x18(sp)             ; 23 3c 91 01  
    76 : ld   s9, 0(sp)                ; 83 3c 01 00  
    77 : add  a2, a2, s9               ; 33 06 96 01  
    78 :      __loops_label_6:         ;              
    79 : ld   s9, 0x20(sp)             ; 83 3c 01 02  
    80 : blt  s9, s8, __loops_label_10 ; 63 c2 8c 03  
    81 : bne  a3, a5, __loops_label_12 ; 63 94 f6 00  
    82 : j    __loops_label_2          ; 6f 00 00 02  
    83 :      __loops_label_12:        ;              
    84 : ld   s10, 0x20(sp)            ; 03 3d 01 02  
    85 : ld   s9, 0x18(sp)             ; 83 3c 81 01  
    86 : add  s9, s9, s10              ; b3 8c ac 01  
    87 : sd   s9, 0x18(sp)             ; 23 3c 91 01  
    88 : ld   s9, 0x10(sp)             ; 83 3c 01 01  
    89 : add  a3, a3, s9               ; b3 86 96 01  
    90 :      __loops_label_10:        ;              
    91 : j    __loops_label_0          ; 6f f0 5f f8  
    92 :      __loops_label_2:         ;              
    93 : ld   s8, 0x58(sp)             ; 03 3c 81 05  
    94 : ld   s9, 0x60(sp)             ; 83 3c 01 06  
    95 : ld   s10, 0x68(sp)            ; 03 3d 81 06  
    96 : ld   s11, 0x70(sp)            ; 83 3d 01 07  
    97 : addi sp, sp, 0x80             ; 13 01 01 08  
    98 : ret                           ; 67 80 00 00  
