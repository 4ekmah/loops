fixed_power_v_float_9(i0, i1, i2)
     0 : mv       a3, zero                  ; 93 06 00 00  
     1 : addi     a5, zero, 0x04            ; 93 07 40 00  
     2 : mul      a4, a2, a5                ; 33 07 f6 02  
     3 :          __loops_label_0:          ;              
     4 : bge      a3, a4, __loops_label_2   ; 63 da e6 02  
     5 : add      a5, a0, a3                ; b3 07 d5 00  
     6 : vl1re8.v v0, (a5)                  ; 07 80 87 02  
     7 : vsetvli  a5, zero, e32, m1, tu, ma ; d7 77 00 09  
     8 : csrrwi   a5, 0x02, 0               ; f3 57 20 00  
     9 : vfmul.vv v1, v0, v0                ; d7 10 00 92  
    10 : vfmul.vv v1, v1, v1                ; d7 90 10 92  
    11 : vfmul.vv v1, v1, v1                ; d7 90 10 92  
    12 : vfmul.vv v0, v0, v1                ; 57 90 00 92  
    13 : add      a5, a1, a3                ; b3 87 d5 00  
    14 : vs1r.v   v0, (a5)                  ; 27 80 87 02  
    15 : addi     a3, a3, 0x20              ; 93 86 06 02  
    16 : j        __loops_label_0           ; 6f f0 1f fd  
    17 :          __loops_label_2:          ;              
    18 : mv       a0, zero                  ; 13 05 00 00  
    19 : ret                                ; 67 80 00 00  
