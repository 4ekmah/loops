min_max_select(i0, i1, i2, i3)
     0 : addi sp, sp, -0x80            ; 13 01 01 f8  
     1 : sd   s8, 0x58(sp)             ; 23 3c 81 05  
     2 : sd   s9, 0x60(sp)             ; 23 30 91 07  
     3 : sd   s10, 0x68(sp)            ; 23 34 a1 07  
     4 : sd   s11, 0x70(sp)            ; 23 38 b1 07  
     5 : mv   s9, zero                 ; 93 0c 00 00  
     6 : sd   s9, 0x28(sp)             ; 23 34 91 03  
     7 : mv   s9, zero                 ; 93 0c 00 00  
     8 : sd   s9, 0(sp)                ; 23 30 91 01  
     9 : mv   s9, zero                 ; 93 0c 00 00  
    10 : sd   s9, 0x08(sp)             ; 23 34 91 01  
    11 : lw   s9, 0(a0)                ; 83 2c 05 00  
    12 : sd   s9, 0x10(sp)             ; 23 38 91 01  
    13 : ld   s9, 0x10(sp)             ; 83 3c 01 01  
    14 : mv   s10, s9                  ; 13 8d 0c 00  
    15 : sd   s10, 0x18(sp)            ; 23 3c a1 01  
    16 : slli s9, a1, 0x02             ; 93 9c 25 00  
    17 : sd   s9, 0x20(sp)             ; 23 30 91 03  
    18 :      __loops_label_0:         ;              
    19 : ld   s10, 0x20(sp)            ; 03 3d 01 02  
    20 : ld   s9, 0x28(sp)             ; 83 3c 81 02  
    21 : bge  s9, s10, __loops_label_2 ; 63 da ac 0f  
    22 : ld   s9, 0x28(sp)             ; 83 3c 81 02  
    23 : add  s8, a0, s9               ; 33 0c 95 01  
    24 : lw   s9, 0(s8)                ; 83 2c 0c 00  
    25 : sd   s9, 0x30(sp)             ; 23 38 91 03  
    26 : ld   s10, 0x10(sp)            ; 03 3d 01 01  
    27 : ld   s9, 0x30(sp)             ; 83 3c 01 03  
    28 : slt  s8, s9, s10              ; 33 ac ac 01  
    29 : ld   s9, 0x28(sp)             ; 83 3c 81 02  
    30 : ld   s10, 0(sp)               ; 03 3d 01 00  
    31 : sub  s11, s9, s10             ; b3 8d ac 41  
    32 : sd   s11, 0x38(sp)            ; 23 3c b1 03  
    33 : sub  s8, zero, s8             ; 33 0c 80 41  
    34 : ld   s9, 0x38(sp)             ; 83 3c 81 03  
    35 : and  s8, s8, s9               ; 33 7c 9c 01  
    36 : ld   s9, 0(sp)                ; 83 3c 01 00  
    37 : add  s9, s9, s8               ; b3 8c 8c 01  
    38 : sd   s9, 0(sp)                ; 23 30 91 01  
    39 : ld   s10, 0x10(sp)            ; 03 3d 01 01  
    40 : ld   s9, 0x30(sp)             ; 83 3c 01 03  
    41 : slt  s8, s9, s10              ; 33 ac ac 01  
    42 : ld   s10, 0x10(sp)            ; 03 3d 01 01  
    43 : ld   s9, 0x30(sp)             ; 83 3c 01 03  
    44 : sub  s11, s9, s10             ; b3 8d ac 41  
    45 : sd   s11, 0x40(sp)            ; 23 30 b1 05  
    46 : sub  s8, zero, s8             ; 33 0c 80 41  
    47 : ld   s9, 0x40(sp)             ; 83 3c 01 04  
    48 : and  s8, s8, s9               ; 33 7c 9c 01  
    49 : ld   s9, 0x10(sp)             ; 83 3c 01 01  
    50 : add  s9, s9, s8               ; b3 8c 8c 01  
    51 : sd   s9, 0x10(sp)             ; 23 38 91 01  
    52 : ld   s10, 0x18(sp)            ; 03 3d 81 01  
    53 : ld   s9, 0x30(sp)             ; 83 3c 01 03  
    54 : slt  s8, s10, s9              ; 33 2c 9d 01  
    55 : ld   s9, 0x28(sp)             ; 83 3c 81 02  
    56 : ld   s10, 0x08(sp)            ; 03 3d 81 00  
    57 : sub  s11, s9, s10             ; b3 8d ac 41  
    58 : sd   s11, 0x48(sp)            ; 23 34 b1 05  
    59 : sub  s8, zero, s8             ; 33 0c 80 41  
    60 : ld   s9, 0x48(sp)             ; 83 3c 81 04  
    61 : and  s8, s8, s9               ; 33 7c 9c 01  
    62 : ld   s9, 0x08(sp)             ; 83 3c 81 00  
    63 : add  s9, s9, s8               ; b3 8c 8c 01  
    64 : sd   s9, 0x08(sp)             ; 23 34 91 01  
    65 : ld   s10, 0x18(sp)            ; 03 3d 81 01  
    66 : ld   s9, 0x30(sp)             ; 83 3c 01 03  
    67 : slt  s8, s9, s10              ; 33 ac ac 01  
    68 : ld   s9, 0x18(sp)             ; 83 3c 81 01  
    69 : ld   s10, 0x30(sp)            ; 03 3d 01 03  
    70 : sub  s11, s9, s10             ; b3 8d ac 41  
    71 : sd   s11, 0x50(sp)            ; 23 38 b1 05  
    72 : sub  s8, zero, s8             ; 33 0c 80 41  
    73 : ld   s9, 0x50(sp)             ; 83 3c 01 05  
    74 : and  s8, s8, s9               ; 33 7c 9c 01  
    75 : ld   s9, 0x30(sp)             ; 83 3c 01 03  
    76 : add  s10, s9, s8              ; 33 8d 8c 01  
    77 : sd   s10, 0x18(sp)            ; 23 3c a1 01  
    78 : ld   s9, 0x28(sp)             ; 83 3c 81 02  
    79 : addi s9, s9, 0x04             ; 93 8c 4c 00  
    80 : sd   s9, 0x28(sp)             ; 23 34 91 03  
    81 : j    __loops_label_0          ; 6f f0 9f f0  
    82 :      __loops_label_2:         ;              
    83 : ld   s9, 0(sp)                ; 83 3c 01 00  
    84 : srai s9, s9, 0x02             ; 93 dc 2c 40  
    85 : sd   s9, 0(sp)                ; 23 30 91 01  
    86 : ld   s9, 0x08(sp)             ; 83 3c 81 00  
    87 : srai s9, s9, 0x02             ; 93 dc 2c 40  
    88 : sd   s9, 0x08(sp)             ; 23 34 91 01  
    89 : ld   s9, 0(sp)                ; 83 3c 01 00  
    90 : sw   s9, 0(a2)                ; 23 20 96 01  
    91 : ld   s9, 0x08(sp)             ; 83 3c 81 00  
    92 : sw   s9, 0(a3)                ; 23 a0 96 01  
    93 : mv   a0, zero                 ; 13 05 00 00  
    94 : ld   s8, 0x58(sp)             ; 03 3c 81 05  
    95 : ld   s9, 0x60(sp)             ; 83 3c 01 06  
    96 : ld   s10, 0x68(sp)            ; 03 3d 81 06  
    97 : ld   s11, 0x70(sp)            ; 83 3d 01 07  
    98 : addi sp, sp, 0x80             ; 13 01 01 08  
    99 : ret                           ; 67 80 00 00  
