has_in_join_cascade(i0, i1, i2)
     0 : addi sp, sp, -0x80            ; 13 01 01 f8  
     1 : sd   s8, 0x68(sp)             ; 23 34 81 07  
     2 : sd   s9, 0x70(sp)             ; 23 38 91 07  
     3 : sd   s10, 0x78(sp)            ; 23 3c a1 07  
     4 : mv   s9, zero                 ; 93 0c 00 00  
     5 : sd   s9, 0x28(sp)             ; 23 34 91 03  
     6 : ld   s9, 0x10(a0)             ; 83 3c 05 01  
     7 : sd   s9, 0x30(sp)             ; 23 38 91 03  
     8 : ld   s9, 0(a0)                ; 83 3c 05 00  
     9 : sd   s9, 0x38(sp)             ; 23 3c 91 03  
    10 : ld   s9, 0x08(a0)             ; 83 3c 85 00  
    11 : sd   s9, 0x40(sp)             ; 23 30 91 05  
    12 :      __loops_label_0:         ;              
    13 : mv   a3, zero                 ; 93 06 00 00  
    14 : ld   s9, 0x30(sp)             ; 83 3c 01 03  
    15 : bge  a3, s9, __loops_label_2  ; 63 d0 96 15  
    16 : ld   s9, 0x38(sp)             ; 83 3c 81 03  
    17 : lw   s10, 0(s9)               ; 03 ad 0c 00  
    18 : sd   s10, 0x48(sp)            ; 23 34 a1 05  
    19 : ld   s9, 0x38(sp)             ; 83 3c 81 03  
    20 : addi s9, s9, 0x04             ; 93 8c 4c 00  
    21 : sd   s9, 0x38(sp)             ; 23 3c 91 03  
    22 : ld   s9, 0x40(sp)             ; 83 3c 01 04  
    23 : lw   s10, 0(s9)               ; 03 ad 0c 00  
    24 : sd   s10, 0x20(sp)            ; 23 30 a1 03  
    25 : ld   s9, 0x40(sp)             ; 83 3c 01 04  
    26 : addi s9, s9, 0x04             ; 93 8c 4c 00  
    27 : sd   s9, 0x40(sp)             ; 23 30 91 05  
    28 : ld   s9, 0x30(sp)             ; 83 3c 01 03  
    29 : addi s9, s9, -0x01            ; 93 8c fc ff  
    30 : sd   s9, 0x30(sp)             ; 23 38 91 03  
    31 : ld   s9, 0x28(a0)             ; 83 3c 85 02  
    32 : sd   s9, 0x50(sp)             ; 23 38 91 05  
    33 : ld   s9, 0x18(a0)             ; 83 3c 85 01  
    34 : sd   s9, 0x58(sp)             ; 23 3c 91 05  
    35 : ld   s9, 0x20(a0)             ; 83 3c 05 02  
    36 : sd   s9, 0x60(sp)             ; 23 30 91 07  
    37 :      __loops_label_3:         ;              
    38 : mv   a3, zero                 ; 93 06 00 00  
    39 : ld   s9, 0x50(sp)             ; 83 3c 01 05  
    40 : bge  a3, s9, __loops_label_5  ; 63 de 96 0d  
    41 : ld   s9, 0x58(sp)             ; 83 3c 81 05  
    42 : lw   s10, 0(s9)               ; 03 ad 0c 00  
    43 : sd   s10, 0(sp)               ; 23 30 a1 01  
    44 : ld   s9, 0x58(sp)             ; 83 3c 81 05  
    45 : addi s9, s9, 0x04             ; 93 8c 4c 00  
    46 : sd   s9, 0x58(sp)             ; 23 3c 91 05  
    47 : ld   s9, 0x60(sp)             ; 83 3c 01 06  
    48 : lw   a3, 0(s9)                ; 83 a6 0c 00  
    49 : ld   s9, 0x60(sp)             ; 83 3c 01 06  
    50 : addi s9, s9, 0x04             ; 93 8c 4c 00  
    51 : sd   s9, 0x60(sp)             ; 23 30 91 07  
    52 : ld   s9, 0x50(sp)             ; 83 3c 01 05  
    53 : addi s9, s9, -0x01            ; 93 8c fc ff  
    54 : sd   s9, 0x50(sp)             ; 23 38 91 05  
    55 : ld   s9, 0x48(sp)             ; 83 3c 81 04  
    56 : bge  s9, a3, __loops_label_7  ; 63 d4 dc 00  
    57 : j    __loops_label_0          ; 6f f0 5f f5  
    58 :      __loops_label_7:         ;              
    59 : ld   s9, 0x48(sp)             ; 83 3c 81 04  
    60 : bne  a3, s9, __loops_label_10 ; 63 96 96 09  
    61 : ld   s9, 0x40(a0)             ; 83 3c 05 04  
    62 : sd   s9, 0x08(sp)             ; 23 34 91 01  
    63 : ld   s9, 0x30(a0)             ; 83 3c 05 03  
    64 : sd   s9, 0x10(sp)             ; 23 38 91 01  
    65 : ld   s9, 0x38(a0)             ; 83 3c 85 03  
    66 : sd   s9, 0x18(sp)             ; 23 3c 91 01  
    67 :      __loops_label_11:        ;              
    68 : mv   s8, zero                 ; 13 0c 00 00  
    69 : ld   s9, 0x08(sp)             ; 83 3c 81 00  
    70 : bge  s8, s9, __loops_label_10 ; 63 54 9c 07  
    71 : ld   s9, 0x10(sp)             ; 83 3c 01 01  
    72 : lw   s8, 0(s9)                ; 03 ac 0c 00  
    73 : ld   s9, 0x10(sp)             ; 83 3c 01 01  
    74 : addi s9, s9, 0x04             ; 93 8c 4c 00  
    75 : sd   s9, 0x10(sp)             ; 23 38 91 01  
    76 : ld   s9, 0x18(sp)             ; 83 3c 81 01  
    77 : lw   a3, 0(s9)                ; 83 a6 0c 00  
    78 : ld   s9, 0x18(sp)             ; 83 3c 81 01  
    79 : addi s9, s9, 0x04             ; 93 8c 4c 00  
    80 : sd   s9, 0x18(sp)             ; 23 3c 91 01  
    81 : ld   s9, 0x08(sp)             ; 83 3c 81 00  
    82 : addi s9, s9, -0x01            ; 93 8c fc ff  
    83 : sd   s9, 0x08(sp)             ; 23 34 91 01  
    84 : ld   s9, 0x20(sp)             ; 83 3c 01 02  
    85 : bge  s9, s8, __loops_label_15 ; 63 d4 8c 01  
    86 : j    __loops_label_0          ; 6f f0 9f ee  
    87 :      __loops_label_15:        ;              
    88 : ld   s9, 0x20(sp)             ; 83 3c 01 02  
    89 : bne  s8, s9, __loops_label_18 ; 63 1e 9c 01  
    90 : ld   s9, 0(sp)                ; 83 3c 01 00  
    91 : bne  s9, a1, __loops_label_18 ; 63 9a bc 00  
    92 : bne  a3, a2, __loops_label_18 ; 63 98 c6 00  
    93 : addi s9, zero, 0x01           ; 93 0c 10 00  
    94 : sd   s9, 0x28(sp)             ; 23 34 91 03  
    95 : j    __loops_label_2          ; 6f 00 00 01  
    96 :      __loops_label_16:        ;              
    97 :      __loops_label_18:        ;              
    98 : j    __loops_label_11         ; 6f f0 5f f9  
    99 :      __loops_label_13:        ;              
   100 :      __loops_label_8:         ;              
   101 :      __loops_label_10:        ;              
   102 : j    __loops_label_3          ; 6f f0 1f f2  
   103 :      __loops_label_5:         ;              
   104 : j    __loops_label_0          ; 6f f0 df eb  
   105 :      __loops_label_2:         ;              
   106 : ld   s9, 0x28(sp)             ; 83 3c 81 02  
   107 : mv   a0, s9                   ; 13 85 0c 00  
   108 : ld   s8, 0x68(sp)             ; 03 3c 81 06  
   109 : ld   s9, 0x70(sp)             ; 83 3c 01 07  
   110 : ld   s10, 0x78(sp)            ; 03 3d 81 07  
   111 : addi sp, sp, 0x80             ; 13 01 01 08  
   112 : ret                           ; 67 80 00 00  
