has_in_join_cascade(i0, i1, i2)
     0 : addi sp, sp, -0x80            ; 13 01 01 f8  
     1 : sd   s8, 0x68(sp)             ; 23 34 81 07  
     2 : sd   s9, 0x70(sp)             ; 23 38 91 07  
     3 : sd   s10, 0x78(sp)            ; 23 3c a1 07  
     4 : sd   a0, 0x30(sp)             ; 23 38 a1 02  
     5 : sd   a1, 0x28(sp)             ; 23 34 b1 02  
     6 : sd   a2, 0x20(sp)             ; 23 30 c1 02  
     7 : mv   s9, zero                 ; 93 0c 00 00  
     8 : sd   s9, 0(sp)                ; 23 30 91 01  
     9 : ld   s9, 0x30(sp)             ; 83 3c 01 03  
    10 : ld   s10, 0x10(s9)            ; 03 bd 0c 01  
    11 : sd   s10, 0x18(sp)            ; 23 3c a1 01  
    12 : ld   s9, 0x30(sp)             ; 83 3c 01 03  
    13 : ld   s10, 0(s9)               ; 03 bd 0c 00  
    14 : sd   s10, 0x10(sp)            ; 23 38 a1 01  
    15 : ld   s9, 0x30(sp)             ; 83 3c 01 03  
    16 : ld   s10, 0x08(s9)            ; 03 bd 8c 00  
    17 : sd   s10, 0x08(sp)            ; 23 34 a1 01  
    18 :      __loops_label_0:         ;              
    19 : mv   a3, zero                 ; 93 06 00 00  
    20 : ld   s9, 0x18(sp)             ; 83 3c 81 01  
    21 : bge  a3, s9, __loops_label_2  ; 63 dc 96 13  
    22 : ld   s9, 0x10(sp)             ; 83 3c 01 01  
    23 : lw   s10, 0(s9)               ; 03 ad 0c 00  
    24 : sd   s10, 0x58(sp)            ; 23 3c a1 05  
    25 : ld   s9, 0x10(sp)             ; 83 3c 01 01  
    26 : addi s9, s9, 0x04             ; 93 8c 4c 00  
    27 : sd   s9, 0x10(sp)             ; 23 38 91 01  
    28 : ld   s9, 0x08(sp)             ; 83 3c 81 00  
    29 : lw   s10, 0(s9)               ; 03 ad 0c 00  
    30 : sd   s10, 0x50(sp)            ; 23 38 a1 05  
    31 : ld   s9, 0x08(sp)             ; 83 3c 81 00  
    32 : addi s9, s9, 0x04             ; 93 8c 4c 00  
    33 : sd   s9, 0x08(sp)             ; 23 34 91 01  
    34 : ld   s9, 0x18(sp)             ; 83 3c 81 01  
    35 : addi s9, s9, -0x01            ; 93 8c fc ff  
    36 : sd   s9, 0x18(sp)             ; 23 3c 91 01  
    37 : ld   s9, 0x30(sp)             ; 83 3c 01 03  
    38 : ld   s10, 0x28(s9)            ; 03 bd 8c 02  
    39 : sd   s10, 0x48(sp)            ; 23 34 a1 05  
    40 : ld   s9, 0x30(sp)             ; 83 3c 01 03  
    41 : ld   s10, 0x18(s9)            ; 03 bd 8c 01  
    42 : sd   s10, 0x40(sp)            ; 23 30 a1 05  
    43 : ld   s9, 0x30(sp)             ; 83 3c 01 03  
    44 : ld   s10, 0x20(s9)            ; 03 bd 0c 02  
    45 : sd   s10, 0x38(sp)            ; 23 3c a1 03  
    46 :      __loops_label_3:         ;              
    47 : mv   a0, zero                 ; 13 05 00 00  
    48 : ld   s9, 0x48(sp)             ; 83 3c 81 04  
    49 : bge  a0, s9, __loops_label_5  ; 63 54 95 0d  
    50 : ld   s9, 0x40(sp)             ; 83 3c 01 04  
    51 : lw   a0, 0(s9)                ; 03 a5 0c 00  
    52 : ld   s9, 0x40(sp)             ; 83 3c 01 04  
    53 : addi s9, s9, 0x04             ; 93 8c 4c 00  
    54 : sd   s9, 0x40(sp)             ; 23 30 91 05  
    55 : ld   s9, 0x38(sp)             ; 83 3c 81 03  
    56 : lw   a1, 0(s9)                ; 83 a5 0c 00  
    57 : ld   s9, 0x38(sp)             ; 83 3c 81 03  
    58 : addi s9, s9, 0x04             ; 93 8c 4c 00  
    59 : sd   s9, 0x38(sp)             ; 23 3c 91 03  
    60 : ld   s9, 0x48(sp)             ; 83 3c 81 04  
    61 : addi s9, s9, -0x01            ; 93 8c fc ff  
    62 : sd   s9, 0x48(sp)             ; 23 34 91 05  
    63 : ld   s9, 0x58(sp)             ; 83 3c 81 05  
    64 : bge  s9, a1, __loops_label_7  ; 63 d4 bc 00  
    65 : j    __loops_label_3          ; 6f f0 9f fb  
    66 :      __loops_label_7:         ;              
    67 : ld   s9, 0x58(sp)             ; 83 3c 81 05  
    68 : bne  a1, s9, __loops_label_10 ; 63 9e 95 07  
    69 : ld   s9, 0x30(sp)             ; 83 3c 01 03  
    70 : ld   a1, 0x40(s9)             ; 83 b5 0c 04  
    71 : ld   s9, 0x30(sp)             ; 83 3c 01 03  
    72 : ld   a2, 0x30(s9)             ; 03 b6 0c 03  
    73 : ld   s9, 0x30(sp)             ; 83 3c 01 03  
    74 : ld   s10, 0x38(s9)            ; 03 bd 8c 03  
    75 : sd   s10, 0x60(sp)            ; 23 30 a1 07  
    76 :      __loops_label_11:        ;              
    77 : mv   a3, zero                 ; 93 06 00 00  
    78 : bge  a3, a1, __loops_label_10 ; 63 dc b6 04  
    79 : lw   a3, 0(a2)                ; 83 26 06 00  
    80 : addi a2, a2, 0x04             ; 13 06 46 00  
    81 : ld   s9, 0x60(sp)             ; 83 3c 01 06  
    82 : lw   s8, 0(s9)                ; 03 ac 0c 00  
    83 : ld   s9, 0x60(sp)             ; 83 3c 01 06  
    84 : addi s9, s9, 0x04             ; 93 8c 4c 00  
    85 : sd   s9, 0x60(sp)             ; 23 30 91 07  
    86 : addi a1, a1, -0x01            ; 93 85 f5 ff  
    87 : ld   s9, 0x50(sp)             ; 83 3c 01 05  
    88 : bge  s9, a3, __loops_label_15 ; 63 d4 dc 00  
    89 : j    __loops_label_11         ; 6f f0 1f fd  
    90 :      __loops_label_15:        ;              
    91 : ld   s9, 0x50(sp)             ; 83 3c 01 05  
    92 : bne  a3, s9, __loops_label_18 ; 63 90 96 03  
    93 : ld   s9, 0x28(sp)             ; 83 3c 81 02  
    94 : bne  a0, s9, __loops_label_18 ; 63 1c 95 01  
    95 : ld   s9, 0x20(sp)             ; 83 3c 01 02  
    96 : bne  s8, s9, __loops_label_18 ; 63 18 9c 01  
    97 : addi s9, zero, 0x01           ; 93 0c 10 00  
    98 : sd   s9, 0(sp)                ; 23 30 91 01  
    99 : j    __loops_label_2          ; 6f 00 00 01  
   100 :      __loops_label_16:        ;              
   101 :      __loops_label_18:        ;              
   102 : j    __loops_label_11         ; 6f f0 9f fa  
   103 :      __loops_label_13:        ;              
   104 :      __loops_label_8:         ;              
   105 :      __loops_label_10:        ;              
   106 : j    __loops_label_3          ; 6f f0 5f f3  
   107 :      __loops_label_5:         ;              
   108 : j    __loops_label_0          ; 6f f0 5f ec  
   109 :      __loops_label_2:         ;              
   110 : ld   s9, 0(sp)                ; 83 3c 01 00  
   111 : mv   a0, s9                   ; 13 85 0c 00  
   112 : ld   s8, 0x68(sp)             ; 03 3c 81 06  
   113 : ld   s9, 0x70(sp)             ; 83 3c 01 07  
   114 : ld   s10, 0x78(sp)            ; 03 3d 81 07  
   115 : addi sp, sp, 0x80             ; 13 01 01 08  
   116 : ret                           ; 67 80 00 00  
