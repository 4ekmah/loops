nullify_msb_lsb(i0, i1, i2)
     0 : addi sp, sp, -0x10 ; 13 01 01 ff  
     1 : sd   s8, 0(sp)     ; 23 30 81 01  
     2 : srli a3, a0, 0x01  ; 93 56 15 00  
     3 : or   a3, a0, a3    ; b3 66 d5 00  
     4 : srli s8, a3, 0x02  ; 13 dc 26 00  
     5 : or   a3, a3, s8    ; b3 e6 86 01  
     6 : srli s8, a3, 0x04  ; 13 dc 46 00  
     7 : or   a3, a3, s8    ; b3 e6 86 01  
     8 : srli s8, a3, 0x08  ; 13 dc 86 00  
     9 : or   a3, a3, s8    ; b3 e6 86 01  
    10 : srli s8, a3, 0x10  ; 13 dc 06 01  
    11 : or   a3, a3, s8    ; b3 e6 86 01  
    12 : srli s8, a3, 0x20  ; 13 dc 06 02  
    13 : or   a3, a3, s8    ; b3 e6 86 01  
    14 : addi a3, a3, 0x01  ; 93 86 16 00  
    15 : srli a3, a3, 0x01  ; 93 d6 16 00  
    16 : xor  a3, a3, a0    ; b3 c6 a6 00  
    17 : sd   a3, 0(a2)     ; 23 30 d6 00  
    18 : addi a2, a0, -0x01 ; 13 06 f5 ff  
    19 : not  a2, a2        ; 13 46 f6 ff  
    20 : and  a2, a0, a2    ; 33 76 c5 00  
    21 : xor  a0, a2, a0    ; 33 45 a6 00  
    22 : sd   a0, 0(a1)     ; 23 b0 a5 00  
    23 : ld   s8, 0(sp)     ; 03 3c 01 00  
    24 : addi sp, sp, 0x10  ; 13 01 01 01  
    25 : ret                ; 67 80 00 00  
