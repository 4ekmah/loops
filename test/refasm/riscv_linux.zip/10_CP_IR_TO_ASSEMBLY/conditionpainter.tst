conditionpainter(i0)
     0 : addi sp, sp, -0x40           ; 13 01 01 fc  
     1 : sd   s8, 0x28(sp)            ; 23 34 81 03  
     2 : sd   s9, 0x30(sp)            ; 23 38 91 03  
     3 : sd   a0, 0x08(sp)            ; 23 34 a1 00  
     4 : addi s9, zero, -0x05         ; 93 0c b0 ff  
     5 : sd   s9, 0(sp)               ; 23 30 91 01  
     6 :      __loops_label_0:        ;              
     7 : addi a2, zero, 0x05          ; 13 06 50 00  
     8 : ld   s9, 0(sp)               ; 83 3c 01 00  
     9 : blt  a2, s9, __loops_label_2 ; 63 4a 96 27  
    10 : ld   s9, 0(sp)               ; 83 3c 01 00  
    11 : addi a2, s9, 0x05            ; 13 86 5c 00  
    12 : addi a3, zero, 0x0b          ; 93 06 b0 00  
    13 : mul  a2, a2, a3              ; 33 06 d6 02  
    14 : addi a3, zero, 0x08          ; 93 06 80 00  
    15 : mul  s9, a2, a3              ; b3 0c d6 02  
    16 : sd   s9, 0x18(sp)            ; 23 3c 91 01  
    17 : addi s9, zero, -0x05         ; 93 0c b0 ff  
    18 : sd   s9, 0x10(sp)            ; 23 38 91 01  
    19 :      __loops_label_3:        ;              
    20 : addi s8, zero, 0x05          ; 13 0c 50 00  
    21 : ld   s9, 0x10(sp)            ; 83 3c 01 01  
    22 : blt  s8, s9, __loops_label_5 ; 63 4a 9c 23  
    23 : ld   s9, 0x10(sp)            ; 83 3c 01 01  
    24 : addi s8, s9, 0x03            ; 13 8c 3c 00  
    25 : ld   s9, 0(sp)               ; 83 3c 01 00  
    26 : slt  s8, s9, s8              ; 33 ac 8c 01  
    27 : neg  s8, s8                  ; 33 0c 80 41  
    28 : addi s8, s8, 0x01            ; 13 0c 1c 00  
    29 : addi a1, zero, 0x04          ; 93 05 40 00  
    30 : ld   s9, 0(sp)               ; 83 3c 01 00  
    31 : slt  a1, a1, s9              ; b3 a5 95 01  
    32 : neg  a1, a1                  ; b3 05 b0 40  
    33 : addi a1, a1, 0x01            ; 93 85 15 00  
    34 : and  a1, s8, a1              ; b3 75 bc 00  
    35 : addi s8, zero, -0x02         ; 13 0c e0 ff  
    36 : ld   s9, 0x10(sp)            ; 83 3c 01 01  
    37 : slt  s8, s9, s8              ; 33 ac 8c 01  
    38 : neg  s8, s8                  ; 33 0c 80 41  
    39 : addi s8, s8, 0x01            ; 13 0c 1c 00  
    40 : and  a1, a1, s8              ; b3 f5 85 01  
    41 : mv   s8, zero                ; 13 0c 00 00  
    42 : ld   s9, 0x10(sp)            ; 83 3c 01 01  
    43 : slt  s8, s8, s9              ; 33 2c 9c 01  
    44 : neg  s8, s8                  ; 33 0c 80 41  
    45 : addi s8, s8, 0x01            ; 13 0c 1c 00  
    46 : and  a1, a1, s8              ; b3 f5 85 01  
    47 : ld   s9, 0x10(sp)            ; 83 3c 01 01  
    48 : addi s8, s9, -0x01           ; 13 8c fc ff  
    49 : ld   s9, 0(sp)               ; 83 3c 01 00  
    50 : slt  s8, s8, s9              ; 33 2c 9c 01  
    51 : neg  s8, s8                  ; 33 0c 80 41  
    52 : addi s8, s8, 0x01            ; 13 0c 1c 00  
    53 : mv   a0, zero                ; 13 05 00 00  
    54 : ld   s9, 0x10(sp)            ; 83 3c 01 01  
    55 : slt  a0, s9, a0              ; 33 a5 ac 00  
    56 : neg  a0, a0                  ; 33 05 a0 40  
    57 : addi a0, a0, 0x01            ; 13 05 15 00  
    58 : and  a0, s8, a0              ; 33 75 ac 00  
    59 : mv   s8, zero                ; 13 0c 00 00  
    60 : ld   s9, 0(sp)               ; 83 3c 01 00  
    61 : slt  s8, s8, s9              ; 33 2c 9c 01  
    62 : neg  s8, s8                  ; 33 0c 80 41  
    63 : addi s8, s8, 0x01            ; 13 0c 1c 00  
    64 : and  a0, a0, s8              ; 33 75 85 01  
    65 : ld   s9, 0x10(sp)            ; 83 3c 01 01  
    66 : mul  s8, s9, s9              ; 33 8c 9c 03  
    67 : ld   s9, 0(sp)               ; 83 3c 01 00  
    68 : mul  a3, s9, s9              ; b3 86 9c 03  
    69 : add  a3, s8, a3              ; b3 06 dc 00  
    70 : addi s8, zero, 0x09          ; 13 0c 90 00  
    71 : slt  a3, s8, a3              ; b3 26 dc 00  
    72 : neg  a3, a3                  ; b3 06 d0 40  
    73 : addi a3, a3, 0x01            ; 93 86 16 00  
    74 : and  a0, a0, a3              ; 33 75 d5 00  
    75 : or   s9, a1, a0              ; b3 ec a5 00  
    76 : sd   s9, 0x20(sp)            ; 23 30 91 03  
    77 : addi a1, zero, 0x02          ; 93 05 20 00  
    78 : mv   a3, zero                ; 93 06 00 00  
    79 : addi s8, zero, 0x02          ; 13 0c 20 00  
    80 : ld   s9, 0x10(sp)            ; 83 3c 01 01  
    81 : slt  s8, s9, s8              ; 33 ac 8c 01  
    82 : neg  s8, s8                  ; 33 0c 80 41  
    83 : addi s8, s8, 0x01            ; 13 0c 1c 00  
    84 : addi a2, zero, 0x04          ; 13 06 40 00  
    85 : ld   s9, 0x10(sp)            ; 83 3c 01 01  
    86 : slt  a2, a2, s9              ; 33 26 96 01  
    87 : neg  a2, a2                  ; 33 06 c0 40  
    88 : addi a2, a2, 0x01            ; 13 06 16 00  
    89 : and  a2, s8, a2              ; 33 76 cc 00  
    90 : addi s8, zero, 0x01          ; 13 0c 10 00  
    91 : ld   s9, 0(sp)               ; 83 3c 01 00  
    92 : slt  s8, s9, s8              ; 33 ac 8c 01  
    93 : neg  s8, s8                  ; 33 0c 80 41  
    94 : addi s8, s8, 0x01            ; 13 0c 1c 00  
    95 : addi a0, zero, 0x03          ; 13 05 30 00  
    96 : ld   s9, 0(sp)               ; 83 3c 01 00  
    97 : slt  a0, a0, s9              ; 33 25 95 01  
    98 : neg  a0, a0                  ; 33 05 a0 40  
    99 : addi a0, a0, 0x01            ; 13 05 15 00  
   100 : and  a0, s8, a0              ; 33 75 ac 00  
   101 : or   a0, a2, a0              ; 33 65 a6 00  
   102 : ld   s9, 0x10(sp)            ; 83 3c 01 01  
   103 : mul  a2, s9, s9              ; 33 86 9c 03  
   104 : ld   s9, 0(sp)               ; 83 3c 01 00  
   105 : mul  s8, s9, s9              ; 33 8c 9c 03  
   106 : add  a2, a2, s8              ; 33 06 86 01  
   107 : addi s8, zero, 0x10          ; 13 0c 00 01  
   108 : slt  a2, s8, a2              ; 33 26 cc 00  
   109 : neg  a2, a2                  ; 33 06 c0 40  
   110 : addi a2, a2, 0x01            ; 13 06 16 00  
   111 : and  a0, a0, a2              ; 33 75 c5 00  
   112 : mv   a2, zero                ; 13 06 00 00  
   113 : sub  a0, a0, a2              ; 33 05 c5 40  
   114 : snez a0, a0                  ; 33 35 a0 00  
   115 : sub  a1, a1, a3              ; b3 85 d5 40  
   116 : sub  a0, zero, a0            ; 33 05 a0 40  
   117 : and  a0, a0, a1              ; 33 75 b5 00  
   118 : add  a0, a3, a0              ; 33 85 a6 00  
   119 : ld   s9, 0x20(sp)            ; 83 3c 01 02  
   120 : add  a0, s9, a0              ; 33 85 ac 00  
   121 : addi a1, zero, 0x02          ; 93 05 20 00  
   122 : ld   s9, 0(sp)               ; 83 3c 01 00  
   123 : mul  a1, s9, a1              ; b3 85 bc 02  
   124 : ld   s9, 0x10(sp)            ; 83 3c 01 01  
   125 : blt  a1, s9, __loops_label_8 ; 63 c2 95 03  
   126 : ld   s9, 0x10(sp)            ; 83 3c 01 01  
   127 : addi a1, s9, 0x03            ; 93 85 3c 00  
   128 : neg  a1, a1                  ; b3 05 b0 40  
   129 : ld   s9, 0x10(sp)            ; 83 3c 01 01  
   130 : addi a2, s9, 0x03            ; 13 86 3c 00  
   131 : mul  a1, a1, a2              ; b3 85 c5 02  
   132 : ld   s9, 0(sp)               ; 83 3c 01 00  
   133 : bge  a1, s9, __loops_label_9 ; 63 dc 95 03  
   134 :      __loops_label_8:        ;              
   135 : addi a1, zero, 0x02          ; 93 05 20 00  
   136 : ld   s9, 0x10(sp)            ; 83 3c 01 01  
   137 : mul  a1, s9, a1              ; b3 85 bc 02  
   138 : ld   s9, 0(sp)               ; 83 3c 01 00  
   139 : blt  a1, s9, __loops_label_7 ; 63 ca 95 03  
   140 : ld   s9, 0x10(sp)            ; 83 3c 01 01  
   141 : addi a1, s9, 0x03            ; 93 85 3c 00  
   142 : neg  a1, a1                  ; b3 05 b0 40  
   143 : ld   s9, 0x10(sp)            ; 83 3c 01 01  
   144 : addi a2, s9, 0x03            ; 13 86 3c 00  
   145 : mul  a1, a1, a2              ; b3 85 c5 02  
   146 : ld   s9, 0(sp)               ; 83 3c 01 00  
   147 : blt  s9, a1, __loops_label_7 ; 63 ca bc 00  
   148 :      __loops_label_9:        ;              
   149 : mv   a1, zero                ; 93 05 00 00  
   150 : ld   s9, 0x10(sp)            ; 83 3c 01 01  
   151 : blt  a1, s9, __loops_label_7 ; 63 c4 95 01  
   152 : addi a0, a0, 0x03            ; 13 05 35 00  
   153 :      __loops_label_7:        ;              
   154 : ld   s9, 0x10(sp)            ; 83 3c 01 01  
   155 : addi a1, s9, 0x05            ; 93 85 5c 00  
   156 : slli a1, a1, 0x03            ; 93 95 35 00  
   157 : ld   s9, 0x18(sp)            ; 83 3c 81 01  
   158 : add  a1, s9, a1              ; b3 85 bc 00  
   159 : ld   s9, 0x08(sp)            ; 83 3c 81 00  
   160 : add  a1, s9, a1              ; b3 85 bc 00  
   161 : sd   a0, 0(a1)               ; 23 b0 a5 00  
   162 : ld   s9, 0x10(sp)            ; 83 3c 01 01  
   163 : addi s9, s9, 0x01            ; 93 8c 1c 00  
   164 : sd   s9, 0x10(sp)            ; 23 38 91 01  
   165 : j    __loops_label_3         ; 6f f0 9f dc  
   166 :      __loops_label_5:        ;              
   167 : ld   s9, 0(sp)               ; 83 3c 01 00  
   168 : addi s9, s9, 0x01            ; 93 8c 1c 00  
   169 : sd   s9, 0(sp)               ; 23 30 91 01  
   170 : j    __loops_label_0         ; 6f f0 9f d8  
   171 :      __loops_label_2:        ;              
   172 : ld   s8, 0x28(sp)            ; 03 3c 81 02  
   173 : ld   s9, 0x30(sp)            ; 83 3c 01 03  
   174 : addi sp, sp, 0x40            ; 13 01 01 04  
   175 : ret                          ; 67 80 00 00  
