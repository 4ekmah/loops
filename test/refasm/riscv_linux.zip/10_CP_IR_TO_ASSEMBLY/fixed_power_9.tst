fixed_power_9(i0)
     0 : mul a1, a0, a0 ; b3 05 a5 02  
     1 : mul a1, a1, a1 ; b3 85 b5 02  
     2 : mul a1, a1, a1 ; b3 85 b5 02  
     3 : mul a0, a0, a1 ; 33 05 b5 02  
     4 : ret            ; 67 80 00 00  
