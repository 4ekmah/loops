all_loads_all_stores(i0, i1, i2, i3, i4)
     0 : addi sp, sp, -0x50            ; 13 01 01 fb  
     1 : sd   s8, 0x30(sp)             ; 23 38 81 03  
     2 : sd   s9, 0x38(sp)             ; 23 3c 91 03  
     3 : sd   s10, 0x40(sp)            ; 23 30 a1 05  
     4 : sd   a3, 0x20(sp)             ; 23 30 d1 02  
     5 : sd   a4, 0x18(sp)             ; 23 3c e1 00  
     6 : mv   s9, zero                 ; 93 0c 00 00  
     7 : sd   s9, 0x10(sp)             ; 23 38 91 01  
     8 : mv   s9, zero                 ; 93 0c 00 00  
     9 : sd   s9, 0(sp)                ; 23 30 91 01  
    10 : mv   s9, zero                 ; 93 0c 00 00  
    11 : sd   s9, 0x08(sp)             ; 23 34 91 01  
    12 : addi s8, zero, 0x02           ; 13 0c 20 00  
    13 : addi a4, zero, 0x01           ; 13 07 10 00  
    14 : addi a3, zero, 0x01           ; 93 06 10 00  
    15 : slt  a3, a3, a1               ; b3 a6 b6 00  
    16 : sub  s8, s8, a4               ; 33 0c ec 40  
    17 : sub  a3, zero, a3             ; b3 06 d0 40  
    18 : and  a3, a3, s8               ; b3 f6 86 01  
    19 : add  a3, a4, a3               ; b3 06 d7 00  
    20 : addi a4, zero, 0x04           ; 13 07 40 00  
    21 : addi s8, zero, 0x03           ; 13 0c 30 00  
    22 : slt  s8, s8, a1               ; 33 2c bc 00  
    23 : sub  a4, a4, a3               ; 33 07 d7 40  
    24 : sub  s8, zero, s8             ; 33 0c 80 41  
    25 : and  a4, s8, a4               ; 33 77 ec 00  
    26 : add  a3, a3, a4               ; b3 86 e6 00  
    27 : addi a4, zero, 0x08           ; 13 07 80 00  
    28 : addi s8, zero, 0x05           ; 13 0c 50 00  
    29 : slt  s8, s8, a1               ; 33 2c bc 00  
    30 : sub  a4, a4, a3               ; 33 07 d7 40  
    31 : sub  s8, zero, s8             ; 33 0c 80 41  
    32 : and  a4, s8, a4               ; 33 77 ec 00  
    33 : add  s9, a3, a4               ; b3 8c e6 00  
    34 : sd   s9, 0x28(sp)             ; 23 34 91 03  
    35 : addi a4, zero, 0x02           ; 13 07 20 00  
    36 : addi s8, zero, 0x01           ; 13 0c 10 00  
    37 : addi a3, zero, 0x01           ; 93 06 10 00  
    38 : ld   s9, 0x20(sp)             ; 83 3c 01 02  
    39 : slt  a3, a3, s9               ; b3 a6 96 01  
    40 : sub  a4, a4, s8               ; 33 07 87 41  
    41 : sub  a3, zero, a3             ; b3 06 d0 40  
    42 : and  a3, a3, a4               ; b3 f6 e6 00  
    43 : add  a3, s8, a3               ; b3 06 dc 00  
    44 : addi a4, zero, 0x04           ; 13 07 40 00  
    45 : addi s8, zero, 0x03           ; 13 0c 30 00  
    46 : ld   s9, 0x20(sp)             ; 83 3c 01 02  
    47 : slt  s8, s8, s9               ; 33 2c 9c 01  
    48 : sub  a4, a4, a3               ; 33 07 d7 40  
    49 : sub  s8, zero, s8             ; 33 0c 80 41  
    50 : and  a4, s8, a4               ; 33 77 ec 00  
    51 : add  a3, a3, a4               ; b3 86 e6 00  
    52 : addi a4, zero, 0x08           ; 13 07 80 00  
    53 : addi s8, zero, 0x05           ; 13 0c 50 00  
    54 : ld   s9, 0x20(sp)             ; 83 3c 01 02  
    55 : slt  s8, s8, s9               ; 33 2c 9c 01  
    56 : sub  a4, a4, a3               ; 33 07 d7 40  
    57 : sub  s8, zero, s8             ; 33 0c 80 41  
    58 : and  a4, s8, a4               ; 33 77 ec 00  
    59 : add  a3, a3, a4               ; b3 86 e6 00  
    60 :      __loops_label_0:         ;              
    61 : ld   s10, 0x18(sp)            ; 03 3d 81 01  
    62 : ld   s9, 0x10(sp)             ; 83 3c 01 01  
    63 : bge  s9, s10, __loops_label_2 ; 63 da ac 1b  
    64 : mv   s8, zero                 ; 13 0c 00 00  
    65 : bne  a1, s8, __loops_label_4  ; 63 9a 85 01  
    66 : ld   s9, 0(sp)                ; 83 3c 01 00  
    67 : add  s8, a0, s9               ; 33 0c 95 01  
    68 : lbu  a4, 0(s8)                ; 03 47 0c 00  
    69 : j    __loops_label_23         ; 6f 00 00 0a  
    70 :      __loops_label_4:         ;              
    71 : addi s8, zero, 0x01           ; 13 0c 10 00  
    72 : bne  a1, s8, __loops_label_7  ; 63 9a 85 01  
    73 : ld   s9, 0(sp)                ; 83 3c 01 00  
    74 : add  s8, a0, s9               ; 33 0c 95 01  
    75 : lb   a4, 0(s8)                ; 03 07 0c 00  
    76 : j    __loops_label_23         ; 6f 00 80 08  
    77 :      __loops_label_7:         ;              
    78 : addi s8, zero, 0x02           ; 13 0c 20 00  
    79 : bne  a1, s8, __loops_label_10 ; 63 9a 85 01  
    80 : ld   s9, 0(sp)                ; 83 3c 01 00  
    81 : add  s8, a0, s9               ; 33 0c 95 01  
    82 : lhu  a4, 0(s8)                ; 03 57 0c 00  
    83 : j    __loops_label_23         ; 6f 00 00 07  
    84 :      __loops_label_10:        ;              
    85 : addi s8, zero, 0x03           ; 13 0c 30 00  
    86 : bne  a1, s8, __loops_label_13 ; 63 9a 85 01  
    87 : ld   s9, 0(sp)                ; 83 3c 01 00  
    88 : add  s8, a0, s9               ; 33 0c 95 01  
    89 : lh   a4, 0(s8)                ; 03 17 0c 00  
    90 : j    __loops_label_23         ; 6f 00 80 05  
    91 :      __loops_label_13:        ;              
    92 : addi s8, zero, 0x04           ; 13 0c 40 00  
    93 : bne  a1, s8, __loops_label_16 ; 63 9a 85 01  
    94 : ld   s9, 0(sp)                ; 83 3c 01 00  
    95 : add  s8, a0, s9               ; 33 0c 95 01  
    96 : lwu  a4, 0(s8)                ; 03 67 0c 00  
    97 : j    __loops_label_23         ; 6f 00 00 04  
    98 :      __loops_label_16:        ;              
    99 : addi s8, zero, 0x05           ; 13 0c 50 00  
   100 : bne  a1, s8, __loops_label_19 ; 63 9a 85 01  
   101 : ld   s9, 0(sp)                ; 83 3c 01 00  
   102 : add  s8, a0, s9               ; 33 0c 95 01  
   103 : lw   a4, 0(s8)                ; 03 27 0c 00  
   104 : j    __loops_label_23         ; 6f 00 80 02  
   105 :      __loops_label_19:        ;              
   106 : addi s8, zero, 0x06           ; 13 0c 60 00  
   107 : bne  a1, s8, __loops_label_22 ; 63 9a 85 01  
   108 : ld   s9, 0(sp)                ; 83 3c 01 00  
   109 : add  s8, a0, s9               ; 33 0c 95 01  
   110 : ld   a4, 0(s8)                ; 03 37 0c 00  
   111 : j    __loops_label_23         ; 6f 00 00 01  
   112 :      __loops_label_22:        ;              
   113 : ld   s9, 0(sp)                ; 83 3c 01 00  
   114 : add  s8, a0, s9               ; 33 0c 95 01  
   115 : ld   a4, 0(s8)                ; 03 37 0c 00  
   116 :      __loops_label_5:         ;              
   117 :      __loops_label_8:         ;              
   118 :      __loops_label_11:        ;              
   119 :      __loops_label_14:        ;              
   120 :      __loops_label_17:        ;              
   121 :      __loops_label_20:        ;              
   122 :      __loops_label_23:        ;              
   123 : mv   s8, zero                 ; 13 0c 00 00  
   124 : ld   s9, 0x20(sp)             ; 83 3c 01 02  
   125 : bne  s9, s8, __loops_label_25 ; 63 9a 8c 01  
   126 : ld   s9, 0x08(sp)             ; 83 3c 81 00  
   127 : add  s8, a2, s9               ; 33 0c 96 01  
   128 : sb   a4, 0(s8)                ; 23 00 ec 00  
   129 : j    __loops_label_44         ; 6f 00 80 0b  
   130 :      __loops_label_25:        ;              
   131 : addi s8, zero, 0x01           ; 13 0c 10 00  
   132 : ld   s9, 0x20(sp)             ; 83 3c 01 02  
   133 : bne  s9, s8, __loops_label_28 ; 63 9a 8c 01  
   134 : ld   s9, 0x08(sp)             ; 83 3c 81 00  
   135 : add  s8, a2, s9               ; 33 0c 96 01  
   136 : sb   a4, 0(s8)                ; 23 00 ec 00  
   137 : j    __loops_label_44         ; 6f 00 c0 09  
   138 :      __loops_label_28:        ;              
   139 : addi s8, zero, 0x02           ; 13 0c 20 00  
   140 : ld   s9, 0x20(sp)             ; 83 3c 01 02  
   141 : bne  s9, s8, __loops_label_31 ; 63 9a 8c 01  
   142 : ld   s9, 0x08(sp)             ; 83 3c 81 00  
   143 : add  s8, a2, s9               ; 33 0c 96 01  
   144 : sh   a4, 0(s8)                ; 23 10 ec 00  
   145 : j    __loops_label_44         ; 6f 00 00 08  
   146 :      __loops_label_31:        ;              
   147 : addi s8, zero, 0x03           ; 13 0c 30 00  
   148 : ld   s9, 0x20(sp)             ; 83 3c 01 02  
   149 : bne  s9, s8, __loops_label_34 ; 63 9a 8c 01  
   150 : ld   s9, 0x08(sp)             ; 83 3c 81 00  
   151 : add  s8, a2, s9               ; 33 0c 96 01  
   152 : sh   a4, 0(s8)                ; 23 10 ec 00  
   153 : j    __loops_label_44         ; 6f 00 40 06  
   154 :      __loops_label_34:        ;              
   155 : addi s8, zero, 0x04           ; 13 0c 40 00  
   156 : ld   s9, 0x20(sp)             ; 83 3c 01 02  
   157 : bne  s9, s8, __loops_label_37 ; 63 9a 8c 01  
   158 : ld   s9, 0x08(sp)             ; 83 3c 81 00  
   159 : add  s8, a2, s9               ; 33 0c 96 01  
   160 : sw   a4, 0(s8)                ; 23 20 ec 00  
   161 : j    __loops_label_44         ; 6f 00 80 04  
   162 :      __loops_label_37:        ;              
   163 : addi s8, zero, 0x05           ; 13 0c 50 00  
   164 : ld   s9, 0x20(sp)             ; 83 3c 01 02  
   165 : bne  s9, s8, __loops_label_40 ; 63 9a 8c 01  
   166 : ld   s9, 0x08(sp)             ; 83 3c 81 00  
   167 : add  s8, a2, s9               ; 33 0c 96 01  
   168 : sw   a4, 0(s8)                ; 23 20 ec 00  
   169 : j    __loops_label_44         ; 6f 00 c0 02  
   170 :      __loops_label_40:        ;              
   171 : addi s8, zero, 0x06           ; 13 0c 60 00  
   172 : ld   s9, 0x20(sp)             ; 83 3c 01 02  
   173 : bne  s9, s8, __loops_label_43 ; 63 9a 8c 01  
   174 : ld   s9, 0x08(sp)             ; 83 3c 81 00  
   175 : add  s8, a2, s9               ; 33 0c 96 01  
   176 : sd   a4, 0(s8)                ; 23 30 ec 00  
   177 : j    __loops_label_44         ; 6f 00 00 01  
   178 :      __loops_label_43:        ;              
   179 : ld   s9, 0x08(sp)             ; 83 3c 81 00  
   180 : add  s8, a2, s9               ; 33 0c 96 01  
   181 : sd   a4, 0(s8)                ; 23 30 ec 00  
   182 :      __loops_label_26:        ;              
   183 :      __loops_label_29:        ;              
   184 :      __loops_label_32:        ;              
   185 :      __loops_label_35:        ;              
   186 :      __loops_label_38:        ;              
   187 :      __loops_label_41:        ;              
   188 :      __loops_label_44:        ;              
   189 : ld   s9, 0(sp)                ; 83 3c 01 00  
   190 : ld   s10, 0x28(sp)            ; 03 3d 81 02  
   191 : add  s9, s9, s10              ; b3 8c ac 01  
   192 : sd   s9, 0(sp)                ; 23 30 91 01  
   193 : ld   s9, 0x08(sp)             ; 83 3c 81 00  
   194 : add  s9, s9, a3               ; b3 8c dc 00  
   195 : sd   s9, 0x08(sp)             ; 23 34 91 01  
   196 : ld   s9, 0x10(sp)             ; 83 3c 01 01  
   197 : addi s9, s9, 0x01             ; 93 8c 1c 00  
   198 : sd   s9, 0x10(sp)             ; 23 38 91 01  
   199 : j    __loops_label_0          ; 6f f0 9f e4  
   200 :      __loops_label_2:         ;              
   201 : ld   s8, 0x30(sp)             ; 03 3c 01 03  
   202 : ld   s9, 0x38(sp)             ; 83 3c 81 03  
   203 : ld   s10, 0x40(sp)            ; 03 3d 01 04  
   204 : addi sp, sp, 0x50             ; 13 01 01 05  
   205 : ret                           ; 67 80 00 00  
