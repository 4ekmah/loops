sort_double(i0, i1)
     0 : addi sp, sp, -0xd0            ; 13 01 01 f3  
     1 : sd   s8, 0xa8(sp)             ; 23 34 81 0b  
     2 : sd   s9, 0xb0(sp)             ; 23 38 91 0b  
     3 : sd   s10, 0xb8(sp)            ; 23 3c a1 0b  
     4 : sd   fp, 0xc0(sp)             ; 23 30 81 0c  
     5 : sd   ra, 0xc8(sp)             ; 23 34 11 0c  
     6 : sd   a0, 0x98(sp)             ; 23 3c a1 08  
     7 : slli s9, a1, 0x03             ; 93 9c 35 00  
     8 : sd   s9, 0x90(sp)             ; 23 38 91 09  
     9 : ld   s9, 0x90(sp)             ; 83 3c 01 09  
    10 : addi s10, s9, -0x08           ; 13 8d 8c ff  
    11 : sd   s10, 0x88(sp)            ; 23 34 a1 09  
    12 : mv   s9, zero                 ; 93 0c 00 00  
    13 : sd   s9, 0x80(sp)             ; 23 30 91 09  
    14 :      __loops_label_0:         ;              
    15 : ld   s10, 0x88(sp)            ; 03 3d 81 08  
    16 : ld   s9, 0x80(sp)             ; 83 3c 01 08  
    17 : bge  s9, s10, __loops_label_2 ; 63 de ac 13  
    18 : ld   s9, 0x80(sp)             ; 83 3c 01 08  
    19 : mv   s10, s9                  ; 13 8d 0c 00  
    20 : sd   s10, 0xa0(sp)            ; 23 30 a1 0b  
    21 : ld   s9, 0xa0(sp)             ; 83 3c 01 0a  
    22 : addi a3, s9, 0x08             ; 93 86 8c 00  
    23 :      __loops_label_3:         ;              
    24 : ld   s9, 0x90(sp)             ; 83 3c 01 09  
    25 : bge  a3, s9, __loops_label_5  ; 63 d2 96 0d  
    26 : ld   s9, 0x98(sp)             ; 83 3c 81 09  
    27 : add  a2, s9, a3               ; 33 86 dc 00  
    28 : ld   a2, 0(a2)                ; 03 36 06 00  
    29 : ld   s9, 0x98(sp)             ; 83 3c 81 09  
    30 : ld   s10, 0xa0(sp)            ; 03 3d 01 0a  
    31 : add  a1, s9, s10              ; b3 85 ac 01  
    32 : ld   a1, 0(a1)                ; 83 b5 05 00  
    33 : addi a0, zero, 0x2b           ; 13 05 b0 02  
    34 : slli a0, a0, 0x20             ; 13 15 05 02  
    35 : lui  s8, 0xbd8bd              ; 37 dc 8b bd  
    36 : addi s8, s8, -0x7a8           ; 13 0c 8c 85  
    37 : add  a0, a0, s8               ; 33 05 85 01  
    38 : sd   t1, 0(sp)                ; 23 30 61 00  
    39 : sd   t2, 0x08(sp)             ; 23 34 71 00  
    40 : sd   a0, 0x10(sp)             ; 23 38 a1 00  
    41 : sd   a1, 0x18(sp)             ; 23 3c b1 00  
    42 : sd   a2, 0x20(sp)             ; 23 30 c1 02  
    43 : sd   a3, 0x28(sp)             ; 23 34 d1 02  
    44 : sd   a4, 0x30(sp)             ; 23 38 e1 02  
    45 : sd   a5, 0x38(sp)             ; 23 3c f1 02  
    46 : sd   a6, 0x40(sp)             ; 23 30 01 05  
    47 : sd   a7, 0x48(sp)             ; 23 34 11 05  
    48 : sd   t3, 0x50(sp)             ; 23 38 c1 05  
    49 : sd   t4, 0x58(sp)             ; 23 3c d1 05  
    50 : sd   t5, 0x60(sp)             ; 23 30 e1 07  
    51 : sd   t6, 0x68(sp)             ; 23 34 f1 07  
    52 : mv   a0, a2                   ; 13 05 06 00  
    53 : ld   t1, 0x10(sp)             ; 03 33 01 01  
    54 : jalr t1                       ; e7 00 03 00  
    55 : ld   t1, 0(sp)                ; 03 33 01 00  
    56 : ld   t2, 0x08(sp)             ; 83 33 81 00  
    57 : ld   a1, 0x18(sp)             ; 83 35 81 01  
    58 : ld   a2, 0x20(sp)             ; 03 36 01 02  
    59 : ld   a3, 0x28(sp)             ; 83 36 81 02  
    60 : ld   a4, 0x30(sp)             ; 03 37 01 03  
    61 : ld   a5, 0x38(sp)             ; 83 37 81 03  
    62 : ld   a6, 0x40(sp)             ; 03 38 01 04  
    63 : ld   a7, 0x48(sp)             ; 83 38 81 04  
    64 : ld   t3, 0x50(sp)             ; 03 3e 01 05  
    65 : ld   t4, 0x58(sp)             ; 83 3e 81 05  
    66 : ld   t5, 0x60(sp)             ; 03 3f 01 06  
    67 : ld   t6, 0x68(sp)             ; 83 3f 81 06  
    68 : mv   a1, zero                 ; 93 05 00 00  
    69 : beq  a0, a1, __loops_label_7  ; 63 06 b5 00  
    70 : mv   s9, a3                   ; 93 8c 06 00  
    71 : sd   s9, 0xa0(sp)             ; 23 30 91 0b  
    72 :      __loops_label_7:         ;              
    73 : addi a3, a3, 0x08             ; 93 86 86 00  
    74 : j    __loops_label_3          ; 6f f0 df f3  
    75 :      __loops_label_5:         ;              
    76 : ld   s10, 0x80(sp)            ; 03 3d 01 08  
    77 : ld   s9, 0xa0(sp)             ; 83 3c 01 0a  
    78 : beq  s9, s10, __loops_label_9 ; 63 82 ac 05  
    79 : ld   s9, 0x98(sp)             ; 83 3c 81 09  
    80 : ld   s10, 0x80(sp)            ; 03 3d 01 08  
    81 : add  a0, s9, s10              ; 33 85 ac 01  
    82 : ld   a0, 0(a0)                ; 03 35 05 00  
    83 : ld   s9, 0x98(sp)             ; 83 3c 81 09  
    84 : ld   s10, 0xa0(sp)            ; 03 3d 01 0a  
    85 : add  a1, s9, s10              ; b3 85 ac 01  
    86 : ld   a1, 0(a1)                ; 83 b5 05 00  
    87 : ld   s9, 0x98(sp)             ; 83 3c 81 09  
    88 : ld   s10, 0xa0(sp)            ; 03 3d 01 0a  
    89 : add  a2, s9, s10              ; 33 86 ac 01  
    90 : sd   a0, 0(a2)                ; 23 30 a6 00  
    91 : ld   s9, 0x98(sp)             ; 83 3c 81 09  
    92 : ld   s10, 0x80(sp)            ; 03 3d 01 08  
    93 : add  a0, s9, s10              ; 33 85 ac 01  
    94 : sd   a1, 0(a0)                ; 23 30 b5 00  
    95 :      __loops_label_9:         ;              
    96 : ld   s9, 0x80(sp)             ; 83 3c 01 08  
    97 : addi s9, s9, 0x08             ; 93 8c 8c 00  
    98 : sd   s9, 0x80(sp)             ; 23 30 91 09  
    99 : j    __loops_label_0          ; 6f f0 1f ec  
   100 :      __loops_label_2:         ;              
   101 : ld   fp, 0xc0(sp)             ; 03 34 01 0c  
   102 : ld   ra, 0xc8(sp)             ; 83 30 81 0c  
   103 : ld   s8, 0xa8(sp)             ; 03 3c 81 0a  
   104 : ld   s9, 0xb0(sp)             ; 83 3c 01 0b  
   105 : ld   s10, 0xb8(sp)            ; 03 3d 81 0b  
   106 : addi sp, sp, 0xd0             ; 13 01 01 0d  
   107 : ret                           ; 67 80 00 00  
