instruction_set_test()
     0 : mv   zero, zero         ; 13 00 00 00  
     1 : mv   t6, zero           ; 93 0f 00 00  
     2 : mv   zero, t6           ; 13 80 0f 00  
     3 : mv   zero, zero         ; 13 00 00 00  
     4 : mv   t6, zero           ; 93 0f 00 00  
     5 : addi zero, zero, 0x01   ; 13 00 10 00  
     6 : addi t6, zero, 0x01     ; 93 0f 10 00  
     7 : addi zero, zero, 0x7ff  ; 13 00 f0 7f  
     8 : addi zero, zero, -0x800 ; 13 00 00 80  
     9 : lui  zero, 0            ; 37 00 00 00  
    10 : lui  t6, 0              ; b7 0f 00 00  
    11 : lui  zero, 0xfffff      ; 37 f0 ff ff  
    12 : add  zero, zero, zero   ; 33 00 00 00  
    13 : add  t6, zero, zero     ; b3 0f 00 00  
    14 : add  zero, t6, zero     ; 33 80 0f 00  
    15 : add  zero, zero, t6     ; 33 00 f0 01  
    16 : addi zero, zero, 0      ; 13 00 00 00  
    17 : addi t6, zero, 0        ; 93 0f 00 00  
    18 : addi zero, t6, 0        ; 13 80 0f 00  
    19 : addi zero, zero, 0x7ff  ; 13 00 f0 7f  
    20 : addi zero, zero, -0x800 ; 13 00 00 80  
    21 : sub  zero, zero, zero   ; 33 00 00 40  
    22 : sub  t6, zero, zero     ; b3 0f 00 40  
    23 : sub  zero, t6, zero     ; 33 80 0f 40  
    24 : sub  zero, zero, t6     ; 33 00 f0 41  
    25 : addi zero, zero, 0      ; 13 00 00 00  
    26 : addi t6, zero, 0        ; 93 0f 00 00  
    27 : addi zero, t6, 0        ; 13 80 0f 00  
    28 : addi zero, zero, -0x800 ; 13 00 00 80  
    29 : addi zero, zero, 0x7ff  ; 13 00 f0 7f  
    30 : neg  zero, zero         ; 33 00 00 40  
    31 : neg  t6, zero           ; b3 0f 00 40  
    32 : neg  zero, t6           ; 33 00 f0 41  
    33 : sll  zero, zero, zero   ; 33 10 00 00  
    34 : sll  t6, zero, zero     ; b3 1f 00 00  
    35 : sll  zero, t6, zero     ; 33 90 0f 00  
    36 : sll  zero, zero, t6     ; 33 10 f0 01  
    37 : slli zero, zero, 0      ; 13 10 00 00  
    38 : slli t6, zero, 0        ; 93 1f 00 00  
    39 : slli zero, t6, 0        ; 13 90 0f 00  
    40 : slli zero, zero, 0x3f   ; 13 10 f0 03  
    41 : srl  zero, zero, zero   ; 33 50 00 00  
    42 : srl  t6, zero, zero     ; b3 5f 00 00  
    43 : srl  zero, t6, zero     ; 33 d0 0f 00  
    44 : srl  zero, zero, t6     ; 33 50 f0 01  
    45 : srli zero, zero, 0      ; 13 50 00 00  
    46 : srli t6, zero, 0        ; 93 5f 00 00  
    47 : srli zero, t6, 0        ; 13 d0 0f 00  
    48 : srli zero, zero, 0x3f   ; 13 50 f0 03  
    49 : sra  zero, zero, zero   ; 33 50 00 40  
    50 : sra  t6, zero, zero     ; b3 5f 00 40  
    51 : sra  zero, t6, zero     ; 33 d0 0f 40  
    52 : sra  zero, zero, t6     ; 33 50 f0 41  
    53 : srai zero, zero, 0      ; 13 50 00 40  
    54 : srai t6, zero, 0        ; 93 5f 00 40  
    55 : srai zero, t6, 0        ; 13 d0 0f 40  
    56 : srai zero, zero, 0x3f   ; 13 50 f0 43  
    57 : mul  zero, zero, zero   ; 33 00 00 02  
    58 : mul  t6, zero, zero     ; b3 0f 00 02  
    59 : mul  zero, t6, zero     ; 33 80 0f 02  
    60 : mul  zero, zero, t6     ; 33 00 f0 03  
    61 : div  zero, zero, zero   ; 33 40 00 02  
    62 : div  t6, zero, zero     ; b3 4f 00 02  
    63 : div  zero, t6, zero     ; 33 c0 0f 02  
    64 : div  zero, zero, t6     ; 33 40 f0 03  
    65 : rem  zero, zero, zero   ; 33 60 00 02  
    66 : rem  t6, zero, zero     ; b3 6f 00 02  
    67 : rem  zero, t6, zero     ; 33 e0 0f 02  
    68 : rem  zero, zero, t6     ; 33 60 f0 03  
    69 : xor  zero, zero, zero   ; 33 40 00 00  
    70 : xor  t6, zero, zero     ; b3 4f 00 00  
    71 : xor  zero, t6, zero     ; 33 c0 0f 00  
    72 : xor  zero, zero, t6     ; 33 40 f0 01  
    73 : xori zero, zero, 0      ; 13 40 00 00  
    74 : xori t6, zero, 0        ; 93 4f 00 00  
    75 : xori zero, t6, 0        ; 13 c0 0f 00  
    76 : xori zero, zero, 0x7ff  ; 13 40 f0 7f  
    77 : xori zero, zero, -0x800 ; 13 40 00 80  
    78 : or   zero, zero, zero   ; 33 60 00 00  
    79 : or   t6, zero, zero     ; b3 6f 00 00  
    80 : or   zero, t6, zero     ; 33 e0 0f 00  
    81 : or   zero, zero, t6     ; 33 60 f0 01  
    82 : ori  zero, zero, 0      ; 13 60 00 00  
    83 : ori  t6, zero, 0        ; 93 6f 00 00  
    84 : ori  zero, t6, 0        ; 13 e0 0f 00  
    85 : ori  zero, zero, 0x7ff  ; 13 60 f0 7f  
    86 : ori  zero, zero, -0x800 ; 13 60 00 80  
    87 : and  zero, zero, zero   ; 33 70 00 00  
    88 : and  t6, zero, zero     ; b3 7f 00 00  
    89 : and  zero, t6, zero     ; 33 f0 0f 00  
    90 : and  zero, zero, t6     ; 33 70 f0 01  
    91 : andi zero, zero, 0      ; 13 70 00 00  
    92 : andi t6, zero, 0        ; 93 7f 00 00  
    93 : andi zero, t6, 0        ; 13 f0 0f 00  
    94 : andi zero, zero, 0x7ff  ; 13 70 f0 7f  
    95 : andi zero, zero, -0x800 ; 13 70 00 80  
    96 : not  zero, zero         ; 13 40 f0 ff  
    97 : not  t6, zero           ; 93 4f f0 ff  
    98 : not  zero, t6           ; 13 c0 ff ff  
    99 : lb   zero, 0(zero)      ; 03 00 00 00  
   100 : lb   t6, 0(zero)        ; 83 0f 00 00  
   101 : lb   zero, 0(t6)        ; 03 80 0f 00  
   102 : lb   zero, 0(zero)      ; 03 00 00 00  
   103 : lb   t6, 0(zero)        ; 83 0f 00 00  
   104 : lb   zero, 0(t6)        ; 03 80 0f 00  
   105 : lb   zero, 0x7ff(zero)  ; 03 00 f0 7f  
   106 : lb   zero, -0x800(zero) ; 03 00 00 80  
   107 : lbu  zero, 0(zero)      ; 03 40 00 00  
   108 : lbu  t6, 0(zero)        ; 83 4f 00 00  
   109 : lbu  zero, 0(t6)        ; 03 c0 0f 00  
   110 : lbu  zero, 0(zero)      ; 03 40 00 00  
   111 : lbu  t6, 0(zero)        ; 83 4f 00 00  
   112 : lbu  zero, 0(t6)        ; 03 c0 0f 00  
   113 : lbu  zero, 0x7ff(zero)  ; 03 40 f0 7f  
   114 : lbu  zero, -0x800(zero) ; 03 40 00 80  
   115 : lh   zero, 0(zero)      ; 03 10 00 00  
   116 : lh   t6, 0(zero)        ; 83 1f 00 00  
   117 : lh   zero, 0(t6)        ; 03 90 0f 00  
   118 : lh   zero, 0(zero)      ; 03 10 00 00  
   119 : lh   t6, 0(zero)        ; 83 1f 00 00  
   120 : lh   zero, 0(t6)        ; 03 90 0f 00  
   121 : lh   zero, 0x7ff(zero)  ; 03 10 f0 7f  
   122 : lh   zero, -0x800(zero) ; 03 10 00 80  
   123 : lhu  zero, 0(zero)      ; 03 50 00 00  
   124 : lhu  t6, 0(zero)        ; 83 5f 00 00  
   125 : lhu  zero, 0(t6)        ; 03 d0 0f 00  
   126 : lhu  zero, 0(zero)      ; 03 50 00 00  
   127 : lhu  t6, 0(zero)        ; 83 5f 00 00  
   128 : lhu  zero, 0(t6)        ; 03 d0 0f 00  
   129 : lhu  zero, 0x7ff(zero)  ; 03 50 f0 7f  
   130 : lhu  zero, -0x800(zero) ; 03 50 00 80  
   131 : lw   zero, 0(zero)      ; 03 20 00 00  
   132 : lw   t6, 0(zero)        ; 83 2f 00 00  
   133 : lw   zero, 0(t6)        ; 03 a0 0f 00  
   134 : lw   zero, 0(zero)      ; 03 20 00 00  
   135 : lw   t6, 0(zero)        ; 83 2f 00 00  
   136 : lw   zero, 0(t6)        ; 03 a0 0f 00  
   137 : lw   zero, 0x7ff(zero)  ; 03 20 f0 7f  
   138 : lw   zero, -0x800(zero) ; 03 20 00 80  
   139 : lwu  zero, 0(zero)      ; 03 60 00 00  
   140 : lwu  t6, 0(zero)        ; 83 6f 00 00  
   141 : lwu  zero, 0(t6)        ; 03 e0 0f 00  
   142 : lwu  zero, 0(zero)      ; 03 60 00 00  
   143 : lwu  t6, 0(zero)        ; 83 6f 00 00  
   144 : lwu  zero, 0(t6)        ; 03 e0 0f 00  
   145 : lwu  zero, 0x7ff(zero)  ; 03 60 f0 7f  
   146 : lwu  zero, -0x800(zero) ; 03 60 00 80  
   147 : ld   zero, 0(zero)      ; 03 30 00 00  
   148 : ld   t6, 0(zero)        ; 83 3f 00 00  
   149 : ld   zero, 0(t6)        ; 03 b0 0f 00  
   150 : ld   zero, 0(zero)      ; 03 30 00 00  
   151 : ld   t6, 0(zero)        ; 83 3f 00 00  
   152 : ld   zero, 0(t6)        ; 03 b0 0f 00  
   153 : ld   zero, 0x7ff(zero)  ; 03 30 f0 7f  
   154 : ld   zero, -0x800(zero) ; 03 30 00 80  
   155 : sb   zero, 0(zero)      ; 23 00 00 00  
   156 : sb   zero, 0(t6)        ; 23 80 0f 00  
   157 : sb   t6, 0(zero)        ; 23 00 f0 01  
   158 : sb   zero, 0(zero)      ; 23 00 00 00  
   159 : sb   zero, 0(t6)        ; 23 80 0f 00  
   160 : sb   t6, 0(zero)        ; 23 00 f0 01  
   161 : sb   zero, 0x7ff(zero)  ; a3 0f 00 7e  
   162 : sb   zero, -0x800(zero) ; 23 00 00 80  
   163 : sh   zero, 0(zero)      ; 23 10 00 00  
   164 : sh   zero, 0(t6)        ; 23 90 0f 00  
   165 : sh   t6, 0(zero)        ; 23 10 f0 01  
   166 : sh   zero, 0(zero)      ; 23 10 00 00  
   167 : sh   zero, 0(t6)        ; 23 90 0f 00  
   168 : sh   t6, 0(zero)        ; 23 10 f0 01  
   169 : sh   zero, 0x7ff(zero)  ; a3 1f 00 7e  
   170 : sh   zero, -0x800(zero) ; 23 10 00 80  
   171 : sw   zero, 0(zero)      ; 23 20 00 00  
   172 : sw   zero, 0(t6)        ; 23 a0 0f 00  
   173 : sw   t6, 0(zero)        ; 23 20 f0 01  
   174 : sw   zero, 0(zero)      ; 23 20 00 00  
   175 : sw   zero, 0(t6)        ; 23 a0 0f 00  
   176 : sw   t6, 0(zero)        ; 23 20 f0 01  
   177 : sw   zero, 0x7ff(zero)  ; a3 2f 00 7e  
   178 : sw   zero, -0x800(zero) ; 23 20 00 80  
   179 : sd   zero, 0(zero)      ; 23 30 00 00  
   180 : sd   zero, 0(t6)        ; 23 b0 0f 00  
   181 : sd   t6, 0(zero)        ; 23 30 f0 01  
   182 : sd   zero, 0(zero)      ; 23 30 00 00  
   183 : sd   zero, 0(t6)        ; 23 b0 0f 00  
   184 : sd   t6, 0(zero)        ; 23 30 f0 01  
   185 : sd   zero, 0x7ff(zero)  ; a3 3f 00 7e  
   186 : sd   zero, -0x800(zero) ; 23 30 00 80  
   187 : slt  zero, zero, zero   ; 33 20 00 00  
   188 : slt  t6, zero, zero     ; b3 2f 00 00  
   189 : slt  zero, t6, zero     ; 33 a0 0f 00  
   190 : slt  zero, zero, t6     ; 33 20 f0 01  
   191 : sltu zero, zero, zero   ; 33 30 00 00  
   192 : sltu t6, zero, zero     ; b3 3f 00 00  
   193 : sltu zero, zero, t6     ; 33 30 f0 01  
   194 : sltu zero, t6, zero     ; 33 b0 0f 00  
   195 : seqz zero, zero         ; 13 30 10 00  
   196 : seqz t6, zero           ; 93 3f 10 00  
   197 : seqz zero, t6           ; 13 b0 1f 00  
   198 : snez zero, zero         ; 33 30 00 00  
   199 : snez t6, zero           ; b3 3f 00 00  
   200 : snez zero, t6           ; 33 30 f0 01  
   201 : jalr zero               ; e7 00 00 00  
   202 : jalr t6                 ; e7 80 0f 00  
