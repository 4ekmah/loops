nonnegative_odd(i0, i1)
     0 : addi sp, sp, -0x20           ; 13 01 01 fe  
     1 : sd   s8, 0x08(sp)            ; 23 34 81 01  
     2 : sd   s9, 0x10(sp)            ; 23 38 91 01  
     3 : mv   a2, zero                ; 13 06 00 00  
     4 : addi s9, zero, -0x04         ; 93 0c c0 ff  
     5 : sd   s9, 0(sp)               ; 23 30 91 01  
     6 : addi s8, zero, 0x04          ; 13 0c 40 00  
     7 : mul  a1, a1, s8              ; b3 85 85 03  
     8 :      __loops_label_0:        ;              
     9 : bge  a2, a1, __loops_label_2 ; 63 50 b6 04  
    10 : add  s8, a0, a2              ; 33 0c c5 00  
    11 : lw   s8, 0(s8)               ; 03 2c 0c 00  
    12 : mv   a3, zero                ; 93 06 00 00  
    13 : bge  s8, a3, __loops_label_4 ; 63 56 dc 00  
    14 : addi a2, a2, 0x04            ; 13 06 46 00  
    15 : j    __loops_label_0         ; 6f f0 9f fe  
    16 :      __loops_label_4:        ;              
    17 : addi a3, zero, 0x02          ; 93 06 20 00  
    18 : rem  a3, s8, a3              ; b3 66 dc 02  
    19 : mv   s8, zero                ; 13 0c 00 00  
    20 : beq  a3, s8, __loops_label_6 ; 63 88 86 01  
    21 : mv   s9, a2                  ; 93 0c 06 00  
    22 : sd   s9, 0(sp)               ; 23 30 91 01  
    23 : j    __loops_label_2         ; 6f 00 c0 00  
    24 :      __loops_label_6:        ;              
    25 : addi a2, a2, 0x04            ; 13 06 46 00  
    26 : j    __loops_label_0         ; 6f f0 5f fc  
    27 :      __loops_label_2:        ;              
    28 : addi a0, zero, 0x04          ; 13 05 40 00  
    29 : ld   s9, 0(sp)               ; 83 3c 01 00  
    30 : div  a0, s9, a0              ; 33 c5 ac 02  
    31 : ld   s8, 0x08(sp)            ; 03 3c 81 00  
    32 : ld   s9, 0x10(sp)            ; 83 3c 01 01  
    33 : addi sp, sp, 0x20            ; 13 01 01 02  
    34 : ret                          ; 67 80 00 00  
