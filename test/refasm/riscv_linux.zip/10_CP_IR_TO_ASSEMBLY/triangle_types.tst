triangle_types(i0, i1, i2)
     0 : addi sp, sp, -0x20            ; 13 01 01 fe  
     1 : sd   s8, 0x08(sp)             ; 23 34 81 01  
     2 : sd   s9, 0x10(sp)             ; 23 38 91 01  
     3 : sd   a1, 0(sp)                ; 23 30 b1 00  
     4 : mv   a3, zero                 ; 93 06 00 00  
     5 : bge  a3, a0, __loops_label_0  ; 63 dc a6 00  
     6 : mv   a3, zero                 ; 93 06 00 00  
     7 : ld   s9, 0(sp)                ; 83 3c 01 00  
     8 : bge  a3, s9, __loops_label_0  ; 63 d6 96 01  
     9 : mv   a3, zero                 ; 93 06 00 00  
    10 : blt  a3, a2, __loops_label_1  ; 63 c6 c6 00  
    11 :      __loops_label_0:         ;              
    12 : mv   a0, zero                 ; 13 05 00 00  
    13 : j    __loops_label_18         ; 6f 00 80 10  
    14 :      __loops_label_1:         ;              
    15 : ld   s9, 0(sp)                ; 83 3c 01 00  
    16 : add  a3, s9, a2               ; b3 86 cc 00  
    17 : blt  a3, a0, __loops_label_3  ; 63 ce a6 00  
    18 : add  a3, a0, a2               ; b3 06 c5 00  
    19 : ld   s9, 0(sp)                ; 83 3c 01 00  
    20 : blt  a3, s9, __loops_label_3  ; 63 c8 96 01  
    21 : ld   s9, 0(sp)                ; 83 3c 01 00  
    22 : add  a3, a0, s9               ; b3 06 95 01  
    23 : bge  a3, a2, __loops_label_4  ; 63 d6 c6 00  
    24 :      __loops_label_3:         ;              
    25 : mv   a0, zero                 ; 13 05 00 00  
    26 : j    __loops_label_18         ; 6f 00 c0 0d  
    27 :      __loops_label_4:         ;              
    28 : ld   s9, 0(sp)                ; 83 3c 01 00  
    29 : bne  a0, s9, __loops_label_7  ; 63 18 95 01  
    30 : bne  a0, a2, __loops_label_7  ; 63 16 c5 00  
    31 : addi a0, zero, 0x02           ; 13 05 20 00  
    32 : j    __loops_label_18         ; 6f 00 80 0c  
    33 :      __loops_label_7:         ;              
    34 : ld   s9, 0(sp)                ; 83 3c 01 00  
    35 : beq  a0, s9, __loops_label_9  ; 63 08 95 01  
    36 : beq  a0, a2, __loops_label_9  ; 63 06 c5 00  
    37 : ld   s9, 0(sp)                ; 83 3c 01 00  
    38 : bne  s9, a2, __loops_label_10 ; 63 96 cc 00  
    39 :      __loops_label_9:         ;              
    40 : addi a0, zero, 0x03           ; 13 05 30 00  
    41 : j    __loops_label_18         ; 6f 00 c0 0a  
    42 :      __loops_label_10:        ;              
    43 : mul  a3, a0, a0               ; b3 06 a5 02  
    44 : ld   s9, 0(sp)                ; 83 3c 01 00  
    45 : mul  s8, s9, s9               ; 33 8c 9c 03  
    46 : mul  a1, a2, a2               ; b3 05 c6 02  
    47 : add  a1, s8, a1               ; b3 05 bc 00  
    48 : beq  a3, a1, __loops_label_12 ; 63 8a b6 02  
    49 : ld   s9, 0(sp)                ; 83 3c 01 00  
    50 : mul  a1, s9, s9               ; b3 85 9c 03  
    51 : mul  a3, a0, a0               ; b3 06 a5 02  
    52 : mul  s8, a2, a2               ; 33 0c c6 02  
    53 : add  a3, a3, s8               ; b3 86 86 01  
    54 : beq  a1, a3, __loops_label_12 ; 63 8e d5 00  
    55 : mul  a1, a2, a2               ; b3 05 c6 02  
    56 : mul  a3, a0, a0               ; b3 06 a5 02  
    57 : ld   s9, 0(sp)                ; 83 3c 01 00  
    58 : mul  s8, s9, s9               ; 33 8c 9c 03  
    59 : add  a3, a3, s8               ; b3 86 86 01  
    60 : bne  a1, a3, __loops_label_13 ; 63 96 d5 00  
    61 :      __loops_label_12:        ;              
    62 : addi a0, zero, 0x01           ; 13 05 10 00  
    63 : j    __loops_label_18         ; 6f 00 c0 05  
    64 :      __loops_label_13:        ;              
    65 : mul  a1, a0, a0               ; b3 05 a5 02  
    66 : ld   s9, 0(sp)                ; 83 3c 01 00  
    67 : mul  a3, s9, s9               ; b3 86 9c 03  
    68 : mul  s8, a2, a2               ; 33 0c c6 02  
    69 : add  a3, a3, s8               ; b3 86 86 01  
    70 : blt  a3, a1, __loops_label_15 ; 63 ca b6 02  
    71 : ld   s9, 0(sp)                ; 83 3c 01 00  
    72 : mul  a1, s9, s9               ; b3 85 9c 03  
    73 : mul  a3, a0, a0               ; b3 06 a5 02  
    74 : mul  s8, a2, a2               ; 33 0c c6 02  
    75 : add  a3, a3, s8               ; b3 86 86 01  
    76 : blt  a3, a1, __loops_label_15 ; 63 ce b6 00  
    77 : mul  a1, a2, a2               ; b3 05 c6 02  
    78 : mul  a0, a0, a0               ; 33 05 a5 02  
    79 : ld   s9, 0(sp)                ; 83 3c 01 00  
    80 : mul  a2, s9, s9               ; 33 86 9c 03  
    81 : add  a0, a0, a2               ; 33 05 c5 00  
    82 : bge  a0, a1, __loops_label_16 ; 63 56 b5 00  
    83 :      __loops_label_15:        ;              
    84 : addi a0, zero, 0x05           ; 13 05 50 00  
    85 : j    __loops_label_18         ; 6f 00 c0 00  
    86 :      __loops_label_16:        ;              
    87 : addi a0, zero, 0x04           ; 13 05 40 00  
    88 : j    __loops_label_18         ; 6f 00 40 00  
    89 :      __loops_label_2:         ;              
    90 :      __loops_label_5:         ;              
    91 :      __loops_label_8:         ;              
    92 :      __loops_label_11:        ;              
    93 :      __loops_label_14:        ;              
    94 :      __loops_label_17:        ;              
    95 :      __loops_label_18:        ;              
    96 : ld   s8, 0x08(sp)             ; 03 3c 81 00  
    97 : ld   s9, 0x10(sp)             ; 83 3c 01 01  
    98 : addi sp, sp, 0x20             ; 13 01 01 02  
    99 : ret                           ; 67 80 00 00  
