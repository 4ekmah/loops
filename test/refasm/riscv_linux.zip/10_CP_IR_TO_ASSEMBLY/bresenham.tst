bresenham(i0, i1, i2, i3, i4, i5, i6)
     0 : addi sp, sp, -0x50            ; 13 01 01 fb  
     1 : sd   s8, 0x28(sp)             ; 23 34 81 03  
     2 : sd   s9, 0x30(sp)             ; 23 38 91 03  
     3 : sd   s10, 0x38(sp)            ; 23 3c a1 03  
     4 : sd   s11, 0x40(sp)            ; 23 30 b1 05  
     5 : sd   a6, 0(sp)                ; 23 30 01 01  
     6 : sub  s8, a4, a2               ; 33 0c c7 40  
     7 : slt  a6, zero, s8             ; 33 28 80 01  
     8 : sub  a6, zero, a6             ; 33 08 00 41  
     9 : and  a6, a6, s8               ; 33 78 88 01  
    10 : sub  s8, zero, s8             ; 33 0c 80 41  
    11 : add  s8, s8, a6               ; 33 0c 0c 01  
    12 : add  s9, s8, a6               ; b3 0c 0c 01  
    13 : sd   s9, 0x08(sp)             ; 23 34 91 01  
    14 : sub  s8, a4, a2               ; 33 0c c7 40  
    15 : slt  a6, s8, zero             ; 33 28 0c 00  
    16 : slt  s8, zero, s8             ; 33 2c 80 01  
    17 : sub  s9, s8, a6               ; b3 0c 0c 41  
    18 : sd   s9, 0x10(sp)             ; 23 38 91 01  
    19 : sub  s8, a5, a3               ; 33 8c d7 40  
    20 : slt  a6, zero, s8             ; 33 28 80 01  
    21 : sub  a6, zero, a6             ; 33 08 00 41  
    22 : and  a6, a6, s8               ; 33 78 88 01  
    23 : sub  s8, zero, s8             ; 33 0c 80 41  
    24 : add  s8, s8, a6               ; 33 0c 0c 01  
    25 : add  a6, s8, a6               ; 33 08 0c 01  
    26 : neg  s9, a6                   ; b3 0c 00 41  
    27 : sd   s9, 0x18(sp)             ; 23 3c 91 01  
    28 : sub  s8, a5, a3               ; 33 8c d7 40  
    29 : slt  a6, s8, zero             ; 33 28 0c 00  
    30 : slt  s8, zero, s8             ; 33 2c 80 01  
    31 : sub  a6, s8, a6               ; 33 08 0c 41  
    32 : ld   s9, 0x08(sp)             ; 83 3c 81 00  
    33 : ld   s10, 0x18(sp)            ; 03 3d 81 01  
    34 : add  s11, s9, s10             ; b3 8d ac 01  
    35 : sd   s11, 0x20(sp)            ; 23 30 b1 03  
    36 :      __loops_label_0:         ;              
    37 : mv   s8, zero                 ; 13 0c 00 00  
    38 : beq  a0, s8, __loops_label_2  ; 63 0e 85 07  
    39 : mul  s8, a3, a1               ; 33 8c b6 02  
    40 : add  s8, s8, a2               ; 33 0c cc 00  
    41 : add  s8, a0, s8               ; 33 0c 85 01  
    42 : ld   s9, 0(sp)                ; 83 3c 01 00  
    43 : sb   s9, 0(s8)                ; 23 00 9c 01  
    44 : bne  a2, a4, __loops_label_4  ; 63 16 e6 00  
    45 : bne  a3, a5, __loops_label_4  ; 63 94 f6 00  
    46 : j    __loops_label_2          ; 6f 00 c0 05  
    47 :      __loops_label_4:         ;              
    48 : ld   s9, 0x20(sp)             ; 83 3c 01 02  
    49 : slli s8, s9, 0x01             ; 13 9c 1c 00  
    50 : ld   s9, 0x18(sp)             ; 83 3c 81 01  
    51 : blt  s8, s9, __loops_label_6  ; 63 42 9c 03  
    52 : bne  a2, a4, __loops_label_8  ; 63 14 e6 00  
    53 : j    __loops_label_2          ; 6f 00 40 04  
    54 :      __loops_label_8:         ;              
    55 : ld   s10, 0x18(sp)            ; 03 3d 81 01  
    56 : ld   s9, 0x20(sp)             ; 83 3c 01 02  
    57 : add  s9, s9, s10              ; b3 8c ac 01  
    58 : sd   s9, 0x20(sp)             ; 23 30 91 03  
    59 : ld   s9, 0x10(sp)             ; 83 3c 01 01  
    60 : add  a2, a2, s9               ; 33 06 96 01  
    61 :      __loops_label_6:         ;              
    62 : ld   s9, 0x08(sp)             ; 83 3c 81 00  
    63 : blt  s9, s8, __loops_label_10 ; 63 c0 8c 03  
    64 : bne  a3, a5, __loops_label_12 ; 63 94 f6 00  
    65 : j    __loops_label_2          ; 6f 00 c0 01  
    66 :      __loops_label_12:        ;              
    67 : ld   s10, 0x08(sp)            ; 03 3d 81 00  
    68 : ld   s9, 0x20(sp)             ; 83 3c 01 02  
    69 : add  s9, s9, s10              ; b3 8c ac 01  
    70 : sd   s9, 0x20(sp)             ; 23 30 91 03  
    71 : add  a3, a3, a6               ; b3 86 06 01  
    72 :      __loops_label_10:        ;              
    73 : j    __loops_label_0          ; 6f f0 5f f8  
    74 :      __loops_label_2:         ;              
    75 : ld   s8, 0x28(sp)             ; 03 3c 81 02  
    76 : ld   s9, 0x30(sp)             ; 83 3c 01 03  
    77 : ld   s10, 0x38(sp)            ; 03 3d 81 03  
    78 : ld   s11, 0x40(sp)            ; 83 3d 01 04  
    79 : addi sp, sp, 0x50             ; 13 01 01 05  
    80 : ret                           ; 67 80 00 00  
