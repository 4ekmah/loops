fixed_power_1(i0)
     0 : ret  ; 67 80 00 00  
