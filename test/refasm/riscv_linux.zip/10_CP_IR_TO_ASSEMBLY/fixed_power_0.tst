fixed_power_0(i0)
     0 : addi a0, zero, 0x01 ; 13 05 10 00  
     1 : ret                 ; 67 80 00 00  
