ten_args_to_sum(i0, i1, i2, i3, i4, i5, i6, i7, i8, i9)
     0 : addi sp, sp, -0x10  ; 13 01 01 ff  
     1 : sd   s8, 0(sp)      ; 23 30 81 01  
     2 : sd   s9, 0x08(sp)   ; 23 34 91 01  
     3 : addi s8, zero, 0x01 ; 13 0c 10 00  
     4 : mul  a0, a0, s8     ; 33 05 85 03  
     5 : addi s8, zero, 0x02 ; 13 0c 20 00  
     6 : mul  a1, a1, s8     ; b3 85 85 03  
     7 : add  a0, a0, a1     ; 33 05 b5 00  
     8 : addi a1, zero, 0x03 ; 93 05 30 00  
     9 : mul  a1, a2, a1     ; b3 05 b6 02  
    10 : add  a0, a0, a1     ; 33 05 b5 00  
    11 : addi a1, zero, 0x04 ; 93 05 40 00  
    12 : mul  a1, a3, a1     ; b3 85 b6 02  
    13 : add  a0, a0, a1     ; 33 05 b5 00  
    14 : addi a1, zero, 0x05 ; 93 05 50 00  
    15 : mul  a1, a4, a1     ; b3 05 b7 02  
    16 : add  a0, a0, a1     ; 33 05 b5 00  
    17 : addi a1, zero, 0x06 ; 93 05 60 00  
    18 : mul  a1, a5, a1     ; b3 85 b7 02  
    19 : add  a0, a0, a1     ; 33 05 b5 00  
    20 : addi a1, zero, 0x07 ; 93 05 70 00  
    21 : mul  a1, a6, a1     ; b3 05 b8 02  
    22 : add  a0, a0, a1     ; 33 05 b5 00  
    23 : addi a1, zero, 0x08 ; 93 05 80 00  
    24 : mul  a1, a7, a1     ; b3 85 b8 02  
    25 : add  a0, a0, a1     ; 33 05 b5 00  
    26 : addi a1, zero, 0x03 ; 93 05 30 00  
    27 : ld   s9, 0x10(sp)   ; 83 3c 01 01  
    28 : mul  a1, s9, a1     ; b3 85 bc 02  
    29 : add  a0, a0, a1     ; 33 05 b5 00  
    30 : addi a1, zero, 0x02 ; 93 05 20 00  
    31 : ld   s9, 0x18(sp)   ; 83 3c 81 01  
    32 : mul  a1, s9, a1     ; b3 85 bc 02  
    33 : add  a0, a0, a1     ; 33 05 b5 00  
    34 : ld   s8, 0(sp)      ; 03 3c 01 00  
    35 : ld   s9, 0x08(sp)   ; 83 3c 81 00  
    36 : addi sp, sp, 0x10   ; 13 01 01 01  
    37 : ret                 ; 67 80 00 00  
