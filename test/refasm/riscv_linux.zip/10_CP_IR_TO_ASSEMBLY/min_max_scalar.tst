min_max_scalar(i0, i1, i2, i3)
     0 : addi sp, sp, -0x40           ; 13 01 01 fc  
     1 : sd   s8, 0x28(sp)            ; 23 34 81 03  
     2 : sd   s9, 0x30(sp)            ; 23 38 91 03  
     3 : sd   a2, 0x08(sp)            ; 23 34 c1 00  
     4 : sd   a3, 0(sp)               ; 23 30 d1 00  
     5 : mv   s8, zero                ; 13 0c 00 00  
     6 : mv   s9, zero                ; 93 0c 00 00  
     7 : sd   s9, 0x18(sp)            ; 23 3c 91 01  
     8 : mv   s9, zero                ; 93 0c 00 00  
     9 : sd   s9, 0x10(sp)            ; 23 38 91 01  
    10 : lw   a2, 0(a0)               ; 03 26 05 00  
    11 : mv   s9, a2                  ; 93 0c 06 00  
    12 : sd   s9, 0x20(sp)            ; 23 30 91 03  
    13 : addi a3, zero, 0x04          ; 93 06 40 00  
    14 : mul  a1, a1, a3              ; b3 85 d5 02  
    15 :      __loops_label_0:        ;              
    16 : bge  s8, a1, __loops_label_2 ; 63 5e bc 02  
    17 : add  a3, a0, s8              ; b3 06 85 01  
    18 : lw   a3, 0(a3)               ; 83 a6 06 00  
    19 : bge  a3, a2, __loops_label_4 ; 63 d8 c6 00  
    20 : mv   a2, a3                  ; 13 86 06 00  
    21 : mv   s9, s8                  ; 93 0c 0c 00  
    22 : sd   s9, 0x18(sp)            ; 23 3c 91 01  
    23 :      __loops_label_4:        ;              
    24 : ld   s9, 0x20(sp)            ; 83 3c 01 02  
    25 : bge  s9, a3, __loops_label_6 ; 63 da dc 00  
    26 : mv   s9, a3                  ; 93 8c 06 00  
    27 : sd   s9, 0x20(sp)            ; 23 30 91 03  
    28 : mv   s9, s8                  ; 93 0c 0c 00  
    29 : sd   s9, 0x10(sp)            ; 23 38 91 01  
    30 :      __loops_label_6:        ;              
    31 : addi s8, s8, 0x04            ; 13 0c 4c 00  
    32 : j    __loops_label_0         ; 6f f0 9f fc  
    33 :      __loops_label_2:        ;              
    34 : addi a0, zero, 0x04          ; 13 05 40 00  
    35 : ld   s9, 0x18(sp)            ; 83 3c 81 01  
    36 : div  a1, s9, a0              ; b3 c5 ac 02  
    37 : ld   s9, 0x10(sp)            ; 83 3c 01 01  
    38 : div  a0, s9, a0              ; 33 c5 ac 02  
    39 : ld   s9, 0x08(sp)            ; 83 3c 81 00  
    40 : sw   a1, 0(s9)               ; 23 a0 bc 00  
    41 : ld   s9, 0(sp)               ; 83 3c 01 00  
    42 : sw   a0, 0(s9)               ; 23 a0 ac 00  
    43 : mv   a0, zero                ; 13 05 00 00  
    44 : ld   s8, 0x28(sp)            ; 03 3c 81 02  
    45 : ld   s9, 0x30(sp)            ; 83 3c 01 03  
    46 : addi sp, sp, 0x40            ; 13 01 01 04  
    47 : ret                          ; 67 80 00 00  
