min_max_select(i0, i1, i2, i3)
     0 : addi sp, sp, -0x50           ; 13 01 01 fb  
     1 : sd   s8, 0x38(sp)            ; 23 3c 81 03  
     2 : sd   s9, 0x40(sp)            ; 23 30 91 05  
     3 : sd   s10, 0x48(sp)           ; 23 34 a1 05  
     4 : sd   a2, 0x08(sp)            ; 23 34 c1 00  
     5 : sd   a3, 0(sp)               ; 23 30 d1 00  
     6 : mv   s8, zero                ; 13 0c 00 00  
     7 : mv   s9, zero                ; 93 0c 00 00  
     8 : sd   s9, 0x18(sp)            ; 23 3c 91 01  
     9 : mv   s9, zero                ; 93 0c 00 00  
    10 : sd   s9, 0x10(sp)            ; 23 38 91 01  
    11 : lw   s9, 0(a0)               ; 83 2c 05 00  
    12 : sd   s9, 0x30(sp)            ; 23 38 91 03  
    13 : ld   s9, 0x30(sp)            ; 83 3c 01 03  
    14 : mv   s10, s9                 ; 13 8d 0c 00  
    15 : sd   s10, 0x28(sp)           ; 23 34 a1 03  
    16 : slli s9, a1, 0x02            ; 93 9c 25 00  
    17 : sd   s9, 0x20(sp)            ; 23 30 91 03  
    18 :      __loops_label_0:        ;              
    19 : ld   s9, 0x20(sp)            ; 83 3c 01 02  
    20 : bge  s8, s9, __loops_label_2 ; 63 50 9c 0b  
    21 : add  a1, a0, s8              ; b3 05 85 01  
    22 : lw   a1, 0(a1)               ; 83 a5 05 00  
    23 : ld   s9, 0x30(sp)            ; 83 3c 01 03  
    24 : slt  a3, a1, s9              ; b3 a6 95 01  
    25 : ld   s9, 0x18(sp)            ; 83 3c 81 01  
    26 : sub  a2, s8, s9              ; 33 06 9c 41  
    27 : sub  a3, zero, a3            ; b3 06 d0 40  
    28 : and  a2, a3, a2              ; 33 f6 c6 00  
    29 : ld   s9, 0x18(sp)            ; 83 3c 81 01  
    30 : add  s9, s9, a2              ; b3 8c cc 00  
    31 : sd   s9, 0x18(sp)            ; 23 3c 91 01  
    32 : ld   s9, 0x30(sp)            ; 83 3c 01 03  
    33 : slt  a2, a1, s9              ; 33 a6 95 01  
    34 : ld   s9, 0x30(sp)            ; 83 3c 01 03  
    35 : sub  a3, a1, s9              ; b3 86 95 41  
    36 : sub  a2, zero, a2            ; 33 06 c0 40  
    37 : and  a2, a2, a3              ; 33 76 d6 00  
    38 : ld   s9, 0x30(sp)            ; 83 3c 01 03  
    39 : add  s9, s9, a2              ; b3 8c cc 00  
    40 : sd   s9, 0x30(sp)            ; 23 38 91 03  
    41 : ld   s9, 0x28(sp)            ; 83 3c 81 02  
    42 : slt  a2, s9, a1              ; 33 a6 bc 00  
    43 : ld   s9, 0x10(sp)            ; 83 3c 01 01  
    44 : sub  a3, s8, s9              ; b3 06 9c 41  
    45 : sub  a2, zero, a2            ; 33 06 c0 40  
    46 : and  a2, a2, a3              ; 33 76 d6 00  
    47 : ld   s9, 0x10(sp)            ; 83 3c 01 01  
    48 : add  s9, s9, a2              ; b3 8c cc 00  
    49 : sd   s9, 0x10(sp)            ; 23 38 91 01  
    50 : ld   s9, 0x28(sp)            ; 83 3c 81 02  
    51 : slt  a2, a1, s9              ; 33 a6 95 01  
    52 : ld   s9, 0x28(sp)            ; 83 3c 81 02  
    53 : sub  a3, s9, a1              ; b3 86 bc 40  
    54 : sub  a2, zero, a2            ; 33 06 c0 40  
    55 : and  a2, a2, a3              ; 33 76 d6 00  
    56 : add  s9, a1, a2              ; b3 8c c5 00  
    57 : sd   s9, 0x28(sp)            ; 23 34 91 03  
    58 : addi s8, s8, 0x04            ; 13 0c 4c 00  
    59 : j    __loops_label_0         ; 6f f0 1f f6  
    60 :      __loops_label_2:        ;              
    61 : ld   s9, 0x18(sp)            ; 83 3c 81 01  
    62 : srai a0, s9, 0x02            ; 13 d5 2c 40  
    63 : ld   s9, 0x10(sp)            ; 83 3c 01 01  
    64 : srai a1, s9, 0x02            ; 93 d5 2c 40  
    65 : ld   s9, 0x08(sp)            ; 83 3c 81 00  
    66 : sw   a0, 0(s9)               ; 23 a0 ac 00  
    67 : ld   s9, 0(sp)               ; 83 3c 01 00  
    68 : sw   a1, 0(s9)               ; 23 a0 bc 00  
    69 : mv   a0, zero                ; 13 05 00 00  
    70 : ld   s8, 0x38(sp)            ; 03 3c 81 03  
    71 : ld   s9, 0x40(sp)            ; 83 3c 01 04  
    72 : ld   s10, 0x48(sp)           ; 03 3d 81 04  
    73 : addi sp, sp, 0x50            ; 13 01 01 05  
    74 : ret                          ; 67 80 00 00  
