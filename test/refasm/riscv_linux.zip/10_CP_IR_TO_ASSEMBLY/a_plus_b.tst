a_plus_b(i0, i1)
     0 : add a0, a0, a1 ; 33 05 b5 00  
     1 : ret            ; 67 80 00 00  
