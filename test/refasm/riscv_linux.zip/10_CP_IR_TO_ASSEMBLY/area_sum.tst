area_sum(i0, i1)
     0 : addi sp, sp, -0xc0           ; 13 01 01 f4  
     1 : sd   s8, 0xa0(sp)            ; 23 30 81 0b  
     2 : sd   s9, 0xa8(sp)            ; 23 34 91 0b  
     3 : sd   s10, 0xb0(sp)           ; 23 38 a1 0b  
     4 : sd   fp, 0xb0(sp)            ; 23 38 81 0a  
     5 : sd   ra, 0xb8(sp)            ; 23 3c 11 0a  
     6 : sd   a0, 0x90(sp)            ; 23 38 a1 08  
     7 : sd   a1, 0x88(sp)            ; 23 34 b1 08  
     8 : mv   s9, zero                ; 93 0c 00 00  
     9 : sd   s9, 0x80(sp)            ; 23 30 91 09  
    10 :      __loops_label_0:        ;              
    11 : mv   a3, zero                ; 93 06 00 00  
    12 : ld   s9, 0x88(sp)            ; 83 3c 81 08  
    13 : bge  a3, s9, __loops_label_2 ; 63 d6 96 2b  
    14 : ld   s9, 0x90(sp)            ; 83 3c 01 09  
    15 : lb   a3, 0(s9)               ; 83 86 0c 00  
    16 : addi s8, zero, 0x2b          ; 13 0c b0 02  
    17 : slli s8, s8, 0x20            ; 13 1c 0c 02  
    18 : lui  a2, 0xbd8bd             ; 37 d6 8b bd  
    19 : addi a2, a2, -0x230          ; 13 06 06 dd  
    20 : add  a2, s8, a2              ; 33 06 cc 00  
    21 : addi s8, zero, 0x2b          ; 13 0c b0 02  
    22 : slli s8, s8, 0x20            ; 13 1c 0c 02  
    23 : lui  a1, 0xbd8bd             ; b7 d5 8b bd  
    24 : addi a1, a1, -0x2d4          ; 93 85 c5 d2  
    25 : add  a1, s8, a1              ; b3 05 bc 00  
    26 : addi s8, zero, 0x2b          ; 13 0c b0 02  
    27 : slli s8, s8, 0x20            ; 13 1c 0c 02  
    28 : lui  a0, 0xbd8bd             ; 37 d5 8b bd  
    29 : addi a0, a0, -0x166          ; 13 05 a5 e9  
    30 : add  a0, s8, a0              ; 33 05 ac 00  
    31 : addi s8, zero, 0x01          ; 13 0c 10 00  
    32 : sub  s8, a3, s8              ; 33 8c 86 41  
    33 : seqz s8, s8                  ; 13 3c 1c 00  
    34 : sub  a1, a1, a0              ; b3 85 a5 40  
    35 : sub  s8, zero, s8            ; 33 0c 80 41  
    36 : and  a1, s8, a1              ; b3 75 bc 00  
    37 : add  a0, a0, a1              ; 33 05 b5 00  
    38 : mv   a1, zero                ; 93 05 00 00  
    39 : sub  a1, a3, a1              ; b3 85 b6 40  
    40 : seqz a1, a1                  ; 93 b5 15 00  
    41 : sub  a2, a2, a0              ; 33 06 a6 40  
    42 : sub  a1, zero, a1            ; b3 05 b0 40  
    43 : and  a1, a1, a2              ; b3 f5 c5 00  
    44 : add  s9, a0, a1              ; b3 0c b5 00  
    45 : sd   s9, 0x98(sp)            ; 23 3c 91 09  
    46 : addi a1, zero, 0x2b          ; 93 05 b0 02  
    47 : slli a1, a1, 0x20            ; 93 95 05 02  
    48 : lui  a2, 0xbd8bd             ; 37 d6 8b bd  
    49 : addi a2, a2, -0x788          ; 13 06 86 87  
    50 : add  a1, a1, a2              ; b3 85 c5 00  
    51 : addi a2, zero, 0x2b          ; 13 06 b0 02  
    52 : slli a2, a2, 0x20            ; 13 16 06 02  
    53 : lui  s8, 0xbd8bd             ; 37 dc 8b bd  
    54 : addi s8, s8, -0x766          ; 13 0c ac 89  
    55 : add  a2, a2, s8              ; 33 06 86 01  
    56 : addi s8, zero, 0x2b          ; 13 0c b0 02  
    57 : slli s8, s8, 0x20            ; 13 1c 0c 02  
    58 : lui  a0, 0xbd8bd             ; 37 d5 8b bd  
    59 : addi a0, a0, -0x74e          ; 13 05 25 8b  
    60 : add  a0, s8, a0              ; 33 05 ac 00  
    61 : addi s8, zero, 0x01          ; 13 0c 10 00  
    62 : sub  s8, a3, s8              ; 33 8c 86 41  
    63 : seqz s8, s8                  ; 13 3c 1c 00  
    64 : sub  a2, a2, a0              ; 33 06 a6 40  
    65 : sub  s8, zero, s8            ; 33 0c 80 41  
    66 : and  a2, s8, a2              ; 33 76 cc 00  
    67 : add  a0, a0, a2              ; 33 05 c5 00  
    68 : mv   a2, zero                ; 13 06 00 00  
    69 : sub  a2, a3, a2              ; 33 86 c6 40  
    70 : seqz a2, a2                  ; 13 36 16 00  
    71 : sub  a1, a1, a0              ; b3 85 a5 40  
    72 : sub  a2, zero, a2            ; 33 06 c0 40  
    73 : and  a1, a2, a1              ; b3 75 b6 00  
    74 : add  a0, a0, a1              ; 33 05 b5 00  
    75 : ld   s10, 0x90(sp)           ; 03 3d 01 09  
    76 : ld   s9, 0x98(sp)            ; 83 3c 81 09  
    77 : sd   t1, 0(sp)               ; 23 30 61 00  
    78 : sd   t2, 0x08(sp)            ; 23 34 71 00  
    79 : sd   a0, 0x10(sp)            ; 23 38 a1 00  
    80 : sd   a1, 0x18(sp)            ; 23 3c b1 00  
    81 : sd   a2, 0x20(sp)            ; 23 30 c1 02  
    82 : sd   a3, 0x28(sp)            ; 23 34 d1 02  
    83 : sd   a4, 0x30(sp)            ; 23 38 e1 02  
    84 : sd   a5, 0x38(sp)            ; 23 3c f1 02  
    85 : sd   a6, 0x40(sp)            ; 23 30 01 05  
    86 : sd   a7, 0x48(sp)            ; 23 34 11 05  
    87 : sd   t3, 0x50(sp)            ; 23 38 c1 05  
    88 : sd   t4, 0x58(sp)            ; 23 3c d1 05  
    89 : sd   t5, 0x60(sp)            ; 23 30 e1 07  
    90 : sd   t6, 0x68(sp)            ; 23 34 f1 07  
    91 : mv   a0, s10                 ; 13 05 0d 00  
    92 : jalr s9                      ; e7 80 0c 00  
    93 : ld   t1, 0(sp)               ; 03 33 01 00  
    94 : ld   t2, 0x08(sp)            ; 83 33 81 00  
    95 : ld   a0, 0x10(sp)            ; 03 35 01 01  
    96 : ld   a1, 0x18(sp)            ; 83 35 81 01  
    97 : ld   a2, 0x20(sp)            ; 03 36 01 02  
    98 : ld   a3, 0x28(sp)            ; 83 36 81 02  
    99 : ld   a4, 0x30(sp)            ; 03 37 01 03  
   100 : ld   a5, 0x38(sp)            ; 83 37 81 03  
   101 : ld   a6, 0x40(sp)            ; 03 38 01 04  
   102 : ld   a7, 0x48(sp)            ; 83 38 81 04  
   103 : ld   t3, 0x50(sp)            ; 03 3e 01 05  
   104 : ld   t4, 0x58(sp)            ; 83 3e 81 05  
   105 : ld   t5, 0x60(sp)            ; 03 3f 01 06  
   106 : ld   t6, 0x68(sp)            ; 83 3f 81 06  
   107 : ld   s9, 0x90(sp)            ; 83 3c 01 09  
   108 : sd   t1, 0(sp)               ; 23 30 61 00  
   109 : sd   t2, 0x08(sp)            ; 23 34 71 00  
   110 : sd   a0, 0x10(sp)            ; 23 38 a1 00  
   111 : sd   a1, 0x18(sp)            ; 23 3c b1 00  
   112 : sd   a2, 0x20(sp)            ; 23 30 c1 02  
   113 : sd   a3, 0x28(sp)            ; 23 34 d1 02  
   114 : sd   a4, 0x30(sp)            ; 23 38 e1 02  
   115 : sd   a5, 0x38(sp)            ; 23 3c f1 02  
   116 : sd   a6, 0x40(sp)            ; 23 30 01 05  
   117 : sd   a7, 0x48(sp)            ; 23 34 11 05  
   118 : sd   t3, 0x50(sp)            ; 23 38 c1 05  
   119 : sd   t4, 0x58(sp)            ; 23 3c d1 05  
   120 : sd   t5, 0x60(sp)            ; 23 30 e1 07  
   121 : sd   t6, 0x68(sp)            ; 23 34 f1 07  
   122 : mv   a0, s9                  ; 13 85 0c 00  
   123 : ld   t1, 0x10(sp)            ; 03 33 01 01  
   124 : jalr t1                      ; e7 00 03 00  
   125 : ld   t1, 0(sp)               ; 03 33 01 00  
   126 : ld   t2, 0x08(sp)            ; 83 33 81 00  
   127 : ld   a1, 0x18(sp)            ; 83 35 81 01  
   128 : ld   a2, 0x20(sp)            ; 03 36 01 02  
   129 : ld   a3, 0x28(sp)            ; 83 36 81 02  
   130 : ld   a4, 0x30(sp)            ; 03 37 01 03  
   131 : ld   a5, 0x38(sp)            ; 83 37 81 03  
   132 : ld   a6, 0x40(sp)            ; 03 38 01 04  
   133 : ld   a7, 0x48(sp)            ; 83 38 81 04  
   134 : ld   t3, 0x50(sp)            ; 03 3e 01 05  
   135 : ld   t4, 0x58(sp)            ; 83 3e 81 05  
   136 : ld   t5, 0x60(sp)            ; 03 3f 01 06  
   137 : ld   t6, 0x68(sp)            ; 83 3f 81 06  
   138 : addi a1, zero, 0x2b          ; 93 05 b0 02  
   139 : slli a1, a1, 0x20            ; 93 95 05 02  
   140 : lui  a2, 0xbd8bd             ; 37 d6 8b bd  
   141 : addi a2, a2, -0x79a          ; 13 06 66 86  
   142 : add  a1, a1, a2              ; b3 85 c5 00  
   143 : ld   s9, 0x80(sp)            ; 83 3c 01 08  
   144 : sd   t1, 0(sp)               ; 23 30 61 00  
   145 : sd   t2, 0x08(sp)            ; 23 34 71 00  
   146 : sd   a0, 0x10(sp)            ; 23 38 a1 00  
   147 : sd   a1, 0x18(sp)            ; 23 3c b1 00  
   148 : sd   a2, 0x20(sp)            ; 23 30 c1 02  
   149 : sd   a3, 0x28(sp)            ; 23 34 d1 02  
   150 : sd   a4, 0x30(sp)            ; 23 38 e1 02  
   151 : sd   a5, 0x38(sp)            ; 23 3c f1 02  
   152 : sd   a6, 0x40(sp)            ; 23 30 01 05  
   153 : sd   a7, 0x48(sp)            ; 23 34 11 05  
   154 : sd   t3, 0x50(sp)            ; 23 38 c1 05  
   155 : sd   t4, 0x58(sp)            ; 23 3c d1 05  
   156 : sd   t5, 0x60(sp)            ; 23 30 e1 07  
   157 : sd   t6, 0x68(sp)            ; 23 34 f1 07  
   158 : mv   a0, s9                  ; 13 85 0c 00  
   159 : ld   a1, 0x10(sp)            ; 83 35 01 01  
   160 : ld   t1, 0x18(sp)            ; 03 33 81 01  
   161 : jalr t1                      ; e7 00 03 00  
   162 : ld   t1, 0(sp)               ; 03 33 01 00  
   163 : ld   t2, 0x08(sp)            ; 83 33 81 00  
   164 : ld   a1, 0x18(sp)            ; 83 35 81 01  
   165 : ld   a2, 0x20(sp)            ; 03 36 01 02  
   166 : ld   a3, 0x28(sp)            ; 83 36 81 02  
   167 : ld   a4, 0x30(sp)            ; 03 37 01 03  
   168 : ld   a5, 0x38(sp)            ; 83 37 81 03  
   169 : ld   a6, 0x40(sp)            ; 03 38 01 04  
   170 : ld   a7, 0x48(sp)            ; 83 38 81 04  
   171 : ld   t3, 0x50(sp)            ; 03 3e 01 05  
   172 : ld   t4, 0x58(sp)            ; 83 3e 81 05  
   173 : ld   t5, 0x60(sp)            ; 03 3f 01 06  
   174 : ld   t6, 0x68(sp)            ; 83 3f 81 06  
   175 : mv   s9, a0                  ; 93 0c 05 00  
   176 : sd   s9, 0x80(sp)            ; 23 30 91 09  
   177 : ld   s9, 0x90(sp)            ; 83 3c 01 09  
   178 : addi s9, s9, 0x38            ; 93 8c 8c 03  
   179 : sd   s9, 0x90(sp)            ; 23 38 91 09  
   180 : ld   s9, 0x88(sp)            ; 83 3c 81 08  
   181 : addi s9, s9, -0x01           ; 93 8c fc ff  
   182 : sd   s9, 0x88(sp)            ; 23 34 91 09  
   183 : j    __loops_label_0         ; 6f f0 1f d5  
   184 :      __loops_label_2:        ;              
   185 : ld   s9, 0x80(sp)            ; 83 3c 01 08  
   186 : mv   a0, s9                  ; 13 85 0c 00  
   187 : ld   fp, 0xb0(sp)            ; 03 34 01 0b  
   188 : ld   ra, 0xb8(sp)            ; 83 30 81 0b  
   189 : ld   s8, 0xa0(sp)            ; 03 3c 01 0a  
   190 : ld   s9, 0xa8(sp)            ; 83 3c 81 0a  
   191 : ld   s10, 0xb0(sp)           ; 03 3d 01 0b  
   192 : addi sp, sp, 0xc0            ; 13 01 01 0c  
   193 : ret                          ; 67 80 00 00  
