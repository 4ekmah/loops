big_immediates(i0)
     0 : lui  a1, 0x01        ; b7 15 00 00  
     1 : addi a1, a1, 0       ; 93 85 05 00  
     2 : sd   a1, 0(a0)       ; 23 30 b5 00  
     3 : addi a0, a0, 0x08    ; 13 05 85 00  
     4 : lui  a1, 0x02        ; b7 25 00 00  
     5 : addi a1, a1, -0x01   ; 93 85 f5 ff  
     6 : sd   a1, 0(a0)       ; 23 30 b5 00  
     7 : addi a0, a0, 0x08    ; 13 05 85 00  
     8 : lui  a1, 0x80000     ; b7 05 00 80  
     9 : xori a1, a1, -0x556  ; 93 c5 a5 aa  
    10 : sd   a1, 0(a0)       ; 23 30 b5 00  
    11 : addi a0, a0, 0x08    ; 13 05 85 00  
    12 : addi a1, zero, 0x01  ; 93 05 10 00  
    13 : slli a1, a1, 0x20    ; 93 95 05 02  
    14 : mv   a2, zero        ; 13 06 00 00  
    15 : add  a1, a1, a2      ; b3 85 c5 00  
    16 : sd   a1, 0(a0)       ; 23 30 b5 00  
    17 : addi a0, a0, 0x08    ; 13 05 85 00  
    18 : addi a1, zero, 0x02  ; 93 05 20 00  
    19 : slli a1, a1, 0x20    ; 93 95 05 02  
    20 : addi a2, zero, -0x01 ; 13 06 f0 ff  
    21 : add  a1, a1, a2      ; b3 85 c5 00  
    22 : sd   a1, 0(a0)       ; 23 30 b5 00  
    23 : addi a0, a0, 0x08    ; 13 05 85 00  
    24 : addi a1, zero, 0x01  ; 93 05 10 00  
    25 : slli a1, a1, 0x3f    ; 93 95 f5 03  
    26 : lui  a2, 0xaaaab     ; 37 b6 aa aa  
    27 : addi a2, a2, -0x556  ; 13 06 a6 aa  
    28 : xor  a1, a1, a2      ; b3 c5 c5 00  
    29 : sd   a1, 0(a0)       ; 23 30 b5 00  
    30 : addi a0, a0, 0x08    ; 13 05 85 00  
    31 : lui  a1, 0x10        ; b7 05 01 00  
    32 : addi a1, a1, -0x01   ; 93 85 f5 ff  
    33 : sd   a1, 0(a0)       ; 23 30 b5 00  
    34 : addi a0, a0, 0x08    ; 13 05 85 00  
    35 : lui  a1, 0x10        ; b7 05 01 00  
    36 : addi a1, a1, 0       ; 93 85 05 00  
    37 : sd   a1, 0(a0)       ; 23 30 b5 00  
    38 : addi a0, a0, 0x08    ; 13 05 85 00  
    39 : lui  a1, 0xffff8     ; b7 85 ff ff  
    40 : addi a1, a1, 0       ; 93 85 05 00  
    41 : sd   a1, 0(a0)       ; 23 30 b5 00  
    42 : addi a0, a0, 0x08    ; 13 05 85 00  
    43 : lui  a1, 0xffff8     ; b7 85 ff ff  
    44 : addi a1, a1, -0x01   ; 93 85 f5 ff  
    45 : sd   a1, 0(a0)       ; 23 30 b5 00  
    46 : addi a0, a0, 0x08    ; 13 05 85 00  
    47 : lui  a1, 0x5f376     ; b7 65 37 5f  
    48 : addi a1, a1, -0x621  ; 93 85 f5 9d  
    49 : sd   a1, 0(a0)       ; 23 30 b5 00  
    50 : addi a0, a0, 0x08    ; 13 05 85 00  
    51 : lui  a1, 0x4005c     ; b7 c5 05 40  
    52 : addi a1, a1, -0xf5   ; 93 85 b5 f0  
    53 : slli a1, a1, 0x20    ; 93 95 05 02  
    54 : lui  a2, 0x8b145     ; 37 56 14 8b  
    55 : addi a2, a2, 0x769   ; 13 06 96 76  
    56 : add  a1, a1, a2      ; b3 85 c5 00  
    57 : sd   a1, 0(a0)       ; 23 30 b5 00  
    58 : addi a0, a0, 0x08    ; 13 05 85 00  
    59 : ret                  ; 67 80 00 00  
