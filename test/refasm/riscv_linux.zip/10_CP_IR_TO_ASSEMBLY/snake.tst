snake(i0, i1, i2)
     0 : addi sp, sp, -0xf0            ; 13 01 01 f1  
     1 : sd   s8, 0xc8(sp)             ; 23 34 81 0d  
     2 : sd   s9, 0xd0(sp)             ; 23 38 91 0d  
     3 : sd   s10, 0xd8(sp)            ; 23 3c a1 0d  
     4 : sd   fp, 0xe0(sp)             ; 23 30 81 0e  
     5 : sd   ra, 0xe8(sp)             ; 23 34 11 0e  
     6 : sd   a0, 0xb8(sp)             ; 23 3c a1 0a  
     7 : sd   a1, 0xb0(sp)             ; 23 38 b1 0a  
     8 : sd   a2, 0xa8(sp)             ; 23 34 c1 0a  
     9 : ld   s9, 0xb0(sp)             ; 83 3c 01 0b  
    10 : ld   s10, 0xa8(sp)            ; 03 3d 81 0a  
    11 : add  a3, s9, s10              ; b3 86 ac 01  
    12 : addi s9, a3, -0x01            ; 93 8c f6 ff  
    13 : sd   s9, 0xa0(sp)             ; 23 30 91 0b  
    14 : mv   s9, zero                 ; 93 0c 00 00  
    15 : sd   s9, 0x98(sp)             ; 23 3c 91 09  
    16 : addi s9, zero, 0x01           ; 93 0c 10 00  
    17 : sd   s9, 0x80(sp)             ; 23 30 91 09  
    18 : ld   s9, 0x80(sp)             ; 83 3c 01 08  
    19 : neg  s10, s9                  ; 33 0d 90 41  
    20 : sd   s10, 0x88(sp)            ; 23 34 a1 09  
    21 : mv   s9, zero                 ; 93 0c 00 00  
    22 : sd   s9, 0x90(sp)             ; 23 38 91 09  
    23 :      __loops_label_0:         ;              
    24 : ld   s10, 0xa0(sp)            ; 03 3d 01 0a  
    25 : ld   s9, 0x90(sp)             ; 83 3c 01 09  
    26 : bge  s9, s10, __loops_label_2 ; 63 da ac 1f  
    27 : mv   s8, zero                 ; 13 0c 00 00  
    28 : mv   s9, zero                 ; 93 0c 00 00  
    29 : sd   s9, 0xc0(sp)             ; 23 30 91 0d  
    30 : ld   s9, 0x90(sp)             ; 83 3c 01 09  
    31 : andi a2, s9, 0x01             ; 13 f6 1c 00  
    32 : mv   a1, zero                 ; 93 05 00 00  
    33 : beq  a2, a1, __loops_label_4  ; 63 0c b6 04  
    34 : ld   s9, 0xa8(sp)             ; 83 3c 81 0a  
    35 : addi a1, s9, -0x01            ; 93 85 fc ff  
    36 : ld   s9, 0x90(sp)             ; 83 3c 01 09  
    37 : slt  a2, a1, s9               ; 33 a6 95 01  
    38 : ld   s9, 0x90(sp)             ; 83 3c 01 09  
    39 : sub  a0, a1, s9               ; 33 85 95 41  
    40 : sub  a2, zero, a2             ; 33 06 c0 40  
    41 : and  a0, a2, a0               ; 33 75 a6 00  
    42 : ld   s9, 0x90(sp)             ; 83 3c 01 09  
    43 : add  s8, s9, a0               ; 33 8c ac 00  
    44 : ld   s9, 0x90(sp)             ; 83 3c 01 09  
    45 : sub  a0, s9, a1               ; 33 85 bc 40  
    46 : mv   a2, zero                 ; 13 06 00 00  
    47 : ld   s9, 0x90(sp)             ; 83 3c 01 09  
    48 : slt  a1, a1, s9               ; b3 a5 95 01  
    49 : sub  a0, a0, a2               ; 33 05 c5 40  
    50 : sub  a1, zero, a1             ; b3 05 b0 40  
    51 : and  a0, a1, a0               ; 33 f5 a5 00  
    52 : add  s9, a2, a0               ; b3 0c a6 00  
    53 : sd   s9, 0xc0(sp)             ; 23 30 91 0d  
    54 : j    __loops_label_6          ; 6f 00 40 05  
    55 :      __loops_label_4:         ;              
    56 : ld   s9, 0xb0(sp)             ; 83 3c 01 0b  
    57 : addi a0, s9, -0x01            ; 13 85 fc ff  
    58 : ld   s9, 0x90(sp)             ; 83 3c 01 09  
    59 : sub  a1, s9, a0               ; b3 85 ac 40  
    60 : mv   a2, zero                 ; 13 06 00 00  
    61 : ld   s9, 0x90(sp)             ; 83 3c 01 09  
    62 : slt  a3, a0, s9               ; b3 26 95 01  
    63 : sub  a1, a1, a2               ; b3 85 c5 40  
    64 : sub  a3, zero, a3             ; b3 06 d0 40  
    65 : and  a1, a3, a1               ; b3 f5 b6 00  
    66 : add  s8, a2, a1               ; 33 0c b6 00  
    67 : ld   s9, 0x90(sp)             ; 83 3c 01 09  
    68 : slt  a1, a0, s9               ; b3 25 95 01  
    69 : ld   s9, 0x90(sp)             ; 83 3c 01 09  
    70 : sub  a0, a0, s9               ; 33 05 95 41  
    71 : sub  a1, zero, a1             ; b3 05 b0 40  
    72 : and  a0, a1, a0               ; 33 f5 a5 00  
    73 : ld   s9, 0x90(sp)             ; 83 3c 01 09  
    74 : add  s10, s9, a0              ; 33 8d ac 00  
    75 : sd   s10, 0xc0(sp)            ; 23 30 a1 0d  
    76 :      __loops_label_5:         ;              
    77 :      __loops_label_6:         ;              
    78 : mv   a0, zero                 ; 13 05 00 00  
    79 : blt  s8, a0, __loops_label_8  ; 63 42 ac 10  
    80 : ld   s9, 0xa8(sp)             ; 83 3c 81 0a  
    81 : bge  s8, s9, __loops_label_8  ; 63 5e 9c 0f  
    82 : mv   a0, zero                 ; 13 05 00 00  
    83 : ld   s9, 0xc0(sp)             ; 83 3c 01 0c  
    84 : blt  s9, a0, __loops_label_8  ; 63 c8 ac 0e  
    85 : ld   s10, 0xb0(sp)            ; 03 3d 01 0b  
    86 : ld   s9, 0xc0(sp)             ; 83 3c 01 0c  
    87 : bge  s9, s10, __loops_label_8 ; 63 d2 ac 0f  
    88 : addi a0, zero, 0x2b           ; 13 05 b0 02  
    89 : slli a0, a0, 0x20             ; 13 15 05 02  
    90 : lui  a1, 0xbd8bd              ; b7 d5 8b bd  
    91 : addi a1, a1, -0x378           ; 93 85 85 c8  
    92 : add  a0, a0, a1               ; 33 05 b5 00  
    93 : ld   s9, 0xc0(sp)             ; 83 3c 01 0c  
    94 : sd   t1, 0(sp)                ; 23 30 61 00  
    95 : sd   t2, 0x08(sp)             ; 23 34 71 00  
    96 : sd   a0, 0x10(sp)             ; 23 38 a1 00  
    97 : sd   a1, 0x18(sp)             ; 23 3c b1 00  
    98 : sd   a2, 0x20(sp)             ; 23 30 c1 02  
    99 : sd   a3, 0x28(sp)             ; 23 34 d1 02  
   100 : sd   a4, 0x30(sp)             ; 23 38 e1 02  
   101 : sd   a5, 0x38(sp)             ; 23 3c f1 02  
   102 : sd   a6, 0x40(sp)             ; 23 30 01 05  
   103 : sd   a7, 0x48(sp)             ; 23 34 11 05  
   104 : sd   t3, 0x50(sp)             ; 23 38 c1 05  
   105 : sd   t4, 0x58(sp)             ; 23 3c d1 05  
   106 : sd   t5, 0x60(sp)             ; 23 30 e1 07  
   107 : sd   t6, 0x68(sp)             ; 23 34 f1 07  
   108 : mv   a0, s8                   ; 13 05 0c 00  
   109 : mv   a1, s9                   ; 93 85 0c 00  
   110 : ld   t1, 0x10(sp)             ; 03 33 01 01  
   111 : jalr t1                       ; e7 00 03 00  
   112 : ld   t1, 0(sp)                ; 03 33 01 00  
   113 : ld   t2, 0x08(sp)             ; 83 33 81 00  
   114 : ld   a0, 0x10(sp)             ; 03 35 01 01  
   115 : ld   a1, 0x18(sp)             ; 83 35 81 01  
   116 : ld   a2, 0x20(sp)             ; 03 36 01 02  
   117 : ld   a3, 0x28(sp)             ; 83 36 81 02  
   118 : ld   a4, 0x30(sp)             ; 03 37 01 03  
   119 : ld   a5, 0x38(sp)             ; 83 37 81 03  
   120 : ld   a6, 0x40(sp)             ; 03 38 01 04  
   121 : ld   a7, 0x48(sp)             ; 83 38 81 04  
   122 : ld   t3, 0x50(sp)             ; 03 3e 01 05  
   123 : ld   t4, 0x58(sp)             ; 83 3e 81 05  
   124 : ld   t5, 0x60(sp)             ; 03 3f 01 06  
   125 : ld   t6, 0x68(sp)             ; 83 3f 81 06  
   126 : ld   s10, 0xa8(sp)            ; 03 3d 81 0a  
   127 : ld   s9, 0xc0(sp)             ; 83 3c 01 0c  
   128 : mul  a0, s9, s10              ; 33 85 ac 03  
   129 : add  a0, a0, s8               ; 33 05 85 01  
   130 : ld   s9, 0xb8(sp)             ; 83 3c 81 0b  
   131 : add  a0, s9, a0               ; 33 85 ac 00  
   132 : ld   s9, 0x98(sp)             ; 83 3c 81 09  
   133 : sb   s9, 0(a0)                ; 23 00 95 01  
   134 : ld   s9, 0x98(sp)             ; 83 3c 81 09  
   135 : addi s9, s9, 0x01             ; 93 8c 1c 00  
   136 : sd   s9, 0x98(sp)             ; 23 3c 91 09  
   137 : ld   s9, 0x80(sp)             ; 83 3c 01 08  
   138 : add  s8, s8, s9               ; 33 0c 9c 01  
   139 : ld   s10, 0x88(sp)            ; 03 3d 81 08  
   140 : ld   s9, 0xc0(sp)             ; 83 3c 01 0c  
   141 : add  s9, s9, s10              ; b3 8c ac 01  
   142 : sd   s9, 0xc0(sp)             ; 23 30 91 0d  
   143 : j    __loops_label_6          ; 6f f0 df ef  
   144 :      __loops_label_8:         ;              
   145 : ld   s9, 0x80(sp)             ; 83 3c 01 08  
   146 : neg  s9, s9                   ; b3 0c 90 41  
   147 : sd   s9, 0x80(sp)             ; 23 30 91 09  
   148 : ld   s9, 0x88(sp)             ; 83 3c 81 08  
   149 : neg  s9, s9                   ; b3 0c 90 41  
   150 : sd   s9, 0x88(sp)             ; 23 34 91 09  
   151 : ld   s9, 0x90(sp)             ; 83 3c 01 09  
   152 : addi s9, s9, 0x01             ; 93 8c 1c 00  
   153 : sd   s9, 0x90(sp)             ; 23 38 91 09  
   154 : j    __loops_label_0          ; 6f f0 9f e0  
   155 :      __loops_label_2:         ;              
   156 : ld   fp, 0xe0(sp)             ; 03 34 01 0e  
   157 : ld   ra, 0xe8(sp)             ; 83 30 81 0e  
   158 : ld   s8, 0xc8(sp)             ; 03 3c 81 0c  
   159 : ld   s9, 0xd0(sp)             ; 83 3c 01 0d  
   160 : ld   s10, 0xd8(sp)            ; 03 3d 81 0d  
   161 : addi sp, sp, 0xf0             ; 13 01 01 0f  
   162 : ret                           ; 67 80 00 00  
