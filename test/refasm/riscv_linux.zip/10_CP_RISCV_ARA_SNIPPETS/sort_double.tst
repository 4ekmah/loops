sort_double(i0, i1)
     0 : sub              i2, i2, 224               
     1 : spill            22, i24                   
     2 : spill            23, i25                   
     3 : spill            24, i26                   
     4 : spill            26, i8                    
     5 : spill            27, i1                    
     6 : shl              i25, i11, 3               
     7 : spill            18, i25                   
     8 : unspill          i25, 18                   
     9 : sub              i26, i25, 8               
    10 : spill            20, i26                   
    11 : mov              i25, 0                    
    12 : spill            21, i25                   
    13 : __loops_label_0:                           
    14 : unspill          i26, 20                   
    15 : unspill          i25, 21                   
    16 : jmp_ge           i25, i26, __loops_label_2 
    17 : unspill          i25, 21                   
    18 : mov              i26, i25                  
    19 : spill            17, i26                   
    20 : unspill          i25, 17                   
    21 : add              i26, i25, 8               
    22 : spill            16, i26                   
    23 : __loops_label_3:                           
    24 : unspill          i26, 18                   
    25 : unspill          i25, 16                   
    26 : jmp_ge           i25, i26, __loops_label_5 
    27 : unspill          i25, 16                   
    28 : add              i24, i10, i25             
    29 : load.fp64        i24, i24                  
    30 : unspill          i25, 17                   
    31 : add              i13, i10, i25             
    32 : load.fp64        i25, i13                  
    33 : spill            19, i25                   
    34 : mov              i12, 43                   
    35 : shl              i12, i12, 32              
    36 : rv_lui           i13, 850104               
    37 : add              i13, i13, -1614           
    38 : add              i12, i12, i13             
    39 : unspill          i25, 19                   
    40 : spill            0, i6                     
    41 : spill            1, i7                     
    42 : spill            2, i10                    
    43 : spill            3, i11                    
    44 : spill            4, i12                    
    45 : spill            5, i13                    
    46 : spill            6, i14                    
    47 : spill            7, i15                    
    48 : spill            8, i16                    
    49 : spill            9, i17                    
    50 : spill            10, i28                   
    51 : spill            11, i29                   
    52 : spill            12, i30                   
    53 : spill            13, i31                   
    54 : mov              i10, i24                  
    55 : mov              i11, i25                  
    56 : call_noret       [i12]()                   
    57 : mov              i12, i10                  
    58 : unspill          i6, 0                     
    59 : unspill          i7, 1                     
    60 : unspill          i10, 2                    
    61 : unspill          i11, 3                    
    62 : unspill          i13, 5                    
    63 : unspill          i14, 6                    
    64 : unspill          i15, 7                    
    65 : unspill          i16, 8                    
    66 : unspill          i17, 9                    
    67 : unspill          i28, 10                   
    68 : unspill          i29, 11                   
    69 : unspill          i30, 12                   
    70 : unspill          i31, 13                   
    71 : mov              i13, 0                    
    72 : jmp_eq           i12, i13, __loops_label_7 
    73 : unspill          i25, 16                   
    74 : mov              i26, i25                  
    75 : spill            17, i26                   
    76 : __loops_label_7:                           
    77 : unspill          i25, 16                   
    78 : add              i25, i25, 8               
    79 : spill            16, i25                   
    80 : jmp              3                         
    81 : __loops_label_5:                           
    82 : unspill          i26, 21                   
    83 : unspill          i25, 17                   
    84 : jmp_eq           i25, i26, __loops_label_9 
    85 : unspill          i25, 21                   
    86 : add              i12, i10, i25             
    87 : load.fp64        i12, i12                  
    88 : unspill          i25, 17                   
    89 : add              i13, i10, i25             
    90 : load.fp64        i13, i13                  
    91 : unspill          i25, 17                   
    92 : add              i24, i10, i25             
    93 : store.fp64       i24, i12                  
    94 : unspill          i25, 21                   
    95 : add              i12, i10, i25             
    96 : store.fp64       i12, i13                  
    97 : __loops_label_9:                           
    98 : unspill          i25, 21                   
    99 : add              i25, i25, 8               
   100 : spill            21, i25                   
   101 : jmp              0                         
   102 : __loops_label_2:                           
   103 : unspill          i8, 26                    
   104 : unspill          i1, 27                    
   105 : unspill          i24, 22                   
   106 : unspill          i25, 23                   
   107 : unspill          i26, 24                   
   108 : add              i2, i2, 224               
   109 : ret                                        
