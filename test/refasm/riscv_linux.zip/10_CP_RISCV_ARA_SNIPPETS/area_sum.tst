area_sum(i0, i1)
     0 : sub              i2, i2, 208               
     1 : spill            21, i24                   
     2 : spill            22, i25                   
     3 : spill            24, i8                    
     4 : spill            25, i1                    
     5 : mov              i25, 0                    
     6 : spill            16, i25                   
     7 : __loops_label_0:                           
     8 : mov              i13, 0                    
     9 : jmp_le           i11, i13, __loops_label_2 
    10 : load.i8          i25, i10                  
    11 : spill            17, i25                   
    12 : mov              i24, 43                   
    13 : shl              i24, i24, 32              
    14 : rv_lui           i12, 850105               
    15 : add              i12, i12, -1436           
    16 : add              i25, i24, i12             
    17 : spill            18, i25                   
    18 : mov              i24, 43                   
    19 : shl              i24, i24, 32              
    20 : rv_lui           i13, 850105               
    21 : add              i13, i13, -1242           
    22 : add              i13, i24, i13             
    23 : mov              i24, 43                   
    24 : shl              i24, i24, 32              
    25 : rv_lui           i12, 850105               
    26 : add              i12, i12, -1098           
    27 : add              i12, i24, i12             
    28 : mov              i24, 1                    
    29 : unspill          i25, 17                   
    30 : sub              i24, i25, i24             
    31 : iverson_eq       i24, i24, 0               
    32 : sub              i13, i13, i12             
    33 : sub              i24, 0, i24               
    34 : and              i13, i24, i13             
    35 : add              i12, i12, i13             
    36 : mov              i13, 0                    
    37 : unspill          i25, 17                   
    38 : sub              i13, i25, i13             
    39 : iverson_eq       i13, i13, 0               
    40 : unspill          i25, 18                   
    41 : sub              i24, i25, i12             
    42 : sub              i13, 0, i13               
    43 : and              i13, i13, i24             
    44 : add              i25, i12, i13             
    45 : spill            19, i25                   
    46 : mov              i13, 43                   
    47 : shl              i13, i13, 32              
    48 : rv_lui           i24, 850105               
    49 : add              i24, i24, -1728           
    50 : add              i25, i13, i24             
    51 : spill            20, i25                   
    52 : mov              i24, 43                   
    53 : shl              i24, i24, 32              
    54 : rv_lui           i12, 850105               
    55 : add              i12, i12, -1632           
    56 : add              i12, i24, i12             
    57 : mov              i24, 43                   
    58 : shl              i24, i24, 32              
    59 : rv_lui           i13, 850105               
    60 : add              i13, i13, -1570           
    61 : add              i13, i24, i13             
    62 : mov              i24, 1                    
    63 : unspill          i25, 17                   
    64 : sub              i24, i25, i24             
    65 : iverson_eq       i24, i24, 0               
    66 : sub              i12, i12, i13             
    67 : sub              i24, 0, i24               
    68 : and              i12, i24, i12             
    69 : add              i12, i13, i12             
    70 : mov              i13, 0                    
    71 : unspill          i25, 17                   
    72 : sub              i13, i25, i13             
    73 : iverson_eq       i13, i13, 0               
    74 : unspill          i25, 20                   
    75 : sub              i24, i25, i12             
    76 : sub              i13, 0, i13               
    77 : and              i13, i13, i24             
    78 : add              i12, i12, i13             
    79 : unspill          i25, 19                   
    80 : spill            0, i6                     
    81 : spill            1, i7                     
    82 : spill            2, i10                    
    83 : spill            3, i11                    
    84 : spill            4, i12                    
    85 : spill            5, i13                    
    86 : spill            6, i14                    
    87 : spill            7, i15                    
    88 : spill            8, i16                    
    89 : spill            9, i17                    
    90 : spill            10, i28                   
    91 : spill            11, i29                   
    92 : spill            12, i30                   
    93 : spill            13, i31                   
    94 : call_noret       [i25]()                   
    95 : unspill          i6, 0                     
    96 : unspill          i7, 1                     
    97 : unspill          i10, 2                    
    98 : unspill          i11, 3                    
    99 : unspill          i12, 4                    
   100 : unspill          i13, 5                    
   101 : unspill          i14, 6                    
   102 : unspill          i15, 7                    
   103 : unspill          i16, 8                    
   104 : unspill          i17, 9                    
   105 : unspill          i28, 10                   
   106 : unspill          i29, 11                   
   107 : unspill          i30, 12                   
   108 : unspill          i31, 13                   
   109 : spill            0, i6                     
   110 : spill            1, i7                     
   111 : spill            2, i10                    
   112 : spill            3, i11                    
   113 : spill            4, i12                    
   114 : spill            5, i13                    
   115 : spill            6, i14                    
   116 : spill            7, i15                    
   117 : spill            8, i16                    
   118 : spill            9, i17                    
   119 : spill            10, i28                   
   120 : spill            11, i29                   
   121 : spill            12, i30                   
   122 : spill            13, i31                   
   123 : call_noret       [i12]()                   
   124 : mov              i12, i10                  
   125 : unspill          i6, 0                     
   126 : unspill          i7, 1                     
   127 : unspill          i10, 2                    
   128 : unspill          i11, 3                    
   129 : unspill          i13, 5                    
   130 : unspill          i14, 6                    
   131 : unspill          i15, 7                    
   132 : unspill          i16, 8                    
   133 : unspill          i17, 9                    
   134 : unspill          i28, 10                   
   135 : unspill          i29, 11                   
   136 : unspill          i30, 12                   
   137 : unspill          i31, 13                   
   138 : mov              i13, 43                   
   139 : shl              i13, i13, 32              
   140 : rv_lui           i24, 850105               
   141 : add              i24, i24, -1796           
   142 : add              i13, i13, i24             
   143 : unspill          i25, 16                   
   144 : spill            0, i6                     
   145 : spill            1, i7                     
   146 : spill            2, i10                    
   147 : spill            3, i11                    
   148 : spill            4, i12                    
   149 : spill            5, i13                    
   150 : spill            6, i14                    
   151 : spill            7, i15                    
   152 : spill            8, i16                    
   153 : spill            9, i17                    
   154 : spill            10, i28                   
   155 : spill            11, i29                   
   156 : spill            12, i30                   
   157 : spill            13, i31                   
   158 : mov              i10, i25                  
   159 : mov              i11, i12                  
   160 : call_noret       [i13]()                   
   161 : mov              i12, i10                  
   162 : unspill          i6, 0                     
   163 : unspill          i7, 1                     
   164 : unspill          i10, 2                    
   165 : unspill          i11, 3                    
   166 : unspill          i13, 5                    
   167 : unspill          i14, 6                    
   168 : unspill          i15, 7                    
   169 : unspill          i16, 8                    
   170 : unspill          i17, 9                    
   171 : unspill          i28, 10                   
   172 : unspill          i29, 11                   
   173 : unspill          i30, 12                   
   174 : unspill          i31, 13                   
   175 : mov              i25, i12                  
   176 : spill            16, i25                   
   177 : add              i10, i10, 56              
   178 : sub              i11, i11, 1               
   179 : jmp              0                         
   180 : __loops_label_2:                           
   181 : unspill          i25, 16                   
   182 : mov              i10, i25                  
   183 : unspill          i8, 24                    
   184 : unspill          i1, 25                    
   185 : unspill          i24, 21                   
   186 : unspill          i25, 22                   
   187 : add              i2, i2, 208               
   188 : ret                                        
