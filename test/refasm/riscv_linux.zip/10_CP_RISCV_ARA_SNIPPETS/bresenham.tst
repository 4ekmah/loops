bresenham(i0, i1, i2, i3, i4, i5, i6)
     0 : sub               i2, i2, 128                
     1 : spill             11, i24                    
     2 : spill             12, i25                    
     3 : spill             13, i26                    
     4 : spill             14, i27                    
     5 : sub               i25, i14, i12              
     6 : spill             5, i25                     
     7 : unspill           i25, 5                     
     8 : iverson_gt        i24, 0, i25                
     9 : sub               i24, 0, i24                
    10 : unspill           i25, 5                     
    11 : and               i26, i24, i25              
    12 : spill             6, i26                     
    13 : unspill           i25, 5                     
    14 : sub               i24, 0, i25                
    15 : unspill           i25, 6                     
    16 : add               i24, i24, i25              
    17 : unspill           i25, 6                     
    18 : add               i26, i24, i25              
    19 : spill             4, i26                     
    20 : sub               i24, i14, i12              
    21 : iverson_gt        i25, i24, 0                
    22 : spill             7, i25                     
    23 : iverson_gt        i24, 0, i24                
    24 : unspill           i25, 7                     
    25 : sub               i26, i24, i25              
    26 : spill             0, i26                     
    27 : sub               i25, i15, i13              
    28 : spill             8, i25                     
    29 : unspill           i25, 8                     
    30 : iverson_gt        i24, 0, i25                
    31 : sub               i24, 0, i24                
    32 : unspill           i25, 8                     
    33 : and               i26, i24, i25              
    34 : spill             9, i26                     
    35 : unspill           i25, 8                     
    36 : sub               i24, 0, i25                
    37 : unspill           i25, 9                     
    38 : add               i24, i24, i25              
    39 : unspill           i25, 9                     
    40 : add               i24, i24, i25              
    41 : neg               i25, i24                   
    42 : spill             1, i25                     
    43 : sub               i24, i15, i13              
    44 : iverson_gt        i25, i24, 0                
    45 : spill             10, i25                    
    46 : iverson_gt        i24, 0, i24                
    47 : unspill           i25, 10                    
    48 : sub               i26, i24, i25              
    49 : spill             2, i26                     
    50 : unspill           i25, 4                     
    51 : unspill           i26, 1                     
    52 : add               i27, i25, i26              
    53 : spill             3, i27                     
    54 : __loops_label_0:                             
    55 : mov               i24, 0                     
    56 : jmp_eq            i10, i24, __loops_label_2  
    57 : mul               i24, i13, i11              
    58 : add               i24, i24, i12              
    59 : add               i24, i10, i24              
    60 : store.u8          i24, i16                   
    61 : jmp_ne            i12, i14, __loops_label_4  
    62 : jmp_ne            i13, i15, __loops_label_4  
    63 : jmp               2                          
    64 : __loops_label_4:                             
    65 : unspill           i25, 3                     
    66 : shl               i24, i25, 1                
    67 : unspill           i25, 1                     
    68 : jmp_gt            i24, i25, __loops_label_6  
    69 : jmp_ne            i12, i14, __loops_label_8  
    70 : jmp               2                          
    71 : __loops_label_8:                             
    72 : unspill           i26, 1                     
    73 : unspill           i25, 3                     
    74 : add               i25, i25, i26              
    75 : spill             3, i25                     
    76 : unspill           i25, 0                     
    77 : add               i12, i12, i25              
    78 : __loops_label_6:                             
    79 : unspill           i25, 4                     
    80 : jmp_gt            i24, i25, __loops_label_10 
    81 : jmp_ne            i13, i15, __loops_label_12 
    82 : jmp               2                          
    83 : __loops_label_12:                            
    84 : unspill           i26, 4                     
    85 : unspill           i25, 3                     
    86 : add               i25, i25, i26              
    87 : spill             3, i25                     
    88 : unspill           i25, 2                     
    89 : add               i13, i13, i25              
    90 : __loops_label_10:                            
    91 : jmp               0                          
    92 : __loops_label_2:                             
    93 : unspill           i24, 11                    
    94 : unspill           i25, 12                    
    95 : unspill           i26, 13                    
    96 : unspill           i27, 14                    
    97 : add               i2, i2, 128                
    98 : ret                                          
