has_in_join_cascade(i0, i1, i2)
     0 : sub               i2, i2, 128                
     1 : spill             13, i24                    
     2 : spill             14, i25                    
     3 : spill             15, i26                    
     4 : mov               i25, 0                     
     5 : spill             5, i25                     
     6 : load.i64          i25, i10, 16               
     7 : spill             6, i25                     
     8 : load.i64          i25, i10, 0                
     9 : spill             7, i25                     
    10 : load.i64          i25, i10, 8                
    11 : spill             8, i25                     
    12 : __loops_label_0:                             
    13 : mov               i13, 0                     
    14 : unspill           i25, 6                     
    15 : jmp_le            i25, i13, __loops_label_2  
    16 : unspill           i25, 7                     
    17 : load.i32          i26, i25                   
    18 : spill             9, i26                     
    19 : unspill           i25, 7                     
    20 : add               i25, i25, 4                
    21 : spill             7, i25                     
    22 : unspill           i25, 8                     
    23 : load.i32          i26, i25                   
    24 : spill             4, i26                     
    25 : unspill           i25, 8                     
    26 : add               i25, i25, 4                
    27 : spill             8, i25                     
    28 : unspill           i25, 6                     
    29 : sub               i25, i25, 1                
    30 : spill             6, i25                     
    31 : load.i64          i25, i10, 40               
    32 : spill             10, i25                    
    33 : load.i64          i25, i10, 24               
    34 : spill             11, i25                    
    35 : load.i64          i25, i10, 32               
    36 : spill             12, i25                    
    37 : __loops_label_3:                             
    38 : mov               i13, 0                     
    39 : unspill           i25, 10                    
    40 : jmp_le            i25, i13, __loops_label_5  
    41 : unspill           i25, 11                    
    42 : load.i32          i26, i25                   
    43 : spill             0, i26                     
    44 : unspill           i25, 11                    
    45 : add               i25, i25, 4                
    46 : spill             11, i25                    
    47 : unspill           i25, 12                    
    48 : load.i32          i13, i25                   
    49 : unspill           i25, 12                    
    50 : add               i25, i25, 4                
    51 : spill             12, i25                    
    52 : unspill           i25, 10                    
    53 : sub               i25, i25, 1                
    54 : spill             10, i25                    
    55 : unspill           i25, 9                     
    56 : jmp_le            i13, i25, __loops_label_7  
    57 : jmp               0                          
    58 : __loops_label_7:                             
    59 : unspill           i25, 9                     
    60 : jmp_ne            i13, i25, __loops_label_10 
    61 : load.i64          i25, i10, 64               
    62 : spill             1, i25                     
    63 : load.i64          i25, i10, 48               
    64 : spill             2, i25                     
    65 : load.i64          i25, i10, 56               
    66 : spill             3, i25                     
    67 : __loops_label_11:                            
    68 : mov               i24, 0                     
    69 : unspill           i25, 1                     
    70 : jmp_le            i25, i24, __loops_label_13 
    71 : unspill           i25, 2                     
    72 : load.i32          i24, i25                   
    73 : unspill           i25, 2                     
    74 : add               i25, i25, 4                
    75 : spill             2, i25                     
    76 : unspill           i25, 3                     
    77 : load.i32          i13, i25                   
    78 : unspill           i25, 3                     
    79 : add               i25, i25, 4                
    80 : spill             3, i25                     
    81 : unspill           i25, 1                     
    82 : sub               i25, i25, 1                
    83 : spill             1, i25                     
    84 : unspill           i25, 4                     
    85 : jmp_le            i24, i25, __loops_label_15 
    86 : jmp               0                          
    87 : __loops_label_15:                            
    88 : unspill           i25, 4                     
    89 : jmp_ne            i24, i25, __loops_label_18 
    90 : unspill           i25, 0                     
    91 : jmp_ne            i25, i11, __loops_label_18 
    92 : jmp_ne            i13, i12, __loops_label_18 
    93 : mov               i25, 1                     
    94 : spill             5, i25                     
    95 : jmp               2                          
    96 : __loops_label_16:                            
    97 : __loops_label_18:                            
    98 : jmp               11                         
    99 : __loops_label_13:                            
   100 : __loops_label_8:                             
   101 : __loops_label_10:                            
   102 : jmp               3                          
   103 : __loops_label_5:                             
   104 : jmp               0                          
   105 : __loops_label_2:                             
   106 : unspill           i25, 5                     
   107 : mov               i10, i25                   
   108 : unspill           i24, 13                    
   109 : unspill           i25, 14                    
   110 : unspill           i26, 15                    
   111 : add               i2, i2, 128                
   112 : ret                                          
