conditionpainter(i0)
     0 : sub              i2, i2, 64                
     1 : spill            5, i24                    
     2 : spill            6, i25                    
     3 : mov              i25, -5                   
     4 : spill            2, i25                    
     5 : __loops_label_0:                           
     6 : mov              i11, 5                    
     7 : unspill          i25, 2                    
     8 : jmp_gt           i25, i11, __loops_label_2 
     9 : unspill          i25, 2                    
    10 : add              i11, i25, 5               
    11 : mov              i12, 11                   
    12 : mul              i11, i11, i12             
    13 : mov              i12, 8                    
    14 : mul              i25, i11, i12             
    15 : spill            1, i25                    
    16 : mov              i25, -5                   
    17 : spill            0, i25                    
    18 : __loops_label_3:                           
    19 : mov              i24, 5                    
    20 : unspill          i25, 0                    
    21 : jmp_gt           i25, i24, __loops_label_5 
    22 : unspill          i25, 0                    
    23 : add              i24, i25, 3               
    24 : unspill          i25, 2                    
    25 : iverson_gt       i24, i25, i24             
    26 : neg              i24, i24                  
    27 : add              i24, i24, 1               
    28 : mov              i13, 4                    
    29 : unspill          i25, 2                    
    30 : iverson_gt       i13, i25, i13             
    31 : neg              i13, i13                  
    32 : add              i13, i13, 1               
    33 : and              i13, i24, i13             
    34 : mov              i24, -2                   
    35 : unspill          i25, 0                    
    36 : iverson_gt       i24, i25, i24             
    37 : neg              i24, i24                  
    38 : add              i24, i24, 1               
    39 : and              i13, i13, i24             
    40 : mov              i24, 0                    
    41 : unspill          i25, 0                    
    42 : iverson_gt       i24, i25, i24             
    43 : neg              i24, i24                  
    44 : add              i24, i24, 1               
    45 : and              i13, i13, i24             
    46 : unspill          i25, 0                    
    47 : sub              i24, i25, 1               
    48 : unspill          i25, 2                    
    49 : iverson_gt       i24, i25, i24             
    50 : neg              i24, i24                  
    51 : add              i24, i24, 1               
    52 : mov              i12, 0                    
    53 : unspill          i25, 0                    
    54 : iverson_gt       i12, i25, i12             
    55 : neg              i12, i12                  
    56 : add              i12, i12, 1               
    57 : and              i12, i24, i12             
    58 : mov              i24, 0                    
    59 : unspill          i25, 2                    
    60 : iverson_gt       i24, i25, i24             
    61 : neg              i24, i24                  
    62 : add              i24, i24, 1               
    63 : and              i12, i12, i24             
    64 : unspill          i25, 0                    
    65 : mul              i24, i25, i25             
    66 : unspill          i25, 2                    
    67 : mul              i11, i25, i25             
    68 : add              i11, i24, i11             
    69 : mov              i24, 9                    
    70 : iverson_gt       i11, i11, i24             
    71 : neg              i11, i11                  
    72 : add              i11, i11, 1               
    73 : and              i11, i12, i11             
    74 : or               i25, i13, i11             
    75 : spill            3, i25                    
    76 : mov              i12, 2                    
    77 : mov              i25, 0                    
    78 : spill            4, i25                    
    79 : mov              i24, 2                    
    80 : unspill          i25, 0                    
    81 : iverson_gt       i24, i25, i24             
    82 : neg              i24, i24                  
    83 : add              i24, i24, 1               
    84 : mov              i11, 4                    
    85 : unspill          i25, 0                    
    86 : iverson_gt       i11, i25, i11             
    87 : neg              i11, i11                  
    88 : add              i11, i11, 1               
    89 : and              i11, i24, i11             
    90 : mov              i24, 1                    
    91 : unspill          i25, 2                    
    92 : iverson_gt       i24, i25, i24             
    93 : neg              i24, i24                  
    94 : add              i24, i24, 1               
    95 : mov              i13, 3                    
    96 : unspill          i25, 2                    
    97 : iverson_gt       i13, i25, i13             
    98 : neg              i13, i13                  
    99 : add              i13, i13, 1               
   100 : and              i13, i24, i13             
   101 : or               i11, i11, i13             
   102 : unspill          i25, 0                    
   103 : mul              i13, i25, i25             
   104 : unspill          i25, 2                    
   105 : mul              i24, i25, i25             
   106 : add              i13, i13, i24             
   107 : mov              i24, 16                   
   108 : iverson_gt       i13, i13, i24             
   109 : neg              i13, i13                  
   110 : add              i13, i13, 1               
   111 : and              i11, i11, i13             
   112 : mov              i13, 0                    
   113 : sub              i11, i11, i13             
   114 : iverson_ne       i11, i11, 0               
   115 : unspill          i25, 4                    
   116 : sub              i12, i12, i25             
   117 : sub              i11, 0, i11               
   118 : and              i11, i11, i12             
   119 : unspill          i25, 4                    
   120 : add              i11, i25, i11             
   121 : unspill          i25, 3                    
   122 : add              i11, i25, i11             
   123 : mov              i12, 2                    
   124 : unspill          i25, 2                    
   125 : mul              i12, i25, i12             
   126 : unspill          i25, 0                    
   127 : jmp_gt           i12, i25, __loops_label_8 
   128 : unspill          i25, 0                    
   129 : add              i12, i25, 3               
   130 : neg              i12, i12                  
   131 : unspill          i25, 0                    
   132 : add              i13, i25, 3               
   133 : mul              i12, i12, i13             
   134 : unspill          i25, 2                    
   135 : jmp_le           i25, i12, __loops_label_9 
   136 : __loops_label_8:                           
   137 : mov              i12, 2                    
   138 : unspill          i25, 0                    
   139 : mul              i12, i25, i12             
   140 : unspill          i25, 2                    
   141 : jmp_gt           i25, i12, __loops_label_7 
   142 : unspill          i25, 0                    
   143 : add              i12, i25, 3               
   144 : neg              i12, i12                  
   145 : unspill          i25, 0                    
   146 : add              i13, i25, 3               
   147 : mul              i12, i12, i13             
   148 : unspill          i25, 2                    
   149 : jmp_gt           i25, i12, __loops_label_7 
   150 : __loops_label_9:                           
   151 : mov              i12, 0                    
   152 : unspill          i25, 0                    
   153 : jmp_gt           i25, i12, __loops_label_7 
   154 : add              i11, i11, 3               
   155 : __loops_label_7:                           
   156 : unspill          i25, 0                    
   157 : add              i12, i25, 5               
   158 : shl              i12, i12, 3               
   159 : unspill          i25, 1                    
   160 : add              i12, i25, i12             
   161 : add              i12, i10, i12             
   162 : store.i64        i12, i11                  
   163 : unspill          i25, 0                    
   164 : add              i25, i25, 1               
   165 : spill            0, i25                    
   166 : jmp              3                         
   167 : __loops_label_5:                           
   168 : unspill          i25, 2                    
   169 : add              i25, i25, 1               
   170 : spill            2, i25                    
   171 : jmp              0                         
   172 : __loops_label_2:                           
   173 : unspill          i24, 5                    
   174 : unspill          i25, 6                    
   175 : add              i2, i2, 64                
   176 : ret                                        
