snake(i0, i1, i2)
     0 : sub              i2, i2, 256               
     1 : spill            27, i24                   
     2 : spill            28, i25                   
     3 : spill            29, i26                   
     4 : spill            30, i8                    
     5 : spill            31, i1                    
     6 : add              i13, i11, i12             
     7 : sub              i25, i13, 1               
     8 : spill            21, i25                   
     9 : mov              i25, 0                    
    10 : spill            20, i25                   
    11 : mov              i25, 1                    
    12 : spill            19, i25                   
    13 : unspill          i25, 19                   
    14 : neg              i26, i25                  
    15 : spill            16, i26                   
    16 : mov              i25, 0                    
    17 : spill            22, i25                   
    18 : __loops_label_0:                           
    19 : unspill          i26, 21                   
    20 : unspill          i25, 22                   
    21 : jmp_ge           i25, i26, __loops_label_2 
    22 : mov              i25, 0                    
    23 : spill            17, i25                   
    24 : mov              i25, 0                    
    25 : spill            18, i25                   
    26 : unspill          i25, 22                   
    27 : and              i13, i25, 1               
    28 : mov              i24, 0                    
    29 : jmp_eq           i13, i24, __loops_label_4 
    30 : sub              i25, i12, 1               
    31 : spill            23, i25                   
    32 : unspill          i26, 22                   
    33 : unspill          i25, 23                   
    34 : iverson_gt       i24, i25, i26             
    35 : unspill          i26, 22                   
    36 : unspill          i25, 23                   
    37 : sub              i13, i25, i26             
    38 : sub              i24, 0, i24               
    39 : and              i13, i24, i13             
    40 : unspill          i25, 22                   
    41 : add              i26, i25, i13             
    42 : spill            17, i26                   
    43 : unspill          i25, 22                   
    44 : unspill          i26, 23                   
    45 : sub              i13, i25, i26             
    46 : mov              i25, 0                    
    47 : spill            24, i25                   
    48 : unspill          i25, 22                   
    49 : unspill          i26, 23                   
    50 : iverson_gt       i24, i25, i26             
    51 : unspill          i25, 24                   
    52 : sub              i13, i13, i25             
    53 : sub              i24, 0, i24               
    54 : and              i13, i24, i13             
    55 : unspill          i25, 24                   
    56 : add              i26, i25, i13             
    57 : spill            18, i26                   
    58 : jmp              5                         
    59 : __loops_label_4:                           
    60 : sub              i25, i11, 1               
    61 : spill            25, i25                   
    62 : unspill          i25, 22                   
    63 : unspill          i26, 25                   
    64 : sub              i24, i25, i26             
    65 : mov              i25, 0                    
    66 : spill            26, i25                   
    67 : unspill          i25, 22                   
    68 : unspill          i26, 25                   
    69 : iverson_gt       i13, i25, i26             
    70 : unspill          i25, 26                   
    71 : sub              i24, i24, i25             
    72 : sub              i13, 0, i13               
    73 : and              i13, i13, i24             
    74 : unspill          i25, 26                   
    75 : add              i26, i25, i13             
    76 : spill            17, i26                   
    77 : unspill          i26, 22                   
    78 : unspill          i25, 25                   
    79 : iverson_gt       i13, i25, i26             
    80 : unspill          i26, 22                   
    81 : unspill          i25, 25                   
    82 : sub              i24, i25, i26             
    83 : sub              i13, 0, i13               
    84 : and              i13, i13, i24             
    85 : unspill          i25, 22                   
    86 : add              i26, i25, i13             
    87 : spill            18, i26                   
    88 : __loops_label_5:                           
    89 : __loops_label_6:                           
    90 : mov              i24, 0                    
    91 : unspill          i25, 17                   
    92 : jmp_gt           i25, i24, __loops_label_8 
    93 : unspill          i25, 17                   
    94 : jmp_ge           i25, i12, __loops_label_8 
    95 : mov              i24, 0                    
    96 : unspill          i25, 18                   
    97 : jmp_gt           i25, i24, __loops_label_8 
    98 : unspill          i25, 18                   
    99 : jmp_ge           i25, i11, __loops_label_8 
   100 : mov              i24, 43                   
   101 : shl              i24, i24, 32              
   102 : rv_lui           i13, 850102               
   103 : add              i13, i13, 286             
   104 : add              i13, i24, i13             
   105 : unspill          i25, 17                   
   106 : unspill          i26, 18                   
   107 : spill            0, i6                     
   108 : spill            1, i7                     
   109 : spill            2, i10                    
   110 : spill            3, i11                    
   111 : spill            4, i12                    
   112 : spill            5, i13                    
   113 : spill            6, i14                    
   114 : spill            7, i15                    
   115 : spill            8, i16                    
   116 : spill            9, i17                    
   117 : spill            10, i28                   
   118 : spill            11, i29                   
   119 : spill            12, i30                   
   120 : spill            13, i31                   
   121 : mov              i10, i25                  
   122 : mov              i11, i26                  
   123 : call_noret       [i13]()                   
   124 : unspill          i6, 0                     
   125 : unspill          i7, 1                     
   126 : unspill          i10, 2                    
   127 : unspill          i11, 3                    
   128 : unspill          i12, 4                    
   129 : unspill          i13, 5                    
   130 : unspill          i14, 6                    
   131 : unspill          i15, 7                    
   132 : unspill          i16, 8                    
   133 : unspill          i17, 9                    
   134 : unspill          i28, 10                   
   135 : unspill          i29, 11                   
   136 : unspill          i30, 12                   
   137 : unspill          i31, 13                   
   138 : unspill          i25, 18                   
   139 : mul              i13, i25, i12             
   140 : unspill          i25, 17                   
   141 : add              i13, i13, i25             
   142 : add              i13, i10, i13             
   143 : unspill          i25, 20                   
   144 : store.u8         i13, i25                  
   145 : unspill          i25, 20                   
   146 : add              i25, i25, 1               
   147 : spill            20, i25                   
   148 : unspill          i26, 19                   
   149 : unspill          i25, 17                   
   150 : add              i25, i25, i26             
   151 : spill            17, i25                   
   152 : unspill          i26, 16                   
   153 : unspill          i25, 18                   
   154 : add              i25, i25, i26             
   155 : spill            18, i25                   
   156 : jmp              6                         
   157 : __loops_label_8:                           
   158 : unspill          i25, 19                   
   159 : neg              i25, i25                  
   160 : spill            19, i25                   
   161 : unspill          i25, 16                   
   162 : neg              i25, i25                  
   163 : spill            16, i25                   
   164 : unspill          i25, 22                   
   165 : add              i25, i25, 1               
   166 : spill            22, i25                   
   167 : jmp              0                         
   168 : __loops_label_2:                           
   169 : unspill          i8, 30                    
   170 : unspill          i1, 31                    
   171 : unspill          i24, 27                   
   172 : unspill          i25, 28                   
   173 : unspill          i26, 29                   
   174 : add              i2, i2, 256               
   175 : ret                                        
