sibling_loops(i0, i1, i2)
     0 : sub              i2, i2, 64                
     1 : spill            6, i24                    
     2 : spill            7, i25                    
     3 : mov              i13, 0                    
     4 : mov              i25, 0                    
     5 : spill            4, i25                    
     6 : __loops_label_0:                           
     7 : jmp_ge           i13, i11, __loops_label_2 
     8 : add              i24, i10, i13             
     9 : load.i32         i24, i24                  
    10 : unspill          i25, 4                    
    11 : add              i25, i25, i24             
    12 : spill            4, i25                    
    13 : add              i13, i13, 4               
    14 : jmp              0                         
    15 : __loops_label_2:                           
    16 : mov              i10, 0                    
    17 : spill            5, i10                    
    18 : __loops_label_3:                           
    19 : mov              i24, 0                    
    20 : jmp_le           i13, i24, __loops_label_5 
    21 : unspill          i25, 5                    
    22 : add              i25, i25, 1               
    23 : spill            5, i25                    
    24 : sub              i13, i13, 4               
    25 : jmp              3                         
    26 : __loops_label_5:                           
    27 : unspill          i10, 5                    
    28 : unspill          i25, 4                    
    29 : store.i32        i12, i25                  
    30 : store.i32        i12, 4, i10               
    31 : mov              i10, 0                    
    32 : unspill          i24, 6                    
    33 : unspill          i25, 7                    
    34 : add              i2, i2, 64                
    35 : ret                                        
