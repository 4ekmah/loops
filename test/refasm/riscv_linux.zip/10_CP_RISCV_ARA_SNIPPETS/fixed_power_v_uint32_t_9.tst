fixed_power_v_uint32_t_9(i0, i1, i2)
     0 : mov              i13, 0                    
     1 : mov              i15, 4                    
     2 : mul              i14, i12, i15             
     3 : __loops_label_0:                           
     4 : jmp_ge           i13, i14, __loops_label_2 
     5 : add              i15, i10, i13             
     6 : vld.u32          v0, i15                   
     7 : rv_vsetvli       i15, 0, 144               
     8 : mul.u32          v1, v0, v0                
     9 : mul.u32          v1, v1, v1                
    10 : mul.u32          v1, v1, v1                
    11 : mul.u32          v0, v0, v1                
    12 : add              i15, i11, i13             
    13 : vst.u32          i15, v0                   
    14 : add              i13, i13, 32              
    15 : jmp              0                         
    16 : __loops_label_2:                           
    17 : mov              i10, 0                    
    18 : ret                                        
