min_max_scalar(i0, i1, i2, i3)
     0 : sub              i2, i2, 112               
     1 : spill            10, i24                   
     2 : spill            11, i25                   
     3 : spill            12, i26                   
     4 : mov              i25, 0                    
     5 : spill            9, i25                    
     6 : mov              i25, 0                    
     7 : spill            4, i25                    
     8 : mov              i25, 0                    
     9 : spill            5, i25                    
    10 : load.i32         i25, i10                  
    11 : spill            6, i25                    
    12 : unspill          i25, 6                    
    13 : mov              i26, i25                  
    14 : spill            7, i26                    
    15 : mov              i24, 4                    
    16 : mul              i11, i11, i24             
    17 : spill            8, i11                    
    18 : __loops_label_0:                           
    19 : unspill          i26, 8                    
    20 : unspill          i25, 9                    
    21 : jmp_ge           i25, i26, __loops_label_2 
    22 : unspill          i25, 9                    
    23 : add              i24, i10, i25             
    24 : load.i32         i24, i24                  
    25 : unspill          i25, 6                    
    26 : jmp_ge           i24, i25, __loops_label_4 
    27 : mov              i25, i24                  
    28 : spill            6, i25                    
    29 : unspill          i25, 9                    
    30 : mov              i26, i25                  
    31 : spill            4, i26                    
    32 : __loops_label_4:                           
    33 : unspill          i25, 7                    
    34 : jmp_le           i24, i25, __loops_label_6 
    35 : mov              i25, i24                  
    36 : spill            7, i25                    
    37 : unspill          i25, 9                    
    38 : mov              i26, i25                  
    39 : spill            5, i26                    
    40 : __loops_label_6:                           
    41 : unspill          i25, 9                    
    42 : add              i25, i25, 4               
    43 : spill            9, i25                    
    44 : jmp              0                         
    45 : __loops_label_2:                           
    46 : mov              i10, 4                    
    47 : unspill          i25, 4                    
    48 : div              i11, i25, i10             
    49 : unspill          i25, 5                    
    50 : div              i10, i25, i10             
    51 : store.i32        i12, i11                  
    52 : store.i32        i13, i10                  
    53 : mov              i10, 0                    
    54 : unspill          i24, 10                   
    55 : unspill          i25, 11                   
    56 : unspill          i26, 12                   
    57 : add              i2, i2, 112               
    58 : ret                                        
