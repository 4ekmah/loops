all_loads_all_stores(i0, i1, i2, i3, i4)
     0 : sub               i2, i2, 224                
     1 : spill             24, i24                    
     2 : spill             25, i25                    
     3 : spill             26, i26                    
     4 : spill             27, i27                    
     5 : mov               i25, 0                     
     6 : spill             4, i25                     
     7 : mov               i25, 0                     
     8 : spill             0, i25                     
     9 : mov               i25, 0                     
    10 : spill             1, i25                     
    11 : mov               i25, 2                     
    12 : spill             7, i25                     
    13 : mov               i25, 1                     
    14 : spill             6, i25                     
    15 : mov               i24, 1                     
    16 : iverson_gt        i24, i11, i24              
    17 : unspill           i25, 7                     
    18 : unspill           i26, 6                     
    19 : sub               i27, i25, i26              
    20 : spill             8, i27                     
    21 : sub               i24, 0, i24                
    22 : unspill           i25, 8                     
    23 : and               i24, i24, i25              
    24 : unspill           i25, 6                     
    25 : add               i26, i25, i24              
    26 : spill             9, i26                     
    27 : mov               i25, 4                     
    28 : spill             10, i25                    
    29 : mov               i24, 3                     
    30 : iverson_gt        i24, i11, i24              
    31 : unspill           i26, 9                     
    32 : unspill           i25, 10                    
    33 : sub               i27, i25, i26              
    34 : spill             11, i27                    
    35 : sub               i24, 0, i24                
    36 : unspill           i25, 11                    
    37 : and               i24, i24, i25              
    38 : unspill           i25, 9                     
    39 : add               i26, i25, i24              
    40 : spill             12, i26                    
    41 : mov               i25, 8                     
    42 : spill             13, i25                    
    43 : mov               i24, 5                     
    44 : iverson_gt        i24, i11, i24              
    45 : unspill           i26, 12                    
    46 : unspill           i25, 13                    
    47 : sub               i27, i25, i26              
    48 : spill             14, i27                    
    49 : sub               i24, 0, i24                
    50 : unspill           i25, 14                    
    51 : and               i24, i24, i25              
    52 : unspill           i25, 12                    
    53 : add               i26, i25, i24              
    54 : spill             2, i26                     
    55 : mov               i25, 2                     
    56 : spill             16, i25                    
    57 : mov               i25, 1                     
    58 : spill             15, i25                    
    59 : mov               i24, 1                     
    60 : iverson_gt        i24, i13, i24              
    61 : unspill           i25, 16                    
    62 : unspill           i26, 15                    
    63 : sub               i27, i25, i26              
    64 : spill             17, i27                    
    65 : sub               i24, 0, i24                
    66 : unspill           i25, 17                    
    67 : and               i24, i24, i25              
    68 : unspill           i25, 15                    
    69 : add               i26, i25, i24              
    70 : spill             18, i26                    
    71 : mov               i25, 4                     
    72 : spill             19, i25                    
    73 : mov               i24, 3                     
    74 : iverson_gt        i24, i13, i24              
    75 : unspill           i26, 18                    
    76 : unspill           i25, 19                    
    77 : sub               i27, i25, i26              
    78 : spill             20, i27                    
    79 : sub               i24, 0, i24                
    80 : unspill           i25, 20                    
    81 : and               i24, i24, i25              
    82 : unspill           i25, 18                    
    83 : add               i26, i25, i24              
    84 : spill             21, i26                    
    85 : mov               i25, 8                     
    86 : spill             22, i25                    
    87 : mov               i24, 5                     
    88 : iverson_gt        i24, i13, i24              
    89 : unspill           i26, 21                    
    90 : unspill           i25, 22                    
    91 : sub               i27, i25, i26              
    92 : spill             23, i27                    
    93 : sub               i24, 0, i24                
    94 : unspill           i25, 23                    
    95 : and               i24, i24, i25              
    96 : unspill           i25, 21                    
    97 : add               i26, i25, i24              
    98 : spill             3, i26                     
    99 : __loops_label_0:                             
   100 : unspill           i25, 4                     
   101 : jmp_ge            i25, i14, __loops_label_2  
   102 : def               i25                        
   103 : spill             5, i25                     
   104 : mov               i24, 0                     
   105 : jmp_ne            i11, i24, __loops_label_4  
   106 : unspill           i25, 0                     
   107 : add               i24, i10, i25              
   108 : load.u8           i25, i24                   
   109 : spill             5, i25                     
   110 : jmp               5                          
   111 : __loops_label_4:                             
   112 : mov               i24, 1                     
   113 : jmp_ne            i11, i24, __loops_label_7  
   114 : unspill           i25, 0                     
   115 : add               i24, i10, i25              
   116 : load.i8           i25, i24                   
   117 : spill             5, i25                     
   118 : jmp               8                          
   119 : __loops_label_7:                             
   120 : mov               i24, 2                     
   121 : jmp_ne            i11, i24, __loops_label_10 
   122 : unspill           i25, 0                     
   123 : add               i24, i10, i25              
   124 : load.u16          i25, i24                   
   125 : spill             5, i25                     
   126 : jmp               11                         
   127 : __loops_label_10:                            
   128 : mov               i24, 3                     
   129 : jmp_ne            i11, i24, __loops_label_13 
   130 : unspill           i25, 0                     
   131 : add               i24, i10, i25              
   132 : load.i16          i25, i24                   
   133 : spill             5, i25                     
   134 : jmp               14                         
   135 : __loops_label_13:                            
   136 : mov               i24, 4                     
   137 : jmp_ne            i11, i24, __loops_label_16 
   138 : unspill           i25, 0                     
   139 : add               i24, i10, i25              
   140 : load.u32          i25, i24                   
   141 : spill             5, i25                     
   142 : jmp               17                         
   143 : __loops_label_16:                            
   144 : mov               i24, 5                     
   145 : jmp_ne            i11, i24, __loops_label_19 
   146 : unspill           i25, 0                     
   147 : add               i24, i10, i25              
   148 : load.i32          i25, i24                   
   149 : spill             5, i25                     
   150 : jmp               20                         
   151 : __loops_label_19:                            
   152 : mov               i24, 6                     
   153 : jmp_ne            i11, i24, __loops_label_22 
   154 : unspill           i25, 0                     
   155 : add               i24, i10, i25              
   156 : load.u64          i25, i24                   
   157 : spill             5, i25                     
   158 : jmp               23                         
   159 : __loops_label_22:                            
   160 : unspill           i25, 0                     
   161 : add               i24, i10, i25              
   162 : load.i64          i25, i24                   
   163 : spill             5, i25                     
   164 : __loops_label_5:                             
   165 : __loops_label_8:                             
   166 : __loops_label_11:                            
   167 : __loops_label_14:                            
   168 : __loops_label_17:                            
   169 : __loops_label_20:                            
   170 : __loops_label_23:                            
   171 : mov               i24, 0                     
   172 : jmp_ne            i13, i24, __loops_label_25 
   173 : unspill           i25, 1                     
   174 : add               i24, i12, i25              
   175 : unspill           i25, 5                     
   176 : store.u8          i24, i25                   
   177 : jmp               26                         
   178 : __loops_label_25:                            
   179 : mov               i24, 1                     
   180 : jmp_ne            i13, i24, __loops_label_28 
   181 : unspill           i25, 1                     
   182 : add               i24, i12, i25              
   183 : unspill           i25, 5                     
   184 : store.i8          i24, i25                   
   185 : jmp               29                         
   186 : __loops_label_28:                            
   187 : mov               i24, 2                     
   188 : jmp_ne            i13, i24, __loops_label_31 
   189 : unspill           i25, 1                     
   190 : add               i24, i12, i25              
   191 : unspill           i25, 5                     
   192 : store.u16         i24, i25                   
   193 : jmp               32                         
   194 : __loops_label_31:                            
   195 : mov               i24, 3                     
   196 : jmp_ne            i13, i24, __loops_label_34 
   197 : unspill           i25, 1                     
   198 : add               i24, i12, i25              
   199 : unspill           i25, 5                     
   200 : store.i16         i24, i25                   
   201 : jmp               35                         
   202 : __loops_label_34:                            
   203 : mov               i24, 4                     
   204 : jmp_ne            i13, i24, __loops_label_37 
   205 : unspill           i25, 1                     
   206 : add               i24, i12, i25              
   207 : unspill           i25, 5                     
   208 : store.u32         i24, i25                   
   209 : jmp               38                         
   210 : __loops_label_37:                            
   211 : mov               i24, 5                     
   212 : jmp_ne            i13, i24, __loops_label_40 
   213 : unspill           i25, 1                     
   214 : add               i24, i12, i25              
   215 : unspill           i25, 5                     
   216 : store.i32         i24, i25                   
   217 : jmp               41                         
   218 : __loops_label_40:                            
   219 : mov               i24, 6                     
   220 : jmp_ne            i13, i24, __loops_label_43 
   221 : unspill           i25, 1                     
   222 : add               i24, i12, i25              
   223 : unspill           i25, 5                     
   224 : store.u64         i24, i25                   
   225 : jmp               44                         
   226 : __loops_label_43:                            
   227 : unspill           i25, 1                     
   228 : add               i24, i12, i25              
   229 : unspill           i25, 5                     
   230 : store.i64         i24, i25                   
   231 : __loops_label_26:                            
   232 : __loops_label_29:                            
   233 : __loops_label_32:                            
   234 : __loops_label_35:                            
   235 : __loops_label_38:                            
   236 : __loops_label_41:                            
   237 : __loops_label_44:                            
   238 : unspill           i25, 0                     
   239 : unspill           i26, 2                     
   240 : add               i25, i25, i26              
   241 : spill             0, i25                     
   242 : unspill           i25, 1                     
   243 : unspill           i26, 3                     
   244 : add               i25, i25, i26              
   245 : spill             1, i25                     
   246 : unspill           i25, 4                     
   247 : add               i25, i25, 1                
   248 : spill             4, i25                     
   249 : jmp               0                          
   250 : __loops_label_2:                             
   251 : unspill           i24, 24                    
   252 : unspill           i25, 25                    
   253 : unspill           i26, 26                    
   254 : unspill           i27, 27                    
   255 : add               i2, i2, 224                
   256 : ret                                          
