nonnegative_odd(i0, i1)
     0 : sub              i2, i2, 64                
     1 : spill            6, i24                    
     2 : spill            7, i25                    
     3 : mov              i12, 0                    
     4 : mov              i25, -4                   
     5 : spill            5, i25                    
     6 : mov              i13, 4                    
     7 : mul              i11, i11, i13             
     8 : spill            4, i11                    
     9 : __loops_label_0:                           
    10 : unspill          i25, 4                    
    11 : jmp_ge           i12, i25, __loops_label_2 
    12 : add              i24, i10, i12             
    13 : load.i32         i24, i24                  
    14 : mov              i13, 0                    
    15 : jmp_ge           i24, i13, __loops_label_4 
    16 : add              i12, i12, 4               
    17 : jmp              0                         
    18 : __loops_label_4:                           
    19 : mov              i13, 2                    
    20 : mod              i13, i24, i13             
    21 : mov              i24, 0                    
    22 : jmp_eq           i13, i24, __loops_label_6 
    23 : mov              i25, i12                  
    24 : spill            5, i25                    
    25 : jmp              2                         
    26 : __loops_label_6:                           
    27 : add              i12, i12, 4               
    28 : jmp              0                         
    29 : __loops_label_2:                           
    30 : mov              i10, 4                    
    31 : unspill          i25, 5                    
    32 : div              i10, i25, i10             
    33 : unspill          i24, 6                    
    34 : unspill          i25, 7                    
    35 : add              i2, i2, 64                
    36 : ret                                        
