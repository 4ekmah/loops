fixed_power_v_uint32_t_0(i0, i1, i2)
     0 : mov              i13, 0                    
     1 : mov              i15, 4                    
     2 : mul              i14, i12, i15             
     3 : __loops_label_0:                           
     4 : jmp_ge           i13, i14, __loops_label_2 
     5 : add              i15, i10, i13             
     6 : vld.u32          v0, i15                   
     7 : rv_vsetvli       i15, 0, 144               
     8 : broadcast.u32    v0, 1                     
     9 : add              i15, i11, i13             
    10 : vst.u32          i15, v0                   
    11 : add              i13, i13, 32              
    12 : jmp              0                         
    13 : __loops_label_2:                           
    14 : mov              i10, 0                    
    15 : ret                                        
