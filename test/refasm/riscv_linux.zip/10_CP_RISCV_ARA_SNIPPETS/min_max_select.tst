min_max_select(i0, i1, i2, i3)
     0 : sub              i2, i2, 128               
     1 : spill            11, i24                   
     2 : spill            12, i25                   
     3 : spill            13, i26                   
     4 : spill            14, i27                   
     5 : mov              i25, 0                    
     6 : spill            5, i25                    
     7 : mov              i25, 0                    
     8 : spill            0, i25                    
     9 : mov              i25, 0                    
    10 : spill            1, i25                    
    11 : load.i32         i25, i10                  
    12 : spill            2, i25                    
    13 : unspill          i25, 2                    
    14 : mov              i26, i25                  
    15 : spill            3, i26                    
    16 : shl              i25, i11, 2               
    17 : spill            4, i25                    
    18 : __loops_label_0:                           
    19 : unspill          i26, 4                    
    20 : unspill          i25, 5                    
    21 : jmp_ge           i25, i26, __loops_label_2 
    22 : unspill          i25, 5                    
    23 : add              i24, i10, i25             
    24 : load.i32         i25, i24                  
    25 : spill            6, i25                    
    26 : unspill          i26, 2                    
    27 : unspill          i25, 6                    
    28 : iverson_gt       i24, i25, i26             
    29 : unspill          i25, 5                    
    30 : unspill          i26, 0                    
    31 : sub              i27, i25, i26             
    32 : spill            7, i27                    
    33 : sub              i24, 0, i24               
    34 : unspill          i25, 7                    
    35 : and              i24, i24, i25             
    36 : unspill          i25, 0                    
    37 : add              i25, i25, i24             
    38 : spill            0, i25                    
    39 : unspill          i26, 2                    
    40 : unspill          i25, 6                    
    41 : iverson_gt       i24, i25, i26             
    42 : unspill          i26, 2                    
    43 : unspill          i25, 6                    
    44 : sub              i27, i25, i26             
    45 : spill            8, i27                    
    46 : sub              i24, 0, i24               
    47 : unspill          i25, 8                    
    48 : and              i24, i24, i25             
    49 : unspill          i25, 2                    
    50 : add              i25, i25, i24             
    51 : spill            2, i25                    
    52 : unspill          i26, 3                    
    53 : unspill          i25, 6                    
    54 : iverson_gt       i24, i25, i26             
    55 : unspill          i25, 5                    
    56 : unspill          i26, 1                    
    57 : sub              i27, i25, i26             
    58 : spill            9, i27                    
    59 : sub              i24, 0, i24               
    60 : unspill          i25, 9                    
    61 : and              i24, i24, i25             
    62 : unspill          i25, 1                    
    63 : add              i25, i25, i24             
    64 : spill            1, i25                    
    65 : unspill          i26, 3                    
    66 : unspill          i25, 6                    
    67 : iverson_gt       i24, i25, i26             
    68 : unspill          i25, 3                    
    69 : unspill          i26, 6                    
    70 : sub              i27, i25, i26             
    71 : spill            10, i27                   
    72 : sub              i24, 0, i24               
    73 : unspill          i25, 10                   
    74 : and              i24, i24, i25             
    75 : unspill          i25, 6                    
    76 : add              i26, i25, i24             
    77 : spill            3, i26                    
    78 : unspill          i25, 5                    
    79 : add              i25, i25, 4               
    80 : spill            5, i25                    
    81 : jmp              0                         
    82 : __loops_label_2:                           
    83 : unspill          i25, 0                    
    84 : sar              i25, i25, 2               
    85 : spill            0, i25                    
    86 : unspill          i25, 1                    
    87 : sar              i25, i25, 2               
    88 : spill            1, i25                    
    89 : unspill          i25, 0                    
    90 : store.i32        i12, i25                  
    91 : unspill          i25, 1                    
    92 : store.i32        i13, i25                  
    93 : mov              i10, 0                    
    94 : unspill          i24, 11                   
    95 : unspill          i25, 12                   
    96 : unspill          i26, 13                   
    97 : unspill          i27, 14                   
    98 : add              i2, i2, 128               
    99 : ret                                        
