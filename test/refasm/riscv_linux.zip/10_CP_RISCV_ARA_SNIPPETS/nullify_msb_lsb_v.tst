nullify_msb_lsb_v(i0, i1, i2, i3)
     0 : mov              i14, 0                    
     1 : mov              i16, 4                    
     2 : mul              i15, i13, i16             
     3 : rv_vsetvli       i13, 0, 144               
     4 : broadcast.u32    v0, 1                     
     5 : __loops_label_0:                           
     6 : jmp_ge           i14, i15, __loops_label_2 
     7 : add              i16, i10, i14             
     8 : vld.u32          v1, i16                   
     9 : rv_vsetvli       i16, 0, 144               
    10 : shr.u32          v2, v1, 1                 
    11 : or               v2, v1, v2                
    12 : shr.u32          v3, v2, 2                 
    13 : or               v2, v2, v3                
    14 : shr.u32          v3, v2, 4                 
    15 : or               v2, v2, v3                
    16 : shr.u32          v3, v2, 8                 
    17 : or               v2, v2, v3                
    18 : shr.u32          v3, v2, 16                
    19 : or               v2, v2, v3                
    20 : add.u32          v2, v2, v0                
    21 : shr.u32          v2, v2, 1                 
    22 : xor              v2, v2, v1                
    23 : add              i16, i11, i14             
    24 : vst.u32          i16, v2                   
    25 : sub.u32          v2, v1, v0                
    26 : not              v2, v2                    
    27 : and              v2, v1, v2                
    28 : xor              v1, v2, v1                
    29 : add              i16, i12, i14             
    30 : vst.u32          i16, v1                   
    31 : add              i14, i14, 32              
    32 : jmp              0                         
    33 : __loops_label_2:                           
    34 : ret                                        
