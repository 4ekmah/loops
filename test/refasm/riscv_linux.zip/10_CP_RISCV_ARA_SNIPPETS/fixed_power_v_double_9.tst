fixed_power_v_double_9(i0, i1, i2)
     0 : mov              i13, 0                    
     1 : mov              i15, 8                    
     2 : mul              i14, i12, i15             
     3 : __loops_label_0:                           
     4 : jmp_ge           i13, i14, __loops_label_2 
     5 : add              i15, i10, i13             
     6 : vld.fp64         v0, i15                   
     7 : rv_vsetvli       i15, 0, 152               
     8 : rv_csrrwi        i15, 2, 0                 
     9 : mul.fp64         v1, v0, v0                
    10 : mul.fp64         v1, v1, v1                
    11 : mul.fp64         v1, v1, v1                
    12 : mul.fp64         v0, v0, v1                
    13 : add              i15, i11, i13             
    14 : vst.fp64         i15, v0                   
    15 : add              i13, i13, 32              
    16 : jmp              0                         
    17 : __loops_label_2:                           
    18 : mov              i10, 0                    
    19 : ret                                        
