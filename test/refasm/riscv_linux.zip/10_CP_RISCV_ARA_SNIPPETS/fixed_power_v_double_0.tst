fixed_power_v_double_0(i0, i1, i2)
     0 : mov              i13, 0                    
     1 : mov              i15, 8                    
     2 : mul              i14, i12, i15             
     3 : __loops_label_0:                           
     4 : jmp_ge           i13, i14, __loops_label_2 
     5 : add              i15, i10, i13             
     6 : vld.fp64         v0, i15                   
     7 : rv_vsetvli       i15, 0, 152               
     8 : rv_lui           i15, 261888               
     9 : add              i15, i15, 0               
    10 : shl              i15, i15, 32              
    11 : mov              i16, 0                    
    12 : add              i15, i15, i16             
    13 : broadcast.fp64   v0, i15                   
    14 : add              i15, i11, i13             
    15 : vst.fp64         i15, v0                   
    16 : add              i13, i13, 32              
    17 : jmp              0                         
    18 : __loops_label_2:                           
    19 : mov              i10, 0                    
    20 : ret                                        
