exp_f32(i0, i1, i2)
     0 : rv_vsetvli             i5, 0, 144              
     1 : rv_lui                 i6, 797452              
     2 : add                    i7, i6, 165             
     3 : broadcast.fp32         v0, i7                  
     4 : rv_lui                 i8, 273164              
     5 : add                    i9, i8, 165             
     6 : broadcast.fp32         v1, i9                  
     7 : rv_lui                 i10, 258048             
     8 : add                    i11, i10, 0             
     9 : broadcast.fp32         v2, i11                 
    10 : rv_lui                 i12, 260096             
    11 : add                    i13, i12, 0             
    12 : broadcast.fp32         v3, i13                 
    13 : rv_lui                 i14, 261003             
    14 : add                    i15, i14, -1477         
    15 : broadcast.fp32         v4, i15                 
    16 : rv_lui                 i16, 783128             
    17 : add                    i17, i16, 0             
    18 : broadcast.fp32         v5, i17                 
    19 : rv_lui                 i18, 234984             
    20 : add                    i19, i18, 131           
    21 : broadcast.fp32         v6, i19                 
    22 : rv_lui                 i20, 234759             
    23 : add                    i21, i20, -1689         
    24 : broadcast.fp32         v7, i21                 
    25 : rv_lui                 i22, 240500             
    26 : add                    i23, i22, 974           
    27 : broadcast.fp32         v8, i23                 
    28 : rv_lui                 i24, 245897             
    29 : add                    i25, i24, -1784         
    30 : broadcast.fp32         v9, i25                 
    31 : rv_lui                 i26, 250539             
    32 : add                    i27, i26, -1599         
    33 : broadcast.fp32         v10, i27                
    34 : rv_lui                 i28, 254635             
    35 : add                    i29, i28, -1366         
    36 : broadcast.fp32         v11, i29                
    37 : rv_lui                 i30, 258048             
    38 : add                    i31, i30, 0             
    39 : broadcast.fp32         v12, i31                
    40 : mov                    i32, 127                
    41 : broadcast.i32          v13, i32                
    42 : mov                    i3, 0                   
    43 : annotation:whilecstart 0                       
    44 : mov                    i4, 0                   
    45 : jmp_le                 i2, i4, __loops_label_2 
    46 : annotation:whilecend                           
    47 : add                    i33, i1, i3             
    48 : vld.fp32               v14, i33                
    49 : rv_vsetvli             i34, 0, 144             
    50 : min.fp32               v21, v14, v1            
    51 : max.fp32               v20, v21, v0            
    52 : rv_csrrwi              i35, 2, 0               
    53 : mov                    v24, v2                 
    54 : fma.fp32               v24, v24, v20, v4       
    55 : rv_csrrwi              i36, 2, 2               
    56 : floor.fp32_i32         v23, v24                
    57 : rv_csrrwi              i37, 2, 0               
    58 : cast.i32_fp32          v22, v23                
    59 : mov                    v19, v20                
    60 : fma.fp32               v19, v19, v22, v5       
    61 : mov                    v18, v19                
    62 : fma.fp32               v18, v18, v22, v6       
    63 : mov                    v29, v8                 
    64 : fma.fp32               v29, v29, v18, v7       
    65 : mov                    v28, v9                 
    66 : fma.fp32               v28, v28, v29, v18      
    67 : mov                    v27, v10                
    68 : fma.fp32               v27, v27, v28, v18      
    69 : mov                    v26, v11                
    70 : fma.fp32               v26, v26, v27, v18      
    71 : mov                    v25, v12                
    72 : fma.fp32               v25, v25, v26, v18      
    73 : mul.fp32               v30, v18, v18           
    74 : mov                    v17, v18                
    75 : fma.fp32               v17, v17, v25, v30      
    76 : add.fp32               v16, v17, v3            
    77 : add.i32                v32, v23, v13           
    78 : sal.i32                v31, v32, 23            
    79 : mul.fp32               v15, v16, v31           
    80 : add                    i38, i0, i3             
    81 : vst.fp32               i38, v15                
    82 : add                    i3, i3, 32              
    83 : sub                    i2, i2, 8               
    84 : annotation:endwhile    0, 2                    
    85 : ret                                            
