snake(i0, i1, i2)
     0 : add                    i4, i1, i2       
     1 : sub                    i3, i4, 1        
     2 : mov                    i5, 0            
     3 : mov                    i6, 1            
     4 : neg                    i7, i6           
     5 : mov                    i8, 0            
     6 : annotation:whilecstart 0                
     7 : cmp                    i8, i3           
     8 : jmp_ge                 __loops_label_2  
     9 : annotation:whilecend                    
    10 : mov                    i9, 0            
    11 : mov                    i10, 0           
    12 : annotation:ifcstart                     
    13 : and                    i11, i8, 1       
    14 : mov                    i20, 0           
    15 : cmp                    i11, i20         
    16 : jmp_eq                 __loops_label_4  
    17 : annotation:ifcend                       
    18 : sub                    i12, i2, 1       
    19 : cmp                    i12, i8          
    20 : iverson_gt             i24              
    21 : sub                    i25, i12, i8     
    22 : sub                    i24, 0, i24      
    23 : and                    i24, i24, i25    
    24 : add                    i9, i8, i24      
    25 : sub                    i13, i8, i12     
    26 : mov                    i14, 0           
    27 : cmp                    i8, i12          
    28 : iverson_gt             i26              
    29 : sub                    i27, i13, i14    
    30 : sub                    i26, 0, i26      
    31 : and                    i26, i26, i27    
    32 : add                    i10, i14, i26    
    33 : annotation:else        4, 5             
    34 : sub                    i15, i1, 1       
    35 : sub                    i16, i8, i15     
    36 : mov                    i17, 0           
    37 : cmp                    i8, i15          
    38 : iverson_gt             i28              
    39 : sub                    i29, i16, i17    
    40 : sub                    i28, 0, i28      
    41 : and                    i28, i28, i29    
    42 : add                    i9, i17, i28     
    43 : cmp                    i15, i8          
    44 : iverson_gt             i30              
    45 : sub                    i31, i15, i8     
    46 : sub                    i30, 0, i30      
    47 : and                    i30, i30, i31    
    48 : add                    i10, i8, i30     
    49 : annotation:endif       5                
    50 : annotation:whilecstart 6                
    51 : mov                    i21, 0           
    52 : cmp                    i9, i21          
    53 : jmp_gt                 __loops_label_8  
    54 : cmp                    i9, i2           
    55 : jmp_ge                 __loops_label_8  
    56 : mov                    i22, 0           
    57 : cmp                    i10, i22         
    58 : jmp_gt                 __loops_label_8  
    59 : cmp                    i10, i1          
    60 : jmp_ge                 __loops_label_8  
    61 : annotation:whilecend                    
    62 : mov                    i23, -1398908398 
    63 : call_noret             [i23](i9, i10)   
    64 : mul                    i19, i10, i2     
    65 : add                    i18, i19, i9     
    66 : store.u8               i0, i18, i5      
    67 : add                    i5, i5, 1        
    68 : add                    i9, i9, i6       
    69 : add                    i10, i10, i7     
    70 : annotation:endwhile    6, 8             
    71 : neg                    i6, i6           
    72 : neg                    i7, i7           
    73 : add                    i8, i8, 1        
    74 : annotation:endwhile    0, 2             
    75 : ret                                     
