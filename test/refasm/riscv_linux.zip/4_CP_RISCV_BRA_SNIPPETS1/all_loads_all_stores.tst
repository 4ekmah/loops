all_loads_all_stores(i0, i1, i2, i3, i4)
     0 : mov                    i5, 0            
     1 : mov                    i6, 0            
     2 : mov                    i7, 0            
     3 : mov                    i8, 2            
     4 : mov                    i9, 1            
     5 : mov                    i19, 1           
     6 : cmp                    i1, i19          
     7 : iverson_gt             i39              
     8 : sub                    i40, i8, i9      
     9 : sub                    i39, 0, i39      
    10 : and                    i39, i39, i40    
    11 : add                    i10, i9, i39     
    12 : mov                    i11, 4           
    13 : mov                    i20, 3           
    14 : cmp                    i1, i20          
    15 : iverson_gt             i41              
    16 : sub                    i42, i11, i10    
    17 : sub                    i41, 0, i41      
    18 : and                    i41, i41, i42    
    19 : add                    i10, i10, i41    
    20 : mov                    i12, 8           
    21 : mov                    i21, 5           
    22 : cmp                    i1, i21          
    23 : iverson_gt             i43              
    24 : sub                    i44, i12, i10    
    25 : sub                    i43, 0, i43      
    26 : and                    i43, i43, i44    
    27 : add                    i10, i10, i43    
    28 : mov                    i13, 2           
    29 : mov                    i14, 1           
    30 : mov                    i22, 1           
    31 : cmp                    i3, i22          
    32 : iverson_gt             i45              
    33 : sub                    i46, i13, i14    
    34 : sub                    i45, 0, i45      
    35 : and                    i45, i45, i46    
    36 : add                    i15, i14, i45    
    37 : mov                    i16, 4           
    38 : mov                    i23, 3           
    39 : cmp                    i3, i23          
    40 : iverson_gt             i47              
    41 : sub                    i48, i16, i15    
    42 : sub                    i47, 0, i47      
    43 : and                    i47, i47, i48    
    44 : add                    i15, i15, i47    
    45 : mov                    i17, 8           
    46 : mov                    i24, 5           
    47 : cmp                    i3, i24          
    48 : iverson_gt             i49              
    49 : sub                    i50, i17, i15    
    50 : sub                    i49, 0, i49      
    51 : and                    i49, i49, i50    
    52 : add                    i15, i15, i49    
    53 : annotation:whilecstart 0                
    54 : cmp                    i5, i4           
    55 : jmp_ge                 __loops_label_2  
    56 : annotation:whilecend                    
    57 : def                    i18              
    58 : annotation:ifcstart                     
    59 : mov                    i25, 0           
    60 : cmp                    i1, i25          
    61 : jmp_ne                 __loops_label_4  
    62 : annotation:ifcend                       
    63 : load.u8                i18, i0, i6      
    64 : annotation:else        4, 5             
    65 : annotation:ifcstart                     
    66 : mov                    i26, 1           
    67 : cmp                    i1, i26          
    68 : jmp_ne                 __loops_label_7  
    69 : annotation:ifcend                       
    70 : load.i8                i18, i0, i6      
    71 : annotation:else        7, 8             
    72 : annotation:ifcstart                     
    73 : mov                    i27, 2           
    74 : cmp                    i1, i27          
    75 : jmp_ne                 __loops_label_10 
    76 : annotation:ifcend                       
    77 : load.u16               i18, i0, i6      
    78 : annotation:else        10, 11           
    79 : annotation:ifcstart                     
    80 : mov                    i28, 3           
    81 : cmp                    i1, i28          
    82 : jmp_ne                 __loops_label_13 
    83 : annotation:ifcend                       
    84 : load.i16               i18, i0, i6      
    85 : annotation:else        13, 14           
    86 : annotation:ifcstart                     
    87 : mov                    i29, 4           
    88 : cmp                    i1, i29          
    89 : jmp_ne                 __loops_label_16 
    90 : annotation:ifcend                       
    91 : load.u32               i18, i0, i6      
    92 : annotation:else        16, 17           
    93 : annotation:ifcstart                     
    94 : mov                    i30, 5           
    95 : cmp                    i1, i30          
    96 : jmp_ne                 __loops_label_19 
    97 : annotation:ifcend                       
    98 : load.i32               i18, i0, i6      
    99 : annotation:else        19, 20           
   100 : annotation:ifcstart                     
   101 : mov                    i31, 6           
   102 : cmp                    i1, i31          
   103 : jmp_ne                 __loops_label_22 
   104 : annotation:ifcend                       
   105 : load.u64               i18, i0, i6      
   106 : annotation:else        22, 23           
   107 : load.i64               i18, i0, i6      
   108 : annotation:endif       5                
   109 : annotation:endif       8                
   110 : annotation:endif       11               
   111 : annotation:endif       14               
   112 : annotation:endif       17               
   113 : annotation:endif       20               
   114 : annotation:endif       23               
   115 : annotation:ifcstart                     
   116 : mov                    i32, 0           
   117 : cmp                    i3, i32          
   118 : jmp_ne                 __loops_label_25 
   119 : annotation:ifcend                       
   120 : store.u8               i2, i7, i18      
   121 : annotation:else        25, 26           
   122 : annotation:ifcstart                     
   123 : mov                    i33, 1           
   124 : cmp                    i3, i33          
   125 : jmp_ne                 __loops_label_28 
   126 : annotation:ifcend                       
   127 : store.i8               i2, i7, i18      
   128 : annotation:else        28, 29           
   129 : annotation:ifcstart                     
   130 : mov                    i34, 2           
   131 : cmp                    i3, i34          
   132 : jmp_ne                 __loops_label_31 
   133 : annotation:ifcend                       
   134 : store.u16              i2, i7, i18      
   135 : annotation:else        31, 32           
   136 : annotation:ifcstart                     
   137 : mov                    i35, 3           
   138 : cmp                    i3, i35          
   139 : jmp_ne                 __loops_label_34 
   140 : annotation:ifcend                       
   141 : store.i16              i2, i7, i18      
   142 : annotation:else        34, 35           
   143 : annotation:ifcstart                     
   144 : mov                    i36, 4           
   145 : cmp                    i3, i36          
   146 : jmp_ne                 __loops_label_37 
   147 : annotation:ifcend                       
   148 : store.u32              i2, i7, i18      
   149 : annotation:else        37, 38           
   150 : annotation:ifcstart                     
   151 : mov                    i37, 5           
   152 : cmp                    i3, i37          
   153 : jmp_ne                 __loops_label_40 
   154 : annotation:ifcend                       
   155 : store.i32              i2, i7, i18      
   156 : annotation:else        40, 41           
   157 : annotation:ifcstart                     
   158 : mov                    i38, 6           
   159 : cmp                    i3, i38          
   160 : jmp_ne                 __loops_label_43 
   161 : annotation:ifcend                       
   162 : store.u64              i2, i7, i18      
   163 : annotation:else        43, 44           
   164 : store.i64              i2, i7, i18      
   165 : annotation:endif       26               
   166 : annotation:endif       29               
   167 : annotation:endif       32               
   168 : annotation:endif       35               
   169 : annotation:endif       38               
   170 : annotation:endif       41               
   171 : annotation:endif       44               
   172 : add                    i6, i6, i10      
   173 : add                    i7, i7, i15      
   174 : add                    i5, i5, 1        
   175 : annotation:endwhile    0, 2             
