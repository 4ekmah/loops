area_sum(i0, i1)
     0 : mov                    i2, 0               
     1 : annotation:whilecstart 0                   
     2 : mov                    i16, 0              
     3 : cmp                    i1, i16             
     4 : jmp_le                 __loops_label_2     
     5 : annotation:whilecend                       
     6 : load.i8                i3, i0              
     7 : mov                    i4, -1398897832     
     8 : mov                    i5, -1398897638     
     9 : mov                    i6, -1398897494     
    10 : mov                    i17, 1              
    11 : cmp                    i3, i17             
    12 : iverson_eq             i22                 
    13 : sub                    i23, i5, i6         
    14 : sub                    i22, 0, i22         
    15 : and                    i22, i22, i23       
    16 : add                    i7, i6, i22         
    17 : mov                    i18, 0              
    18 : cmp                    i3, i18             
    19 : iverson_eq             i24                 
    20 : sub                    i25, i4, i7         
    21 : sub                    i24, 0, i24         
    22 : and                    i24, i24, i25       
    23 : add                    i8, i7, i24         
    24 : mov                    i9, -1398898124     
    25 : mov                    i10, -1398898028    
    26 : mov                    i11, -1398897966    
    27 : mov                    i19, 1              
    28 : cmp                    i3, i19             
    29 : iverson_eq             i26                 
    30 : sub                    i27, i10, i11       
    31 : sub                    i26, 0, i26         
    32 : and                    i26, i26, i27       
    33 : add                    i12, i11, i26       
    34 : mov                    i20, 0              
    35 : cmp                    i3, i20             
    36 : iverson_eq             i28                 
    37 : sub                    i29, i9, i12        
    38 : sub                    i28, 0, i28         
    39 : and                    i28, i28, i29       
    40 : add                    i13, i12, i28       
    41 : call_noret             [i8](i0)            
    42 : call                   [i13](i14, i0)      
    43 : mov                    i21, -1398898192    
    44 : call                   [i21](i15, i2, i14) 
    45 : mov                    i2, i15             
    46 : add                    i0, i0, 56          
    47 : sub                    i1, i1, 1           
    48 : annotation:endwhile    0, 2                
    49 : mov                    iR, i2              
    50 : ret                                        
