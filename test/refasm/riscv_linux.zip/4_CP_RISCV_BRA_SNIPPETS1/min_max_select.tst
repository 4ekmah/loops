min_max_select(i0, i1, i2, i3)
     0 : mov                    i4, 0           
     1 : mov                    i5, 0           
     2 : mov                    i6, 0           
     3 : load.i32               i7, i0          
     4 : mov                    i8, i7          
     5 : shl                    i1, i1, 2       
     6 : annotation:whilecstart 0               
     7 : cmp                    i4, i1          
     8 : jmp_ge                 __loops_label_2 
     9 : annotation:whilecend                   
    10 : load.i32               i9, i0, i4      
    11 : cmp                    i9, i7          
    12 : iverson_gt             i10             
    13 : sub                    i11, i4, i5     
    14 : sub                    i10, 0, i10     
    15 : and                    i10, i10, i11   
    16 : add                    i5, i5, i10     
    17 : cmp                    i9, i7          
    18 : iverson_gt             i12             
    19 : sub                    i13, i9, i7     
    20 : sub                    i12, 0, i12     
    21 : and                    i12, i12, i13   
    22 : add                    i7, i7, i12     
    23 : cmp                    i9, i8          
    24 : iverson_gt             i14             
    25 : sub                    i15, i4, i6     
    26 : sub                    i14, 0, i14     
    27 : and                    i14, i14, i15   
    28 : add                    i6, i6, i14     
    29 : cmp                    i9, i8          
    30 : iverson_gt             i16             
    31 : sub                    i17, i8, i9     
    32 : sub                    i16, 0, i16     
    33 : and                    i16, i16, i17   
    34 : add                    i8, i9, i16     
    35 : add                    i4, i4, 4       
    36 : annotation:endwhile    0, 2            
    37 : sar                    i5, i5, 2       
    38 : sar                    i6, i6, 2       
    39 : store.i32              i2, i5          
    40 : store.i32              i3, i6          
    41 : mov                    iR, 0           
    42 : ret                                    
