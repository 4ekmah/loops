bresenham(i0, i1, i2, i3, i4, i5, i6)
     0 : sub                    i8, i4, i2       
     1 : cmp                    0, i8            
     2 : iverson_gt             i21              
     3 : sub                    i21, 0, i21      
     4 : and                    i21, i21, i8     
     5 : sub                    i7, 0, i8        
     6 : add                    i7, i7, i21      
     7 : add                    i7, i7, i21      
     8 : sub                    i10, i4, i2      
     9 : cmp                    i10, 0           
    10 : iverson_gt             i22              
    11 : cmp                    0, i10           
    12 : iverson_gt             i23              
    13 : sub                    i9, i23, i22     
    14 : sub                    i13, i5, i3      
    15 : cmp                    0, i13           
    16 : iverson_gt             i24              
    17 : sub                    i24, 0, i24      
    18 : and                    i24, i24, i13    
    19 : sub                    i12, 0, i13      
    20 : add                    i12, i12, i24    
    21 : add                    i12, i12, i24    
    22 : neg                    i11, i12         
    23 : sub                    i15, i5, i3      
    24 : cmp                    i15, 0           
    25 : iverson_gt             i25              
    26 : cmp                    0, i15           
    27 : iverson_gt             i26              
    28 : sub                    i14, i26, i25    
    29 : add                    i16, i7, i11     
    30 : annotation:whilecstart 0                
    31 : mov                    i20, 0           
    32 : cmp                    i0, i20          
    33 : jmp_eq                 __loops_label_2  
    34 : annotation:whilecend                    
    35 : mul                    i18, i3, i1      
    36 : add                    i17, i18, i2     
    37 : store.u8               i0, i17, i6      
    38 : annotation:ifcstart                     
    39 : cmp                    i2, i4           
    40 : jmp_ne                 __loops_label_4  
    41 : cmp                    i3, i5           
    42 : jmp_ne                 __loops_label_4  
    43 : annotation:ifcend                       
    44 : annotation:break       2                
    45 : annotation:endif       4                
    46 : shl                    i19, i16, 1      
    47 : annotation:ifcstart                     
    48 : cmp                    i19, i11         
    49 : jmp_gt                 __loops_label_6  
    50 : annotation:ifcend                       
    51 : annotation:ifcstart                     
    52 : cmp                    i2, i4           
    53 : jmp_ne                 __loops_label_8  
    54 : annotation:ifcend                       
    55 : annotation:break       2                
    56 : annotation:endif       8                
    57 : add                    i16, i16, i11    
    58 : add                    i2, i2, i9       
    59 : annotation:endif       6                
    60 : annotation:ifcstart                     
    61 : cmp                    i19, i7          
    62 : jmp_gt                 __loops_label_10 
    63 : annotation:ifcend                       
    64 : annotation:ifcstart                     
    65 : cmp                    i3, i5           
    66 : jmp_ne                 __loops_label_12 
    67 : annotation:ifcend                       
    68 : annotation:break       2                
    69 : annotation:endif       12               
    70 : add                    i16, i16, i7     
    71 : add                    i3, i3, i14      
    72 : annotation:endif       10               
    73 : annotation:endwhile    0, 2             
    74 : ret                                     
