helloworld_call()
     0 : mov        i0, -358482374 
     1 : call_noret [i0]()         
     2 : ret                       
