helloworld_call()
     0 : mov        i0, -812950850 
     1 : call_noret [i0]()         
     2 : ret                       
