helloworld_call()
     0 : mov        i0, -602489878 
     1 : call_noret [i0]()         
     2 : ret                       
