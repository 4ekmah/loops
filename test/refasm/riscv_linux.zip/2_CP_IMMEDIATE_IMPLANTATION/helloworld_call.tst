helloworld_call()
     0 : mov        i0, -1398910030 
     1 : call_noret [i0]()          
     2 : ret                        
