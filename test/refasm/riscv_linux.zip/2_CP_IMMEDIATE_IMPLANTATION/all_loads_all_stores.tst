all_loads_all_stores(i0, i1, i2, i3, i4)
     0 : mov                    i5, 0            
     1 : mov                    i6, 0            
     2 : mov                    i7, 0            
     3 : mov                    i8, 2            
     4 : mov                    i9, 1            
     5 : mov                    i19, 1           
     6 : cmp                    i1, i19          
     7 : select_gt              i10, i8, i9      
     8 : mov                    i11, 4           
     9 : mov                    i20, 3           
    10 : cmp                    i1, i20          
    11 : select_gt              i10, i11, i10    
    12 : mov                    i12, 8           
    13 : mov                    i21, 5           
    14 : cmp                    i1, i21          
    15 : select_gt              i10, i12, i10    
    16 : mov                    i13, 2           
    17 : mov                    i14, 1           
    18 : mov                    i22, 1           
    19 : cmp                    i3, i22          
    20 : select_gt              i15, i13, i14    
    21 : mov                    i16, 4           
    22 : mov                    i23, 3           
    23 : cmp                    i3, i23          
    24 : select_gt              i15, i16, i15    
    25 : mov                    i17, 8           
    26 : mov                    i24, 5           
    27 : cmp                    i3, i24          
    28 : select_gt              i15, i17, i15    
    29 : annotation:whilecstart 0                
    30 : cmp                    i5, i4           
    31 : jmp_ge                 __loops_label_2  
    32 : annotation:whilecend                    
    33 : def                    i18              
    34 : annotation:ifcstart                     
    35 : mov                    i25, 0           
    36 : cmp                    i1, i25          
    37 : jmp_ne                 __loops_label_4  
    38 : annotation:ifcend                       
    39 : load.u8                i18, i0, i6      
    40 : annotation:elif        4, 5             
    41 : mov                    i26, 1           
    42 : cmp                    i1, i26          
    43 : jmp_ne                 __loops_label_7  
    44 : annotation:ifcend                       
    45 : load.i8                i18, i0, i6      
    46 : annotation:elif        7, 8             
    47 : mov                    i27, 2           
    48 : cmp                    i1, i27          
    49 : jmp_ne                 __loops_label_10 
    50 : annotation:ifcend                       
    51 : load.u16               i18, i0, i6      
    52 : annotation:elif        10, 11           
    53 : mov                    i28, 3           
    54 : cmp                    i1, i28          
    55 : jmp_ne                 __loops_label_13 
    56 : annotation:ifcend                       
    57 : load.i16               i18, i0, i6      
    58 : annotation:elif        13, 14           
    59 : mov                    i29, 4           
    60 : cmp                    i1, i29          
    61 : jmp_ne                 __loops_label_16 
    62 : annotation:ifcend                       
    63 : load.u32               i18, i0, i6      
    64 : annotation:elif        16, 17           
    65 : mov                    i30, 5           
    66 : cmp                    i1, i30          
    67 : jmp_ne                 __loops_label_19 
    68 : annotation:ifcend                       
    69 : load.i32               i18, i0, i6      
    70 : annotation:elif        19, 20           
    71 : mov                    i31, 6           
    72 : cmp                    i1, i31          
    73 : jmp_ne                 __loops_label_22 
    74 : annotation:ifcend                       
    75 : load.u64               i18, i0, i6      
    76 : annotation:else        22, 23           
    77 : load.i64               i18, i0, i6      
    78 : annotation:endif       23               
    79 : annotation:ifcstart                     
    80 : mov                    i32, 0           
    81 : cmp                    i3, i32          
    82 : jmp_ne                 __loops_label_25 
    83 : annotation:ifcend                       
    84 : store.u8               i2, i7, i18      
    85 : annotation:elif        25, 26           
    86 : mov                    i33, 1           
    87 : cmp                    i3, i33          
    88 : jmp_ne                 __loops_label_28 
    89 : annotation:ifcend                       
    90 : store.i8               i2, i7, i18      
    91 : annotation:elif        28, 29           
    92 : mov                    i34, 2           
    93 : cmp                    i3, i34          
    94 : jmp_ne                 __loops_label_31 
    95 : annotation:ifcend                       
    96 : store.u16              i2, i7, i18      
    97 : annotation:elif        31, 32           
    98 : mov                    i35, 3           
    99 : cmp                    i3, i35          
   100 : jmp_ne                 __loops_label_34 
   101 : annotation:ifcend                       
   102 : store.i16              i2, i7, i18      
   103 : annotation:elif        34, 35           
   104 : mov                    i36, 4           
   105 : cmp                    i3, i36          
   106 : jmp_ne                 __loops_label_37 
   107 : annotation:ifcend                       
   108 : store.u32              i2, i7, i18      
   109 : annotation:elif        37, 38           
   110 : mov                    i37, 5           
   111 : cmp                    i3, i37          
   112 : jmp_ne                 __loops_label_40 
   113 : annotation:ifcend                       
   114 : store.i32              i2, i7, i18      
   115 : annotation:elif        40, 41           
   116 : mov                    i38, 6           
   117 : cmp                    i3, i38          
   118 : jmp_ne                 __loops_label_43 
   119 : annotation:ifcend                       
   120 : store.u64              i2, i7, i18      
   121 : annotation:else        43, 44           
   122 : store.i64              i2, i7, i18      
   123 : annotation:endif       44               
   124 : add                    i6, i6, i10      
   125 : add                    i7, i7, i15      
   126 : add                    i5, i5, 1        
   127 : annotation:endwhile    0, 2             
