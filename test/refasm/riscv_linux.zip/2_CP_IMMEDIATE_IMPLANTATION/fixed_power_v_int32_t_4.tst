fixed_power_v_int32_t_4(i0, i1, i2)
     0 : mov                    i3, 0           
     1 : mov                    i4, 4           
     2 : mul                    i2, i2, i4      
     3 : annotation:whilecstart 0               
     4 : cmp                    i3, i2          
     5 : jmp_ge                 __loops_label_2 
     6 : annotation:whilecend                   
     7 : vld.i32                v0, i0, i3      
     8 : mul.i32                v2, v0, v0      
     9 : mul.i32                v1, v2, v2      
    10 : vst.i32                i1, i3, v1      
    11 : add                    i3, i3, 32      
    12 : annotation:endwhile    0, 2            
    13 : mov                    iR, 0           
    14 : ret                                    
