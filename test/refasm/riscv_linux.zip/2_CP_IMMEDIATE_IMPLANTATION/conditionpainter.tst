conditionpainter(i0)
     0 : mov                    i1, -5          
     1 : annotation:whilecstart 0               
     2 : mov                    i54, 5          
     3 : cmp                    i1, i54         
     4 : jmp_gt                 __loops_label_2 
     5 : annotation:whilecend                   
     6 : add                    i4, i1, 5       
     7 : mov                    i55, 11         
     8 : mul                    i3, i4, i55     
     9 : mov                    i56, 8          
    10 : mul                    i2, i3, i56     
    11 : mov                    i5, -5          
    12 : annotation:whilecstart 3               
    13 : mov                    i57, 5          
    14 : cmp                    i5, i57         
    15 : jmp_gt                 __loops_label_5 
    16 : annotation:whilecend                   
    17 : add                    i10, i5, 3      
    18 : cmp                    i1, i10         
    19 : iverson_ge             i11             
    20 : mov                    i58, 4          
    21 : cmp                    i1, i58         
    22 : iverson_le             i12             
    23 : and                    i9, i11, i12    
    24 : mov                    i59, -2         
    25 : cmp                    i5, i59         
    26 : iverson_ge             i13             
    27 : and                    i8, i9, i13     
    28 : mov                    i60, 0          
    29 : cmp                    i5, i60         
    30 : iverson_le             i14             
    31 : and                    i7, i8, i14     
    32 : sub                    i18, i5, 1      
    33 : cmp                    i1, i18         
    34 : iverson_le             i19             
    35 : mov                    i61, 0          
    36 : cmp                    i5, i61         
    37 : iverson_ge             i20             
    38 : and                    i17, i19, i20   
    39 : mov                    i62, 0          
    40 : cmp                    i1, i62         
    41 : iverson_le             i21             
    42 : and                    i16, i17, i21   
    43 : mul                    i23, i5, i5     
    44 : mul                    i24, i1, i1     
    45 : add                    i22, i23, i24   
    46 : mov                    i63, 9          
    47 : cmp                    i22, i63        
    48 : iverson_le             i25             
    49 : and                    i15, i16, i25   
    50 : or                     i6, i7, i15     
    51 : mov                    i26, 2          
    52 : mov                    i27, 0          
    53 : mov                    i64, 2          
    54 : cmp                    i5, i64         
    55 : iverson_ge             i31             
    56 : mov                    i65, 4          
    57 : cmp                    i5, i65         
    58 : iverson_le             i32             
    59 : and                    i30, i31, i32   
    60 : mov                    i66, 1          
    61 : cmp                    i1, i66         
    62 : iverson_ge             i34             
    63 : mov                    i67, 3          
    64 : cmp                    i1, i67         
    65 : iverson_le             i35             
    66 : and                    i33, i34, i35   
    67 : or                     i29, i30, i33   
    68 : mul                    i37, i5, i5     
    69 : mul                    i38, i1, i1     
    70 : add                    i36, i37, i38   
    71 : mov                    i68, 16         
    72 : cmp                    i36, i68        
    73 : iverson_le             i39             
    74 : and                    i28, i29, i39   
    75 : mov                    i69, 0          
    76 : cmp                    i28, i69        
    77 : select_ne              i40, i26, i27   
    78 : add                    i6, i6, i40     
    79 : annotation:ifcstart                    
    80 : mov                    i70, 2          
    81 : mul                    i41, i1, i70    
    82 : cmp                    i41, i5         
    83 : jmp_gt                 __loops_label_8 
    84 : add                    i44, i5, 3      
    85 : neg                    i43, i44        
    86 : add                    i45, i5, 3      
    87 : mul                    i42, i43, i45   
    88 : cmp                    i1, i42         
    89 : jmp_le                 __loops_label_9 
    90 : __loops_label_8:                       
    91 : mov                    i71, 2          
    92 : mul                    i46, i5, i71    
    93 : cmp                    i1, i46         
    94 : jmp_gt                 __loops_label_7 
    95 : add                    i49, i5, 3      
    96 : neg                    i48, i49        
    97 : add                    i50, i5, 3      
    98 : mul                    i47, i48, i50   
    99 : cmp                    i1, i47         
   100 : jmp_gt                 __loops_label_7 
   101 : __loops_label_9:                       
   102 : mov                    i72, 0          
   103 : cmp                    i5, i72         
   104 : jmp_gt                 __loops_label_7 
   105 : annotation:ifcend                      
   106 : add                    i6, i6, 3       
   107 : annotation:endif       7               
   108 : add                    i53, i5, 5      
   109 : shl                    i52, i53, 3     
   110 : add                    i51, i2, i52    
   111 : store.i64              i0, i51, i6     
   112 : add                    i5, i5, 1       
   113 : annotation:endwhile    3, 5            
   114 : add                    i1, i1, 1       
   115 : annotation:endwhile    0, 2            
   116 : ret                                    
