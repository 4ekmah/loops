sort_double(i0, i1)
     0 : shl                    i1, i1, 3         
     1 : sub                    i2, i1, 8         
     2 : mov                    i3, 0             
     3 : annotation:whilecstart 0                 
     4 : cmp                    i3, i2            
     5 : jmp_ge                 __loops_label_2   
     6 : annotation:whilecend                     
     7 : mov                    i4, i3            
     8 : add                    i5, i4, 8         
     9 : annotation:whilecstart 3                 
    10 : cmp                    i5, i1            
    11 : jmp_ge                 __loops_label_5   
    12 : annotation:whilecend                     
    13 : annotation:ifcstart                      
    14 : load.fp64              i7, i0, i5        
    15 : load.fp64              i8, i0, i4        
    16 : mov                    i11, -1398902106  
    17 : call                   [i11](i6, i7, i8) 
    18 : mov                    i12, 0            
    19 : cmp                    i6, i12           
    20 : jmp_eq                 __loops_label_7   
    21 : annotation:ifcend                        
    22 : mov                    i4, i5            
    23 : annotation:endif       7                 
    24 : add                    i5, i5, 8         
    25 : annotation:endwhile    3, 5              
    26 : annotation:ifcstart                      
    27 : cmp                    i4, i3            
    28 : jmp_eq                 __loops_label_9   
    29 : annotation:ifcend                        
    30 : load.fp64              i9, i0, i3        
    31 : load.fp64              i10, i0, i4       
    32 : store.fp64             i0, i4, i9        
    33 : store.fp64             i0, i3, i10       
    34 : annotation:endif       9                 
    35 : add                    i3, i3, 8         
    36 : annotation:endwhile    0, 2              
    37 : ret                                      
