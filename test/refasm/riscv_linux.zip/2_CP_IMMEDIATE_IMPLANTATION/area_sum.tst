area_sum(i0, i1)
     0 : mov                    i2, 0               
     1 : annotation:whilecstart 0                   
     2 : mov                    i16, 0              
     3 : cmp                    i1, i16             
     4 : jmp_le                 __loops_label_2     
     5 : annotation:whilecend                       
     6 : load.i8                i3, i0              
     7 : mov                    i4, -1398897832     
     8 : mov                    i5, -1398897638     
     9 : mov                    i6, -1398897494     
    10 : mov                    i17, 1              
    11 : cmp                    i3, i17             
    12 : select_eq              i7, i5, i6          
    13 : mov                    i18, 0              
    14 : cmp                    i3, i18             
    15 : select_eq              i8, i4, i7          
    16 : mov                    i9, -1398898124     
    17 : mov                    i10, -1398898028    
    18 : mov                    i11, -1398897966    
    19 : mov                    i19, 1              
    20 : cmp                    i3, i19             
    21 : select_eq              i12, i10, i11       
    22 : mov                    i20, 0              
    23 : cmp                    i3, i20             
    24 : select_eq              i13, i9, i12        
    25 : call_noret             [i8](i0)            
    26 : call                   [i13](i14, i0)      
    27 : mov                    i21, -1398898192    
    28 : call                   [i21](i15, i2, i14) 
    29 : mov                    i2, i15             
    30 : add                    i0, i0, 56          
    31 : sub                    i1, i1, 1           
    32 : annotation:endwhile    0, 2                
    33 : mov                    iR, i2              
    34 : ret                                        
