bresenham(i0, i1, i2, i3, i4, i5, i6)
     0 : sub                    i8, i4, i2       
     1 : abs                    i7, i8           
     2 : sub                    i10, i4, i2      
     3 : sign                   i9, i10          
     4 : sub                    i13, i5, i3      
     5 : abs                    i12, i13         
     6 : neg                    i11, i12         
     7 : sub                    i15, i5, i3      
     8 : sign                   i14, i15         
     9 : add                    i16, i7, i11     
    10 : annotation:whilecstart 0                
    11 : mov                    i20, 0           
    12 : cmp                    i0, i20          
    13 : jmp_eq                 __loops_label_2  
    14 : annotation:whilecend                    
    15 : mul                    i18, i3, i1      
    16 : add                    i17, i18, i2     
    17 : store.u8               i0, i17, i6      
    18 : annotation:ifcstart                     
    19 : cmp                    i2, i4           
    20 : jmp_ne                 __loops_label_4  
    21 : cmp                    i3, i5           
    22 : jmp_ne                 __loops_label_4  
    23 : annotation:ifcend                       
    24 : annotation:break       2                
    25 : annotation:endif       4                
    26 : shl                    i19, i16, 1      
    27 : annotation:ifcstart                     
    28 : cmp                    i19, i11         
    29 : jmp_gt                 __loops_label_6  
    30 : annotation:ifcend                       
    31 : annotation:ifcstart                     
    32 : cmp                    i2, i4           
    33 : jmp_ne                 __loops_label_8  
    34 : annotation:ifcend                       
    35 : annotation:break       2                
    36 : annotation:endif       8                
    37 : add                    i16, i16, i11    
    38 : add                    i2, i2, i9       
    39 : annotation:endif       6                
    40 : annotation:ifcstart                     
    41 : cmp                    i19, i7          
    42 : jmp_gt                 __loops_label_10 
    43 : annotation:ifcend                       
    44 : annotation:ifcstart                     
    45 : cmp                    i3, i5           
    46 : jmp_ne                 __loops_label_12 
    47 : annotation:ifcend                       
    48 : annotation:break       2                
    49 : annotation:endif       12               
    50 : add                    i16, i16, i7     
    51 : add                    i3, i3, i14      
    52 : annotation:endif       10               
    53 : annotation:endwhile    0, 2             
    54 : ret                                     
