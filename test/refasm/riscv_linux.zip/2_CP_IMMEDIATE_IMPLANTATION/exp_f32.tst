exp_f32(i0, i1, i2)
     0 : mov                    v0, -1028603739    
     1 : mov                    v1, 1118879909     
     2 : mov                    v2, 1056964608     
     3 : mov                    v3, 1065353216     
     4 : mov                    v4, 1069066811     
     5 : mov                    v5, -1087275008    
     6 : mov                    v6, 962494595      
     7 : mov                    v7, 961571175      
     8 : mov                    v8, 985088974      
     9 : mov                    v9, 1007192328     
    10 : mov                    v10, 1026206145    
    11 : mov                    v11, 1042983594    
    12 : mov                    v12, 1056964608    
    13 : mov                    v13, 127           
    14 : mov                    i3, 0              
    15 : annotation:whilecstart 0                  
    16 : mov                    i4, 0              
    17 : cmp                    i2, i4             
    18 : jmp_le                 __loops_label_2    
    19 : annotation:whilecend                      
    20 : vld.fp32               v14, i1, i3        
    21 : min.fp32               v21, v14, v1       
    22 : max.fp32               v20, v21, v0       
    23 : fma.fp32               v24, v2, v20, v4   
    24 : floor.fp32_i32         v23, v24           
    25 : cast.i32_fp32          v22, v23           
    26 : fma.fp32               v19, v20, v22, v5  
    27 : fma.fp32               v18, v19, v22, v6  
    28 : fma.fp32               v29, v8, v18, v7   
    29 : fma.fp32               v28, v9, v29, v18  
    30 : fma.fp32               v27, v10, v28, v18 
    31 : fma.fp32               v26, v11, v27, v18 
    32 : fma.fp32               v25, v12, v26, v18 
    33 : mul.fp32               v30, v18, v18      
    34 : fma.fp32               v17, v18, v25, v30 
    35 : add.fp32               v16, v17, v3       
    36 : add.i32                v32, v23, v13      
    37 : sal.i32                v31, v32, 23       
    38 : mul.fp32               v15, v16, v31      
    39 : vst.fp32               i0, i3, v15        
    40 : add                    i3, i3, 32         
    41 : sub                    i2, i2, 8          
    42 : annotation:endwhile    0, 2               
    43 : ret                                       
