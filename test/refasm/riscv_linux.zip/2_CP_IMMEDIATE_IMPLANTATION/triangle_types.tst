triangle_types(i0, i1, i2)
     0 : annotation:ifcstart                  
     1 : mov                 i30, 0           
     2 : cmp                 i0, i30          
     3 : jmp_le              __loops_label_0  
     4 : mov                 i31, 0           
     5 : cmp                 i1, i31          
     6 : jmp_le              __loops_label_0  
     7 : mov                 i32, 0           
     8 : cmp                 i2, i32          
     9 : jmp_gt              __loops_label_1  
    10 : __loops_label_0:                     
    11 : annotation:ifcend                    
    12 : mov                 iR, 0            
    13 : ret                                  
    14 : annotation:elif     1, 2             
    15 : add                 i3, i1, i2       
    16 : cmp                 i0, i3           
    17 : jmp_gt              __loops_label_3  
    18 : add                 i4, i0, i2       
    19 : cmp                 i1, i4           
    20 : jmp_gt              __loops_label_3  
    21 : add                 i5, i0, i1       
    22 : cmp                 i2, i5           
    23 : jmp_le              __loops_label_4  
    24 : __loops_label_3:                     
    25 : annotation:ifcend                    
    26 : mov                 iR, 0            
    27 : ret                                  
    28 : annotation:elif     4, 5             
    29 : cmp                 i0, i1           
    30 : jmp_ne              __loops_label_7  
    31 : cmp                 i0, i2           
    32 : jmp_ne              __loops_label_7  
    33 : annotation:ifcend                    
    34 : mov                 iR, 2            
    35 : ret                                  
    36 : annotation:elif     7, 8             
    37 : cmp                 i0, i1           
    38 : jmp_eq              __loops_label_9  
    39 : cmp                 i0, i2           
    40 : jmp_eq              __loops_label_9  
    41 : cmp                 i1, i2           
    42 : jmp_ne              __loops_label_10 
    43 : __loops_label_9:                     
    44 : annotation:ifcend                    
    45 : mov                 iR, 3            
    46 : ret                                  
    47 : annotation:elif     10, 11           
    48 : mul                 i6, i0, i0       
    49 : mul                 i8, i1, i1       
    50 : mul                 i9, i2, i2       
    51 : add                 i7, i8, i9       
    52 : cmp                 i6, i7           
    53 : jmp_eq              __loops_label_12 
    54 : mul                 i10, i1, i1      
    55 : mul                 i12, i0, i0      
    56 : mul                 i13, i2, i2      
    57 : add                 i11, i12, i13    
    58 : cmp                 i10, i11         
    59 : jmp_eq              __loops_label_12 
    60 : mul                 i14, i2, i2      
    61 : mul                 i16, i0, i0      
    62 : mul                 i17, i1, i1      
    63 : add                 i15, i16, i17    
    64 : cmp                 i14, i15         
    65 : jmp_ne              __loops_label_13 
    66 : __loops_label_12:                    
    67 : annotation:ifcend                    
    68 : mov                 iR, 1            
    69 : ret                                  
    70 : annotation:elif     13, 14           
    71 : mul                 i18, i0, i0      
    72 : mul                 i20, i1, i1      
    73 : mul                 i21, i2, i2      
    74 : add                 i19, i20, i21    
    75 : cmp                 i18, i19         
    76 : jmp_gt              __loops_label_15 
    77 : mul                 i22, i1, i1      
    78 : mul                 i24, i0, i0      
    79 : mul                 i25, i2, i2      
    80 : add                 i23, i24, i25    
    81 : cmp                 i22, i23         
    82 : jmp_gt              __loops_label_15 
    83 : mul                 i26, i2, i2      
    84 : mul                 i28, i0, i0      
    85 : mul                 i29, i1, i1      
    86 : add                 i27, i28, i29    
    87 : cmp                 i26, i27         
    88 : jmp_le              __loops_label_16 
    89 : __loops_label_15:                    
    90 : annotation:ifcend                    
    91 : mov                 iR, 5            
    92 : ret                                  
    93 : annotation:else     16, 17           
    94 : mov                 iR, 4            
    95 : ret                                  
    96 : annotation:endif    17               
