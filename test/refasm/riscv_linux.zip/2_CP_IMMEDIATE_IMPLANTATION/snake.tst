snake(i0, i1, i2)
     0 : add                    i4, i1, i2       
     1 : sub                    i3, i4, 1        
     2 : mov                    i5, 0            
     3 : mov                    i6, 1            
     4 : neg                    i7, i6           
     5 : mov                    i8, 0            
     6 : annotation:whilecstart 0                
     7 : cmp                    i8, i3           
     8 : jmp_ge                 __loops_label_2  
     9 : annotation:whilecend                    
    10 : mov                    i9, 0            
    11 : mov                    i10, 0           
    12 : annotation:ifcstart                     
    13 : and                    i11, i8, 1       
    14 : mov                    i20, 0           
    15 : cmp                    i11, i20         
    16 : jmp_eq                 __loops_label_4  
    17 : annotation:ifcend                       
    18 : sub                    i12, i2, 1       
    19 : min                    i9, i12, i8      
    20 : sub                    i13, i8, i12     
    21 : mov                    i14, 0           
    22 : cmp                    i8, i12          
    23 : select_gt              i10, i13, i14    
    24 : annotation:else        4, 5             
    25 : sub                    i15, i1, 1       
    26 : sub                    i16, i8, i15     
    27 : mov                    i17, 0           
    28 : cmp                    i8, i15          
    29 : select_gt              i9, i16, i17     
    30 : min                    i10, i15, i8     
    31 : annotation:endif       5                
    32 : annotation:whilecstart 6                
    33 : mov                    i21, 0           
    34 : cmp                    i9, i21          
    35 : jmp_gt                 __loops_label_8  
    36 : cmp                    i9, i2           
    37 : jmp_ge                 __loops_label_8  
    38 : mov                    i22, 0           
    39 : cmp                    i10, i22         
    40 : jmp_gt                 __loops_label_8  
    41 : cmp                    i10, i1          
    42 : jmp_ge                 __loops_label_8  
    43 : annotation:whilecend                    
    44 : mov                    i23, -1398908398 
    45 : call_noret             [i23](i9, i10)   
    46 : mul                    i19, i10, i2     
    47 : add                    i18, i19, i9     
    48 : store.u8               i0, i18, i5      
    49 : add                    i5, i5, 1        
    50 : add                    i9, i9, i6       
    51 : add                    i10, i10, i7     
    52 : annotation:endwhile    6, 8             
    53 : neg                    i6, i6           
    54 : neg                    i7, i7           
    55 : add                    i8, i8, 1        
    56 : annotation:endwhile    0, 2             
    57 : ret                                     
