nonnegative_odd(i0, i1)
     0 : mov                    i2, 0           
     1 : mov                    i3, -4          
     2 : mov                    i6, 4           
     3 : mul                    i1, i1, i6      
     4 : annotation:whilecstart 0               
     5 : cmp                    i2, i1          
     6 : jmp_ge                 __loops_label_2 
     7 : annotation:whilecend                   
     8 : load.i32               i4, i0, i2      
     9 : annotation:ifcstart                    
    10 : mov                    i7, 0           
    11 : cmp                    i4, i7          
    12 : jmp_ge                 __loops_label_4 
    13 : annotation:ifcend                      
    14 : add                    i2, i2, 4       
    15 : annotation:break       0               
    16 : annotation:endif       4               
    17 : mov                    i8, 2           
    18 : mod                    i5, i4, i8      
    19 : annotation:ifcstart                    
    20 : mov                    i9, 0           
    21 : cmp                    i5, i9          
    22 : jmp_eq                 __loops_label_6 
    23 : annotation:ifcend                      
    24 : mov                    i3, i2          
    25 : annotation:break       2               
    26 : annotation:endif       6               
    27 : add                    i2, i2, 4       
    28 : annotation:endwhile    0, 2            
    29 : mov                    i10, 4          
    30 : div                    i3, i3, i10     
    31 : mov                    iR, i3          
    32 : ret                                    
