min_max_select(i0, i1, i2, i3)
     0 : sub                    i2, i2, 80                
     1 : spill                  7, i24                    
     2 : spill                  8, i25                    
     3 : spill                  9, i26                    
     4 : spill                  1, i12                    
     5 : spill                  0, i13                    
     6 : mov                    i24, 0                    
     7 : mov                    i25, 0                    
     8 : spill                  3, i25                    
     9 : mov                    i25, 0                    
    10 : spill                  2, i25                    
    11 : load.i32               i25, i10                  
    12 : spill                  6, i25                    
    13 : unspill                i25, 6                    
    14 : mov                    i26, i25                  
    15 : spill                  5, i26                    
    16 : shl                    i25, i11, 2               
    17 : spill                  4, i25                    
    18 : annotation:whilecstart 0                         
    19 : unspill                i25, 4                    
    20 : jmp_ge                 i24, i25, __loops_label_2 
    21 : annotation:whilecend                             
    22 : add                    i11, i10, i24             
    23 : load.i32               i11, i11                  
    24 : unspill                i25, 6                    
    25 : iverson_gt             i13, i11, i25             
    26 : unspill                i25, 3                    
    27 : sub                    i12, i24, i25             
    28 : sub                    i13, 0, i13               
    29 : and                    i12, i13, i12             
    30 : unspill                i25, 3                    
    31 : add                    i25, i25, i12             
    32 : spill                  3, i25                    
    33 : unspill                i25, 6                    
    34 : iverson_gt             i12, i11, i25             
    35 : unspill                i25, 6                    
    36 : sub                    i13, i11, i25             
    37 : sub                    i12, 0, i12               
    38 : and                    i12, i12, i13             
    39 : unspill                i25, 6                    
    40 : add                    i25, i25, i12             
    41 : spill                  6, i25                    
    42 : unspill                i25, 5                    
    43 : iverson_gt             i12, i11, i25             
    44 : unspill                i25, 2                    
    45 : sub                    i13, i24, i25             
    46 : sub                    i12, 0, i12               
    47 : and                    i12, i12, i13             
    48 : unspill                i25, 2                    
    49 : add                    i25, i25, i12             
    50 : spill                  2, i25                    
    51 : unspill                i25, 5                    
    52 : iverson_gt             i12, i11, i25             
    53 : unspill                i25, 5                    
    54 : sub                    i13, i25, i11             
    55 : sub                    i12, 0, i12               
    56 : and                    i12, i12, i13             
    57 : add                    i25, i11, i12             
    58 : spill                  5, i25                    
    59 : add                    i24, i24, 4               
    60 : annotation:endwhile    0, 2                      
    61 : unspill                i25, 3                    
    62 : sar                    i10, i25, 2               
    63 : unspill                i25, 2                    
    64 : sar                    i11, i25, 2               
    65 : unspill                i25, 1                    
    66 : store.i32              i25, i10                  
    67 : unspill                i25, 0                    
    68 : store.i32              i25, i11                  
    69 : mov                    i10, 0                    
    70 : ret                                              
    71 : unspill                i24, 7                    
    72 : unspill                i25, 8                    
    73 : unspill                i26, 9                    
    74 : add                    i2, i2, 80                
