bresenham(i0, i1, i2, i3, i4, i5, i6)
     0 : sub                    i2, i2, 80                 
     1 : spill                  5, i24                     
     2 : spill                  6, i25                     
     3 : spill                  7, i26                     
     4 : spill                  8, i27                     
     5 : spill                  0, i16                     
     6 : sub                    i24, i14, i12              
     7 : iverson_gt             i16, 0, i24                
     8 : sub                    i16, 0, i16                
     9 : and                    i16, i16, i24              
    10 : sub                    i24, 0, i24                
    11 : add                    i24, i24, i16              
    12 : add                    i25, i24, i16              
    13 : spill                  1, i25                     
    14 : sub                    i24, i14, i12              
    15 : iverson_gt             i16, i24, 0                
    16 : iverson_gt             i24, 0, i24                
    17 : sub                    i25, i24, i16              
    18 : spill                  2, i25                     
    19 : sub                    i24, i15, i13              
    20 : iverson_gt             i16, 0, i24                
    21 : sub                    i16, 0, i16                
    22 : and                    i16, i16, i24              
    23 : sub                    i24, 0, i24                
    24 : add                    i24, i24, i16              
    25 : add                    i16, i24, i16              
    26 : neg                    i25, i16                   
    27 : spill                  3, i25                     
    28 : sub                    i24, i15, i13              
    29 : iverson_gt             i16, i24, 0                
    30 : iverson_gt             i24, 0, i24                
    31 : sub                    i16, i24, i16              
    32 : unspill                i25, 1                     
    33 : unspill                i26, 3                     
    34 : add                    i27, i25, i26              
    35 : spill                  4, i27                     
    36 : annotation:whilecstart 0                          
    37 : mov                    i24, 0                     
    38 : jmp_eq                 i10, i24, __loops_label_2  
    39 : annotation:whilecend                              
    40 : mul                    i24, i13, i11              
    41 : add                    i24, i24, i12              
    42 : add                    i24, i10, i24              
    43 : unspill                i25, 0                     
    44 : store.u8               i24, i25                   
    45 : annotation:ifcstart                               
    46 : jmp_ne                 i12, i14, __loops_label_4  
    47 : jmp_ne                 i13, i15, __loops_label_4  
    48 : annotation:ifcend                                 
    49 : annotation:break       2                          
    50 : annotation:endif       4                          
    51 : unspill                i25, 4                     
    52 : shl                    i24, i25, 1                
    53 : annotation:ifcstart                               
    54 : unspill                i25, 3                     
    55 : jmp_gt                 i24, i25, __loops_label_6  
    56 : annotation:ifcend                                 
    57 : annotation:ifcstart                               
    58 : jmp_ne                 i12, i14, __loops_label_8  
    59 : annotation:ifcend                                 
    60 : annotation:break       2                          
    61 : annotation:endif       8                          
    62 : unspill                i26, 3                     
    63 : unspill                i25, 4                     
    64 : add                    i25, i25, i26              
    65 : spill                  4, i25                     
    66 : unspill                i25, 2                     
    67 : add                    i12, i12, i25              
    68 : annotation:endif       6                          
    69 : annotation:ifcstart                               
    70 : unspill                i25, 1                     
    71 : jmp_gt                 i24, i25, __loops_label_10 
    72 : annotation:ifcend                                 
    73 : annotation:ifcstart                               
    74 : jmp_ne                 i13, i15, __loops_label_12 
    75 : annotation:ifcend                                 
    76 : annotation:break       2                          
    77 : annotation:endif       12                         
    78 : unspill                i26, 1                     
    79 : unspill                i25, 4                     
    80 : add                    i25, i25, i26              
    81 : spill                  4, i25                     
    82 : add                    i13, i13, i16              
    83 : annotation:endif       10                         
    84 : annotation:endwhile    0, 2                       
    85 : ret                                               
    86 : unspill                i24, 5                     
    87 : unspill                i25, 6                     
    88 : unspill                i26, 7                     
    89 : unspill                i27, 8                     
    90 : add                    i2, i2, 80                 
