fixed_power_1(i0)
     0 : mov i10, i10 
     1 : ret          
