nonnegative_odd(i0, i1)
     0 : sub                    i2, i2, 32                
     1 : spill                  1, i24                    
     2 : spill                  2, i25                    
     3 : mov                    i12, 0                    
     4 : mov                    i25, -4                   
     5 : spill                  0, i25                    
     6 : mov                    i24, 4                    
     7 : mul                    i11, i11, i24             
     8 : annotation:whilecstart 0                         
     9 : jmp_ge                 i12, i11, __loops_label_2 
    10 : annotation:whilecend                             
    11 : add                    i24, i10, i12             
    12 : load.i32               i24, i24                  
    13 : annotation:ifcstart                              
    14 : mov                    i13, 0                    
    15 : jmp_ge                 i24, i13, __loops_label_4 
    16 : annotation:ifcend                                
    17 : add                    i12, i12, 4               
    18 : annotation:break       0                         
    19 : annotation:endif       4                         
    20 : mov                    i13, 2                    
    21 : mod                    i13, i24, i13             
    22 : annotation:ifcstart                              
    23 : mov                    i24, 0                    
    24 : jmp_eq                 i13, i24, __loops_label_6 
    25 : annotation:ifcend                                
    26 : mov                    i25, i12                  
    27 : spill                  0, i25                    
    28 : annotation:break       2                         
    29 : annotation:endif       6                         
    30 : add                    i12, i12, 4               
    31 : annotation:endwhile    0, 2                      
    32 : mov                    i10, 4                    
    33 : unspill                i25, 0                    
    34 : div                    i10, i25, i10             
    35 : mov                    i10, i10                  
    36 : ret                                              
    37 : unspill                i24, 1                    
    38 : unspill                i25, 2                    
    39 : add                    i2, i2, 32                
