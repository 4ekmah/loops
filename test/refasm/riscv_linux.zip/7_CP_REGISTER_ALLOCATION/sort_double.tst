sort_double(i0, i1)
     0 : sub                    i2, i2, 208               
     1 : spill                  21, i24                   
     2 : spill                  22, i25                   
     3 : spill                  23, i26                   
     4 : spill                  24, i8                    
     5 : spill                  25, i1                    
     6 : spill                  19, i10                   
     7 : shl                    i25, i11, 3               
     8 : spill                  18, i25                   
     9 : unspill                i25, 18                   
    10 : sub                    i26, i25, 8               
    11 : spill                  17, i26                   
    12 : mov                    i25, 0                    
    13 : spill                  16, i25                   
    14 : annotation:whilecstart 0                         
    15 : unspill                i26, 17                   
    16 : unspill                i25, 16                   
    17 : jmp_ge                 i25, i26, __loops_label_2 
    18 : annotation:whilecend                             
    19 : unspill                i25, 16                   
    20 : mov                    i26, i25                  
    21 : spill                  20, i26                   
    22 : unspill                i25, 20                   
    23 : add                    i13, i25, 8               
    24 : annotation:whilecstart 3                         
    25 : unspill                i25, 18                   
    26 : jmp_ge                 i13, i25, __loops_label_5 
    27 : annotation:whilecend                             
    28 : annotation:ifcstart                              
    29 : unspill                i25, 19                   
    30 : add                    i12, i25, i13             
    31 : load.fp64              i12, i12                  
    32 : unspill                i25, 19                   
    33 : unspill                i26, 20                   
    34 : add                    i11, i25, i26             
    35 : load.fp64              i11, i11                  
    36 : mov                    i10, 43                   
    37 : shl                    i10, i10, 32              
    38 : rv_lui                 i24, 776381               
    39 : add                    i24, i24, -1960           
    40 : add                    i10, i10, i24             
    41 : call                   [i10](i10, i12, i11)      
    42 : mov                    i11, 0                    
    43 : jmp_eq                 i10, i11, __loops_label_7 
    44 : annotation:ifcend                                
    45 : mov                    i25, i13                  
    46 : spill                  20, i25                   
    47 : annotation:endif       7                         
    48 : add                    i13, i13, 8               
    49 : annotation:endwhile    3, 5                      
    50 : annotation:ifcstart                              
    51 : unspill                i26, 16                   
    52 : unspill                i25, 20                   
    53 : jmp_eq                 i25, i26, __loops_label_9 
    54 : annotation:ifcend                                
    55 : unspill                i25, 19                   
    56 : unspill                i26, 16                   
    57 : add                    i10, i25, i26             
    58 : load.fp64              i10, i10                  
    59 : unspill                i25, 19                   
    60 : unspill                i26, 20                   
    61 : add                    i11, i25, i26             
    62 : load.fp64              i11, i11                  
    63 : unspill                i25, 19                   
    64 : unspill                i26, 20                   
    65 : add                    i12, i25, i26             
    66 : store.fp64             i12, i10                  
    67 : unspill                i25, 19                   
    68 : unspill                i26, 16                   
    69 : add                    i10, i25, i26             
    70 : store.fp64             i10, i11                  
    71 : annotation:endif       9                         
    72 : unspill                i25, 16                   
    73 : add                    i25, i25, 8               
    74 : spill                  16, i25                   
    75 : annotation:endwhile    0, 2                      
    76 : ret                                              
    77 : unspill                i8, 24                    
    78 : unspill                i1, 25                    
    79 : unspill                i24, 21                   
    80 : unspill                i25, 22                   
    81 : unspill                i26, 23                   
    82 : add                    i2, i2, 208               
