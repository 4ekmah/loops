a_plus_b(i0, i1)
     0 : add i10, i10, i11 
     1 : mov i10, i10      
     2 : ret               
