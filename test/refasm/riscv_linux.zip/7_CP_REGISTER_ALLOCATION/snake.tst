snake(i0, i1, i2)
     0 : sub                    i2, i2, 240               
     1 : spill                  25, i24                   
     2 : spill                  26, i25                   
     3 : spill                  27, i26                   
     4 : spill                  28, i8                    
     5 : spill                  29, i1                    
     6 : spill                  23, i10                   
     7 : spill                  22, i11                   
     8 : spill                  21, i12                   
     9 : unspill                i25, 22                   
    10 : unspill                i26, 21                   
    11 : add                    i13, i25, i26             
    12 : sub                    i25, i13, 1               
    13 : spill                  20, i25                   
    14 : mov                    i25, 0                    
    15 : spill                  19, i25                   
    16 : mov                    i25, 1                    
    17 : spill                  16, i25                   
    18 : unspill                i25, 16                   
    19 : neg                    i26, i25                  
    20 : spill                  17, i26                   
    21 : mov                    i25, 0                    
    22 : spill                  18, i25                   
    23 : annotation:whilecstart 0                         
    24 : unspill                i26, 20                   
    25 : unspill                i25, 18                   
    26 : jmp_ge                 i25, i26, __loops_label_2 
    27 : annotation:whilecend                             
    28 : mov                    i24, 0                    
    29 : mov                    i25, 0                    
    30 : spill                  24, i25                   
    31 : annotation:ifcstart                              
    32 : unspill                i25, 18                   
    33 : and                    i12, i25, 1               
    34 : mov                    i11, 0                    
    35 : jmp_eq                 i12, i11, __loops_label_4 
    36 : annotation:ifcend                                
    37 : unspill                i25, 21                   
    38 : sub                    i11, i25, 1               
    39 : unspill                i25, 18                   
    40 : iverson_gt             i12, i11, i25             
    41 : unspill                i25, 18                   
    42 : sub                    i10, i11, i25             
    43 : sub                    i12, 0, i12               
    44 : and                    i10, i12, i10             
    45 : unspill                i25, 18                   
    46 : add                    i24, i25, i10             
    47 : unspill                i25, 18                   
    48 : sub                    i10, i25, i11             
    49 : mov                    i12, 0                    
    50 : unspill                i25, 18                   
    51 : iverson_gt             i11, i25, i11             
    52 : sub                    i10, i10, i12             
    53 : sub                    i11, 0, i11               
    54 : and                    i10, i11, i10             
    55 : add                    i25, i12, i10             
    56 : spill                  24, i25                   
    57 : annotation:else        4, 5                      
    58 : unspill                i25, 22                   
    59 : sub                    i10, i25, 1               
    60 : unspill                i25, 18                   
    61 : sub                    i11, i25, i10             
    62 : mov                    i12, 0                    
    63 : unspill                i25, 18                   
    64 : iverson_gt             i13, i25, i10             
    65 : sub                    i11, i11, i12             
    66 : sub                    i13, 0, i13               
    67 : and                    i11, i13, i11             
    68 : add                    i24, i12, i11             
    69 : unspill                i25, 18                   
    70 : iverson_gt             i11, i10, i25             
    71 : unspill                i25, 18                   
    72 : sub                    i10, i10, i25             
    73 : sub                    i11, 0, i11               
    74 : and                    i10, i11, i10             
    75 : unspill                i25, 18                   
    76 : add                    i26, i25, i10             
    77 : spill                  24, i26                   
    78 : annotation:endif       5                         
    79 : annotation:whilecstart 6                         
    80 : mov                    i10, 0                    
    81 : jmp_gt                 i24, i10, __loops_label_8 
    82 : unspill                i25, 21                   
    83 : jmp_ge                 i24, i25, __loops_label_8 
    84 : mov                    i10, 0                    
    85 : unspill                i25, 24                   
    86 : jmp_gt                 i25, i10, __loops_label_8 
    87 : unspill                i26, 22                   
    88 : unspill                i25, 24                   
    89 : jmp_ge                 i25, i26, __loops_label_8 
    90 : annotation:whilecend                             
    91 : mov                    i10, 43                   
    92 : shl                    i10, i10, 32              
    93 : rv_lui                 i11, 776381               
    94 : add                    i11, i11, -888            
    95 : add                    i10, i10, i11             
    96 : unspill                i25, 24                   
    97 : call_noret             [i10](i24, i25)           
    98 : unspill                i26, 21                   
    99 : unspill                i25, 24                   
   100 : mul                    i10, i25, i26             
   101 : add                    i10, i10, i24             
   102 : unspill                i25, 23                   
   103 : add                    i10, i25, i10             
   104 : unspill                i25, 19                   
   105 : store.u8               i10, i25                  
   106 : unspill                i25, 19                   
   107 : add                    i25, i25, 1               
   108 : spill                  19, i25                   
   109 : unspill                i25, 16                   
   110 : add                    i24, i24, i25             
   111 : unspill                i26, 17                   
   112 : unspill                i25, 24                   
   113 : add                    i25, i25, i26             
   114 : spill                  24, i25                   
   115 : annotation:endwhile    6, 8                      
   116 : unspill                i25, 16                   
   117 : neg                    i25, i25                  
   118 : spill                  16, i25                   
   119 : unspill                i25, 17                   
   120 : neg                    i25, i25                  
   121 : spill                  17, i25                   
   122 : unspill                i25, 18                   
   123 : add                    i25, i25, 1               
   124 : spill                  18, i25                   
   125 : annotation:endwhile    0, 2                      
   126 : ret                                              
   127 : unspill                i8, 28                    
   128 : unspill                i1, 29                    
   129 : unspill                i24, 25                   
   130 : unspill                i25, 26                   
   131 : unspill                i26, 27                   
   132 : add                    i2, i2, 240               
