min_max_scalar(i0, i1, i2, i3)
     0 : sub                    i2, i2, 64                
     1 : spill                  5, i24                    
     2 : spill                  6, i25                    
     3 : spill                  1, i12                    
     4 : spill                  0, i13                    
     5 : mov                    i24, 0                    
     6 : mov                    i25, 0                    
     7 : spill                  3, i25                    
     8 : mov                    i25, 0                    
     9 : spill                  2, i25                    
    10 : load.i32               i12, i10                  
    11 : mov                    i25, i12                  
    12 : spill                  4, i25                    
    13 : mov                    i13, 4                    
    14 : mul                    i11, i11, i13             
    15 : annotation:whilecstart 0                         
    16 : jmp_ge                 i24, i11, __loops_label_2 
    17 : annotation:whilecend                             
    18 : add                    i13, i10, i24             
    19 : load.i32               i13, i13                  
    20 : annotation:ifcstart                              
    21 : jmp_ge                 i13, i12, __loops_label_4 
    22 : annotation:ifcend                                
    23 : mov                    i12, i13                  
    24 : mov                    i25, i24                  
    25 : spill                  3, i25                    
    26 : annotation:endif       4                         
    27 : annotation:ifcstart                              
    28 : unspill                i25, 4                    
    29 : jmp_le                 i13, i25, __loops_label_6 
    30 : annotation:ifcend                                
    31 : mov                    i25, i13                  
    32 : spill                  4, i25                    
    33 : mov                    i25, i24                  
    34 : spill                  2, i25                    
    35 : annotation:endif       6                         
    36 : add                    i24, i24, 4               
    37 : annotation:endwhile    0, 2                      
    38 : mov                    i10, 4                    
    39 : unspill                i25, 3                    
    40 : div                    i11, i25, i10             
    41 : unspill                i25, 2                    
    42 : div                    i10, i25, i10             
    43 : unspill                i25, 1                    
    44 : store.i32              i25, i11                  
    45 : unspill                i25, 0                    
    46 : store.i32              i25, i10                  
    47 : mov                    i10, 0                    
    48 : ret                                              
    49 : unspill                i24, 5                    
    50 : unspill                i25, 6                    
    51 : add                    i2, i2, 64                
