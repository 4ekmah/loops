big_immediates(i0)
     0 : rv_lui    i11, 1          
     1 : add       i11, i11, 0     
     2 : store.u64 i10, i11        
     3 : add       i10, i10, 8     
     4 : rv_lui    i11, 2          
     5 : add       i11, i11, -1    
     6 : store.u64 i10, i11        
     7 : add       i10, i10, 8     
     8 : rv_lui    i11, 524288     
     9 : xor       i11, i11, -1366 
    10 : store.u64 i10, i11        
    11 : add       i10, i10, 8     
    12 : mov       i11, 1          
    13 : shl       i11, i11, 32    
    14 : mov       i12, 0          
    15 : add       i11, i11, i12   
    16 : store.u64 i10, i11        
    17 : add       i10, i10, 8     
    18 : mov       i11, 2          
    19 : shl       i11, i11, 32    
    20 : mov       i12, -1         
    21 : add       i11, i11, i12   
    22 : store.u64 i10, i11        
    23 : add       i10, i10, 8     
    24 : mov       i11, 1          
    25 : shl       i11, i11, 63    
    26 : rv_lui    i12, 699051     
    27 : add       i12, i12, -1366 
    28 : xor       i11, i11, i12   
    29 : store.u64 i10, i11        
    30 : add       i10, i10, 8     
    31 : rv_lui    i11, 16         
    32 : add       i11, i11, -1    
    33 : store.u64 i10, i11        
    34 : add       i10, i10, 8     
    35 : rv_lui    i11, 16         
    36 : add       i11, i11, 0     
    37 : store.u64 i10, i11        
    38 : add       i10, i10, 8     
    39 : rv_lui    i11, 1048568    
    40 : add       i11, i11, 0     
    41 : store.i64 i10, i11        
    42 : add       i10, i10, 8     
    43 : rv_lui    i11, 1048568    
    44 : add       i11, i11, -1    
    45 : store.i64 i10, i11        
    46 : add       i10, i10, 8     
    47 : rv_lui    i11, 390006     
    48 : add       i11, i11, -1569 
    49 : store.u64 i10, i11        
    50 : add       i10, i10, 8     
    51 : rv_lui    i11, 262236     
    52 : add       i11, i11, -245  
    53 : shl       i11, i11, 32    
    54 : rv_lui    i12, 569669     
    55 : add       i12, i12, 1897  
    56 : add       i11, i11, i12   
    57 : store.u64 i10, i11        
    58 : add       i10, i10, 8     
    59 : ret                       
