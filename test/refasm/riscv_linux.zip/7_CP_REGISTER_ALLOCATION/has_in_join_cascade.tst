has_in_join_cascade(i0, i1, i2)
     0 : sub                    i2, i2, 128                
     1 : spill                  13, i24                    
     2 : spill                  14, i25                    
     3 : spill                  15, i26                    
     4 : spill                  6, i10                     
     5 : spill                  5, i11                     
     6 : spill                  4, i12                     
     7 : mov                    i25, 0                     
     8 : spill                  0, i25                     
     9 : unspill                i25, 6                     
    10 : load.i64               i26, i25, 16               
    11 : spill                  3, i26                     
    12 : unspill                i25, 6                     
    13 : load.i64               i26, i25, 0                
    14 : spill                  2, i26                     
    15 : unspill                i25, 6                     
    16 : load.i64               i26, i25, 8                
    17 : spill                  1, i26                     
    18 : annotation:whilecstart 0                          
    19 : mov                    i13, 0                     
    20 : unspill                i25, 3                     
    21 : jmp_le                 i25, i13, __loops_label_2  
    22 : annotation:whilecend                              
    23 : unspill                i25, 2                     
    24 : load.i32               i26, i25                   
    25 : spill                  11, i26                    
    26 : unspill                i25, 2                     
    27 : add                    i25, i25, 4                
    28 : spill                  2, i25                     
    29 : unspill                i25, 1                     
    30 : load.i32               i26, i25                   
    31 : spill                  10, i26                    
    32 : unspill                i25, 1                     
    33 : add                    i25, i25, 4                
    34 : spill                  1, i25                     
    35 : unspill                i25, 3                     
    36 : sub                    i25, i25, 1                
    37 : spill                  3, i25                     
    38 : unspill                i25, 6                     
    39 : load.i64               i26, i25, 40               
    40 : spill                  9, i26                     
    41 : unspill                i25, 6                     
    42 : load.i64               i26, i25, 24               
    43 : spill                  8, i26                     
    44 : unspill                i25, 6                     
    45 : load.i64               i26, i25, 32               
    46 : spill                  7, i26                     
    47 : annotation:whilecstart 3                          
    48 : mov                    i10, 0                     
    49 : unspill                i25, 9                     
    50 : jmp_le                 i25, i10, __loops_label_5  
    51 : annotation:whilecend                              
    52 : unspill                i25, 8                     
    53 : load.i32               i10, i25                   
    54 : unspill                i25, 8                     
    55 : add                    i25, i25, 4                
    56 : spill                  8, i25                     
    57 : unspill                i25, 7                     
    58 : load.i32               i11, i25                   
    59 : unspill                i25, 7                     
    60 : add                    i25, i25, 4                
    61 : spill                  7, i25                     
    62 : unspill                i25, 9                     
    63 : sub                    i25, i25, 1                
    64 : spill                  9, i25                     
    65 : annotation:ifcstart                               
    66 : unspill                i25, 11                    
    67 : jmp_le                 i11, i25, __loops_label_7  
    68 : annotation:ifcend                                 
    69 : annotation:break       3                          
    70 : annotation:else        7, 8                       
    71 : annotation:ifcstart                               
    72 : unspill                i25, 11                    
    73 : jmp_ne                 i11, i25, __loops_label_10 
    74 : annotation:ifcend                                 
    75 : unspill                i25, 6                     
    76 : load.i64               i11, i25, 64               
    77 : unspill                i25, 6                     
    78 : load.i64               i12, i25, 48               
    79 : unspill                i25, 6                     
    80 : load.i64               i26, i25, 56               
    81 : spill                  12, i26                    
    82 : annotation:whilecstart 11                         
    83 : mov                    i13, 0                     
    84 : jmp_le                 i11, i13, __loops_label_13 
    85 : annotation:whilecend                              
    86 : load.i32               i13, i12                   
    87 : add                    i12, i12, 4                
    88 : unspill                i25, 12                    
    89 : load.i32               i24, i25                   
    90 : unspill                i25, 12                    
    91 : add                    i25, i25, 4                
    92 : spill                  12, i25                    
    93 : sub                    i11, i11, 1                
    94 : annotation:ifcstart                               
    95 : unspill                i25, 10                    
    96 : jmp_le                 i13, i25, __loops_label_15 
    97 : annotation:ifcend                                 
    98 : annotation:break       11                         
    99 : annotation:else        15, 16                     
   100 : annotation:ifcstart                               
   101 : unspill                i25, 10                    
   102 : jmp_ne                 i13, i25, __loops_label_18 
   103 : unspill                i25, 5                     
   104 : jmp_ne                 i10, i25, __loops_label_18 
   105 : unspill                i25, 4                     
   106 : jmp_ne                 i24, i25, __loops_label_18 
   107 : annotation:ifcend                                 
   108 : mov                    i25, 1                     
   109 : spill                  0, i25                     
   110 : annotation:break       2                          
   111 : annotation:endif       16                         
   112 : annotation:endif       18                         
   113 : annotation:endwhile    11, 13                     
   114 : annotation:endif       8                          
   115 : annotation:endif       10                         
   116 : annotation:endwhile    3, 5                       
   117 : annotation:endwhile    0, 2                       
   118 : unspill                i25, 0                     
   119 : mov                    i10, i25                   
   120 : ret                                               
   121 : unspill                i24, 13                    
   122 : unspill                i25, 14                    
   123 : unspill                i26, 15                    
   124 : add                    i2, i2, 128                
