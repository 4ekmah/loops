all_loads_all_stores(i0, i1, i2, i3, i4)
     0 : sub                    i2, i2, 80                 
     1 : spill                  6, i24                     
     2 : spill                  7, i25                     
     3 : spill                  8, i26                     
     4 : spill                  4, i13                     
     5 : spill                  3, i14                     
     6 : mov                    i25, 0                     
     7 : spill                  2, i25                     
     8 : mov                    i25, 0                     
     9 : spill                  0, i25                     
    10 : mov                    i25, 0                     
    11 : spill                  1, i25                     
    12 : mov                    i24, 2                     
    13 : mov                    i14, 1                     
    14 : mov                    i13, 1                     
    15 : iverson_gt             i13, i11, i13              
    16 : sub                    i24, i24, i14              
    17 : sub                    i13, 0, i13                
    18 : and                    i13, i13, i24              
    19 : add                    i13, i14, i13              
    20 : mov                    i14, 4                     
    21 : mov                    i24, 3                     
    22 : iverson_gt             i24, i11, i24              
    23 : sub                    i14, i14, i13              
    24 : sub                    i24, 0, i24                
    25 : and                    i14, i24, i14              
    26 : add                    i13, i13, i14              
    27 : mov                    i14, 8                     
    28 : mov                    i24, 5                     
    29 : iverson_gt             i24, i11, i24              
    30 : sub                    i14, i14, i13              
    31 : sub                    i24, 0, i24                
    32 : and                    i14, i24, i14              
    33 : add                    i25, i13, i14              
    34 : spill                  5, i25                     
    35 : mov                    i14, 2                     
    36 : mov                    i24, 1                     
    37 : mov                    i13, 1                     
    38 : unspill                i25, 4                     
    39 : iverson_gt             i13, i25, i13              
    40 : sub                    i14, i14, i24              
    41 : sub                    i13, 0, i13                
    42 : and                    i13, i13, i14              
    43 : add                    i13, i24, i13              
    44 : mov                    i14, 4                     
    45 : mov                    i24, 3                     
    46 : unspill                i25, 4                     
    47 : iverson_gt             i24, i25, i24              
    48 : sub                    i14, i14, i13              
    49 : sub                    i24, 0, i24                
    50 : and                    i14, i24, i14              
    51 : add                    i13, i13, i14              
    52 : mov                    i14, 8                     
    53 : mov                    i24, 5                     
    54 : unspill                i25, 4                     
    55 : iverson_gt             i24, i25, i24              
    56 : sub                    i14, i14, i13              
    57 : sub                    i24, 0, i24                
    58 : and                    i14, i24, i14              
    59 : add                    i13, i13, i14              
    60 : annotation:whilecstart 0                          
    61 : unspill                i26, 3                     
    62 : unspill                i25, 2                     
    63 : jmp_ge                 i25, i26, __loops_label_2  
    64 : annotation:whilecend                              
    65 : def                    i14                        
    66 : annotation:ifcstart                               
    67 : mov                    i24, 0                     
    68 : jmp_ne                 i11, i24, __loops_label_4  
    69 : annotation:ifcend                                 
    70 : unspill                i25, 0                     
    71 : add                    i24, i10, i25              
    72 : load.u8                i14, i24                   
    73 : annotation:else        4, 5                       
    74 : annotation:ifcstart                               
    75 : mov                    i24, 1                     
    76 : jmp_ne                 i11, i24, __loops_label_7  
    77 : annotation:ifcend                                 
    78 : unspill                i25, 0                     
    79 : add                    i24, i10, i25              
    80 : load.i8                i14, i24                   
    81 : annotation:else        7, 8                       
    82 : annotation:ifcstart                               
    83 : mov                    i24, 2                     
    84 : jmp_ne                 i11, i24, __loops_label_10 
    85 : annotation:ifcend                                 
    86 : unspill                i25, 0                     
    87 : add                    i24, i10, i25              
    88 : load.u16               i14, i24                   
    89 : annotation:else        10, 11                     
    90 : annotation:ifcstart                               
    91 : mov                    i24, 3                     
    92 : jmp_ne                 i11, i24, __loops_label_13 
    93 : annotation:ifcend                                 
    94 : unspill                i25, 0                     
    95 : add                    i24, i10, i25              
    96 : load.i16               i14, i24                   
    97 : annotation:else        13, 14                     
    98 : annotation:ifcstart                               
    99 : mov                    i24, 4                     
   100 : jmp_ne                 i11, i24, __loops_label_16 
   101 : annotation:ifcend                                 
   102 : unspill                i25, 0                     
   103 : add                    i24, i10, i25              
   104 : load.u32               i14, i24                   
   105 : annotation:else        16, 17                     
   106 : annotation:ifcstart                               
   107 : mov                    i24, 5                     
   108 : jmp_ne                 i11, i24, __loops_label_19 
   109 : annotation:ifcend                                 
   110 : unspill                i25, 0                     
   111 : add                    i24, i10, i25              
   112 : load.i32               i14, i24                   
   113 : annotation:else        19, 20                     
   114 : annotation:ifcstart                               
   115 : mov                    i24, 6                     
   116 : jmp_ne                 i11, i24, __loops_label_22 
   117 : annotation:ifcend                                 
   118 : unspill                i25, 0                     
   119 : add                    i24, i10, i25              
   120 : load.u64               i14, i24                   
   121 : annotation:else        22, 23                     
   122 : unspill                i25, 0                     
   123 : add                    i24, i10, i25              
   124 : load.i64               i14, i24                   
   125 : annotation:endif       5                          
   126 : annotation:endif       8                          
   127 : annotation:endif       11                         
   128 : annotation:endif       14                         
   129 : annotation:endif       17                         
   130 : annotation:endif       20                         
   131 : annotation:endif       23                         
   132 : annotation:ifcstart                               
   133 : mov                    i24, 0                     
   134 : unspill                i25, 4                     
   135 : jmp_ne                 i25, i24, __loops_label_25 
   136 : annotation:ifcend                                 
   137 : unspill                i25, 1                     
   138 : add                    i24, i12, i25              
   139 : store.u8               i24, i14                   
   140 : annotation:else        25, 26                     
   141 : annotation:ifcstart                               
   142 : mov                    i24, 1                     
   143 : unspill                i25, 4                     
   144 : jmp_ne                 i25, i24, __loops_label_28 
   145 : annotation:ifcend                                 
   146 : unspill                i25, 1                     
   147 : add                    i24, i12, i25              
   148 : store.i8               i24, i14                   
   149 : annotation:else        28, 29                     
   150 : annotation:ifcstart                               
   151 : mov                    i24, 2                     
   152 : unspill                i25, 4                     
   153 : jmp_ne                 i25, i24, __loops_label_31 
   154 : annotation:ifcend                                 
   155 : unspill                i25, 1                     
   156 : add                    i24, i12, i25              
   157 : store.u16              i24, i14                   
   158 : annotation:else        31, 32                     
   159 : annotation:ifcstart                               
   160 : mov                    i24, 3                     
   161 : unspill                i25, 4                     
   162 : jmp_ne                 i25, i24, __loops_label_34 
   163 : annotation:ifcend                                 
   164 : unspill                i25, 1                     
   165 : add                    i24, i12, i25              
   166 : store.i16              i24, i14                   
   167 : annotation:else        34, 35                     
   168 : annotation:ifcstart                               
   169 : mov                    i24, 4                     
   170 : unspill                i25, 4                     
   171 : jmp_ne                 i25, i24, __loops_label_37 
   172 : annotation:ifcend                                 
   173 : unspill                i25, 1                     
   174 : add                    i24, i12, i25              
   175 : store.u32              i24, i14                   
   176 : annotation:else        37, 38                     
   177 : annotation:ifcstart                               
   178 : mov                    i24, 5                     
   179 : unspill                i25, 4                     
   180 : jmp_ne                 i25, i24, __loops_label_40 
   181 : annotation:ifcend                                 
   182 : unspill                i25, 1                     
   183 : add                    i24, i12, i25              
   184 : store.i32              i24, i14                   
   185 : annotation:else        40, 41                     
   186 : annotation:ifcstart                               
   187 : mov                    i24, 6                     
   188 : unspill                i25, 4                     
   189 : jmp_ne                 i25, i24, __loops_label_43 
   190 : annotation:ifcend                                 
   191 : unspill                i25, 1                     
   192 : add                    i24, i12, i25              
   193 : store.u64              i24, i14                   
   194 : annotation:else        43, 44                     
   195 : unspill                i25, 1                     
   196 : add                    i24, i12, i25              
   197 : store.i64              i24, i14                   
   198 : annotation:endif       26                         
   199 : annotation:endif       29                         
   200 : annotation:endif       32                         
   201 : annotation:endif       35                         
   202 : annotation:endif       38                         
   203 : annotation:endif       41                         
   204 : annotation:endif       44                         
   205 : unspill                i25, 0                     
   206 : unspill                i26, 5                     
   207 : add                    i25, i25, i26              
   208 : spill                  0, i25                     
   209 : unspill                i25, 1                     
   210 : add                    i25, i25, i13              
   211 : spill                  1, i25                     
   212 : unspill                i25, 2                     
   213 : add                    i25, i25, 1                
   214 : spill                  2, i25                     
   215 : annotation:endwhile    0, 2                       
   216 : unspill                i24, 6                     
   217 : unspill                i25, 7                     
   218 : unspill                i26, 8                     
   219 : add                    i2, i2, 80                 
