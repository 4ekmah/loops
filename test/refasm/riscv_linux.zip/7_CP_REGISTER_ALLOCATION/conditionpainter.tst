conditionpainter(i0)
     0 : sub                    i2, i2, 64                
     1 : spill                  5, i24                    
     2 : spill                  6, i25                    
     3 : spill                  1, i10                    
     4 : mov                    i25, -5                   
     5 : spill                  0, i25                    
     6 : annotation:whilecstart 0                         
     7 : mov                    i12, 5                    
     8 : unspill                i25, 0                    
     9 : jmp_gt                 i25, i12, __loops_label_2 
    10 : annotation:whilecend                             
    11 : unspill                i25, 0                    
    12 : add                    i12, i25, 5               
    13 : mov                    i13, 11                   
    14 : mul                    i12, i12, i13             
    15 : mov                    i13, 8                    
    16 : mul                    i25, i12, i13             
    17 : spill                  3, i25                    
    18 : mov                    i25, -5                   
    19 : spill                  2, i25                    
    20 : annotation:whilecstart 3                         
    21 : mov                    i24, 5                    
    22 : unspill                i25, 2                    
    23 : jmp_gt                 i25, i24, __loops_label_5 
    24 : annotation:whilecend                             
    25 : unspill                i25, 2                    
    26 : add                    i24, i25, 3               
    27 : unspill                i25, 0                    
    28 : iverson_gt             i24, i25, i24             
    29 : neg                    i24, i24                  
    30 : add                    i24, i24, 1               
    31 : mov                    i11, 4                    
    32 : unspill                i25, 0                    
    33 : iverson_gt             i11, i25, i11             
    34 : neg                    i11, i11                  
    35 : add                    i11, i11, 1               
    36 : and                    i11, i24, i11             
    37 : mov                    i24, -2                   
    38 : unspill                i25, 2                    
    39 : iverson_gt             i24, i25, i24             
    40 : neg                    i24, i24                  
    41 : add                    i24, i24, 1               
    42 : and                    i11, i11, i24             
    43 : mov                    i24, 0                    
    44 : unspill                i25, 2                    
    45 : iverson_gt             i24, i25, i24             
    46 : neg                    i24, i24                  
    47 : add                    i24, i24, 1               
    48 : and                    i11, i11, i24             
    49 : unspill                i25, 2                    
    50 : sub                    i24, i25, 1               
    51 : unspill                i25, 0                    
    52 : iverson_gt             i24, i25, i24             
    53 : neg                    i24, i24                  
    54 : add                    i24, i24, 1               
    55 : mov                    i10, 0                    
    56 : unspill                i25, 2                    
    57 : iverson_gt             i10, i25, i10             
    58 : neg                    i10, i10                  
    59 : add                    i10, i10, 1               
    60 : and                    i10, i24, i10             
    61 : mov                    i24, 0                    
    62 : unspill                i25, 0                    
    63 : iverson_gt             i24, i25, i24             
    64 : neg                    i24, i24                  
    65 : add                    i24, i24, 1               
    66 : and                    i10, i10, i24             
    67 : unspill                i25, 2                    
    68 : mul                    i24, i25, i25             
    69 : unspill                i25, 0                    
    70 : mul                    i13, i25, i25             
    71 : add                    i13, i24, i13             
    72 : mov                    i24, 9                    
    73 : iverson_gt             i13, i13, i24             
    74 : neg                    i13, i13                  
    75 : add                    i13, i13, 1               
    76 : and                    i10, i10, i13             
    77 : or                     i25, i11, i10             
    78 : spill                  4, i25                    
    79 : mov                    i11, 2                    
    80 : mov                    i13, 0                    
    81 : mov                    i24, 2                    
    82 : unspill                i25, 2                    
    83 : iverson_gt             i24, i25, i24             
    84 : neg                    i24, i24                  
    85 : add                    i24, i24, 1               
    86 : mov                    i12, 4                    
    87 : unspill                i25, 2                    
    88 : iverson_gt             i12, i25, i12             
    89 : neg                    i12, i12                  
    90 : add                    i12, i12, 1               
    91 : and                    i12, i24, i12             
    92 : mov                    i24, 1                    
    93 : unspill                i25, 0                    
    94 : iverson_gt             i24, i25, i24             
    95 : neg                    i24, i24                  
    96 : add                    i24, i24, 1               
    97 : mov                    i10, 3                    
    98 : unspill                i25, 0                    
    99 : iverson_gt             i10, i25, i10             
   100 : neg                    i10, i10                  
   101 : add                    i10, i10, 1               
   102 : and                    i10, i24, i10             
   103 : or                     i10, i12, i10             
   104 : unspill                i25, 2                    
   105 : mul                    i12, i25, i25             
   106 : unspill                i25, 0                    
   107 : mul                    i24, i25, i25             
   108 : add                    i12, i12, i24             
   109 : mov                    i24, 16                   
   110 : iverson_gt             i12, i12, i24             
   111 : neg                    i12, i12                  
   112 : add                    i12, i12, 1               
   113 : and                    i10, i10, i12             
   114 : mov                    i12, 0                    
   115 : sub                    i10, i10, i12             
   116 : iverson_ne             i10, i10, 0               
   117 : sub                    i11, i11, i13             
   118 : sub                    i10, 0, i10               
   119 : and                    i10, i10, i11             
   120 : add                    i10, i13, i10             
   121 : unspill                i25, 4                    
   122 : add                    i10, i25, i10             
   123 : annotation:ifcstart                              
   124 : mov                    i11, 2                    
   125 : unspill                i25, 0                    
   126 : mul                    i11, i25, i11             
   127 : unspill                i25, 2                    
   128 : jmp_gt                 i11, i25, __loops_label_8 
   129 : unspill                i25, 2                    
   130 : add                    i11, i25, 3               
   131 : neg                    i11, i11                  
   132 : unspill                i25, 2                    
   133 : add                    i12, i25, 3               
   134 : mul                    i11, i11, i12             
   135 : unspill                i25, 0                    
   136 : jmp_le                 i25, i11, __loops_label_9 
   137 : __loops_label_8:                                 
   138 : mov                    i11, 2                    
   139 : unspill                i25, 2                    
   140 : mul                    i11, i25, i11             
   141 : unspill                i25, 0                    
   142 : jmp_gt                 i25, i11, __loops_label_7 
   143 : unspill                i25, 2                    
   144 : add                    i11, i25, 3               
   145 : neg                    i11, i11                  
   146 : unspill                i25, 2                    
   147 : add                    i12, i25, 3               
   148 : mul                    i11, i11, i12             
   149 : unspill                i25, 0                    
   150 : jmp_gt                 i25, i11, __loops_label_7 
   151 : __loops_label_9:                                 
   152 : mov                    i11, 0                    
   153 : unspill                i25, 2                    
   154 : jmp_gt                 i25, i11, __loops_label_7 
   155 : annotation:ifcend                                
   156 : add                    i10, i10, 3               
   157 : annotation:endif       7                         
   158 : unspill                i25, 2                    
   159 : add                    i11, i25, 5               
   160 : shl                    i11, i11, 3               
   161 : unspill                i25, 3                    
   162 : add                    i11, i25, i11             
   163 : unspill                i25, 1                    
   164 : add                    i11, i25, i11             
   165 : store.i64              i11, i10                  
   166 : unspill                i25, 2                    
   167 : add                    i25, i25, 1               
   168 : spill                  2, i25                    
   169 : annotation:endwhile    3, 5                      
   170 : unspill                i25, 0                    
   171 : add                    i25, i25, 1               
   172 : spill                  0, i25                    
   173 : annotation:endwhile    0, 2                      
   174 : ret                                              
   175 : unspill                i24, 5                    
   176 : unspill                i25, 6                    
   177 : add                    i2, i2, 64                
