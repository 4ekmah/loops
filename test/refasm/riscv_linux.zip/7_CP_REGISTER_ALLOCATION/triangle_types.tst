triangle_types(i0, i1, i2)
     0 : sub                 i2, i2, 32                 
     1 : spill               1, i24                     
     2 : spill               2, i25                     
     3 : spill               0, i11                     
     4 : annotation:ifcstart                            
     5 : mov                 i13, 0                     
     6 : jmp_le              i10, i13, __loops_label_0  
     7 : mov                 i13, 0                     
     8 : unspill             i25, 0                     
     9 : jmp_le              i25, i13, __loops_label_0  
    10 : mov                 i13, 0                     
    11 : jmp_gt              i12, i13, __loops_label_1  
    12 : __loops_label_0:                               
    13 : annotation:ifcend                              
    14 : mov                 i10, 0                     
    15 : ret                                            
    16 : annotation:else     1, 2                       
    17 : annotation:ifcstart                            
    18 : unspill             i25, 0                     
    19 : add                 i13, i25, i12              
    20 : jmp_gt              i10, i13, __loops_label_3  
    21 : add                 i13, i10, i12              
    22 : unspill             i25, 0                     
    23 : jmp_gt              i25, i13, __loops_label_3  
    24 : unspill             i25, 0                     
    25 : add                 i13, i10, i25              
    26 : jmp_le              i12, i13, __loops_label_4  
    27 : __loops_label_3:                               
    28 : annotation:ifcend                              
    29 : mov                 i10, 0                     
    30 : ret                                            
    31 : annotation:else     4, 5                       
    32 : annotation:ifcstart                            
    33 : unspill             i25, 0                     
    34 : jmp_ne              i10, i25, __loops_label_7  
    35 : jmp_ne              i10, i12, __loops_label_7  
    36 : annotation:ifcend                              
    37 : mov                 i10, 2                     
    38 : ret                                            
    39 : annotation:else     7, 8                       
    40 : annotation:ifcstart                            
    41 : unspill             i25, 0                     
    42 : jmp_eq              i10, i25, __loops_label_9  
    43 : jmp_eq              i10, i12, __loops_label_9  
    44 : unspill             i25, 0                     
    45 : jmp_ne              i25, i12, __loops_label_10 
    46 : __loops_label_9:                               
    47 : annotation:ifcend                              
    48 : mov                 i10, 3                     
    49 : ret                                            
    50 : annotation:else     10, 11                     
    51 : annotation:ifcstart                            
    52 : mul                 i13, i10, i10              
    53 : unspill             i25, 0                     
    54 : mul                 i24, i25, i25              
    55 : mul                 i11, i12, i12              
    56 : add                 i11, i24, i11              
    57 : jmp_eq              i13, i11, __loops_label_12 
    58 : unspill             i25, 0                     
    59 : mul                 i11, i25, i25              
    60 : mul                 i13, i10, i10              
    61 : mul                 i24, i12, i12              
    62 : add                 i13, i13, i24              
    63 : jmp_eq              i11, i13, __loops_label_12 
    64 : mul                 i11, i12, i12              
    65 : mul                 i13, i10, i10              
    66 : unspill             i25, 0                     
    67 : mul                 i24, i25, i25              
    68 : add                 i13, i13, i24              
    69 : jmp_ne              i11, i13, __loops_label_13 
    70 : __loops_label_12:                              
    71 : annotation:ifcend                              
    72 : mov                 i10, 1                     
    73 : ret                                            
    74 : annotation:else     13, 14                     
    75 : annotation:ifcstart                            
    76 : mul                 i11, i10, i10              
    77 : unspill             i25, 0                     
    78 : mul                 i13, i25, i25              
    79 : mul                 i24, i12, i12              
    80 : add                 i13, i13, i24              
    81 : jmp_gt              i11, i13, __loops_label_15 
    82 : unspill             i25, 0                     
    83 : mul                 i11, i25, i25              
    84 : mul                 i13, i10, i10              
    85 : mul                 i24, i12, i12              
    86 : add                 i13, i13, i24              
    87 : jmp_gt              i11, i13, __loops_label_15 
    88 : mul                 i11, i12, i12              
    89 : mul                 i10, i10, i10              
    90 : unspill             i25, 0                     
    91 : mul                 i12, i25, i25              
    92 : add                 i10, i10, i12              
    93 : jmp_le              i11, i10, __loops_label_16 
    94 : __loops_label_15:                              
    95 : annotation:ifcend                              
    96 : mov                 i10, 5                     
    97 : ret                                            
    98 : annotation:else     16, 17                     
    99 : mov                 i10, 4                     
   100 : ret                                            
   101 : annotation:endif    2                          
   102 : annotation:endif    5                          
   103 : annotation:endif    8                          
   104 : annotation:endif    11                         
   105 : annotation:endif    14                         
   106 : annotation:endif    17                         
   107 : unspill             i24, 1                     
   108 : unspill             i25, 2                     
   109 : add                 i2, i2, 32                 
