area_sum(i0, i1)
     0 : sub                    i2, i2, 192               
     1 : spill                  20, i24                   
     2 : spill                  21, i25                   
     3 : spill                  22, i26                   
     4 : spill                  22, i8                    
     5 : spill                  23, i1                    
     6 : spill                  18, i10                   
     7 : spill                  17, i11                   
     8 : mov                    i25, 0                    
     9 : spill                  16, i25                   
    10 : annotation:whilecstart 0                         
    11 : mov                    i13, 0                    
    12 : unspill                i25, 17                   
    13 : jmp_le                 i25, i13, __loops_label_2 
    14 : annotation:whilecend                             
    15 : unspill                i25, 18                   
    16 : load.i8                i13, i25                  
    17 : mov                    i24, 43                   
    18 : shl                    i24, i24, 32              
    19 : rv_lui                 i12, 776381               
    20 : add                    i12, i12, -560            
    21 : add                    i12, i24, i12             
    22 : mov                    i24, 43                   
    23 : shl                    i24, i24, 32              
    24 : rv_lui                 i11, 776381               
    25 : add                    i11, i11, -724            
    26 : add                    i11, i24, i11             
    27 : mov                    i24, 43                   
    28 : shl                    i24, i24, 32              
    29 : rv_lui                 i10, 776381               
    30 : add                    i10, i10, -358            
    31 : add                    i10, i24, i10             
    32 : mov                    i24, 1                    
    33 : sub                    i24, i13, i24             
    34 : iverson_eq             i24, i24, 0               
    35 : sub                    i11, i11, i10             
    36 : sub                    i24, 0, i24               
    37 : and                    i11, i24, i11             
    38 : add                    i10, i10, i11             
    39 : mov                    i11, 0                    
    40 : sub                    i11, i13, i11             
    41 : iverson_eq             i11, i11, 0               
    42 : sub                    i12, i12, i10             
    43 : sub                    i11, 0, i11               
    44 : and                    i11, i11, i12             
    45 : add                    i25, i10, i11             
    46 : spill                  19, i25                   
    47 : mov                    i11, 43                   
    48 : shl                    i11, i11, 32              
    49 : rv_lui                 i12, 776381               
    50 : add                    i12, i12, -1928           
    51 : add                    i11, i11, i12             
    52 : mov                    i12, 43                   
    53 : shl                    i12, i12, 32              
    54 : rv_lui                 i24, 776381               
    55 : add                    i24, i24, -1894           
    56 : add                    i12, i12, i24             
    57 : mov                    i24, 43                   
    58 : shl                    i24, i24, 32              
    59 : rv_lui                 i10, 776381               
    60 : add                    i10, i10, -1870           
    61 : add                    i10, i24, i10             
    62 : mov                    i24, 1                    
    63 : sub                    i24, i13, i24             
    64 : iverson_eq             i24, i24, 0               
    65 : sub                    i12, i12, i10             
    66 : sub                    i24, 0, i24               
    67 : and                    i12, i24, i12             
    68 : add                    i10, i10, i12             
    69 : mov                    i12, 0                    
    70 : sub                    i12, i13, i12             
    71 : iverson_eq             i12, i12, 0               
    72 : sub                    i11, i11, i10             
    73 : sub                    i12, 0, i12               
    74 : and                    i11, i12, i11             
    75 : add                    i10, i10, i11             
    76 : unspill                i26, 18                   
    77 : unspill                i25, 19                   
    78 : call_noret             [i25](i26)                
    79 : unspill                i25, 18                   
    80 : call                   [i10](i10, i25)           
    81 : mov                    i11, 43                   
    82 : shl                    i11, i11, 32              
    83 : rv_lui                 i12, 776381               
    84 : add                    i12, i12, -1946           
    85 : add                    i11, i11, i12             
    86 : unspill                i25, 16                   
    87 : call                   [i11](i10, i25, i10)      
    88 : mov                    i25, i10                  
    89 : spill                  16, i25                   
    90 : unspill                i25, 18                   
    91 : add                    i25, i25, 56              
    92 : spill                  18, i25                   
    93 : unspill                i25, 17                   
    94 : sub                    i25, i25, 1               
    95 : spill                  17, i25                   
    96 : annotation:endwhile    0, 2                      
    97 : unspill                i25, 16                   
    98 : mov                    i10, i25                  
    99 : ret                                              
   100 : unspill                i8, 22                    
   101 : unspill                i1, 23                    
   102 : unspill                i24, 20                   
   103 : unspill                i25, 21                   
   104 : unspill                i26, 22                   
   105 : add                    i2, i2, 192               
