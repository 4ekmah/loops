fixed_power_0(i0)
     0 : mov i10, 1   
     1 : mov i10, i10 
     2 : ret          
