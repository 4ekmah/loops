has_in_join_cascade(i0, i1, i2)
     0 : sub               i2, i2, 128                
     1 : spill             13, i24                    
     2 : spill             14, i25                    
     3 : spill             15, i26                    
     4 : spill             6, i10                     
     5 : spill             5, i11                     
     6 : spill             4, i12                     
     7 : mov               i25, 0                     
     8 : spill             0, i25                     
     9 : unspill           i25, 6                     
    10 : load.i64          i26, i25, 16               
    11 : spill             3, i26                     
    12 : unspill           i25, 6                     
    13 : load.i64          i26, i25, 0                
    14 : spill             2, i26                     
    15 : unspill           i25, 6                     
    16 : load.i64          i26, i25, 8                
    17 : spill             1, i26                     
    18 : __loops_label_0:                             
    19 : mov               i13, 0                     
    20 : unspill           i25, 3                     
    21 : jmp_le            i25, i13, __loops_label_2  
    22 : unspill           i25, 2                     
    23 : load.i32          i26, i25                   
    24 : spill             11, i26                    
    25 : unspill           i25, 2                     
    26 : add               i25, i25, 4                
    27 : spill             2, i25                     
    28 : unspill           i25, 1                     
    29 : load.i32          i26, i25                   
    30 : spill             10, i26                    
    31 : unspill           i25, 1                     
    32 : add               i25, i25, 4                
    33 : spill             1, i25                     
    34 : unspill           i25, 3                     
    35 : sub               i25, i25, 1                
    36 : spill             3, i25                     
    37 : unspill           i25, 6                     
    38 : load.i64          i26, i25, 40               
    39 : spill             9, i26                     
    40 : unspill           i25, 6                     
    41 : load.i64          i26, i25, 24               
    42 : spill             8, i26                     
    43 : unspill           i25, 6                     
    44 : load.i64          i26, i25, 32               
    45 : spill             7, i26                     
    46 : __loops_label_3:                             
    47 : mov               i10, 0                     
    48 : unspill           i25, 9                     
    49 : jmp_le            i25, i10, __loops_label_5  
    50 : unspill           i25, 8                     
    51 : load.i32          i10, i25                   
    52 : unspill           i25, 8                     
    53 : add               i25, i25, 4                
    54 : spill             8, i25                     
    55 : unspill           i25, 7                     
    56 : load.i32          i11, i25                   
    57 : unspill           i25, 7                     
    58 : add               i25, i25, 4                
    59 : spill             7, i25                     
    60 : unspill           i25, 9                     
    61 : sub               i25, i25, 1                
    62 : spill             9, i25                     
    63 : unspill           i25, 11                    
    64 : jmp_le            i11, i25, __loops_label_7  
    65 : jmp               3                          
    66 : __loops_label_7:                             
    67 : unspill           i25, 11                    
    68 : jmp_ne            i11, i25, __loops_label_10 
    69 : unspill           i25, 6                     
    70 : load.i64          i11, i25, 64               
    71 : unspill           i25, 6                     
    72 : load.i64          i12, i25, 48               
    73 : unspill           i25, 6                     
    74 : load.i64          i26, i25, 56               
    75 : spill             12, i26                    
    76 : __loops_label_11:                            
    77 : mov               i13, 0                     
    78 : jmp_le            i11, i13, __loops_label_13 
    79 : load.i32          i13, i12                   
    80 : add               i12, i12, 4                
    81 : unspill           i25, 12                    
    82 : load.i32          i24, i25                   
    83 : unspill           i25, 12                    
    84 : add               i25, i25, 4                
    85 : spill             12, i25                    
    86 : sub               i11, i11, 1                
    87 : unspill           i25, 10                    
    88 : jmp_le            i13, i25, __loops_label_15 
    89 : jmp               11                         
    90 : __loops_label_15:                            
    91 : unspill           i25, 10                    
    92 : jmp_ne            i13, i25, __loops_label_18 
    93 : unspill           i25, 5                     
    94 : jmp_ne            i10, i25, __loops_label_18 
    95 : unspill           i25, 4                     
    96 : jmp_ne            i24, i25, __loops_label_18 
    97 : mov               i25, 1                     
    98 : spill             0, i25                     
    99 : jmp               2                          
   100 : __loops_label_16:                            
   101 : __loops_label_18:                            
   102 : jmp               11                         
   103 : __loops_label_13:                            
   104 : __loops_label_8:                             
   105 : __loops_label_10:                            
   106 : jmp               3                          
   107 : __loops_label_5:                             
   108 : jmp               0                          
   109 : __loops_label_2:                             
   110 : unspill           i25, 0                     
   111 : mov               i10, i25                   
   112 : unspill           i24, 13                    
   113 : unspill           i25, 14                    
   114 : unspill           i26, 15                    
   115 : add               i2, i2, 128                
   116 : ret                                          
