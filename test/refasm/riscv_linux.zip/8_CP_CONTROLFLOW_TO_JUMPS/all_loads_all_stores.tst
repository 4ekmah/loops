all_loads_all_stores(i0, i1, i2, i3, i4)
     0 : sub               i2, i2, 80                 
     1 : spill             6, i24                     
     2 : spill             7, i25                     
     3 : spill             8, i26                     
     4 : spill             4, i13                     
     5 : spill             3, i14                     
     6 : mov               i25, 0                     
     7 : spill             2, i25                     
     8 : mov               i25, 0                     
     9 : spill             0, i25                     
    10 : mov               i25, 0                     
    11 : spill             1, i25                     
    12 : mov               i24, 2                     
    13 : mov               i14, 1                     
    14 : mov               i13, 1                     
    15 : iverson_gt        i13, i11, i13              
    16 : sub               i24, i24, i14              
    17 : sub               i13, 0, i13                
    18 : and               i13, i13, i24              
    19 : add               i13, i14, i13              
    20 : mov               i14, 4                     
    21 : mov               i24, 3                     
    22 : iverson_gt        i24, i11, i24              
    23 : sub               i14, i14, i13              
    24 : sub               i24, 0, i24                
    25 : and               i14, i24, i14              
    26 : add               i13, i13, i14              
    27 : mov               i14, 8                     
    28 : mov               i24, 5                     
    29 : iverson_gt        i24, i11, i24              
    30 : sub               i14, i14, i13              
    31 : sub               i24, 0, i24                
    32 : and               i14, i24, i14              
    33 : add               i25, i13, i14              
    34 : spill             5, i25                     
    35 : mov               i14, 2                     
    36 : mov               i24, 1                     
    37 : mov               i13, 1                     
    38 : unspill           i25, 4                     
    39 : iverson_gt        i13, i25, i13              
    40 : sub               i14, i14, i24              
    41 : sub               i13, 0, i13                
    42 : and               i13, i13, i14              
    43 : add               i13, i24, i13              
    44 : mov               i14, 4                     
    45 : mov               i24, 3                     
    46 : unspill           i25, 4                     
    47 : iverson_gt        i24, i25, i24              
    48 : sub               i14, i14, i13              
    49 : sub               i24, 0, i24                
    50 : and               i14, i24, i14              
    51 : add               i13, i13, i14              
    52 : mov               i14, 8                     
    53 : mov               i24, 5                     
    54 : unspill           i25, 4                     
    55 : iverson_gt        i24, i25, i24              
    56 : sub               i14, i14, i13              
    57 : sub               i24, 0, i24                
    58 : and               i14, i24, i14              
    59 : add               i13, i13, i14              
    60 : __loops_label_0:                             
    61 : unspill           i26, 3                     
    62 : unspill           i25, 2                     
    63 : jmp_ge            i25, i26, __loops_label_2  
    64 : def               i14                        
    65 : mov               i24, 0                     
    66 : jmp_ne            i11, i24, __loops_label_4  
    67 : unspill           i25, 0                     
    68 : add               i24, i10, i25              
    69 : load.u8           i14, i24                   
    70 : jmp               5                          
    71 : __loops_label_4:                             
    72 : mov               i24, 1                     
    73 : jmp_ne            i11, i24, __loops_label_7  
    74 : unspill           i25, 0                     
    75 : add               i24, i10, i25              
    76 : load.i8           i14, i24                   
    77 : jmp               8                          
    78 : __loops_label_7:                             
    79 : mov               i24, 2                     
    80 : jmp_ne            i11, i24, __loops_label_10 
    81 : unspill           i25, 0                     
    82 : add               i24, i10, i25              
    83 : load.u16          i14, i24                   
    84 : jmp               11                         
    85 : __loops_label_10:                            
    86 : mov               i24, 3                     
    87 : jmp_ne            i11, i24, __loops_label_13 
    88 : unspill           i25, 0                     
    89 : add               i24, i10, i25              
    90 : load.i16          i14, i24                   
    91 : jmp               14                         
    92 : __loops_label_13:                            
    93 : mov               i24, 4                     
    94 : jmp_ne            i11, i24, __loops_label_16 
    95 : unspill           i25, 0                     
    96 : add               i24, i10, i25              
    97 : load.u32          i14, i24                   
    98 : jmp               17                         
    99 : __loops_label_16:                            
   100 : mov               i24, 5                     
   101 : jmp_ne            i11, i24, __loops_label_19 
   102 : unspill           i25, 0                     
   103 : add               i24, i10, i25              
   104 : load.i32          i14, i24                   
   105 : jmp               20                         
   106 : __loops_label_19:                            
   107 : mov               i24, 6                     
   108 : jmp_ne            i11, i24, __loops_label_22 
   109 : unspill           i25, 0                     
   110 : add               i24, i10, i25              
   111 : load.u64          i14, i24                   
   112 : jmp               23                         
   113 : __loops_label_22:                            
   114 : unspill           i25, 0                     
   115 : add               i24, i10, i25              
   116 : load.i64          i14, i24                   
   117 : __loops_label_5:                             
   118 : __loops_label_8:                             
   119 : __loops_label_11:                            
   120 : __loops_label_14:                            
   121 : __loops_label_17:                            
   122 : __loops_label_20:                            
   123 : __loops_label_23:                            
   124 : mov               i24, 0                     
   125 : unspill           i25, 4                     
   126 : jmp_ne            i25, i24, __loops_label_25 
   127 : unspill           i25, 1                     
   128 : add               i24, i12, i25              
   129 : store.u8          i24, i14                   
   130 : jmp               26                         
   131 : __loops_label_25:                            
   132 : mov               i24, 1                     
   133 : unspill           i25, 4                     
   134 : jmp_ne            i25, i24, __loops_label_28 
   135 : unspill           i25, 1                     
   136 : add               i24, i12, i25              
   137 : store.i8          i24, i14                   
   138 : jmp               29                         
   139 : __loops_label_28:                            
   140 : mov               i24, 2                     
   141 : unspill           i25, 4                     
   142 : jmp_ne            i25, i24, __loops_label_31 
   143 : unspill           i25, 1                     
   144 : add               i24, i12, i25              
   145 : store.u16         i24, i14                   
   146 : jmp               32                         
   147 : __loops_label_31:                            
   148 : mov               i24, 3                     
   149 : unspill           i25, 4                     
   150 : jmp_ne            i25, i24, __loops_label_34 
   151 : unspill           i25, 1                     
   152 : add               i24, i12, i25              
   153 : store.i16         i24, i14                   
   154 : jmp               35                         
   155 : __loops_label_34:                            
   156 : mov               i24, 4                     
   157 : unspill           i25, 4                     
   158 : jmp_ne            i25, i24, __loops_label_37 
   159 : unspill           i25, 1                     
   160 : add               i24, i12, i25              
   161 : store.u32         i24, i14                   
   162 : jmp               38                         
   163 : __loops_label_37:                            
   164 : mov               i24, 5                     
   165 : unspill           i25, 4                     
   166 : jmp_ne            i25, i24, __loops_label_40 
   167 : unspill           i25, 1                     
   168 : add               i24, i12, i25              
   169 : store.i32         i24, i14                   
   170 : jmp               41                         
   171 : __loops_label_40:                            
   172 : mov               i24, 6                     
   173 : unspill           i25, 4                     
   174 : jmp_ne            i25, i24, __loops_label_43 
   175 : unspill           i25, 1                     
   176 : add               i24, i12, i25              
   177 : store.u64         i24, i14                   
   178 : jmp               44                         
   179 : __loops_label_43:                            
   180 : unspill           i25, 1                     
   181 : add               i24, i12, i25              
   182 : store.i64         i24, i14                   
   183 : __loops_label_26:                            
   184 : __loops_label_29:                            
   185 : __loops_label_32:                            
   186 : __loops_label_35:                            
   187 : __loops_label_38:                            
   188 : __loops_label_41:                            
   189 : __loops_label_44:                            
   190 : unspill           i25, 0                     
   191 : unspill           i26, 5                     
   192 : add               i25, i25, i26              
   193 : spill             0, i25                     
   194 : unspill           i25, 1                     
   195 : add               i25, i25, i13              
   196 : spill             1, i25                     
   197 : unspill           i25, 2                     
   198 : add               i25, i25, 1                
   199 : spill             2, i25                     
   200 : jmp               0                          
   201 : __loops_label_2:                             
   202 : unspill           i24, 6                     
   203 : unspill           i25, 7                     
   204 : unspill           i26, 8                     
   205 : add               i2, i2, 80                 
   206 : ret                                          
