sort_double(i0, i1)
     0 : sub              i2, i2, 208               
     1 : spill            21, i24                   
     2 : spill            22, i25                   
     3 : spill            23, i26                   
     4 : spill            24, i8                    
     5 : spill            25, i1                    
     6 : spill            19, i10                   
     7 : shl              i25, i11, 3               
     8 : spill            18, i25                   
     9 : unspill          i25, 18                   
    10 : sub              i26, i25, 8               
    11 : spill            17, i26                   
    12 : mov              i25, 0                    
    13 : spill            16, i25                   
    14 : __loops_label_0:                           
    15 : unspill          i26, 17                   
    16 : unspill          i25, 16                   
    17 : jmp_ge           i25, i26, __loops_label_2 
    18 : unspill          i25, 16                   
    19 : mov              i26, i25                  
    20 : spill            20, i26                   
    21 : unspill          i25, 20                   
    22 : add              i13, i25, 8               
    23 : __loops_label_3:                           
    24 : unspill          i25, 18                   
    25 : jmp_ge           i13, i25, __loops_label_5 
    26 : unspill          i25, 19                   
    27 : add              i12, i25, i13             
    28 : load.fp64        i12, i12                  
    29 : unspill          i25, 19                   
    30 : unspill          i26, 20                   
    31 : add              i11, i25, i26             
    32 : load.fp64        i11, i11                  
    33 : mov              i10, 43                   
    34 : shl              i10, i10, 32              
    35 : rv_lui           i24, 776381               
    36 : add              i24, i24, -1960           
    37 : add              i10, i10, i24             
    38 : call             [i10](i10, i12, i11)      
    39 : mov              i11, 0                    
    40 : jmp_eq           i10, i11, __loops_label_7 
    41 : mov              i25, i13                  
    42 : spill            20, i25                   
    43 : __loops_label_7:                           
    44 : add              i13, i13, 8               
    45 : jmp              3                         
    46 : __loops_label_5:                           
    47 : unspill          i26, 16                   
    48 : unspill          i25, 20                   
    49 : jmp_eq           i25, i26, __loops_label_9 
    50 : unspill          i25, 19                   
    51 : unspill          i26, 16                   
    52 : add              i10, i25, i26             
    53 : load.fp64        i10, i10                  
    54 : unspill          i25, 19                   
    55 : unspill          i26, 20                   
    56 : add              i11, i25, i26             
    57 : load.fp64        i11, i11                  
    58 : unspill          i25, 19                   
    59 : unspill          i26, 20                   
    60 : add              i12, i25, i26             
    61 : store.fp64       i12, i10                  
    62 : unspill          i25, 19                   
    63 : unspill          i26, 16                   
    64 : add              i10, i25, i26             
    65 : store.fp64       i10, i11                  
    66 : __loops_label_9:                           
    67 : unspill          i25, 16                   
    68 : add              i25, i25, 8               
    69 : spill            16, i25                   
    70 : jmp              0                         
    71 : __loops_label_2:                           
    72 : unspill          i8, 24                    
    73 : unspill          i1, 25                    
    74 : unspill          i24, 21                   
    75 : unspill          i25, 22                   
    76 : unspill          i26, 23                   
    77 : add              i2, i2, 208               
    78 : ret                                        
