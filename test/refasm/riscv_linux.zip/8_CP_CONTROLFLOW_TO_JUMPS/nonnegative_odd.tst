nonnegative_odd(i0, i1)
     0 : sub              i2, i2, 32                
     1 : spill            1, i24                    
     2 : spill            2, i25                    
     3 : mov              i12, 0                    
     4 : mov              i25, -4                   
     5 : spill            0, i25                    
     6 : mov              i24, 4                    
     7 : mul              i11, i11, i24             
     8 : __loops_label_0:                           
     9 : jmp_ge           i12, i11, __loops_label_2 
    10 : add              i24, i10, i12             
    11 : load.i32         i24, i24                  
    12 : mov              i13, 0                    
    13 : jmp_ge           i24, i13, __loops_label_4 
    14 : add              i12, i12, 4               
    15 : jmp              0                         
    16 : __loops_label_4:                           
    17 : mov              i13, 2                    
    18 : mod              i13, i24, i13             
    19 : mov              i24, 0                    
    20 : jmp_eq           i13, i24, __loops_label_6 
    21 : mov              i25, i12                  
    22 : spill            0, i25                    
    23 : jmp              2                         
    24 : __loops_label_6:                           
    25 : add              i12, i12, 4               
    26 : jmp              0                         
    27 : __loops_label_2:                           
    28 : mov              i10, 4                    
    29 : unspill          i25, 0                    
    30 : div              i10, i25, i10             
    31 : mov              i10, i10                  
    32 : unspill          i24, 1                    
    33 : unspill          i25, 2                    
    34 : add              i2, i2, 32                
    35 : ret                                        
