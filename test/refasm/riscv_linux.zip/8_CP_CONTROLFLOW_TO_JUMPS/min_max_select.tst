min_max_select(i0, i1, i2, i3)
     0 : sub              i2, i2, 80                
     1 : spill            7, i24                    
     2 : spill            8, i25                    
     3 : spill            9, i26                    
     4 : spill            1, i12                    
     5 : spill            0, i13                    
     6 : mov              i24, 0                    
     7 : mov              i25, 0                    
     8 : spill            3, i25                    
     9 : mov              i25, 0                    
    10 : spill            2, i25                    
    11 : load.i32         i25, i10                  
    12 : spill            6, i25                    
    13 : unspill          i25, 6                    
    14 : mov              i26, i25                  
    15 : spill            5, i26                    
    16 : shl              i25, i11, 2               
    17 : spill            4, i25                    
    18 : __loops_label_0:                           
    19 : unspill          i25, 4                    
    20 : jmp_ge           i24, i25, __loops_label_2 
    21 : add              i11, i10, i24             
    22 : load.i32         i11, i11                  
    23 : unspill          i25, 6                    
    24 : iverson_gt       i13, i11, i25             
    25 : unspill          i25, 3                    
    26 : sub              i12, i24, i25             
    27 : sub              i13, 0, i13               
    28 : and              i12, i13, i12             
    29 : unspill          i25, 3                    
    30 : add              i25, i25, i12             
    31 : spill            3, i25                    
    32 : unspill          i25, 6                    
    33 : iverson_gt       i12, i11, i25             
    34 : unspill          i25, 6                    
    35 : sub              i13, i11, i25             
    36 : sub              i12, 0, i12               
    37 : and              i12, i12, i13             
    38 : unspill          i25, 6                    
    39 : add              i25, i25, i12             
    40 : spill            6, i25                    
    41 : unspill          i25, 5                    
    42 : iverson_gt       i12, i11, i25             
    43 : unspill          i25, 2                    
    44 : sub              i13, i24, i25             
    45 : sub              i12, 0, i12               
    46 : and              i12, i12, i13             
    47 : unspill          i25, 2                    
    48 : add              i25, i25, i12             
    49 : spill            2, i25                    
    50 : unspill          i25, 5                    
    51 : iverson_gt       i12, i11, i25             
    52 : unspill          i25, 5                    
    53 : sub              i13, i25, i11             
    54 : sub              i12, 0, i12               
    55 : and              i12, i12, i13             
    56 : add              i25, i11, i12             
    57 : spill            5, i25                    
    58 : add              i24, i24, 4               
    59 : jmp              0                         
    60 : __loops_label_2:                           
    61 : unspill          i25, 3                    
    62 : sar              i10, i25, 2               
    63 : unspill          i25, 2                    
    64 : sar              i11, i25, 2               
    65 : unspill          i25, 1                    
    66 : store.i32        i25, i10                  
    67 : unspill          i25, 0                    
    68 : store.i32        i25, i11                  
    69 : mov              i10, 0                    
    70 : unspill          i24, 7                    
    71 : unspill          i25, 8                    
    72 : unspill          i26, 9                    
    73 : add              i2, i2, 80                
    74 : ret                                        
