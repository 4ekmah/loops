conditionpainter(i0)
     0 : sub              i2, i2, 64                
     1 : spill            5, i24                    
     2 : spill            6, i25                    
     3 : spill            1, i10                    
     4 : mov              i25, -5                   
     5 : spill            0, i25                    
     6 : __loops_label_0:                           
     7 : mov              i12, 5                    
     8 : unspill          i25, 0                    
     9 : jmp_gt           i25, i12, __loops_label_2 
    10 : unspill          i25, 0                    
    11 : add              i12, i25, 5               
    12 : mov              i13, 11                   
    13 : mul              i12, i12, i13             
    14 : mov              i13, 8                    
    15 : mul              i25, i12, i13             
    16 : spill            3, i25                    
    17 : mov              i25, -5                   
    18 : spill            2, i25                    
    19 : __loops_label_3:                           
    20 : mov              i24, 5                    
    21 : unspill          i25, 2                    
    22 : jmp_gt           i25, i24, __loops_label_5 
    23 : unspill          i25, 2                    
    24 : add              i24, i25, 3               
    25 : unspill          i25, 0                    
    26 : iverson_gt       i24, i25, i24             
    27 : neg              i24, i24                  
    28 : add              i24, i24, 1               
    29 : mov              i11, 4                    
    30 : unspill          i25, 0                    
    31 : iverson_gt       i11, i25, i11             
    32 : neg              i11, i11                  
    33 : add              i11, i11, 1               
    34 : and              i11, i24, i11             
    35 : mov              i24, -2                   
    36 : unspill          i25, 2                    
    37 : iverson_gt       i24, i25, i24             
    38 : neg              i24, i24                  
    39 : add              i24, i24, 1               
    40 : and              i11, i11, i24             
    41 : mov              i24, 0                    
    42 : unspill          i25, 2                    
    43 : iverson_gt       i24, i25, i24             
    44 : neg              i24, i24                  
    45 : add              i24, i24, 1               
    46 : and              i11, i11, i24             
    47 : unspill          i25, 2                    
    48 : sub              i24, i25, 1               
    49 : unspill          i25, 0                    
    50 : iverson_gt       i24, i25, i24             
    51 : neg              i24, i24                  
    52 : add              i24, i24, 1               
    53 : mov              i10, 0                    
    54 : unspill          i25, 2                    
    55 : iverson_gt       i10, i25, i10             
    56 : neg              i10, i10                  
    57 : add              i10, i10, 1               
    58 : and              i10, i24, i10             
    59 : mov              i24, 0                    
    60 : unspill          i25, 0                    
    61 : iverson_gt       i24, i25, i24             
    62 : neg              i24, i24                  
    63 : add              i24, i24, 1               
    64 : and              i10, i10, i24             
    65 : unspill          i25, 2                    
    66 : mul              i24, i25, i25             
    67 : unspill          i25, 0                    
    68 : mul              i13, i25, i25             
    69 : add              i13, i24, i13             
    70 : mov              i24, 9                    
    71 : iverson_gt       i13, i13, i24             
    72 : neg              i13, i13                  
    73 : add              i13, i13, 1               
    74 : and              i10, i10, i13             
    75 : or               i25, i11, i10             
    76 : spill            4, i25                    
    77 : mov              i11, 2                    
    78 : mov              i13, 0                    
    79 : mov              i24, 2                    
    80 : unspill          i25, 2                    
    81 : iverson_gt       i24, i25, i24             
    82 : neg              i24, i24                  
    83 : add              i24, i24, 1               
    84 : mov              i12, 4                    
    85 : unspill          i25, 2                    
    86 : iverson_gt       i12, i25, i12             
    87 : neg              i12, i12                  
    88 : add              i12, i12, 1               
    89 : and              i12, i24, i12             
    90 : mov              i24, 1                    
    91 : unspill          i25, 0                    
    92 : iverson_gt       i24, i25, i24             
    93 : neg              i24, i24                  
    94 : add              i24, i24, 1               
    95 : mov              i10, 3                    
    96 : unspill          i25, 0                    
    97 : iverson_gt       i10, i25, i10             
    98 : neg              i10, i10                  
    99 : add              i10, i10, 1               
   100 : and              i10, i24, i10             
   101 : or               i10, i12, i10             
   102 : unspill          i25, 2                    
   103 : mul              i12, i25, i25             
   104 : unspill          i25, 0                    
   105 : mul              i24, i25, i25             
   106 : add              i12, i12, i24             
   107 : mov              i24, 16                   
   108 : iverson_gt       i12, i12, i24             
   109 : neg              i12, i12                  
   110 : add              i12, i12, 1               
   111 : and              i10, i10, i12             
   112 : mov              i12, 0                    
   113 : sub              i10, i10, i12             
   114 : iverson_ne       i10, i10, 0               
   115 : sub              i11, i11, i13             
   116 : sub              i10, 0, i10               
   117 : and              i10, i10, i11             
   118 : add              i10, i13, i10             
   119 : unspill          i25, 4                    
   120 : add              i10, i25, i10             
   121 : mov              i11, 2                    
   122 : unspill          i25, 0                    
   123 : mul              i11, i25, i11             
   124 : unspill          i25, 2                    
   125 : jmp_gt           i11, i25, __loops_label_8 
   126 : unspill          i25, 2                    
   127 : add              i11, i25, 3               
   128 : neg              i11, i11                  
   129 : unspill          i25, 2                    
   130 : add              i12, i25, 3               
   131 : mul              i11, i11, i12             
   132 : unspill          i25, 0                    
   133 : jmp_le           i25, i11, __loops_label_9 
   134 : __loops_label_8:                           
   135 : mov              i11, 2                    
   136 : unspill          i25, 2                    
   137 : mul              i11, i25, i11             
   138 : unspill          i25, 0                    
   139 : jmp_gt           i25, i11, __loops_label_7 
   140 : unspill          i25, 2                    
   141 : add              i11, i25, 3               
   142 : neg              i11, i11                  
   143 : unspill          i25, 2                    
   144 : add              i12, i25, 3               
   145 : mul              i11, i11, i12             
   146 : unspill          i25, 0                    
   147 : jmp_gt           i25, i11, __loops_label_7 
   148 : __loops_label_9:                           
   149 : mov              i11, 0                    
   150 : unspill          i25, 2                    
   151 : jmp_gt           i25, i11, __loops_label_7 
   152 : add              i10, i10, 3               
   153 : __loops_label_7:                           
   154 : unspill          i25, 2                    
   155 : add              i11, i25, 5               
   156 : shl              i11, i11, 3               
   157 : unspill          i25, 3                    
   158 : add              i11, i25, i11             
   159 : unspill          i25, 1                    
   160 : add              i11, i25, i11             
   161 : store.i64        i11, i10                  
   162 : unspill          i25, 2                    
   163 : add              i25, i25, 1               
   164 : spill            2, i25                    
   165 : jmp              3                         
   166 : __loops_label_5:                           
   167 : unspill          i25, 0                    
   168 : add              i25, i25, 1               
   169 : spill            0, i25                    
   170 : jmp              0                         
   171 : __loops_label_2:                           
   172 : unspill          i24, 5                    
   173 : unspill          i25, 6                    
   174 : add              i2, i2, 64                
   175 : ret                                        
