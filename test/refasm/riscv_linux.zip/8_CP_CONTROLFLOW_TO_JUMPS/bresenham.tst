bresenham(i0, i1, i2, i3, i4, i5, i6)
     0 : sub               i2, i2, 80                 
     1 : spill             5, i24                     
     2 : spill             6, i25                     
     3 : spill             7, i26                     
     4 : spill             8, i27                     
     5 : spill             0, i16                     
     6 : sub               i24, i14, i12              
     7 : iverson_gt        i16, 0, i24                
     8 : sub               i16, 0, i16                
     9 : and               i16, i16, i24              
    10 : sub               i24, 0, i24                
    11 : add               i24, i24, i16              
    12 : add               i25, i24, i16              
    13 : spill             1, i25                     
    14 : sub               i24, i14, i12              
    15 : iverson_gt        i16, i24, 0                
    16 : iverson_gt        i24, 0, i24                
    17 : sub               i25, i24, i16              
    18 : spill             2, i25                     
    19 : sub               i24, i15, i13              
    20 : iverson_gt        i16, 0, i24                
    21 : sub               i16, 0, i16                
    22 : and               i16, i16, i24              
    23 : sub               i24, 0, i24                
    24 : add               i24, i24, i16              
    25 : add               i16, i24, i16              
    26 : neg               i25, i16                   
    27 : spill             3, i25                     
    28 : sub               i24, i15, i13              
    29 : iverson_gt        i16, i24, 0                
    30 : iverson_gt        i24, 0, i24                
    31 : sub               i16, i24, i16              
    32 : unspill           i25, 1                     
    33 : unspill           i26, 3                     
    34 : add               i27, i25, i26              
    35 : spill             4, i27                     
    36 : __loops_label_0:                             
    37 : mov               i24, 0                     
    38 : jmp_eq            i10, i24, __loops_label_2  
    39 : mul               i24, i13, i11              
    40 : add               i24, i24, i12              
    41 : add               i24, i10, i24              
    42 : unspill           i25, 0                     
    43 : store.u8          i24, i25                   
    44 : jmp_ne            i12, i14, __loops_label_4  
    45 : jmp_ne            i13, i15, __loops_label_4  
    46 : jmp               2                          
    47 : __loops_label_4:                             
    48 : unspill           i25, 4                     
    49 : shl               i24, i25, 1                
    50 : unspill           i25, 3                     
    51 : jmp_gt            i24, i25, __loops_label_6  
    52 : jmp_ne            i12, i14, __loops_label_8  
    53 : jmp               2                          
    54 : __loops_label_8:                             
    55 : unspill           i26, 3                     
    56 : unspill           i25, 4                     
    57 : add               i25, i25, i26              
    58 : spill             4, i25                     
    59 : unspill           i25, 2                     
    60 : add               i12, i12, i25              
    61 : __loops_label_6:                             
    62 : unspill           i25, 1                     
    63 : jmp_gt            i24, i25, __loops_label_10 
    64 : jmp_ne            i13, i15, __loops_label_12 
    65 : jmp               2                          
    66 : __loops_label_12:                            
    67 : unspill           i26, 1                     
    68 : unspill           i25, 4                     
    69 : add               i25, i25, i26              
    70 : spill             4, i25                     
    71 : add               i13, i13, i16              
    72 : __loops_label_10:                            
    73 : jmp               0                          
    74 : __loops_label_2:                             
    75 : unspill           i24, 5                     
    76 : unspill           i25, 6                     
    77 : unspill           i26, 7                     
    78 : unspill           i27, 8                     
    79 : add               i2, i2, 80                 
    80 : ret                                          
