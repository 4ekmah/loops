area_sum(i0, i1)
     0 : sub              i2, i2, 192               
     1 : spill            20, i24                   
     2 : spill            21, i25                   
     3 : spill            22, i26                   
     4 : spill            22, i8                    
     5 : spill            23, i1                    
     6 : spill            18, i10                   
     7 : spill            17, i11                   
     8 : mov              i25, 0                    
     9 : spill            16, i25                   
    10 : __loops_label_0:                           
    11 : mov              i13, 0                    
    12 : unspill          i25, 17                   
    13 : jmp_le           i25, i13, __loops_label_2 
    14 : unspill          i25, 18                   
    15 : load.i8          i13, i25                  
    16 : mov              i24, 43                   
    17 : shl              i24, i24, 32              
    18 : rv_lui           i12, 776381               
    19 : add              i12, i12, -560            
    20 : add              i12, i24, i12             
    21 : mov              i24, 43                   
    22 : shl              i24, i24, 32              
    23 : rv_lui           i11, 776381               
    24 : add              i11, i11, -724            
    25 : add              i11, i24, i11             
    26 : mov              i24, 43                   
    27 : shl              i24, i24, 32              
    28 : rv_lui           i10, 776381               
    29 : add              i10, i10, -358            
    30 : add              i10, i24, i10             
    31 : mov              i24, 1                    
    32 : sub              i24, i13, i24             
    33 : iverson_eq       i24, i24, 0               
    34 : sub              i11, i11, i10             
    35 : sub              i24, 0, i24               
    36 : and              i11, i24, i11             
    37 : add              i10, i10, i11             
    38 : mov              i11, 0                    
    39 : sub              i11, i13, i11             
    40 : iverson_eq       i11, i11, 0               
    41 : sub              i12, i12, i10             
    42 : sub              i11, 0, i11               
    43 : and              i11, i11, i12             
    44 : add              i25, i10, i11             
    45 : spill            19, i25                   
    46 : mov              i11, 43                   
    47 : shl              i11, i11, 32              
    48 : rv_lui           i12, 776381               
    49 : add              i12, i12, -1928           
    50 : add              i11, i11, i12             
    51 : mov              i12, 43                   
    52 : shl              i12, i12, 32              
    53 : rv_lui           i24, 776381               
    54 : add              i24, i24, -1894           
    55 : add              i12, i12, i24             
    56 : mov              i24, 43                   
    57 : shl              i24, i24, 32              
    58 : rv_lui           i10, 776381               
    59 : add              i10, i10, -1870           
    60 : add              i10, i24, i10             
    61 : mov              i24, 1                    
    62 : sub              i24, i13, i24             
    63 : iverson_eq       i24, i24, 0               
    64 : sub              i12, i12, i10             
    65 : sub              i24, 0, i24               
    66 : and              i12, i24, i12             
    67 : add              i10, i10, i12             
    68 : mov              i12, 0                    
    69 : sub              i12, i13, i12             
    70 : iverson_eq       i12, i12, 0               
    71 : sub              i11, i11, i10             
    72 : sub              i12, 0, i12               
    73 : and              i11, i12, i11             
    74 : add              i10, i10, i11             
    75 : unspill          i26, 18                   
    76 : unspill          i25, 19                   
    77 : call_noret       [i25](i26)                
    78 : unspill          i25, 18                   
    79 : call             [i10](i10, i25)           
    80 : mov              i11, 43                   
    81 : shl              i11, i11, 32              
    82 : rv_lui           i12, 776381               
    83 : add              i12, i12, -1946           
    84 : add              i11, i11, i12             
    85 : unspill          i25, 16                   
    86 : call             [i11](i10, i25, i10)      
    87 : mov              i25, i10                  
    88 : spill            16, i25                   
    89 : unspill          i25, 18                   
    90 : add              i25, i25, 56              
    91 : spill            18, i25                   
    92 : unspill          i25, 17                   
    93 : sub              i25, i25, 1               
    94 : spill            17, i25                   
    95 : jmp              0                         
    96 : __loops_label_2:                           
    97 : unspill          i25, 16                   
    98 : mov              i10, i25                  
    99 : unspill          i8, 22                    
   100 : unspill          i1, 23                    
   101 : unspill          i24, 20                   
   102 : unspill          i25, 21                   
   103 : unspill          i26, 22                   
   104 : add              i2, i2, 192               
   105 : ret                                        
