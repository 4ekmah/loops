nullify_msb_lsb(i0, i1, i2)
     0 : sub       i2, i2, 16    
     1 : spill     0, i24        
     2 : shr       i13, i10, 1   
     3 : or        i13, i10, i13 
     4 : shr       i24, i13, 2   
     5 : or        i13, i13, i24 
     6 : shr       i24, i13, 4   
     7 : or        i13, i13, i24 
     8 : shr       i24, i13, 8   
     9 : or        i13, i13, i24 
    10 : shr       i24, i13, 16  
    11 : or        i13, i13, i24 
    12 : shr       i24, i13, 32  
    13 : or        i13, i13, i24 
    14 : add       i13, i13, 1   
    15 : shr       i13, i13, 1   
    16 : xor       i13, i13, i10 
    17 : store.u64 i12, i13      
    18 : sub       i12, i10, 1   
    19 : not       i12, i12      
    20 : and       i12, i10, i12 
    21 : xor       i10, i12, i10 
    22 : store.u64 i11, i10      
    23 : unspill   i24, 0        
    24 : add       i2, i2, 16    
    25 : ret                     
