min_max_scalar(i0, i1, i2, i3)
     0 : sub              i2, i2, 64                
     1 : spill            5, i24                    
     2 : spill            6, i25                    
     3 : spill            1, i12                    
     4 : spill            0, i13                    
     5 : mov              i24, 0                    
     6 : mov              i25, 0                    
     7 : spill            3, i25                    
     8 : mov              i25, 0                    
     9 : spill            2, i25                    
    10 : load.i32         i12, i10                  
    11 : mov              i25, i12                  
    12 : spill            4, i25                    
    13 : mov              i13, 4                    
    14 : mul              i11, i11, i13             
    15 : __loops_label_0:                           
    16 : jmp_ge           i24, i11, __loops_label_2 
    17 : add              i13, i10, i24             
    18 : load.i32         i13, i13                  
    19 : jmp_ge           i13, i12, __loops_label_4 
    20 : mov              i12, i13                  
    21 : mov              i25, i24                  
    22 : spill            3, i25                    
    23 : __loops_label_4:                           
    24 : unspill          i25, 4                    
    25 : jmp_le           i13, i25, __loops_label_6 
    26 : mov              i25, i13                  
    27 : spill            4, i25                    
    28 : mov              i25, i24                  
    29 : spill            2, i25                    
    30 : __loops_label_6:                           
    31 : add              i24, i24, 4               
    32 : jmp              0                         
    33 : __loops_label_2:                           
    34 : mov              i10, 4                    
    35 : unspill          i25, 3                    
    36 : div              i11, i25, i10             
    37 : unspill          i25, 2                    
    38 : div              i10, i25, i10             
    39 : unspill          i25, 1                    
    40 : store.i32        i25, i11                  
    41 : unspill          i25, 0                    
    42 : store.i32        i25, i10                  
    43 : mov              i10, 0                    
    44 : unspill          i24, 5                    
    45 : unspill          i25, 6                    
    46 : add              i2, i2, 64                
    47 : ret                                        
