triangle_types(i0, i1, i2)
     0 : sub               i2, i2, 32                 
     1 : spill             1, i24                     
     2 : spill             2, i25                     
     3 : spill             0, i11                     
     4 : mov               i13, 0                     
     5 : jmp_le            i10, i13, __loops_label_0  
     6 : mov               i13, 0                     
     7 : unspill           i25, 0                     
     8 : jmp_le            i25, i13, __loops_label_0  
     9 : mov               i13, 0                     
    10 : jmp_gt            i12, i13, __loops_label_1  
    11 : __loops_label_0:                             
    12 : mov               i10, 0                     
    13 : jmp               18                         
    14 : __loops_label_1:                             
    15 : unspill           i25, 0                     
    16 : add               i13, i25, i12              
    17 : jmp_gt            i10, i13, __loops_label_3  
    18 : add               i13, i10, i12              
    19 : unspill           i25, 0                     
    20 : jmp_gt            i25, i13, __loops_label_3  
    21 : unspill           i25, 0                     
    22 : add               i13, i10, i25              
    23 : jmp_le            i12, i13, __loops_label_4  
    24 : __loops_label_3:                             
    25 : mov               i10, 0                     
    26 : jmp               18                         
    27 : __loops_label_4:                             
    28 : unspill           i25, 0                     
    29 : jmp_ne            i10, i25, __loops_label_7  
    30 : jmp_ne            i10, i12, __loops_label_7  
    31 : mov               i10, 2                     
    32 : jmp               18                         
    33 : __loops_label_7:                             
    34 : unspill           i25, 0                     
    35 : jmp_eq            i10, i25, __loops_label_9  
    36 : jmp_eq            i10, i12, __loops_label_9  
    37 : unspill           i25, 0                     
    38 : jmp_ne            i25, i12, __loops_label_10 
    39 : __loops_label_9:                             
    40 : mov               i10, 3                     
    41 : jmp               18                         
    42 : __loops_label_10:                            
    43 : mul               i13, i10, i10              
    44 : unspill           i25, 0                     
    45 : mul               i24, i25, i25              
    46 : mul               i11, i12, i12              
    47 : add               i11, i24, i11              
    48 : jmp_eq            i13, i11, __loops_label_12 
    49 : unspill           i25, 0                     
    50 : mul               i11, i25, i25              
    51 : mul               i13, i10, i10              
    52 : mul               i24, i12, i12              
    53 : add               i13, i13, i24              
    54 : jmp_eq            i11, i13, __loops_label_12 
    55 : mul               i11, i12, i12              
    56 : mul               i13, i10, i10              
    57 : unspill           i25, 0                     
    58 : mul               i24, i25, i25              
    59 : add               i13, i13, i24              
    60 : jmp_ne            i11, i13, __loops_label_13 
    61 : __loops_label_12:                            
    62 : mov               i10, 1                     
    63 : jmp               18                         
    64 : __loops_label_13:                            
    65 : mul               i11, i10, i10              
    66 : unspill           i25, 0                     
    67 : mul               i13, i25, i25              
    68 : mul               i24, i12, i12              
    69 : add               i13, i13, i24              
    70 : jmp_gt            i11, i13, __loops_label_15 
    71 : unspill           i25, 0                     
    72 : mul               i11, i25, i25              
    73 : mul               i13, i10, i10              
    74 : mul               i24, i12, i12              
    75 : add               i13, i13, i24              
    76 : jmp_gt            i11, i13, __loops_label_15 
    77 : mul               i11, i12, i12              
    78 : mul               i10, i10, i10              
    79 : unspill           i25, 0                     
    80 : mul               i12, i25, i25              
    81 : add               i10, i10, i12              
    82 : jmp_le            i11, i10, __loops_label_16 
    83 : __loops_label_15:                            
    84 : mov               i10, 5                     
    85 : jmp               18                         
    86 : __loops_label_16:                            
    87 : mov               i10, 4                     
    88 : jmp               18                         
    89 : __loops_label_2:                             
    90 : __loops_label_5:                             
    91 : __loops_label_8:                             
    92 : __loops_label_11:                            
    93 : __loops_label_14:                            
    94 : __loops_label_17:                            
    95 : __loops_label_18:                            
    96 : unspill           i24, 1                     
    97 : unspill           i25, 2                     
    98 : add               i2, i2, 32                 
    99 : ret                                          
