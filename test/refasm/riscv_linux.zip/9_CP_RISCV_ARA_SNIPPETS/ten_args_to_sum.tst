ten_args_to_sum(i0, i1, i2, i3, i4, i5, i6, i7, i8, i9)
     0 : sub     i2, i2, 16    
     1 : spill   0, i24        
     2 : spill   1, i25        
     3 : mov     i24, 1        
     4 : mul     i10, i10, i24 
     5 : mov     i24, 2        
     6 : mul     i11, i11, i24 
     7 : add     i10, i10, i11 
     8 : mov     i11, 3        
     9 : mul     i11, i12, i11 
    10 : add     i10, i10, i11 
    11 : mov     i11, 4        
    12 : mul     i11, i13, i11 
    13 : add     i10, i10, i11 
    14 : mov     i11, 5        
    15 : mul     i11, i14, i11 
    16 : add     i10, i10, i11 
    17 : mov     i11, 6        
    18 : mul     i11, i15, i11 
    19 : add     i10, i10, i11 
    20 : mov     i11, 7        
    21 : mul     i11, i16, i11 
    22 : add     i10, i10, i11 
    23 : mov     i11, 8        
    24 : mul     i11, i17, i11 
    25 : add     i10, i10, i11 
    26 : mov     i11, 3        
    27 : unspill i25, 2        
    28 : mul     i11, i25, i11 
    29 : add     i10, i10, i11 
    30 : mov     i11, 2        
    31 : unspill i25, 3        
    32 : mul     i11, i25, i11 
    33 : add     i10, i10, i11 
    34 : unspill i24, 0        
    35 : unspill i25, 1        
    36 : add     i2, i2, 16    
    37 : ret                   
