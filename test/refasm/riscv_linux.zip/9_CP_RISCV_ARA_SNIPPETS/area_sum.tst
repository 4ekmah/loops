area_sum(i0, i1)
     0 : sub              i2, i2, 192               
     1 : spill            20, i24                   
     2 : spill            21, i25                   
     3 : spill            22, i26                   
     4 : spill            22, i8                    
     5 : spill            23, i1                    
     6 : spill            18, i10                   
     7 : spill            17, i11                   
     8 : mov              i25, 0                    
     9 : spill            16, i25                   
    10 : __loops_label_0:                           
    11 : mov              i13, 0                    
    12 : unspill          i25, 17                   
    13 : jmp_le           i25, i13, __loops_label_2 
    14 : unspill          i25, 18                   
    15 : load.i8          i13, i25                  
    16 : mov              i24, 43                   
    17 : shl              i24, i24, 32              
    18 : rv_lui           i12, 776381               
    19 : add              i12, i12, -560            
    20 : add              i12, i24, i12             
    21 : mov              i24, 43                   
    22 : shl              i24, i24, 32              
    23 : rv_lui           i11, 776381               
    24 : add              i11, i11, -724            
    25 : add              i11, i24, i11             
    26 : mov              i24, 43                   
    27 : shl              i24, i24, 32              
    28 : rv_lui           i10, 776381               
    29 : add              i10, i10, -358            
    30 : add              i10, i24, i10             
    31 : mov              i24, 1                    
    32 : sub              i24, i13, i24             
    33 : iverson_eq       i24, i24, 0               
    34 : sub              i11, i11, i10             
    35 : sub              i24, 0, i24               
    36 : and              i11, i24, i11             
    37 : add              i10, i10, i11             
    38 : mov              i11, 0                    
    39 : sub              i11, i13, i11             
    40 : iverson_eq       i11, i11, 0               
    41 : sub              i12, i12, i10             
    42 : sub              i11, 0, i11               
    43 : and              i11, i11, i12             
    44 : add              i25, i10, i11             
    45 : spill            19, i25                   
    46 : mov              i11, 43                   
    47 : shl              i11, i11, 32              
    48 : rv_lui           i12, 776381               
    49 : add              i12, i12, -1928           
    50 : add              i11, i11, i12             
    51 : mov              i12, 43                   
    52 : shl              i12, i12, 32              
    53 : rv_lui           i24, 776381               
    54 : add              i24, i24, -1894           
    55 : add              i12, i12, i24             
    56 : mov              i24, 43                   
    57 : shl              i24, i24, 32              
    58 : rv_lui           i10, 776381               
    59 : add              i10, i10, -1870           
    60 : add              i10, i24, i10             
    61 : mov              i24, 1                    
    62 : sub              i24, i13, i24             
    63 : iverson_eq       i24, i24, 0               
    64 : sub              i12, i12, i10             
    65 : sub              i24, 0, i24               
    66 : and              i12, i24, i12             
    67 : add              i10, i10, i12             
    68 : mov              i12, 0                    
    69 : sub              i12, i13, i12             
    70 : iverson_eq       i12, i12, 0               
    71 : sub              i11, i11, i10             
    72 : sub              i12, 0, i12               
    73 : and              i11, i12, i11             
    74 : add              i10, i10, i11             
    75 : unspill          i26, 18                   
    76 : unspill          i25, 19                   
    77 : spill            0, i6                     
    78 : spill            1, i7                     
    79 : spill            2, i10                    
    80 : spill            3, i11                    
    81 : spill            4, i12                    
    82 : spill            5, i13                    
    83 : spill            6, i14                    
    84 : spill            7, i15                    
    85 : spill            8, i16                    
    86 : spill            9, i17                    
    87 : spill            10, i28                   
    88 : spill            11, i29                   
    89 : spill            12, i30                   
    90 : spill            13, i31                   
    91 : mov              i10, i26                  
    92 : call_noret       [i25]()                   
    93 : unspill          i6, 0                     
    94 : unspill          i7, 1                     
    95 : unspill          i10, 2                    
    96 : unspill          i11, 3                    
    97 : unspill          i12, 4                    
    98 : unspill          i13, 5                    
    99 : unspill          i14, 6                    
   100 : unspill          i15, 7                    
   101 : unspill          i16, 8                    
   102 : unspill          i17, 9                    
   103 : unspill          i28, 10                   
   104 : unspill          i29, 11                   
   105 : unspill          i30, 12                   
   106 : unspill          i31, 13                   
   107 : unspill          i25, 18                   
   108 : spill            0, i6                     
   109 : spill            1, i7                     
   110 : spill            2, i10                    
   111 : spill            3, i11                    
   112 : spill            4, i12                    
   113 : spill            5, i13                    
   114 : spill            6, i14                    
   115 : spill            7, i15                    
   116 : spill            8, i16                    
   117 : spill            9, i17                    
   118 : spill            10, i28                   
   119 : spill            11, i29                   
   120 : spill            12, i30                   
   121 : spill            13, i31                   
   122 : mov              i10, i25                  
   123 : unspill          i6, 2                     
   124 : call_noret       [i6]()                    
   125 : unspill          i6, 0                     
   126 : unspill          i7, 1                     
   127 : unspill          i11, 3                    
   128 : unspill          i12, 4                    
   129 : unspill          i13, 5                    
   130 : unspill          i14, 6                    
   131 : unspill          i15, 7                    
   132 : unspill          i16, 8                    
   133 : unspill          i17, 9                    
   134 : unspill          i28, 10                   
   135 : unspill          i29, 11                   
   136 : unspill          i30, 12                   
   137 : unspill          i31, 13                   
   138 : mov              i11, 43                   
   139 : shl              i11, i11, 32              
   140 : rv_lui           i12, 776381               
   141 : add              i12, i12, -1946           
   142 : add              i11, i11, i12             
   143 : unspill          i25, 16                   
   144 : spill            0, i6                     
   145 : spill            1, i7                     
   146 : spill            2, i10                    
   147 : spill            3, i11                    
   148 : spill            4, i12                    
   149 : spill            5, i13                    
   150 : spill            6, i14                    
   151 : spill            7, i15                    
   152 : spill            8, i16                    
   153 : spill            9, i17                    
   154 : spill            10, i28                   
   155 : spill            11, i29                   
   156 : spill            12, i30                   
   157 : spill            13, i31                   
   158 : mov              i10, i25                  
   159 : unspill          i11, 2                    
   160 : unspill          i6, 3                     
   161 : call_noret       [i6]()                    
   162 : unspill          i6, 0                     
   163 : unspill          i7, 1                     
   164 : unspill          i11, 3                    
   165 : unspill          i12, 4                    
   166 : unspill          i13, 5                    
   167 : unspill          i14, 6                    
   168 : unspill          i15, 7                    
   169 : unspill          i16, 8                    
   170 : unspill          i17, 9                    
   171 : unspill          i28, 10                   
   172 : unspill          i29, 11                   
   173 : unspill          i30, 12                   
   174 : unspill          i31, 13                   
   175 : mov              i25, i10                  
   176 : spill            16, i25                   
   177 : unspill          i25, 18                   
   178 : add              i25, i25, 56              
   179 : spill            18, i25                   
   180 : unspill          i25, 17                   
   181 : sub              i25, i25, 1               
   182 : spill            17, i25                   
   183 : jmp              0                         
   184 : __loops_label_2:                           
   185 : unspill          i25, 16                   
   186 : mov              i10, i25                  
   187 : unspill          i8, 22                    
   188 : unspill          i1, 23                    
   189 : unspill          i24, 20                   
   190 : unspill          i25, 21                   
   191 : unspill          i26, 22                   
   192 : add              i2, i2, 192               
   193 : ret                                        
