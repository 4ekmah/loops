fixed_power_9(i0)
     0 : mul i11, i10, i10 
     1 : mul i11, i11, i11 
     2 : mul i11, i11, i11 
     3 : mul i10, i10, i11 
     4 : ret               
