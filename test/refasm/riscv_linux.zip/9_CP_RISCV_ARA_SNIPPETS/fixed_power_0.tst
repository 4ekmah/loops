fixed_power_0(i0)
     0 : mov i10, 1 
     1 : ret        
