helloworld_call()
     0 : sub        i2, i2, 144   
     1 : spill      16, i8        
     2 : spill      17, i1        
     3 : mov        i10, 43       
     4 : shl        i10, i10, 32  
     5 : rv_lui     i11, 707045   
     6 : add        i11, i11, 946 
     7 : add        i10, i10, i11 
     8 : spill      0, i6         
     9 : spill      1, i7         
    10 : spill      2, i10        
    11 : spill      3, i11        
    12 : spill      4, i12        
    13 : spill      5, i13        
    14 : spill      6, i14        
    15 : spill      7, i15        
    16 : spill      8, i16        
    17 : spill      9, i17        
    18 : spill      10, i28       
    19 : spill      11, i29       
    20 : spill      12, i30       
    21 : spill      13, i31       
    22 : call_noret [i10]()       
    23 : unspill    i6, 0         
    24 : unspill    i7, 1         
    25 : unspill    i10, 2        
    26 : unspill    i11, 3        
    27 : unspill    i12, 4        
    28 : unspill    i13, 5        
    29 : unspill    i14, 6        
    30 : unspill    i15, 7        
    31 : unspill    i16, 8        
    32 : unspill    i17, 9        
    33 : unspill    i28, 10       
    34 : unspill    i29, 11       
    35 : unspill    i30, 12       
    36 : unspill    i31, 13       
    37 : unspill    i8, 16        
    38 : unspill    i1, 17        
    39 : add        i2, i2, 144   
    40 : ret                      
