snake(i0, i1, i2)
     0 : sub              i2, i2, 240               
     1 : spill            25, i24                   
     2 : spill            26, i25                   
     3 : spill            27, i26                   
     4 : spill            28, i8                    
     5 : spill            29, i1                    
     6 : spill            23, i10                   
     7 : spill            22, i11                   
     8 : spill            21, i12                   
     9 : unspill          i25, 22                   
    10 : unspill          i26, 21                   
    11 : add              i13, i25, i26             
    12 : sub              i25, i13, 1               
    13 : spill            20, i25                   
    14 : mov              i25, 0                    
    15 : spill            19, i25                   
    16 : mov              i25, 1                    
    17 : spill            16, i25                   
    18 : unspill          i25, 16                   
    19 : neg              i26, i25                  
    20 : spill            17, i26                   
    21 : mov              i25, 0                    
    22 : spill            18, i25                   
    23 : __loops_label_0:                           
    24 : unspill          i26, 20                   
    25 : unspill          i25, 18                   
    26 : jmp_ge           i25, i26, __loops_label_2 
    27 : mov              i24, 0                    
    28 : mov              i25, 0                    
    29 : spill            24, i25                   
    30 : unspill          i25, 18                   
    31 : and              i12, i25, 1               
    32 : mov              i11, 0                    
    33 : jmp_eq           i12, i11, __loops_label_4 
    34 : unspill          i25, 21                   
    35 : sub              i11, i25, 1               
    36 : unspill          i25, 18                   
    37 : iverson_gt       i12, i11, i25             
    38 : unspill          i25, 18                   
    39 : sub              i10, i11, i25             
    40 : sub              i12, 0, i12               
    41 : and              i10, i12, i10             
    42 : unspill          i25, 18                   
    43 : add              i24, i25, i10             
    44 : unspill          i25, 18                   
    45 : sub              i10, i25, i11             
    46 : mov              i12, 0                    
    47 : unspill          i25, 18                   
    48 : iverson_gt       i11, i25, i11             
    49 : sub              i10, i10, i12             
    50 : sub              i11, 0, i11               
    51 : and              i10, i11, i10             
    52 : add              i25, i12, i10             
    53 : spill            24, i25                   
    54 : jmp              5                         
    55 : __loops_label_4:                           
    56 : unspill          i25, 22                   
    57 : sub              i10, i25, 1               
    58 : unspill          i25, 18                   
    59 : sub              i11, i25, i10             
    60 : mov              i12, 0                    
    61 : unspill          i25, 18                   
    62 : iverson_gt       i13, i25, i10             
    63 : sub              i11, i11, i12             
    64 : sub              i13, 0, i13               
    65 : and              i11, i13, i11             
    66 : add              i24, i12, i11             
    67 : unspill          i25, 18                   
    68 : iverson_gt       i11, i10, i25             
    69 : unspill          i25, 18                   
    70 : sub              i10, i10, i25             
    71 : sub              i11, 0, i11               
    72 : and              i10, i11, i10             
    73 : unspill          i25, 18                   
    74 : add              i26, i25, i10             
    75 : spill            24, i26                   
    76 : __loops_label_5:                           
    77 : __loops_label_6:                           
    78 : mov              i10, 0                    
    79 : jmp_gt           i24, i10, __loops_label_8 
    80 : unspill          i25, 21                   
    81 : jmp_ge           i24, i25, __loops_label_8 
    82 : mov              i10, 0                    
    83 : unspill          i25, 24                   
    84 : jmp_gt           i25, i10, __loops_label_8 
    85 : unspill          i26, 22                   
    86 : unspill          i25, 24                   
    87 : jmp_ge           i25, i26, __loops_label_8 
    88 : mov              i10, 43                   
    89 : shl              i10, i10, 32              
    90 : rv_lui           i11, 776381               
    91 : add              i11, i11, -888            
    92 : add              i10, i10, i11             
    93 : unspill          i25, 24                   
    94 : spill            0, i6                     
    95 : spill            1, i7                     
    96 : spill            2, i10                    
    97 : spill            3, i11                    
    98 : spill            4, i12                    
    99 : spill            5, i13                    
   100 : spill            6, i14                    
   101 : spill            7, i15                    
   102 : spill            8, i16                    
   103 : spill            9, i17                    
   104 : spill            10, i28                   
   105 : spill            11, i29                   
   106 : spill            12, i30                   
   107 : spill            13, i31                   
   108 : mov              i10, i24                  
   109 : mov              i11, i25                  
   110 : unspill          i6, 2                     
   111 : call_noret       [i6]()                    
   112 : unspill          i6, 0                     
   113 : unspill          i7, 1                     
   114 : unspill          i10, 2                    
   115 : unspill          i11, 3                    
   116 : unspill          i12, 4                    
   117 : unspill          i13, 5                    
   118 : unspill          i14, 6                    
   119 : unspill          i15, 7                    
   120 : unspill          i16, 8                    
   121 : unspill          i17, 9                    
   122 : unspill          i28, 10                   
   123 : unspill          i29, 11                   
   124 : unspill          i30, 12                   
   125 : unspill          i31, 13                   
   126 : unspill          i26, 21                   
   127 : unspill          i25, 24                   
   128 : mul              i10, i25, i26             
   129 : add              i10, i10, i24             
   130 : unspill          i25, 23                   
   131 : add              i10, i25, i10             
   132 : unspill          i25, 19                   
   133 : store.u8         i10, i25                  
   134 : unspill          i25, 19                   
   135 : add              i25, i25, 1               
   136 : spill            19, i25                   
   137 : unspill          i25, 16                   
   138 : add              i24, i24, i25             
   139 : unspill          i26, 17                   
   140 : unspill          i25, 24                   
   141 : add              i25, i25, i26             
   142 : spill            24, i25                   
   143 : jmp              6                         
   144 : __loops_label_8:                           
   145 : unspill          i25, 16                   
   146 : neg              i25, i25                  
   147 : spill            16, i25                   
   148 : unspill          i25, 17                   
   149 : neg              i25, i25                  
   150 : spill            17, i25                   
   151 : unspill          i25, 18                   
   152 : add              i25, i25, 1               
   153 : spill            18, i25                   
   154 : jmp              0                         
   155 : __loops_label_2:                           
   156 : unspill          i8, 28                    
   157 : unspill          i1, 29                    
   158 : unspill          i24, 25                   
   159 : unspill          i25, 26                   
   160 : unspill          i26, 27                   
   161 : add              i2, i2, 240               
   162 : ret                                        
