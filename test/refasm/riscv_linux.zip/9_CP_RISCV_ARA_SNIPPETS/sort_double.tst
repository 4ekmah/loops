sort_double(i0, i1)
     0 : sub              i2, i2, 208               
     1 : spill            21, i24                   
     2 : spill            22, i25                   
     3 : spill            23, i26                   
     4 : spill            24, i8                    
     5 : spill            25, i1                    
     6 : spill            19, i10                   
     7 : shl              i25, i11, 3               
     8 : spill            18, i25                   
     9 : unspill          i25, 18                   
    10 : sub              i26, i25, 8               
    11 : spill            17, i26                   
    12 : mov              i25, 0                    
    13 : spill            16, i25                   
    14 : __loops_label_0:                           
    15 : unspill          i26, 17                   
    16 : unspill          i25, 16                   
    17 : jmp_ge           i25, i26, __loops_label_2 
    18 : unspill          i25, 16                   
    19 : mov              i26, i25                  
    20 : spill            20, i26                   
    21 : unspill          i25, 20                   
    22 : add              i13, i25, 8               
    23 : __loops_label_3:                           
    24 : unspill          i25, 18                   
    25 : jmp_ge           i13, i25, __loops_label_5 
    26 : unspill          i25, 19                   
    27 : add              i12, i25, i13             
    28 : load.fp64        i12, i12                  
    29 : unspill          i25, 19                   
    30 : unspill          i26, 20                   
    31 : add              i11, i25, i26             
    32 : load.fp64        i11, i11                  
    33 : mov              i10, 43                   
    34 : shl              i10, i10, 32              
    35 : rv_lui           i24, 776381               
    36 : add              i24, i24, -1960           
    37 : add              i10, i10, i24             
    38 : spill            0, i6                     
    39 : spill            1, i7                     
    40 : spill            2, i10                    
    41 : spill            3, i11                    
    42 : spill            4, i12                    
    43 : spill            5, i13                    
    44 : spill            6, i14                    
    45 : spill            7, i15                    
    46 : spill            8, i16                    
    47 : spill            9, i17                    
    48 : spill            10, i28                   
    49 : spill            11, i29                   
    50 : spill            12, i30                   
    51 : spill            13, i31                   
    52 : mov              i10, i12                  
    53 : unspill          i6, 2                     
    54 : call_noret       [i6]()                    
    55 : unspill          i6, 0                     
    56 : unspill          i7, 1                     
    57 : unspill          i11, 3                    
    58 : unspill          i12, 4                    
    59 : unspill          i13, 5                    
    60 : unspill          i14, 6                    
    61 : unspill          i15, 7                    
    62 : unspill          i16, 8                    
    63 : unspill          i17, 9                    
    64 : unspill          i28, 10                   
    65 : unspill          i29, 11                   
    66 : unspill          i30, 12                   
    67 : unspill          i31, 13                   
    68 : mov              i11, 0                    
    69 : jmp_eq           i10, i11, __loops_label_7 
    70 : mov              i25, i13                  
    71 : spill            20, i25                   
    72 : __loops_label_7:                           
    73 : add              i13, i13, 8               
    74 : jmp              3                         
    75 : __loops_label_5:                           
    76 : unspill          i26, 16                   
    77 : unspill          i25, 20                   
    78 : jmp_eq           i25, i26, __loops_label_9 
    79 : unspill          i25, 19                   
    80 : unspill          i26, 16                   
    81 : add              i10, i25, i26             
    82 : load.fp64        i10, i10                  
    83 : unspill          i25, 19                   
    84 : unspill          i26, 20                   
    85 : add              i11, i25, i26             
    86 : load.fp64        i11, i11                  
    87 : unspill          i25, 19                   
    88 : unspill          i26, 20                   
    89 : add              i12, i25, i26             
    90 : store.fp64       i12, i10                  
    91 : unspill          i25, 19                   
    92 : unspill          i26, 16                   
    93 : add              i10, i25, i26             
    94 : store.fp64       i10, i11                  
    95 : __loops_label_9:                           
    96 : unspill          i25, 16                   
    97 : add              i25, i25, 8               
    98 : spill            16, i25                   
    99 : jmp              0                         
   100 : __loops_label_2:                           
   101 : unspill          i8, 24                    
   102 : unspill          i1, 25                    
   103 : unspill          i24, 21                   
   104 : unspill          i25, 22                   
   105 : unspill          i26, 23                   
   106 : add              i2, i2, 208               
   107 : ret                                        
