helloworld_call()
     0 : call_noret [0x0000AAAAAF36EE90]() 
     1 : ret                               
