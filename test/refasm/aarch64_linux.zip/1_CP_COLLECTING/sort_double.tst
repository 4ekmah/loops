sort_double(i0, i1)
     0 : shl                    i1, i1, 3                        
     1 : sub                    i2, i1, 8                        
     2 : mov                    i3, 0                            
     3 : annotation:whilecstart 0                                
     4 : cmp                    i3, i2                           
     5 : jmp_ge                 __loops_label_2                  
     6 : annotation:whilecend                                    
     7 : mov                    i4, i3                           
     8 : add                    i5, i4, 8                        
     9 : annotation:whilecstart 3                                
    10 : cmp                    i5, i1                           
    11 : jmp_ge                 __loops_label_5                  
    12 : annotation:whilecend                                    
    13 : annotation:ifcstart                                     
    14 : load.fp64              i7, i0, i5                       
    15 : load.fp64              i8, i0, i4                       
    16 : call                   [0x0000AAAAE7656098](i6, i7, i8) 
    17 : cmp                    i6, 0                            
    18 : jmp_eq                 __loops_label_7                  
    19 : annotation:ifcend                                       
    20 : mov                    i4, i5                           
    21 : annotation:endif       7                                
    22 : add                    i5, i5, 8                        
    23 : annotation:endwhile    3, 5                             
    24 : annotation:ifcstart                                     
    25 : cmp                    i4, i3                           
    26 : jmp_eq                 __loops_label_9                  
    27 : annotation:ifcend                                       
    28 : load.fp64              i9, i0, i3                       
    29 : load.fp64              i10, i0, i4                      
    30 : store.fp64             i0, i4, i9                       
    31 : store.fp64             i0, i3, i10                      
    32 : annotation:endif       9                                
    33 : add                    i3, i3, 8                        
    34 : annotation:endwhile    0, 2                             
    35 : ret                                                     
