area_sum(i0, i1)
     0 : sub              i31, i31, 464      
     1 : spill            53, i25            
     2 : spill            54, i26            
     3 : arm_stp          i31, 448, i29, i30 
     4 : mov              i29, i31           
     5 : mov              i26, 0             
     6 : spill            50, i26            
     7 : __loops_label_0:                    
     8 : cmp              i1, 0              
     9 : jmp_le           __loops_label_2    
    10 : load.i8          i26, i0            
    11 : spill            51, i26            
    12 : mov              i25, 61668         
    13 : arm_movk         i25, 44854, 16     
    14 : arm_movk         i25, 43690, 32     
    15 : mov              i2, 61440          
    16 : arm_movk         i2, 44854, 16      
    17 : arm_movk         i2, 43690, 32      
    18 : mov              i3, 61952          
    19 : arm_movk         i3, 44854, 16      
    20 : arm_movk         i3, 43690, 32      
    21 : unspill          i26, 51            
    22 : cmp              i26, 1             
    23 : select_eq        i2, i2, i3         
    24 : unspill          i26, 51            
    25 : cmp              i26, 0             
    26 : select_eq        i26, i25, i2       
    27 : spill            52, i26            
    28 : mov              i3, 59856          
    29 : arm_movk         i3, 44854, 16      
    30 : arm_movk         i3, 43690, 32      
    31 : mov              i25, 59888         
    32 : arm_movk         i25, 44854, 16     
    33 : arm_movk         i25, 43690, 32     
    34 : mov              i2, 59920          
    35 : arm_movk         i2, 44854, 16      
    36 : arm_movk         i2, 43690, 32      
    37 : unspill          i26, 51            
    38 : cmp              i26, 1             
    39 : select_eq        i2, i25, i2        
    40 : unspill          i26, 51            
    41 : cmp              i26, 0             
    42 : select_eq        i2, i3, i2         
    43 : unspill          i26, 52            
    44 : call_noret       [i26](i0)          
    45 : call             [i2](i2, i0)       
    46 : mov              i3, 59828          
    47 : arm_movk         i3, 44854, 16      
    48 : arm_movk         i3, 43690, 32      
    49 : unspill          i26, 50            
    50 : call             [i3](i2, i26, i2)  
    51 : mov              i26, i2            
    52 : spill            50, i26            
    53 : add              i0, i0, 56         
    54 : sub              i1, i1, 1          
    55 : jmp              0                  
    56 : __loops_label_2:                    
    57 : unspill          i26, 50            
    58 : mov              i0, i26            
    59 : arm_ldp          i29, i30, i31, 448 
    60 : unspill          i25, 53            
    61 : unspill          i26, 54            
    62 : add              i31, i31, 464      
    63 : ret                                 
