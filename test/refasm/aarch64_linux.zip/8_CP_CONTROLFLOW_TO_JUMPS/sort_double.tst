sort_double(i0, i1)
     0 : sub              i31, i31, 480      
     1 : spill            55, i25            
     2 : spill            56, i26            
     3 : spill            57, i27            
     4 : arm_stp          i31, 464, i29, i30 
     5 : mov              i29, i31           
     6 : shl              i26, i1, 3         
     7 : spill            52, i26            
     8 : unspill          i26, 52            
     9 : sub              i27, i26, 8        
    10 : spill            53, i27            
    11 : mov              i26, 0             
    12 : spill            54, i26            
    13 : __loops_label_0:                    
    14 : unspill          i27, 53            
    15 : unspill          i26, 54            
    16 : cmp              i26, i27           
    17 : jmp_ge           __loops_label_2    
    18 : unspill          i26, 54            
    19 : mov              i27, i26           
    20 : spill            51, i27            
    21 : unspill          i26, 51            
    22 : add              i27, i26, 8        
    23 : spill            50, i27            
    24 : __loops_label_3:                    
    25 : unspill          i27, 52            
    26 : unspill          i26, 50            
    27 : cmp              i26, i27           
    28 : jmp_ge           __loops_label_5    
    29 : unspill          i26, 50            
    30 : load.fp64        i25, i0, i26       
    31 : unspill          i26, 51            
    32 : load.fp64        i3, i0, i26        
    33 : mov              i2, 59808          
    34 : arm_movk         i2, 44854, 16      
    35 : arm_movk         i2, 43690, 32      
    36 : call             [i2](i2, i25, i3)  
    37 : cmp              i2, 0              
    38 : jmp_eq           __loops_label_7    
    39 : unspill          i26, 50            
    40 : mov              i27, i26           
    41 : spill            51, i27            
    42 : __loops_label_7:                    
    43 : unspill          i26, 50            
    44 : add              i26, i26, 8        
    45 : spill            50, i26            
    46 : jmp              3                  
    47 : __loops_label_5:                    
    48 : unspill          i27, 54            
    49 : unspill          i26, 51            
    50 : cmp              i26, i27           
    51 : jmp_eq           __loops_label_9    
    52 : unspill          i26, 54            
    53 : load.fp64        i2, i0, i26        
    54 : unspill          i26, 51            
    55 : load.fp64        i3, i0, i26        
    56 : unspill          i26, 51            
    57 : store.fp64       i0, i26, i2        
    58 : unspill          i26, 54            
    59 : store.fp64       i0, i26, i3        
    60 : __loops_label_9:                    
    61 : unspill          i26, 54            
    62 : add              i26, i26, 8        
    63 : spill            54, i26            
    64 : jmp              0                  
    65 : __loops_label_2:                    
    66 : arm_ldp          i29, i30, i31, 464 
    67 : unspill          i25, 55            
    68 : unspill          i26, 56            
    69 : unspill          i27, 57            
    70 : add              i31, i31, 480      
    71 : ret                                 
