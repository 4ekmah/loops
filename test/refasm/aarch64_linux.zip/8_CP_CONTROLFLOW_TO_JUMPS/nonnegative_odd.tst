nonnegative_odd(i0, i1)
     0 : sub              i31, i31, 64    
     1 : spill            4, i25          
     2 : spill            5, i26          
     3 : spill            6, i27          
     4 : mov              i26, 0          
     5 : spill            3, i26          
     6 : mov              i26, -4         
     7 : spill            2, i26          
     8 : mov              i2, 4           
     9 : mul              i1, i1, i2      
    10 : spill            1, i1           
    11 : __loops_label_0:                 
    12 : unspill          i27, 1          
    13 : unspill          i26, 3          
    14 : cmp              i26, i27        
    15 : jmp_ge           __loops_label_2 
    16 : unspill          i26, 3          
    17 : load.i32         i25, i0, i26    
    18 : cmp              i25, 0          
    19 : jmp_ge           __loops_label_4 
    20 : unspill          i26, 3          
    21 : add              i26, i26, 4     
    22 : spill            3, i26          
    23 : jmp              0               
    24 : __loops_label_4:                 
    25 : mov              i3, 2           
    26 : div              i2, i25, i3     
    27 : mul              i2, i2, i3      
    28 : sub              i2, i25, i2     
    29 : cmp              i2, 0           
    30 : jmp_eq           __loops_label_6 
    31 : unspill          i26, 3          
    32 : mov              i27, i26        
    33 : spill            2, i27          
    34 : jmp              2               
    35 : __loops_label_6:                 
    36 : unspill          i26, 3          
    37 : add              i26, i26, 4     
    38 : spill            3, i26          
    39 : jmp              0               
    40 : __loops_label_2:                 
    41 : mov              i0, 4           
    42 : unspill          i26, 2          
    43 : div              i0, i26, i0     
    44 : mov              i0, i0          
    45 : unspill          i25, 4          
    46 : unspill          i26, 5          
    47 : unspill          i27, 6          
    48 : add              i31, i31, 64    
    49 : ret                              
