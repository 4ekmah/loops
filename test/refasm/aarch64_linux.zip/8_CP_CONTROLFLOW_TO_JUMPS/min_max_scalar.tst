min_max_scalar(i0, i1, i2, i3)
     0 : sub              i31, i31, 80    
     1 : spill            7, i25          
     2 : spill            8, i26          
     3 : spill            9, i27          
     4 : mov              i26, 0          
     5 : spill            6, i26          
     6 : mov              i26, 0          
     7 : spill            1, i26          
     8 : mov              i26, 0          
     9 : spill            2, i26          
    10 : load.i32         i26, i0         
    11 : spill            3, i26          
    12 : unspill          i26, 3          
    13 : mov              i27, i26        
    14 : spill            4, i27          
    15 : mov              i25, 4          
    16 : mul              i1, i1, i25     
    17 : spill            5, i1           
    18 : __loops_label_0:                 
    19 : unspill          i27, 5          
    20 : unspill          i26, 6          
    21 : cmp              i26, i27        
    22 : jmp_ge           __loops_label_2 
    23 : unspill          i26, 6          
    24 : load.i32         i25, i0, i26    
    25 : unspill          i26, 3          
    26 : cmp              i25, i26        
    27 : jmp_ge           __loops_label_4 
    28 : mov              i26, i25        
    29 : spill            3, i26          
    30 : unspill          i26, 6          
    31 : mov              i27, i26        
    32 : spill            1, i27          
    33 : __loops_label_4:                 
    34 : unspill          i26, 4          
    35 : cmp              i25, i26        
    36 : jmp_le           __loops_label_6 
    37 : mov              i26, i25        
    38 : spill            4, i26          
    39 : unspill          i26, 6          
    40 : mov              i27, i26        
    41 : spill            2, i27          
    42 : __loops_label_6:                 
    43 : unspill          i26, 6          
    44 : add              i26, i26, 4     
    45 : spill            6, i26          
    46 : jmp              0               
    47 : __loops_label_2:                 
    48 : mov              i0, 4           
    49 : unspill          i26, 1          
    50 : div              i1, i26, i0     
    51 : unspill          i26, 2          
    52 : div              i0, i26, i0     
    53 : store.i32        i2, i1          
    54 : store.i32        i3, i0          
    55 : mov              i0, 0           
    56 : unspill          i25, 7          
    57 : unspill          i26, 8          
    58 : unspill          i27, 9          
    59 : add              i31, i31, 80    
    60 : ret                              
