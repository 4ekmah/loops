min_max_select(i0, i1, i2, i3)
     0 : sub              i31, i31, 80    
     1 : spill            7, i25          
     2 : spill            8, i26          
     3 : spill            9, i27          
     4 : mov              i26, 0          
     5 : spill            6, i26          
     6 : mov              i26, 0          
     7 : spill            1, i26          
     8 : mov              i26, 0          
     9 : spill            2, i26          
    10 : load.i32         i26, i0         
    11 : spill            3, i26          
    12 : unspill          i26, 3          
    13 : mov              i27, i26        
    14 : spill            4, i27          
    15 : shl              i1, i1, 2       
    16 : spill            5, i1           
    17 : __loops_label_0:                 
    18 : unspill          i27, 5          
    19 : unspill          i26, 6          
    20 : cmp              i26, i27        
    21 : jmp_ge           __loops_label_2 
    22 : unspill          i26, 6          
    23 : load.i32         i25, i0, i26    
    24 : unspill          i26, 3          
    25 : cmp              i25, i26        
    26 : unspill          i26, 6          
    27 : unspill          i27, 1          
    28 : select_gt        i27, i26, i27   
    29 : spill            1, i27          
    30 : unspill          i26, 3          
    31 : cmp              i25, i26        
    32 : unspill          i26, 3          
    33 : select_gt        i26, i25, i26   
    34 : spill            3, i26          
    35 : unspill          i26, 4          
    36 : cmp              i25, i26        
    37 : unspill          i26, 6          
    38 : unspill          i27, 2          
    39 : select_gt        i27, i26, i27   
    40 : spill            2, i27          
    41 : unspill          i26, 4          
    42 : cmp              i25, i26        
    43 : unspill          i26, 4          
    44 : select_gt        i26, i25, i26   
    45 : spill            4, i26          
    46 : unspill          i26, 6          
    47 : add              i26, i26, 4     
    48 : spill            6, i26          
    49 : jmp              0               
    50 : __loops_label_2:                 
    51 : unspill          i26, 1          
    52 : sar              i26, i26, 2     
    53 : spill            1, i26          
    54 : unspill          i26, 2          
    55 : sar              i26, i26, 2     
    56 : spill            2, i26          
    57 : unspill          i26, 1          
    58 : store.i32        i2, i26         
    59 : unspill          i26, 2          
    60 : store.i32        i3, i26         
    61 : mov              i0, 0           
    62 : unspill          i25, 7          
    63 : unspill          i26, 8          
    64 : unspill          i27, 9          
    65 : add              i31, i31, 80    
    66 : ret                              
