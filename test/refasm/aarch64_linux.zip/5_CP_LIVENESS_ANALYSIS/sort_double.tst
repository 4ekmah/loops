sort_double(i0, i1)
     0 : shl                    i2, i1, 3         
     1 : sub                    i3, i2, 8         
     2 : mov                    i4, 0             
     3 : annotation:whilecstart 0                 
     4 : cmp                    i4, i3            
     5 : jmp_ge                 __loops_label_2   
     6 : annotation:whilecend                     
     7 : mov                    i5, i4            
     8 : add                    i6, i5, 8         
     9 : annotation:whilecstart 3                 
    10 : cmp                    i6, i2            
    11 : jmp_ge                 __loops_label_5   
    12 : annotation:whilecend                     
    13 : annotation:ifcstart                      
    14 : load.fp64              i8, i0, i6        
    15 : load.fp64              i9, i0, i5        
    16 : mov                    i12, 24728        
    17 : arm_movk               i12, 59237, 16    
    18 : arm_movk               i12, 43690, 32    
    19 : call                   [i12](i7, i8, i9) 
    20 : cmp                    i7, 0             
    21 : jmp_eq                 __loops_label_7   
    22 : annotation:ifcend                        
    23 : mov                    i5, i6            
    24 : annotation:endif       7                 
    25 : add                    i6, i6, 8         
    26 : annotation:endwhile    3, 5              
    27 : annotation:ifcstart                      
    28 : cmp                    i5, i4            
    29 : jmp_eq                 __loops_label_9   
    30 : annotation:ifcend                        
    31 : load.fp64              i10, i0, i4       
    32 : load.fp64              i11, i0, i5       
    33 : store.fp64             i0, i5, i10       
    34 : store.fp64             i0, i4, i11       
    35 : annotation:endif       9                 
    36 : add                    i4, i4, 8         
    37 : annotation:endwhile    0, 2              
    38 : ret                                      
