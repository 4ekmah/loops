area_sum(i0, i1)
     0 : sub                    i31, i31, 464      
     1 : spill                  53, i25            
     2 : spill                  54, i26            
     3 : arm_stp                i31, 448, i29, i30 
     4 : mov                    i29, i31           
     5 : spill                  52, i0             
     6 : spill                  51, i1             
     7 : mov                    i26, 0             
     8 : spill                  50, i26            
     9 : annotation:whilecstart 0                  
    10 : unspill                i26, 51            
    11 : cmp                    i26, 0             
    12 : jmp_le                 __loops_label_2    
    13 : annotation:whilecend                      
    14 : unspill                i26, 52            
    15 : load.i8                i3, i26            
    16 : mov                    i25, 55700         
    17 : arm_movk               i25, 48874, 16     
    18 : arm_movk               i25, 43690, 32     
    19 : mov                    i2, 55472          
    20 : arm_movk               i2, 48874, 16      
    21 : arm_movk               i2, 43690, 32      
    22 : mov                    i1, 55984          
    23 : arm_movk               i1, 48874, 16      
    24 : arm_movk               i1, 43690, 32      
    25 : cmp                    i3, 1              
    26 : select_eq              i1, i2, i1         
    27 : cmp                    i3, 0              
    28 : select_eq              i1, i25, i1        
    29 : mov                    i2, 53888          
    30 : arm_movk               i2, 48874, 16      
    31 : arm_movk               i2, 43690, 32      
    32 : mov                    i25, 53920         
    33 : arm_movk               i25, 48874, 16     
    34 : arm_movk               i25, 43690, 32     
    35 : mov                    i0, 53952          
    36 : arm_movk               i0, 48874, 16      
    37 : arm_movk               i0, 43690, 32      
    38 : cmp                    i3, 1              
    39 : select_eq              i0, i25, i0        
    40 : cmp                    i3, 0              
    41 : select_eq              i0, i2, i0         
    42 : unspill                i26, 52            
    43 : call_noret             [i1](i26)          
    44 : unspill                i26, 52            
    45 : call                   [i0](i0, i26)      
    46 : mov                    i1, 53860          
    47 : arm_movk               i1, 48874, 16      
    48 : arm_movk               i1, 43690, 32      
    49 : unspill                i26, 50            
    50 : call                   [i1](i0, i26, i0)  
    51 : mov                    i26, i0            
    52 : spill                  50, i26            
    53 : unspill                i26, 52            
    54 : add                    i26, i26, 56       
    55 : spill                  52, i26            
    56 : unspill                i26, 51            
    57 : sub                    i26, i26, 1        
    58 : spill                  51, i26            
    59 : annotation:endwhile    0, 2               
    60 : unspill                i26, 50            
    61 : mov                    i0, i26            
    62 : ret                                       
    63 : arm_ldp                i29, i30, i31, 448 
    64 : unspill                i25, 53            
    65 : unspill                i26, 54            
    66 : add                    i31, i31, 464      
