sort_double(i0, i1)
     0 : sub              i31, i31, 480      
     1 : spill            55, i25            
     2 : spill            56, i26            
     3 : spill            57, i27            
     4 : arm_stp          i31, 464, i29, i30 
     5 : mov              i29, i31           
     6 : shl              i26, i1, 3         
     7 : spill            52, i26            
     8 : unspill          i26, 52            
     9 : sub              i27, i26, 8        
    10 : spill            53, i27            
    11 : mov              i26, 0             
    12 : spill            54, i26            
    13 : __loops_label_0:                    
    14 : unspill          i27, 53            
    15 : unspill          i26, 54            
    16 : cmp              i26, i27           
    17 : jmp_ge           __loops_label_2    
    18 : unspill          i26, 54            
    19 : mov              i27, i26           
    20 : spill            51, i27            
    21 : unspill          i26, 51            
    22 : add              i27, i26, 8        
    23 : spill            50, i27            
    24 : __loops_label_3:                    
    25 : unspill          i27, 52            
    26 : unspill          i26, 50            
    27 : cmp              i26, i27           
    28 : jmp_ge           __loops_label_5    
    29 : unspill          i26, 50            
    30 : load.fp64        i25, i0, i26       
    31 : unspill          i26, 51            
    32 : load.fp64        i3, i0, i26        
    33 : mov              i2, 59808          
    34 : arm_movk         i2, 44854, 16      
    35 : arm_movk         i2, 43690, 32      
    36 : arm_stp          i31, 0, i0, i1     
    37 : arm_stp          i31, 16, i2, i3    
    38 : arm_stp          i31, 32, i4, i5    
    39 : arm_stp          i31, 48, i6, i7    
    40 : arm_stp          i31, 64, i8, i9    
    41 : arm_stp          i31, 80, i10, i11  
    42 : arm_stp          i31, 96, i12, i13  
    43 : arm_stp          i31, 112, i14, i15 
    44 : arm_stp          i31, 128, i16, i17 
    45 : mov              i0, i25            
    46 : mov              i1, i3             
    47 : add              i10, i31, 144      
    48 : vst_lane.u64     i10, v0            
    49 : vst_lane.u64     i10, v4            
    50 : vst_lane.u64     i10, v8            
    51 : vst_lane.u64     i10, v12           
    52 : call_noret       [i2]()             
    53 : add              i10, i31, 144      
    54 : vld_lane.u64     v0, i10            
    55 : vld_lane.u64     v4, i10            
    56 : vld_lane.u64     v8, i10            
    57 : vld_lane.u64     v12, i10           
    58 : mov              i2, i0             
    59 : arm_ldp          i0, i1, i31, 0     
    60 : unspill          i3, 3              
    61 : arm_ldp          i4, i5, i31, 32    
    62 : arm_ldp          i6, i7, i31, 48    
    63 : arm_ldp          i8, i9, i31, 64    
    64 : arm_ldp          i10, i11, i31, 80  
    65 : arm_ldp          i12, i13, i31, 96  
    66 : arm_ldp          i14, i15, i31, 112 
    67 : arm_ldp          i16, i17, i31, 128 
    68 : cmp              i2, 0              
    69 : jmp_eq           __loops_label_7    
    70 : unspill          i26, 50            
    71 : mov              i27, i26           
    72 : spill            51, i27            
    73 : __loops_label_7:                    
    74 : unspill          i26, 50            
    75 : add              i26, i26, 8        
    76 : spill            50, i26            
    77 : jmp              3                  
    78 : __loops_label_5:                    
    79 : unspill          i27, 54            
    80 : unspill          i26, 51            
    81 : cmp              i26, i27           
    82 : jmp_eq           __loops_label_9    
    83 : unspill          i26, 54            
    84 : load.fp64        i2, i0, i26        
    85 : unspill          i26, 51            
    86 : load.fp64        i3, i0, i26        
    87 : unspill          i26, 51            
    88 : store.fp64       i0, i26, i2        
    89 : unspill          i26, 54            
    90 : store.fp64       i0, i26, i3        
    91 : __loops_label_9:                    
    92 : unspill          i26, 54            
    93 : add              i26, i26, 8        
    94 : spill            54, i26            
    95 : jmp              0                  
    96 : __loops_label_2:                    
    97 : arm_ldp          i29, i30, i31, 464 
    98 : unspill          i25, 55            
    99 : unspill          i26, 56            
   100 : unspill          i27, 57            
   101 : add              i31, i31, 480      
   102 : ret                                 
