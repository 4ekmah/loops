area_sum(i0, i1)
     0 : sub              i31, i31, 464      
     1 : spill            53, i25            
     2 : spill            54, i26            
     3 : arm_stp          i31, 448, i29, i30 
     4 : mov              i29, i31           
     5 : spill            52, i0             
     6 : spill            51, i1             
     7 : mov              i26, 0             
     8 : spill            50, i26            
     9 : __loops_label_0:                    
    10 : unspill          i26, 51            
    11 : cmp              i26, 0             
    12 : jmp_le           __loops_label_2    
    13 : unspill          i26, 52            
    14 : load.i8          i3, i26            
    15 : mov              i25, 55700         
    16 : arm_movk         i25, 48874, 16     
    17 : arm_movk         i25, 43690, 32     
    18 : mov              i2, 55472          
    19 : arm_movk         i2, 48874, 16      
    20 : arm_movk         i2, 43690, 32      
    21 : mov              i1, 55984          
    22 : arm_movk         i1, 48874, 16      
    23 : arm_movk         i1, 43690, 32      
    24 : cmp              i3, 1              
    25 : select_eq        i1, i2, i1         
    26 : cmp              i3, 0              
    27 : select_eq        i1, i25, i1        
    28 : mov              i2, 53888          
    29 : arm_movk         i2, 48874, 16      
    30 : arm_movk         i2, 43690, 32      
    31 : mov              i25, 53920         
    32 : arm_movk         i25, 48874, 16     
    33 : arm_movk         i25, 43690, 32     
    34 : mov              i0, 53952          
    35 : arm_movk         i0, 48874, 16      
    36 : arm_movk         i0, 43690, 32      
    37 : cmp              i3, 1              
    38 : select_eq        i0, i25, i0        
    39 : cmp              i3, 0              
    40 : select_eq        i0, i2, i0         
    41 : unspill          i26, 52            
    42 : arm_stp          i31, 0, i0, i1     
    43 : arm_stp          i31, 16, i2, i3    
    44 : arm_stp          i31, 32, i4, i5    
    45 : arm_stp          i31, 48, i6, i7    
    46 : arm_stp          i31, 64, i8, i9    
    47 : arm_stp          i31, 80, i10, i11  
    48 : arm_stp          i31, 96, i12, i13  
    49 : arm_stp          i31, 112, i14, i15 
    50 : arm_stp          i31, 128, i16, i17 
    51 : mov              i0, i26            
    52 : add              i10, i31, 144      
    53 : vst_lane.u64     i10, v0            
    54 : vst_lane.u64     i10, v4            
    55 : vst_lane.u64     i10, v8            
    56 : vst_lane.u64     i10, v12           
    57 : call_noret       [i1]()             
    58 : add              i10, i31, 144      
    59 : vld_lane.u64     v0, i10            
    60 : vld_lane.u64     v4, i10            
    61 : vld_lane.u64     v8, i10            
    62 : vld_lane.u64     v12, i10           
    63 : arm_ldp          i0, i1, i31, 0     
    64 : arm_ldp          i2, i3, i31, 16    
    65 : arm_ldp          i4, i5, i31, 32    
    66 : arm_ldp          i6, i7, i31, 48    
    67 : arm_ldp          i8, i9, i31, 64    
    68 : arm_ldp          i10, i11, i31, 80  
    69 : arm_ldp          i12, i13, i31, 96  
    70 : arm_ldp          i14, i15, i31, 112 
    71 : arm_ldp          i16, i17, i31, 128 
    72 : unspill          i26, 52            
    73 : arm_stp          i31, 0, i0, i1     
    74 : arm_stp          i31, 16, i2, i3    
    75 : arm_stp          i31, 32, i4, i5    
    76 : arm_stp          i31, 48, i6, i7    
    77 : arm_stp          i31, 64, i8, i9    
    78 : arm_stp          i31, 80, i10, i11  
    79 : arm_stp          i31, 96, i12, i13  
    80 : arm_stp          i31, 112, i14, i15 
    81 : arm_stp          i31, 128, i16, i17 
    82 : mov              i0, i26            
    83 : unspill          i9, 0              
    84 : add              i10, i31, 144      
    85 : vst_lane.u64     i10, v0            
    86 : vst_lane.u64     i10, v4            
    87 : vst_lane.u64     i10, v8            
    88 : vst_lane.u64     i10, v12           
    89 : call_noret       [i9]()             
    90 : add              i10, i31, 144      
    91 : vld_lane.u64     v0, i10            
    92 : vld_lane.u64     v4, i10            
    93 : vld_lane.u64     v8, i10            
    94 : vld_lane.u64     v12, i10           
    95 : unspill          i1, 1              
    96 : arm_ldp          i2, i3, i31, 16    
    97 : arm_ldp          i4, i5, i31, 32    
    98 : arm_ldp          i6, i7, i31, 48    
    99 : arm_ldp          i8, i9, i31, 64    
   100 : arm_ldp          i10, i11, i31, 80  
   101 : arm_ldp          i12, i13, i31, 96  
   102 : arm_ldp          i14, i15, i31, 112 
   103 : arm_ldp          i16, i17, i31, 128 
   104 : mov              i1, 53860          
   105 : arm_movk         i1, 48874, 16      
   106 : arm_movk         i1, 43690, 32      
   107 : unspill          i26, 50            
   108 : arm_stp          i31, 0, i0, i1     
   109 : arm_stp          i31, 16, i2, i3    
   110 : arm_stp          i31, 32, i4, i5    
   111 : arm_stp          i31, 48, i6, i7    
   112 : arm_stp          i31, 64, i8, i9    
   113 : arm_stp          i31, 80, i10, i11  
   114 : arm_stp          i31, 96, i12, i13  
   115 : arm_stp          i31, 112, i14, i15 
   116 : arm_stp          i31, 128, i16, i17 
   117 : mov              i0, i26            
   118 : unspill          i1, 0              
   119 : unspill          i9, 1              
   120 : add              i10, i31, 144      
   121 : vst_lane.u64     i10, v0            
   122 : vst_lane.u64     i10, v4            
   123 : vst_lane.u64     i10, v8            
   124 : vst_lane.u64     i10, v12           
   125 : call_noret       [i9]()             
   126 : add              i10, i31, 144      
   127 : vld_lane.u64     v0, i10            
   128 : vld_lane.u64     v4, i10            
   129 : vld_lane.u64     v8, i10            
   130 : vld_lane.u64     v12, i10           
   131 : unspill          i1, 1              
   132 : arm_ldp          i2, i3, i31, 16    
   133 : arm_ldp          i4, i5, i31, 32    
   134 : arm_ldp          i6, i7, i31, 48    
   135 : arm_ldp          i8, i9, i31, 64    
   136 : arm_ldp          i10, i11, i31, 80  
   137 : arm_ldp          i12, i13, i31, 96  
   138 : arm_ldp          i14, i15, i31, 112 
   139 : arm_ldp          i16, i17, i31, 128 
   140 : mov              i26, i0            
   141 : spill            50, i26            
   142 : unspill          i26, 52            
   143 : add              i26, i26, 56       
   144 : spill            52, i26            
   145 : unspill          i26, 51            
   146 : sub              i26, i26, 1        
   147 : spill            51, i26            
   148 : jmp              0                  
   149 : __loops_label_2:                    
   150 : unspill          i26, 50            
   151 : mov              i0, i26            
   152 : arm_ldp          i29, i30, i31, 448 
   153 : unspill          i25, 53            
   154 : unspill          i26, 54            
   155 : add              i31, i31, 464      
   156 : ret                                 
