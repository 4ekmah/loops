area_sum(i0, i1)
     0 : mov                    i2, 0               
     1 : annotation:whilecstart 0                   
     2 : cmp                    i1, 0               
     3 : jmp_le                 __loops_label_2     
     4 : annotation:whilecend                       
     5 : load.i8                i3, i0              
     6 : mov                    i4, 28776           
     7 : arm_movk               i4, 59237, 16       
     8 : arm_movk               i4, 43690, 32       
     9 : mov                    i5, 28996           
    10 : arm_movk               i5, 59237, 16       
    11 : arm_movk               i5, 43690, 32       
    12 : mov                    i6, 29156           
    13 : arm_movk               i6, 59237, 16       
    14 : arm_movk               i6, 43690, 32       
    15 : cmp                    i3, 1               
    16 : select_eq              i7, i5, i6          
    17 : cmp                    i3, 0               
    18 : select_eq              i8, i4, i7          
    19 : mov                    i9, 28500           
    20 : arm_movk               i9, 59237, 16       
    21 : arm_movk               i9, 43690, 32       
    22 : mov                    i10, 28588          
    23 : arm_movk               i10, 59237, 16      
    24 : arm_movk               i10, 43690, 32      
    25 : mov                    i11, 28644          
    26 : arm_movk               i11, 59237, 16      
    27 : arm_movk               i11, 43690, 32      
    28 : cmp                    i3, 1               
    29 : select_eq              i12, i10, i11       
    30 : cmp                    i3, 0               
    31 : select_eq              i13, i9, i12        
    32 : call_noret             [i8](i0)            
    33 : call                   [i13](i14, i0)      
    34 : mov                    i16, 28440          
    35 : arm_movk               i16, 59237, 16      
    36 : arm_movk               i16, 43690, 32      
    37 : call                   [i16](i15, i2, i14) 
    38 : mov                    i2, i15             
    39 : add                    i0, i0, 56          
    40 : sub                    i1, i1, 1           
    41 : annotation:endwhile    0, 2                
    42 : mov                    iR, i2              
    43 : ret                                        
