helloworld_call()
     0 : mov        i0, 61072     
     1 : arm_movk   i0, 44854, 16 
     2 : arm_movk   i0, 43690, 32 
     3 : call_noret [i0]()        
     4 : ret                      
