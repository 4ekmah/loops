snake(i0, i1, i2)
     0 : sub                    i31, i31, 528   
     1 : spill                  60, i25         
     2 : spill                  61, i26         
     3 : spill                  62, i27         
     4 : spill                  63, i28         
     5 : spill                  64, i29         
     6 : spill                  65, i30         
     7 : mov                    i29, i31        
     8 : add                    i3, i1, i2      
     9 : sub                    i26, i3, 1      
    10 : spill                  54, i26         
    11 : mov                    i3, 0           
    12 : mov                    i26, 1          
    13 : spill                  53, i26         
    14 : unspill                i26, 53         
    15 : neg                    i27, i26        
    16 : spill                  50, i27         
    17 : mov                    i26, 0          
    18 : spill                  55, i26         
    19 : annotation:whilecstart 0               
    20 : unspill                i27, 54         
    21 : unspill                i26, 55         
    22 : cmp                    i26, i27        
    23 : jmp_ge                 __loops_label_2 
    24 : annotation:whilecend                   
    25 : mov                    i26, 0          
    26 : spill                  51, i26         
    27 : mov                    i26, 0          
    28 : spill                  52, i26         
    29 : annotation:ifcstart                    
    30 : unspill                i26, 55         
    31 : and                    i25, i26, 1     
    32 : cmp                    i25, 0          
    33 : jmp_eq                 __loops_label_4 
    34 : annotation:ifcend                      
    35 : sub                    i25, i2, 1      
    36 : unspill                i26, 55         
    37 : cmp                    i25, i26        
    38 : unspill                i26, 55         
    39 : select_gt              i27, i25, i26   
    40 : spill                  51, i27         
    41 : unspill                i26, 55         
    42 : sub                    i27, i26, i25   
    43 : spill                  56, i27         
    44 : mov                    i26, 0          
    45 : spill                  57, i26         
    46 : unspill                i26, 55         
    47 : cmp                    i26, i25        
    48 : unspill                i26, 56         
    49 : unspill                i27, 57         
    50 : select_gt              i28, i26, i27   
    51 : spill                  52, i28         
    52 : annotation:else        4, 5            
    53 : sub                    i26, i1, 1      
    54 : spill                  58, i26         
    55 : unspill                i26, 55         
    56 : unspill                i27, 58         
    57 : sub                    i25, i26, i27   
    58 : mov                    i26, 0          
    59 : spill                  59, i26         
    60 : unspill                i26, 55         
    61 : unspill                i27, 58         
    62 : cmp                    i26, i27        
    63 : unspill                i26, 59         
    64 : select_gt              i27, i25, i26   
    65 : spill                  51, i27         
    66 : unspill                i27, 55         
    67 : unspill                i26, 58         
    68 : cmp                    i26, i27        
    69 : unspill                i27, 55         
    70 : unspill                i26, 58         
    71 : select_gt              i28, i26, i27   
    72 : spill                  52, i28         
    73 : annotation:endif       5               
    74 : annotation:whilecstart 6               
    75 : unspill                i26, 51         
    76 : cmp                    i26, 0          
    77 : jmp_gt                 __loops_label_8 
    78 : unspill                i26, 51         
    79 : cmp                    i26, i2         
    80 : jmp_ge                 __loops_label_8 
    81 : unspill                i26, 52         
    82 : cmp                    i26, 0          
    83 : jmp_gt                 __loops_label_8 
    84 : unspill                i26, 52         
    85 : cmp                    i26, i1         
    86 : jmp_ge                 __loops_label_8 
    87 : annotation:whilecend                   
    88 : mov                    i25, 61216      
    89 : arm_movk               i25, 49873, 16  
    90 : arm_movk               i25, 43690, 32  
    91 : unspill                i26, 51         
    92 : unspill                i27, 52         
    93 : call_noret             [i25](i26, i27) 
    94 : unspill                i26, 52         
    95 : mul                    i25, i26, i2    
    96 : unspill                i26, 51         
    97 : add                    i25, i25, i26   
    98 : store.u8               i0, i25, i3     
    99 : add                    i3, i3, 1       
   100 : unspill                i27, 53         
   101 : unspill                i26, 51         
   102 : add                    i26, i26, i27   
   103 : spill                  51, i26         
   104 : unspill                i27, 50         
   105 : unspill                i26, 52         
   106 : add                    i26, i26, i27   
   107 : spill                  52, i26         
   108 : annotation:endwhile    6, 8            
   109 : unspill                i26, 53         
   110 : neg                    i26, i26        
   111 : spill                  53, i26         
   112 : unspill                i26, 50         
   113 : neg                    i26, i26        
   114 : spill                  50, i26         
   115 : unspill                i26, 55         
   116 : add                    i26, i26, 1     
   117 : spill                  55, i26         
   118 : annotation:endwhile    0, 2            
   119 : ret                                    
   120 : unspill                i29, 64         
   121 : unspill                i30, 65         
   122 : unspill                i25, 60         
   123 : unspill                i26, 61         
   124 : unspill                i27, 62         
   125 : unspill                i28, 63         
   126 : add                    i31, i31, 528   
