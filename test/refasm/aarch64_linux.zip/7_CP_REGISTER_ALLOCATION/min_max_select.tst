min_max_select(i0, i1, i2, i3)
     0 : sub                    i31, i31, 80    
     1 : spill                  7, i25          
     2 : spill                  8, i26          
     3 : spill                  9, i27          
     4 : mov                    i26, 0          
     5 : spill                  6, i26          
     6 : mov                    i26, 0          
     7 : spill                  1, i26          
     8 : mov                    i26, 0          
     9 : spill                  2, i26          
    10 : load.i32               i26, i0         
    11 : spill                  3, i26          
    12 : unspill                i26, 3          
    13 : mov                    i27, i26        
    14 : spill                  4, i27          
    15 : shl                    i1, i1, 2       
    16 : spill                  5, i1           
    17 : annotation:whilecstart 0               
    18 : unspill                i27, 5          
    19 : unspill                i26, 6          
    20 : cmp                    i26, i27        
    21 : jmp_ge                 __loops_label_2 
    22 : annotation:whilecend                   
    23 : unspill                i26, 6          
    24 : load.i32               i25, i0, i26    
    25 : unspill                i26, 3          
    26 : cmp                    i25, i26        
    27 : unspill                i26, 6          
    28 : unspill                i27, 1          
    29 : select_gt              i27, i26, i27   
    30 : spill                  1, i27          
    31 : unspill                i26, 3          
    32 : cmp                    i25, i26        
    33 : unspill                i26, 3          
    34 : select_gt              i26, i25, i26   
    35 : spill                  3, i26          
    36 : unspill                i26, 4          
    37 : cmp                    i25, i26        
    38 : unspill                i26, 6          
    39 : unspill                i27, 2          
    40 : select_gt              i27, i26, i27   
    41 : spill                  2, i27          
    42 : unspill                i26, 4          
    43 : cmp                    i25, i26        
    44 : unspill                i26, 4          
    45 : select_gt              i26, i25, i26   
    46 : spill                  4, i26          
    47 : unspill                i26, 6          
    48 : add                    i26, i26, 4     
    49 : spill                  6, i26          
    50 : annotation:endwhile    0, 2            
    51 : unspill                i26, 1          
    52 : sar                    i26, i26, 2     
    53 : spill                  1, i26          
    54 : unspill                i26, 2          
    55 : sar                    i26, i26, 2     
    56 : spill                  2, i26          
    57 : unspill                i26, 1          
    58 : store.i32              i2, i26         
    59 : unspill                i26, 2          
    60 : store.i32              i3, i26         
    61 : mov                    i0, 0           
    62 : ret                                    
    63 : unspill                i25, 7          
    64 : unspill                i26, 8          
    65 : unspill                i27, 9          
    66 : add                    i31, i31, 80    
