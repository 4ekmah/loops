exp_f32(i0, i1, i2)
     0 : sub                    i31, i31, 160      
     1 : spill                  0, v8              
     2 : spill                  2, v9              
     3 : spill                  4, v10             
     4 : spill                  6, v11             
     5 : spill                  8, v12             
     6 : spill                  10, v13            
     7 : spill                  12, v14            
     8 : spill                  14, v15            
     9 : spill                  16, v16            
    10 : spill                  18, v17            
    11 : mov                    i3, 49317          
    12 : arm_movk               i3, 49840, 16      
    13 : broadcast.fp32         v0, i3             
    14 : mov                    i3, 49317          
    15 : arm_movk               i3, 17072, 16      
    16 : broadcast.fp32         v1, i3             
    17 : mov                    i3, 0              
    18 : arm_movk               i3, 16128, 16      
    19 : broadcast.fp32         v2, i3             
    20 : mov                    i3, 0              
    21 : arm_movk               i3, 16256, 16      
    22 : broadcast.fp32         v3, i3             
    23 : mov                    i3, 43579          
    24 : arm_movk               i3, 16312, 16      
    25 : broadcast.fp32         v4, i3             
    26 : mov                    i3, 32768          
    27 : arm_movk               i3, 48945, 16      
    28 : broadcast.fp32         v5, i3             
    29 : mov                    i3, 32899          
    30 : arm_movk               i3, 14686, 16      
    31 : broadcast.fp32         v6, i3             
    32 : mov                    i3, 26983          
    33 : arm_movk               i3, 14672, 16      
    34 : broadcast.fp32         v7, i3             
    35 : mov                    i3, 17358          
    36 : arm_movk               i3, 15031, 16      
    37 : broadcast.fp32         v8, i3             
    38 : mov                    i3, 35080          
    39 : arm_movk               i3, 15368, 16      
    40 : broadcast.fp32         v9, i3             
    41 : mov                    i3, 43457          
    42 : arm_movk               i3, 15658, 16      
    43 : broadcast.fp32         v10, i3            
    44 : mov                    i3, 43690          
    45 : arm_movk               i3, 15914, 16      
    46 : broadcast.fp32         v11, i3            
    47 : mov                    i3, 0              
    48 : arm_movk               i3, 16128, 16      
    49 : broadcast.fp32         v12, i3            
    50 : mov                    v13, 127           
    51 : mov                    i3, 0              
    52 : annotation:whilecstart 0                  
    53 : cmp                    i2, 0              
    54 : jmp_le                 __loops_label_2    
    55 : annotation:whilecend                      
    56 : vld.fp32               v14, i1, i3        
    57 : min.fp32               v14, v14, v1       
    58 : max.fp32               v14, v14, v0       
    59 : mov                    v15, v2            
    60 : fma.fp32               v15, v15, v14, v4  
    61 : floor.fp32_i32         v15, v15           
    62 : cast.i32_fp32          v16, v15           
    63 : mov                    v14, v14           
    64 : fma.fp32               v14, v14, v16, v5  
    65 : mov                    v14, v14           
    66 : fma.fp32               v14, v14, v16, v6  
    67 : mov                    v16, v8            
    68 : fma.fp32               v16, v16, v14, v7  
    69 : mov                    v17, v9            
    70 : fma.fp32               v17, v17, v16, v14 
    71 : mov                    v16, v10           
    72 : fma.fp32               v16, v16, v17, v14 
    73 : mov                    v17, v11           
    74 : fma.fp32               v17, v17, v16, v14 
    75 : mov                    v16, v12           
    76 : fma.fp32               v16, v16, v17, v14 
    77 : mul.fp32               v17, v14, v14      
    78 : mov                    v14, v14           
    79 : fma.fp32               v14, v14, v16, v17 
    80 : add.fp32               v14, v14, v3       
    81 : add.i32                v15, v15, v13      
    82 : sal.i32                v15, v15, 23       
    83 : mul.fp32               v14, v14, v15      
    84 : vst.fp32               i0, i3, v14        
    85 : add                    i3, i3, 16         
    86 : sub                    i2, i2, 4          
    87 : annotation:endwhile    0, 2               
    88 : ret                                       
    89 : unspill                v8, 0              
    90 : unspill                v9, 2              
    91 : unspill                v10, 4             
    92 : unspill                v11, 6             
    93 : unspill                v12, 8             
    94 : unspill                v13, 10            
    95 : unspill                v14, 12            
    96 : unspill                v15, 14            
    97 : unspill                v16, 16            
    98 : unspill                v17, 18            
    99 : add                    i31, i31, 160      
