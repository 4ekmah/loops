nonnegative_odd(i0, i1)
     0 : sub                    i31, i31, 64    
     1 : spill                  4, i25          
     2 : spill                  5, i26          
     3 : spill                  6, i27          
     4 : mov                    i26, 0          
     5 : spill                  3, i26          
     6 : mov                    i26, -4         
     7 : spill                  2, i26          
     8 : mov                    i2, 4           
     9 : mul                    i1, i1, i2      
    10 : spill                  1, i1           
    11 : annotation:whilecstart 0               
    12 : unspill                i27, 1          
    13 : unspill                i26, 3          
    14 : cmp                    i26, i27        
    15 : jmp_ge                 __loops_label_2 
    16 : annotation:whilecend                   
    17 : unspill                i26, 3          
    18 : load.i32               i25, i0, i26    
    19 : annotation:ifcstart                    
    20 : cmp                    i25, 0          
    21 : jmp_ge                 __loops_label_4 
    22 : annotation:ifcend                      
    23 : unspill                i26, 3          
    24 : add                    i26, i26, 4     
    25 : spill                  3, i26          
    26 : annotation:continue    0               
    27 : annotation:endif       4               
    28 : mov                    i3, 2           
    29 : div                    i2, i25, i3     
    30 : mul                    i2, i2, i3      
    31 : sub                    i2, i25, i2     
    32 : annotation:ifcstart                    
    33 : cmp                    i2, 0           
    34 : jmp_eq                 __loops_label_6 
    35 : annotation:ifcend                      
    36 : unspill                i26, 3          
    37 : mov                    i27, i26        
    38 : spill                  2, i27          
    39 : annotation:break       2               
    40 : annotation:endif       6               
    41 : unspill                i26, 3          
    42 : add                    i26, i26, 4     
    43 : spill                  3, i26          
    44 : annotation:endwhile    0, 2            
    45 : mov                    i0, 4           
    46 : unspill                i26, 2          
    47 : div                    i0, i26, i0     
    48 : mov                    i0, i0          
    49 : ret                                    
    50 : unspill                i25, 4          
    51 : unspill                i26, 5          
    52 : unspill                i27, 6          
    53 : add                    i31, i31, 64    
