helloworld_call()
     0 : mov        i0, -1355354480 
     1 : call_noret [i0]()          
     2 : ret                        
