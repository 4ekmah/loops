has_in_join_cascade(i0, i1, i2)
     0 : sub   sp, sp, #0x80     ; ff 03 02 d1  
     1 : str   x25, [sp, #0x68]  ; f9 37 00 f9  
     2 : str   x26, [sp, #0x70]  ; fa 3b 00 f9  
     3 : str   x27, [sp, #0x78]  ; fb 3f 00 f9  
     4 : str   x0, [sp, #0x30]   ; e0 1b 00 f9  
     5 : str   x1, [sp, #0x28]   ; e1 17 00 f9  
     6 : str   x2, [sp, #0x20]   ; e2 13 00 f9  
     7 : eor   x26, x26, x26     ; 5a 03 1a ca  
     8 : str   x26, [sp, #0]     ; fa 03 00 f9  
     9 : ldr   x26, [sp, #0x30]  ; fa 1b 40 f9  
    10 : ldr   x27, [x26, #0x10] ; 5b 0b 40 f9  
    11 : str   x27, [sp, #0x18]  ; fb 0f 00 f9  
    12 : ldr   x26, [sp, #0x30]  ; fa 1b 40 f9  
    13 : ldr   x27, [x26, #0]    ; 5b 03 40 f9  
    14 : str   x27, [sp, #0x10]  ; fb 0b 00 f9  
    15 : ldr   x26, [sp, #0x30]  ; fa 1b 40 f9  
    16 : ldr   x27, [x26, #0x08] ; 5b 07 40 f9  
    17 : str   x27, [sp, #0x08]  ; fb 07 00 f9  
    18 :       __loops_label_0:  ;              
    19 : ldr   x26, [sp, #0x18]  ; fa 0f 40 f9  
    20 : cmp   x26, #0           ; 5f 03 00 f1  
    21 : b.le  __loops_label_2   ; 8d 0a 00 54  
    22 : ldr   x26, [sp, #0x10]  ; fa 0b 40 f9  
    23 : ldrsw x27, [x26, #0]    ; 5b 03 80 b9  
    24 : str   x27, [sp, #0x58]  ; fb 2f 00 f9  
    25 : ldr   x26, [sp, #0x10]  ; fa 0b 40 f9  
    26 : add   x26, x26, #0x04   ; 5a 13 00 91  
    27 : str   x26, [sp, #0x10]  ; fa 0b 00 f9  
    28 : ldr   x26, [sp, #0x08]  ; fa 07 40 f9  
    29 : ldrsw x27, [x26, #0]    ; 5b 03 80 b9  
    30 : str   x27, [sp, #0x50]  ; fb 2b 00 f9  
    31 : ldr   x26, [sp, #0x08]  ; fa 07 40 f9  
    32 : add   x26, x26, #0x04   ; 5a 13 00 91  
    33 : str   x26, [sp, #0x08]  ; fa 07 00 f9  
    34 : ldr   x26, [sp, #0x18]  ; fa 0f 40 f9  
    35 : sub   x26, x26, #0x01   ; 5a 07 00 d1  
    36 : str   x26, [sp, #0x18]  ; fa 0f 00 f9  
    37 : ldr   x26, [sp, #0x30]  ; fa 1b 40 f9  
    38 : ldr   x27, [x26, #0x28] ; 5b 17 40 f9  
    39 : str   x27, [sp, #0x48]  ; fb 27 00 f9  
    40 : ldr   x26, [sp, #0x30]  ; fa 1b 40 f9  
    41 : ldr   x27, [x26, #0x18] ; 5b 0f 40 f9  
    42 : str   x27, [sp, #0x40]  ; fb 23 00 f9  
    43 : ldr   x26, [sp, #0x30]  ; fa 1b 40 f9  
    44 : ldr   x27, [x26, #0x20] ; 5b 13 40 f9  
    45 : str   x27, [sp, #0x38]  ; fb 1f 00 f9  
    46 :       __loops_label_3:  ;              
    47 : ldr   x26, [sp, #0x48]  ; fa 27 40 f9  
    48 : cmp   x26, #0           ; 5f 03 00 f1  
    49 : b.le  __loops_label_5   ; 0d 07 00 54  
    50 : ldr   x26, [sp, #0x40]  ; fa 23 40 f9  
    51 : ldrsw x0, [x26, #0]     ; 40 03 80 b9  
    52 : ldr   x26, [sp, #0x40]  ; fa 23 40 f9  
    53 : add   x26, x26, #0x04   ; 5a 13 00 91  
    54 : str   x26, [sp, #0x40]  ; fa 23 00 f9  
    55 : ldr   x26, [sp, #0x38]  ; fa 1f 40 f9  
    56 : ldrsw x1, [x26, #0]     ; 41 03 80 b9  
    57 : ldr   x26, [sp, #0x38]  ; fa 1f 40 f9  
    58 : add   x26, x26, #0x04   ; 5a 13 00 91  
    59 : str   x26, [sp, #0x38]  ; fa 1f 00 f9  
    60 : ldr   x26, [sp, #0x48]  ; fa 27 40 f9  
    61 : sub   x26, x26, #0x01   ; 5a 07 00 d1  
    62 : str   x26, [sp, #0x48]  ; fa 27 00 f9  
    63 : ldr   x26, [sp, #0x58]  ; fa 2f 40 f9  
    64 : cmp   x1, x26           ; 3f 00 1a eb  
    65 : b.le  __loops_label_7   ; 4d 00 00 54  
    66 : b     __loops_label_3   ; ed ff ff 17  
    67 :       __loops_label_7:  ;              
    68 : ldr   x26, [sp, #0x58]  ; fa 2f 40 f9  
    69 : cmp   x1, x26           ; 3f 00 1a eb  
    70 : b.ne  __loops_label_10  ; 61 04 00 54  
    71 : ldr   x26, [sp, #0x30]  ; fa 1b 40 f9  
    72 : ldr   x1, [x26, #0x40]  ; 41 23 40 f9  
    73 : ldr   x26, [sp, #0x30]  ; fa 1b 40 f9  
    74 : ldr   x2, [x26, #0x30]  ; 42 1b 40 f9  
    75 : ldr   x26, [sp, #0x30]  ; fa 1b 40 f9  
    76 : ldr   x27, [x26, #0x38] ; 5b 1f 40 f9  
    77 : str   x27, [sp, #0x60]  ; fb 33 00 f9  
    78 :       __loops_label_11: ;              
    79 : cmp   x1, #0            ; 3f 00 00 f1  
    80 : b.le  __loops_label_10  ; 4d 03 00 54  
    81 : ldrsw x3, [x2, #0]      ; 43 00 80 b9  
    82 : add   x2, x2, #0x04     ; 42 10 00 91  
    83 : ldr   x26, [sp, #0x60]  ; fa 33 40 f9  
    84 : ldrsw x25, [x26, #0]    ; 59 03 80 b9  
    85 : ldr   x26, [sp, #0x60]  ; fa 33 40 f9  
    86 : add   x26, x26, #0x04   ; 5a 13 00 91  
    87 : str   x26, [sp, #0x60]  ; fa 33 00 f9  
    88 : sub   x1, x1, #0x01     ; 21 04 00 d1  
    89 : ldr   x26, [sp, #0x50]  ; fa 2b 40 f9  
    90 : cmp   x3, x26           ; 7f 00 1a eb  
    91 : b.le  __loops_label_15  ; 4d 00 00 54  
    92 : b     __loops_label_11  ; f3 ff ff 17  
    93 :       __loops_label_15: ;              
    94 : ldr   x26, [sp, #0x50]  ; fa 2b 40 f9  
    95 : cmp   x3, x26           ; 7f 00 1a eb  
    96 : b.ne  __loops_label_18  ; 41 01 00 54  
    97 : ldr   x26, [sp, #0x28]  ; fa 17 40 f9  
    98 : cmp   x0, x26           ; 1f 00 1a eb  
    99 : b.ne  __loops_label_18  ; e1 00 00 54  
   100 : ldr   x26, [sp, #0x20]  ; fa 13 40 f9  
   101 : cmp   x25, x26          ; 3f 03 1a eb  
   102 : b.ne  __loops_label_18  ; 81 00 00 54  
   103 : mov   x26, #0x01        ; 3a 00 80 d2  
   104 : str   x26, [sp, #0]     ; fa 03 00 f9  
   105 : b     __loops_label_2   ; 04 00 00 14  
   106 :       __loops_label_16: ;              
   107 :       __loops_label_18: ;              
   108 : b     __loops_label_11  ; e6 ff ff 17  
   109 :       __loops_label_13: ;              
   110 :       __loops_label_8:  ;              
   111 :       __loops_label_10: ;              
   112 : b     __loops_label_3   ; c7 ff ff 17  
   113 :       __loops_label_5:  ;              
   114 : b     __loops_label_0   ; ab ff ff 17  
   115 :       __loops_label_2:  ;              
   116 : ldr   x26, [sp, #0]     ; fa 03 40 f9  
   117 : mov   x0, x26           ; e0 03 1a aa  
   118 : ldr   x25, [sp, #0x68]  ; f9 37 40 f9  
   119 : ldr   x26, [sp, #0x70]  ; fa 3b 40 f9  
   120 : ldr   x27, [sp, #0x78]  ; fb 3f 40 f9  
   121 : add   sp, sp, #0x80     ; ff 03 02 91  
   122 : ret   x30               ; c0 03 5f d6  
