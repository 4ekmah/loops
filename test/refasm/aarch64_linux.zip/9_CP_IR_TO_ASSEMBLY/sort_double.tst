sort_double(i0, i1)
     0 : sub  sp, sp, #0x1e0                                 ; ff 83 07 d1  
     1 : str  x25, [sp, #0x1b0]                              ; f9 db 00 f9  
     2 : str  x26, [sp, #0x1b8]                              ; fa df 00 f9  
     3 : str  x27, [sp, #0x1c0]                              ; fb e3 00 f9  
     4 : stp  x29, x30, [sp, #0x1d0]                         ; fd 7b 1d a9  
     5 : mov  x29, sp                                        ; fd 03 1f aa  
     6 : str  x0, [sp, #0x1a8]                               ; e0 d7 00 f9  
     7 : lsl  x26, x1, #0x03                                 ; 3a f0 7d d3  
     8 : str  x26, [sp, #0x1a0]                              ; fa d3 00 f9  
     9 : ldr  x26, [sp, #0x1a0]                              ; fa d3 40 f9  
    10 : sub  x27, x26, #0x08                                ; 5b 23 00 d1  
    11 : str  x27, [sp, #0x198]                              ; fb cf 00 f9  
    12 : eor  x26, x26, x26                                  ; 5a 03 1a ca  
    13 : str  x26, [sp, #0x190]                              ; fa cb 00 f9  
    14 :      __loops_label_0:                               ;              
    15 : ldr  x27, [sp, #0x198]                              ; fb cf 40 f9  
    16 : ldr  x26, [sp, #0x190]                              ; fa cb 40 f9  
    17 : cmp  x26, x27                                       ; 5f 03 1b eb  
    18 : b.ge __loops_label_2                                ; 6a 08 00 54  
    19 : ldr  x26, [sp, #0x190]                              ; fa cb 40 f9  
    20 : mov  x25, x26                                       ; f9 03 1a aa  
    21 : add  x3, x25, #0x08                                 ; 23 23 00 91  
    22 :      __loops_label_3:                               ;              
    23 : ldr  x26, [sp, #0x1a0]                              ; fa d3 40 f9  
    24 : cmp  x3, x26                                        ; 7f 00 1a eb  
    25 : b.ge __loops_label_5                                ; 8a 05 00 54  
    26 : ldr  x26, [sp, #0x1a8]                              ; fa d7 40 f9  
    27 : ldr  x2, [x26, x3]                                  ; 42 6b 63 f8  
    28 : ldr  x26, [sp, #0x1a8]                              ; fa d7 40 f9  
    29 : ldr  x1, [x26, x25]                                 ; 41 6b 79 f8  
    30 : mov  x0, #0xd250                                    ; 00 4a 9a d2  
    31 : movk x0, #0xbeea, lsl #16                           ; 40 dd b7 f2  
    32 : movk x0, #0xaaaa, lsl #32                           ; 40 55 d5 f2  
    33 : stp  x0, x1, [sp, #0]                               ; e0 07 00 a9  
    34 : stp  x2, x3, [sp, #0x10]                            ; e2 0f 01 a9  
    35 : stp  x4, x5, [sp, #0x20]                            ; e4 17 02 a9  
    36 : stp  x6, x7, [sp, #0x30]                            ; e6 1f 03 a9  
    37 : stp  x8, x9, [sp, #0x40]                            ; e8 27 04 a9  
    38 : stp  x10, x11, [sp, #0x50]                          ; ea 2f 05 a9  
    39 : stp  x12, x13, [sp, #0x60]                          ; ec 37 06 a9  
    40 : stp  x14, x15, [sp, #0x70]                          ; ee 3f 07 a9  
    41 : stp  x16, x17, [sp, #0x80]                          ; f0 47 08 a9  
    42 : mov  x0, x2                                         ; e0 03 02 aa  
    43 : ldr  x9, [sp, #0]                                   ; e9 03 40 f9  
    44 : add  x10, sp, #0x90                                 ; ea 43 02 91  
    45 : st1  {v0.2d, v1.2d, v2.2d, v3.2d}, [x10], #0x40     ; 40 2d 9f 4c  
    46 : st1  {v4.2d, v5.2d, v6.2d, v7.2d}, [x10], #0x40     ; 44 2d 9f 4c  
    47 : st1  {v8.2d, v9.2d, v10.2d, v11.2d}, [x10], #0x40   ; 48 2d 9f 4c  
    48 : st1  {v12.2d, v13.2d, v14.2d, v15.2d}, [x10], #0x40 ; 4c 2d 9f 4c  
    49 : blr  x9                                             ; 20 01 3f d6  
    50 : add  x10, sp, #0x90                                 ; ea 43 02 91  
    51 : ld1  {v0.2d, v1.2d, v2.2d, v3.2d}, [x10], #0x40     ; 40 2d df 4c  
    52 : ld1  {v4.2d, v5.2d, v6.2d, v7.2d}, [x10], #0x40     ; 44 2d df 4c  
    53 : ld1  {v8.2d, v9.2d, v10.2d, v11.2d}, [x10], #0x40   ; 48 2d df 4c  
    54 : ld1  {v12.2d, v13.2d, v14.2d, v15.2d}, [x10], #0x40 ; 4c 2d df 4c  
    55 : ldr  x1, [sp, #0x08]                                ; e1 07 40 f9  
    56 : ldp  x2, x3, [sp, #0x10]                            ; e2 0f 41 a9  
    57 : ldp  x4, x5, [sp, #0x20]                            ; e4 17 42 a9  
    58 : ldp  x6, x7, [sp, #0x30]                            ; e6 1f 43 a9  
    59 : ldp  x8, x9, [sp, #0x40]                            ; e8 27 44 a9  
    60 : ldp  x10, x11, [sp, #0x50]                          ; ea 2f 45 a9  
    61 : ldp  x12, x13, [sp, #0x60]                          ; ec 37 46 a9  
    62 : ldp  x14, x15, [sp, #0x70]                          ; ee 3f 47 a9  
    63 : ldp  x16, x17, [sp, #0x80]                          ; f0 47 48 a9  
    64 : cmp  x0, #0                                         ; 1f 00 00 f1  
    65 : b.eq __loops_label_7                                ; 40 00 00 54  
    66 : mov  x25, x3                                        ; f9 03 03 aa  
    67 :      __loops_label_7:                               ;              
    68 : add  x3, x3, #0x08                                  ; 63 20 00 91  
    69 : b    __loops_label_3                                ; d3 ff ff 17  
    70 :      __loops_label_5:                               ;              
    71 : ldr  x26, [sp, #0x190]                              ; fa cb 40 f9  
    72 : cmp  x25, x26                                       ; 3f 03 1a eb  
    73 : b.eq __loops_label_9                                ; 60 01 00 54  
    74 : ldr  x26, [sp, #0x1a8]                              ; fa d7 40 f9  
    75 : ldr  x27, [sp, #0x190]                              ; fb cb 40 f9  
    76 : ldr  x0, [x26, x27]                                 ; 40 6b 7b f8  
    77 : ldr  x26, [sp, #0x1a8]                              ; fa d7 40 f9  
    78 : ldr  x1, [x26, x25]                                 ; 41 6b 79 f8  
    79 : ldr  x26, [sp, #0x1a8]                              ; fa d7 40 f9  
    80 : str  x0, [x26, x25]                                 ; 40 6b 39 f8  
    81 : ldr  x26, [sp, #0x1a8]                              ; fa d7 40 f9  
    82 : ldr  x27, [sp, #0x190]                              ; fb cb 40 f9  
    83 : str  x1, [x26, x27]                                 ; 41 6b 3b f8  
    84 :      __loops_label_9:                               ;              
    85 : ldr  x26, [sp, #0x190]                              ; fa cb 40 f9  
    86 : add  x26, x26, #0x08                                ; 5a 23 00 91  
    87 : str  x26, [sp, #0x190]                              ; fa cb 00 f9  
    88 : b    __loops_label_0                                ; bb ff ff 17  
    89 :      __loops_label_2:                               ;              
    90 : ldp  x29, x30, [sp, #0x1d0]                         ; fd 7b 5d a9  
    91 : ldr  x25, [sp, #0x1b0]                              ; f9 db 40 f9  
    92 : ldr  x26, [sp, #0x1b8]                              ; fa df 40 f9  
    93 : ldr  x27, [sp, #0x1c0]                              ; fb e3 40 f9  
    94 : add  sp, sp, #0x1e0                                 ; ff 83 07 91  
    95 : ret  x30                                            ; c0 03 5f d6  
