fixed_power_v_float_4(i0, i1, i2)
     0 : sub  sp, sp, #0x10       ; ff 43 00 d1  
     1 : str  x25, [sp, #0]       ; f9 03 00 f9  
     2 : eor  x3, x3, x3          ; 63 00 03 ca  
     3 : mov  x25, #0x04          ; 99 00 80 d2  
     4 : mul  x2, x2, x25         ; 42 7c 19 9b  
     5 :      __loops_label_0:    ;              
     6 : cmp  x3, x2              ; 7f 00 02 eb  
     7 : b.ge __loops_label_2     ; ea 00 00 54  
     8 : ldr  q0, [x0, x3]        ; 00 68 e3 3c  
     9 : fmul v0.4s, v0.4s, v0.4s ; 00 dc 20 6e  
    10 : fmul v0.4s, v0.4s, v0.4s ; 00 dc 20 6e  
    11 : str  q0, [x1, x3]        ; 20 68 a3 3c  
    12 : add  x3, x3, #0x10       ; 63 40 00 91  
    13 : b    __loops_label_0     ; f9 ff ff 17  
    14 :      __loops_label_2:    ;              
    15 : eor  x0, x0, x0          ; 00 00 00 ca  
    16 : ldr  x25, [sp, #0]       ; f9 03 40 f9  
    17 : add  sp, sp, #0x10       ; ff 43 00 91  
    18 : ret  x30                 ; c0 03 5f d6  
