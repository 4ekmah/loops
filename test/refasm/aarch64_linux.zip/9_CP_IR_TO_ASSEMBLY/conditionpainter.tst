conditionpainter(i0)
     0 : sub  sp, sp, #0x40    ; ff 03 01 d1  
     1 : str  x0, [sp, #0x08]  ; e0 07 00 f9  
     2 : str  x25, [sp, #0x28] ; f9 17 00 f9  
     3 : str  x26, [sp, #0x30] ; fa 1b 00 f9  
     4 : movn x26, #0x04       ; 9a 00 80 92  
     5 : str  x26, [sp, #0]    ; fa 03 00 f9  
     6 :      __loops_label_0: ;              
     7 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
     8 : cmp  x26, #0x05       ; 5f 17 00 f1  
     9 : b.gt __loops_label_2  ; 8c 10 00 54  
    10 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
    11 : add  x2, x26, #0x05   ; 42 17 00 91  
    12 : mov  x3, #0x0b        ; 63 01 80 d2  
    13 : mul  x2, x2, x3       ; 42 7c 03 9b  
    14 : mov  x3, #0x08        ; 03 01 80 d2  
    15 : mul  x26, x2, x3      ; 5a 7c 03 9b  
    16 : str  x26, [sp, #0x18] ; fa 0f 00 f9  
    17 : movn x26, #0x04       ; 9a 00 80 92  
    18 : str  x26, [sp, #0x10] ; fa 0b 00 f9  
    19 :      __loops_label_3: ;              
    20 : ldr  x26, [sp, #0x10] ; fa 0b 40 f9  
    21 : cmp  x26, #0x05       ; 5f 17 00 f1  
    22 : b.gt __loops_label_5  ; 8c 0e 00 54  
    23 : ldr  x26, [sp, #0x10] ; fa 0b 40 f9  
    24 : add  x25, x26, #0x03  ; 59 0f 00 91  
    25 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
    26 : cmp  x26, x25         ; 5f 03 19 eb  
    27 : cset x25, ge          ; f9 b7 9f 9a  
    28 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
    29 : cmp  x26, #0x04       ; 5f 13 00 f1  
    30 : cset x1, le           ; e1 c7 9f 9a  
    31 : and  x1, x25, x1      ; 21 03 01 8a  
    32 : movn x25, #0x01       ; 39 00 80 92  
    33 : ldr  x26, [sp, #0x10] ; fa 0b 40 f9  
    34 : cmp  x26, x25         ; 5f 03 19 eb  
    35 : cset x25, ge          ; f9 b7 9f 9a  
    36 : and  x1, x1, x25      ; 21 00 19 8a  
    37 : ldr  x26, [sp, #0x10] ; fa 0b 40 f9  
    38 : cmp  x26, #0          ; 5f 03 00 f1  
    39 : cset x25, le          ; f9 c7 9f 9a  
    40 : and  x1, x1, x25      ; 21 00 19 8a  
    41 : ldr  x26, [sp, #0x10] ; fa 0b 40 f9  
    42 : sub  x25, x26, #0x01  ; 59 07 00 d1  
    43 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
    44 : cmp  x26, x25         ; 5f 03 19 eb  
    45 : cset x25, le          ; f9 c7 9f 9a  
    46 : ldr  x26, [sp, #0x10] ; fa 0b 40 f9  
    47 : cmp  x26, #0          ; 5f 03 00 f1  
    48 : cset x0, ge           ; e0 b7 9f 9a  
    49 : and  x0, x25, x0      ; 20 03 00 8a  
    50 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
    51 : cmp  x26, #0          ; 5f 03 00 f1  
    52 : cset x25, le          ; f9 c7 9f 9a  
    53 : and  x0, x0, x25      ; 00 00 19 8a  
    54 : ldr  x26, [sp, #0x10] ; fa 0b 40 f9  
    55 : mul  x25, x26, x26    ; 59 7f 1a 9b  
    56 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
    57 : mul  x3, x26, x26     ; 43 7f 1a 9b  
    58 : add  x3, x25, x3      ; 23 03 03 8b  
    59 : cmp  x3, #0x09        ; 7f 24 00 f1  
    60 : cset x3, le           ; e3 c7 9f 9a  
    61 : and  x0, x0, x3       ; 00 00 03 8a  
    62 : orr  x26, x1, x0      ; 3a 00 00 aa  
    63 : str  x26, [sp, #0x20] ; fa 13 00 f9  
    64 : mov  x1, #0x02        ; 41 00 80 d2  
    65 : eor  x3, x3, x3       ; 63 00 03 ca  
    66 : ldr  x26, [sp, #0x10] ; fa 0b 40 f9  
    67 : cmp  x26, #0x02       ; 5f 0b 00 f1  
    68 : cset x25, ge          ; f9 b7 9f 9a  
    69 : ldr  x26, [sp, #0x10] ; fa 0b 40 f9  
    70 : cmp  x26, #0x04       ; 5f 13 00 f1  
    71 : cset x2, le           ; e2 c7 9f 9a  
    72 : and  x2, x25, x2      ; 22 03 02 8a  
    73 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
    74 : cmp  x26, #0x01       ; 5f 07 00 f1  
    75 : cset x25, ge          ; f9 b7 9f 9a  
    76 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
    77 : cmp  x26, #0x03       ; 5f 0f 00 f1  
    78 : cset x0, le           ; e0 c7 9f 9a  
    79 : and  x0, x25, x0      ; 20 03 00 8a  
    80 : orr  x0, x2, x0       ; 40 00 00 aa  
    81 : ldr  x26, [sp, #0x10] ; fa 0b 40 f9  
    82 : mul  x2, x26, x26     ; 42 7f 1a 9b  
    83 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
    84 : mul  x25, x26, x26    ; 59 7f 1a 9b  
    85 : add  x2, x2, x25      ; 42 00 19 8b  
    86 : cmp  x2, #0x10        ; 5f 40 00 f1  
    87 : cset x2, le           ; e2 c7 9f 9a  
    88 : and  x0, x0, x2       ; 00 00 02 8a  
    89 : cmp  x0, #0           ; 1f 00 00 f1  
    90 : csel x0, x1, x3, ne   ; 20 10 83 9a  
    91 : ldr  x26, [sp, #0x20] ; fa 13 40 f9  
    92 : add  x0, x26, x0      ; 40 03 00 8b  
    93 : mov  x1, #0x02        ; 41 00 80 d2  
    94 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
    95 : mul  x1, x26, x1      ; 41 7f 01 9b  
    96 : ldr  x26, [sp, #0x10] ; fa 0b 40 f9  
    97 : cmp  x1, x26          ; 3f 00 1a eb  
    98 : b.lt __loops_label_8  ; 4b 01 00 54  
    99 : ldr  x26, [sp, #0x10] ; fa 0b 40 f9  
   100 : add  x1, x26, #0x03   ; 41 0f 00 91  
   101 : neg  x1, x1           ; e1 03 01 cb  
   102 : ldr  x26, [sp, #0x10] ; fa 0b 40 f9  
   103 : add  x2, x26, #0x03   ; 42 0f 00 91  
   104 : mul  x1, x1, x2       ; 21 7c 02 9b  
   105 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
   106 : cmp  x26, x1          ; 5f 03 01 eb  
   107 : b.le __loops_label_9  ; 0d 02 00 54  
   108 :      __loops_label_8: ;              
   109 : mov  x1, #0x02        ; 41 00 80 d2  
   110 : ldr  x26, [sp, #0x10] ; fa 0b 40 f9  
   111 : mul  x1, x26, x1      ; 41 7f 01 9b  
   112 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
   113 : cmp  x26, x1          ; 5f 03 01 eb  
   114 : b.gt __loops_label_7  ; cc 01 00 54  
   115 : ldr  x26, [sp, #0x10] ; fa 0b 40 f9  
   116 : add  x1, x26, #0x03   ; 41 0f 00 91  
   117 : neg  x1, x1           ; e1 03 01 cb  
   118 : ldr  x26, [sp, #0x10] ; fa 0b 40 f9  
   119 : add  x2, x26, #0x03   ; 42 0f 00 91  
   120 : mul  x1, x1, x2       ; 21 7c 02 9b  
   121 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
   122 : cmp  x26, x1          ; 5f 03 01 eb  
   123 : b.lt __loops_label_7  ; ab 00 00 54  
   124 :      __loops_label_9: ;              
   125 : ldr  x26, [sp, #0x10] ; fa 0b 40 f9  
   126 : cmp  x26, #0          ; 5f 03 00 f1  
   127 : b.gt __loops_label_7  ; 4c 00 00 54  
   128 : add  x0, x0, #0x03    ; 00 0c 00 91  
   129 :      __loops_label_7: ;              
   130 : ldr  x26, [sp, #0x10] ; fa 0b 40 f9  
   131 : add  x1, x26, #0x05   ; 41 17 00 91  
   132 : lsl  x1, x1, #0x03    ; 21 f0 7d d3  
   133 : ldr  x26, [sp, #0x18] ; fa 0f 40 f9  
   134 : add  x1, x26, x1      ; 41 03 01 8b  
   135 : ldr  x26, [sp, #0x08] ; fa 07 40 f9  
   136 : str  x0, [x26, x1]    ; 40 6b 21 f8  
   137 : ldr  x26, [sp, #0x10] ; fa 0b 40 f9  
   138 : add  x26, x26, #0x01  ; 5a 07 00 91  
   139 : str  x26, [sp, #0x10] ; fa 0b 00 f9  
   140 : b    __loops_label_3  ; 8b ff ff 17  
   141 :      __loops_label_5: ;              
   142 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
   143 : add  x26, x26, #0x01  ; 5a 07 00 91  
   144 : str  x26, [sp, #0]    ; fa 03 00 f9  
   145 : b    __loops_label_0  ; 7b ff ff 17  
   146 :      __loops_label_2: ;              
   147 : ldr  x25, [sp, #0x28] ; f9 17 40 f9  
   148 : ldr  x26, [sp, #0x30] ; fa 1b 40 f9  
   149 : add  sp, sp, #0x40    ; ff 03 01 91  
   150 : ret  x30              ; c0 03 5f d6  
