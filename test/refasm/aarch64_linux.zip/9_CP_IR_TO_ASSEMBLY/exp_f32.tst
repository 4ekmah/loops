exp_f32(i0, i1, i2)
     0 : sub    sp, sp, #0xb0          ; ff c3 02 d1  
     1 : str    q8, [sp, #0x10]        ; e8 07 80 3d  
     2 : str    q9, [sp, #0x20]        ; e9 0b 80 3d  
     3 : str    q10, [sp, #0x30]       ; ea 0f 80 3d  
     4 : str    q11, [sp, #0x40]       ; eb 13 80 3d  
     5 : str    q12, [sp, #0x50]       ; ec 17 80 3d  
     6 : str    q13, [sp, #0x60]       ; ed 1b 80 3d  
     7 : str    q14, [sp, #0x70]       ; ee 1f 80 3d  
     8 : str    q15, [sp, #0x80]       ; ef 23 80 3d  
     9 : str    q16, [sp, #0x90]       ; f0 27 80 3d  
    10 : str    q17, [sp, #0xa0]       ; f1 2b 80 3d  
    11 : mov    x3, #0xc0a5            ; a3 14 98 d2  
    12 : movk   x3, #0xc2b0, lsl #16   ; 03 56 b8 f2  
    13 : dup    v0.4s, w3              ; 60 0c 04 4e  
    14 : mov    x3, #0xc0a5            ; a3 14 98 d2  
    15 : movk   x3, #0x42b0, lsl #16   ; 03 56 a8 f2  
    16 : dup    v1.4s, w3              ; 61 0c 04 4e  
    17 : eor    x3, x3, x3             ; 63 00 03 ca  
    18 : movk   x3, #0x3f00, lsl #16   ; 03 e0 a7 f2  
    19 : dup    v2.4s, w3              ; 62 0c 04 4e  
    20 : eor    x3, x3, x3             ; 63 00 03 ca  
    21 : movk   x3, #0x3f80, lsl #16   ; 03 f0 a7 f2  
    22 : dup    v3.4s, w3              ; 63 0c 04 4e  
    23 : mov    x3, #0xaa3b            ; 63 47 95 d2  
    24 : movk   x3, #0x3fb8, lsl #16   ; 03 f7 a7 f2  
    25 : dup    v4.4s, w3              ; 64 0c 04 4e  
    26 : mov    x3, #0x8000            ; 03 00 90 d2  
    27 : movk   x3, #0xbf31, lsl #16   ; 23 e6 b7 f2  
    28 : dup    v5.4s, w3              ; 65 0c 04 4e  
    29 : mov    x3, #0x8083            ; 63 10 90 d2  
    30 : movk   x3, #0x395e, lsl #16   ; c3 2b a7 f2  
    31 : dup    v6.4s, w3              ; 66 0c 04 4e  
    32 : mov    x3, #0x6967            ; e3 2c 8d d2  
    33 : movk   x3, #0x3950, lsl #16   ; 03 2a a7 f2  
    34 : dup    v7.4s, w3              ; 67 0c 04 4e  
    35 : mov    x3, #0x43ce            ; c3 79 88 d2  
    36 : movk   x3, #0x3ab7, lsl #16   ; e3 56 a7 f2  
    37 : dup    v8.4s, w3              ; 68 0c 04 4e  
    38 : mov    x3, #0x8908            ; 03 21 91 d2  
    39 : movk   x3, #0x3c08, lsl #16   ; 03 81 a7 f2  
    40 : dup    v9.4s, w3              ; 69 0c 04 4e  
    41 : mov    x3, #0xa9c1            ; 23 38 95 d2  
    42 : movk   x3, #0x3d2a, lsl #16   ; 43 a5 a7 f2  
    43 : dup    v10.4s, w3             ; 6a 0c 04 4e  
    44 : mov    x3, #0xaaaa            ; 43 55 95 d2  
    45 : movk   x3, #0x3e2a, lsl #16   ; 43 c5 a7 f2  
    46 : dup    v11.4s, w3             ; 6b 0c 04 4e  
    47 : eor    x3, x3, x3             ; 63 00 03 ca  
    48 : movk   x3, #0x3f00, lsl #16   ; 03 e0 a7 f2  
    49 : dup    v12.4s, w3             ; 6c 0c 04 4e  
    50 : movi   v13.4s, #0x7f          ; ed 07 03 4f  
    51 : eor    x3, x3, x3             ; 63 00 03 ca  
    52 :        __loops_label_0:       ;              
    53 : cmp    x2, #0                 ; 5f 00 00 f1  
    54 : b.le   __loops_label_2        ; 4d 05 00 54  
    55 : ldr    q14, [x1, x3]          ; 2e 68 e3 3c  
    56 : fmin   v14.4s, v14.4s, v1.4s  ; ce f5 a1 4e  
    57 : fmax   v14.4s, v14.4s, v0.4s  ; ce f5 20 4e  
    58 : mov    v15.4s, v2.4s          ; 4f 1c a2 4e  
    59 : fmla   v15.4s, v14.4s, v4.4s  ; cf cd 24 4e  
    60 : fcvtms v15.4s, v15.4s         ; ef b9 21 4e  
    61 : scvtf  v16.4s, v15.4s         ; f0 d9 21 4e  
    62 : fmla   v14.4s, v16.4s, v5.4s  ; 0e ce 25 4e  
    63 : fmla   v14.4s, v16.4s, v6.4s  ; 0e ce 26 4e  
    64 : mov    v16.4s, v8.4s          ; 10 1d a8 4e  
    65 : fmla   v16.4s, v14.4s, v7.4s  ; d0 cd 27 4e  
    66 : str    q0, [sp, #0]           ; e0 03 80 3d  
    67 : mov    v0.4s, v16.4s          ; 00 1e b0 4e  
    68 : mov    v16.4s, v9.4s          ; 30 1d a9 4e  
    69 : fmla   v16.4s, v0.4s, v14.4s  ; 10 cc 2e 4e  
    70 : ldr    q0, [sp, #0]           ; e0 03 c0 3d  
    71 : str    q0, [sp, #0]           ; e0 03 80 3d  
    72 : mov    v0.4s, v16.4s          ; 00 1e b0 4e  
    73 : mov    v16.4s, v10.4s         ; 50 1d aa 4e  
    74 : fmla   v16.4s, v0.4s, v14.4s  ; 10 cc 2e 4e  
    75 : ldr    q0, [sp, #0]           ; e0 03 c0 3d  
    76 : str    q0, [sp, #0]           ; e0 03 80 3d  
    77 : mov    v0.4s, v16.4s          ; 00 1e b0 4e  
    78 : mov    v16.4s, v11.4s         ; 70 1d ab 4e  
    79 : fmla   v16.4s, v0.4s, v14.4s  ; 10 cc 2e 4e  
    80 : ldr    q0, [sp, #0]           ; e0 03 c0 3d  
    81 : str    q0, [sp, #0]           ; e0 03 80 3d  
    82 : mov    v0.4s, v16.4s          ; 00 1e b0 4e  
    83 : mov    v16.4s, v12.4s         ; 90 1d ac 4e  
    84 : fmla   v16.4s, v0.4s, v14.4s  ; 10 cc 2e 4e  
    85 : ldr    q0, [sp, #0]           ; e0 03 c0 3d  
    86 : fmul   v17.4s, v14.4s, v14.4s ; d1 dd 2e 6e  
    87 : fmla   v14.4s, v16.4s, v17.4s ; 0e ce 31 4e  
    88 : fadd   v14.4s, v14.4s, v3.4s  ; ce d5 23 4e  
    89 : add    v15.4s, v15.4s, v13.4s ; ef 85 ad 4e  
    90 : shl    v15.4s, v15.4s, #0x17  ; ef 55 37 4f  
    91 : fmul   v14.4s, v14.4s, v15.4s ; ce dd 2f 6e  
    92 : str    q14, [x0, x3]          ; 0e 68 a3 3c  
    93 : add    x3, x3, #0x10          ; 63 40 00 91  
    94 : sub    x2, x2, #0x04          ; 42 10 00 d1  
    95 : b      __loops_label_0        ; d6 ff ff 17  
    96 :        __loops_label_2:       ;              
    97 : ldr    q8, [sp, #0x10]        ; e8 07 c0 3d  
    98 : ldr    q9, [sp, #0x20]        ; e9 0b c0 3d  
    99 : ldr    q10, [sp, #0x30]       ; ea 0f c0 3d  
   100 : ldr    q11, [sp, #0x40]       ; eb 13 c0 3d  
   101 : ldr    q12, [sp, #0x50]       ; ec 17 c0 3d  
   102 : ldr    q13, [sp, #0x60]       ; ed 1b c0 3d  
   103 : ldr    q14, [sp, #0x70]       ; ee 1f c0 3d  
   104 : ldr    q15, [sp, #0x80]       ; ef 23 c0 3d  
   105 : ldr    q16, [sp, #0x90]       ; f0 27 c0 3d  
   106 : ldr    q17, [sp, #0xa0]       ; f1 2b c0 3d  
   107 : add    sp, sp, #0xb0          ; ff c3 02 91  
   108 : ret    x30                    ; c0 03 5f d6  
