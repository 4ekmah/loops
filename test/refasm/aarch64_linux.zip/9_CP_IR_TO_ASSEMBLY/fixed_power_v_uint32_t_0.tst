fixed_power_v_uint32_t_0(i0, i1, i2)
     0 : sub  sp, sp, #0x10    ; ff 43 00 d1  
     1 : str  x25, [sp, #0]    ; f9 03 00 f9  
     2 : eor  x3, x3, x3       ; 63 00 03 ca  
     3 : mov  x25, #0x04       ; 99 00 80 d2  
     4 : mul  x2, x2, x25      ; 42 7c 19 9b  
     5 :      __loops_label_0: ;              
     6 : cmp  x3, x2           ; 7f 00 02 eb  
     7 : b.ge __loops_label_2  ; ca 00 00 54  
     8 : ldr  q0, [x0, x3]     ; 00 68 e3 3c  
     9 : movi v0.4s, #0x01     ; 20 04 00 4f  
    10 : str  q0, [x1, x3]     ; 20 68 a3 3c  
    11 : add  x3, x3, #0x10    ; 63 40 00 91  
    12 : b    __loops_label_0  ; fa ff ff 17  
    13 :      __loops_label_2: ;              
    14 : eor  x0, x0, x0       ; 00 00 00 ca  
    15 : ldr  x25, [sp, #0]    ; f9 03 40 f9  
    16 : add  sp, sp, #0x10    ; ff 43 00 91  
    17 : ret  x30              ; c0 03 5f d6  
