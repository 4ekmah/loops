all_loads_all_stores(i0, i1, i2, i3, i4)
     0 : sub   sp, sp, #0x40     ; ff 03 01 d1  
     1 : str   x4, [sp, #0x18]   ; e4 0f 00 f9  
     2 : str   x25, [sp, #0x28]  ; f9 17 00 f9  
     3 : str   x26, [sp, #0x30]  ; fa 1b 00 f9  
     4 : str   x27, [sp, #0x38]  ; fb 1f 00 f9  
     5 : eor   x26, x26, x26     ; 5a 03 1a ca  
     6 : str   x26, [sp, #0x10]  ; fa 0b 00 f9  
     7 : eor   x26, x26, x26     ; 5a 03 1a ca  
     8 : str   x26, [sp, #0]     ; fa 03 00 f9  
     9 : eor   x26, x26, x26     ; 5a 03 1a ca  
    10 : str   x26, [sp, #0x08]  ; fa 07 00 f9  
    11 : mov   x25, #0x02        ; 59 00 80 d2  
    12 : mov   x4, #0x01         ; 24 00 80 d2  
    13 : cmp   x1, #0x01         ; 3f 04 00 f1  
    14 : csel  x4, x25, x4, gt   ; 24 c3 84 9a  
    15 : mov   x25, #0x04        ; 99 00 80 d2  
    16 : cmp   x1, #0x03         ; 3f 0c 00 f1  
    17 : csel  x4, x25, x4, gt   ; 24 c3 84 9a  
    18 : mov   x25, #0x08        ; 19 01 80 d2  
    19 : cmp   x1, #0x05         ; 3f 14 00 f1  
    20 : csel  x26, x25, x4, gt  ; 3a c3 84 9a  
    21 : str   x26, [sp, #0x20]  ; fa 13 00 f9  
    22 : mov   x25, #0x02        ; 59 00 80 d2  
    23 : mov   x4, #0x01         ; 24 00 80 d2  
    24 : cmp   x3, #0x01         ; 7f 04 00 f1  
    25 : csel  x4, x25, x4, gt   ; 24 c3 84 9a  
    26 : mov   x25, #0x04        ; 99 00 80 d2  
    27 : cmp   x3, #0x03         ; 7f 0c 00 f1  
    28 : csel  x4, x25, x4, gt   ; 24 c3 84 9a  
    29 : mov   x25, #0x08        ; 19 01 80 d2  
    30 : cmp   x3, #0x05         ; 7f 14 00 f1  
    31 : csel  x4, x25, x4, gt   ; 24 c3 84 9a  
    32 :       __loops_label_0:  ;              
    33 : ldr   x27, [sp, #0x18]  ; fb 0f 40 f9  
    34 : ldr   x26, [sp, #0x10]  ; fa 0b 40 f9  
    35 : cmp   x26, x27          ; 5f 03 1b eb  
    36 : b.ge  __loops_label_2   ; ca 0a 00 54  
    37 : cmp   x1, #0            ; 3f 00 00 f1  
    38 : b.ne  __loops_label_4   ; 81 00 00 54  
    39 : ldr   x26, [sp, #0]     ; fa 03 40 f9  
    40 : ldrb  w25, [x0, x26]    ; 19 68 7a 38  
    41 : b     __loops_label_23  ; 21 00 00 14  
    42 :       __loops_label_4:  ;              
    43 : cmp   x1, #0x01         ; 3f 04 00 f1  
    44 : b.ne  __loops_label_7   ; 81 00 00 54  
    45 : ldr   x26, [sp, #0]     ; fa 03 40 f9  
    46 : ldrsb x25, [x0, x26]    ; 19 68 ba 38  
    47 : b     __loops_label_23  ; 1c 00 00 14  
    48 :       __loops_label_7:  ;              
    49 : cmp   x1, #0x02         ; 3f 08 00 f1  
    50 : b.ne  __loops_label_10  ; 81 00 00 54  
    51 : ldr   x26, [sp, #0]     ; fa 03 40 f9  
    52 : ldrh  w25, [x0, x26]    ; 19 68 7a 78  
    53 : b     __loops_label_23  ; 17 00 00 14  
    54 :       __loops_label_10: ;              
    55 : cmp   x1, #0x03         ; 3f 0c 00 f1  
    56 : b.ne  __loops_label_13  ; 81 00 00 54  
    57 : ldr   x26, [sp, #0]     ; fa 03 40 f9  
    58 : ldrsh x25, [x0, x26]    ; 19 68 ba 78  
    59 : b     __loops_label_23  ; 12 00 00 14  
    60 :       __loops_label_13: ;              
    61 : cmp   x1, #0x04         ; 3f 10 00 f1  
    62 : b.ne  __loops_label_16  ; 81 00 00 54  
    63 : ldr   x26, [sp, #0]     ; fa 03 40 f9  
    64 : ldr   w25, [x0, x26]    ; 19 68 7a b8  
    65 : b     __loops_label_23  ; 0d 00 00 14  
    66 :       __loops_label_16: ;              
    67 : cmp   x1, #0x05         ; 3f 14 00 f1  
    68 : b.ne  __loops_label_19  ; 81 00 00 54  
    69 : ldr   x26, [sp, #0]     ; fa 03 40 f9  
    70 : ldrsw x25, [x0, x26]    ; 19 68 ba b8  
    71 : b     __loops_label_23  ; 08 00 00 14  
    72 :       __loops_label_19: ;              
    73 : cmp   x1, #0x06         ; 3f 18 00 f1  
    74 : b.ne  __loops_label_22  ; 81 00 00 54  
    75 : ldr   x26, [sp, #0]     ; fa 03 40 f9  
    76 : ldr   x25, [x0, x26]    ; 19 68 7a f8  
    77 : b     __loops_label_23  ; 03 00 00 14  
    78 :       __loops_label_22: ;              
    79 : ldr   x26, [sp, #0]     ; fa 03 40 f9  
    80 : ldr   x25, [x0, x26]    ; 19 68 7a f8  
    81 :       __loops_label_5:  ;              
    82 :       __loops_label_8:  ;              
    83 :       __loops_label_11: ;              
    84 :       __loops_label_14: ;              
    85 :       __loops_label_17: ;              
    86 :       __loops_label_20: ;              
    87 :       __loops_label_23: ;              
    88 : cmp   x3, #0            ; 7f 00 00 f1  
    89 : b.ne  __loops_label_25  ; 81 00 00 54  
    90 : ldr   x26, [sp, #0x08]  ; fa 07 40 f9  
    91 : strb  w25, [x2, x26]    ; 59 68 3a 38  
    92 : b     __loops_label_44  ; 21 00 00 14  
    93 :       __loops_label_25: ;              
    94 : cmp   x3, #0x01         ; 7f 04 00 f1  
    95 : b.ne  __loops_label_28  ; 81 00 00 54  
    96 : ldr   x26, [sp, #0x08]  ; fa 07 40 f9  
    97 : strb  w25, [x2, x26]    ; 59 68 3a 38  
    98 : b     __loops_label_44  ; 1c 00 00 14  
    99 :       __loops_label_28: ;              
   100 : cmp   x3, #0x02         ; 7f 08 00 f1  
   101 : b.ne  __loops_label_31  ; 81 00 00 54  
   102 : ldr   x26, [sp, #0x08]  ; fa 07 40 f9  
   103 : strh  w25, [x2, x26]    ; 59 68 3a 78  
   104 : b     __loops_label_44  ; 17 00 00 14  
   105 :       __loops_label_31: ;              
   106 : cmp   x3, #0x03         ; 7f 0c 00 f1  
   107 : b.ne  __loops_label_34  ; 81 00 00 54  
   108 : ldr   x26, [sp, #0x08]  ; fa 07 40 f9  
   109 : strh  w25, [x2, x26]    ; 59 68 3a 78  
   110 : b     __loops_label_44  ; 12 00 00 14  
   111 :       __loops_label_34: ;              
   112 : cmp   x3, #0x04         ; 7f 10 00 f1  
   113 : b.ne  __loops_label_37  ; 81 00 00 54  
   114 : ldr   x26, [sp, #0x08]  ; fa 07 40 f9  
   115 : str   w25, [x2, x26]    ; 59 68 3a b8  
   116 : b     __loops_label_44  ; 0d 00 00 14  
   117 :       __loops_label_37: ;              
   118 : cmp   x3, #0x05         ; 7f 14 00 f1  
   119 : b.ne  __loops_label_40  ; 81 00 00 54  
   120 : ldr   x26, [sp, #0x08]  ; fa 07 40 f9  
   121 : str   w25, [x2, x26]    ; 59 68 3a b8  
   122 : b     __loops_label_44  ; 08 00 00 14  
   123 :       __loops_label_40: ;              
   124 : cmp   x3, #0x06         ; 7f 18 00 f1  
   125 : b.ne  __loops_label_43  ; 81 00 00 54  
   126 : ldr   x26, [sp, #0x08]  ; fa 07 40 f9  
   127 : str   x25, [x2, x26]    ; 59 68 3a f8  
   128 : b     __loops_label_44  ; 03 00 00 14  
   129 :       __loops_label_43: ;              
   130 : ldr   x26, [sp, #0x08]  ; fa 07 40 f9  
   131 : str   x25, [x2, x26]    ; 59 68 3a f8  
   132 :       __loops_label_26: ;              
   133 :       __loops_label_29: ;              
   134 :       __loops_label_32: ;              
   135 :       __loops_label_35: ;              
   136 :       __loops_label_38: ;              
   137 :       __loops_label_41: ;              
   138 :       __loops_label_44: ;              
   139 : ldr   x26, [sp, #0]     ; fa 03 40 f9  
   140 : ldr   x27, [sp, #0x20]  ; fb 13 40 f9  
   141 : add   x26, x26, x27     ; 5a 03 1b 8b  
   142 : str   x26, [sp, #0]     ; fa 03 00 f9  
   143 : ldr   x26, [sp, #0x08]  ; fa 07 40 f9  
   144 : add   x26, x26, x4      ; 5a 03 04 8b  
   145 : str   x26, [sp, #0x08]  ; fa 07 00 f9  
   146 : ldr   x26, [sp, #0x10]  ; fa 0b 40 f9  
   147 : add   x26, x26, #0x01   ; 5a 07 00 91  
   148 : str   x26, [sp, #0x10]  ; fa 0b 00 f9  
   149 : b     __loops_label_0   ; a8 ff ff 17  
   150 :       __loops_label_2:  ;              
   151 : ldr   x25, [sp, #0x28]  ; f9 17 40 f9  
   152 : ldr   x26, [sp, #0x30]  ; fa 1b 40 f9  
   153 : ldr   x27, [sp, #0x38]  ; fb 1f 40 f9  
   154 : add   sp, sp, #0x40     ; ff 03 01 91  
   155 : ret   x30               ; c0 03 5f d6  
