nonnegative_odd(i0, i1)
     0 : sub   sp, sp, #0x30    ; ff c3 00 d1  
     1 : str   x25, [sp, #0x18] ; f9 0f 00 f9  
     2 : str   x26, [sp, #0x20] ; fa 13 00 f9  
     3 : eor   x2, x2, x2       ; 42 00 02 ca  
     4 : movn  x26, #0x03       ; 7a 00 80 92  
     5 : str   x26, [sp, #0x10] ; fa 0b 00 f9  
     6 : mov   x25, #0x04       ; 99 00 80 d2  
     7 : mul   x1, x1, x25      ; 21 7c 19 9b  
     8 :       __loops_label_0: ;              
     9 : cmp   x2, x1           ; 5f 00 01 eb  
    10 : b.ge  __loops_label_2  ; 8a 02 00 54  
    11 : ldrsw x25, [x0, x2]    ; 19 68 a2 b8  
    12 : cmp   x25, #0          ; 3f 03 00 f1  
    13 : b.ge  __loops_label_4  ; 6a 00 00 54  
    14 : add   x2, x2, #0x04    ; 42 10 00 91  
    15 : b     __loops_label_0  ; fa ff ff 17  
    16 :       __loops_label_4: ;              
    17 : mov   x3, #0x02        ; 43 00 80 d2  
    18 : str   x0, [sp, #0]     ; e0 03 00 f9  
    19 : mov   x0, x3           ; e0 03 03 aa  
    20 : sdiv  x3, x25, x0      ; 23 0f c0 9a  
    21 : mul   x3, x3, x0       ; 63 7c 00 9b  
    22 : sub   x3, x25, x3      ; 23 03 03 cb  
    23 : ldr   x0, [sp, #0]     ; e0 03 40 f9  
    24 : cmp   x3, #0           ; 7f 00 00 f1  
    25 : b.eq  __loops_label_6  ; 80 00 00 54  
    26 : mov   x26, x2          ; fa 03 02 aa  
    27 : str   x26, [sp, #0x10] ; fa 0b 00 f9  
    28 : b     __loops_label_2  ; 03 00 00 14  
    29 :       __loops_label_6: ;              
    30 : add   x2, x2, #0x04    ; 42 10 00 91  
    31 : b     __loops_label_0  ; ec ff ff 17  
    32 :       __loops_label_2: ;              
    33 : mov   x0, #0x04        ; 80 00 80 d2  
    34 : ldr   x26, [sp, #0x10] ; fa 0b 40 f9  
    35 : sdiv  x0, x26, x0      ; 40 0f c0 9a  
    36 : ldr   x25, [sp, #0x18] ; f9 0f 40 f9  
    37 : ldr   x26, [sp, #0x20] ; fa 13 40 f9  
    38 : add   sp, sp, #0x30    ; ff c3 00 91  
    39 : ret   x30              ; c0 03 5f d6  
