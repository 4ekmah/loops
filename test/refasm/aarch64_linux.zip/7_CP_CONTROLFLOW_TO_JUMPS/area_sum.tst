area_sum(i0, i1)
     0 : sub              i31, i31, 464      
     1 : spill            52, i0             
     2 : spill            51, i1             
     3 : spill            53, i25            
     4 : spill            54, i26            
     5 : arm_stp          i31, 448, i29, i30 
     6 : mov              i29, i31           
     7 : mov              i26, 0             
     8 : spill            50, i26            
     9 : __loops_label_0:                    
    10 : unspill          i26, 51            
    11 : cmp              i26, 0             
    12 : jmp_le           __loops_label_2    
    13 : unspill          i26, 52            
    14 : load.i8          i3, i26            
    15 : mov              i25, 28776         
    16 : arm_movk         i25, 59237, 16     
    17 : arm_movk         i25, 43690, 32     
    18 : mov              i2, 28996          
    19 : arm_movk         i2, 59237, 16      
    20 : arm_movk         i2, 43690, 32      
    21 : mov              i1, 29156          
    22 : arm_movk         i1, 59237, 16      
    23 : arm_movk         i1, 43690, 32      
    24 : cmp              i3, 1              
    25 : select_eq        i1, i2, i1         
    26 : cmp              i3, 0              
    27 : select_eq        i1, i25, i1        
    28 : mov              i2, 28500          
    29 : arm_movk         i2, 59237, 16      
    30 : arm_movk         i2, 43690, 32      
    31 : mov              i25, 28588         
    32 : arm_movk         i25, 59237, 16     
    33 : arm_movk         i25, 43690, 32     
    34 : mov              i0, 28644          
    35 : arm_movk         i0, 59237, 16      
    36 : arm_movk         i0, 43690, 32      
    37 : cmp              i3, 1              
    38 : select_eq        i0, i25, i0        
    39 : cmp              i3, 0              
    40 : select_eq        i0, i2, i0         
    41 : unspill          i26, 52            
    42 : call_noret       [i1](i26)          
    43 : unspill          i26, 52            
    44 : call             [i0](i0, i26)      
    45 : mov              i1, 28440          
    46 : arm_movk         i1, 59237, 16      
    47 : arm_movk         i1, 43690, 32      
    48 : unspill          i26, 50            
    49 : call             [i1](i0, i26, i0)  
    50 : mov              i26, i0            
    51 : spill            50, i26            
    52 : unspill          i26, 52            
    53 : add              i26, i26, 56       
    54 : spill            52, i26            
    55 : unspill          i26, 51            
    56 : sub              i26, i26, 1        
    57 : spill            51, i26            
    58 : jmp              0                  
    59 : __loops_label_2:                    
    60 : unspill          i26, 50            
    61 : mov              i0, i26            
    62 : arm_ldp          i29, i30, i31, 448 
    63 : unspill          i25, 53            
    64 : unspill          i26, 54            
    65 : add              i31, i31, 464      
    66 : ret                                 
