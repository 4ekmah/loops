min_max_select(i0, i1, i2, i3)
     0 : sub   sp, sp, #0x50     ; ff 43 01 d1  
     1 : str   x25, [sp, #0x38]  ; f9 1f 00 f9  
     2 : str   x26, [sp, #0x40]  ; fa 23 00 f9  
     3 : str   x27, [sp, #0x48]  ; fb 27 00 f9  
     4 : eor   x26, x26, x26     ; 5a 03 1a ca  
     5 : str   x26, [sp, #0x30]  ; fa 1b 00 f9  
     6 : eor   x26, x26, x26     ; 5a 03 1a ca  
     7 : str   x26, [sp, #0x08]  ; fa 07 00 f9  
     8 : eor   x26, x26, x26     ; 5a 03 1a ca  
     9 : str   x26, [sp, #0x10]  ; fa 0b 00 f9  
    10 : ldrsw x26, [x0, #0]     ; 1a 00 80 b9  
    11 : str   x26, [sp, #0x18]  ; fa 0f 00 f9  
    12 : ldr   x26, [sp, #0x18]  ; fa 0f 40 f9  
    13 : mov   x27, x26          ; fb 03 1a aa  
    14 : str   x27, [sp, #0x20]  ; fb 13 00 f9  
    15 : lsl   x1, x1, #0x02     ; 21 f4 7e d3  
    16 : str   x1, [sp, #0x28]   ; e1 17 00 f9  
    17 :       __loops_label_0:  ;              
    18 : ldr   x27, [sp, #0x28]  ; fb 17 40 f9  
    19 : ldr   x26, [sp, #0x30]  ; fa 1b 40 f9  
    20 : cmp   x26, x27          ; 5f 03 1b eb  
    21 : b.ge  __loops_label_2   ; aa 03 00 54  
    22 : ldr   x26, [sp, #0x30]  ; fa 1b 40 f9  
    23 : ldrsw x25, [x0, x26]    ; 19 68 ba b8  
    24 : ldr   x26, [sp, #0x18]  ; fa 0f 40 f9  
    25 : cmp   x25, x26          ; 3f 03 1a eb  
    26 : ldr   x26, [sp, #0x30]  ; fa 1b 40 f9  
    27 : ldr   x27, [sp, #0x08]  ; fb 07 40 f9  
    28 : csel  x27, x26, x27, lt ; 5b b3 9b 9a  
    29 : str   x27, [sp, #0x08]  ; fb 07 00 f9  
    30 : ldr   x26, [sp, #0x18]  ; fa 0f 40 f9  
    31 : cmp   x25, x26          ; 3f 03 1a eb  
    32 : ldr   x26, [sp, #0x18]  ; fa 0f 40 f9  
    33 : csel  x26, x25, x26, lt ; 3a b3 9a 9a  
    34 : str   x26, [sp, #0x18]  ; fa 0f 00 f9  
    35 : ldr   x26, [sp, #0x20]  ; fa 13 40 f9  
    36 : cmp   x25, x26          ; 3f 03 1a eb  
    37 : ldr   x26, [sp, #0x30]  ; fa 1b 40 f9  
    38 : ldr   x27, [sp, #0x10]  ; fb 0b 40 f9  
    39 : csel  x27, x26, x27, gt ; 5b c3 9b 9a  
    40 : str   x27, [sp, #0x10]  ; fb 0b 00 f9  
    41 : ldr   x26, [sp, #0x20]  ; fa 13 40 f9  
    42 : cmp   x25, x26          ; 3f 03 1a eb  
    43 : ldr   x26, [sp, #0x20]  ; fa 13 40 f9  
    44 : csel  x26, x25, x26, gt ; 3a c3 9a 9a  
    45 : str   x26, [sp, #0x20]  ; fa 13 00 f9  
    46 : ldr   x26, [sp, #0x30]  ; fa 1b 40 f9  
    47 : add   x26, x26, #0x04   ; 5a 13 00 91  
    48 : str   x26, [sp, #0x30]  ; fa 1b 00 f9  
    49 : b     __loops_label_0   ; e1 ff ff 17  
    50 :       __loops_label_2:  ;              
    51 : ldr   x26, [sp, #0x08]  ; fa 07 40 f9  
    52 : asr   x26, x26, #0x02   ; 5a ff 42 93  
    53 : str   x26, [sp, #0x08]  ; fa 07 00 f9  
    54 : ldr   x26, [sp, #0x10]  ; fa 0b 40 f9  
    55 : asr   x26, x26, #0x02   ; 5a ff 42 93  
    56 : str   x26, [sp, #0x10]  ; fa 0b 00 f9  
    57 : ldr   x26, [sp, #0x08]  ; fa 07 40 f9  
    58 : str   w26, [x2, #0]     ; 5a 00 00 b9  
    59 : ldr   x26, [sp, #0x10]  ; fa 0b 40 f9  
    60 : str   w26, [x3, #0]     ; 7a 00 00 b9  
    61 : eor   x0, x0, x0        ; 00 00 00 ca  
    62 : ldr   x25, [sp, #0x38]  ; f9 1f 40 f9  
    63 : ldr   x26, [sp, #0x40]  ; fa 23 40 f9  
    64 : ldr   x27, [sp, #0x48]  ; fb 27 40 f9  
    65 : add   sp, sp, #0x50     ; ff 43 01 91  
    66 : ret   x30               ; c0 03 5f d6  
