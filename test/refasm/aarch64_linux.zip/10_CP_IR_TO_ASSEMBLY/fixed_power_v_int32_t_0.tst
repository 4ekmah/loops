fixed_power_v_int32_t_0(i0, i1, i2)
     0 : sub  sp, sp, #0x20    ; ff 83 00 d1  
     1 : str  x25, [sp, #0x08] ; f9 07 00 f9  
     2 : str  x26, [sp, #0x10] ; fa 0b 00 f9  
     3 : eor  x3, x3, x3       ; 63 00 03 ca  
     4 : mov  x26, #0x04       ; 9a 00 80 d2  
     5 : str  x26, [sp, #0]    ; fa 03 00 f9  
     6 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
     7 : mul  x25, x2, x26     ; 59 7c 1a 9b  
     8 :      __loops_label_0: ;              
     9 : cmp  x3, x25          ; 7f 00 19 eb  
    10 : b.ge __loops_label_2  ; ca 00 00 54  
    11 : ldr  q0, [x0, x3]     ; 00 68 e3 3c  
    12 : movi v0.4s, #0x01     ; 20 04 00 4f  
    13 : str  q0, [x1, x3]     ; 20 68 a3 3c  
    14 : add  x3, x3, #0x10    ; 63 40 00 91  
    15 : b    __loops_label_0  ; fa ff ff 17  
    16 :      __loops_label_2: ;              
    17 : eor  x0, x0, x0       ; 00 00 00 ca  
    18 : ldr  x25, [sp, #0x08] ; f9 07 40 f9  
    19 : ldr  x26, [sp, #0x10] ; fa 0b 40 f9  
    20 : add  sp, sp, #0x20    ; ff 83 00 91  
    21 : ret  x30              ; c0 03 5f d6  
