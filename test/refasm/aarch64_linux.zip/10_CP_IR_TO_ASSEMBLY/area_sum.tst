area_sum(i0, i1)
     0 : sub   sp, sp, #0x1d0                                 ; ff 43 07 d1  
     1 : str   x25, [sp, #0x1a8]                              ; f9 d7 00 f9  
     2 : str   x26, [sp, #0x1b0]                              ; fa db 00 f9  
     3 : stp   x29, x30, [sp, #0x1c0]                         ; fd 7b 1c a9  
     4 : mov   x29, sp                                        ; fd 03 1f aa  
     5 : eor   x26, x26, x26                                  ; 5a 03 1a ca  
     6 : str   x26, [sp, #0x190]                              ; fa cb 00 f9  
     7 :       __loops_label_0:                               ;              
     8 : cmp   x1, #0                                         ; 3f 00 00 f1  
     9 : b.le  __loops_label_2                                ; ed 10 00 54  
    10 : ldrsb x26, [x0, #0]                                  ; 1a 00 80 39  
    11 : str   x26, [sp, #0x198]                              ; fa cf 00 f9  
    12 : mov   x25, #0xf0e4                                   ; 99 1c 9e d2  
    13 : movk  x25, #0xaf36, lsl #16                          ; d9 e6 b5 f2  
    14 : movk  x25, #0xaaaa, lsl #32                          ; 59 55 d5 f2  
    15 : mov   x2, #0xf000                                    ; 02 00 9e d2  
    16 : movk  x2, #0xaf36, lsl #16                           ; c2 e6 b5 f2  
    17 : movk  x2, #0xaaaa, lsl #32                           ; 42 55 d5 f2  
    18 : mov   x3, #0xf200                                    ; 03 40 9e d2  
    19 : movk  x3, #0xaf36, lsl #16                           ; c3 e6 b5 f2  
    20 : movk  x3, #0xaaaa, lsl #32                           ; 43 55 d5 f2  
    21 : ldr   x26, [sp, #0x198]                              ; fa cf 40 f9  
    22 : cmp   x26, #0x01                                     ; 5f 07 00 f1  
    23 : csel  x2, x2, x3, eq                                 ; 42 00 83 9a  
    24 : ldr   x26, [sp, #0x198]                              ; fa cf 40 f9  
    25 : cmp   x26, #0                                        ; 5f 03 00 f1  
    26 : csel  x26, x25, x2, eq                               ; 3a 03 82 9a  
    27 : str   x26, [sp, #0x1a0]                              ; fa d3 00 f9  
    28 : mov   x3, #0xe9d0                                    ; 03 3a 9d d2  
    29 : movk  x3, #0xaf36, lsl #16                           ; c3 e6 b5 f2  
    30 : movk  x3, #0xaaaa, lsl #32                           ; 43 55 d5 f2  
    31 : mov   x25, #0xe9f0                                   ; 19 3e 9d d2  
    32 : movk  x25, #0xaf36, lsl #16                          ; d9 e6 b5 f2  
    33 : movk  x25, #0xaaaa, lsl #32                          ; 59 55 d5 f2  
    34 : mov   x2, #0xea10                                    ; 02 42 9d d2  
    35 : movk  x2, #0xaf36, lsl #16                           ; c2 e6 b5 f2  
    36 : movk  x2, #0xaaaa, lsl #32                           ; 42 55 d5 f2  
    37 : ldr   x26, [sp, #0x198]                              ; fa cf 40 f9  
    38 : cmp   x26, #0x01                                     ; 5f 07 00 f1  
    39 : csel  x2, x25, x2, eq                                ; 22 03 82 9a  
    40 : ldr   x26, [sp, #0x198]                              ; fa cf 40 f9  
    41 : cmp   x26, #0                                        ; 5f 03 00 f1  
    42 : csel  x2, x3, x2, eq                                 ; 62 00 82 9a  
    43 : ldr   x26, [sp, #0x1a0]                              ; fa d3 40 f9  
    44 : stp   x0, x1, [sp, #0]                               ; e0 07 00 a9  
    45 : stp   x2, x3, [sp, #0x10]                            ; e2 0f 01 a9  
    46 : stp   x4, x5, [sp, #0x20]                            ; e4 17 02 a9  
    47 : stp   x6, x7, [sp, #0x30]                            ; e6 1f 03 a9  
    48 : stp   x8, x9, [sp, #0x40]                            ; e8 27 04 a9  
    49 : stp   x10, x11, [sp, #0x50]                          ; ea 2f 05 a9  
    50 : stp   x12, x13, [sp, #0x60]                          ; ec 37 06 a9  
    51 : stp   x14, x15, [sp, #0x70]                          ; ee 3f 07 a9  
    52 : stp   x16, x17, [sp, #0x80]                          ; f0 47 08 a9  
    53 : add   x10, sp, #0x90                                 ; ea 43 02 91  
    54 : st1   {v0.2d, v1.2d, v2.2d, v3.2d}, [x10], #0x40     ; 40 2d 9f 4c  
    55 : st1   {v4.2d, v5.2d, v6.2d, v7.2d}, [x10], #0x40     ; 44 2d 9f 4c  
    56 : st1   {v8.2d, v9.2d, v10.2d, v11.2d}, [x10], #0x40   ; 48 2d 9f 4c  
    57 : st1   {v12.2d, v13.2d, v14.2d, v15.2d}, [x10], #0x40 ; 4c 2d 9f 4c  
    58 : blr   x26                                            ; 40 03 3f d6  
    59 : add   x10, sp, #0x90                                 ; ea 43 02 91  
    60 : ld1   {v0.2d, v1.2d, v2.2d, v3.2d}, [x10], #0x40     ; 40 2d df 4c  
    61 : ld1   {v4.2d, v5.2d, v6.2d, v7.2d}, [x10], #0x40     ; 44 2d df 4c  
    62 : ld1   {v8.2d, v9.2d, v10.2d, v11.2d}, [x10], #0x40   ; 48 2d df 4c  
    63 : ld1   {v12.2d, v13.2d, v14.2d, v15.2d}, [x10], #0x40 ; 4c 2d df 4c  
    64 : ldp   x0, x1, [sp, #0]                               ; e0 07 40 a9  
    65 : ldp   x2, x3, [sp, #0x10]                            ; e2 0f 41 a9  
    66 : ldp   x4, x5, [sp, #0x20]                            ; e4 17 42 a9  
    67 : ldp   x6, x7, [sp, #0x30]                            ; e6 1f 43 a9  
    68 : ldp   x8, x9, [sp, #0x40]                            ; e8 27 44 a9  
    69 : ldp   x10, x11, [sp, #0x50]                          ; ea 2f 45 a9  
    70 : ldp   x12, x13, [sp, #0x60]                          ; ec 37 46 a9  
    71 : ldp   x14, x15, [sp, #0x70]                          ; ee 3f 47 a9  
    72 : ldp   x16, x17, [sp, #0x80]                          ; f0 47 48 a9  
    73 : stp   x0, x1, [sp, #0]                               ; e0 07 00 a9  
    74 : stp   x2, x3, [sp, #0x10]                            ; e2 0f 01 a9  
    75 : stp   x4, x5, [sp, #0x20]                            ; e4 17 02 a9  
    76 : stp   x6, x7, [sp, #0x30]                            ; e6 1f 03 a9  
    77 : stp   x8, x9, [sp, #0x40]                            ; e8 27 04 a9  
    78 : stp   x10, x11, [sp, #0x50]                          ; ea 2f 05 a9  
    79 : stp   x12, x13, [sp, #0x60]                          ; ec 37 06 a9  
    80 : stp   x14, x15, [sp, #0x70]                          ; ee 3f 07 a9  
    81 : stp   x16, x17, [sp, #0x80]                          ; f0 47 08 a9  
    82 : add   x10, sp, #0x90                                 ; ea 43 02 91  
    83 : st1   {v0.2d, v1.2d, v2.2d, v3.2d}, [x10], #0x40     ; 40 2d 9f 4c  
    84 : st1   {v4.2d, v5.2d, v6.2d, v7.2d}, [x10], #0x40     ; 44 2d 9f 4c  
    85 : st1   {v8.2d, v9.2d, v10.2d, v11.2d}, [x10], #0x40   ; 48 2d 9f 4c  
    86 : st1   {v12.2d, v13.2d, v14.2d, v15.2d}, [x10], #0x40 ; 4c 2d 9f 4c  
    87 : blr   x2                                             ; 40 00 3f d6  
    88 : add   x10, sp, #0x90                                 ; ea 43 02 91  
    89 : ld1   {v0.2d, v1.2d, v2.2d, v3.2d}, [x10], #0x40     ; 40 2d df 4c  
    90 : ld1   {v4.2d, v5.2d, v6.2d, v7.2d}, [x10], #0x40     ; 44 2d df 4c  
    91 : ld1   {v8.2d, v9.2d, v10.2d, v11.2d}, [x10], #0x40   ; 48 2d df 4c  
    92 : ld1   {v12.2d, v13.2d, v14.2d, v15.2d}, [x10], #0x40 ; 4c 2d df 4c  
    93 : mov   x2, x0                                         ; e2 03 00 aa  
    94 : ldp   x0, x1, [sp, #0]                               ; e0 07 40 a9  
    95 : ldr   x3, [sp, #0x18]                                ; e3 0f 40 f9  
    96 : ldp   x4, x5, [sp, #0x20]                            ; e4 17 42 a9  
    97 : ldp   x6, x7, [sp, #0x30]                            ; e6 1f 43 a9  
    98 : ldp   x8, x9, [sp, #0x40]                            ; e8 27 44 a9  
    99 : ldp   x10, x11, [sp, #0x50]                          ; ea 2f 45 a9  
   100 : ldp   x12, x13, [sp, #0x60]                          ; ec 37 46 a9  
   101 : ldp   x14, x15, [sp, #0x70]                          ; ee 3f 47 a9  
   102 : ldp   x16, x17, [sp, #0x80]                          ; f0 47 48 a9  
   103 : mov   x3, #0xe9b4                                    ; 83 36 9d d2  
   104 : movk  x3, #0xaf36, lsl #16                           ; c3 e6 b5 f2  
   105 : movk  x3, #0xaaaa, lsl #32                           ; 43 55 d5 f2  
   106 : ldr   x26, [sp, #0x190]                              ; fa cb 40 f9  
   107 : stp   x0, x1, [sp, #0]                               ; e0 07 00 a9  
   108 : stp   x2, x3, [sp, #0x10]                            ; e2 0f 01 a9  
   109 : stp   x4, x5, [sp, #0x20]                            ; e4 17 02 a9  
   110 : stp   x6, x7, [sp, #0x30]                            ; e6 1f 03 a9  
   111 : stp   x8, x9, [sp, #0x40]                            ; e8 27 04 a9  
   112 : stp   x10, x11, [sp, #0x50]                          ; ea 2f 05 a9  
   113 : stp   x12, x13, [sp, #0x60]                          ; ec 37 06 a9  
   114 : stp   x14, x15, [sp, #0x70]                          ; ee 3f 07 a9  
   115 : stp   x16, x17, [sp, #0x80]                          ; f0 47 08 a9  
   116 : mov   x0, x26                                        ; e0 03 1a aa  
   117 : mov   x1, x2                                         ; e1 03 02 aa  
   118 : add   x10, sp, #0x90                                 ; ea 43 02 91  
   119 : st1   {v0.2d, v1.2d, v2.2d, v3.2d}, [x10], #0x40     ; 40 2d 9f 4c  
   120 : st1   {v4.2d, v5.2d, v6.2d, v7.2d}, [x10], #0x40     ; 44 2d 9f 4c  
   121 : st1   {v8.2d, v9.2d, v10.2d, v11.2d}, [x10], #0x40   ; 48 2d 9f 4c  
   122 : st1   {v12.2d, v13.2d, v14.2d, v15.2d}, [x10], #0x40 ; 4c 2d 9f 4c  
   123 : blr   x3                                             ; 60 00 3f d6  
   124 : add   x10, sp, #0x90                                 ; ea 43 02 91  
   125 : ld1   {v0.2d, v1.2d, v2.2d, v3.2d}, [x10], #0x40     ; 40 2d df 4c  
   126 : ld1   {v4.2d, v5.2d, v6.2d, v7.2d}, [x10], #0x40     ; 44 2d df 4c  
   127 : ld1   {v8.2d, v9.2d, v10.2d, v11.2d}, [x10], #0x40   ; 48 2d df 4c  
   128 : ld1   {v12.2d, v13.2d, v14.2d, v15.2d}, [x10], #0x40 ; 4c 2d df 4c  
   129 : mov   x2, x0                                         ; e2 03 00 aa  
   130 : ldp   x0, x1, [sp, #0]                               ; e0 07 40 a9  
   131 : ldr   x3, [sp, #0x18]                                ; e3 0f 40 f9  
   132 : ldp   x4, x5, [sp, #0x20]                            ; e4 17 42 a9  
   133 : ldp   x6, x7, [sp, #0x30]                            ; e6 1f 43 a9  
   134 : ldp   x8, x9, [sp, #0x40]                            ; e8 27 44 a9  
   135 : ldp   x10, x11, [sp, #0x50]                          ; ea 2f 45 a9  
   136 : ldp   x12, x13, [sp, #0x60]                          ; ec 37 46 a9  
   137 : ldp   x14, x15, [sp, #0x70]                          ; ee 3f 47 a9  
   138 : ldp   x16, x17, [sp, #0x80]                          ; f0 47 48 a9  
   139 : mov   x26, x2                                        ; fa 03 02 aa  
   140 : str   x26, [sp, #0x190]                              ; fa cb 00 f9  
   141 : add   x0, x0, #0x38                                  ; 00 e0 00 91  
   142 : sub   x1, x1, #0x01                                  ; 21 04 00 d1  
   143 : b     __loops_label_0                                ; 79 ff ff 17  
   144 :       __loops_label_2:                               ;              
   145 : ldr   x26, [sp, #0x190]                              ; fa cb 40 f9  
   146 : mov   x0, x26                                        ; e0 03 1a aa  
   147 : ldp   x29, x30, [sp, #0x1c0]                         ; fd 7b 5c a9  
   148 : ldr   x25, [sp, #0x1a8]                              ; f9 d7 40 f9  
   149 : ldr   x26, [sp, #0x1b0]                              ; fa db 40 f9  
   150 : add   sp, sp, #0x1d0                                 ; ff 43 07 91  
   151 : ret   x30                                            ; c0 03 5f d6  
