fixed_power_v_double_0(i0, i1, i2)
     0 : sub  sp, sp, #0x20         ; ff 83 00 d1  
     1 : str  x25, [sp, #0x10]      ; f9 0b 00 f9  
     2 : str  x26, [sp, #0x18]      ; fa 0f 00 f9  
     3 : eor  x3, x3, x3            ; 63 00 03 ca  
     4 : mov  x25, #0x08            ; 19 01 80 d2  
     5 : mul  x2, x2, x25           ; 42 7c 19 9b  
     6 : str  x2, [sp, #0x08]       ; e2 07 00 f9  
     7 :      __loops_label_0:      ;              
     8 : ldr  x26, [sp, #0x08]      ; fa 07 40 f9  
     9 : cmp  x3, x26               ; 7f 00 1a eb  
    10 : b.ge __loops_label_2       ; 0a 01 00 54  
    11 : ldr  q0, [x0, x3]          ; 00 68 e3 3c  
    12 : eor  x25, x25, x25         ; 39 03 19 ca  
    13 : movk x25, #0x3ff0, lsl #48 ; 19 fe e7 f2  
    14 : dup  v0.2d, x25            ; 20 0f 08 4e  
    15 : str  q0, [x1, x3]          ; 20 68 a3 3c  
    16 : add  x3, x3, #0x10         ; 63 40 00 91  
    17 : b    __loops_label_0       ; f7 ff ff 17  
    18 :      __loops_label_2:      ;              
    19 : eor  x0, x0, x0            ; 00 00 00 ca  
    20 : ldr  x25, [sp, #0x10]      ; f9 0b 40 f9  
    21 : ldr  x26, [sp, #0x18]      ; fa 0f 40 f9  
    22 : add  sp, sp, #0x20         ; ff 83 00 91  
    23 : ret  x30                   ; c0 03 5f d6  
