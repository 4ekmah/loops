nonnegative_odd(i0, i1)
     0 : sub   sp, sp, #0x40    ; ff 03 01 d1  
     1 : str   x25, [sp, #0x20] ; f9 13 00 f9  
     2 : str   x26, [sp, #0x28] ; fa 17 00 f9  
     3 : str   x27, [sp, #0x30] ; fb 1b 00 f9  
     4 : eor   x26, x26, x26    ; 5a 03 1a ca  
     5 : str   x26, [sp, #0x18] ; fa 0f 00 f9  
     6 : movn  x26, #0x03       ; 7a 00 80 92  
     7 : str   x26, [sp, #0x10] ; fa 0b 00 f9  
     8 : mov   x2, #0x04        ; 82 00 80 d2  
     9 : mul   x1, x1, x2       ; 21 7c 02 9b  
    10 : str   x1, [sp, #0x08]  ; e1 07 00 f9  
    11 :       __loops_label_0: ;              
    12 : ldr   x27, [sp, #0x08] ; fb 07 40 f9  
    13 : ldr   x26, [sp, #0x18] ; fa 0f 40 f9  
    14 : cmp   x26, x27         ; 5f 03 1b eb  
    15 : b.ge  __loops_label_2  ; ea 02 00 54  
    16 : ldr   x26, [sp, #0x18] ; fa 0f 40 f9  
    17 : ldrsw x25, [x0, x26]   ; 19 68 ba b8  
    18 : cmp   x25, #0          ; 3f 03 00 f1  
    19 : b.ge  __loops_label_4  ; aa 00 00 54  
    20 : ldr   x26, [sp, #0x18] ; fa 0f 40 f9  
    21 : add   x26, x26, #0x04  ; 5a 13 00 91  
    22 : str   x26, [sp, #0x18] ; fa 0f 00 f9  
    23 : b     __loops_label_0  ; f5 ff ff 17  
    24 :       __loops_label_4: ;              
    25 : mov   x3, #0x02        ; 43 00 80 d2  
    26 : sdiv  x2, x25, x3      ; 22 0f c3 9a  
    27 : mul   x2, x2, x3       ; 42 7c 03 9b  
    28 : sub   x2, x25, x2      ; 22 03 02 cb  
    29 : cmp   x2, #0           ; 5f 00 00 f1  
    30 : b.eq  __loops_label_6  ; a0 00 00 54  
    31 : ldr   x26, [sp, #0x18] ; fa 0f 40 f9  
    32 : mov   x27, x26         ; fb 03 1a aa  
    33 : str   x27, [sp, #0x10] ; fb 0b 00 f9  
    34 : b     __loops_label_2  ; 05 00 00 14  
    35 :       __loops_label_6: ;              
    36 : ldr   x26, [sp, #0x18] ; fa 0f 40 f9  
    37 : add   x26, x26, #0x04  ; 5a 13 00 91  
    38 : str   x26, [sp, #0x18] ; fa 0f 00 f9  
    39 : b     __loops_label_0  ; e7 ff ff 17  
    40 :       __loops_label_2: ;              
    41 : mov   x0, #0x04        ; 80 00 80 d2  
    42 : ldr   x26, [sp, #0x10] ; fa 0b 40 f9  
    43 : sdiv  x0, x26, x0      ; 40 0f c0 9a  
    44 : ldr   x25, [sp, #0x20] ; f9 13 40 f9  
    45 : ldr   x26, [sp, #0x28] ; fa 17 40 f9  
    46 : ldr   x27, [sp, #0x30] ; fb 1b 40 f9  
    47 : add   sp, sp, #0x40    ; ff 03 01 91  
    48 : ret   x30              ; c0 03 5f d6  
