nullify_msb_lsb_v(i0, i1, i2, i3)
     0 : sub  sp, sp, #0x30       ; ff c3 00 d1  
     1 : str  x25, [sp, #0x18]    ; f9 0f 00 f9  
     2 : str  x26, [sp, #0x20]    ; fa 13 00 f9  
     3 : eor  x25, x25, x25       ; 39 03 19 ca  
     4 : mov  x26, #0x04          ; 9a 00 80 d2  
     5 : str  x26, [sp, #0x10]    ; fa 0b 00 f9  
     6 : ldr  x26, [sp, #0x10]    ; fa 0b 40 f9  
     7 : mul  x3, x3, x26         ; 63 7c 1a 9b  
     8 : movi v0.4s, #0x01        ; 20 04 00 4f  
     9 : str  x3, [sp, #0x08]     ; e3 07 00 f9  
    10 :      __loops_label_0:    ;              
    11 : ldr  x26, [sp, #0x08]    ; fa 07 40 f9  
    12 : cmp  x25, x26            ; 3f 03 1a eb  
    13 : b.ge __loops_label_2     ; ea 02 00 54  
    14 : ldr  q1, [x0, x25]       ; 01 68 f9 3c  
    15 : ushr v2.4s, v1.4s, #0x01 ; 22 04 3f 6f  
    16 : orr  v2.4s, v1.4s, v2.4s ; 22 1c a2 4e  
    17 : ushr v3.4s, v2.4s, #0x02 ; 43 04 3e 6f  
    18 : orr  v2.4s, v2.4s, v3.4s ; 42 1c a3 4e  
    19 : ushr v3.4s, v2.4s, #0x04 ; 43 04 3c 6f  
    20 : orr  v2.4s, v2.4s, v3.4s ; 42 1c a3 4e  
    21 : ushr v3.4s, v2.4s, #0x08 ; 43 04 38 6f  
    22 : orr  v2.4s, v2.4s, v3.4s ; 42 1c a3 4e  
    23 : ushr v3.4s, v2.4s, #0x10 ; 43 04 30 6f  
    24 : orr  v2.4s, v2.4s, v3.4s ; 42 1c a3 4e  
    25 : add  v2.4s, v2.4s, v0.4s ; 42 84 a0 4e  
    26 : ushr v2.4s, v2.4s, #0x01 ; 42 04 3f 6f  
    27 : eor  v2.4s, v2.4s, v1.4s ; 42 1c 21 6e  
    28 : str  q2, [x1, x25]       ; 22 68 b9 3c  
    29 : sub  v2.4s, v1.4s, v0.4s ; 22 84 a0 6e  
    30 : mvn  v2.4s, v2.4s        ; 42 58 20 6e  
    31 : and  v2.4s, v1.4s, v2.4s ; 22 1c 22 4e  
    32 : eor  v1.4s, v2.4s, v1.4s ; 41 1c 21 6e  
    33 : str  q1, [x2, x25]       ; 41 68 b9 3c  
    34 : add  x25, x25, #0x10     ; 39 43 00 91  
    35 : b    __loops_label_0     ; e8 ff ff 17  
    36 :      __loops_label_2:    ;              
    37 : ldr  x25, [sp, #0x18]    ; f9 0f 40 f9  
    38 : ldr  x26, [sp, #0x20]    ; fa 13 40 f9  
    39 : add  sp, sp, #0x30       ; ff c3 00 91  
    40 : ret  x30                 ; c0 03 5f d6  
