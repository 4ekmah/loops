min_max_scalar(i0, i1, i2, i3)
     0 : sub   sp, sp, #0x60    ; ff 83 01 d1  
     1 : str   x25, [sp, #0x40] ; f9 23 00 f9  
     2 : str   x26, [sp, #0x48] ; fa 27 00 f9  
     3 : str   x27, [sp, #0x50] ; fb 2b 00 f9  
     4 : eor   x26, x26, x26    ; 5a 03 1a ca  
     5 : str   x26, [sp, #0x38] ; fa 1f 00 f9  
     6 : eor   x26, x26, x26    ; 5a 03 1a ca  
     7 : str   x26, [sp, #0x10] ; fa 0b 00 f9  
     8 : eor   x26, x26, x26    ; 5a 03 1a ca  
     9 : str   x26, [sp, #0x18] ; fa 0f 00 f9  
    10 : ldrsw x26, [x0, #0]    ; 1a 00 80 b9  
    11 : str   x26, [sp, #0x20] ; fa 13 00 f9  
    12 : ldr   x26, [sp, #0x20] ; fa 13 40 f9  
    13 : mov   x27, x26         ; fb 03 1a aa  
    14 : str   x27, [sp, #0x28] ; fb 17 00 f9  
    15 : mov   x25, #0x04       ; 99 00 80 d2  
    16 : mul   x1, x1, x25      ; 21 7c 19 9b  
    17 : str   x1, [sp, #0x30]  ; e1 1b 00 f9  
    18 :       __loops_label_0: ;              
    19 : ldr   x27, [sp, #0x30] ; fb 1b 40 f9  
    20 : ldr   x26, [sp, #0x38] ; fa 1f 40 f9  
    21 : cmp   x26, x27         ; 5f 03 1b eb  
    22 : b.ge  __loops_label_2  ; ea 02 00 54  
    23 : ldr   x26, [sp, #0x38] ; fa 1f 40 f9  
    24 : ldrsw x25, [x0, x26]   ; 19 68 ba b8  
    25 : ldr   x26, [sp, #0x20] ; fa 13 40 f9  
    26 : cmp   x25, x26         ; 3f 03 1a eb  
    27 : b.ge  __loops_label_4  ; ca 00 00 54  
    28 : mov   x26, x25         ; fa 03 19 aa  
    29 : str   x26, [sp, #0x20] ; fa 13 00 f9  
    30 : ldr   x26, [sp, #0x38] ; fa 1f 40 f9  
    31 : mov   x27, x26         ; fb 03 1a aa  
    32 : str   x27, [sp, #0x10] ; fb 0b 00 f9  
    33 :       __loops_label_4: ;              
    34 : ldr   x26, [sp, #0x28] ; fa 17 40 f9  
    35 : cmp   x25, x26         ; 3f 03 1a eb  
    36 : b.le  __loops_label_6  ; cd 00 00 54  
    37 : mov   x26, x25         ; fa 03 19 aa  
    38 : str   x26, [sp, #0x28] ; fa 17 00 f9  
    39 : ldr   x26, [sp, #0x38] ; fa 1f 40 f9  
    40 : mov   x27, x26         ; fb 03 1a aa  
    41 : str   x27, [sp, #0x18] ; fb 0f 00 f9  
    42 :       __loops_label_6: ;              
    43 : ldr   x26, [sp, #0x38] ; fa 1f 40 f9  
    44 : add   x26, x26, #0x04  ; 5a 13 00 91  
    45 : str   x26, [sp, #0x38] ; fa 1f 00 f9  
    46 : b     __loops_label_0  ; e7 ff ff 17  
    47 :       __loops_label_2: ;              
    48 : mov   x0, #0x04        ; 80 00 80 d2  
    49 : ldr   x26, [sp, #0x10] ; fa 0b 40 f9  
    50 : sdiv  x1, x26, x0      ; 41 0f c0 9a  
    51 : ldr   x26, [sp, #0x18] ; fa 0f 40 f9  
    52 : sdiv  x0, x26, x0      ; 40 0f c0 9a  
    53 : str   w1, [x2, #0]     ; 41 00 00 b9  
    54 : str   w0, [x3, #0]     ; 60 00 00 b9  
    55 : eor   x0, x0, x0       ; 00 00 00 ca  
    56 : ldr   x25, [sp, #0x40] ; f9 23 40 f9  
    57 : ldr   x26, [sp, #0x48] ; fa 27 40 f9  
    58 : ldr   x27, [sp, #0x50] ; fb 2b 40 f9  
    59 : add   sp, sp, #0x60    ; ff 83 01 91  
    60 : ret   x30              ; c0 03 5f d6  
