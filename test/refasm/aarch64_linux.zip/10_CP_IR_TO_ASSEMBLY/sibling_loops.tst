sibling_loops(i0, i1, i2)
     0 : sub   sp, sp, #0x20    ; ff 83 00 d1  
     1 : str   x25, [sp, #0x08] ; f9 07 00 f9  
     2 : str   x26, [sp, #0x10] ; fa 0b 00 f9  
     3 : eor   x3, x3, x3       ; 63 00 03 ca  
     4 : eor   x26, x26, x26    ; 5a 03 1a ca  
     5 : str   x26, [sp, #0]    ; fa 03 00 f9  
     6 :       __loops_label_0: ;              
     7 : cmp   x3, x1           ; 7f 00 01 eb  
     8 : b.ge  __loops_label_2  ; ea 00 00 54  
     9 : ldrsw x25, [x0, x3]    ; 19 68 a3 b8  
    10 : ldr   x26, [sp, #0]    ; fa 03 40 f9  
    11 : add   x26, x26, x25    ; 5a 03 19 8b  
    12 : str   x26, [sp, #0]    ; fa 03 00 f9  
    13 : add   x3, x3, #0x04    ; 63 10 00 91  
    14 : b     __loops_label_0  ; f9 ff ff 17  
    15 :       __loops_label_2: ;              
    16 : eor   x25, x25, x25    ; 39 03 19 ca  
    17 :       __loops_label_3: ;              
    18 : cmp   x3, #0           ; 7f 00 00 f1  
    19 : b.le  __loops_label_5  ; 8d 00 00 54  
    20 : add   x25, x25, #0x01  ; 39 07 00 91  
    21 : sub   x3, x3, #0x04    ; 63 10 00 d1  
    22 : b     __loops_label_3  ; fc ff ff 17  
    23 :       __loops_label_5: ;              
    24 : ldr   x26, [sp, #0]    ; fa 03 40 f9  
    25 : str   w26, [x2, #0]    ; 5a 00 00 b9  
    26 : str   w25, [x2, #0x04] ; 59 04 00 b9  
    27 : eor   x0, x0, x0       ; 00 00 00 ca  
    28 : ldr   x25, [sp, #0x08] ; f9 07 40 f9  
    29 : ldr   x26, [sp, #0x10] ; fa 0b 40 f9  
    30 : add   sp, sp, #0x20    ; ff 83 00 91  
    31 : ret   x30              ; c0 03 5f d6  
