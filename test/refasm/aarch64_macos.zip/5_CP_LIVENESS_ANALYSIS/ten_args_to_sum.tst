ten_args_to_sum(i0, i1, i2, i3, i4, i5, i6, i7, i8, i9)
     0 : mov i29, 1        
     1 : mul i10, i0, i29  
     2 : mov i30, 2        
     3 : mul i20, i1, i30  
     4 : add i11, i10, i20 
     5 : mov i31, 3        
     6 : mul i21, i2, i31  
     7 : add i12, i11, i21 
     8 : mov i32, 4        
     9 : mul i22, i3, i32  
    10 : add i13, i12, i22 
    11 : mov i33, 5        
    12 : mul i23, i4, i33  
    13 : add i14, i13, i23 
    14 : mov i34, 6        
    15 : mul i24, i5, i34  
    16 : add i15, i14, i24 
    17 : mov i35, 7        
    18 : mul i25, i6, i35  
    19 : add i16, i15, i25 
    20 : mov i36, 8        
    21 : mul i26, i7, i36  
    22 : add i17, i16, i26 
    23 : mov i37, 3        
    24 : mul i27, i8, i37  
    25 : add i18, i17, i27 
    26 : mov i38, 2        
    27 : mul i28, i9, i38  
    28 : add i19, i18, i28 
    29 : mov iR, i19       
    30 : ret               
