fixed_power_v_int32_t_0(i0, i1, i2)
     0 : mov                    i4, 0           
     1 : mov                    i5, 4           
     2 : mul                    i3, i2, i5      
     3 : annotation:whilecstart 0               
     4 : cmp                    i4, i3          
     5 : jmp_ge                 __loops_label_2 
     6 : annotation:whilecend                   
     7 : vld.i32                v0, i0, i4      
     8 : mov                    v1, 1           
     9 : vst.i32                i1, i4, v1      
    10 : add                    i4, i4, 16      
    11 : annotation:endwhile    0, 2            
    12 : mov                    iR, 0           
    13 : ret                                    
