big_immediates(i0, i1)
     0 : annotation:ifcstart                  
     1 : cmp                 i1, 0            
     2 : jmp_ne              __loops_label_1  
     3 : annotation:ifcend                    
     4 : mov                 i4, 65535        
     5 : store.u64           i0, i4           
     6 : add                 i0, i0, 8        
     7 : mov                 i5, 0            
     8 : arm_movk            i5, 1, 16        
     9 : store.u64           i0, i5           
    10 : add                 i0, i0, 8        
    11 : mov                 i6, -32768       
    12 : store.i64           i0, i6           
    13 : add                 i0, i0, 8        
    14 : mov                 i7, -32769       
    15 : store.i64           i0, i7           
    16 : add                 i0, i0, 8        
    17 : mov                 i8, 23007        
    18 : arm_movk            i8, 24375, 16    
    19 : store.u64           i0, i8           
    20 : add                 i0, i0, 8        
    21 : mov                 i9, 22377        
    22 : arm_movk            i9, 35604, 16    
    23 : arm_movk            i9, 48906, 32    
    24 : arm_movk            i9, 16389, 48    
    25 : store.u64           i0, i9           
    26 : add                 i0, i0, 8        
    27 : annotation:else     1, 2             
    28 : annotation:ifcstart                  
    29 : cmp                 i1, 1            
    30 : jmp_ne              __loops_label_4  
    31 : annotation:ifcend                    
    32 : mov                 v0, 0            
    33 : vst.u8              i0, v0           
    34 : add                 i0, i0, 16       
    35 : mov                 v1, 255          
    36 : vst.u8              i0, v1           
    37 : add                 i0, i0, 16       
    38 : annotation:else     4, 5             
    39 : annotation:ifcstart                  
    40 : cmp                 i1, 2            
    41 : jmp_ne              __loops_label_7  
    42 : annotation:ifcend                    
    43 : mov                 v2, 128          
    44 : vst.i8              i0, v2           
    45 : add                 i0, i0, 16       
    46 : annotation:else     7, 8             
    47 : annotation:ifcstart                  
    48 : cmp                 i1, 3            
    49 : jmp_ne              __loops_label_10 
    50 : annotation:ifcend                    
    51 : mov                 v3, 0            
    52 : vst.u16             i0, v3           
    53 : add                 i0, i0, 16       
    54 : mov                 v4, 255          
    55 : vst.u16             i0, v4           
    56 : add                 i0, i0, 16       
    57 : mov                 i10, 256         
    58 : broadcast.u16       v5, i10          
    59 : vst.u16             i0, v5           
    60 : add                 i0, i0, 16       
    61 : annotation:else     10, 11           
    62 : annotation:ifcstart                  
    63 : cmp                 i1, 4            
    64 : jmp_ne              __loops_label_13 
    65 : annotation:ifcend                    
    66 : mov                 i11, 65408       
    67 : broadcast.i16       v6, i11          
    68 : vst.i16             i0, v6           
    69 : add                 i0, i0, 16       
    70 : mov                 i12, 65407       
    71 : broadcast.i16       v7, i12          
    72 : vst.i16             i0, v7           
    73 : add                 i0, i0, 16       
    74 : annotation:else     13, 14           
    75 : annotation:ifcstart                  
    76 : cmp                 i1, 5            
    77 : jmp_ne              __loops_label_16 
    78 : annotation:ifcend                    
    79 : mov                 v8, 0            
    80 : vst.u32             i0, v8           
    81 : add                 i0, i0, 16       
    82 : mov                 v9, 255          
    83 : vst.u32             i0, v9           
    84 : add                 i0, i0, 16       
    85 : mov                 i13, 256         
    86 : broadcast.u32       v10, i13         
    87 : vst.u32             i0, v10          
    88 : add                 i0, i0, 16       
    89 : annotation:else     16, 17           
    90 : annotation:ifcstart                  
    91 : cmp                 i1, 6            
    92 : jmp_ne              __loops_label_19 
    93 : annotation:ifcend                    
    94 : mov                 i14, 65408       
    95 : arm_movk            i14, 65535, 16   
    96 : broadcast.i32       v11, i14         
    97 : vst.i32             i0, v11          
    98 : add                 i0, i0, 16       
    99 : mov                 i15, 65407       
   100 : arm_movk            i15, 65535, 16   
   101 : broadcast.i32       v12, i15         
   102 : vst.i32             i0, v12          
   103 : add                 i0, i0, 16       
   104 : annotation:else     19, 20           
   105 : annotation:ifcstart                  
   106 : cmp                 i1, 7            
   107 : jmp_ne              __loops_label_22 
   108 : annotation:ifcend                    
   109 : mov                 v13, 0           
   110 : vst.u64             i0, v13          
   111 : add                 i0, i0, 16       
   112 : mov                 v14, 255         
   113 : vst.u64             i0, v14          
   114 : add                 i0, i0, 16       
   115 : mov                 v15, 65280       
   116 : vst.u64             i0, v15          
   117 : add                 i0, i0, 16       
   118 : annotation:else     22, 23           
   119 : annotation:ifcstart                  
   120 : cmp                 i1, 8            
   121 : jmp_ne              __loops_label_25 
   122 : annotation:ifcend                    
   123 : mov                 v16, -256        
   124 : vst.i64             i0, v16          
   125 : add                 i0, i0, 16       
   126 : annotation:else     25, 26           
   127 : annotation:ifcstart                  
   128 : cmp                 i1, 9            
   129 : jmp_ne              __loops_label_28 
   130 : annotation:ifcend                    
   131 : mov                 i16, 256         
   132 : broadcast.u64       v17, i16         
   133 : vst.u64             i0, v17          
   134 : add                 i2, i0, 16       
   135 : mov                 i17, 254         
   136 : broadcast.u64       v18, i17         
   137 : vst.u64             i2, v18          
   138 : add                 i3, i2, 16       
   139 : annotation:endif    2                
   140 : annotation:endif    5                
   141 : annotation:endif    8                
   142 : annotation:endif    11               
   143 : annotation:endif    14               
   144 : annotation:endif    17               
   145 : annotation:endif    20               
   146 : annotation:endif    23               
   147 : annotation:endif    26               
   148 : annotation:endif    28               
   149 : ret                                  
