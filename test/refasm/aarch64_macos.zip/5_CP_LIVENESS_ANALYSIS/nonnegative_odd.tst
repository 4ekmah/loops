nonnegative_odd(i0, i1)
     0 : mov                    i3, 0           
     1 : mov                    i4, -4          
     2 : mov                    i8, 4           
     3 : mul                    i2, i1, i8      
     4 : annotation:whilecstart 0               
     5 : cmp                    i3, i2          
     6 : jmp_ge                 __loops_label_2 
     7 : annotation:whilecend                   
     8 : load.i32               i6, i0, i3      
     9 : annotation:ifcstart                    
    10 : cmp                    i6, 0           
    11 : jmp_ge                 __loops_label_4 
    12 : annotation:ifcend                      
    13 : add                    i3, i3, 4       
    14 : annotation:break       0               
    15 : annotation:endif       4               
    16 : mov                    i9, 2           
    17 : mod                    i7, i6, i9      
    18 : annotation:ifcstart                    
    19 : cmp                    i7, 0           
    20 : jmp_eq                 __loops_label_6 
    21 : annotation:ifcend                      
    22 : mov                    i4, i3          
    23 : annotation:break       2               
    24 : annotation:endif       6               
    25 : add                    i3, i3, 4       
    26 : annotation:endwhile    0, 2            
    27 : mov                    i10, 4          
    28 : div                    i5, i4, i10     
    29 : mov                    iR, i5          
    30 : ret                                    
