bresenham(i0, i1, i2, i3, i4, i5, i6)
     0 : sub                    i8, i4, i2       
     1 : cmp                    i8, 0            
     2 : arm_cneg               i7, i8, 33       
     3 : sub                    i11, i4, i2      
     4 : cmp                    i11, 0           
     5 : sar                    i9, i11, 63      
     6 : arm_cinc               i10, i9, 30      
     7 : sub                    i14, i5, i3      
     8 : cmp                    i14, 0           
     9 : arm_cneg               i13, i14, 33     
    10 : neg                    i12, i13         
    11 : sub                    i17, i5, i3      
    12 : cmp                    i17, 0           
    13 : sar                    i15, i17, 63     
    14 : arm_cinc               i16, i15, 30     
    15 : add                    i18, i7, i12     
    16 : annotation:whilecstart 0                
    17 : cmp                    i0, 0            
    18 : jmp_eq                 __loops_label_2  
    19 : annotation:whilecend                    
    20 : mul                    i20, i3, i1      
    21 : add                    i19, i20, i2     
    22 : store.u8               i0, i19, i6      
    23 : annotation:ifcstart                     
    24 : cmp                    i2, i4           
    25 : jmp_ne                 __loops_label_4  
    26 : cmp                    i3, i5           
    27 : jmp_ne                 __loops_label_4  
    28 : annotation:ifcend                       
    29 : annotation:break       2                
    30 : annotation:endif       4                
    31 : shl                    i21, i18, 1      
    32 : annotation:ifcstart                     
    33 : cmp                    i21, i12         
    34 : jmp_gt                 __loops_label_6  
    35 : annotation:ifcend                       
    36 : annotation:ifcstart                     
    37 : cmp                    i2, i4           
    38 : jmp_ne                 __loops_label_8  
    39 : annotation:ifcend                       
    40 : annotation:break       2                
    41 : annotation:endif       8                
    42 : add                    i18, i18, i12    
    43 : add                    i2, i2, i10      
    44 : annotation:endif       6                
    45 : annotation:ifcstart                     
    46 : cmp                    i21, i7          
    47 : jmp_gt                 __loops_label_10 
    48 : annotation:ifcend                       
    49 : annotation:ifcstart                     
    50 : cmp                    i3, i5           
    51 : jmp_ne                 __loops_label_12 
    52 : annotation:ifcend                       
    53 : annotation:break       2                
    54 : annotation:endif       12               
    55 : add                    i18, i18, i7     
    56 : add                    i3, i3, i16      
    57 : annotation:endif       10               
    58 : annotation:endwhile    0, 2             
    59 : ret                                     
