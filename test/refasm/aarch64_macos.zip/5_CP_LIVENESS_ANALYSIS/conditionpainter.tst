conditionpainter(i0)
     0 : mov                    i1, -5          
     1 : annotation:whilecstart 0               
     2 : cmp                    i1, 5           
     3 : jmp_gt                 __loops_label_2 
     4 : annotation:whilecend                   
     5 : add                    i4, i1, 5       
     6 : mov                    i55, 11         
     7 : mul                    i3, i4, i55     
     8 : mov                    i56, 8          
     9 : mul                    i2, i3, i56     
    10 : mov                    i5, -5          
    11 : annotation:whilecstart 3               
    12 : cmp                    i5, 5           
    13 : jmp_gt                 __loops_label_5 
    14 : annotation:whilecend                   
    15 : add                    i11, i5, 3      
    16 : cmp                    i1, i11         
    17 : iverson_ge             i12             
    18 : cmp                    i1, 4           
    19 : iverson_le             i13             
    20 : and                    i10, i12, i13   
    21 : mov                    i57, -2         
    22 : cmp                    i5, i57         
    23 : iverson_ge             i14             
    24 : and                    i9, i10, i14    
    25 : cmp                    i5, 0           
    26 : iverson_le             i15             
    27 : and                    i8, i9, i15     
    28 : sub                    i19, i5, 1      
    29 : cmp                    i1, i19         
    30 : iverson_le             i20             
    31 : cmp                    i5, 0           
    32 : iverson_ge             i21             
    33 : and                    i18, i20, i21   
    34 : cmp                    i1, 0           
    35 : iverson_le             i22             
    36 : and                    i17, i18, i22   
    37 : mul                    i24, i5, i5     
    38 : mul                    i25, i1, i1     
    39 : add                    i23, i24, i25   
    40 : cmp                    i23, 9          
    41 : iverson_le             i26             
    42 : and                    i16, i17, i26   
    43 : or                     i6, i8, i16     
    44 : mov                    i27, 2          
    45 : mov                    i28, 0          
    46 : cmp                    i5, 2           
    47 : iverson_ge             i32             
    48 : cmp                    i5, 4           
    49 : iverson_le             i33             
    50 : and                    i31, i32, i33   
    51 : cmp                    i1, 1           
    52 : iverson_ge             i35             
    53 : cmp                    i1, 3           
    54 : iverson_le             i36             
    55 : and                    i34, i35, i36   
    56 : or                     i30, i31, i34   
    57 : mul                    i38, i5, i5     
    58 : mul                    i39, i1, i1     
    59 : add                    i37, i38, i39   
    60 : cmp                    i37, 16         
    61 : iverson_le             i40             
    62 : and                    i29, i30, i40   
    63 : cmp                    i29, 0          
    64 : select_ne              i41, i27, i28   
    65 : add                    i7, i6, i41     
    66 : annotation:ifcstart                    
    67 : mov                    i58, 2          
    68 : mul                    i42, i1, i58    
    69 : cmp                    i42, i5         
    70 : jmp_gt                 __loops_label_8 
    71 : add                    i45, i5, 3      
    72 : neg                    i44, i45        
    73 : add                    i46, i5, 3      
    74 : mul                    i43, i44, i46   
    75 : cmp                    i1, i43         
    76 : jmp_le                 __loops_label_9 
    77 : __loops_label_8:                       
    78 : mov                    i59, 2          
    79 : mul                    i47, i5, i59    
    80 : cmp                    i1, i47         
    81 : jmp_gt                 __loops_label_7 
    82 : add                    i50, i5, 3      
    83 : neg                    i49, i50        
    84 : add                    i51, i5, 3      
    85 : mul                    i48, i49, i51   
    86 : cmp                    i1, i48         
    87 : jmp_gt                 __loops_label_7 
    88 : __loops_label_9:                       
    89 : cmp                    i5, 0           
    90 : jmp_gt                 __loops_label_7 
    91 : annotation:ifcend                      
    92 : add                    i7, i7, 3       
    93 : annotation:endif       7               
    94 : add                    i54, i5, 5      
    95 : shl                    i53, i54, 3     
    96 : add                    i52, i2, i53    
    97 : store.i64              i0, i52, i7     
    98 : add                    i5, i5, 1       
    99 : annotation:endwhile    3, 5            
   100 : add                    i1, i1, 1       
   101 : annotation:endwhile    0, 2            
   102 : ret                                    
