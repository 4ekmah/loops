fixed_power_v_uint32_t_4(i0, i1, i2)
     0 : mov                    i4, 0           
     1 : mov                    i5, 4           
     2 : mul                    i3, i2, i5      
     3 : annotation:whilecstart 0               
     4 : cmp                    i4, i3          
     5 : jmp_ge                 __loops_label_2 
     6 : annotation:whilecend                   
     7 : vld.u32                v0, i0, i4      
     8 : mul.u32                v2, v0, v0      
     9 : mul.u32                v1, v2, v2      
    10 : vst.u32                i1, i4, v1      
    11 : add                    i4, i4, 16      
    12 : annotation:endwhile    0, 2            
    13 : mov                    iR, 0           
    14 : ret                                    
