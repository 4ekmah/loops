fixed_power_v_double_0(i0, i1, i2)
     0 : mov                    i4, 0           
     1 : mov                    i5, 8           
     2 : mul                    i3, i2, i5      
     3 : annotation:whilecstart 0               
     4 : cmp                    i4, i3          
     5 : jmp_ge                 __loops_label_2 
     6 : annotation:whilecend                   
     7 : vld.fp64               v0, i0, i4      
     8 : mov                    i6, 0           
     9 : arm_movk               i6, 16368, 48   
    10 : broadcast.fp64         v1, i6          
    11 : vst.fp64               i1, i4, v1      
    12 : add                    i4, i4, 16      
    13 : annotation:endwhile    0, 2            
    14 : mov                    iR, 0           
    15 : ret                                    
