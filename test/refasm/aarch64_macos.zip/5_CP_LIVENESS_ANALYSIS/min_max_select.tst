min_max_select(i0, i1, i2, i3)
     0 : mov                    i5, 0           
     1 : mov                    i6, 0           
     2 : mov                    i8, 0           
     3 : load.i32               i10, i0         
     4 : mov                    i11, i10        
     5 : shl                    i4, i1, 2       
     6 : annotation:whilecstart 0               
     7 : cmp                    i5, i4          
     8 : jmp_ge                 __loops_label_2 
     9 : annotation:whilecend                   
    10 : load.i32               i12, i0, i5     
    11 : cmp                    i12, i10        
    12 : select_gt              i6, i5, i6      
    13 : min                    i10, i12, i10   
    14 : cmp                    i12, i11        
    15 : select_gt              i8, i5, i8      
    16 : max                    i11, i12, i11   
    17 : add                    i5, i5, 4       
    18 : annotation:endwhile    0, 2            
    19 : sar                    i7, i6, 2       
    20 : sar                    i9, i8, 2       
    21 : store.i32              i2, i7          
    22 : store.i32              i3, i9          
    23 : mov                    iR, 0           
    24 : ret                                    
