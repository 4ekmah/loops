nullify_msb_lsb_v(i0, i1, i2, i3)
     0 : mov                    i5, 0           
     1 : mov                    i6, 4           
     2 : mul                    i4, i3, i6      
     3 : mov                    v0, 1           
     4 : annotation:whilecstart 0               
     5 : cmp                    i5, i4          
     6 : jmp_ge                 __loops_label_2 
     7 : annotation:whilecend                   
     8 : vld.u32                v1, i0, i5      
     9 : shr.u32                v10, v1, 1      
    10 : or                     v2, v1, v10     
    11 : shr.u32                v11, v2, 2      
    12 : or                     v3, v2, v11     
    13 : shr.u32                v12, v3, 4      
    14 : or                     v4, v3, v12     
    15 : shr.u32                v13, v4, 8      
    16 : or                     v5, v4, v13     
    17 : shr.u32                v14, v5, 16     
    18 : or                     v6, v5, v14     
    19 : add.u32                v7, v6, v0      
    20 : shr.u32                v8, v7, 1       
    21 : xor                    v9, v8, v1      
    22 : vst.u32                i1, i5, v9      
    23 : sub.u32                v18, v1, v0     
    24 : not                    v17, v18        
    25 : and                    v15, v1, v17    
    26 : xor                    v16, v15, v1    
    27 : vst.u32                i2, i5, v16     
    28 : add                    i5, i5, 16      
    29 : annotation:endwhile    0, 2            
    30 : ret                                    
