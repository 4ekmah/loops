nullify_msb_lsb_v(i0, i1, i2, i3)
     0 : sub  sp, sp, #0x20       ; ff 83 00 d1  
     1 : str  x25, [sp, #0x08]    ; f9 07 00 f9  
     2 : str  x26, [sp, #0x10]    ; fa 0b 00 f9  
     3 : eor  x26, x26, x26       ; 5a 03 1a ca  
     4 : str  x26, [sp, #0]       ; fa 03 00 f9  
     5 : mov  x25, #0x04          ; 99 00 80 d2  
     6 : mul  x3, x3, x25         ; 63 7c 19 9b  
     7 : movi v0.4s, #0x01        ; 20 04 00 4f  
     8 :      Loops_label_0:      ;              
     9 : ldr  x26, [sp, #0]       ; fa 03 40 f9  
    10 : cmp  x26, x3             ; 5f 03 03 eb  
    11 : b.ge Loops_label_2       ; 8a 03 00 54  
    12 : ldr  x26, [sp, #0]       ; fa 03 40 f9  
    13 : ldr  q1, [x0, x26]       ; 01 68 fa 3c  
    14 : ushr v2.4s, v1.4s, #0x01 ; 22 04 3f 6f  
    15 : orr  v2.4s, v1.4s, v2.4s ; 22 1c a2 4e  
    16 : ushr v3.4s, v2.4s, #0x02 ; 43 04 3e 6f  
    17 : orr  v2.4s, v2.4s, v3.4s ; 42 1c a3 4e  
    18 : ushr v3.4s, v2.4s, #0x04 ; 43 04 3c 6f  
    19 : orr  v2.4s, v2.4s, v3.4s ; 42 1c a3 4e  
    20 : ushr v3.4s, v2.4s, #0x08 ; 43 04 38 6f  
    21 : orr  v2.4s, v2.4s, v3.4s ; 42 1c a3 4e  
    22 : ushr v3.4s, v2.4s, #0x10 ; 43 04 30 6f  
    23 : orr  v2.4s, v2.4s, v3.4s ; 42 1c a3 4e  
    24 : add  v2.4s, v2.4s, v0.4s ; 42 84 a0 4e  
    25 : ushr v2.4s, v2.4s, #0x01 ; 42 04 3f 6f  
    26 : eor  v2.4s, v2.4s, v1.4s ; 42 1c 21 6e  
    27 : ldr  x26, [sp, #0]       ; fa 03 40 f9  
    28 : str  q2, [x1, x26]       ; 22 68 ba 3c  
    29 : sub  v2.4s, v1.4s, v0.4s ; 22 84 a0 6e  
    30 : mvn  v2.4s, v2.4s        ; 42 58 20 6e  
    31 : and  v2.4s, v1.4s, v2.4s ; 22 1c 22 4e  
    32 : eor  v1.4s, v2.4s, v1.4s ; 41 1c 21 6e  
    33 : ldr  x26, [sp, #0]       ; fa 03 40 f9  
    34 : str  q1, [x2, x26]       ; 41 68 ba 3c  
    35 : ldr  x26, [sp, #0]       ; fa 03 40 f9  
    36 : add  x26, x26, #0x10     ; 5a 43 00 91  
    37 : str  x26, [sp, #0]       ; fa 03 00 f9  
    38 : b    Loops_label_0       ; e3 ff ff 17  
    39 :      Loops_label_2:      ;              
    40 : ldr  x25, [sp, #0x08]    ; f9 07 40 f9  
    41 : ldr  x26, [sp, #0x10]    ; fa 0b 40 f9  
    42 : add  sp, sp, #0x20       ; ff 83 00 91  
    43 : ret  x30                 ; c0 03 5f d6  
