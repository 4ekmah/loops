fixed_power_v_double_0(i0, i1, i2)
     0 : sub  sp, sp, #0x10         ; ff 43 00 d1  
     1 : str  x25, [sp, #0]         ; f9 03 00 f9  
     2 : eor  x3, x3, x3            ; 63 00 03 ca  
     3 : mov  x25, #0x08            ; 19 01 80 d2  
     4 : mul  x2, x2, x25           ; 42 7c 19 9b  
     5 :      Loops_label_0:        ;              
     6 : cmp  x3, x2                ; 7f 00 02 eb  
     7 : b.ge Loops_label_2         ; 0a 01 00 54  
     8 : ldr  q0, [x0, x3]          ; 00 68 e3 3c  
     9 : eor  x25, x25, x25         ; 39 03 19 ca  
    10 : movk x25, #0x3ff0, lsl #48 ; 19 fe e7 f2  
    11 : dup  v0.2d, x25            ; 20 0f 08 4e  
    12 : str  q0, [x1, x3]          ; 20 68 a3 3c  
    13 : add  x3, x3, #0x10         ; 63 40 00 91  
    14 : b    Loops_label_0         ; f8 ff ff 17  
    15 :      Loops_label_2:        ;              
    16 : eor  x0, x0, x0            ; 00 00 00 ca  
    17 : ldr  x25, [sp, #0]         ; f9 03 40 f9  
    18 : add  sp, sp, #0x10         ; ff 43 00 91  
    19 : ret  x30                   ; c0 03 5f d6  
