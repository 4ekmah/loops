exp_f32(i0, i1, i2)
     0 : sub    sp, sp, #0x30          ; ff c3 00 d1  
     1 : str    q16, [sp, #0x10]       ; f0 07 80 3d  
     2 : str    q17, [sp, #0x20]       ; f1 0b 80 3d  
     3 : mov    x3, #0xc0a5            ; a3 14 98 d2  
     4 : movk   x3, #0xc2b0, lsl #16   ; 03 56 b8 f2  
     5 : dup    v0.4s, w3              ; 60 0c 04 4e  
     6 : mov    x3, #0xc0a5            ; a3 14 98 d2  
     7 : movk   x3, #0x42b0, lsl #16   ; 03 56 a8 f2  
     8 : dup    v1.4s, w3              ; 61 0c 04 4e  
     9 : eor    x3, x3, x3             ; 63 00 03 ca  
    10 : movk   x3, #0x3f00, lsl #16   ; 03 e0 a7 f2  
    11 : dup    v2.4s, w3              ; 62 0c 04 4e  
    12 : eor    x3, x3, x3             ; 63 00 03 ca  
    13 : movk   x3, #0x3f80, lsl #16   ; 03 f0 a7 f2  
    14 : dup    v3.4s, w3              ; 63 0c 04 4e  
    15 : mov    x3, #0xaa3b            ; 63 47 95 d2  
    16 : movk   x3, #0x3fb8, lsl #16   ; 03 f7 a7 f2  
    17 : dup    v4.4s, w3              ; 64 0c 04 4e  
    18 : mov    x3, #0x8000            ; 03 00 90 d2  
    19 : movk   x3, #0xbf31, lsl #16   ; 23 e6 b7 f2  
    20 : dup    v5.4s, w3              ; 65 0c 04 4e  
    21 : mov    x3, #0x8083            ; 63 10 90 d2  
    22 : movk   x3, #0x395e, lsl #16   ; c3 2b a7 f2  
    23 : dup    v6.4s, w3              ; 66 0c 04 4e  
    24 : mov    x3, #0x6967            ; e3 2c 8d d2  
    25 : movk   x3, #0x3950, lsl #16   ; 03 2a a7 f2  
    26 : dup    v7.4s, w3              ; 67 0c 04 4e  
    27 : mov    x3, #0x43ce            ; c3 79 88 d2  
    28 : movk   x3, #0x3ab7, lsl #16   ; e3 56 a7 f2  
    29 : dup    v8.4s, w3              ; 68 0c 04 4e  
    30 : mov    x3, #0x8908            ; 03 21 91 d2  
    31 : movk   x3, #0x3c08, lsl #16   ; 03 81 a7 f2  
    32 : dup    v9.4s, w3              ; 69 0c 04 4e  
    33 : mov    x3, #0xa9c1            ; 23 38 95 d2  
    34 : movk   x3, #0x3d2a, lsl #16   ; 43 a5 a7 f2  
    35 : dup    v10.4s, w3             ; 6a 0c 04 4e  
    36 : mov    x3, #0xaaaa            ; 43 55 95 d2  
    37 : movk   x3, #0x3e2a, lsl #16   ; 43 c5 a7 f2  
    38 : dup    v11.4s, w3             ; 6b 0c 04 4e  
    39 : eor    x3, x3, x3             ; 63 00 03 ca  
    40 : movk   x3, #0x3f00, lsl #16   ; 03 e0 a7 f2  
    41 : dup    v12.4s, w3             ; 6c 0c 04 4e  
    42 : movi   v13.4s, #0x7f          ; ed 07 03 4f  
    43 : eor    x3, x3, x3             ; 63 00 03 ca  
    44 :        Loops_label_0:         ;              
    45 : cmp    x2, #0                 ; 5f 00 00 f1  
    46 : b.le   Loops_label_2          ; 4d 05 00 54  
    47 : ldr    q14, [x1, x3]          ; 2e 68 e3 3c  
    48 : fmin   v14.4s, v14.4s, v1.4s  ; ce f5 a1 4e  
    49 : fmax   v14.4s, v14.4s, v0.4s  ; ce f5 20 4e  
    50 : mov    v15.4s, v2.4s          ; 4f 1c a2 4e  
    51 : fmla   v15.4s, v14.4s, v4.4s  ; cf cd 24 4e  
    52 : fcvtms v15.4s, v15.4s         ; ef b9 21 4e  
    53 : scvtf  v16.4s, v15.4s         ; f0 d9 21 4e  
    54 : fmla   v14.4s, v16.4s, v5.4s  ; 0e ce 25 4e  
    55 : fmla   v14.4s, v16.4s, v6.4s  ; 0e ce 26 4e  
    56 : mov    v16.4s, v8.4s          ; 10 1d a8 4e  
    57 : fmla   v16.4s, v14.4s, v7.4s  ; d0 cd 27 4e  
    58 : str    q0, [sp, #0]           ; e0 03 80 3d  
    59 : mov    v0.4s, v16.4s          ; 00 1e b0 4e  
    60 : mov    v16.4s, v9.4s          ; 30 1d a9 4e  
    61 : fmla   v16.4s, v0.4s, v14.4s  ; 10 cc 2e 4e  
    62 : ldr    q0, [sp, #0]           ; e0 03 c0 3d  
    63 : str    q0, [sp, #0]           ; e0 03 80 3d  
    64 : mov    v0.4s, v16.4s          ; 00 1e b0 4e  
    65 : mov    v16.4s, v10.4s         ; 50 1d aa 4e  
    66 : fmla   v16.4s, v0.4s, v14.4s  ; 10 cc 2e 4e  
    67 : ldr    q0, [sp, #0]           ; e0 03 c0 3d  
    68 : str    q0, [sp, #0]           ; e0 03 80 3d  
    69 : mov    v0.4s, v16.4s          ; 00 1e b0 4e  
    70 : mov    v16.4s, v11.4s         ; 70 1d ab 4e  
    71 : fmla   v16.4s, v0.4s, v14.4s  ; 10 cc 2e 4e  
    72 : ldr    q0, [sp, #0]           ; e0 03 c0 3d  
    73 : str    q0, [sp, #0]           ; e0 03 80 3d  
    74 : mov    v0.4s, v16.4s          ; 00 1e b0 4e  
    75 : mov    v16.4s, v12.4s         ; 90 1d ac 4e  
    76 : fmla   v16.4s, v0.4s, v14.4s  ; 10 cc 2e 4e  
    77 : ldr    q0, [sp, #0]           ; e0 03 c0 3d  
    78 : fmul   v17.4s, v14.4s, v14.4s ; d1 dd 2e 6e  
    79 : fmla   v14.4s, v16.4s, v17.4s ; 0e ce 31 4e  
    80 : fadd   v14.4s, v14.4s, v3.4s  ; ce d5 23 4e  
    81 : add    v15.4s, v15.4s, v13.4s ; ef 85 ad 4e  
    82 : shl    v15.4s, v15.4s, #0x17  ; ef 55 37 4f  
    83 : fmul   v14.4s, v14.4s, v15.4s ; ce dd 2f 6e  
    84 : str    q14, [x0, x3]          ; 0e 68 a3 3c  
    85 : add    x3, x3, #0x10          ; 63 40 00 91  
    86 : sub    x2, x2, #0x04          ; 42 10 00 d1  
    87 : b      Loops_label_0          ; d6 ff ff 17  
    88 :        Loops_label_2:         ;              
    89 : ldr    q16, [sp, #0x10]       ; f0 07 c0 3d  
    90 : ldr    q17, [sp, #0x20]       ; f1 0b c0 3d  
    91 : add    sp, sp, #0x30          ; ff c3 00 91  
    92 : ret    x30                    ; c0 03 5f d6  
