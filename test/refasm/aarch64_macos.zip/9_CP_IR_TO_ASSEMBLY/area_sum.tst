area_sum(i0, i1)
     0 : sub   sp, sp, #0x1d0                                 ; ff 43 07 d1  
     1 : str   x0, [sp, #0x1a0]                               ; e0 d3 00 f9  
     2 : str   x1, [sp, #0x198]                               ; e1 cf 00 f9  
     3 : str   x25, [sp, #0x1a8]                              ; f9 d7 00 f9  
     4 : str   x26, [sp, #0x1b0]                              ; fa db 00 f9  
     5 : stp   x29, x30, [sp, #0x1c0]                         ; fd 7b 1c a9  
     6 : mov   x29, sp                                        ; fd 03 1f aa  
     7 : eor   x26, x26, x26                                  ; 5a 03 1a ca  
     8 : str   x26, [sp, #0x190]                              ; fa cb 00 f9  
     9 :       Loops_label_0:                                 ;              
    10 : ldr   x26, [sp, #0x198]                              ; fa cf 40 f9  
    11 : cmp   x26, #0                                        ; 5f 03 00 f1  
    12 : b.le  Loops_label_2                                  ; 2d 11 00 54  
    13 : ldr   x26, [sp, #0x1a0]                              ; fa d3 40 f9  
    14 : ldrsb x3, [x26, #0]                                  ; 43 03 80 39  
    15 : mov   x25, #0xf92c                                   ; 99 25 9f d2  
    16 : movk  x25, #0x415, lsl #16                           ; b9 82 a0 f2  
    17 : movk  x25, #0x01, lsl #32                            ; 39 00 c0 f2  
    18 : mov   x2, #0xf9c4                                    ; 82 38 9f d2  
    19 : movk  x2, #0x415, lsl #16                            ; a2 82 a0 f2  
    20 : movk  x2, #0x01, lsl #32                             ; 22 00 c0 f2  
    21 : mov   x1, #0xfa38                                    ; 01 47 9f d2  
    22 : movk  x1, #0x415, lsl #16                            ; a1 82 a0 f2  
    23 : movk  x1, #0x01, lsl #32                             ; 21 00 c0 f2  
    24 : cmp   x3, #0x01                                      ; 7f 04 00 f1  
    25 : csel  x1, x2, x1, eq                                 ; 41 00 81 9a  
    26 : cmp   x3, #0                                         ; 7f 00 00 f1  
    27 : csel  x1, x25, x1, eq                                ; 21 03 81 9a  
    28 : mov   x2, #0xfafc                                    ; 82 5f 9f d2  
    29 : movk  x2, #0x415, lsl #16                            ; a2 82 a0 f2  
    30 : movk  x2, #0x01, lsl #32                             ; 22 00 c0 f2  
    31 : mov   x25, #0xfb5c                                   ; 99 6b 9f d2  
    32 : movk  x25, #0x415, lsl #16                           ; b9 82 a0 f2  
    33 : movk  x25, #0x01, lsl #32                            ; 39 00 c0 f2  
    34 : mov   x0, #0xfba8                                    ; 00 75 9f d2  
    35 : movk  x0, #0x415, lsl #16                            ; a0 82 a0 f2  
    36 : movk  x0, #0x01, lsl #32                             ; 20 00 c0 f2  
    37 : cmp   x3, #0x01                                      ; 7f 04 00 f1  
    38 : csel  x0, x25, x0, eq                                ; 20 03 80 9a  
    39 : cmp   x3, #0                                         ; 7f 00 00 f1  
    40 : csel  x0, x2, x0, eq                                 ; 40 00 80 9a  
    41 : ldr   x26, [sp, #0x1a0]                              ; fa d3 40 f9  
    42 : stp   x0, x1, [sp, #0]                               ; e0 07 00 a9  
    43 : stp   x2, x3, [sp, #0x10]                            ; e2 0f 01 a9  
    44 : stp   x4, x5, [sp, #0x20]                            ; e4 17 02 a9  
    45 : stp   x6, x7, [sp, #0x30]                            ; e6 1f 03 a9  
    46 : stp   x8, x9, [sp, #0x40]                            ; e8 27 04 a9  
    47 : stp   x10, x11, [sp, #0x50]                          ; ea 2f 05 a9  
    48 : stp   x12, x13, [sp, #0x60]                          ; ec 37 06 a9  
    49 : stp   x14, x15, [sp, #0x70]                          ; ee 3f 07 a9  
    50 : stp   x16, x17, [sp, #0x80]                          ; f0 47 08 a9  
    51 : mov   x0, x26                                        ; e0 03 1a aa  
    52 : add   x10, sp, #0x90                                 ; ea 43 02 91  
    53 : st1   {v0.2d, v1.2d, v2.2d, v3.2d}, [x10], #0x40     ; 40 2d 9f 4c  
    54 : st1   {v4.2d, v5.2d, v6.2d, v7.2d}, [x10], #0x40     ; 44 2d 9f 4c  
    55 : st1   {v8.2d, v9.2d, v10.2d, v11.2d}, [x10], #0x40   ; 48 2d 9f 4c  
    56 : st1   {v12.2d, v13.2d, v14.2d, v15.2d}, [x10], #0x40 ; 4c 2d 9f 4c  
    57 : blr   x1                                             ; 20 00 3f d6  
    58 : add   x10, sp, #0x90                                 ; ea 43 02 91  
    59 : ld1   {v0.2d, v1.2d, v2.2d, v3.2d}, [x10], #0x40     ; 40 2d df 4c  
    60 : ld1   {v4.2d, v5.2d, v6.2d, v7.2d}, [x10], #0x40     ; 44 2d df 4c  
    61 : ld1   {v8.2d, v9.2d, v10.2d, v11.2d}, [x10], #0x40   ; 48 2d df 4c  
    62 : ld1   {v12.2d, v13.2d, v14.2d, v15.2d}, [x10], #0x40 ; 4c 2d df 4c  
    63 : ldp   x0, x1, [sp, #0]                               ; e0 07 40 a9  
    64 : ldp   x2, x3, [sp, #0x10]                            ; e2 0f 41 a9  
    65 : ldp   x4, x5, [sp, #0x20]                            ; e4 17 42 a9  
    66 : ldp   x6, x7, [sp, #0x30]                            ; e6 1f 43 a9  
    67 : ldp   x8, x9, [sp, #0x40]                            ; e8 27 44 a9  
    68 : ldp   x10, x11, [sp, #0x50]                          ; ea 2f 45 a9  
    69 : ldp   x12, x13, [sp, #0x60]                          ; ec 37 46 a9  
    70 : ldp   x14, x15, [sp, #0x70]                          ; ee 3f 47 a9  
    71 : ldp   x16, x17, [sp, #0x80]                          ; f0 47 48 a9  
    72 : ldr   x26, [sp, #0x1a0]                              ; fa d3 40 f9  
    73 : stp   x0, x1, [sp, #0]                               ; e0 07 00 a9  
    74 : stp   x2, x3, [sp, #0x10]                            ; e2 0f 01 a9  
    75 : stp   x4, x5, [sp, #0x20]                            ; e4 17 02 a9  
    76 : stp   x6, x7, [sp, #0x30]                            ; e6 1f 03 a9  
    77 : stp   x8, x9, [sp, #0x40]                            ; e8 27 04 a9  
    78 : stp   x10, x11, [sp, #0x50]                          ; ea 2f 05 a9  
    79 : stp   x12, x13, [sp, #0x60]                          ; ec 37 06 a9  
    80 : stp   x14, x15, [sp, #0x70]                          ; ee 3f 07 a9  
    81 : stp   x16, x17, [sp, #0x80]                          ; f0 47 08 a9  
    82 : mov   x0, x26                                        ; e0 03 1a aa  
    83 : ldr   x9, [sp, #0]                                   ; e9 03 40 f9  
    84 : add   x10, sp, #0x90                                 ; ea 43 02 91  
    85 : st1   {v0.2d, v1.2d, v2.2d, v3.2d}, [x10], #0x40     ; 40 2d 9f 4c  
    86 : st1   {v4.2d, v5.2d, v6.2d, v7.2d}, [x10], #0x40     ; 44 2d 9f 4c  
    87 : st1   {v8.2d, v9.2d, v10.2d, v11.2d}, [x10], #0x40   ; 48 2d 9f 4c  
    88 : st1   {v12.2d, v13.2d, v14.2d, v15.2d}, [x10], #0x40 ; 4c 2d 9f 4c  
    89 : blr   x9                                             ; 20 01 3f d6  
    90 : add   x10, sp, #0x90                                 ; ea 43 02 91  
    91 : ld1   {v0.2d, v1.2d, v2.2d, v3.2d}, [x10], #0x40     ; 40 2d df 4c  
    92 : ld1   {v4.2d, v5.2d, v6.2d, v7.2d}, [x10], #0x40     ; 44 2d df 4c  
    93 : ld1   {v8.2d, v9.2d, v10.2d, v11.2d}, [x10], #0x40   ; 48 2d df 4c  
    94 : ld1   {v12.2d, v13.2d, v14.2d, v15.2d}, [x10], #0x40 ; 4c 2d df 4c  
    95 : ldr   x1, [sp, #0x08]                                ; e1 07 40 f9  
    96 : ldp   x2, x3, [sp, #0x10]                            ; e2 0f 41 a9  
    97 : ldp   x4, x5, [sp, #0x20]                            ; e4 17 42 a9  
    98 : ldp   x6, x7, [sp, #0x30]                            ; e6 1f 43 a9  
    99 : ldp   x8, x9, [sp, #0x40]                            ; e8 27 44 a9  
   100 : ldp   x10, x11, [sp, #0x50]                          ; ea 2f 45 a9  
   101 : ldp   x12, x13, [sp, #0x60]                          ; ec 37 46 a9  
   102 : ldp   x14, x15, [sp, #0x70]                          ; ee 3f 47 a9  
   103 : ldp   x16, x17, [sp, #0x80]                          ; f0 47 48 a9  
   104 : mov   x1, #0xfc30                                    ; 01 86 9f d2  
   105 : movk  x1, #0x415, lsl #16                            ; a1 82 a0 f2  
   106 : movk  x1, #0x01, lsl #32                             ; 21 00 c0 f2  
   107 : ldr   x26, [sp, #0x190]                              ; fa cb 40 f9  
   108 : stp   x0, x1, [sp, #0]                               ; e0 07 00 a9  
   109 : stp   x2, x3, [sp, #0x10]                            ; e2 0f 01 a9  
   110 : stp   x4, x5, [sp, #0x20]                            ; e4 17 02 a9  
   111 : stp   x6, x7, [sp, #0x30]                            ; e6 1f 03 a9  
   112 : stp   x8, x9, [sp, #0x40]                            ; e8 27 04 a9  
   113 : stp   x10, x11, [sp, #0x50]                          ; ea 2f 05 a9  
   114 : stp   x12, x13, [sp, #0x60]                          ; ec 37 06 a9  
   115 : stp   x14, x15, [sp, #0x70]                          ; ee 3f 07 a9  
   116 : stp   x16, x17, [sp, #0x80]                          ; f0 47 08 a9  
   117 : mov   x0, x26                                        ; e0 03 1a aa  
   118 : ldr   x1, [sp, #0]                                   ; e1 03 40 f9  
   119 : ldr   x9, [sp, #0x08]                                ; e9 07 40 f9  
   120 : add   x10, sp, #0x90                                 ; ea 43 02 91  
   121 : st1   {v0.2d, v1.2d, v2.2d, v3.2d}, [x10], #0x40     ; 40 2d 9f 4c  
   122 : st1   {v4.2d, v5.2d, v6.2d, v7.2d}, [x10], #0x40     ; 44 2d 9f 4c  
   123 : st1   {v8.2d, v9.2d, v10.2d, v11.2d}, [x10], #0x40   ; 48 2d 9f 4c  
   124 : st1   {v12.2d, v13.2d, v14.2d, v15.2d}, [x10], #0x40 ; 4c 2d 9f 4c  
   125 : blr   x9                                             ; 20 01 3f d6  
   126 : add   x10, sp, #0x90                                 ; ea 43 02 91  
   127 : ld1   {v0.2d, v1.2d, v2.2d, v3.2d}, [x10], #0x40     ; 40 2d df 4c  
   128 : ld1   {v4.2d, v5.2d, v6.2d, v7.2d}, [x10], #0x40     ; 44 2d df 4c  
   129 : ld1   {v8.2d, v9.2d, v10.2d, v11.2d}, [x10], #0x40   ; 48 2d df 4c  
   130 : ld1   {v12.2d, v13.2d, v14.2d, v15.2d}, [x10], #0x40 ; 4c 2d df 4c  
   131 : ldr   x1, [sp, #0x08]                                ; e1 07 40 f9  
   132 : ldp   x2, x3, [sp, #0x10]                            ; e2 0f 41 a9  
   133 : ldp   x4, x5, [sp, #0x20]                            ; e4 17 42 a9  
   134 : ldp   x6, x7, [sp, #0x30]                            ; e6 1f 43 a9  
   135 : ldp   x8, x9, [sp, #0x40]                            ; e8 27 44 a9  
   136 : ldp   x10, x11, [sp, #0x50]                          ; ea 2f 45 a9  
   137 : ldp   x12, x13, [sp, #0x60]                          ; ec 37 46 a9  
   138 : ldp   x14, x15, [sp, #0x70]                          ; ee 3f 47 a9  
   139 : ldp   x16, x17, [sp, #0x80]                          ; f0 47 48 a9  
   140 : mov   x26, x0                                        ; fa 03 00 aa  
   141 : str   x26, [sp, #0x190]                              ; fa cb 00 f9  
   142 : ldr   x26, [sp, #0x1a0]                              ; fa d3 40 f9  
   143 : add   x26, x26, #0x38                                ; 5a e3 00 91  
   144 : str   x26, [sp, #0x1a0]                              ; fa d3 00 f9  
   145 : ldr   x26, [sp, #0x198]                              ; fa cf 40 f9  
   146 : sub   x26, x26, #0x01                                ; 5a 07 00 d1  
   147 : str   x26, [sp, #0x198]                              ; fa cf 00 f9  
   148 : b     Loops_label_0                                  ; 76 ff ff 17  
   149 :       Loops_label_2:                                 ;              
   150 : ldr   x26, [sp, #0x190]                              ; fa cb 40 f9  
   151 : mov   x0, x26                                        ; e0 03 1a aa  
   152 : ldp   x29, x30, [sp, #0x1c0]                         ; fd 7b 5c a9  
   153 : ldr   x25, [sp, #0x1a8]                              ; f9 d7 40 f9  
   154 : ldr   x26, [sp, #0x1b0]                              ; fa db 40 f9  
   155 : add   sp, sp, #0x1d0                                 ; ff 43 07 91  
   156 : ret   x30                                            ; c0 03 5f d6  
