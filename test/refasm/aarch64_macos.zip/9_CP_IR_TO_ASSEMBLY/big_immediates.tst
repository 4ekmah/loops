big_immediates(i0, i1)
     0 : cmp  x1, #0                     ; 3f 00 00 f1  
     1 : b.ne Loops_label_1              ; 21 03 00 54  
     2 : mov  x2, #0xffff                ; e2 ff 9f d2  
     3 : str  x2, [x0, #0]               ; 02 00 00 f9  
     4 : add  x0, x0, #0x08              ; 00 20 00 91  
     5 : eor  x2, x2, x2                 ; 42 00 02 ca  
     6 : movk x2, #0x01, lsl #16         ; 22 00 a0 f2  
     7 : str  x2, [x0, #0]               ; 02 00 00 f9  
     8 : add  x0, x0, #0x08              ; 00 20 00 91  
     9 : movn x2, #0x7fff                ; e2 ff 8f 92  
    10 : str  x2, [x0, #0]               ; 02 00 00 f9  
    11 : add  x0, x0, #0x08              ; 00 20 00 91  
    12 : movn x2, #0x8000                ; 02 00 90 92  
    13 : str  x2, [x0, #0]               ; 02 00 00 f9  
    14 : add  x0, x0, #0x08              ; 00 20 00 91  
    15 : mov  x2, #0x59df                ; e2 3b 8b d2  
    16 : movk x2, #0x5f37, lsl #16       ; e2 e6 ab f2  
    17 : str  x2, [x0, #0]               ; 02 00 00 f9  
    18 : add  x0, x0, #0x08              ; 00 20 00 91  
    19 : mov  x2, #0x5769                ; 22 ed 8a d2  
    20 : movk x2, #0x8b14, lsl #16       ; 82 62 b1 f2  
    21 : movk x2, #0xbf0a, lsl #32       ; 42 e1 d7 f2  
    22 : movk x2, #0x4005, lsl #48       ; a2 00 e8 f2  
    23 : str  x2, [x0, #0]               ; 02 00 00 f9  
    24 : add  x0, x0, #0x08              ; 00 20 00 91  
    25 : b    Loops_label_28             ; 5e 00 00 14  
    26 :      Loops_label_1:             ;              
    27 : cmp  x1, #0x01                  ; 3f 04 00 f1  
    28 : b.ne Loops_label_4              ; 01 01 00 54  
    29 : movi v0.16b, #0                 ; 00 e4 00 4f  
    30 : str  q0, [x0, #0]               ; 00 00 80 3d  
    31 : add  x0, x0, #0x10              ; 00 40 00 91  
    32 : movi v0.16b, #0xff              ; e0 e7 07 4f  
    33 : str  q0, [x0, #0]               ; 00 00 80 3d  
    34 : add  x0, x0, #0x10              ; 00 40 00 91  
    35 : b    Loops_label_28             ; 55 00 00 14  
    36 :      Loops_label_4:             ;              
    37 : cmp  x1, #0x02                  ; 3f 08 00 f1  
    38 : b.ne Loops_label_7              ; a1 00 00 54  
    39 : movi v0.16b, #0x80              ; 00 e4 04 4f  
    40 : str  q0, [x0, #0]               ; 00 00 80 3d  
    41 : add  x0, x0, #0x10              ; 00 40 00 91  
    42 : b    Loops_label_28             ; 4f 00 00 14  
    43 :      Loops_label_7:             ;              
    44 : cmp  x1, #0x03                  ; 3f 0c 00 f1  
    45 : b.ne Loops_label_10             ; 81 01 00 54  
    46 : movi v0.8h, #0                  ; 00 84 00 4f  
    47 : str  q0, [x0, #0]               ; 00 00 80 3d  
    48 : add  x0, x0, #0x10              ; 00 40 00 91  
    49 : movi v0.8h, #0xff               ; e0 87 07 4f  
    50 : str  q0, [x0, #0]               ; 00 00 80 3d  
    51 : add  x0, x0, #0x10              ; 00 40 00 91  
    52 : mov  x2, #0x100                 ; 02 20 80 d2  
    53 : dup  v0.8h, w2                  ; 40 0c 02 4e  
    54 : str  q0, [x0, #0]               ; 00 00 80 3d  
    55 : add  x0, x0, #0x10              ; 00 40 00 91  
    56 : b    Loops_label_28             ; 42 00 00 14  
    57 :      Loops_label_10:            ;              
    58 : cmp  x1, #0x04                  ; 3f 10 00 f1  
    59 : b.ne Loops_label_13             ; 41 01 00 54  
    60 : mov  x2, #0xff80                ; 02 f0 9f d2  
    61 : dup  v0.8h, w2                  ; 40 0c 02 4e  
    62 : str  q0, [x0, #0]               ; 00 00 80 3d  
    63 : add  x0, x0, #0x10              ; 00 40 00 91  
    64 : mov  x2, #0xff7f                ; e2 ef 9f d2  
    65 : dup  v0.8h, w2                  ; 40 0c 02 4e  
    66 : str  q0, [x0, #0]               ; 00 00 80 3d  
    67 : add  x0, x0, #0x10              ; 00 40 00 91  
    68 : b    Loops_label_28             ; 37 00 00 14  
    69 :      Loops_label_13:            ;              
    70 : cmp  x1, #0x05                  ; 3f 14 00 f1  
    71 : b.ne Loops_label_16             ; 81 01 00 54  
    72 : movi v0.4s, #0                  ; 00 04 00 4f  
    73 : str  q0, [x0, #0]               ; 00 00 80 3d  
    74 : add  x0, x0, #0x10              ; 00 40 00 91  
    75 : movi v0.4s, #0xff               ; e0 07 07 4f  
    76 : str  q0, [x0, #0]               ; 00 00 80 3d  
    77 : add  x0, x0, #0x10              ; 00 40 00 91  
    78 : mov  x2, #0x100                 ; 02 20 80 d2  
    79 : dup  v0.4s, w2                  ; 40 0c 04 4e  
    80 : str  q0, [x0, #0]               ; 00 00 80 3d  
    81 : add  x0, x0, #0x10              ; 00 40 00 91  
    82 : b    Loops_label_28             ; 2a 00 00 14  
    83 :      Loops_label_16:            ;              
    84 : cmp  x1, #0x06                  ; 3f 18 00 f1  
    85 : b.ne Loops_label_19             ; 81 01 00 54  
    86 : mov  x2, #0xff80                ; 02 f0 9f d2  
    87 : movk x2, #0xffff, lsl #16       ; e2 ff bf f2  
    88 : dup  v0.4s, w2                  ; 40 0c 04 4e  
    89 : str  q0, [x0, #0]               ; 00 00 80 3d  
    90 : add  x0, x0, #0x10              ; 00 40 00 91  
    91 : mov  x2, #0xff7f                ; e2 ef 9f d2  
    92 : movk x2, #0xffff, lsl #16       ; e2 ff bf f2  
    93 : dup  v0.4s, w2                  ; 40 0c 04 4e  
    94 : str  q0, [x0, #0]               ; 00 00 80 3d  
    95 : add  x0, x0, #0x10              ; 00 40 00 91  
    96 : b    Loops_label_28             ; 1d 00 00 14  
    97 :      Loops_label_19:            ;              
    98 : cmp  x1, #0x07                  ; 3f 1c 00 f1  
    99 : b.ne Loops_label_22             ; 61 01 00 54  
   100 : movi v0.2d, #0                  ; 00 e4 00 6f  
   101 : str  q0, [x0, #0]               ; 00 00 80 3d  
   102 : add  x0, x0, #0x10              ; 00 40 00 91  
   103 : movi v0.2d, #0xff               ; 20 e4 00 6f  
   104 : str  q0, [x0, #0]               ; 00 00 80 3d  
   105 : add  x0, x0, #0x10              ; 00 40 00 91  
   106 : movi v0.2d, #0xff00             ; 40 e4 00 6f  
   107 : str  q0, [x0, #0]               ; 00 00 80 3d  
   108 : add  x0, x0, #0x10              ; 00 40 00 91  
   109 : b    Loops_label_28             ; 11 00 00 14  
   110 :      Loops_label_22:            ;              
   111 : cmp  x1, #0x08                  ; 3f 20 00 f1  
   112 : b.ne Loops_label_25             ; a1 00 00 54  
   113 : movi v0.2d, #0xffffffffffffff00 ; c0 e7 07 6f  
   114 : str  q0, [x0, #0]               ; 00 00 80 3d  
   115 : add  x0, x0, #0x10              ; 00 40 00 91  
   116 : b    Loops_label_28             ; 0b 00 00 14  
   117 :      Loops_label_25:            ;              
   118 : cmp  x1, #0x09                  ; 3f 24 00 f1  
   119 : b.ne Loops_label_28             ; 21 01 00 54  
   120 : mov  x1, #0x100                 ; 01 20 80 d2  
   121 : dup  v0.2d, x1                  ; 20 0c 08 4e  
   122 : str  q0, [x0, #0]               ; 00 00 80 3d  
   123 : add  x0, x0, #0x10              ; 00 40 00 91  
   124 : mov  x1, #0xfe                  ; c1 1f 80 d2  
   125 : dup  v0.2d, x1                  ; 20 0c 08 4e  
   126 : str  q0, [x0, #0]               ; 00 00 80 3d  
   127 : add  x0, x0, #0x10              ; 00 40 00 91  
   128 :      Loops_label_2:             ;              
   129 :      Loops_label_5:             ;              
   130 :      Loops_label_8:             ;              
   131 :      Loops_label_11:            ;              
   132 :      Loops_label_14:            ;              
   133 :      Loops_label_17:            ;              
   134 :      Loops_label_20:            ;              
   135 :      Loops_label_23:            ;              
   136 :      Loops_label_26:            ;              
   137 :      Loops_label_28:            ;              
   138 : ret  x30                        ; c0 03 5f d6  
