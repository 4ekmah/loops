triangle_types(i0, i1, i2)
     0 : sub  sp, sp, #0x20    ; ff 83 00 d1  
     1 : str  x1, [sp, #0]     ; e1 03 00 f9  
     2 : str  x25, [sp, #0x08] ; f9 07 00 f9  
     3 : str  x26, [sp, #0x10] ; fa 0b 00 f9  
     4 : cmp  x0, #0           ; 1f 00 00 f1  
     5 : b.le Loops_label_0    ; cd 00 00 54  
     6 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
     7 : cmp  x26, #0          ; 5f 03 00 f1  
     8 : b.le Loops_label_0    ; 6d 00 00 54  
     9 : cmp  x2, #0           ; 5f 00 00 f1  
    10 : b.gt Loops_label_1    ; 6c 00 00 54  
    11 :      Loops_label_0:   ;              
    12 : eor  x0, x0, x0       ; 00 00 00 ca  
    13 : b    Loops_label_18   ; 50 00 00 14  
    14 :      Loops_label_1:   ;              
    15 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
    16 : add  x3, x26, x2      ; 43 03 02 8b  
    17 : cmp  x0, x3           ; 1f 00 03 eb  
    18 : b.gt Loops_label_3    ; 2c 01 00 54  
    19 : add  x3, x0, x2       ; 03 00 02 8b  
    20 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
    21 : cmp  x26, x3          ; 5f 03 03 eb  
    22 : b.gt Loops_label_3    ; ac 00 00 54  
    23 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
    24 : add  x3, x0, x26      ; 03 00 1a 8b  
    25 : cmp  x2, x3           ; 5f 00 03 eb  
    26 : b.le Loops_label_4    ; 6d 00 00 54  
    27 :      Loops_label_3:   ;              
    28 : eor  x0, x0, x0       ; 00 00 00 ca  
    29 : b    Loops_label_18   ; 42 00 00 14  
    30 :      Loops_label_4:   ;              
    31 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
    32 : cmp  x0, x26          ; 1f 00 1a eb  
    33 : b.ne Loops_label_7    ; a1 00 00 54  
    34 : cmp  x0, x2           ; 1f 00 02 eb  
    35 : b.ne Loops_label_7    ; 61 00 00 54  
    36 : mov  x0, #0x02        ; 40 00 80 d2  
    37 : b    Loops_label_18   ; 3b 00 00 14  
    38 :      Loops_label_7:   ;              
    39 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
    40 : cmp  x0, x26          ; 1f 00 1a eb  
    41 : b.eq Loops_label_9    ; c0 00 00 54  
    42 : cmp  x0, x2           ; 1f 00 02 eb  
    43 : b.eq Loops_label_9    ; 80 00 00 54  
    44 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
    45 : cmp  x26, x2          ; 5f 03 02 eb  
    46 : b.ne Loops_label_10   ; 61 00 00 54  
    47 :      Loops_label_9:   ;              
    48 : mov  x0, #0x03        ; 60 00 80 d2  
    49 : b    Loops_label_18   ; 31 00 00 14  
    50 :      Loops_label_10:  ;              
    51 : mul  x3, x0, x0       ; 03 7c 00 9b  
    52 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
    53 : mul  x25, x26, x26    ; 59 7f 1a 9b  
    54 : mul  x1, x2, x2       ; 41 7c 02 9b  
    55 : add  x1, x25, x1      ; 21 03 01 8b  
    56 : cmp  x3, x1           ; 7f 00 01 eb  
    57 : b.eq Loops_label_12   ; e0 01 00 54  
    58 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
    59 : mul  x1, x26, x26     ; 41 7f 1a 9b  
    60 : mul  x3, x0, x0       ; 03 7c 00 9b  
    61 : mul  x25, x2, x2      ; 59 7c 02 9b  
    62 : add  x3, x3, x25      ; 63 00 19 8b  
    63 : cmp  x1, x3           ; 3f 00 03 eb  
    64 : b.eq Loops_label_12   ; 00 01 00 54  
    65 : mul  x1, x2, x2       ; 41 7c 02 9b  
    66 : mul  x3, x0, x0       ; 03 7c 00 9b  
    67 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
    68 : mul  x25, x26, x26    ; 59 7f 1a 9b  
    69 : add  x3, x3, x25      ; 63 00 19 8b  
    70 : cmp  x1, x3           ; 3f 00 03 eb  
    71 : b.ne Loops_label_13   ; 61 00 00 54  
    72 :      Loops_label_12:  ;              
    73 : mov  x0, #0x01        ; 20 00 80 d2  
    74 : b    Loops_label_18   ; 1a 00 00 14  
    75 :      Loops_label_13:  ;              
    76 : mul  x1, x0, x0       ; 01 7c 00 9b  
    77 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
    78 : mul  x3, x26, x26     ; 43 7f 1a 9b  
    79 : mul  x25, x2, x2      ; 59 7c 02 9b  
    80 : add  x3, x3, x25      ; 63 00 19 8b  
    81 : cmp  x1, x3           ; 3f 00 03 eb  
    82 : b.gt Loops_label_15   ; ec 01 00 54  
    83 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
    84 : mul  x1, x26, x26     ; 41 7f 1a 9b  
    85 : mul  x3, x0, x0       ; 03 7c 00 9b  
    86 : mul  x25, x2, x2      ; 59 7c 02 9b  
    87 : add  x3, x3, x25      ; 63 00 19 8b  
    88 : cmp  x1, x3           ; 3f 00 03 eb  
    89 : b.gt Loops_label_15   ; 0c 01 00 54  
    90 : mul  x1, x2, x2       ; 41 7c 02 9b  
    91 : mul  x0, x0, x0       ; 00 7c 00 9b  
    92 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
    93 : mul  x2, x26, x26     ; 42 7f 1a 9b  
    94 : add  x0, x0, x2       ; 00 00 02 8b  
    95 : cmp  x1, x0           ; 3f 00 00 eb  
    96 : b.le Loops_label_16   ; 6d 00 00 54  
    97 :      Loops_label_15:  ;              
    98 : mov  x0, #0x05        ; a0 00 80 d2  
    99 : b    Loops_label_18   ; 03 00 00 14  
   100 :      Loops_label_16:  ;              
   101 : mov  x0, #0x04        ; 80 00 80 d2  
   102 : b    Loops_label_18   ; 01 00 00 14  
   103 :      Loops_label_2:   ;              
   104 :      Loops_label_5:   ;              
   105 :      Loops_label_8:   ;              
   106 :      Loops_label_11:  ;              
   107 :      Loops_label_14:  ;              
   108 :      Loops_label_17:  ;              
   109 :      Loops_label_18:  ;              
   110 : ldr  x25, [sp, #0x08] ; f9 07 40 f9  
   111 : ldr  x26, [sp, #0x10] ; fa 0b 40 f9  
   112 : add  sp, sp, #0x20    ; ff 83 00 91  
   113 : ret  x30              ; c0 03 5f d6  
