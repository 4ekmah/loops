fixed_power_v_float_9(i0, i1, i2)
     0 : sub  sp, sp, #0x10       ; ff 43 00 d1  
     1 : str  x25, [sp, #0]       ; f9 03 00 f9  
     2 : eor  x3, x3, x3          ; 63 00 03 ca  
     3 : mov  x25, #0x04          ; 99 00 80 d2  
     4 : mul  x2, x2, x25         ; 42 7c 19 9b  
     5 :      Loops_label_0:      ;              
     6 : cmp  x3, x2              ; 7f 00 02 eb  
     7 : b.ge Loops_label_2       ; 2a 01 00 54  
     8 : ldr  q0, [x0, x3]        ; 00 68 e3 3c  
     9 : fmul v1.4s, v0.4s, v0.4s ; 01 dc 20 6e  
    10 : fmul v1.4s, v1.4s, v1.4s ; 21 dc 21 6e  
    11 : fmul v1.4s, v1.4s, v1.4s ; 21 dc 21 6e  
    12 : fmul v0.4s, v0.4s, v1.4s ; 00 dc 21 6e  
    13 : str  q0, [x1, x3]        ; 20 68 a3 3c  
    14 : add  x3, x3, #0x10       ; 63 40 00 91  
    15 : b    Loops_label_0       ; f7 ff ff 17  
    16 :      Loops_label_2:      ;              
    17 : eor  x0, x0, x0          ; 00 00 00 ca  
    18 : ldr  x25, [sp, #0]       ; f9 03 40 f9  
    19 : add  sp, sp, #0x10       ; ff 43 00 91  
    20 : ret  x30                 ; c0 03 5f d6  
