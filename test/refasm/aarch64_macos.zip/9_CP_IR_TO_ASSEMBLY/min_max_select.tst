min_max_select(i0, i1, i2, i3)
     0 : sub   sp, sp, #0x40     ; ff 03 01 d1  
     1 : str   x25, [sp, #0x28]  ; f9 17 00 f9  
     2 : str   x26, [sp, #0x30]  ; fa 1b 00 f9  
     3 : str   x2, [sp, #0x08]   ; e2 07 00 f9  
     4 : str   x3, [sp, #0]      ; e3 03 00 f9  
     5 : eor   x25, x25, x25     ; 39 03 19 ca  
     6 : eor   x26, x26, x26     ; 5a 03 1a ca  
     7 : str   x26, [sp, #0x18]  ; fa 0f 00 f9  
     8 : eor   x26, x26, x26     ; 5a 03 1a ca  
     9 : str   x26, [sp, #0x10]  ; fa 0b 00 f9  
    10 : ldrsw x2, [x0, #0]      ; 02 00 80 b9  
    11 : mov   x3, x2            ; e3 03 02 aa  
    12 : lsl   x26, x1, #0x02    ; 3a f4 7e d3  
    13 : str   x26, [sp, #0x20]  ; fa 13 00 f9  
    14 :       Loops_label_0:    ;              
    15 : ldr   x26, [sp, #0x20]  ; fa 13 40 f9  
    16 : cmp   x25, x26          ; 3f 03 1a eb  
    17 : b.ge  Loops_label_2     ; 0a 02 00 54  
    18 : ldrsw x1, [x0, x25]     ; 01 68 b9 b8  
    19 : cmp   x1, x2            ; 3f 00 02 eb  
    20 : ldr   x26, [sp, #0x18]  ; fa 0f 40 f9  
    21 : csel  x26, x25, x26, lt ; 3a b3 9a 9a  
    22 : str   x26, [sp, #0x18]  ; fa 0f 00 f9  
    23 : cmp   x1, x2            ; 3f 00 02 eb  
    24 : csel  x2, x1, x2, lt    ; 22 b0 82 9a  
    25 : cmp   x1, x3            ; 3f 00 03 eb  
    26 : ldr   x26, [sp, #0x10]  ; fa 0b 40 f9  
    27 : csel  x26, x25, x26, gt ; 3a c3 9a 9a  
    28 : str   x26, [sp, #0x10]  ; fa 0b 00 f9  
    29 : cmp   x1, x3            ; 3f 00 03 eb  
    30 : csel  x3, x1, x3, gt    ; 23 c0 83 9a  
    31 : add   x25, x25, #0x04   ; 39 13 00 91  
    32 : b     Loops_label_0     ; ef ff ff 17  
    33 :       Loops_label_2:    ;              
    34 : ldr   x26, [sp, #0x18]  ; fa 0f 40 f9  
    35 : asr   x0, x26, #0x02    ; 40 ff 42 93  
    36 : ldr   x26, [sp, #0x10]  ; fa 0b 40 f9  
    37 : asr   x1, x26, #0x02    ; 41 ff 42 93  
    38 : ldr   x26, [sp, #0x08]  ; fa 07 40 f9  
    39 : str   w0, [x26, #0]     ; 40 03 00 b9  
    40 : ldr   x26, [sp, #0]     ; fa 03 40 f9  
    41 : str   w1, [x26, #0]     ; 41 03 00 b9  
    42 : eor   x0, x0, x0        ; 00 00 00 ca  
    43 : ldr   x25, [sp, #0x28]  ; f9 17 40 f9  
    44 : ldr   x26, [sp, #0x30]  ; fa 1b 40 f9  
    45 : add   sp, sp, #0x40     ; ff 03 01 91  
    46 : ret   x30               ; c0 03 5f d6  
