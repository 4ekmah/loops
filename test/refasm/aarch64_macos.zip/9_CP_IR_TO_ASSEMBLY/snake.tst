snake(i0, i1, i2)
     0 : sub  sp, sp, #0x200                                 ; ff 03 08 d1  
     1 : str  x0, [sp, #0x1c8]                               ; e0 e7 00 f9  
     2 : str  x1, [sp, #0x1c0]                               ; e1 e3 00 f9  
     3 : str  x2, [sp, #0x1b8]                               ; e2 df 00 f9  
     4 : str  x25, [sp, #0x1d0]                              ; f9 eb 00 f9  
     5 : str  x26, [sp, #0x1d8]                              ; fa ef 00 f9  
     6 : str  x27, [sp, #0x1e0]                              ; fb f3 00 f9  
     7 : stp  x29, x30, [sp, #0x1f0]                         ; fd 7b 1f a9  
     8 : mov  x29, sp                                        ; fd 03 1f aa  
     9 : ldr  x26, [sp, #0x1c0]                              ; fa e3 40 f9  
    10 : ldr  x27, [sp, #0x1b8]                              ; fb df 40 f9  
    11 : add  x3, x26, x27                                   ; 43 03 1b 8b  
    12 : sub  x26, x3, #0x01                                 ; 7a 04 00 d1  
    13 : str  x26, [sp, #0x1b0]                              ; fa db 00 f9  
    14 : eor  x26, x26, x26                                  ; 5a 03 1a ca  
    15 : str  x26, [sp, #0x1a8]                              ; fa d7 00 f9  
    16 : mov  x26, #0x01                                     ; 3a 00 80 d2  
    17 : str  x26, [sp, #0x190]                              ; fa cb 00 f9  
    18 : ldr  x26, [sp, #0x190]                              ; fa cb 40 f9  
    19 : neg  x27, x26                                       ; fb 03 1a cb  
    20 : str  x27, [sp, #0x198]                              ; fb cf 00 f9  
    21 : eor  x26, x26, x26                                  ; 5a 03 1a ca  
    22 : str  x26, [sp, #0x1a0]                              ; fa d3 00 f9  
    23 :      Loops_label_0:                                 ;              
    24 : ldr  x27, [sp, #0x1b0]                              ; fb db 40 f9  
    25 : ldr  x26, [sp, #0x1a0]                              ; fa d3 40 f9  
    26 : cmp  x26, x27                                       ; 5f 03 1b eb  
    27 : b.ge Loops_label_2                                  ; 6a 0c 00 54  
    28 : eor  x25, x25, x25                                  ; 39 03 19 ca  
    29 : eor  x3, x3, x3                                     ; 63 00 03 ca  
    30 : ldr  x26, [sp, #0x1a0]                              ; fa d3 40 f9  
    31 : and  x2, x26, #0x01                                 ; 42 03 40 92  
    32 : cmp  x2, #0                                         ; 5f 00 00 f1  
    33 : b.eq Loops_label_4                                  ; a0 01 00 54  
    34 : ldr  x26, [sp, #0x1b8]                              ; fa df 40 f9  
    35 : sub  x2, x26, #0x01                                 ; 42 07 00 d1  
    36 : ldr  x26, [sp, #0x1a0]                              ; fa d3 40 f9  
    37 : cmp  x2, x26                                        ; 5f 00 1a eb  
    38 : csel x25, x2, x26, lt                               ; 59 b0 9a 9a  
    39 : ldr  x26, [sp, #0x1a0]                              ; fa d3 40 f9  
    40 : sub  x1, x26, x2                                    ; 41 03 02 cb  
    41 : eor  x0, x0, x0                                     ; 00 00 00 ca  
    42 : ldr  x26, [sp, #0x1a0]                              ; fa d3 40 f9  
    43 : cmp  x26, x2                                        ; 5f 03 02 eb  
    44 : csel x3, x1, x0, gt                                 ; 23 c0 80 9a  
    45 : b    Loops_label_6                                  ; 0c 00 00 14  
    46 :      Loops_label_4:                                 ;              
    47 : ldr  x26, [sp, #0x1c0]                              ; fa e3 40 f9  
    48 : sub  x0, x26, #0x01                                 ; 40 07 00 d1  
    49 : ldr  x26, [sp, #0x1a0]                              ; fa d3 40 f9  
    50 : sub  x1, x26, x0                                    ; 41 03 00 cb  
    51 : eor  x2, x2, x2                                     ; 42 00 02 ca  
    52 : ldr  x26, [sp, #0x1a0]                              ; fa d3 40 f9  
    53 : cmp  x26, x0                                        ; 5f 03 00 eb  
    54 : csel x25, x1, x2, gt                                ; 39 c0 82 9a  
    55 : ldr  x26, [sp, #0x1a0]                              ; fa d3 40 f9  
    56 : cmp  x0, x26                                        ; 1f 00 1a eb  
    57 : csel x3, x0, x26, lt                                ; 03 b0 9a 9a  
    58 :      Loops_label_5:                                 ;              
    59 :      Loops_label_6:                                 ;              
    60 : cmp  x25, #0                                        ; 3f 03 00 f1  
    61 : b.lt Loops_label_8                                  ; 4b 07 00 54  
    62 : ldr  x26, [sp, #0x1b8]                              ; fa df 40 f9  
    63 : cmp  x25, x26                                       ; 3f 03 1a eb  
    64 : b.ge Loops_label_8                                  ; ea 06 00 54  
    65 : cmp  x3, #0                                         ; 7f 00 00 f1  
    66 : b.lt Loops_label_8                                  ; ab 06 00 54  
    67 : ldr  x26, [sp, #0x1c0]                              ; fa e3 40 f9  
    68 : cmp  x3, x26                                        ; 7f 00 1a eb  
    69 : b.ge Loops_label_8                                  ; 4a 06 00 54  
    70 : mov  x0, #0xbad0                                    ; 00 5a 97 d2  
    71 : movk x0, #0x415, lsl #16                            ; a0 82 a0 f2  
    72 : movk x0, #0x01, lsl #32                             ; 20 00 c0 f2  
    73 : stp  x0, x1, [sp, #0]                               ; e0 07 00 a9  
    74 : stp  x2, x3, [sp, #0x10]                            ; e2 0f 01 a9  
    75 : stp  x4, x5, [sp, #0x20]                            ; e4 17 02 a9  
    76 : stp  x6, x7, [sp, #0x30]                            ; e6 1f 03 a9  
    77 : stp  x8, x9, [sp, #0x40]                            ; e8 27 04 a9  
    78 : stp  x10, x11, [sp, #0x50]                          ; ea 2f 05 a9  
    79 : stp  x12, x13, [sp, #0x60]                          ; ec 37 06 a9  
    80 : stp  x14, x15, [sp, #0x70]                          ; ee 3f 07 a9  
    81 : stp  x16, x17, [sp, #0x80]                          ; f0 47 08 a9  
    82 : mov  x0, x25                                        ; e0 03 19 aa  
    83 : mov  x1, x3                                         ; e1 03 03 aa  
    84 : ldr  x9, [sp, #0]                                   ; e9 03 40 f9  
    85 : add  x10, sp, #0x90                                 ; ea 43 02 91  
    86 : st1  {v0.2d, v1.2d, v2.2d, v3.2d}, [x10], #0x40     ; 40 2d 9f 4c  
    87 : st1  {v4.2d, v5.2d, v6.2d, v7.2d}, [x10], #0x40     ; 44 2d 9f 4c  
    88 : st1  {v8.2d, v9.2d, v10.2d, v11.2d}, [x10], #0x40   ; 48 2d 9f 4c  
    89 : st1  {v12.2d, v13.2d, v14.2d, v15.2d}, [x10], #0x40 ; 4c 2d 9f 4c  
    90 : blr  x9                                             ; 20 01 3f d6  
    91 : add  x10, sp, #0x90                                 ; ea 43 02 91  
    92 : ld1  {v0.2d, v1.2d, v2.2d, v3.2d}, [x10], #0x40     ; 40 2d df 4c  
    93 : ld1  {v4.2d, v5.2d, v6.2d, v7.2d}, [x10], #0x40     ; 44 2d df 4c  
    94 : ld1  {v8.2d, v9.2d, v10.2d, v11.2d}, [x10], #0x40   ; 48 2d df 4c  
    95 : ld1  {v12.2d, v13.2d, v14.2d, v15.2d}, [x10], #0x40 ; 4c 2d df 4c  
    96 : ldp  x0, x1, [sp, #0]                               ; e0 07 40 a9  
    97 : ldp  x2, x3, [sp, #0x10]                            ; e2 0f 41 a9  
    98 : ldp  x4, x5, [sp, #0x20]                            ; e4 17 42 a9  
    99 : ldp  x6, x7, [sp, #0x30]                            ; e6 1f 43 a9  
   100 : ldp  x8, x9, [sp, #0x40]                            ; e8 27 44 a9  
   101 : ldp  x10, x11, [sp, #0x50]                          ; ea 2f 45 a9  
   102 : ldp  x12, x13, [sp, #0x60]                          ; ec 37 46 a9  
   103 : ldp  x14, x15, [sp, #0x70]                          ; ee 3f 47 a9  
   104 : ldp  x16, x17, [sp, #0x80]                          ; f0 47 48 a9  
   105 : ldr  x26, [sp, #0x1b8]                              ; fa df 40 f9  
   106 : mul  x0, x3, x26                                    ; 60 7c 1a 9b  
   107 : add  x0, x0, x25                                    ; 00 00 19 8b  
   108 : ldr  x26, [sp, #0x1c8]                              ; fa e7 40 f9  
   109 : ldr  x27, [sp, #0x1a8]                              ; fb d7 40 f9  
   110 : strb w27, [x26, x0]                                 ; 5b 6b 20 38  
   111 : ldr  x26, [sp, #0x1a8]                              ; fa d7 40 f9  
   112 : add  x26, x26, #0x01                                ; 5a 07 00 91  
   113 : str  x26, [sp, #0x1a8]                              ; fa d7 00 f9  
   114 : ldr  x26, [sp, #0x190]                              ; fa cb 40 f9  
   115 : add  x25, x25, x26                                  ; 39 03 1a 8b  
   116 : ldr  x26, [sp, #0x198]                              ; fa cf 40 f9  
   117 : add  x3, x3, x26                                    ; 63 00 1a 8b  
   118 : b    Loops_label_6                                  ; c6 ff ff 17  
   119 :      Loops_label_8:                                 ;              
   120 : ldr  x26, [sp, #0x190]                              ; fa cb 40 f9  
   121 : neg  x26, x26                                       ; fa 03 1a cb  
   122 : str  x26, [sp, #0x190]                              ; fa cb 00 f9  
   123 : ldr  x26, [sp, #0x198]                              ; fa cf 40 f9  
   124 : neg  x26, x26                                       ; fa 03 1a cb  
   125 : str  x26, [sp, #0x198]                              ; fa cf 00 f9  
   126 : ldr  x26, [sp, #0x1a0]                              ; fa d3 40 f9  
   127 : add  x26, x26, #0x01                                ; 5a 07 00 91  
   128 : str  x26, [sp, #0x1a0]                              ; fa d3 00 f9  
   129 : b    Loops_label_0                                  ; 9b ff ff 17  
   130 :      Loops_label_2:                                 ;              
   131 : ldp  x29, x30, [sp, #0x1f0]                         ; fd 7b 5f a9  
   132 : ldr  x25, [sp, #0x1d0]                              ; f9 eb 40 f9  
   133 : ldr  x26, [sp, #0x1d8]                              ; fa ef 40 f9  
   134 : ldr  x27, [sp, #0x1e0]                              ; fb f3 40 f9  
   135 : add  sp, sp, #0x200                                 ; ff 03 08 91  
   136 : ret  x30                                            ; c0 03 5f d6  
