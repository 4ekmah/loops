nullify_msb_lsb_v(i0, i1, i2, i3)
     0 : mov                    i4, 0           
     1 : mov                    i5, 4           
     2 : mul                    i3, i3, i5      
     3 : mov                    v0, 1           
     4 : annotation:whilecstart 0               
     5 : cmp                    i4, i3          
     6 : jmp_ge                 __loops_label_2 
     7 : annotation:whilecend                   
     8 : vld.u32                v1, i0, i4      
     9 : shr.u32                v3, v1, 1       
    10 : or                     v2, v1, v3      
    11 : shr.u32                v4, v2, 2       
    12 : or                     v2, v2, v4      
    13 : shr.u32                v5, v2, 4       
    14 : or                     v2, v2, v5      
    15 : shr.u32                v6, v2, 8       
    16 : or                     v2, v2, v6      
    17 : shr.u32                v7, v2, 16      
    18 : or                     v2, v2, v7      
    19 : add.u32                v2, v2, v0      
    20 : shr.u32                v2, v2, 1       
    21 : xor                    v2, v2, v1      
    22 : vst.u32                i1, i4, v2      
    23 : sub.u32                v10, v1, v0     
    24 : not                    v9, v10         
    25 : and                    v8, v1, v9      
    26 : xor                    v8, v8, v1      
    27 : vst.u32                i2, i4, v8      
    28 : add                    i4, i4, 16      
    29 : annotation:endwhile    0, 2            
    30 : ret                                    
