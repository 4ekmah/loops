min_max_scalar(i0, i1, i2, i3)
     0 : mov                    i4, 0           
     1 : mov                    i5, 0           
     2 : mov                    i6, 0           
     3 : load.i32               i7, i0          
     4 : mov                    i8, i7          
     5 : mov                    i11, 4          
     6 : mul                    i1, i1, i11     
     7 : annotation:whilecstart 0               
     8 : cmp                    i4, i1          
     9 : jmp_ge                 __loops_label_2 
    10 : annotation:whilecend                   
    11 : load.i32               i9, i0, i4      
    12 : annotation:ifcstart                    
    13 : cmp                    i9, i7          
    14 : jmp_ge                 __loops_label_4 
    15 : annotation:ifcend                      
    16 : mov                    i7, i9          
    17 : mov                    i5, i4          
    18 : annotation:endif       4               
    19 : annotation:ifcstart                    
    20 : cmp                    i9, i8          
    21 : jmp_le                 __loops_label_6 
    22 : annotation:ifcend                      
    23 : mov                    i8, i9          
    24 : mov                    i6, i4          
    25 : annotation:endif       6               
    26 : add                    i4, i4, 4       
    27 : annotation:endwhile    0, 2            
    28 : mov                    i10, 4          
    29 : div                    i5, i5, i10     
    30 : div                    i6, i6, i10     
    31 : store.i32              i2, i5          
    32 : store.i32              i3, i6          
    33 : mov                    iR, 0           
    34 : ret                                    
