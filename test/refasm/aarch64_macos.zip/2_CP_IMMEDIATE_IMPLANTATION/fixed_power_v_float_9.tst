fixed_power_v_float_9(i0, i1, i2)
     0 : mov                    i3, 0           
     1 : mov                    i4, 4           
     2 : mul                    i2, i2, i4      
     3 : annotation:whilecstart 0               
     4 : cmp                    i3, i2          
     5 : jmp_ge                 __loops_label_2 
     6 : annotation:whilecend                   
     7 : vld.fp32               v0, i0, i3      
     8 : mul.fp32               v4, v0, v0      
     9 : mul.fp32               v3, v4, v4      
    10 : mul.fp32               v2, v3, v3      
    11 : mul.fp32               v1, v0, v2      
    12 : vst.fp32               i1, i3, v1      
    13 : add                    i3, i3, 16      
    14 : annotation:endwhile    0, 2            
    15 : mov                    iR, 0           
    16 : ret                                    
