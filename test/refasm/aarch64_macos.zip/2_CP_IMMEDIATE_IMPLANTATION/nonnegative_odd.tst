nonnegative_odd(i0, i1)
     0 : mov                    i2, 0           
     1 : mov                    i3, -4          
     2 : mov                    i6, 4           
     3 : mul                    i1, i1, i6      
     4 : annotation:whilecstart 0               
     5 : cmp                    i2, i1          
     6 : jmp_ge                 __loops_label_2 
     7 : annotation:whilecend                   
     8 : load.i32               i4, i0, i2      
     9 : annotation:ifcstart                    
    10 : cmp                    i4, 0           
    11 : jmp_ge                 __loops_label_4 
    12 : annotation:ifcend                      
    13 : add                    i2, i2, 4       
    14 : annotation:break       0               
    15 : annotation:endif       4               
    16 : mov                    i7, 2           
    17 : mod                    i5, i4, i7      
    18 : annotation:ifcstart                    
    19 : cmp                    i5, 0           
    20 : jmp_eq                 __loops_label_6 
    21 : annotation:ifcend                      
    22 : mov                    i3, i2          
    23 : annotation:break       2               
    24 : annotation:endif       6               
    25 : add                    i2, i2, 4       
    26 : annotation:endwhile    0, 2            
    27 : mov                    i8, 4           
    28 : div                    i3, i3, i8      
    29 : mov                    iR, i3          
    30 : ret                                    
