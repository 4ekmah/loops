fixed_power_v_double_4(i0, i1, i2)
     0 : mov                    i3, 0           
     1 : mov                    i4, 8           
     2 : mul                    i2, i2, i4      
     3 : annotation:whilecstart 0               
     4 : cmp                    i3, i2          
     5 : jmp_ge                 __loops_label_2 
     6 : annotation:whilecend                   
     7 : vld.fp64               v0, i0, i3      
     8 : mul.fp64               v2, v0, v0      
     9 : mul.fp64               v1, v2, v2      
    10 : vst.fp64               i1, i3, v1      
    11 : add                    i3, i3, 16      
    12 : annotation:endwhile    0, 2            
    13 : mov                    iR, 0           
    14 : ret                                    
