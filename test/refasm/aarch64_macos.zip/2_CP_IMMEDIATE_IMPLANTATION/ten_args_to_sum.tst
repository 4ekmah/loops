ten_args_to_sum(i0, i1, i2, i3, i4, i5, i6, i7, i8, i9)
     0 : mov i20, 1        
     1 : mul i10, i0, i20  
     2 : mov i21, 2        
     3 : mul i11, i1, i21  
     4 : add i10, i10, i11 
     5 : mov i22, 3        
     6 : mul i12, i2, i22  
     7 : add i10, i10, i12 
     8 : mov i23, 4        
     9 : mul i13, i3, i23  
    10 : add i10, i10, i13 
    11 : mov i24, 5        
    12 : mul i14, i4, i24  
    13 : add i10, i10, i14 
    14 : mov i25, 6        
    15 : mul i15, i5, i25  
    16 : add i10, i10, i15 
    17 : mov i26, 7        
    18 : mul i16, i6, i26  
    19 : add i10, i10, i16 
    20 : mov i27, 8        
    21 : mul i17, i7, i27  
    22 : add i10, i10, i17 
    23 : mov i28, 3        
    24 : mul i18, i8, i28  
    25 : add i10, i10, i18 
    26 : mov i29, 2        
    27 : mul i19, i9, i29  
    28 : add i10, i10, i19 
    29 : mov iR, i10       
    30 : ret               
