fixed_power_v_int32_t_0(i0, i1, i2)
     0 : mov                    i3, 0           
     1 : mov                    i4, 4           
     2 : mul                    i2, i2, i4      
     3 : annotation:whilecstart 0               
     4 : cmp                    i3, i2          
     5 : jmp_ge                 __loops_label_2 
     6 : annotation:whilecend                   
     7 : vld.i32                v0, i0, i3      
     8 : mov                    v1, 1           
     9 : vst.i32                i1, i3, v1      
    10 : add                    i3, i3, 16      
    11 : annotation:endwhile    0, 2            
    12 : mov                    iR, 0           
    13 : ret                                    
