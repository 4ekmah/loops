helloworld_call()
     0 : mov        i0, 68520212 
     1 : call_noret [i0]()       
     2 : ret                     
