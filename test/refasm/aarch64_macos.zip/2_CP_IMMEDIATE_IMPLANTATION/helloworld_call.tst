helloworld_call()
     0 : mov        i0, 71349216 
     1 : call_noret [i0]()       
     2 : ret                     
