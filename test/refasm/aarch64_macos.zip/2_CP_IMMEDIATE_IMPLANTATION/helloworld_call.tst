helloworld_call()
     0 : mov        i0, 42383344 
     1 : call_noret [i0]()       
     2 : ret                     
