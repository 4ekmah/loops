sort_double(i0, i1)
     0 : shl                    i1, i1, 3         
     1 : sub                    i2, i1, 8         
     2 : mov                    i3, 0             
     3 : annotation:whilecstart 0                 
     4 : cmp                    i3, i2            
     5 : jmp_ge                 __loops_label_2   
     6 : annotation:whilecend                     
     7 : mov                    i4, i3            
     8 : add                    i5, i4, 8         
     9 : annotation:whilecstart 3                 
    10 : cmp                    i5, i1            
    11 : jmp_ge                 __loops_label_5   
    12 : annotation:whilecend                     
    13 : annotation:ifcstart                      
    14 : load.fp64              i7, i0, i5        
    15 : load.fp64              i8, i0, i4        
    16 : mov                    i11, 68540784     
    17 : call                   [i11](i6, i7, i8) 
    18 : cmp                    i6, 0             
    19 : jmp_eq                 __loops_label_7   
    20 : annotation:ifcend                        
    21 : mov                    i4, i5            
    22 : annotation:endif       7                 
    23 : add                    i5, i5, 8         
    24 : annotation:endwhile    3, 5              
    25 : annotation:ifcstart                      
    26 : cmp                    i4, i3            
    27 : jmp_eq                 __loops_label_9   
    28 : annotation:ifcend                        
    29 : load.fp64              i9, i0, i3        
    30 : load.fp64              i10, i0, i4       
    31 : store.fp64             i0, i4, i9        
    32 : store.fp64             i0, i3, i10       
    33 : annotation:endif       9                 
    34 : add                    i3, i3, 8         
    35 : annotation:endwhile    0, 2              
    36 : ret                                      
