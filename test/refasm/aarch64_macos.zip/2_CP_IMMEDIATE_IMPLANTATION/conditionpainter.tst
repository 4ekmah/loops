conditionpainter(i0)
     0 : mov                    i1, -5          
     1 : annotation:whilecstart 0               
     2 : cmp                    i1, 5           
     3 : jmp_gt                 __loops_label_2 
     4 : annotation:whilecend                   
     5 : add                    i4, i1, 5       
     6 : mov                    i54, 11         
     7 : mul                    i3, i4, i54     
     8 : mov                    i55, 8          
     9 : mul                    i2, i3, i55     
    10 : mov                    i5, -5          
    11 : annotation:whilecstart 3               
    12 : cmp                    i5, 5           
    13 : jmp_gt                 __loops_label_5 
    14 : annotation:whilecend                   
    15 : add                    i10, i5, 3      
    16 : cmp                    i1, i10         
    17 : iverson_ge             i11             
    18 : cmp                    i1, 4           
    19 : iverson_le             i12             
    20 : and                    i9, i11, i12    
    21 : mov                    i56, -2         
    22 : cmp                    i5, i56         
    23 : iverson_ge             i13             
    24 : and                    i8, i9, i13     
    25 : cmp                    i5, 0           
    26 : iverson_le             i14             
    27 : and                    i7, i8, i14     
    28 : sub                    i18, i5, 1      
    29 : cmp                    i1, i18         
    30 : iverson_le             i19             
    31 : cmp                    i5, 0           
    32 : iverson_ge             i20             
    33 : and                    i17, i19, i20   
    34 : cmp                    i1, 0           
    35 : iverson_le             i21             
    36 : and                    i16, i17, i21   
    37 : mul                    i23, i5, i5     
    38 : mul                    i24, i1, i1     
    39 : add                    i22, i23, i24   
    40 : cmp                    i22, 9          
    41 : iverson_le             i25             
    42 : and                    i15, i16, i25   
    43 : or                     i6, i7, i15     
    44 : mov                    i26, 2          
    45 : mov                    i27, 0          
    46 : cmp                    i5, 2           
    47 : iverson_ge             i31             
    48 : cmp                    i5, 4           
    49 : iverson_le             i32             
    50 : and                    i30, i31, i32   
    51 : cmp                    i1, 1           
    52 : iverson_ge             i34             
    53 : cmp                    i1, 3           
    54 : iverson_le             i35             
    55 : and                    i33, i34, i35   
    56 : or                     i29, i30, i33   
    57 : mul                    i37, i5, i5     
    58 : mul                    i38, i1, i1     
    59 : add                    i36, i37, i38   
    60 : cmp                    i36, 16         
    61 : iverson_le             i39             
    62 : and                    i28, i29, i39   
    63 : cmp                    i28, 0          
    64 : select_ne              i40, i26, i27   
    65 : add                    i6, i6, i40     
    66 : annotation:ifcstart                    
    67 : mov                    i57, 2          
    68 : mul                    i41, i1, i57    
    69 : cmp                    i41, i5         
    70 : jmp_gt                 __loops_label_8 
    71 : add                    i44, i5, 3      
    72 : neg                    i43, i44        
    73 : add                    i45, i5, 3      
    74 : mul                    i42, i43, i45   
    75 : cmp                    i1, i42         
    76 : jmp_le                 __loops_label_9 
    77 : __loops_label_8:                       
    78 : mov                    i58, 2          
    79 : mul                    i46, i5, i58    
    80 : cmp                    i1, i46         
    81 : jmp_gt                 __loops_label_7 
    82 : add                    i49, i5, 3      
    83 : neg                    i48, i49        
    84 : add                    i50, i5, 3      
    85 : mul                    i47, i48, i50   
    86 : cmp                    i1, i47         
    87 : jmp_gt                 __loops_label_7 
    88 : __loops_label_9:                       
    89 : cmp                    i5, 0           
    90 : jmp_gt                 __loops_label_7 
    91 : annotation:ifcend                      
    92 : add                    i6, i6, 3       
    93 : annotation:endif       7               
    94 : add                    i53, i5, 5      
    95 : shl                    i52, i53, 3     
    96 : add                    i51, i2, i52    
    97 : store.i64              i0, i51, i6     
    98 : add                    i5, i5, 1       
    99 : annotation:endwhile    3, 5            
   100 : add                    i1, i1, 1       
   101 : annotation:endwhile    0, 2            
   102 : ret                                    
