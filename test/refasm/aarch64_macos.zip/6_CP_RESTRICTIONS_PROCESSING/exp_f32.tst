exp_f32(i0, i1, i2)
     0 : mov                    i4, 49317          
     1 : arm_movk               i4, 49840, 16      
     2 : broadcast.fp32         v0, i4             
     3 : mov                    i5, 49317          
     4 : arm_movk               i5, 17072, 16      
     5 : broadcast.fp32         v1, i5             
     6 : mov                    i6, 0              
     7 : arm_movk               i6, 16128, 16      
     8 : broadcast.fp32         v2, i6             
     9 : mov                    i7, 0              
    10 : arm_movk               i7, 16256, 16      
    11 : broadcast.fp32         v3, i7             
    12 : mov                    i8, 43579          
    13 : arm_movk               i8, 16312, 16      
    14 : broadcast.fp32         v4, i8             
    15 : mov                    i9, 32768          
    16 : arm_movk               i9, 48945, 16      
    17 : broadcast.fp32         v5, i9             
    18 : mov                    i10, 32899         
    19 : arm_movk               i10, 14686, 16     
    20 : broadcast.fp32         v6, i10            
    21 : mov                    i11, 26983         
    22 : arm_movk               i11, 14672, 16     
    23 : broadcast.fp32         v7, i11            
    24 : mov                    i12, 17358         
    25 : arm_movk               i12, 15031, 16     
    26 : broadcast.fp32         v8, i12            
    27 : mov                    i13, 35080         
    28 : arm_movk               i13, 15368, 16     
    29 : broadcast.fp32         v9, i13            
    30 : mov                    i14, 43457         
    31 : arm_movk               i14, 15658, 16     
    32 : broadcast.fp32         v10, i14           
    33 : mov                    i15, 43690         
    34 : arm_movk               i15, 15914, 16     
    35 : broadcast.fp32         v11, i15           
    36 : mov                    i16, 0             
    37 : arm_movk               i16, 16128, 16     
    38 : broadcast.fp32         v12, i16           
    39 : mov                    v13, 127           
    40 : mov                    i3, 0              
    41 : annotation:whilecstart 0                  
    42 : cmp                    i2, 0              
    43 : jmp_le                 __loops_label_2    
    44 : annotation:whilecend                      
    45 : vld.fp32               v14, i1, i3        
    46 : min.fp32               v21, v14, v1       
    47 : max.fp32               v20, v21, v0       
    48 : mov                    v24, v2            
    49 : fma.fp32               v24, v24, v20, v4  
    50 : floor.fp32_i32         v23, v24           
    51 : cast.i32_fp32          v22, v23           
    52 : mov                    v19, v20           
    53 : fma.fp32               v19, v19, v22, v5  
    54 : mov                    v18, v19           
    55 : fma.fp32               v18, v18, v22, v6  
    56 : mov                    v29, v8            
    57 : fma.fp32               v29, v29, v18, v7  
    58 : mov                    v28, v9            
    59 : fma.fp32               v28, v28, v29, v18 
    60 : mov                    v27, v10           
    61 : fma.fp32               v27, v27, v28, v18 
    62 : mov                    v26, v11           
    63 : fma.fp32               v26, v26, v27, v18 
    64 : mov                    v25, v12           
    65 : fma.fp32               v25, v25, v26, v18 
    66 : mul.fp32               v30, v18, v18      
    67 : mov                    v17, v18           
    68 : fma.fp32               v17, v17, v25, v30 
    69 : add.fp32               v16, v17, v3       
    70 : add.i32                v32, v23, v13      
    71 : sal.i32                v31, v32, 23       
    72 : mul.fp32               v15, v16, v31      
    73 : vst.fp32               i0, i3, v15        
    74 : add                    i3, i3, 16         
    75 : sub                    i2, i2, 4          
    76 : annotation:endwhile    0, 2               
    77 : ret                                       
