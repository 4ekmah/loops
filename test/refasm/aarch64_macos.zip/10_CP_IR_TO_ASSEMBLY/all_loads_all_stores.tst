all_loads_all_stores(i0, i1, i2, i3, i4)
     0 : sub   sp, sp, #0x70     ; ff c3 01 d1  
     1 : str   x25, [sp, #0x58]  ; f9 2f 00 f9  
     2 : str   x26, [sp, #0x60]  ; fa 33 00 f9  
     3 : str   x27, [sp, #0x68]  ; fb 37 00 f9  
     4 : eor   x26, x26, x26     ; 5a 03 1a ca  
     5 : str   x26, [sp, #0x20]  ; fa 13 00 f9  
     6 : eor   x26, x26, x26     ; 5a 03 1a ca  
     7 : str   x26, [sp, #0]     ; fa 03 00 f9  
     8 : eor   x26, x26, x26     ; 5a 03 1a ca  
     9 : str   x26, [sp, #0x08]  ; fa 07 00 f9  
    10 : mov   x25, #0x02        ; 59 00 80 d2  
    11 : mov   x26, #0x01        ; 3a 00 80 d2  
    12 : str   x26, [sp, #0x28]  ; fa 17 00 f9  
    13 : cmp   x1, #0x01         ; 3f 04 00 f1  
    14 : ldr   x26, [sp, #0x28]  ; fa 17 40 f9  
    15 : csel  x25, x25, x26, gt ; 39 c3 9a 9a  
    16 : mov   x26, #0x04        ; 9a 00 80 d2  
    17 : str   x26, [sp, #0x30]  ; fa 1b 00 f9  
    18 : cmp   x1, #0x03         ; 3f 0c 00 f1  
    19 : ldr   x26, [sp, #0x30]  ; fa 1b 40 f9  
    20 : csel  x25, x26, x25, gt ; 59 c3 99 9a  
    21 : mov   x26, #0x08        ; 1a 01 80 d2  
    22 : str   x26, [sp, #0x38]  ; fa 1f 00 f9  
    23 : cmp   x1, #0x05         ; 3f 14 00 f1  
    24 : ldr   x26, [sp, #0x38]  ; fa 1f 40 f9  
    25 : csel  x27, x26, x25, gt ; 5b c3 99 9a  
    26 : str   x27, [sp, #0x10]  ; fb 0b 00 f9  
    27 : mov   x25, #0x02        ; 59 00 80 d2  
    28 : mov   x26, #0x01        ; 3a 00 80 d2  
    29 : str   x26, [sp, #0x40]  ; fa 23 00 f9  
    30 : cmp   x3, #0x01         ; 7f 04 00 f1  
    31 : ldr   x26, [sp, #0x40]  ; fa 23 40 f9  
    32 : csel  x25, x25, x26, gt ; 39 c3 9a 9a  
    33 : mov   x26, #0x04        ; 9a 00 80 d2  
    34 : str   x26, [sp, #0x48]  ; fa 27 00 f9  
    35 : cmp   x3, #0x03         ; 7f 0c 00 f1  
    36 : ldr   x26, [sp, #0x48]  ; fa 27 40 f9  
    37 : csel  x25, x26, x25, gt ; 59 c3 99 9a  
    38 : mov   x26, #0x08        ; 1a 01 80 d2  
    39 : str   x26, [sp, #0x50]  ; fa 2b 00 f9  
    40 : cmp   x3, #0x05         ; 7f 14 00 f1  
    41 : ldr   x26, [sp, #0x50]  ; fa 2b 40 f9  
    42 : csel  x27, x26, x25, gt ; 5b c3 99 9a  
    43 : str   x27, [sp, #0x18]  ; fb 0f 00 f9  
    44 :       Loops_label_0:    ;              
    45 : ldr   x26, [sp, #0x20]  ; fa 13 40 f9  
    46 : cmp   x26, x4           ; 5f 03 04 eb  
    47 : b.ge  Loops_label_2     ; ea 0a 00 54  
    48 : cmp   x1, #0            ; 3f 00 00 f1  
    49 : b.ne  Loops_label_4     ; 81 00 00 54  
    50 : ldr   x26, [sp, #0]     ; fa 03 40 f9  
    51 : ldrb  w25, [x0, x26]    ; 19 68 7a 38  
    52 : b     Loops_label_23    ; 21 00 00 14  
    53 :       Loops_label_4:    ;              
    54 : cmp   x1, #0x01         ; 3f 04 00 f1  
    55 : b.ne  Loops_label_7     ; 81 00 00 54  
    56 : ldr   x26, [sp, #0]     ; fa 03 40 f9  
    57 : ldrsb x25, [x0, x26]    ; 19 68 ba 38  
    58 : b     Loops_label_23    ; 1c 00 00 14  
    59 :       Loops_label_7:    ;              
    60 : cmp   x1, #0x02         ; 3f 08 00 f1  
    61 : b.ne  Loops_label_10    ; 81 00 00 54  
    62 : ldr   x26, [sp, #0]     ; fa 03 40 f9  
    63 : ldrh  w25, [x0, x26]    ; 19 68 7a 78  
    64 : b     Loops_label_23    ; 17 00 00 14  
    65 :       Loops_label_10:   ;              
    66 : cmp   x1, #0x03         ; 3f 0c 00 f1  
    67 : b.ne  Loops_label_13    ; 81 00 00 54  
    68 : ldr   x26, [sp, #0]     ; fa 03 40 f9  
    69 : ldrsh x25, [x0, x26]    ; 19 68 ba 78  
    70 : b     Loops_label_23    ; 12 00 00 14  
    71 :       Loops_label_13:   ;              
    72 : cmp   x1, #0x04         ; 3f 10 00 f1  
    73 : b.ne  Loops_label_16    ; 81 00 00 54  
    74 : ldr   x26, [sp, #0]     ; fa 03 40 f9  
    75 : ldr   w25, [x0, x26]    ; 19 68 7a b8  
    76 : b     Loops_label_23    ; 0d 00 00 14  
    77 :       Loops_label_16:   ;              
    78 : cmp   x1, #0x05         ; 3f 14 00 f1  
    79 : b.ne  Loops_label_19    ; 81 00 00 54  
    80 : ldr   x26, [sp, #0]     ; fa 03 40 f9  
    81 : ldrsw x25, [x0, x26]    ; 19 68 ba b8  
    82 : b     Loops_label_23    ; 08 00 00 14  
    83 :       Loops_label_19:   ;              
    84 : cmp   x1, #0x06         ; 3f 18 00 f1  
    85 : b.ne  Loops_label_22    ; 81 00 00 54  
    86 : ldr   x26, [sp, #0]     ; fa 03 40 f9  
    87 : ldr   x25, [x0, x26]    ; 19 68 7a f8  
    88 : b     Loops_label_23    ; 03 00 00 14  
    89 :       Loops_label_22:   ;              
    90 : ldr   x26, [sp, #0]     ; fa 03 40 f9  
    91 : ldr   x25, [x0, x26]    ; 19 68 7a f8  
    92 :       Loops_label_5:    ;              
    93 :       Loops_label_8:    ;              
    94 :       Loops_label_11:   ;              
    95 :       Loops_label_14:   ;              
    96 :       Loops_label_17:   ;              
    97 :       Loops_label_20:   ;              
    98 :       Loops_label_23:   ;              
    99 : cmp   x3, #0            ; 7f 00 00 f1  
   100 : b.ne  Loops_label_25    ; 81 00 00 54  
   101 : ldr   x26, [sp, #0x08]  ; fa 07 40 f9  
   102 : strb  w25, [x2, x26]    ; 59 68 3a 38  
   103 : b     Loops_label_44    ; 21 00 00 14  
   104 :       Loops_label_25:   ;              
   105 : cmp   x3, #0x01         ; 7f 04 00 f1  
   106 : b.ne  Loops_label_28    ; 81 00 00 54  
   107 : ldr   x26, [sp, #0x08]  ; fa 07 40 f9  
   108 : strb  w25, [x2, x26]    ; 59 68 3a 38  
   109 : b     Loops_label_44    ; 1c 00 00 14  
   110 :       Loops_label_28:   ;              
   111 : cmp   x3, #0x02         ; 7f 08 00 f1  
   112 : b.ne  Loops_label_31    ; 81 00 00 54  
   113 : ldr   x26, [sp, #0x08]  ; fa 07 40 f9  
   114 : strh  w25, [x2, x26]    ; 59 68 3a 78  
   115 : b     Loops_label_44    ; 17 00 00 14  
   116 :       Loops_label_31:   ;              
   117 : cmp   x3, #0x03         ; 7f 0c 00 f1  
   118 : b.ne  Loops_label_34    ; 81 00 00 54  
   119 : ldr   x26, [sp, #0x08]  ; fa 07 40 f9  
   120 : strh  w25, [x2, x26]    ; 59 68 3a 78  
   121 : b     Loops_label_44    ; 12 00 00 14  
   122 :       Loops_label_34:   ;              
   123 : cmp   x3, #0x04         ; 7f 10 00 f1  
   124 : b.ne  Loops_label_37    ; 81 00 00 54  
   125 : ldr   x26, [sp, #0x08]  ; fa 07 40 f9  
   126 : str   w25, [x2, x26]    ; 59 68 3a b8  
   127 : b     Loops_label_44    ; 0d 00 00 14  
   128 :       Loops_label_37:   ;              
   129 : cmp   x3, #0x05         ; 7f 14 00 f1  
   130 : b.ne  Loops_label_40    ; 81 00 00 54  
   131 : ldr   x26, [sp, #0x08]  ; fa 07 40 f9  
   132 : str   w25, [x2, x26]    ; 59 68 3a b8  
   133 : b     Loops_label_44    ; 08 00 00 14  
   134 :       Loops_label_40:   ;              
   135 : cmp   x3, #0x06         ; 7f 18 00 f1  
   136 : b.ne  Loops_label_43    ; 81 00 00 54  
   137 : ldr   x26, [sp, #0x08]  ; fa 07 40 f9  
   138 : str   x25, [x2, x26]    ; 59 68 3a f8  
   139 : b     Loops_label_44    ; 03 00 00 14  
   140 :       Loops_label_43:   ;              
   141 : ldr   x26, [sp, #0x08]  ; fa 07 40 f9  
   142 : str   x25, [x2, x26]    ; 59 68 3a f8  
   143 :       Loops_label_26:   ;              
   144 :       Loops_label_29:   ;              
   145 :       Loops_label_32:   ;              
   146 :       Loops_label_35:   ;              
   147 :       Loops_label_38:   ;              
   148 :       Loops_label_41:   ;              
   149 :       Loops_label_44:   ;              
   150 : ldr   x26, [sp, #0]     ; fa 03 40 f9  
   151 : ldr   x27, [sp, #0x10]  ; fb 0b 40 f9  
   152 : add   x26, x26, x27     ; 5a 03 1b 8b  
   153 : str   x26, [sp, #0]     ; fa 03 00 f9  
   154 : ldr   x26, [sp, #0x08]  ; fa 07 40 f9  
   155 : ldr   x27, [sp, #0x18]  ; fb 0f 40 f9  
   156 : add   x26, x26, x27     ; 5a 03 1b 8b  
   157 : str   x26, [sp, #0x08]  ; fa 07 00 f9  
   158 : ldr   x26, [sp, #0x20]  ; fa 13 40 f9  
   159 : add   x26, x26, #0x01   ; 5a 07 00 91  
   160 : str   x26, [sp, #0x20]  ; fa 13 00 f9  
   161 : b     Loops_label_0     ; a8 ff ff 17  
   162 :       Loops_label_2:    ;              
   163 : ldr   x25, [sp, #0x58]  ; f9 2f 40 f9  
   164 : ldr   x26, [sp, #0x60]  ; fa 33 40 f9  
   165 : ldr   x27, [sp, #0x68]  ; fb 37 40 f9  
   166 : add   sp, sp, #0x70     ; ff c3 01 91  
   167 : ret   x30               ; c0 03 5f d6  
