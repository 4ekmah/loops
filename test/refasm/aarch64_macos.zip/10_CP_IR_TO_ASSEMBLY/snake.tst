snake(i0, i1, i2)
     0 : sub  sp, sp, #0x210                                 ; ff 43 08 d1  
     1 : str  x25, [sp, #0x1e0]                              ; f9 f3 00 f9  
     2 : str  x26, [sp, #0x1e8]                              ; fa f7 00 f9  
     3 : str  x27, [sp, #0x1f0]                              ; fb fb 00 f9  
     4 : str  x28, [sp, #0x1f8]                              ; fc ff 00 f9  
     5 : str  x29, [sp, #0x200]                              ; fd 03 01 f9  
     6 : str  x30, [sp, #0x208]                              ; fe 07 01 f9  
     7 : mov  x29, sp                                        ; fd 03 1f aa  
     8 : add  x3, x1, x2                                     ; 23 00 02 8b  
     9 : sub  x26, x3, #0x01                                 ; 7a 04 00 d1  
    10 : str  x26, [sp, #0x1b0]                              ; fa db 00 f9  
    11 : eor  x3, x3, x3                                     ; 63 00 03 ca  
    12 : mov  x26, #0x01                                     ; 3a 00 80 d2  
    13 : str  x26, [sp, #0x1a8]                              ; fa d7 00 f9  
    14 : ldr  x26, [sp, #0x1a8]                              ; fa d7 40 f9  
    15 : neg  x27, x26                                       ; fb 03 1a cb  
    16 : str  x27, [sp, #0x190]                              ; fb cb 00 f9  
    17 : eor  x26, x26, x26                                  ; 5a 03 1a ca  
    18 : str  x26, [sp, #0x1b8]                              ; fa df 00 f9  
    19 :      Loops_label_0:                                 ;              
    20 : ldr  x27, [sp, #0x1b0]                              ; fb db 40 f9  
    21 : ldr  x26, [sp, #0x1b8]                              ; fa df 40 f9  
    22 : cmp  x26, x27                                       ; 5f 03 1b eb  
    23 : b.ge Loops_label_2                                  ; 0a 0f 00 54  
    24 : eor  x26, x26, x26                                  ; 5a 03 1a ca  
    25 : str  x26, [sp, #0x198]                              ; fa cf 00 f9  
    26 : eor  x26, x26, x26                                  ; 5a 03 1a ca  
    27 : str  x26, [sp, #0x1a0]                              ; fa d3 00 f9  
    28 : ldr  x26, [sp, #0x1b8]                              ; fa df 40 f9  
    29 : and  x25, x26, #0x01                                ; 59 03 40 92  
    30 : cmp  x25, #0                                        ; 3f 03 00 f1  
    31 : b.eq Loops_label_4                                  ; 60 02 00 54  
    32 : sub  x25, x2, #0x01                                 ; 59 04 00 d1  
    33 : ldr  x26, [sp, #0x1b8]                              ; fa df 40 f9  
    34 : cmp  x25, x26                                       ; 3f 03 1a eb  
    35 : ldr  x26, [sp, #0x1b8]                              ; fa df 40 f9  
    36 : csel x27, x25, x26, lt                              ; 3b b3 9a 9a  
    37 : str  x27, [sp, #0x198]                              ; fb cf 00 f9  
    38 : ldr  x26, [sp, #0x1b8]                              ; fa df 40 f9  
    39 : sub  x27, x26, x25                                  ; 5b 03 19 cb  
    40 : str  x27, [sp, #0x1c0]                              ; fb e3 00 f9  
    41 : eor  x26, x26, x26                                  ; 5a 03 1a ca  
    42 : str  x26, [sp, #0x1c8]                              ; fa e7 00 f9  
    43 : ldr  x26, [sp, #0x1b8]                              ; fa df 40 f9  
    44 : cmp  x26, x25                                       ; 5f 03 19 eb  
    45 : ldr  x26, [sp, #0x1c0]                              ; fa e3 40 f9  
    46 : ldr  x27, [sp, #0x1c8]                              ; fb e7 40 f9  
    47 : csel x28, x26, x27, gt                              ; 5c c3 9b 9a  
    48 : str  x28, [sp, #0x1a0]                              ; fc d3 00 f9  
    49 : b    Loops_label_6                                  ; 15 00 00 14  
    50 :      Loops_label_4:                                 ;              
    51 : sub  x26, x1, #0x01                                 ; 3a 04 00 d1  
    52 : str  x26, [sp, #0x1d0]                              ; fa eb 00 f9  
    53 : ldr  x26, [sp, #0x1b8]                              ; fa df 40 f9  
    54 : ldr  x27, [sp, #0x1d0]                              ; fb eb 40 f9  
    55 : sub  x25, x26, x27                                  ; 59 03 1b cb  
    56 : eor  x26, x26, x26                                  ; 5a 03 1a ca  
    57 : str  x26, [sp, #0x1d8]                              ; fa ef 00 f9  
    58 : ldr  x26, [sp, #0x1b8]                              ; fa df 40 f9  
    59 : ldr  x27, [sp, #0x1d0]                              ; fb eb 40 f9  
    60 : cmp  x26, x27                                       ; 5f 03 1b eb  
    61 : ldr  x26, [sp, #0x1d8]                              ; fa ef 40 f9  
    62 : csel x27, x25, x26, gt                              ; 3b c3 9a 9a  
    63 : str  x27, [sp, #0x198]                              ; fb cf 00 f9  
    64 : ldr  x27, [sp, #0x1b8]                              ; fb df 40 f9  
    65 : ldr  x26, [sp, #0x1d0]                              ; fa eb 40 f9  
    66 : cmp  x26, x27                                       ; 5f 03 1b eb  
    67 : ldr  x27, [sp, #0x1b8]                              ; fb df 40 f9  
    68 : ldr  x26, [sp, #0x1d0]                              ; fa eb 40 f9  
    69 : csel x28, x26, x27, lt                              ; 5c b3 9b 9a  
    70 : str  x28, [sp, #0x1a0]                              ; fc d3 00 f9  
    71 :      Loops_label_5:                                 ;              
    72 :      Loops_label_6:                                 ;              
    73 : ldr  x26, [sp, #0x198]                              ; fa cf 40 f9  
    74 : cmp  x26, #0                                        ; 5f 03 00 f1  
    75 : b.lt Loops_label_8                                  ; ab 07 00 54  
    76 : ldr  x26, [sp, #0x198]                              ; fa cf 40 f9  
    77 : cmp  x26, x2                                        ; 5f 03 02 eb  
    78 : b.ge Loops_label_8                                  ; 4a 07 00 54  
    79 : ldr  x26, [sp, #0x1a0]                              ; fa d3 40 f9  
    80 : cmp  x26, #0                                        ; 5f 03 00 f1  
    81 : b.lt Loops_label_8                                  ; eb 06 00 54  
    82 : ldr  x26, [sp, #0x1a0]                              ; fa d3 40 f9  
    83 : cmp  x26, x1                                        ; 5f 03 01 eb  
    84 : b.ge Loops_label_8                                  ; 8a 06 00 54  
    85 : mov  x25, #0xfd10                                   ; 19 a2 9f d2  
    86 : movk x25, #0x286, lsl #16                           ; d9 50 a0 f2  
    87 : movk x25, #0x01, lsl #32                            ; 39 00 c0 f2  
    88 : ldr  x26, [sp, #0x198]                              ; fa cf 40 f9  
    89 : ldr  x27, [sp, #0x1a0]                              ; fb d3 40 f9  
    90 : stp  x0, x1, [sp, #0]                               ; e0 07 00 a9  
    91 : stp  x2, x3, [sp, #0x10]                            ; e2 0f 01 a9  
    92 : stp  x4, x5, [sp, #0x20]                            ; e4 17 02 a9  
    93 : stp  x6, x7, [sp, #0x30]                            ; e6 1f 03 a9  
    94 : stp  x8, x9, [sp, #0x40]                            ; e8 27 04 a9  
    95 : stp  x10, x11, [sp, #0x50]                          ; ea 2f 05 a9  
    96 : stp  x12, x13, [sp, #0x60]                          ; ec 37 06 a9  
    97 : stp  x14, x15, [sp, #0x70]                          ; ee 3f 07 a9  
    98 : stp  x16, x17, [sp, #0x80]                          ; f0 47 08 a9  
    99 : mov  x0, x26                                        ; e0 03 1a aa  
   100 : mov  x1, x27                                        ; e1 03 1b aa  
   101 : add  x10, sp, #0x90                                 ; ea 43 02 91  
   102 : st1  {v0.2d, v1.2d, v2.2d, v3.2d}, [x10], #0x40     ; 40 2d 9f 4c  
   103 : st1  {v4.2d, v5.2d, v6.2d, v7.2d}, [x10], #0x40     ; 44 2d 9f 4c  
   104 : st1  {v8.2d, v9.2d, v10.2d, v11.2d}, [x10], #0x40   ; 48 2d 9f 4c  
   105 : st1  {v12.2d, v13.2d, v14.2d, v15.2d}, [x10], #0x40 ; 4c 2d 9f 4c  
   106 : blr  x25                                            ; 20 03 3f d6  
   107 : add  x10, sp, #0x90                                 ; ea 43 02 91  
   108 : ld1  {v0.2d, v1.2d, v2.2d, v3.2d}, [x10], #0x40     ; 40 2d df 4c  
   109 : ld1  {v4.2d, v5.2d, v6.2d, v7.2d}, [x10], #0x40     ; 44 2d df 4c  
   110 : ld1  {v8.2d, v9.2d, v10.2d, v11.2d}, [x10], #0x40   ; 48 2d df 4c  
   111 : ld1  {v12.2d, v13.2d, v14.2d, v15.2d}, [x10], #0x40 ; 4c 2d df 4c  
   112 : ldp  x0, x1, [sp, #0]                               ; e0 07 40 a9  
   113 : ldp  x2, x3, [sp, #0x10]                            ; e2 0f 41 a9  
   114 : ldp  x4, x5, [sp, #0x20]                            ; e4 17 42 a9  
   115 : ldp  x6, x7, [sp, #0x30]                            ; e6 1f 43 a9  
   116 : ldp  x8, x9, [sp, #0x40]                            ; e8 27 44 a9  
   117 : ldp  x10, x11, [sp, #0x50]                          ; ea 2f 45 a9  
   118 : ldp  x12, x13, [sp, #0x60]                          ; ec 37 46 a9  
   119 : ldp  x14, x15, [sp, #0x70]                          ; ee 3f 47 a9  
   120 : ldp  x16, x17, [sp, #0x80]                          ; f0 47 48 a9  
   121 : ldr  x26, [sp, #0x1a0]                              ; fa d3 40 f9  
   122 : mul  x25, x26, x2                                   ; 59 7f 02 9b  
   123 : ldr  x26, [sp, #0x198]                              ; fa cf 40 f9  
   124 : add  x25, x25, x26                                  ; 39 03 1a 8b  
   125 : strb w3, [x0, x25]                                  ; 03 68 39 38  
   126 : add  x3, x3, #0x01                                  ; 63 04 00 91  
   127 : ldr  x27, [sp, #0x1a8]                              ; fb d7 40 f9  
   128 : ldr  x26, [sp, #0x198]                              ; fa cf 40 f9  
   129 : add  x26, x26, x27                                  ; 5a 03 1b 8b  
   130 : str  x26, [sp, #0x198]                              ; fa cf 00 f9  
   131 : ldr  x27, [sp, #0x190]                              ; fb cb 40 f9  
   132 : ldr  x26, [sp, #0x1a0]                              ; fa d3 40 f9  
   133 : add  x26, x26, x27                                  ; 5a 03 1b 8b  
   134 : str  x26, [sp, #0x1a0]                              ; fa d3 00 f9  
   135 : b    Loops_label_6                                  ; c2 ff ff 17  
   136 :      Loops_label_8:                                 ;              
   137 : ldr  x26, [sp, #0x1a8]                              ; fa d7 40 f9  
   138 : neg  x26, x26                                       ; fa 03 1a cb  
   139 : str  x26, [sp, #0x1a8]                              ; fa d7 00 f9  
   140 : ldr  x26, [sp, #0x190]                              ; fa cb 40 f9  
   141 : neg  x26, x26                                       ; fa 03 1a cb  
   142 : str  x26, [sp, #0x190]                              ; fa cb 00 f9  
   143 : ldr  x26, [sp, #0x1b8]                              ; fa df 40 f9  
   144 : add  x26, x26, #0x01                                ; 5a 07 00 91  
   145 : str  x26, [sp, #0x1b8]                              ; fa df 00 f9  
   146 : b    Loops_label_0                                  ; 86 ff ff 17  
   147 :      Loops_label_2:                                 ;              
   148 : ldr  x29, [sp, #0x200]                              ; fd 03 41 f9  
   149 : ldr  x30, [sp, #0x208]                              ; fe 07 41 f9  
   150 : ldr  x25, [sp, #0x1e0]                              ; f9 f3 40 f9  
   151 : ldr  x26, [sp, #0x1e8]                              ; fa f7 40 f9  
   152 : ldr  x27, [sp, #0x1f0]                              ; fb fb 40 f9  
   153 : ldr  x28, [sp, #0x1f8]                              ; fc ff 40 f9  
   154 : add  sp, sp, #0x210                                 ; ff 43 08 91  
   155 : ret  x30                                            ; c0 03 5f d6  
