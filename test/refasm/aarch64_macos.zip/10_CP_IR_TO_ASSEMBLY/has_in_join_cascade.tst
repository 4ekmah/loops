has_in_join_cascade(i0, i1, i2)
     0 : sub   sp, sp, #0x80    ; ff 03 02 d1  
     1 : str   x25, [sp, #0x68] ; f9 37 00 f9  
     2 : str   x26, [sp, #0x70] ; fa 3b 00 f9  
     3 : str   x27, [sp, #0x78] ; fb 3f 00 f9  
     4 : eor   x26, x26, x26    ; 5a 03 1a ca  
     5 : str   x26, [sp, #0x28] ; fa 17 00 f9  
     6 : ldr   x26, [x0, #0x10] ; 1a 08 40 f9  
     7 : str   x26, [sp, #0x30] ; fa 1b 00 f9  
     8 : ldr   x26, [x0, #0]    ; 1a 00 40 f9  
     9 : str   x26, [sp, #0x38] ; fa 1f 00 f9  
    10 : ldr   x26, [x0, #0x08] ; 1a 04 40 f9  
    11 : str   x26, [sp, #0x40] ; fa 23 00 f9  
    12 :       Loops_label_0:   ;              
    13 : ldr   x26, [sp, #0x30] ; fa 1b 40 f9  
    14 : cmp   x26, #0          ; 5f 03 00 f1  
    15 : b.le  Loops_label_2    ; cd 0a 00 54  
    16 : ldr   x26, [sp, #0x38] ; fa 1f 40 f9  
    17 : ldrsw x27, [x26, #0]   ; 5b 03 80 b9  
    18 : str   x27, [sp, #0x48] ; fb 27 00 f9  
    19 : ldr   x26, [sp, #0x38] ; fa 1f 40 f9  
    20 : add   x26, x26, #0x04  ; 5a 13 00 91  
    21 : str   x26, [sp, #0x38] ; fa 1f 00 f9  
    22 : ldr   x26, [sp, #0x40] ; fa 23 40 f9  
    23 : ldrsw x27, [x26, #0]   ; 5b 03 80 b9  
    24 : str   x27, [sp, #0x20] ; fb 13 00 f9  
    25 : ldr   x26, [sp, #0x40] ; fa 23 40 f9  
    26 : add   x26, x26, #0x04  ; 5a 13 00 91  
    27 : str   x26, [sp, #0x40] ; fa 23 00 f9  
    28 : ldr   x26, [sp, #0x30] ; fa 1b 40 f9  
    29 : sub   x26, x26, #0x01  ; 5a 07 00 d1  
    30 : str   x26, [sp, #0x30] ; fa 1b 00 f9  
    31 : ldr   x26, [x0, #0x28] ; 1a 14 40 f9  
    32 : str   x26, [sp, #0x50] ; fa 2b 00 f9  
    33 : ldr   x26, [x0, #0x18] ; 1a 0c 40 f9  
    34 : str   x26, [sp, #0x58] ; fa 2f 00 f9  
    35 : ldr   x26, [x0, #0x20] ; 1a 10 40 f9  
    36 : str   x26, [sp, #0x60] ; fa 33 00 f9  
    37 :       Loops_label_3:   ;              
    38 : ldr   x26, [sp, #0x50] ; fa 2b 40 f9  
    39 : cmp   x26, #0          ; 5f 03 00 f1  
    40 : b.le  Loops_label_5    ; ad 07 00 54  
    41 : ldr   x26, [sp, #0x58] ; fa 2f 40 f9  
    42 : ldrsw x27, [x26, #0]   ; 5b 03 80 b9  
    43 : str   x27, [sp, #0]    ; fb 03 00 f9  
    44 : ldr   x26, [sp, #0x58] ; fa 2f 40 f9  
    45 : add   x26, x26, #0x04  ; 5a 13 00 91  
    46 : str   x26, [sp, #0x58] ; fa 2f 00 f9  
    47 : ldr   x26, [sp, #0x60] ; fa 33 40 f9  
    48 : ldrsw x3, [x26, #0]    ; 43 03 80 b9  
    49 : ldr   x26, [sp, #0x60] ; fa 33 40 f9  
    50 : add   x26, x26, #0x04  ; 5a 13 00 91  
    51 : str   x26, [sp, #0x60] ; fa 33 00 f9  
    52 : ldr   x26, [sp, #0x50] ; fa 2b 40 f9  
    53 : sub   x26, x26, #0x01  ; 5a 07 00 d1  
    54 : str   x26, [sp, #0x50] ; fa 2b 00 f9  
    55 : ldr   x26, [sp, #0x48] ; fa 27 40 f9  
    56 : cmp   x3, x26          ; 7f 00 1a eb  
    57 : b.le  Loops_label_7    ; 4d 00 00 54  
    58 : b     Loops_label_0    ; d4 ff ff 17  
    59 :       Loops_label_7:   ;              
    60 : ldr   x26, [sp, #0x48] ; fa 27 40 f9  
    61 : cmp   x3, x26          ; 7f 00 1a eb  
    62 : b.ne  Loops_label_10   ; e1 04 00 54  
    63 : ldr   x26, [x0, #0x40] ; 1a 20 40 f9  
    64 : str   x26, [sp, #0x08] ; fa 07 00 f9  
    65 : ldr   x26, [x0, #0x30] ; 1a 18 40 f9  
    66 : str   x26, [sp, #0x10] ; fa 0b 00 f9  
    67 : ldr   x26, [x0, #0x38] ; 1a 1c 40 f9  
    68 : str   x26, [sp, #0x18] ; fa 0f 00 f9  
    69 :       Loops_label_11:  ;              
    70 : ldr   x26, [sp, #0x08] ; fa 07 40 f9  
    71 : cmp   x26, #0          ; 5f 03 00 f1  
    72 : b.le  Loops_label_10   ; cd 03 00 54  
    73 : ldr   x26, [sp, #0x10] ; fa 0b 40 f9  
    74 : ldrsw x25, [x26, #0]   ; 59 03 80 b9  
    75 : ldr   x26, [sp, #0x10] ; fa 0b 40 f9  
    76 : add   x26, x26, #0x04  ; 5a 13 00 91  
    77 : str   x26, [sp, #0x10] ; fa 0b 00 f9  
    78 : ldr   x26, [sp, #0x18] ; fa 0f 40 f9  
    79 : ldrsw x3, [x26, #0]    ; 43 03 80 b9  
    80 : ldr   x26, [sp, #0x18] ; fa 0f 40 f9  
    81 : add   x26, x26, #0x04  ; 5a 13 00 91  
    82 : str   x26, [sp, #0x18] ; fa 0f 00 f9  
    83 : ldr   x26, [sp, #0x08] ; fa 07 40 f9  
    84 : sub   x26, x26, #0x01  ; 5a 07 00 d1  
    85 : str   x26, [sp, #0x08] ; fa 07 00 f9  
    86 : ldr   x26, [sp, #0x20] ; fa 13 40 f9  
    87 : cmp   x25, x26         ; 3f 03 1a eb  
    88 : b.le  Loops_label_15   ; 4d 00 00 54  
    89 : b     Loops_label_0    ; b7 ff ff 17  
    90 :       Loops_label_15:  ;              
    91 : ldr   x26, [sp, #0x20] ; fa 13 40 f9  
    92 : cmp   x25, x26         ; 3f 03 1a eb  
    93 : b.ne  Loops_label_18   ; 21 01 00 54  
    94 : ldr   x26, [sp, #0]    ; fa 03 40 f9  
    95 : cmp   x26, x1          ; 5f 03 01 eb  
    96 : b.ne  Loops_label_18   ; c1 00 00 54  
    97 : cmp   x3, x2           ; 7f 00 02 eb  
    98 : b.ne  Loops_label_18   ; 81 00 00 54  
    99 : mov   x26, #0x01       ; 3a 00 80 d2  
   100 : str   x26, [sp, #0x28] ; fa 17 00 f9  
   101 : b     Loops_label_2    ; 04 00 00 14  
   102 :       Loops_label_16:  ;              
   103 :       Loops_label_18:  ;              
   104 : b     Loops_label_11   ; e1 ff ff 17  
   105 :       Loops_label_13:  ;              
   106 :       Loops_label_8:   ;              
   107 :       Loops_label_10:  ;              
   108 : b     Loops_label_3    ; c2 ff ff 17  
   109 :       Loops_label_5:   ;              
   110 : b     Loops_label_0    ; a9 ff ff 17  
   111 :       Loops_label_2:   ;              
   112 : ldr   x26, [sp, #0x28] ; fa 17 40 f9  
   113 : mov   x0, x26          ; e0 03 1a aa  
   114 : ldr   x25, [sp, #0x68] ; f9 37 40 f9  
   115 : ldr   x26, [sp, #0x70] ; fa 3b 40 f9  
   116 : ldr   x27, [sp, #0x78] ; fb 3f 40 f9  
   117 : add   sp, sp, #0x80    ; ff 03 02 91  
   118 : ret   x30              ; c0 03 5f d6  
