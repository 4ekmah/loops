sort_double(i0, i1)
     0 : sub  sp, sp, #0x1e0                                 ; ff 83 07 d1  
     1 : str  x25, [sp, #0x1b8]                              ; f9 df 00 f9  
     2 : str  x26, [sp, #0x1c0]                              ; fa e3 00 f9  
     3 : str  x27, [sp, #0x1c8]                              ; fb e7 00 f9  
     4 : stp  x29, x30, [sp, #0x1d0]                         ; fd 7b 1d a9  
     5 : mov  x29, sp                                        ; fd 03 1f aa  
     6 : lsl  x26, x1, #0x03                                 ; 3a f0 7d d3  
     7 : str  x26, [sp, #0x1a0]                              ; fa d3 00 f9  
     8 : ldr  x26, [sp, #0x1a0]                              ; fa d3 40 f9  
     9 : sub  x27, x26, #0x08                                ; 5b 23 00 d1  
    10 : str  x27, [sp, #0x1a8]                              ; fb d7 00 f9  
    11 : eor  x26, x26, x26                                  ; 5a 03 1a ca  
    12 : str  x26, [sp, #0x1b0]                              ; fa db 00 f9  
    13 :      Loops_label_0:                                 ;              
    14 : ldr  x27, [sp, #0x1a8]                              ; fb d7 40 f9  
    15 : ldr  x26, [sp, #0x1b0]                              ; fa db 40 f9  
    16 : cmp  x26, x27                                       ; 5f 03 1b eb  
    17 : b.ge Loops_label_2                                  ; 6a 09 00 54  
    18 : ldr  x26, [sp, #0x1b0]                              ; fa db 40 f9  
    19 : mov  x27, x26                                       ; fb 03 1a aa  
    20 : str  x27, [sp, #0x198]                              ; fb cf 00 f9  
    21 : ldr  x26, [sp, #0x198]                              ; fa cf 40 f9  
    22 : add  x27, x26, #0x08                                ; 5b 23 00 91  
    23 : str  x27, [sp, #0x190]                              ; fb cb 00 f9  
    24 :      Loops_label_3:                                 ;              
    25 : ldr  x27, [sp, #0x1a0]                              ; fb d3 40 f9  
    26 : ldr  x26, [sp, #0x190]                              ; fa cb 40 f9  
    27 : cmp  x26, x27                                       ; 5f 03 1b eb  
    28 : b.ge Loops_label_5                                  ; 2a 06 00 54  
    29 : ldr  x26, [sp, #0x190]                              ; fa cb 40 f9  
    30 : ldr  x25, [x0, x26]                                 ; 19 68 7a f8  
    31 : ldr  x26, [sp, #0x198]                              ; fa cf 40 f9  
    32 : ldr  x3, [x0, x26]                                  ; 03 68 7a f8  
    33 : mov  x2, #0x2420                                    ; 02 84 84 d2  
    34 : movk x2, #0x287, lsl #16                            ; e2 50 a0 f2  
    35 : movk x2, #0x01, lsl #32                             ; 22 00 c0 f2  
    36 : stp  x0, x1, [sp, #0]                               ; e0 07 00 a9  
    37 : stp  x2, x3, [sp, #0x10]                            ; e2 0f 01 a9  
    38 : stp  x4, x5, [sp, #0x20]                            ; e4 17 02 a9  
    39 : stp  x6, x7, [sp, #0x30]                            ; e6 1f 03 a9  
    40 : stp  x8, x9, [sp, #0x40]                            ; e8 27 04 a9  
    41 : stp  x10, x11, [sp, #0x50]                          ; ea 2f 05 a9  
    42 : stp  x12, x13, [sp, #0x60]                          ; ec 37 06 a9  
    43 : stp  x14, x15, [sp, #0x70]                          ; ee 3f 07 a9  
    44 : stp  x16, x17, [sp, #0x80]                          ; f0 47 08 a9  
    45 : mov  x0, x25                                        ; e0 03 19 aa  
    46 : mov  x1, x3                                         ; e1 03 03 aa  
    47 : add  x10, sp, #0x90                                 ; ea 43 02 91  
    48 : st1  {v0.2d, v1.2d, v2.2d, v3.2d}, [x10], #0x40     ; 40 2d 9f 4c  
    49 : st1  {v4.2d, v5.2d, v6.2d, v7.2d}, [x10], #0x40     ; 44 2d 9f 4c  
    50 : st1  {v8.2d, v9.2d, v10.2d, v11.2d}, [x10], #0x40   ; 48 2d 9f 4c  
    51 : st1  {v12.2d, v13.2d, v14.2d, v15.2d}, [x10], #0x40 ; 4c 2d 9f 4c  
    52 : blr  x2                                             ; 40 00 3f d6  
    53 : add  x10, sp, #0x90                                 ; ea 43 02 91  
    54 : ld1  {v0.2d, v1.2d, v2.2d, v3.2d}, [x10], #0x40     ; 40 2d df 4c  
    55 : ld1  {v4.2d, v5.2d, v6.2d, v7.2d}, [x10], #0x40     ; 44 2d df 4c  
    56 : ld1  {v8.2d, v9.2d, v10.2d, v11.2d}, [x10], #0x40   ; 48 2d df 4c  
    57 : ld1  {v12.2d, v13.2d, v14.2d, v15.2d}, [x10], #0x40 ; 4c 2d df 4c  
    58 : mov  x2, x0                                         ; e2 03 00 aa  
    59 : ldp  x0, x1, [sp, #0]                               ; e0 07 40 a9  
    60 : ldr  x3, [sp, #0x18]                                ; e3 0f 40 f9  
    61 : ldp  x4, x5, [sp, #0x20]                            ; e4 17 42 a9  
    62 : ldp  x6, x7, [sp, #0x30]                            ; e6 1f 43 a9  
    63 : ldp  x8, x9, [sp, #0x40]                            ; e8 27 44 a9  
    64 : ldp  x10, x11, [sp, #0x50]                          ; ea 2f 45 a9  
    65 : ldp  x12, x13, [sp, #0x60]                          ; ec 37 46 a9  
    66 : ldp  x14, x15, [sp, #0x70]                          ; ee 3f 47 a9  
    67 : ldp  x16, x17, [sp, #0x80]                          ; f0 47 48 a9  
    68 : cmp  x2, #0                                         ; 5f 00 00 f1  
    69 : b.eq Loops_label_7                                  ; 80 00 00 54  
    70 : ldr  x26, [sp, #0x190]                              ; fa cb 40 f9  
    71 : mov  x27, x26                                       ; fb 03 1a aa  
    72 : str  x27, [sp, #0x198]                              ; fb cf 00 f9  
    73 :      Loops_label_7:                                 ;              
    74 : ldr  x26, [sp, #0x190]                              ; fa cb 40 f9  
    75 : add  x26, x26, #0x08                                ; 5a 23 00 91  
    76 : str  x26, [sp, #0x190]                              ; fa cb 00 f9  
    77 : b    Loops_label_3                                  ; cd ff ff 17  
    78 :      Loops_label_5:                                 ;              
    79 : ldr  x27, [sp, #0x1b0]                              ; fb db 40 f9  
    80 : ldr  x26, [sp, #0x198]                              ; fa cf 40 f9  
    81 : cmp  x26, x27                                       ; 5f 03 1b eb  
    82 : b.eq Loops_label_9                                  ; 20 01 00 54  
    83 : ldr  x26, [sp, #0x1b0]                              ; fa db 40 f9  
    84 : ldr  x2, [x0, x26]                                  ; 02 68 7a f8  
    85 : ldr  x26, [sp, #0x198]                              ; fa cf 40 f9  
    86 : ldr  x3, [x0, x26]                                  ; 03 68 7a f8  
    87 : ldr  x26, [sp, #0x198]                              ; fa cf 40 f9  
    88 : str  x2, [x0, x26]                                  ; 02 68 3a f8  
    89 : ldr  x26, [sp, #0x1b0]                              ; fa db 40 f9  
    90 : str  x3, [x0, x26]                                  ; 03 68 3a f8  
    91 :      Loops_label_9:                                 ;              
    92 : ldr  x26, [sp, #0x1b0]                              ; fa db 40 f9  
    93 : add  x26, x26, #0x08                                ; 5a 23 00 91  
    94 : str  x26, [sp, #0x1b0]                              ; fa db 00 f9  
    95 : b    Loops_label_0                                  ; b3 ff ff 17  
    96 :      Loops_label_2:                                 ;              
    97 : ldp  x29, x30, [sp, #0x1d0]                         ; fd 7b 5d a9  
    98 : ldr  x25, [sp, #0x1b8]                              ; f9 df 40 f9  
    99 : ldr  x26, [sp, #0x1c0]                              ; fa e3 40 f9  
   100 : ldr  x27, [sp, #0x1c8]                              ; fb e7 40 f9  
   101 : add  sp, sp, #0x1e0                                 ; ff 83 07 91  
   102 : ret  x30                                            ; c0 03 5f d6  
