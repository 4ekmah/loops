conditionpainter(i0)
     0 : sub  sp, sp, #0x40    ; ff 03 01 d1  
     1 : str  x25, [sp, #0x28] ; f9 17 00 f9  
     2 : str  x26, [sp, #0x30] ; fa 1b 00 f9  
     3 : movn x26, #0x04       ; 9a 00 80 92  
     4 : str  x26, [sp, #0x10] ; fa 0b 00 f9  
     5 :      Loops_label_0:   ;              
     6 : ldr  x26, [sp, #0x10] ; fa 0b 40 f9  
     7 : cmp  x26, #0x05       ; 5f 17 00 f1  
     8 : b.gt Loops_label_2    ; ac 10 00 54  
     9 : ldr  x26, [sp, #0x10] ; fa 0b 40 f9  
    10 : add  x1, x26, #0x05   ; 41 17 00 91  
    11 : mov  x2, #0x0b        ; 62 01 80 d2  
    12 : mul  x1, x1, x2       ; 21 7c 02 9b  
    13 : mov  x2, #0x08        ; 02 01 80 d2  
    14 : mul  x26, x1, x2      ; 3a 7c 02 9b  
    15 : str  x26, [sp, #0x08] ; fa 07 00 f9  
    16 : movn x26, #0x04       ; 9a 00 80 92  
    17 : str  x26, [sp, #0]    ; fa 03 00 f9  
    18 :      Loops_label_3:   ;              
    19 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
    20 : cmp  x26, #0x05       ; 5f 17 00 f1  
    21 : b.gt Loops_label_5    ; ac 0e 00 54  
    22 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
    23 : add  x25, x26, #0x03  ; 59 0f 00 91  
    24 : ldr  x26, [sp, #0x10] ; fa 0b 40 f9  
    25 : cmp  x26, x25         ; 5f 03 19 eb  
    26 : cset x25, ge          ; f9 b7 9f 9a  
    27 : ldr  x26, [sp, #0x10] ; fa 0b 40 f9  
    28 : cmp  x26, #0x04       ; 5f 13 00 f1  
    29 : cset x3, le           ; e3 c7 9f 9a  
    30 : and  x3, x25, x3      ; 23 03 03 8a  
    31 : movn x25, #0x01       ; 39 00 80 92  
    32 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
    33 : cmp  x26, x25         ; 5f 03 19 eb  
    34 : cset x25, ge          ; f9 b7 9f 9a  
    35 : and  x3, x3, x25      ; 63 00 19 8a  
    36 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
    37 : cmp  x26, #0          ; 5f 03 00 f1  
    38 : cset x25, le          ; f9 c7 9f 9a  
    39 : and  x3, x3, x25      ; 63 00 19 8a  
    40 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
    41 : sub  x25, x26, #0x01  ; 59 07 00 d1  
    42 : ldr  x26, [sp, #0x10] ; fa 0b 40 f9  
    43 : cmp  x26, x25         ; 5f 03 19 eb  
    44 : cset x25, le          ; f9 c7 9f 9a  
    45 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
    46 : cmp  x26, #0          ; 5f 03 00 f1  
    47 : cset x2, ge           ; e2 b7 9f 9a  
    48 : and  x2, x25, x2      ; 22 03 02 8a  
    49 : ldr  x26, [sp, #0x10] ; fa 0b 40 f9  
    50 : cmp  x26, #0          ; 5f 03 00 f1  
    51 : cset x25, le          ; f9 c7 9f 9a  
    52 : and  x2, x2, x25      ; 42 00 19 8a  
    53 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
    54 : mul  x25, x26, x26    ; 59 7f 1a 9b  
    55 : ldr  x26, [sp, #0x10] ; fa 0b 40 f9  
    56 : mul  x1, x26, x26     ; 41 7f 1a 9b  
    57 : add  x1, x25, x1      ; 21 03 01 8b  
    58 : cmp  x1, #0x09        ; 3f 24 00 f1  
    59 : cset x1, le           ; e1 c7 9f 9a  
    60 : and  x1, x2, x1       ; 41 00 01 8a  
    61 : orr  x26, x3, x1      ; 7a 00 01 aa  
    62 : str  x26, [sp, #0x18] ; fa 0f 00 f9  
    63 : mov  x2, #0x02        ; 42 00 80 d2  
    64 : eor  x26, x26, x26    ; 5a 03 1a ca  
    65 : str  x26, [sp, #0x20] ; fa 13 00 f9  
    66 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
    67 : cmp  x26, #0x02       ; 5f 0b 00 f1  
    68 : cset x25, ge          ; f9 b7 9f 9a  
    69 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
    70 : cmp  x26, #0x04       ; 5f 13 00 f1  
    71 : cset x1, le           ; e1 c7 9f 9a  
    72 : and  x1, x25, x1      ; 21 03 01 8a  
    73 : ldr  x26, [sp, #0x10] ; fa 0b 40 f9  
    74 : cmp  x26, #0x01       ; 5f 07 00 f1  
    75 : cset x25, ge          ; f9 b7 9f 9a  
    76 : ldr  x26, [sp, #0x10] ; fa 0b 40 f9  
    77 : cmp  x26, #0x03       ; 5f 0f 00 f1  
    78 : cset x3, le           ; e3 c7 9f 9a  
    79 : and  x3, x25, x3      ; 23 03 03 8a  
    80 : orr  x1, x1, x3       ; 21 00 03 aa  
    81 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
    82 : mul  x3, x26, x26     ; 43 7f 1a 9b  
    83 : ldr  x26, [sp, #0x10] ; fa 0b 40 f9  
    84 : mul  x25, x26, x26    ; 59 7f 1a 9b  
    85 : add  x3, x3, x25      ; 63 00 19 8b  
    86 : cmp  x3, #0x10        ; 7f 40 00 f1  
    87 : cset x3, le           ; e3 c7 9f 9a  
    88 : and  x1, x1, x3       ; 21 00 03 8a  
    89 : cmp  x1, #0           ; 3f 00 00 f1  
    90 : ldr  x26, [sp, #0x20] ; fa 13 40 f9  
    91 : csel x1, x2, x26, ne  ; 41 10 9a 9a  
    92 : ldr  x26, [sp, #0x18] ; fa 0f 40 f9  
    93 : add  x1, x26, x1      ; 41 03 01 8b  
    94 : mov  x2, #0x02        ; 42 00 80 d2  
    95 : ldr  x26, [sp, #0x10] ; fa 0b 40 f9  
    96 : mul  x2, x26, x2      ; 42 7f 02 9b  
    97 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
    98 : cmp  x2, x26          ; 5f 00 1a eb  
    99 : b.lt Loops_label_8    ; 4b 01 00 54  
   100 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
   101 : add  x2, x26, #0x03   ; 42 0f 00 91  
   102 : neg  x2, x2           ; e2 03 02 cb  
   103 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
   104 : add  x3, x26, #0x03   ; 43 0f 00 91  
   105 : mul  x2, x2, x3       ; 42 7c 03 9b  
   106 : ldr  x26, [sp, #0x10] ; fa 0b 40 f9  
   107 : cmp  x26, x2          ; 5f 03 02 eb  
   108 : b.le Loops_label_9    ; 0d 02 00 54  
   109 :      Loops_label_8:   ;              
   110 : mov  x2, #0x02        ; 42 00 80 d2  
   111 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
   112 : mul  x2, x26, x2      ; 42 7f 02 9b  
   113 : ldr  x26, [sp, #0x10] ; fa 0b 40 f9  
   114 : cmp  x26, x2          ; 5f 03 02 eb  
   115 : b.gt Loops_label_7    ; cc 01 00 54  
   116 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
   117 : add  x2, x26, #0x03   ; 42 0f 00 91  
   118 : neg  x2, x2           ; e2 03 02 cb  
   119 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
   120 : add  x3, x26, #0x03   ; 43 0f 00 91  
   121 : mul  x2, x2, x3       ; 42 7c 03 9b  
   122 : ldr  x26, [sp, #0x10] ; fa 0b 40 f9  
   123 : cmp  x26, x2          ; 5f 03 02 eb  
   124 : b.lt Loops_label_7    ; ab 00 00 54  
   125 :      Loops_label_9:   ;              
   126 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
   127 : cmp  x26, #0          ; 5f 03 00 f1  
   128 : b.gt Loops_label_7    ; 4c 00 00 54  
   129 : add  x1, x1, #0x03    ; 21 0c 00 91  
   130 :      Loops_label_7:   ;              
   131 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
   132 : add  x2, x26, #0x05   ; 42 17 00 91  
   133 : lsl  x2, x2, #0x03    ; 42 f0 7d d3  
   134 : ldr  x26, [sp, #0x08] ; fa 07 40 f9  
   135 : add  x2, x26, x2      ; 42 03 02 8b  
   136 : str  x1, [x0, x2]     ; 01 68 22 f8  
   137 : ldr  x26, [sp, #0]    ; fa 03 40 f9  
   138 : add  x26, x26, #0x01  ; 5a 07 00 91  
   139 : str  x26, [sp, #0]    ; fa 03 00 f9  
   140 : b    Loops_label_3    ; 8a ff ff 17  
   141 :      Loops_label_5:   ;              
   142 : ldr  x26, [sp, #0x10] ; fa 0b 40 f9  
   143 : add  x26, x26, #0x01  ; 5a 07 00 91  
   144 : str  x26, [sp, #0x10] ; fa 0b 00 f9  
   145 : b    Loops_label_0    ; 7a ff ff 17  
   146 :      Loops_label_2:   ;              
   147 : ldr  x25, [sp, #0x28] ; f9 17 40 f9  
   148 : ldr  x26, [sp, #0x30] ; fa 1b 40 f9  
   149 : add  sp, sp, #0x40    ; ff 03 01 91  
   150 : ret  x30              ; c0 03 5f d6  
