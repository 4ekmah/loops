has_in_join_cascade(i0, i1, i2)
     0 : mov                    i3, 0            
     1 : load.i64               i4, i0, 16       
     2 : load.i64               i5, i0, 0        
     3 : load.i64               i6, i0, 8        
     4 : annotation:whilecstart 0                
     5 : cmp                    i4, 0            
     6 : jmp_le                 __loops_label_2  
     7 : annotation:whilecend                    
     8 : load.i32               i7, i5           
     9 : add                    i5, i5, 4        
    10 : load.i32               i8, i6           
    11 : add                    i6, i6, 4        
    12 : sub                    i4, i4, 1        
    13 : load.i64               i9, i0, 40       
    14 : load.i64               i10, i0, 24      
    15 : load.i64               i11, i0, 32      
    16 : annotation:whilecstart 3                
    17 : cmp                    i9, 0            
    18 : jmp_le                 __loops_label_5  
    19 : annotation:whilecend                    
    20 : load.i32               i12, i10         
    21 : add                    i10, i10, 4      
    22 : load.i32               i13, i11         
    23 : add                    i11, i11, 4      
    24 : sub                    i9, i9, 1        
    25 : annotation:ifcstart                     
    26 : cmp                    i13, i7          
    27 : jmp_le                 __loops_label_7  
    28 : annotation:ifcend                       
    29 : annotation:break       3                
    30 : annotation:else        7, 8             
    31 : annotation:ifcstart                     
    32 : cmp                    i13, i7          
    33 : jmp_ne                 __loops_label_10 
    34 : annotation:ifcend                       
    35 : load.i64               i14, i0, 64      
    36 : load.i64               i15, i0, 48      
    37 : load.i64               i16, i0, 56      
    38 : annotation:whilecstart 11               
    39 : cmp                    i14, 0           
    40 : jmp_le                 __loops_label_13 
    41 : annotation:whilecend                    
    42 : load.i32               i17, i15         
    43 : add                    i15, i15, 4      
    44 : load.i32               i18, i16         
    45 : add                    i16, i16, 4      
    46 : sub                    i14, i14, 1      
    47 : annotation:ifcstart                     
    48 : cmp                    i17, i8          
    49 : jmp_le                 __loops_label_15 
    50 : annotation:ifcend                       
    51 : annotation:break       11               
    52 : annotation:else        15, 16           
    53 : annotation:ifcstart                     
    54 : cmp                    i17, i8          
    55 : jmp_ne                 __loops_label_18 
    56 : cmp                    i12, i1          
    57 : jmp_ne                 __loops_label_18 
    58 : cmp                    i18, i2          
    59 : jmp_ne                 __loops_label_18 
    60 : annotation:ifcend                       
    61 : mov                    i3, 1            
    62 : annotation:break       2                
    63 : annotation:endif       16               
    64 : annotation:endif       18               
    65 : annotation:endwhile    11, 13           
    66 : annotation:endif       8                
    67 : annotation:endif       10               
    68 : annotation:endwhile    3, 5             
    69 : annotation:endwhile    0, 2             
    70 : mov                    iR, i3           
    71 : ret                                     
