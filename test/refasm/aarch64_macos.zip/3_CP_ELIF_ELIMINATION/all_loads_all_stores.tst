all_loads_all_stores(i0, i1, i2, i3, i4)
     0 : mov                    i5, 0            
     1 : mov                    i6, 0            
     2 : mov                    i7, 0            
     3 : mov                    i8, 2            
     4 : mov                    i9, 1            
     5 : cmp                    i1, 1            
     6 : select_gt              i10, i8, i9      
     7 : mov                    i11, 4           
     8 : cmp                    i1, 3            
     9 : select_gt              i10, i11, i10    
    10 : mov                    i12, 8           
    11 : cmp                    i1, 5            
    12 : select_gt              i10, i12, i10    
    13 : mov                    i13, 2           
    14 : mov                    i14, 1           
    15 : cmp                    i3, 1            
    16 : select_gt              i15, i13, i14    
    17 : mov                    i16, 4           
    18 : cmp                    i3, 3            
    19 : select_gt              i15, i16, i15    
    20 : mov                    i17, 8           
    21 : cmp                    i3, 5            
    22 : select_gt              i15, i17, i15    
    23 : annotation:whilecstart 0                
    24 : cmp                    i5, i4           
    25 : jmp_ge                 __loops_label_2  
    26 : annotation:whilecend                    
    27 : def                    i18              
    28 : annotation:ifcstart                     
    29 : cmp                    i1, 0            
    30 : jmp_ne                 __loops_label_4  
    31 : annotation:ifcend                       
    32 : load.u8                i18, i0, i6      
    33 : annotation:else        4, 5             
    34 : annotation:ifcstart                     
    35 : cmp                    i1, 1            
    36 : jmp_ne                 __loops_label_7  
    37 : annotation:ifcend                       
    38 : load.i8                i18, i0, i6      
    39 : annotation:else        7, 8             
    40 : annotation:ifcstart                     
    41 : cmp                    i1, 2            
    42 : jmp_ne                 __loops_label_10 
    43 : annotation:ifcend                       
    44 : load.u16               i18, i0, i6      
    45 : annotation:else        10, 11           
    46 : annotation:ifcstart                     
    47 : cmp                    i1, 3            
    48 : jmp_ne                 __loops_label_13 
    49 : annotation:ifcend                       
    50 : load.i16               i18, i0, i6      
    51 : annotation:else        13, 14           
    52 : annotation:ifcstart                     
    53 : cmp                    i1, 4            
    54 : jmp_ne                 __loops_label_16 
    55 : annotation:ifcend                       
    56 : load.u32               i18, i0, i6      
    57 : annotation:else        16, 17           
    58 : annotation:ifcstart                     
    59 : cmp                    i1, 5            
    60 : jmp_ne                 __loops_label_19 
    61 : annotation:ifcend                       
    62 : load.i32               i18, i0, i6      
    63 : annotation:else        19, 20           
    64 : annotation:ifcstart                     
    65 : cmp                    i1, 6            
    66 : jmp_ne                 __loops_label_22 
    67 : annotation:ifcend                       
    68 : load.u64               i18, i0, i6      
    69 : annotation:else        22, 23           
    70 : load.i64               i18, i0, i6      
    71 : annotation:endif       5                
    72 : annotation:endif       8                
    73 : annotation:endif       11               
    74 : annotation:endif       14               
    75 : annotation:endif       17               
    76 : annotation:endif       20               
    77 : annotation:endif       23               
    78 : annotation:ifcstart                     
    79 : cmp                    i3, 0            
    80 : jmp_ne                 __loops_label_25 
    81 : annotation:ifcend                       
    82 : store.u8               i2, i7, i18      
    83 : annotation:else        25, 26           
    84 : annotation:ifcstart                     
    85 : cmp                    i3, 1            
    86 : jmp_ne                 __loops_label_28 
    87 : annotation:ifcend                       
    88 : store.i8               i2, i7, i18      
    89 : annotation:else        28, 29           
    90 : annotation:ifcstart                     
    91 : cmp                    i3, 2            
    92 : jmp_ne                 __loops_label_31 
    93 : annotation:ifcend                       
    94 : store.u16              i2, i7, i18      
    95 : annotation:else        31, 32           
    96 : annotation:ifcstart                     
    97 : cmp                    i3, 3            
    98 : jmp_ne                 __loops_label_34 
    99 : annotation:ifcend                       
   100 : store.i16              i2, i7, i18      
   101 : annotation:else        34, 35           
   102 : annotation:ifcstart                     
   103 : cmp                    i3, 4            
   104 : jmp_ne                 __loops_label_37 
   105 : annotation:ifcend                       
   106 : store.u32              i2, i7, i18      
   107 : annotation:else        37, 38           
   108 : annotation:ifcstart                     
   109 : cmp                    i3, 5            
   110 : jmp_ne                 __loops_label_40 
   111 : annotation:ifcend                       
   112 : store.i32              i2, i7, i18      
   113 : annotation:else        40, 41           
   114 : annotation:ifcstart                     
   115 : cmp                    i3, 6            
   116 : jmp_ne                 __loops_label_43 
   117 : annotation:ifcend                       
   118 : store.u64              i2, i7, i18      
   119 : annotation:else        43, 44           
   120 : store.i64              i2, i7, i18      
   121 : annotation:endif       26               
   122 : annotation:endif       29               
   123 : annotation:endif       32               
   124 : annotation:endif       35               
   125 : annotation:endif       38               
   126 : annotation:endif       41               
   127 : annotation:endif       44               
   128 : add                    i6, i6, i10      
   129 : add                    i7, i7, i15      
   130 : add                    i5, i5, 1        
   131 : annotation:endwhile    0, 2             
