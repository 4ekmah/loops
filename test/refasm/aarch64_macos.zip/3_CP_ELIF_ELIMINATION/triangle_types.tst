triangle_types(i0, i1, i2)
     0 : annotation:ifcstart                  
     1 : cmp                 i0, 0            
     2 : jmp_le              __loops_label_0  
     3 : cmp                 i1, 0            
     4 : jmp_le              __loops_label_0  
     5 : cmp                 i2, 0            
     6 : jmp_gt              __loops_label_1  
     7 : __loops_label_0:                     
     8 : annotation:ifcend                    
     9 : mov                 iR, 0            
    10 : ret                                  
    11 : annotation:else     1, 2             
    12 : annotation:ifcstart                  
    13 : add                 i3, i1, i2       
    14 : cmp                 i0, i3           
    15 : jmp_gt              __loops_label_3  
    16 : add                 i4, i0, i2       
    17 : cmp                 i1, i4           
    18 : jmp_gt              __loops_label_3  
    19 : add                 i5, i0, i1       
    20 : cmp                 i2, i5           
    21 : jmp_le              __loops_label_4  
    22 : __loops_label_3:                     
    23 : annotation:ifcend                    
    24 : mov                 iR, 0            
    25 : ret                                  
    26 : annotation:else     4, 5             
    27 : annotation:ifcstart                  
    28 : cmp                 i0, i1           
    29 : jmp_ne              __loops_label_7  
    30 : cmp                 i0, i2           
    31 : jmp_ne              __loops_label_7  
    32 : annotation:ifcend                    
    33 : mov                 iR, 2            
    34 : ret                                  
    35 : annotation:else     7, 8             
    36 : annotation:ifcstart                  
    37 : cmp                 i0, i1           
    38 : jmp_eq              __loops_label_9  
    39 : cmp                 i0, i2           
    40 : jmp_eq              __loops_label_9  
    41 : cmp                 i1, i2           
    42 : jmp_ne              __loops_label_10 
    43 : __loops_label_9:                     
    44 : annotation:ifcend                    
    45 : mov                 iR, 3            
    46 : ret                                  
    47 : annotation:else     10, 11           
    48 : annotation:ifcstart                  
    49 : mul                 i6, i0, i0       
    50 : mul                 i8, i1, i1       
    51 : mul                 i9, i2, i2       
    52 : add                 i7, i8, i9       
    53 : cmp                 i6, i7           
    54 : jmp_eq              __loops_label_12 
    55 : mul                 i10, i1, i1      
    56 : mul                 i12, i0, i0      
    57 : mul                 i13, i2, i2      
    58 : add                 i11, i12, i13    
    59 : cmp                 i10, i11         
    60 : jmp_eq              __loops_label_12 
    61 : mul                 i14, i2, i2      
    62 : mul                 i16, i0, i0      
    63 : mul                 i17, i1, i1      
    64 : add                 i15, i16, i17    
    65 : cmp                 i14, i15         
    66 : jmp_ne              __loops_label_13 
    67 : __loops_label_12:                    
    68 : annotation:ifcend                    
    69 : mov                 iR, 1            
    70 : ret                                  
    71 : annotation:else     13, 14           
    72 : annotation:ifcstart                  
    73 : mul                 i18, i0, i0      
    74 : mul                 i20, i1, i1      
    75 : mul                 i21, i2, i2      
    76 : add                 i19, i20, i21    
    77 : cmp                 i18, i19         
    78 : jmp_gt              __loops_label_15 
    79 : mul                 i22, i1, i1      
    80 : mul                 i24, i0, i0      
    81 : mul                 i25, i2, i2      
    82 : add                 i23, i24, i25    
    83 : cmp                 i22, i23         
    84 : jmp_gt              __loops_label_15 
    85 : mul                 i26, i2, i2      
    86 : mul                 i28, i0, i0      
    87 : mul                 i29, i1, i1      
    88 : add                 i27, i28, i29    
    89 : cmp                 i26, i27         
    90 : jmp_le              __loops_label_16 
    91 : __loops_label_15:                    
    92 : annotation:ifcend                    
    93 : mov                 iR, 5            
    94 : ret                                  
    95 : annotation:else     16, 17           
    96 : mov                 iR, 4            
    97 : ret                                  
    98 : annotation:endif    2                
    99 : annotation:endif    5                
   100 : annotation:endif    8                
   101 : annotation:endif    11               
   102 : annotation:endif    14               
   103 : annotation:endif    17               
