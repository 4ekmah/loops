big_immediates(i0, i1)
     0 : annotation:ifcstart                  
     1 : cmp                 i1, 0            
     2 : jmp_ne              __loops_label_1  
     3 : annotation:ifcend                    
     4 : mov                 i2, 65535        
     5 : store.u64           i0, i2           
     6 : add                 i0, i0, 8        
     7 : mov                 i3, 65536        
     8 : store.u64           i0, i3           
     9 : add                 i0, i0, 8        
    10 : mov                 i4, -32768       
    11 : store.i64           i0, i4           
    12 : add                 i0, i0, 8        
    13 : mov                 i5, -32769       
    14 : store.i64           i0, i5           
    15 : add                 i0, i0, 8        
    16 : mov                 i6, 1597463007   
    17 : store.u64           i0, i6           
    18 : add                 i0, i0, 8        
    19 : mov                 i7, -1961601175  
    20 : store.u64           i0, i7           
    21 : add                 i0, i0, 8        
    22 : annotation:else     1, 2             
    23 : annotation:ifcstart                  
    24 : cmp                 i1, 1            
    25 : jmp_ne              __loops_label_4  
    26 : annotation:ifcend                    
    27 : mov                 v0, 0            
    28 : vst.u8              i0, v0           
    29 : add                 i0, i0, 16       
    30 : mov                 v1, 255          
    31 : vst.u8              i0, v1           
    32 : add                 i0, i0, 16       
    33 : annotation:else     4, 5             
    34 : annotation:ifcstart                  
    35 : cmp                 i1, 2            
    36 : jmp_ne              __loops_label_7  
    37 : annotation:ifcend                    
    38 : mov                 v2, 128          
    39 : vst.i8              i0, v2           
    40 : add                 i0, i0, 16       
    41 : annotation:else     7, 8             
    42 : annotation:ifcstart                  
    43 : cmp                 i1, 3            
    44 : jmp_ne              __loops_label_10 
    45 : annotation:ifcend                    
    46 : mov                 v3, 0            
    47 : vst.u16             i0, v3           
    48 : add                 i0, i0, 16       
    49 : mov                 v4, 255          
    50 : vst.u16             i0, v4           
    51 : add                 i0, i0, 16       
    52 : mov                 v5, 256          
    53 : vst.u16             i0, v5           
    54 : add                 i0, i0, 16       
    55 : annotation:else     10, 11           
    56 : annotation:ifcstart                  
    57 : cmp                 i1, 4            
    58 : jmp_ne              __loops_label_13 
    59 : annotation:ifcend                    
    60 : mov                 v6, 65408        
    61 : vst.i16             i0, v6           
    62 : add                 i0, i0, 16       
    63 : mov                 v7, 65407        
    64 : vst.i16             i0, v7           
    65 : add                 i0, i0, 16       
    66 : annotation:else     13, 14           
    67 : annotation:ifcstart                  
    68 : cmp                 i1, 5            
    69 : jmp_ne              __loops_label_16 
    70 : annotation:ifcend                    
    71 : mov                 v8, 0            
    72 : vst.u32             i0, v8           
    73 : add                 i0, i0, 16       
    74 : mov                 v9, 255          
    75 : vst.u32             i0, v9           
    76 : add                 i0, i0, 16       
    77 : mov                 v10, 256         
    78 : vst.u32             i0, v10          
    79 : add                 i0, i0, 16       
    80 : annotation:else     16, 17           
    81 : annotation:ifcstart                  
    82 : cmp                 i1, 6            
    83 : jmp_ne              __loops_label_19 
    84 : annotation:ifcend                    
    85 : mov                 v11, -128        
    86 : vst.i32             i0, v11          
    87 : add                 i0, i0, 16       
    88 : mov                 v12, -129        
    89 : vst.i32             i0, v12          
    90 : add                 i0, i0, 16       
    91 : annotation:else     19, 20           
    92 : annotation:ifcstart                  
    93 : cmp                 i1, 7            
    94 : jmp_ne              __loops_label_22 
    95 : annotation:ifcend                    
    96 : mov                 v13, 0           
    97 : vst.u64             i0, v13          
    98 : add                 i0, i0, 16       
    99 : mov                 v14, 255         
   100 : vst.u64             i0, v14          
   101 : add                 i0, i0, 16       
   102 : mov                 v15, 65280       
   103 : vst.u64             i0, v15          
   104 : add                 i0, i0, 16       
   105 : annotation:else     22, 23           
   106 : annotation:ifcstart                  
   107 : cmp                 i1, 8            
   108 : jmp_ne              __loops_label_25 
   109 : annotation:ifcend                    
   110 : mov                 v16, -256        
   111 : vst.i64             i0, v16          
   112 : add                 i0, i0, 16       
   113 : annotation:else     25, 26           
   114 : annotation:ifcstart                  
   115 : cmp                 i1, 9            
   116 : jmp_ne              __loops_label_28 
   117 : annotation:ifcend                    
   118 : mov                 v17, 256         
   119 : vst.u64             i0, v17          
   120 : add                 i0, i0, 16       
   121 : mov                 v18, 254         
   122 : vst.u64             i0, v18          
   123 : add                 i0, i0, 16       
   124 : annotation:endif    2                
   125 : annotation:endif    5                
   126 : annotation:endif    8                
   127 : annotation:endif    11               
   128 : annotation:endif    14               
   129 : annotation:endif    17               
   130 : annotation:endif    20               
   131 : annotation:endif    23               
   132 : annotation:endif    26               
   133 : annotation:endif    28               
   134 : ret                                  
