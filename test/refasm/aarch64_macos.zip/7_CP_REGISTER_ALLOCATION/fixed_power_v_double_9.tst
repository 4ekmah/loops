fixed_power_v_double_9(i0, i1, i2)
     0 : sub                    i31, i31, 32    
     1 : spill                  1, i25          
     2 : spill                  2, i26          
     3 : mov                    i3, 0           
     4 : mov                    i26, 8          
     5 : spill                  0, i26          
     6 : unspill                i26, 0          
     7 : mul                    i25, i2, i26    
     8 : annotation:whilecstart 0               
     9 : cmp                    i3, i25         
    10 : jmp_ge                 __loops_label_2 
    11 : annotation:whilecend                   
    12 : vld.fp64               v0, i0, i3      
    13 : mul.fp64               v1, v0, v0      
    14 : mul.fp64               v1, v1, v1      
    15 : mul.fp64               v1, v1, v1      
    16 : mul.fp64               v0, v0, v1      
    17 : vst.fp64               i1, i3, v0      
    18 : add                    i3, i3, 16      
    19 : annotation:endwhile    0, 2            
    20 : mov                    i0, 0           
    21 : ret                                    
    22 : unspill                i25, 1          
    23 : unspill                i26, 2          
    24 : add                    i31, i31, 32    
