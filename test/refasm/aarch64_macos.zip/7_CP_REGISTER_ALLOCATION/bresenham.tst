bresenham(i0, i1, i2, i3, i4, i5, i6)
     0 : sub                    i31, i31, 80     
     1 : spill                  5, i25           
     2 : spill                  6, i26           
     3 : spill                  7, i27           
     4 : spill                  8, i28           
     5 : sub                    i25, i4, i2      
     6 : cmp                    i25, 0           
     7 : arm_cneg               i26, i25, 33     
     8 : spill                  4, i26           
     9 : sub                    i25, i4, i2      
    10 : cmp                    i25, 0           
    11 : sar                    i25, i25, 63     
    12 : arm_cinc               i26, i25, 30     
    13 : spill                  0, i26           
    14 : sub                    i25, i5, i3      
    15 : cmp                    i25, 0           
    16 : arm_cneg               i25, i25, 33     
    17 : neg                    i26, i25         
    18 : spill                  1, i26           
    19 : sub                    i25, i5, i3      
    20 : cmp                    i25, 0           
    21 : sar                    i25, i25, 63     
    22 : arm_cinc               i26, i25, 30     
    23 : spill                  2, i26           
    24 : unspill                i26, 4           
    25 : unspill                i27, 1           
    26 : add                    i28, i26, i27    
    27 : spill                  3, i28           
    28 : annotation:whilecstart 0                
    29 : cmp                    i0, 0            
    30 : jmp_eq                 __loops_label_2  
    31 : annotation:whilecend                    
    32 : mul                    i25, i3, i1      
    33 : add                    i25, i25, i2     
    34 : store.u8               i0, i25, i6      
    35 : annotation:ifcstart                     
    36 : cmp                    i2, i4           
    37 : jmp_ne                 __loops_label_4  
    38 : cmp                    i3, i5           
    39 : jmp_ne                 __loops_label_4  
    40 : annotation:ifcend                       
    41 : annotation:break       2                
    42 : annotation:endif       4                
    43 : unspill                i26, 3           
    44 : shl                    i25, i26, 1      
    45 : annotation:ifcstart                     
    46 : unspill                i26, 1           
    47 : cmp                    i25, i26         
    48 : jmp_gt                 __loops_label_6  
    49 : annotation:ifcend                       
    50 : annotation:ifcstart                     
    51 : cmp                    i2, i4           
    52 : jmp_ne                 __loops_label_8  
    53 : annotation:ifcend                       
    54 : annotation:break       2                
    55 : annotation:endif       8                
    56 : unspill                i27, 1           
    57 : unspill                i26, 3           
    58 : add                    i26, i26, i27    
    59 : spill                  3, i26           
    60 : unspill                i26, 0           
    61 : add                    i2, i2, i26      
    62 : annotation:endif       6                
    63 : annotation:ifcstart                     
    64 : unspill                i26, 4           
    65 : cmp                    i25, i26         
    66 : jmp_gt                 __loops_label_10 
    67 : annotation:ifcend                       
    68 : annotation:ifcstart                     
    69 : cmp                    i3, i5           
    70 : jmp_ne                 __loops_label_12 
    71 : annotation:ifcend                       
    72 : annotation:break       2                
    73 : annotation:endif       12               
    74 : unspill                i27, 4           
    75 : unspill                i26, 3           
    76 : add                    i26, i26, i27    
    77 : spill                  3, i26           
    78 : unspill                i26, 2           
    79 : add                    i3, i3, i26      
    80 : annotation:endif       10               
    81 : annotation:endwhile    0, 2             
    82 : ret                                     
    83 : unspill                i25, 5           
    84 : unspill                i26, 6           
    85 : unspill                i27, 7           
    86 : unspill                i28, 8           
    87 : add                    i31, i31, 80     
