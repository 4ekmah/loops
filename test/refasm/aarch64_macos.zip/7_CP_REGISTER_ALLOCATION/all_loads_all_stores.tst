all_loads_all_stores(i0, i1, i2, i3, i4)
     0 : sub                    i31, i31, 112    
     1 : spill                  11, i25          
     2 : spill                  12, i26          
     3 : spill                  13, i27          
     4 : mov                    i26, 0           
     5 : spill                  4, i26           
     6 : mov                    i26, 0           
     7 : spill                  0, i26           
     8 : mov                    i26, 0           
     9 : spill                  1, i26           
    10 : mov                    i25, 2           
    11 : mov                    i26, 1           
    12 : spill                  5, i26           
    13 : cmp                    i1, 1            
    14 : unspill                i26, 5           
    15 : select_gt              i25, i25, i26    
    16 : mov                    i26, 4           
    17 : spill                  6, i26           
    18 : cmp                    i1, 3            
    19 : unspill                i26, 6           
    20 : select_gt              i25, i26, i25    
    21 : mov                    i26, 8           
    22 : spill                  7, i26           
    23 : cmp                    i1, 5            
    24 : unspill                i26, 7           
    25 : select_gt              i27, i26, i25    
    26 : spill                  2, i27           
    27 : mov                    i25, 2           
    28 : mov                    i26, 1           
    29 : spill                  8, i26           
    30 : cmp                    i3, 1            
    31 : unspill                i26, 8           
    32 : select_gt              i25, i25, i26    
    33 : mov                    i26, 4           
    34 : spill                  9, i26           
    35 : cmp                    i3, 3            
    36 : unspill                i26, 9           
    37 : select_gt              i25, i26, i25    
    38 : mov                    i26, 8           
    39 : spill                  10, i26          
    40 : cmp                    i3, 5            
    41 : unspill                i26, 10          
    42 : select_gt              i27, i26, i25    
    43 : spill                  3, i27           
    44 : annotation:whilecstart 0                
    45 : unspill                i26, 4           
    46 : cmp                    i26, i4          
    47 : jmp_ge                 __loops_label_2  
    48 : annotation:whilecend                    
    49 : def                    i25              
    50 : annotation:ifcstart                     
    51 : cmp                    i1, 0            
    52 : jmp_ne                 __loops_label_4  
    53 : annotation:ifcend                       
    54 : unspill                i26, 0           
    55 : load.u8                i25, i0, i26     
    56 : annotation:else        4, 5             
    57 : annotation:ifcstart                     
    58 : cmp                    i1, 1            
    59 : jmp_ne                 __loops_label_7  
    60 : annotation:ifcend                       
    61 : unspill                i26, 0           
    62 : load.i8                i25, i0, i26     
    63 : annotation:else        7, 8             
    64 : annotation:ifcstart                     
    65 : cmp                    i1, 2            
    66 : jmp_ne                 __loops_label_10 
    67 : annotation:ifcend                       
    68 : unspill                i26, 0           
    69 : load.u16               i25, i0, i26     
    70 : annotation:else        10, 11           
    71 : annotation:ifcstart                     
    72 : cmp                    i1, 3            
    73 : jmp_ne                 __loops_label_13 
    74 : annotation:ifcend                       
    75 : unspill                i26, 0           
    76 : load.i16               i25, i0, i26     
    77 : annotation:else        13, 14           
    78 : annotation:ifcstart                     
    79 : cmp                    i1, 4            
    80 : jmp_ne                 __loops_label_16 
    81 : annotation:ifcend                       
    82 : unspill                i26, 0           
    83 : load.u32               i25, i0, i26     
    84 : annotation:else        16, 17           
    85 : annotation:ifcstart                     
    86 : cmp                    i1, 5            
    87 : jmp_ne                 __loops_label_19 
    88 : annotation:ifcend                       
    89 : unspill                i26, 0           
    90 : load.i32               i25, i0, i26     
    91 : annotation:else        19, 20           
    92 : annotation:ifcstart                     
    93 : cmp                    i1, 6            
    94 : jmp_ne                 __loops_label_22 
    95 : annotation:ifcend                       
    96 : unspill                i26, 0           
    97 : load.u64               i25, i0, i26     
    98 : annotation:else        22, 23           
    99 : unspill                i26, 0           
   100 : load.i64               i25, i0, i26     
   101 : annotation:endif       5                
   102 : annotation:endif       8                
   103 : annotation:endif       11               
   104 : annotation:endif       14               
   105 : annotation:endif       17               
   106 : annotation:endif       20               
   107 : annotation:endif       23               
   108 : annotation:ifcstart                     
   109 : cmp                    i3, 0            
   110 : jmp_ne                 __loops_label_25 
   111 : annotation:ifcend                       
   112 : unspill                i26, 1           
   113 : store.u8               i2, i26, i25     
   114 : annotation:else        25, 26           
   115 : annotation:ifcstart                     
   116 : cmp                    i3, 1            
   117 : jmp_ne                 __loops_label_28 
   118 : annotation:ifcend                       
   119 : unspill                i26, 1           
   120 : store.i8               i2, i26, i25     
   121 : annotation:else        28, 29           
   122 : annotation:ifcstart                     
   123 : cmp                    i3, 2            
   124 : jmp_ne                 __loops_label_31 
   125 : annotation:ifcend                       
   126 : unspill                i26, 1           
   127 : store.u16              i2, i26, i25     
   128 : annotation:else        31, 32           
   129 : annotation:ifcstart                     
   130 : cmp                    i3, 3            
   131 : jmp_ne                 __loops_label_34 
   132 : annotation:ifcend                       
   133 : unspill                i26, 1           
   134 : store.i16              i2, i26, i25     
   135 : annotation:else        34, 35           
   136 : annotation:ifcstart                     
   137 : cmp                    i3, 4            
   138 : jmp_ne                 __loops_label_37 
   139 : annotation:ifcend                       
   140 : unspill                i26, 1           
   141 : store.u32              i2, i26, i25     
   142 : annotation:else        37, 38           
   143 : annotation:ifcstart                     
   144 : cmp                    i3, 5            
   145 : jmp_ne                 __loops_label_40 
   146 : annotation:ifcend                       
   147 : unspill                i26, 1           
   148 : store.i32              i2, i26, i25     
   149 : annotation:else        40, 41           
   150 : annotation:ifcstart                     
   151 : cmp                    i3, 6            
   152 : jmp_ne                 __loops_label_43 
   153 : annotation:ifcend                       
   154 : unspill                i26, 1           
   155 : store.u64              i2, i26, i25     
   156 : annotation:else        43, 44           
   157 : unspill                i26, 1           
   158 : store.i64              i2, i26, i25     
   159 : annotation:endif       26               
   160 : annotation:endif       29               
   161 : annotation:endif       32               
   162 : annotation:endif       35               
   163 : annotation:endif       38               
   164 : annotation:endif       41               
   165 : annotation:endif       44               
   166 : unspill                i26, 0           
   167 : unspill                i27, 2           
   168 : add                    i26, i26, i27    
   169 : spill                  0, i26           
   170 : unspill                i26, 1           
   171 : unspill                i27, 3           
   172 : add                    i26, i26, i27    
   173 : spill                  1, i26           
   174 : unspill                i26, 4           
   175 : add                    i26, i26, 1      
   176 : spill                  4, i26           
   177 : annotation:endwhile    0, 2             
   178 : unspill                i25, 11          
   179 : unspill                i26, 12          
   180 : unspill                i27, 13          
   181 : add                    i31, i31, 112    
