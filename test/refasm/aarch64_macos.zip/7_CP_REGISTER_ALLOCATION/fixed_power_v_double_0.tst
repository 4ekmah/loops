fixed_power_v_double_0(i0, i1, i2)
     0 : sub                    i31, i31, 48    
     1 : spill                  3, i25          
     2 : spill                  4, i26          
     3 : mov                    i3, 0           
     4 : mov                    i25, 8          
     5 : mul                    i2, i2, i25     
     6 : spill                  2, i2           
     7 : annotation:whilecstart 0               
     8 : unspill                i26, 2          
     9 : cmp                    i3, i26         
    10 : jmp_ge                 __loops_label_2 
    11 : annotation:whilecend                   
    12 : vld.fp64               v0, i0, i3      
    13 : mov                    i25, 0          
    14 : arm_movk               i25, 16368, 48  
    15 : broadcast.fp64         v0, i25         
    16 : vst.fp64               i1, i3, v0      
    17 : add                    i3, i3, 16      
    18 : annotation:endwhile    0, 2            
    19 : mov                    i0, 0           
    20 : ret                                    
    21 : unspill                i25, 3          
    22 : unspill                i26, 4          
    23 : add                    i31, i31, 48    
