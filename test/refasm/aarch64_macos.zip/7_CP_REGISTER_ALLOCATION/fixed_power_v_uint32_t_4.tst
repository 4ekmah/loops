fixed_power_v_uint32_t_4(i0, i1, i2)
     0 : sub                    i31, i31, 32    
     1 : spill                  1, i25          
     2 : spill                  2, i26          
     3 : mov                    i3, 0           
     4 : mov                    i26, 4          
     5 : spill                  0, i26          
     6 : unspill                i26, 0          
     7 : mul                    i25, i2, i26    
     8 : annotation:whilecstart 0               
     9 : cmp                    i3, i25         
    10 : jmp_ge                 __loops_label_2 
    11 : annotation:whilecend                   
    12 : vld.u32                v0, i0, i3      
    13 : mul.u32                v0, v0, v0      
    14 : mul.u32                v0, v0, v0      
    15 : vst.u32                i1, i3, v0      
    16 : add                    i3, i3, 16      
    17 : annotation:endwhile    0, 2            
    18 : mov                    i0, 0           
    19 : ret                                    
    20 : unspill                i25, 1          
    21 : unspill                i26, 2          
    22 : add                    i31, i31, 32    
