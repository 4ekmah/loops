conditionpainter(i0)
     0 : sub                    i31, i31, 64    
     1 : spill                  5, i25          
     2 : spill                  6, i26          
     3 : mov                    i26, -5         
     4 : spill                  2, i26          
     5 : annotation:whilecstart 0               
     6 : unspill                i26, 2          
     7 : cmp                    i26, 5          
     8 : jmp_gt                 __loops_label_2 
     9 : annotation:whilecend                   
    10 : unspill                i26, 2          
    11 : add                    i1, i26, 5      
    12 : mov                    i2, 11          
    13 : mul                    i1, i1, i2      
    14 : mov                    i2, 8           
    15 : mul                    i26, i1, i2     
    16 : spill                  1, i26          
    17 : mov                    i26, -5         
    18 : spill                  0, i26          
    19 : annotation:whilecstart 3               
    20 : unspill                i26, 0          
    21 : cmp                    i26, 5          
    22 : jmp_gt                 __loops_label_5 
    23 : annotation:whilecend                   
    24 : unspill                i26, 0          
    25 : add                    i25, i26, 3     
    26 : unspill                i26, 2          
    27 : cmp                    i26, i25        
    28 : iverson_ge             i25             
    29 : unspill                i26, 2          
    30 : cmp                    i26, 4          
    31 : iverson_le             i3              
    32 : and                    i3, i25, i3     
    33 : mov                    i25, -2         
    34 : unspill                i26, 0          
    35 : cmp                    i26, i25        
    36 : iverson_ge             i25             
    37 : and                    i3, i3, i25     
    38 : unspill                i26, 0          
    39 : cmp                    i26, 0          
    40 : iverson_le             i25             
    41 : and                    i3, i3, i25     
    42 : unspill                i26, 0          
    43 : sub                    i25, i26, 1     
    44 : unspill                i26, 2          
    45 : cmp                    i26, i25        
    46 : iverson_le             i25             
    47 : unspill                i26, 0          
    48 : cmp                    i26, 0          
    49 : iverson_ge             i2              
    50 : and                    i2, i25, i2     
    51 : unspill                i26, 2          
    52 : cmp                    i26, 0          
    53 : iverson_le             i25             
    54 : and                    i2, i2, i25     
    55 : unspill                i26, 0          
    56 : mul                    i25, i26, i26   
    57 : unspill                i26, 2          
    58 : mul                    i1, i26, i26    
    59 : add                    i1, i25, i1     
    60 : cmp                    i1, 9           
    61 : iverson_le             i1              
    62 : and                    i1, i2, i1      
    63 : or                     i26, i3, i1     
    64 : spill                  3, i26          
    65 : mov                    i2, 2           
    66 : mov                    i26, 0          
    67 : spill                  4, i26          
    68 : unspill                i26, 0          
    69 : cmp                    i26, 2          
    70 : iverson_ge             i25             
    71 : unspill                i26, 0          
    72 : cmp                    i26, 4          
    73 : iverson_le             i1              
    74 : and                    i1, i25, i1     
    75 : unspill                i26, 2          
    76 : cmp                    i26, 1          
    77 : iverson_ge             i25             
    78 : unspill                i26, 2          
    79 : cmp                    i26, 3          
    80 : iverson_le             i3              
    81 : and                    i3, i25, i3     
    82 : or                     i1, i1, i3      
    83 : unspill                i26, 0          
    84 : mul                    i3, i26, i26    
    85 : unspill                i26, 2          
    86 : mul                    i25, i26, i26   
    87 : add                    i3, i3, i25     
    88 : cmp                    i3, 16          
    89 : iverson_le             i3              
    90 : and                    i1, i1, i3      
    91 : cmp                    i1, 0           
    92 : unspill                i26, 4          
    93 : select_ne              i1, i2, i26     
    94 : unspill                i26, 3          
    95 : add                    i1, i26, i1     
    96 : annotation:ifcstart                    
    97 : mov                    i2, 2           
    98 : unspill                i26, 2          
    99 : mul                    i2, i26, i2     
   100 : unspill                i26, 0          
   101 : cmp                    i2, i26         
   102 : jmp_gt                 __loops_label_8 
   103 : unspill                i26, 0          
   104 : add                    i2, i26, 3      
   105 : neg                    i2, i2          
   106 : unspill                i26, 0          
   107 : add                    i3, i26, 3      
   108 : mul                    i2, i2, i3      
   109 : unspill                i26, 2          
   110 : cmp                    i26, i2         
   111 : jmp_le                 __loops_label_9 
   112 : __loops_label_8:                       
   113 : mov                    i2, 2           
   114 : unspill                i26, 0          
   115 : mul                    i2, i26, i2     
   116 : unspill                i26, 2          
   117 : cmp                    i26, i2         
   118 : jmp_gt                 __loops_label_7 
   119 : unspill                i26, 0          
   120 : add                    i2, i26, 3      
   121 : neg                    i2, i2          
   122 : unspill                i26, 0          
   123 : add                    i3, i26, 3      
   124 : mul                    i2, i2, i3      
   125 : unspill                i26, 2          
   126 : cmp                    i26, i2         
   127 : jmp_gt                 __loops_label_7 
   128 : __loops_label_9:                       
   129 : unspill                i26, 0          
   130 : cmp                    i26, 0          
   131 : jmp_gt                 __loops_label_7 
   132 : annotation:ifcend                      
   133 : add                    i1, i1, 3       
   134 : annotation:endif       7               
   135 : unspill                i26, 0          
   136 : add                    i2, i26, 5      
   137 : shl                    i2, i2, 3       
   138 : unspill                i26, 1          
   139 : add                    i2, i26, i2     
   140 : store.i64              i0, i2, i1      
   141 : unspill                i26, 0          
   142 : add                    i26, i26, 1     
   143 : spill                  0, i26          
   144 : annotation:endwhile    3, 5            
   145 : unspill                i26, 2          
   146 : add                    i26, i26, 1     
   147 : spill                  2, i26          
   148 : annotation:endwhile    0, 2            
   149 : ret                                    
   150 : unspill                i25, 5          
   151 : unspill                i26, 6          
   152 : add                    i31, i31, 64    
