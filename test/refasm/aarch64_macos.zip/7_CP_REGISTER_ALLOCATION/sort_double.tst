sort_double(i0, i1)
     0 : sub                    i31, i31, 480      
     1 : spill                  55, i25            
     2 : spill                  56, i26            
     3 : spill                  57, i27            
     4 : arm_stp                i31, 464, i29, i30 
     5 : mov                    i29, i31           
     6 : shl                    i26, i1, 3         
     7 : spill                  52, i26            
     8 : unspill                i26, 52            
     9 : sub                    i27, i26, 8        
    10 : spill                  53, i27            
    11 : mov                    i26, 0             
    12 : spill                  54, i26            
    13 : annotation:whilecstart 0                  
    14 : unspill                i27, 53            
    15 : unspill                i26, 54            
    16 : cmp                    i26, i27           
    17 : jmp_ge                 __loops_label_2    
    18 : annotation:whilecend                      
    19 : unspill                i26, 54            
    20 : mov                    i27, i26           
    21 : spill                  51, i27            
    22 : unspill                i26, 51            
    23 : add                    i27, i26, 8        
    24 : spill                  50, i27            
    25 : annotation:whilecstart 3                  
    26 : unspill                i27, 52            
    27 : unspill                i26, 50            
    28 : cmp                    i26, i27           
    29 : jmp_ge                 __loops_label_5    
    30 : annotation:whilecend                      
    31 : annotation:ifcstart                       
    32 : unspill                i26, 50            
    33 : load.fp64              i25, i0, i26       
    34 : unspill                i26, 51            
    35 : load.fp64              i3, i0, i26        
    36 : mov                    i2, 1084           
    37 : arm_movk               i2, 1089, 16       
    38 : arm_movk               i2, 1, 32          
    39 : call                   [i2](i2, i25, i3)  
    40 : cmp                    i2, 0              
    41 : jmp_eq                 __loops_label_7    
    42 : annotation:ifcend                         
    43 : unspill                i26, 50            
    44 : mov                    i27, i26           
    45 : spill                  51, i27            
    46 : annotation:endif       7                  
    47 : unspill                i26, 50            
    48 : add                    i26, i26, 8        
    49 : spill                  50, i26            
    50 : annotation:endwhile    3, 5               
    51 : annotation:ifcstart                       
    52 : unspill                i27, 54            
    53 : unspill                i26, 51            
    54 : cmp                    i26, i27           
    55 : jmp_eq                 __loops_label_9    
    56 : annotation:ifcend                         
    57 : unspill                i26, 54            
    58 : load.fp64              i2, i0, i26        
    59 : unspill                i26, 51            
    60 : load.fp64              i3, i0, i26        
    61 : unspill                i26, 51            
    62 : store.fp64             i0, i26, i2        
    63 : unspill                i26, 54            
    64 : store.fp64             i0, i26, i3        
    65 : annotation:endif       9                  
    66 : unspill                i26, 54            
    67 : add                    i26, i26, 8        
    68 : spill                  54, i26            
    69 : annotation:endwhile    0, 2               
    70 : ret                                       
    71 : arm_ldp                i29, i30, i31, 464 
    72 : unspill                i25, 55            
    73 : unspill                i26, 56            
    74 : unspill                i27, 57            
    75 : add                    i31, i31, 480      
