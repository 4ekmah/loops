min_max_scalar(i0, i1, i2, i3)
     0 : sub                    i31, i31, 96    
     1 : spill                  8, i25          
     2 : spill                  9, i26          
     3 : spill                  10, i27         
     4 : mov                    i26, 0          
     5 : spill                  7, i26          
     6 : mov                    i26, 0          
     7 : spill                  2, i26          
     8 : mov                    i26, 0          
     9 : spill                  3, i26          
    10 : load.i32               i26, i0         
    11 : spill                  4, i26          
    12 : unspill                i26, 4          
    13 : mov                    i27, i26        
    14 : spill                  5, i27          
    15 : mov                    i25, 4          
    16 : mul                    i1, i1, i25     
    17 : spill                  6, i1           
    18 : annotation:whilecstart 0               
    19 : unspill                i27, 6          
    20 : unspill                i26, 7          
    21 : cmp                    i26, i27        
    22 : jmp_ge                 __loops_label_2 
    23 : annotation:whilecend                   
    24 : unspill                i26, 7          
    25 : load.i32               i25, i0, i26    
    26 : annotation:ifcstart                    
    27 : unspill                i26, 4          
    28 : cmp                    i25, i26        
    29 : jmp_ge                 __loops_label_4 
    30 : annotation:ifcend                      
    31 : mov                    i26, i25        
    32 : spill                  4, i26          
    33 : unspill                i26, 7          
    34 : mov                    i27, i26        
    35 : spill                  2, i27          
    36 : annotation:endif       4               
    37 : annotation:ifcstart                    
    38 : unspill                i26, 5          
    39 : cmp                    i25, i26        
    40 : jmp_le                 __loops_label_6 
    41 : annotation:ifcend                      
    42 : mov                    i26, i25        
    43 : spill                  5, i26          
    44 : unspill                i26, 7          
    45 : mov                    i27, i26        
    46 : spill                  3, i27          
    47 : annotation:endif       6               
    48 : unspill                i26, 7          
    49 : add                    i26, i26, 4     
    50 : spill                  7, i26          
    51 : annotation:endwhile    0, 2            
    52 : mov                    i0, 4           
    53 : unspill                i26, 2          
    54 : div                    i1, i26, i0     
    55 : unspill                i26, 3          
    56 : div                    i0, i26, i0     
    57 : store.i32              i2, i1          
    58 : store.i32              i3, i0          
    59 : mov                    i0, 0           
    60 : ret                                    
    61 : unspill                i25, 8          
    62 : unspill                i26, 9          
    63 : unspill                i27, 10         
    64 : add                    i31, i31, 96    
