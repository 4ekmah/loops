nullify_msb_lsb_v(i0, i1, i2, i3)
     0 : sub                    i31, i31, 48    
     1 : spill                  4, i25          
     2 : spill                  5, i26          
     3 : mov                    i25, 0          
     4 : mov                    i26, 4          
     5 : spill                  3, i26          
     6 : unspill                i26, 3          
     7 : mul                    i3, i3, i26     
     8 : mov                    v0, 1           
     9 : spill                  2, i3           
    10 : annotation:whilecstart 0               
    11 : unspill                i26, 2          
    12 : cmp                    i25, i26        
    13 : jmp_ge                 __loops_label_2 
    14 : annotation:whilecend                   
    15 : vld.u32                v1, i0, i25     
    16 : shr.u32                v2, v1, 1       
    17 : or                     v2, v1, v2      
    18 : shr.u32                v3, v2, 2       
    19 : or                     v2, v2, v3      
    20 : shr.u32                v3, v2, 4       
    21 : or                     v2, v2, v3      
    22 : shr.u32                v3, v2, 8       
    23 : or                     v2, v2, v3      
    24 : shr.u32                v3, v2, 16      
    25 : or                     v2, v2, v3      
    26 : add.u32                v2, v2, v0      
    27 : shr.u32                v2, v2, 1       
    28 : xor                    v2, v2, v1      
    29 : vst.u32                i1, i25, v2     
    30 : sub.u32                v2, v1, v0      
    31 : not                    v2, v2          
    32 : and                    v2, v1, v2      
    33 : xor                    v1, v2, v1      
    34 : vst.u32                i2, i25, v1     
    35 : add                    i25, i25, 16    
    36 : annotation:endwhile    0, 2            
    37 : ret                                    
    38 : unspill                i25, 4          
    39 : unspill                i26, 5          
    40 : add                    i31, i31, 48    
