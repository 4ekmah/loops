area_sum(i0, i1)
     0 : sub                    i31, i31, 464      
     1 : spill                  53, i25            
     2 : spill                  54, i26            
     3 : arm_stp                i31, 448, i29, i30 
     4 : mov                    i29, i31           
     5 : mov                    i26, 0             
     6 : spill                  50, i26            
     7 : annotation:whilecstart 0                  
     8 : cmp                    i1, 0              
     9 : jmp_le                 __loops_label_2    
    10 : annotation:whilecend                      
    11 : load.i8                i26, i0            
    12 : spill                  51, i26            
    13 : mov                    i25, 9208          
    14 : arm_movk               i25, 1089, 16      
    15 : arm_movk               i25, 1, 32         
    16 : mov                    i2, 9360           
    17 : arm_movk               i2, 1089, 16       
    18 : arm_movk               i2, 1, 32          
    19 : mov                    i3, 9476           
    20 : arm_movk               i3, 1089, 16       
    21 : arm_movk               i3, 1, 32          
    22 : unspill                i26, 51            
    23 : cmp                    i26, 1             
    24 : select_eq              i2, i2, i3         
    25 : unspill                i26, 51            
    26 : cmp                    i26, 0             
    27 : select_eq              i26, i25, i2       
    28 : spill                  52, i26            
    29 : mov                    i3, 9672           
    30 : arm_movk               i3, 1089, 16       
    31 : arm_movk               i3, 1, 32          
    32 : mov                    i25, 9768          
    33 : arm_movk               i25, 1089, 16      
    34 : arm_movk               i25, 1, 32         
    35 : mov                    i2, 9844           
    36 : arm_movk               i2, 1089, 16       
    37 : arm_movk               i2, 1, 32          
    38 : unspill                i26, 51            
    39 : cmp                    i26, 1             
    40 : select_eq              i2, i25, i2        
    41 : unspill                i26, 51            
    42 : cmp                    i26, 0             
    43 : select_eq              i2, i3, i2         
    44 : unspill                i26, 52            
    45 : call_noret             [i26](i0)          
    46 : call                   [i2](i2, i0)       
    47 : mov                    i3, 9980           
    48 : arm_movk               i3, 1089, 16       
    49 : arm_movk               i3, 1, 32          
    50 : unspill                i26, 50            
    51 : call                   [i3](i2, i26, i2)  
    52 : mov                    i26, i2            
    53 : spill                  50, i26            
    54 : add                    i0, i0, 56         
    55 : sub                    i1, i1, 1          
    56 : annotation:endwhile    0, 2               
    57 : unspill                i26, 50            
    58 : mov                    i0, i26            
    59 : ret                                       
    60 : arm_ldp                i29, i30, i31, 448 
    61 : unspill                i25, 53            
    62 : unspill                i26, 54            
    63 : add                    i31, i31, 464      
