has_in_join_cascade(i0, i1, i2)
     0 : sub                    i31, i31, 128    
     1 : spill                  13, i25          
     2 : spill                  14, i26          
     3 : spill                  15, i27          
     4 : mov                    i26, 0           
     5 : spill                  5, i26           
     6 : load.i64               i26, i0, 16      
     7 : spill                  6, i26           
     8 : load.i64               i26, i0, 0       
     9 : spill                  7, i26           
    10 : load.i64               i26, i0, 8       
    11 : spill                  8, i26           
    12 : annotation:whilecstart 0                
    13 : unspill                i26, 6           
    14 : cmp                    i26, 0           
    15 : jmp_le                 __loops_label_2  
    16 : annotation:whilecend                    
    17 : unspill                i26, 7           
    18 : load.i32               i27, i26         
    19 : spill                  9, i27           
    20 : unspill                i26, 7           
    21 : add                    i26, i26, 4      
    22 : spill                  7, i26           
    23 : unspill                i26, 8           
    24 : load.i32               i27, i26         
    25 : spill                  4, i27           
    26 : unspill                i26, 8           
    27 : add                    i26, i26, 4      
    28 : spill                  8, i26           
    29 : unspill                i26, 6           
    30 : sub                    i26, i26, 1      
    31 : spill                  6, i26           
    32 : load.i64               i26, i0, 40      
    33 : spill                  10, i26          
    34 : load.i64               i26, i0, 24      
    35 : spill                  11, i26          
    36 : load.i64               i26, i0, 32      
    37 : spill                  12, i26          
    38 : annotation:whilecstart 3                
    39 : unspill                i26, 10          
    40 : cmp                    i26, 0           
    41 : jmp_le                 __loops_label_5  
    42 : annotation:whilecend                    
    43 : unspill                i26, 11          
    44 : load.i32               i27, i26         
    45 : spill                  0, i27           
    46 : unspill                i26, 11          
    47 : add                    i26, i26, 4      
    48 : spill                  11, i26          
    49 : unspill                i26, 12          
    50 : load.i32               i3, i26          
    51 : unspill                i26, 12          
    52 : add                    i26, i26, 4      
    53 : spill                  12, i26          
    54 : unspill                i26, 10          
    55 : sub                    i26, i26, 1      
    56 : spill                  10, i26          
    57 : annotation:ifcstart                     
    58 : unspill                i26, 9           
    59 : cmp                    i3, i26          
    60 : jmp_le                 __loops_label_7  
    61 : annotation:ifcend                       
    62 : annotation:continue    0                
    63 : annotation:else        7, 8             
    64 : annotation:ifcstart                     
    65 : unspill                i26, 9           
    66 : cmp                    i3, i26          
    67 : jmp_ne                 __loops_label_10 
    68 : annotation:ifcend                       
    69 : load.i64               i26, i0, 64      
    70 : spill                  1, i26           
    71 : load.i64               i26, i0, 48      
    72 : spill                  2, i26           
    73 : load.i64               i26, i0, 56      
    74 : spill                  3, i26           
    75 : annotation:whilecstart 11               
    76 : unspill                i26, 1           
    77 : cmp                    i26, 0           
    78 : jmp_le                 __loops_label_13 
    79 : annotation:whilecend                    
    80 : unspill                i26, 2           
    81 : load.i32               i25, i26         
    82 : unspill                i26, 2           
    83 : add                    i26, i26, 4      
    84 : spill                  2, i26           
    85 : unspill                i26, 3           
    86 : load.i32               i3, i26          
    87 : unspill                i26, 3           
    88 : add                    i26, i26, 4      
    89 : spill                  3, i26           
    90 : unspill                i26, 1           
    91 : sub                    i26, i26, 1      
    92 : spill                  1, i26           
    93 : annotation:ifcstart                     
    94 : unspill                i26, 4           
    95 : cmp                    i25, i26         
    96 : jmp_le                 __loops_label_15 
    97 : annotation:ifcend                       
    98 : annotation:continue    0                
    99 : annotation:else        15, 16           
   100 : annotation:ifcstart                     
   101 : unspill                i26, 4           
   102 : cmp                    i25, i26         
   103 : jmp_ne                 __loops_label_18 
   104 : unspill                i26, 0           
   105 : cmp                    i26, i1          
   106 : jmp_ne                 __loops_label_18 
   107 : cmp                    i3, i2           
   108 : jmp_ne                 __loops_label_18 
   109 : annotation:ifcend                       
   110 : mov                    i26, 1           
   111 : spill                  5, i26           
   112 : annotation:break       2                
   113 : annotation:endif       16               
   114 : annotation:endif       18               
   115 : annotation:endwhile    11, 13           
   116 : annotation:endif       8                
   117 : annotation:endif       10               
   118 : annotation:endwhile    3, 5             
   119 : annotation:endwhile    0, 2             
   120 : unspill                i26, 5           
   121 : mov                    i0, i26          
   122 : ret                                     
   123 : unspill                i25, 13          
   124 : unspill                i26, 14          
   125 : unspill                i27, 15          
   126 : add                    i31, i31, 128    
