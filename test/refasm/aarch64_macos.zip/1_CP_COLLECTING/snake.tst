snake(i0, i1, i2)
     0 : add                    i4, i1, i2                    
     1 : sub                    i3, i4, 1                     
     2 : mov                    i5, 0                         
     3 : mov                    i6, 1                         
     4 : neg                    i7, i6                        
     5 : mov                    i8, 0                         
     6 : annotation:whilecstart 0                             
     7 : cmp                    i8, i3                        
     8 : jmp_ge                 __loops_label_2               
     9 : annotation:whilecend                                 
    10 : mov                    i9, 0                         
    11 : mov                    i10, 0                        
    12 : annotation:ifcstart                                  
    13 : and                    i11, i8, 1                    
    14 : cmp                    i11, 0                        
    15 : jmp_eq                 __loops_label_4               
    16 : annotation:ifcend                                    
    17 : sub                    i12, i2, 1                    
    18 : min                    i9, i12, i8                   
    19 : sub                    i13, i8, i12                  
    20 : mov                    i14, 0                        
    21 : cmp                    i8, i12                       
    22 : select_gt              i10, i13, i14                 
    23 : annotation:else        4, 5                          
    24 : sub                    i15, i1, 1                    
    25 : sub                    i16, i8, i15                  
    26 : mov                    i17, 0                        
    27 : cmp                    i8, i15                       
    28 : select_gt              i9, i16, i17                  
    29 : min                    i10, i15, i8                  
    30 : annotation:endif       5                             
    31 : annotation:whilecstart 6                             
    32 : cmp                    i9, 0                         
    33 : jmp_gt                 __loops_label_8               
    34 : cmp                    i9, i2                        
    35 : jmp_ge                 __loops_label_8               
    36 : cmp                    i10, 0                        
    37 : jmp_gt                 __loops_label_8               
    38 : cmp                    i10, i1                       
    39 : jmp_ge                 __loops_label_8               
    40 : annotation:whilecend                                 
    41 : call_noret             [0x000000010415BAD0](i9, i10) 
    42 : mul                    i19, i10, i2                  
    43 : add                    i18, i19, i9                  
    44 : store.u8               i0, i18, i5                   
    45 : add                    i5, i5, 1                     
    46 : add                    i9, i9, i6                    
    47 : add                    i10, i10, i7                  
    48 : annotation:endwhile    6, 8                          
    49 : neg                    i6, i6                        
    50 : neg                    i7, i7                        
    51 : add                    i8, i8, 1                     
    52 : annotation:endwhile    0, 2                          
    53 : ret                                                  
