fixed_power_0(i0)
     0 : mov i1, 1  
     1 : mov iR, i1 
     2 : ret        
