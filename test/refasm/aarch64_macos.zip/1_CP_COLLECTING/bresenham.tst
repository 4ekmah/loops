bresenham(i0, i1, i2, i3, i4, i5, i6)
     0 : sub                    i8, i4, i2       
     1 : abs                    i7, i8           
     2 : sub                    i10, i4, i2      
     3 : sign                   i9, i10          
     4 : sub                    i13, i5, i3      
     5 : abs                    i12, i13         
     6 : neg                    i11, i12         
     7 : sub                    i15, i5, i3      
     8 : sign                   i14, i15         
     9 : add                    i16, i7, i11     
    10 : annotation:whilecstart 0                
    11 : cmp                    i0, 0            
    12 : jmp_eq                 __loops_label_2  
    13 : annotation:whilecend                    
    14 : mul                    i18, i3, i1      
    15 : add                    i17, i18, i2     
    16 : store.u8               i0, i17, i6      
    17 : annotation:ifcstart                     
    18 : cmp                    i2, i4           
    19 : jmp_ne                 __loops_label_4  
    20 : cmp                    i3, i5           
    21 : jmp_ne                 __loops_label_4  
    22 : annotation:ifcend                       
    23 : annotation:break       2                
    24 : annotation:endif       4                
    25 : shl                    i19, i16, 1      
    26 : annotation:ifcstart                     
    27 : cmp                    i19, i11         
    28 : jmp_gt                 __loops_label_6  
    29 : annotation:ifcend                       
    30 : annotation:ifcstart                     
    31 : cmp                    i2, i4           
    32 : jmp_ne                 __loops_label_8  
    33 : annotation:ifcend                       
    34 : annotation:break       2                
    35 : annotation:endif       8                
    36 : add                    i16, i16, i11    
    37 : add                    i2, i2, i9       
    38 : annotation:endif       6                
    39 : annotation:ifcstart                     
    40 : cmp                    i19, i7          
    41 : jmp_gt                 __loops_label_10 
    42 : annotation:ifcend                       
    43 : annotation:ifcstart                     
    44 : cmp                    i3, i5           
    45 : jmp_ne                 __loops_label_12 
    46 : annotation:ifcend                       
    47 : annotation:break       2                
    48 : annotation:endif       12               
    49 : add                    i16, i16, i7     
    50 : add                    i3, i3, i14      
    51 : annotation:endif       10               
    52 : annotation:endwhile    0, 2             
    53 : ret                                     
