ten_args_to_sum(i0, i1, i2, i3, i4, i5, i6, i7, i8, i9)
     0 : mul i10, i0, 1    
     1 : mul i11, i1, 2    
     2 : add i10, i10, i11 
     3 : mul i12, i2, 3    
     4 : add i10, i10, i12 
     5 : mul i13, i3, 4    
     6 : add i10, i10, i13 
     7 : mul i14, i4, 5    
     8 : add i10, i10, i14 
     9 : mul i15, i5, 6    
    10 : add i10, i10, i15 
    11 : mul i16, i6, 7    
    12 : add i10, i10, i16 
    13 : mul i17, i7, 8    
    14 : add i10, i10, i17 
    15 : mul i18, i8, 3    
    16 : add i10, i10, i18 
    17 : mul i19, i9, 2    
    18 : add i10, i10, i19 
    19 : mov iR, i10       
    20 : ret               
