triangle_types(i0, i1, i2)
     0 : annotation:ifcstart                  
     1 : cmp                 i0, 0            
     2 : jmp_le              __loops_label_0  
     3 : cmp                 i1, 0            
     4 : jmp_le              __loops_label_0  
     5 : cmp                 i2, 0            
     6 : jmp_gt              __loops_label_1  
     7 : __loops_label_0:                     
     8 : annotation:ifcend                    
     9 : mov                 iR, 0            
    10 : ret                                  
    11 : annotation:elif     1, 2             
    12 : add                 i3, i1, i2       
    13 : cmp                 i0, i3           
    14 : jmp_gt              __loops_label_3  
    15 : add                 i4, i0, i2       
    16 : cmp                 i1, i4           
    17 : jmp_gt              __loops_label_3  
    18 : add                 i5, i0, i1       
    19 : cmp                 i2, i5           
    20 : jmp_le              __loops_label_4  
    21 : __loops_label_3:                     
    22 : annotation:ifcend                    
    23 : mov                 iR, 0            
    24 : ret                                  
    25 : annotation:elif     4, 5             
    26 : cmp                 i0, i1           
    27 : jmp_ne              __loops_label_7  
    28 : cmp                 i0, i2           
    29 : jmp_ne              __loops_label_7  
    30 : annotation:ifcend                    
    31 : mov                 iR, 2            
    32 : ret                                  
    33 : annotation:elif     7, 8             
    34 : cmp                 i0, i1           
    35 : jmp_eq              __loops_label_9  
    36 : cmp                 i0, i2           
    37 : jmp_eq              __loops_label_9  
    38 : cmp                 i1, i2           
    39 : jmp_ne              __loops_label_10 
    40 : __loops_label_9:                     
    41 : annotation:ifcend                    
    42 : mov                 iR, 3            
    43 : ret                                  
    44 : annotation:elif     10, 11           
    45 : mul                 i6, i0, i0       
    46 : mul                 i8, i1, i1       
    47 : mul                 i9, i2, i2       
    48 : add                 i7, i8, i9       
    49 : cmp                 i6, i7           
    50 : jmp_eq              __loops_label_12 
    51 : mul                 i10, i1, i1      
    52 : mul                 i12, i0, i0      
    53 : mul                 i13, i2, i2      
    54 : add                 i11, i12, i13    
    55 : cmp                 i10, i11         
    56 : jmp_eq              __loops_label_12 
    57 : mul                 i14, i2, i2      
    58 : mul                 i16, i0, i0      
    59 : mul                 i17, i1, i1      
    60 : add                 i15, i16, i17    
    61 : cmp                 i14, i15         
    62 : jmp_ne              __loops_label_13 
    63 : __loops_label_12:                    
    64 : annotation:ifcend                    
    65 : mov                 iR, 1            
    66 : ret                                  
    67 : annotation:elif     13, 14           
    68 : mul                 i18, i0, i0      
    69 : mul                 i20, i1, i1      
    70 : mul                 i21, i2, i2      
    71 : add                 i19, i20, i21    
    72 : cmp                 i18, i19         
    73 : jmp_gt              __loops_label_15 
    74 : mul                 i22, i1, i1      
    75 : mul                 i24, i0, i0      
    76 : mul                 i25, i2, i2      
    77 : add                 i23, i24, i25    
    78 : cmp                 i22, i23         
    79 : jmp_gt              __loops_label_15 
    80 : mul                 i26, i2, i2      
    81 : mul                 i28, i0, i0      
    82 : mul                 i29, i1, i1      
    83 : add                 i27, i28, i29    
    84 : cmp                 i26, i27         
    85 : jmp_le              __loops_label_16 
    86 : __loops_label_15:                    
    87 : annotation:ifcend                    
    88 : mov                 iR, 5            
    89 : ret                                  
    90 : annotation:else     16, 17           
    91 : mov                 iR, 4            
    92 : ret                                  
    93 : annotation:endif    17               
