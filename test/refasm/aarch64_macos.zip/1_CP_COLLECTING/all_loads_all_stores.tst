all_loads_all_stores(i0, i1, i2, i3, i4)
     0 : mov                    i5, 0            
     1 : mov                    i6, 0            
     2 : mov                    i7, 0            
     3 : mov                    i8, 2            
     4 : mov                    i9, 1            
     5 : cmp                    i1, 1            
     6 : select_gt              i10, i8, i9      
     7 : mov                    i11, 4           
     8 : cmp                    i1, 3            
     9 : select_gt              i10, i11, i10    
    10 : mov                    i12, 8           
    11 : cmp                    i1, 5            
    12 : select_gt              i10, i12, i10    
    13 : mov                    i13, 2           
    14 : mov                    i14, 1           
    15 : cmp                    i3, 1            
    16 : select_gt              i15, i13, i14    
    17 : mov                    i16, 4           
    18 : cmp                    i3, 3            
    19 : select_gt              i15, i16, i15    
    20 : mov                    i17, 8           
    21 : cmp                    i3, 5            
    22 : select_gt              i15, i17, i15    
    23 : annotation:whilecstart 0                
    24 : cmp                    i5, i4           
    25 : jmp_ge                 __loops_label_2  
    26 : annotation:whilecend                    
    27 : def                    i18              
    28 : annotation:ifcstart                     
    29 : cmp                    i1, 0            
    30 : jmp_ne                 __loops_label_4  
    31 : annotation:ifcend                       
    32 : load.u8                i18, i0, i6      
    33 : annotation:elif        4, 5             
    34 : cmp                    i1, 1            
    35 : jmp_ne                 __loops_label_7  
    36 : annotation:ifcend                       
    37 : load.i8                i18, i0, i6      
    38 : annotation:elif        7, 8             
    39 : cmp                    i1, 2            
    40 : jmp_ne                 __loops_label_10 
    41 : annotation:ifcend                       
    42 : load.u16               i18, i0, i6      
    43 : annotation:elif        10, 11           
    44 : cmp                    i1, 3            
    45 : jmp_ne                 __loops_label_13 
    46 : annotation:ifcend                       
    47 : load.i16               i18, i0, i6      
    48 : annotation:elif        13, 14           
    49 : cmp                    i1, 4            
    50 : jmp_ne                 __loops_label_16 
    51 : annotation:ifcend                       
    52 : load.u32               i18, i0, i6      
    53 : annotation:elif        16, 17           
    54 : cmp                    i1, 5            
    55 : jmp_ne                 __loops_label_19 
    56 : annotation:ifcend                       
    57 : load.i32               i18, i0, i6      
    58 : annotation:elif        19, 20           
    59 : cmp                    i1, 6            
    60 : jmp_ne                 __loops_label_22 
    61 : annotation:ifcend                       
    62 : load.u64               i18, i0, i6      
    63 : annotation:else        22, 23           
    64 : load.i64               i18, i0, i6      
    65 : annotation:endif       23               
    66 : annotation:ifcstart                     
    67 : cmp                    i3, 0            
    68 : jmp_ne                 __loops_label_25 
    69 : annotation:ifcend                       
    70 : store.u8               i2, i7, i18      
    71 : annotation:elif        25, 26           
    72 : cmp                    i3, 1            
    73 : jmp_ne                 __loops_label_28 
    74 : annotation:ifcend                       
    75 : store.i8               i2, i7, i18      
    76 : annotation:elif        28, 29           
    77 : cmp                    i3, 2            
    78 : jmp_ne                 __loops_label_31 
    79 : annotation:ifcend                       
    80 : store.u16              i2, i7, i18      
    81 : annotation:elif        31, 32           
    82 : cmp                    i3, 3            
    83 : jmp_ne                 __loops_label_34 
    84 : annotation:ifcend                       
    85 : store.i16              i2, i7, i18      
    86 : annotation:elif        34, 35           
    87 : cmp                    i3, 4            
    88 : jmp_ne                 __loops_label_37 
    89 : annotation:ifcend                       
    90 : store.u32              i2, i7, i18      
    91 : annotation:elif        37, 38           
    92 : cmp                    i3, 5            
    93 : jmp_ne                 __loops_label_40 
    94 : annotation:ifcend                       
    95 : store.i32              i2, i7, i18      
    96 : annotation:elif        40, 41           
    97 : cmp                    i3, 6            
    98 : jmp_ne                 __loops_label_43 
    99 : annotation:ifcend                       
   100 : store.u64              i2, i7, i18      
   101 : annotation:else        43, 44           
   102 : store.i64              i2, i7, i18      
   103 : annotation:endif       44               
   104 : add                    i6, i6, i10      
   105 : add                    i7, i7, i15      
   106 : add                    i5, i5, 1        
   107 : annotation:endwhile    0, 2             
