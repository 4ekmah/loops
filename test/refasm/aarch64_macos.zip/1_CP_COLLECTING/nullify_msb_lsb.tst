nullify_msb_lsb(i0, i1, i2)
     0 : shr       i4, i0, 1    
     1 : or        i3, i0, i4   
     2 : shr       i5, i3, 2    
     3 : or        i3, i3, i5   
     4 : shr       i6, i3, 4    
     5 : or        i3, i3, i6   
     6 : shr       i7, i3, 8    
     7 : or        i3, i3, i7   
     8 : shr       i8, i3, 16   
     9 : or        i3, i3, i8   
    10 : shr       i9, i3, 32   
    11 : or        i3, i3, i9   
    12 : add       i3, i3, 1    
    13 : shr       i3, i3, 1    
    14 : xor       i3, i3, i0   
    15 : store.u64 i2, i3       
    16 : sub       i12, i0, 1   
    17 : not       i11, i12     
    18 : and       i10, i0, i11 
    19 : xor       i10, i10, i0 
    20 : store.u64 i1, i10      
    21 : ret                    
