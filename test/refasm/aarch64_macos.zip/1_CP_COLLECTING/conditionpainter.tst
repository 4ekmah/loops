conditionpainter(i0)
     0 : mov                    i1, -5          
     1 : annotation:whilecstart 0               
     2 : cmp                    i1, 5           
     3 : jmp_gt                 __loops_label_2 
     4 : annotation:whilecend                   
     5 : add                    i4, i1, 5       
     6 : mul                    i3, i4, 11      
     7 : mul                    i2, i3, 8       
     8 : mov                    i5, -5          
     9 : annotation:whilecstart 3               
    10 : cmp                    i5, 5           
    11 : jmp_gt                 __loops_label_5 
    12 : annotation:whilecend                   
    13 : add                    i10, i5, 3      
    14 : cmp                    i1, i10         
    15 : iverson_ge             i11             
    16 : cmp                    i1, 4           
    17 : iverson_le             i12             
    18 : and                    i9, i11, i12    
    19 : cmp                    i5, -2          
    20 : iverson_ge             i13             
    21 : and                    i8, i9, i13     
    22 : cmp                    i5, 0           
    23 : iverson_le             i14             
    24 : and                    i7, i8, i14     
    25 : sub                    i18, i5, 1      
    26 : cmp                    i1, i18         
    27 : iverson_le             i19             
    28 : cmp                    i5, 0           
    29 : iverson_ge             i20             
    30 : and                    i17, i19, i20   
    31 : cmp                    i1, 0           
    32 : iverson_le             i21             
    33 : and                    i16, i17, i21   
    34 : mul                    i23, i5, i5     
    35 : mul                    i24, i1, i1     
    36 : add                    i22, i23, i24   
    37 : cmp                    i22, 9          
    38 : iverson_le             i25             
    39 : and                    i15, i16, i25   
    40 : or                     i6, i7, i15     
    41 : mov                    i26, 2          
    42 : mov                    i27, 0          
    43 : cmp                    i5, 2           
    44 : iverson_ge             i31             
    45 : cmp                    i5, 4           
    46 : iverson_le             i32             
    47 : and                    i30, i31, i32   
    48 : cmp                    i1, 1           
    49 : iverson_ge             i34             
    50 : cmp                    i1, 3           
    51 : iverson_le             i35             
    52 : and                    i33, i34, i35   
    53 : or                     i29, i30, i33   
    54 : mul                    i37, i5, i5     
    55 : mul                    i38, i1, i1     
    56 : add                    i36, i37, i38   
    57 : cmp                    i36, 16         
    58 : iverson_le             i39             
    59 : and                    i28, i29, i39   
    60 : cmp                    i28, 0          
    61 : select_ne              i40, i26, i27   
    62 : add                    i6, i6, i40     
    63 : annotation:ifcstart                    
    64 : mul                    i41, i1, 2      
    65 : cmp                    i41, i5         
    66 : jmp_gt                 __loops_label_8 
    67 : add                    i44, i5, 3      
    68 : neg                    i43, i44        
    69 : add                    i45, i5, 3      
    70 : mul                    i42, i43, i45   
    71 : cmp                    i1, i42         
    72 : jmp_le                 __loops_label_9 
    73 : __loops_label_8:                       
    74 : mul                    i46, i5, 2      
    75 : cmp                    i1, i46         
    76 : jmp_gt                 __loops_label_7 
    77 : add                    i49, i5, 3      
    78 : neg                    i48, i49        
    79 : add                    i50, i5, 3      
    80 : mul                    i47, i48, i50   
    81 : cmp                    i1, i47         
    82 : jmp_gt                 __loops_label_7 
    83 : __loops_label_9:                       
    84 : cmp                    i5, 0           
    85 : jmp_gt                 __loops_label_7 
    86 : annotation:ifcend                      
    87 : add                    i6, i6, 3       
    88 : annotation:endif       7               
    89 : add                    i53, i5, 5      
    90 : shl                    i52, i53, 3     
    91 : add                    i51, i2, i52    
    92 : store.i64              i0, i51, i6     
    93 : add                    i5, i5, 1       
    94 : annotation:endwhile    3, 5            
    95 : add                    i1, i1, 1       
    96 : annotation:endwhile    0, 2            
    97 : ret                                    
