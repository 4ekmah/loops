has_in_join_cascade(i0, i1, i2)
     0 : mov                    i3, 0            
     1 : load.i64               i4, i0, 16       
     2 : load.i64               i5, i0, 0        
     3 : load.i64               i6, i0, 8        
     4 : annotation:whilecstart 0                
     5 : cmp                    i4, 0            
     6 : jmp_le                 __loops_label_2  
     7 : annotation:whilecend                    
     8 : load.i32               i7, i5           
     9 : add                    i5, i5, 4        
    10 : load.i32               i8, i6           
    11 : add                    i6, i6, 4        
    12 : sub                    i4, i4, 1        
    13 : load.i64               i9, i0, 40       
    14 : load.i64               i10, i0, 24      
    15 : load.i64               i11, i0, 32      
    16 : annotation:whilecstart 3                
    17 : cmp                    i9, 0            
    18 : jmp_le                 __loops_label_5  
    19 : annotation:whilecend                    
    20 : load.i32               i12, i10         
    21 : add                    i10, i10, 4      
    22 : load.i32               i13, i11         
    23 : add                    i11, i11, 4      
    24 : sub                    i9, i9, 1        
    25 : annotation:ifcstart                     
    26 : cmp                    i13, i7          
    27 : jmp_le                 __loops_label_7  
    28 : annotation:ifcend                       
    29 : annotation:break       3                
    30 : annotation:elif        7, 8             
    31 : cmp                    i13, i7          
    32 : jmp_ne                 __loops_label_10 
    33 : annotation:ifcend                       
    34 : load.i64               i14, i0, 64      
    35 : load.i64               i15, i0, 48      
    36 : load.i64               i16, i0, 56      
    37 : annotation:whilecstart 11               
    38 : cmp                    i14, 0           
    39 : jmp_le                 __loops_label_13 
    40 : annotation:whilecend                    
    41 : load.i32               i17, i15         
    42 : add                    i15, i15, 4      
    43 : load.i32               i18, i16         
    44 : add                    i16, i16, 4      
    45 : sub                    i14, i14, 1      
    46 : annotation:ifcstart                     
    47 : cmp                    i17, i8          
    48 : jmp_le                 __loops_label_15 
    49 : annotation:ifcend                       
    50 : annotation:break       11               
    51 : annotation:elif        15, 16           
    52 : cmp                    i17, i8          
    53 : jmp_ne                 __loops_label_18 
    54 : cmp                    i12, i1          
    55 : jmp_ne                 __loops_label_18 
    56 : cmp                    i18, i2          
    57 : jmp_ne                 __loops_label_18 
    58 : annotation:ifcend                       
    59 : mov                    i3, 1            
    60 : annotation:break       2                
    61 : annotation:endif       18               
    62 : annotation:endwhile    11, 13           
    63 : annotation:endif       10               
    64 : annotation:endwhile    3, 5             
    65 : annotation:endwhile    0, 2             
    66 : mov                    iR, i3           
    67 : ret                                     
