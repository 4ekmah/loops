big_immediates(i0, i1)
     0 : annotation:ifcstart                  
     1 : cmp                 i1, 0            
     2 : jmp_ne              __loops_label_1  
     3 : annotation:ifcend                    
     4 : mov                 i2, 65535        
     5 : store.u64           i0, i2           
     6 : add                 i0, i0, 8        
     7 : mov                 i3, 65536        
     8 : store.u64           i0, i3           
     9 : add                 i0, i0, 8        
    10 : mov                 i4, -32768       
    11 : store.i64           i0, i4           
    12 : add                 i0, i0, 8        
    13 : mov                 i5, -32769       
    14 : store.i64           i0, i5           
    15 : add                 i0, i0, 8        
    16 : mov                 i6, 1597463007   
    17 : store.u64           i0, i6           
    18 : add                 i0, i0, 8        
    19 : mov                 i7, -1961601175  
    20 : store.u64           i0, i7           
    21 : add                 i0, i0, 8        
    22 : annotation:elif     1, 2             
    23 : cmp                 i1, 1            
    24 : jmp_ne              __loops_label_4  
    25 : annotation:ifcend                    
    26 : mov                 v0, 0            
    27 : vst.u8              i0, v0           
    28 : add                 i0, i0, 16       
    29 : mov                 v1, 255          
    30 : vst.u8              i0, v1           
    31 : add                 i0, i0, 16       
    32 : annotation:elif     4, 5             
    33 : cmp                 i1, 2            
    34 : jmp_ne              __loops_label_7  
    35 : annotation:ifcend                    
    36 : mov                 v2, 128          
    37 : vst.i8              i0, v2           
    38 : add                 i0, i0, 16       
    39 : annotation:elif     7, 8             
    40 : cmp                 i1, 3            
    41 : jmp_ne              __loops_label_10 
    42 : annotation:ifcend                    
    43 : mov                 v3, 0            
    44 : vst.u16             i0, v3           
    45 : add                 i0, i0, 16       
    46 : mov                 v4, 255          
    47 : vst.u16             i0, v4           
    48 : add                 i0, i0, 16       
    49 : mov                 v5, 256          
    50 : vst.u16             i0, v5           
    51 : add                 i0, i0, 16       
    52 : annotation:elif     10, 11           
    53 : cmp                 i1, 4            
    54 : jmp_ne              __loops_label_13 
    55 : annotation:ifcend                    
    56 : mov                 v6, 65408        
    57 : vst.i16             i0, v6           
    58 : add                 i0, i0, 16       
    59 : mov                 v7, 65407        
    60 : vst.i16             i0, v7           
    61 : add                 i0, i0, 16       
    62 : annotation:elif     13, 14           
    63 : cmp                 i1, 5            
    64 : jmp_ne              __loops_label_16 
    65 : annotation:ifcend                    
    66 : mov                 v8, 0            
    67 : vst.u32             i0, v8           
    68 : add                 i0, i0, 16       
    69 : mov                 v9, 255          
    70 : vst.u32             i0, v9           
    71 : add                 i0, i0, 16       
    72 : mov                 v10, 256         
    73 : vst.u32             i0, v10          
    74 : add                 i0, i0, 16       
    75 : annotation:elif     16, 17           
    76 : cmp                 i1, 6            
    77 : jmp_ne              __loops_label_19 
    78 : annotation:ifcend                    
    79 : mov                 v11, -128        
    80 : vst.i32             i0, v11          
    81 : add                 i0, i0, 16       
    82 : mov                 v12, -129        
    83 : vst.i32             i0, v12          
    84 : add                 i0, i0, 16       
    85 : annotation:elif     19, 20           
    86 : cmp                 i1, 7            
    87 : jmp_ne              __loops_label_22 
    88 : annotation:ifcend                    
    89 : mov                 v13, 0           
    90 : vst.u64             i0, v13          
    91 : add                 i0, i0, 16       
    92 : mov                 v14, 255         
    93 : vst.u64             i0, v14          
    94 : add                 i0, i0, 16       
    95 : mov                 v15, 65280       
    96 : vst.u64             i0, v15          
    97 : add                 i0, i0, 16       
    98 : annotation:elif     22, 23           
    99 : cmp                 i1, 8            
   100 : jmp_ne              __loops_label_25 
   101 : annotation:ifcend                    
   102 : mov                 v16, -256        
   103 : vst.i64             i0, v16          
   104 : add                 i0, i0, 16       
   105 : annotation:elif     25, 26           
   106 : cmp                 i1, 9            
   107 : jmp_ne              __loops_label_28 
   108 : annotation:ifcend                    
   109 : mov                 v17, 256         
   110 : vst.u64             i0, v17          
   111 : add                 i0, i0, 16       
   112 : mov                 v18, 254         
   113 : vst.u64             i0, v18          
   114 : add                 i0, i0, 16       
   115 : annotation:endif    28               
   116 : ret                                  
