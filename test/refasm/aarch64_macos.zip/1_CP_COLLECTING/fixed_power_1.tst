fixed_power_1(i0)
     0 : mov iR, i0 
     1 : ret        
