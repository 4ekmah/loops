min_max_select(i0, i1, i2, i3)
     0 : sub              i31, i31, 64    
     1 : spill            5, i25          
     2 : spill            6, i26          
     3 : spill            1, i2           
     4 : spill            0, i3           
     5 : mov              i25, 0          
     6 : mov              i26, 0          
     7 : spill            3, i26          
     8 : mov              i26, 0          
     9 : spill            2, i26          
    10 : load.i32         i2, i0          
    11 : mov              i3, i2          
    12 : shl              i26, i1, 2      
    13 : spill            4, i26          
    14 : __loops_label_0:                 
    15 : unspill          i26, 4          
    16 : cmp              i25, i26        
    17 : jmp_ge           __loops_label_2 
    18 : load.i32         i1, i0, i25     
    19 : cmp              i1, i2          
    20 : unspill          i26, 3          
    21 : select_gt        i26, i25, i26   
    22 : spill            3, i26          
    23 : min              i2, i1, i2      
    24 : cmp              i1, i3          
    25 : unspill          i26, 2          
    26 : select_gt        i26, i25, i26   
    27 : spill            2, i26          
    28 : max              i3, i1, i3      
    29 : add              i25, i25, 4     
    30 : jmp              0               
    31 : __loops_label_2:                 
    32 : unspill          i26, 3          
    33 : sar              i0, i26, 2      
    34 : unspill          i26, 2          
    35 : sar              i1, i26, 2      
    36 : unspill          i26, 1          
    37 : store.i32        i26, i0         
    38 : unspill          i26, 0          
    39 : store.i32        i26, i1         
    40 : mov              i0, 0           
    41 : unspill          i25, 5          
    42 : unspill          i26, 6          
    43 : add              i31, i31, 64    
    44 : ret                              
