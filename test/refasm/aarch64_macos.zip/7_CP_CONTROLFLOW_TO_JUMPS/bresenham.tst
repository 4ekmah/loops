bresenham(i0, i1, i2, i3, i4, i5, i6)
     0 : sub               i31, i31, 80     
     1 : spill             5, i25           
     2 : spill             6, i26           
     3 : spill             7, i27           
     4 : spill             8, i28           
     5 : sub               i25, i4, i2      
     6 : abs               i26, i25         
     7 : spill             0, i26           
     8 : sub               i25, i4, i2      
     9 : sign              i26, i25         
    10 : spill             1, i26           
    11 : sub               i25, i5, i3      
    12 : abs               i25, i25         
    13 : neg               i26, i25         
    14 : spill             2, i26           
    15 : sub               i25, i5, i3      
    16 : sign              i26, i25         
    17 : spill             4, i26           
    18 : unspill           i26, 0           
    19 : unspill           i27, 2           
    20 : add               i28, i26, i27    
    21 : spill             3, i28           
    22 : __loops_label_0:                   
    23 : cmp               i0, 0            
    24 : jmp_eq            __loops_label_2  
    25 : mul               i25, i3, i1      
    26 : add               i25, i25, i2     
    27 : store.u8          i0, i25, i6      
    28 : cmp               i2, i4           
    29 : jmp_ne            __loops_label_4  
    30 : cmp               i3, i5           
    31 : jmp_ne            __loops_label_4  
    32 : jmp               2                
    33 : __loops_label_4:                   
    34 : unspill           i26, 3           
    35 : shl               i25, i26, 1      
    36 : unspill           i26, 2           
    37 : cmp               i25, i26         
    38 : jmp_gt            __loops_label_6  
    39 : cmp               i2, i4           
    40 : jmp_ne            __loops_label_8  
    41 : jmp               2                
    42 : __loops_label_8:                   
    43 : unspill           i27, 2           
    44 : unspill           i26, 3           
    45 : add               i26, i26, i27    
    46 : spill             3, i26           
    47 : unspill           i26, 1           
    48 : add               i2, i2, i26      
    49 : __loops_label_6:                   
    50 : unspill           i26, 0           
    51 : cmp               i25, i26         
    52 : jmp_gt            __loops_label_10 
    53 : cmp               i3, i5           
    54 : jmp_ne            __loops_label_12 
    55 : jmp               2                
    56 : __loops_label_12:                  
    57 : unspill           i27, 0           
    58 : unspill           i26, 3           
    59 : add               i26, i26, i27    
    60 : spill             3, i26           
    61 : unspill           i26, 4           
    62 : add               i3, i3, i26      
    63 : __loops_label_10:                  
    64 : jmp               0                
    65 : __loops_label_2:                   
    66 : unspill           i25, 5           
    67 : unspill           i26, 6           
    68 : unspill           i27, 7           
    69 : unspill           i28, 8           
    70 : add               i31, i31, 80     
    71 : ret                                
