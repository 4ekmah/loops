nonnegative_odd(i0, i1)
     0 : sub              i31, i31, 48    
     1 : spill            3, i25          
     2 : spill            4, i26          
     3 : mov              i2, 0           
     4 : mov              i26, -4         
     5 : spill            2, i26          
     6 : mov              i25, 4          
     7 : mul              i1, i1, i25     
     8 : __loops_label_0:                 
     9 : cmp              i2, i1          
    10 : jmp_ge           __loops_label_2 
    11 : load.i32         i25, i0, i2     
    12 : cmp              i25, 0          
    13 : jmp_ge           __loops_label_4 
    14 : add              i2, i2, 4       
    15 : jmp              0               
    16 : __loops_label_4:                 
    17 : mov              i3, 2           
    18 : mod              i3, i25, i3     
    19 : cmp              i3, 0           
    20 : jmp_eq           __loops_label_6 
    21 : mov              i26, i2         
    22 : spill            2, i26          
    23 : jmp              2               
    24 : __loops_label_6:                 
    25 : add              i2, i2, 4       
    26 : jmp              0               
    27 : __loops_label_2:                 
    28 : mov              i0, 4           
    29 : unspill          i26, 2          
    30 : div              i0, i26, i0     
    31 : mov              i0, i0          
    32 : unspill          i25, 3          
    33 : unspill          i26, 4          
    34 : add              i31, i31, 48    
    35 : ret                              
