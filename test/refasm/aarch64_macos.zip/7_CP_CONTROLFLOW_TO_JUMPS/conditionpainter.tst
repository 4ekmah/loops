conditionpainter(i0)
     0 : sub              i31, i31, 64    
     1 : spill            5, i25          
     2 : spill            6, i26          
     3 : spill            1, i0           
     4 : mov              i26, -5         
     5 : spill            0, i26          
     6 : __loops_label_0:                 
     7 : unspill          i26, 0          
     8 : cmp              i26, 5          
     9 : jmp_gt           __loops_label_2 
    10 : unspill          i26, 0          
    11 : add              i2, i26, 5      
    12 : mov              i3, 11          
    13 : mul              i2, i2, i3      
    14 : mov              i3, 8           
    15 : mul              i26, i2, i3     
    16 : spill            3, i26          
    17 : mov              i26, -5         
    18 : spill            2, i26          
    19 : __loops_label_3:                 
    20 : unspill          i26, 2          
    21 : cmp              i26, 5          
    22 : jmp_gt           __loops_label_5 
    23 : unspill          i26, 2          
    24 : add              i25, i26, 3     
    25 : unspill          i26, 0          
    26 : cmp              i26, i25        
    27 : iverson_ge       i25             
    28 : unspill          i26, 0          
    29 : cmp              i26, 4          
    30 : iverson_le       i1              
    31 : and              i1, i25, i1     
    32 : mov              i25, -2         
    33 : unspill          i26, 2          
    34 : cmp              i26, i25        
    35 : iverson_ge       i25             
    36 : and              i1, i1, i25     
    37 : unspill          i26, 2          
    38 : cmp              i26, 0          
    39 : iverson_le       i25             
    40 : and              i1, i1, i25     
    41 : unspill          i26, 2          
    42 : sub              i25, i26, 1     
    43 : unspill          i26, 0          
    44 : cmp              i26, i25        
    45 : iverson_le       i25             
    46 : unspill          i26, 2          
    47 : cmp              i26, 0          
    48 : iverson_ge       i0              
    49 : and              i0, i25, i0     
    50 : unspill          i26, 0          
    51 : cmp              i26, 0          
    52 : iverson_le       i25             
    53 : and              i0, i0, i25     
    54 : unspill          i26, 2          
    55 : mul              i25, i26, i26   
    56 : unspill          i26, 0          
    57 : mul              i3, i26, i26    
    58 : add              i3, i25, i3     
    59 : cmp              i3, 9           
    60 : iverson_le       i3              
    61 : and              i0, i0, i3      
    62 : or               i26, i1, i0     
    63 : spill            4, i26          
    64 : mov              i1, 2           
    65 : mov              i3, 0           
    66 : unspill          i26, 2          
    67 : cmp              i26, 2          
    68 : iverson_ge       i25             
    69 : unspill          i26, 2          
    70 : cmp              i26, 4          
    71 : iverson_le       i2              
    72 : and              i2, i25, i2     
    73 : unspill          i26, 0          
    74 : cmp              i26, 1          
    75 : iverson_ge       i25             
    76 : unspill          i26, 0          
    77 : cmp              i26, 3          
    78 : iverson_le       i0              
    79 : and              i0, i25, i0     
    80 : or               i0, i2, i0      
    81 : unspill          i26, 2          
    82 : mul              i2, i26, i26    
    83 : unspill          i26, 0          
    84 : mul              i25, i26, i26   
    85 : add              i2, i2, i25     
    86 : cmp              i2, 16          
    87 : iverson_le       i2              
    88 : and              i0, i0, i2      
    89 : cmp              i0, 0           
    90 : select_ne        i0, i1, i3      
    91 : unspill          i26, 4          
    92 : add              i0, i26, i0     
    93 : mov              i1, 2           
    94 : unspill          i26, 0          
    95 : mul              i1, i26, i1     
    96 : unspill          i26, 2          
    97 : cmp              i1, i26         
    98 : jmp_gt           __loops_label_8 
    99 : unspill          i26, 2          
   100 : add              i1, i26, 3      
   101 : neg              i1, i1          
   102 : unspill          i26, 2          
   103 : add              i2, i26, 3      
   104 : mul              i1, i1, i2      
   105 : unspill          i26, 0          
   106 : cmp              i26, i1         
   107 : jmp_le           __loops_label_9 
   108 : __loops_label_8:                 
   109 : mov              i1, 2           
   110 : unspill          i26, 2          
   111 : mul              i1, i26, i1     
   112 : unspill          i26, 0          
   113 : cmp              i26, i1         
   114 : jmp_gt           __loops_label_7 
   115 : unspill          i26, 2          
   116 : add              i1, i26, 3      
   117 : neg              i1, i1          
   118 : unspill          i26, 2          
   119 : add              i2, i26, 3      
   120 : mul              i1, i1, i2      
   121 : unspill          i26, 0          
   122 : cmp              i26, i1         
   123 : jmp_gt           __loops_label_7 
   124 : __loops_label_9:                 
   125 : unspill          i26, 2          
   126 : cmp              i26, 0          
   127 : jmp_gt           __loops_label_7 
   128 : add              i0, i0, 3       
   129 : __loops_label_7:                 
   130 : unspill          i26, 2          
   131 : add              i1, i26, 5      
   132 : shl              i1, i1, 3       
   133 : unspill          i26, 3          
   134 : add              i1, i26, i1     
   135 : unspill          i26, 1          
   136 : store.i64        i26, i1, i0     
   137 : unspill          i26, 2          
   138 : add              i26, i26, 1     
   139 : spill            2, i26          
   140 : jmp              3               
   141 : __loops_label_5:                 
   142 : unspill          i26, 0          
   143 : add              i26, i26, 1     
   144 : spill            0, i26          
   145 : jmp              0               
   146 : __loops_label_2:                 
   147 : unspill          i25, 5          
   148 : unspill          i26, 6          
   149 : add              i31, i31, 64    
   150 : ret                              
