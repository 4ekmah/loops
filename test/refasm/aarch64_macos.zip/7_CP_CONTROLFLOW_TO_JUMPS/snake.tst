snake(i0, i1, i2)
     0 : sub              i31, i31, 512      
     1 : spill            57, i0             
     2 : spill            56, i1             
     3 : spill            55, i2             
     4 : spill            58, i25            
     5 : spill            59, i26            
     6 : spill            60, i27            
     7 : arm_stp          i31, 496, i29, i30 
     8 : mov              i29, i31           
     9 : unspill          i26, 56            
    10 : unspill          i27, 55            
    11 : add              i3, i26, i27       
    12 : sub              i26, i3, 1         
    13 : spill            54, i26            
    14 : mov              i26, 0             
    15 : spill            53, i26            
    16 : mov              i26, 1             
    17 : spill            50, i26            
    18 : unspill          i26, 50            
    19 : neg              i27, i26           
    20 : spill            51, i27            
    21 : mov              i26, 0             
    22 : spill            52, i26            
    23 : __loops_label_0:                    
    24 : unspill          i27, 54            
    25 : unspill          i26, 52            
    26 : cmp              i26, i27           
    27 : jmp_ge           __loops_label_2    
    28 : mov              i25, 0             
    29 : mov              i3, 0              
    30 : unspill          i26, 52            
    31 : and              i2, i26, 1         
    32 : cmp              i2, 0              
    33 : jmp_eq           __loops_label_4    
    34 : unspill          i26, 55            
    35 : sub              i2, i26, 1         
    36 : unspill          i26, 52            
    37 : min              i25, i2, i26       
    38 : unspill          i26, 52            
    39 : sub              i1, i26, i2        
    40 : mov              i0, 0              
    41 : unspill          i26, 52            
    42 : cmp              i26, i2            
    43 : select_gt        i3, i1, i0         
    44 : jmp              5                  
    45 : __loops_label_4:                    
    46 : unspill          i26, 56            
    47 : sub              i0, i26, 1         
    48 : unspill          i26, 52            
    49 : sub              i1, i26, i0        
    50 : mov              i2, 0              
    51 : unspill          i26, 52            
    52 : cmp              i26, i0            
    53 : select_gt        i25, i1, i2        
    54 : unspill          i26, 52            
    55 : min              i3, i0, i26        
    56 : __loops_label_5:                    
    57 : __loops_label_6:                    
    58 : cmp              i25, 0             
    59 : jmp_gt           __loops_label_8    
    60 : unspill          i26, 55            
    61 : cmp              i25, i26           
    62 : jmp_ge           __loops_label_8    
    63 : cmp              i3, 0              
    64 : jmp_gt           __loops_label_8    
    65 : unspill          i26, 56            
    66 : cmp              i3, i26            
    67 : jmp_ge           __loops_label_8    
    68 : mov              i0, 47824          
    69 : arm_movk         i0, 1045, 16       
    70 : arm_movk         i0, 1, 32          
    71 : call_noret       [i0](i25, i3)      
    72 : unspill          i26, 55            
    73 : mul              i0, i3, i26        
    74 : add              i0, i0, i25        
    75 : unspill          i26, 57            
    76 : unspill          i27, 53            
    77 : store.u8         i26, i0, i27       
    78 : unspill          i26, 53            
    79 : add              i26, i26, 1        
    80 : spill            53, i26            
    81 : unspill          i26, 50            
    82 : add              i25, i25, i26      
    83 : unspill          i26, 51            
    84 : add              i3, i3, i26        
    85 : jmp              6                  
    86 : __loops_label_8:                    
    87 : unspill          i26, 50            
    88 : neg              i26, i26           
    89 : spill            50, i26            
    90 : unspill          i26, 51            
    91 : neg              i26, i26           
    92 : spill            51, i26            
    93 : unspill          i26, 52            
    94 : add              i26, i26, 1        
    95 : spill            52, i26            
    96 : jmp              0                  
    97 : __loops_label_2:                    
    98 : arm_ldp          i29, i30, i31, 496 
    99 : unspill          i25, 58            
   100 : unspill          i26, 59            
   101 : unspill          i27, 60            
   102 : add              i31, i31, 512      
   103 : ret                                 
