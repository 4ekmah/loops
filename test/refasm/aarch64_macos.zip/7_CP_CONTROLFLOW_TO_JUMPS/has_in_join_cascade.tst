has_in_join_cascade(i0, i1, i2)
     0 : sub               i31, i31, 128    
     1 : spill             13, i25          
     2 : spill             14, i26          
     3 : spill             15, i27          
     4 : spill             6, i0            
     5 : spill             5, i1            
     6 : spill             4, i2            
     7 : mov               i26, 0           
     8 : spill             0, i26           
     9 : unspill           i26, 6           
    10 : load.i64          i27, i26, 16     
    11 : spill             3, i27           
    12 : unspill           i26, 6           
    13 : load.i64          i27, i26, 0      
    14 : spill             2, i27           
    15 : unspill           i26, 6           
    16 : load.i64          i27, i26, 8      
    17 : spill             1, i27           
    18 : __loops_label_0:                   
    19 : unspill           i26, 3           
    20 : cmp               i26, 0           
    21 : jmp_le            __loops_label_2  
    22 : unspill           i26, 2           
    23 : load.i32          i27, i26         
    24 : spill             11, i27          
    25 : unspill           i26, 2           
    26 : add               i26, i26, 4      
    27 : spill             2, i26           
    28 : unspill           i26, 1           
    29 : load.i32          i27, i26         
    30 : spill             10, i27          
    31 : unspill           i26, 1           
    32 : add               i26, i26, 4      
    33 : spill             1, i26           
    34 : unspill           i26, 3           
    35 : sub               i26, i26, 1      
    36 : spill             3, i26           
    37 : unspill           i26, 6           
    38 : load.i64          i27, i26, 40     
    39 : spill             9, i27           
    40 : unspill           i26, 6           
    41 : load.i64          i27, i26, 24     
    42 : spill             8, i27           
    43 : unspill           i26, 6           
    44 : load.i64          i27, i26, 32     
    45 : spill             7, i27           
    46 : __loops_label_3:                   
    47 : unspill           i26, 9           
    48 : cmp               i26, 0           
    49 : jmp_le            __loops_label_5  
    50 : unspill           i26, 8           
    51 : load.i32          i0, i26          
    52 : unspill           i26, 8           
    53 : add               i26, i26, 4      
    54 : spill             8, i26           
    55 : unspill           i26, 7           
    56 : load.i32          i1, i26          
    57 : unspill           i26, 7           
    58 : add               i26, i26, 4      
    59 : spill             7, i26           
    60 : unspill           i26, 9           
    61 : sub               i26, i26, 1      
    62 : spill             9, i26           
    63 : unspill           i26, 11          
    64 : cmp               i1, i26          
    65 : jmp_le            __loops_label_7  
    66 : jmp               3                
    67 : __loops_label_7:                   
    68 : unspill           i26, 11          
    69 : cmp               i1, i26          
    70 : jmp_ne            __loops_label_10 
    71 : unspill           i26, 6           
    72 : load.i64          i1, i26, 64      
    73 : unspill           i26, 6           
    74 : load.i64          i2, i26, 48      
    75 : unspill           i26, 6           
    76 : load.i64          i27, i26, 56     
    77 : spill             12, i27          
    78 : __loops_label_11:                  
    79 : cmp               i1, 0            
    80 : jmp_le            __loops_label_13 
    81 : load.i32          i3, i2           
    82 : add               i2, i2, 4        
    83 : unspill           i26, 12          
    84 : load.i32          i25, i26         
    85 : unspill           i26, 12          
    86 : add               i26, i26, 4      
    87 : spill             12, i26          
    88 : sub               i1, i1, 1        
    89 : unspill           i26, 10          
    90 : cmp               i3, i26          
    91 : jmp_le            __loops_label_15 
    92 : jmp               11               
    93 : __loops_label_15:                  
    94 : unspill           i26, 10          
    95 : cmp               i3, i26          
    96 : jmp_ne            __loops_label_18 
    97 : unspill           i26, 5           
    98 : cmp               i0, i26          
    99 : jmp_ne            __loops_label_18 
   100 : unspill           i26, 4           
   101 : cmp               i25, i26         
   102 : jmp_ne            __loops_label_18 
   103 : mov               i26, 1           
   104 : spill             0, i26           
   105 : jmp               2                
   106 : __loops_label_16:                  
   107 : __loops_label_18:                  
   108 : jmp               11               
   109 : __loops_label_13:                  
   110 : __loops_label_8:                   
   111 : __loops_label_10:                  
   112 : jmp               3                
   113 : __loops_label_5:                   
   114 : jmp               0                
   115 : __loops_label_2:                   
   116 : unspill           i26, 0           
   117 : mov               i0, i26          
   118 : unspill           i25, 13          
   119 : unspill           i26, 14          
   120 : unspill           i27, 15          
   121 : add               i31, i31, 128    
   122 : ret                                
