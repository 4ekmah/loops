sort_double(i0, i1)
     0 : sub              i31, i31, 480      
     1 : spill            54, i25            
     2 : spill            55, i26            
     3 : spill            56, i27            
     4 : arm_stp          i31, 464, i29, i30 
     5 : mov              i29, i31           
     6 : spill            53, i0             
     7 : shl              i26, i1, 3         
     8 : spill            52, i26            
     9 : unspill          i26, 52            
    10 : sub              i27, i26, 8        
    11 : spill            51, i27            
    12 : mov              i26, 0             
    13 : spill            50, i26            
    14 : __loops_label_0:                    
    15 : unspill          i27, 51            
    16 : unspill          i26, 50            
    17 : cmp              i26, i27           
    18 : jmp_ge           __loops_label_2    
    19 : unspill          i26, 50            
    20 : mov              i25, i26           
    21 : add              i3, i25, 8         
    22 : __loops_label_3:                    
    23 : unspill          i26, 52            
    24 : cmp              i3, i26            
    25 : jmp_ge           __loops_label_5    
    26 : unspill          i26, 53            
    27 : load.fp64        i2, i26, i3        
    28 : unspill          i26, 53            
    29 : load.fp64        i1, i26, i25       
    30 : mov              i0, 35616          
    31 : arm_movk         i0, 248, 16        
    32 : arm_movk         i0, 1, 32          
    33 : call             [i0](i0, i2, i1)   
    34 : cmp              i0, 0              
    35 : jmp_eq           __loops_label_7    
    36 : mov              i25, i3            
    37 : __loops_label_7:                    
    38 : add              i3, i3, 8          
    39 : jmp              3                  
    40 : __loops_label_5:                    
    41 : unspill          i26, 50            
    42 : cmp              i25, i26           
    43 : jmp_eq           __loops_label_9    
    44 : unspill          i26, 53            
    45 : unspill          i27, 50            
    46 : load.fp64        i0, i26, i27       
    47 : unspill          i26, 53            
    48 : load.fp64        i1, i26, i25       
    49 : unspill          i26, 53            
    50 : store.fp64       i26, i25, i0       
    51 : unspill          i26, 53            
    52 : unspill          i27, 50            
    53 : store.fp64       i26, i27, i1       
    54 : __loops_label_9:                    
    55 : unspill          i26, 50            
    56 : add              i26, i26, 8        
    57 : spill            50, i26            
    58 : jmp              0                  
    59 : __loops_label_2:                    
    60 : arm_ldp          i29, i30, i31, 464 
    61 : unspill          i25, 54            
    62 : unspill          i26, 55            
    63 : unspill          i27, 56            
    64 : add              i31, i31, 480      
    65 : ret                                 
