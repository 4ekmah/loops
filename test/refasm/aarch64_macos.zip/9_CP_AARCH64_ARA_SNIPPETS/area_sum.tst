area_sum(i0, i1)
     0 : sub              i31, i31, 464      
     1 : spill            53, i25            
     2 : spill            54, i26            
     3 : arm_stp          i31, 448, i29, i30 
     4 : mov              i29, i31           
     5 : mov              i26, 0             
     6 : spill            50, i26            
     7 : __loops_label_0:                    
     8 : cmp              i1, 0              
     9 : jmp_le           __loops_label_2    
    10 : load.i8          i26, i0            
    11 : spill            51, i26            
    12 : mov              i25, 9208          
    13 : arm_movk         i25, 1089, 16      
    14 : arm_movk         i25, 1, 32         
    15 : mov              i2, 9360           
    16 : arm_movk         i2, 1089, 16       
    17 : arm_movk         i2, 1, 32          
    18 : mov              i3, 9476           
    19 : arm_movk         i3, 1089, 16       
    20 : arm_movk         i3, 1, 32          
    21 : unspill          i26, 51            
    22 : cmp              i26, 1             
    23 : select_eq        i2, i2, i3         
    24 : unspill          i26, 51            
    25 : cmp              i26, 0             
    26 : select_eq        i26, i25, i2       
    27 : spill            52, i26            
    28 : mov              i3, 9672           
    29 : arm_movk         i3, 1089, 16       
    30 : arm_movk         i3, 1, 32          
    31 : mov              i25, 9768          
    32 : arm_movk         i25, 1089, 16      
    33 : arm_movk         i25, 1, 32         
    34 : mov              i2, 9844           
    35 : arm_movk         i2, 1089, 16       
    36 : arm_movk         i2, 1, 32          
    37 : unspill          i26, 51            
    38 : cmp              i26, 1             
    39 : select_eq        i2, i25, i2        
    40 : unspill          i26, 51            
    41 : cmp              i26, 0             
    42 : select_eq        i2, i3, i2         
    43 : unspill          i26, 52            
    44 : arm_stp          i31, 0, i0, i1     
    45 : arm_stp          i31, 16, i2, i3    
    46 : arm_stp          i31, 32, i4, i5    
    47 : arm_stp          i31, 48, i6, i7    
    48 : arm_stp          i31, 64, i8, i9    
    49 : arm_stp          i31, 80, i10, i11  
    50 : arm_stp          i31, 96, i12, i13  
    51 : arm_stp          i31, 112, i14, i15 
    52 : arm_stp          i31, 128, i16, i17 
    53 : add              i10, i31, 144      
    54 : vst_lane.u64     i10, v0            
    55 : vst_lane.u64     i10, v4            
    56 : vst_lane.u64     i10, v8            
    57 : vst_lane.u64     i10, v12           
    58 : call_noret       [i26]()            
    59 : add              i10, i31, 144      
    60 : vld_lane.u64     v0, i10            
    61 : vld_lane.u64     v4, i10            
    62 : vld_lane.u64     v8, i10            
    63 : vld_lane.u64     v12, i10           
    64 : arm_ldp          i0, i1, i31, 0     
    65 : arm_ldp          i2, i3, i31, 16    
    66 : arm_ldp          i4, i5, i31, 32    
    67 : arm_ldp          i6, i7, i31, 48    
    68 : arm_ldp          i8, i9, i31, 64    
    69 : arm_ldp          i10, i11, i31, 80  
    70 : arm_ldp          i12, i13, i31, 96  
    71 : arm_ldp          i14, i15, i31, 112 
    72 : arm_ldp          i16, i17, i31, 128 
    73 : arm_stp          i31, 0, i0, i1     
    74 : arm_stp          i31, 16, i2, i3    
    75 : arm_stp          i31, 32, i4, i5    
    76 : arm_stp          i31, 48, i6, i7    
    77 : arm_stp          i31, 64, i8, i9    
    78 : arm_stp          i31, 80, i10, i11  
    79 : arm_stp          i31, 96, i12, i13  
    80 : arm_stp          i31, 112, i14, i15 
    81 : arm_stp          i31, 128, i16, i17 
    82 : add              i10, i31, 144      
    83 : vst_lane.u64     i10, v0            
    84 : vst_lane.u64     i10, v4            
    85 : vst_lane.u64     i10, v8            
    86 : vst_lane.u64     i10, v12           
    87 : call_noret       [i2]()             
    88 : add              i10, i31, 144      
    89 : vld_lane.u64     v0, i10            
    90 : vld_lane.u64     v4, i10            
    91 : vld_lane.u64     v8, i10            
    92 : vld_lane.u64     v12, i10           
    93 : mov              i2, i0             
    94 : arm_ldp          i0, i1, i31, 0     
    95 : unspill          i3, 3              
    96 : arm_ldp          i4, i5, i31, 32    
    97 : arm_ldp          i6, i7, i31, 48    
    98 : arm_ldp          i8, i9, i31, 64    
    99 : arm_ldp          i10, i11, i31, 80  
   100 : arm_ldp          i12, i13, i31, 96  
   101 : arm_ldp          i14, i15, i31, 112 
   102 : arm_ldp          i16, i17, i31, 128 
   103 : mov              i3, 9980           
   104 : arm_movk         i3, 1089, 16       
   105 : arm_movk         i3, 1, 32          
   106 : unspill          i26, 50            
   107 : arm_stp          i31, 0, i0, i1     
   108 : arm_stp          i31, 16, i2, i3    
   109 : arm_stp          i31, 32, i4, i5    
   110 : arm_stp          i31, 48, i6, i7    
   111 : arm_stp          i31, 64, i8, i9    
   112 : arm_stp          i31, 80, i10, i11  
   113 : arm_stp          i31, 96, i12, i13  
   114 : arm_stp          i31, 112, i14, i15 
   115 : arm_stp          i31, 128, i16, i17 
   116 : mov              i0, i26            
   117 : mov              i1, i2             
   118 : add              i10, i31, 144      
   119 : vst_lane.u64     i10, v0            
   120 : vst_lane.u64     i10, v4            
   121 : vst_lane.u64     i10, v8            
   122 : vst_lane.u64     i10, v12           
   123 : call_noret       [i3]()             
   124 : add              i10, i31, 144      
   125 : vld_lane.u64     v0, i10            
   126 : vld_lane.u64     v4, i10            
   127 : vld_lane.u64     v8, i10            
   128 : vld_lane.u64     v12, i10           
   129 : mov              i2, i0             
   130 : arm_ldp          i0, i1, i31, 0     
   131 : unspill          i3, 3              
   132 : arm_ldp          i4, i5, i31, 32    
   133 : arm_ldp          i6, i7, i31, 48    
   134 : arm_ldp          i8, i9, i31, 64    
   135 : arm_ldp          i10, i11, i31, 80  
   136 : arm_ldp          i12, i13, i31, 96  
   137 : arm_ldp          i14, i15, i31, 112 
   138 : arm_ldp          i16, i17, i31, 128 
   139 : mov              i26, i2            
   140 : spill            50, i26            
   141 : add              i0, i0, 56         
   142 : sub              i1, i1, 1          
   143 : jmp              0                  
   144 : __loops_label_2:                    
   145 : unspill          i26, 50            
   146 : mov              i0, i26            
   147 : arm_ldp          i29, i30, i31, 448 
   148 : unspill          i25, 53            
   149 : unspill          i26, 54            
   150 : add              i31, i31, 464      
   151 : ret                                 
