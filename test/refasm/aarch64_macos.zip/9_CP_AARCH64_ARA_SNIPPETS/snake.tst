snake(i0, i1, i2)
     0 : sub              i31, i31, 528      
     1 : spill            60, i25            
     2 : spill            61, i26            
     3 : spill            62, i27            
     4 : spill            63, i28            
     5 : spill            64, i29            
     6 : spill            65, i30            
     7 : mov              i29, i31           
     8 : add              i3, i1, i2         
     9 : sub              i26, i3, 1         
    10 : spill            54, i26            
    11 : mov              i3, 0              
    12 : mov              i26, 1             
    13 : spill            53, i26            
    14 : unspill          i26, 53            
    15 : neg              i27, i26           
    16 : spill            50, i27            
    17 : mov              i26, 0             
    18 : spill            55, i26            
    19 : __loops_label_0:                    
    20 : unspill          i27, 54            
    21 : unspill          i26, 55            
    22 : cmp              i26, i27           
    23 : jmp_ge           __loops_label_2    
    24 : mov              i26, 0             
    25 : spill            51, i26            
    26 : mov              i26, 0             
    27 : spill            52, i26            
    28 : unspill          i26, 55            
    29 : and              i25, i26, 1        
    30 : cmp              i25, 0             
    31 : jmp_eq           __loops_label_4    
    32 : sub              i25, i2, 1         
    33 : unspill          i26, 55            
    34 : cmp              i25, i26           
    35 : unspill          i26, 55            
    36 : select_gt        i27, i25, i26      
    37 : spill            51, i27            
    38 : unspill          i26, 55            
    39 : sub              i27, i26, i25      
    40 : spill            56, i27            
    41 : mov              i26, 0             
    42 : spill            57, i26            
    43 : unspill          i26, 55            
    44 : cmp              i26, i25           
    45 : unspill          i26, 56            
    46 : unspill          i27, 57            
    47 : select_gt        i28, i26, i27      
    48 : spill            52, i28            
    49 : jmp              5                  
    50 : __loops_label_4:                    
    51 : sub              i26, i1, 1         
    52 : spill            58, i26            
    53 : unspill          i26, 55            
    54 : unspill          i27, 58            
    55 : sub              i25, i26, i27      
    56 : mov              i26, 0             
    57 : spill            59, i26            
    58 : unspill          i26, 55            
    59 : unspill          i27, 58            
    60 : cmp              i26, i27           
    61 : unspill          i26, 59            
    62 : select_gt        i27, i25, i26      
    63 : spill            51, i27            
    64 : unspill          i27, 55            
    65 : unspill          i26, 58            
    66 : cmp              i26, i27           
    67 : unspill          i27, 55            
    68 : unspill          i26, 58            
    69 : select_gt        i28, i26, i27      
    70 : spill            52, i28            
    71 : __loops_label_5:                    
    72 : __loops_label_6:                    
    73 : unspill          i26, 51            
    74 : cmp              i26, 0             
    75 : jmp_gt           __loops_label_8    
    76 : unspill          i26, 51            
    77 : cmp              i26, i2            
    78 : jmp_ge           __loops_label_8    
    79 : unspill          i26, 52            
    80 : cmp              i26, 0             
    81 : jmp_gt           __loops_label_8    
    82 : unspill          i26, 52            
    83 : cmp              i26, i1            
    84 : jmp_ge           __loops_label_8    
    85 : mov              i25, 64784         
    86 : arm_movk         i25, 646, 16       
    87 : arm_movk         i25, 1, 32         
    88 : unspill          i26, 51            
    89 : unspill          i27, 52            
    90 : arm_stp          i31, 0, i0, i1     
    91 : arm_stp          i31, 16, i2, i3    
    92 : arm_stp          i31, 32, i4, i5    
    93 : arm_stp          i31, 48, i6, i7    
    94 : arm_stp          i31, 64, i8, i9    
    95 : arm_stp          i31, 80, i10, i11  
    96 : arm_stp          i31, 96, i12, i13  
    97 : arm_stp          i31, 112, i14, i15 
    98 : arm_stp          i31, 128, i16, i17 
    99 : mov              i0, i26            
   100 : mov              i1, i27            
   101 : add              i10, i31, 144      
   102 : vst_lane.u64     i10, v0            
   103 : vst_lane.u64     i10, v4            
   104 : vst_lane.u64     i10, v8            
   105 : vst_lane.u64     i10, v12           
   106 : call_noret       [i25]()            
   107 : add              i10, i31, 144      
   108 : vld_lane.u64     v0, i10            
   109 : vld_lane.u64     v4, i10            
   110 : vld_lane.u64     v8, i10            
   111 : vld_lane.u64     v12, i10           
   112 : arm_ldp          i0, i1, i31, 0     
   113 : arm_ldp          i2, i3, i31, 16    
   114 : arm_ldp          i4, i5, i31, 32    
   115 : arm_ldp          i6, i7, i31, 48    
   116 : arm_ldp          i8, i9, i31, 64    
   117 : arm_ldp          i10, i11, i31, 80  
   118 : arm_ldp          i12, i13, i31, 96  
   119 : arm_ldp          i14, i15, i31, 112 
   120 : arm_ldp          i16, i17, i31, 128 
   121 : unspill          i26, 52            
   122 : mul              i25, i26, i2       
   123 : unspill          i26, 51            
   124 : add              i25, i25, i26      
   125 : store.u8         i0, i25, i3        
   126 : add              i3, i3, 1          
   127 : unspill          i27, 53            
   128 : unspill          i26, 51            
   129 : add              i26, i26, i27      
   130 : spill            51, i26            
   131 : unspill          i27, 50            
   132 : unspill          i26, 52            
   133 : add              i26, i26, i27      
   134 : spill            52, i26            
   135 : jmp              6                  
   136 : __loops_label_8:                    
   137 : unspill          i26, 53            
   138 : neg              i26, i26           
   139 : spill            53, i26            
   140 : unspill          i26, 50            
   141 : neg              i26, i26           
   142 : spill            50, i26            
   143 : unspill          i26, 55            
   144 : add              i26, i26, 1        
   145 : spill            55, i26            
   146 : jmp              0                  
   147 : __loops_label_2:                    
   148 : unspill          i29, 64            
   149 : unspill          i30, 65            
   150 : unspill          i25, 60            
   151 : unspill          i26, 61            
   152 : unspill          i27, 62            
   153 : unspill          i28, 63            
   154 : add              i31, i31, 528      
   155 : ret                                 
