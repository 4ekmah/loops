bresenham(i0, i1, i2, i3, i4, i5, i6)
     0 : sub                    i31, i31, 80     
     1 : spill                  5, i25           
     2 : spill                  6, i26           
     3 : spill                  7, i27           
     4 : spill                  8, i28           
     5 : sub                    i25, i4, i2      
     6 : abs                    i26, i25         
     7 : spill                  0, i26           
     8 : sub                    i25, i4, i2      
     9 : sign                   i26, i25         
    10 : spill                  1, i26           
    11 : sub                    i25, i5, i3      
    12 : abs                    i25, i25         
    13 : neg                    i26, i25         
    14 : spill                  2, i26           
    15 : sub                    i25, i5, i3      
    16 : sign                   i26, i25         
    17 : spill                  4, i26           
    18 : unspill                i26, 0           
    19 : unspill                i27, 2           
    20 : add                    i28, i26, i27    
    21 : spill                  3, i28           
    22 : annotation:whilecstart 0                
    23 : cmp                    i0, 0            
    24 : jmp_eq                 __loops_label_2  
    25 : annotation:whilecend                    
    26 : mul                    i25, i3, i1      
    27 : add                    i25, i25, i2     
    28 : store.u8               i0, i25, i6      
    29 : annotation:ifcstart                     
    30 : cmp                    i2, i4           
    31 : jmp_ne                 __loops_label_4  
    32 : cmp                    i3, i5           
    33 : jmp_ne                 __loops_label_4  
    34 : annotation:ifcend                       
    35 : annotation:break       2                
    36 : annotation:endif       4                
    37 : unspill                i26, 3           
    38 : shl                    i25, i26, 1      
    39 : annotation:ifcstart                     
    40 : unspill                i26, 2           
    41 : cmp                    i25, i26         
    42 : jmp_gt                 __loops_label_6  
    43 : annotation:ifcend                       
    44 : annotation:ifcstart                     
    45 : cmp                    i2, i4           
    46 : jmp_ne                 __loops_label_8  
    47 : annotation:ifcend                       
    48 : annotation:break       2                
    49 : annotation:endif       8                
    50 : unspill                i27, 2           
    51 : unspill                i26, 3           
    52 : add                    i26, i26, i27    
    53 : spill                  3, i26           
    54 : unspill                i26, 1           
    55 : add                    i2, i2, i26      
    56 : annotation:endif       6                
    57 : annotation:ifcstart                     
    58 : unspill                i26, 0           
    59 : cmp                    i25, i26         
    60 : jmp_gt                 __loops_label_10 
    61 : annotation:ifcend                       
    62 : annotation:ifcstart                     
    63 : cmp                    i3, i5           
    64 : jmp_ne                 __loops_label_12 
    65 : annotation:ifcend                       
    66 : annotation:break       2                
    67 : annotation:endif       12               
    68 : unspill                i27, 0           
    69 : unspill                i26, 3           
    70 : add                    i26, i26, i27    
    71 : spill                  3, i26           
    72 : unspill                i26, 4           
    73 : add                    i3, i3, i26      
    74 : annotation:endif       10               
    75 : annotation:endwhile    0, 2             
    76 : ret                                     
    77 : unspill                i25, 5           
    78 : unspill                i26, 6           
    79 : unspill                i27, 7           
    80 : unspill                i28, 8           
    81 : add                    i31, i31, 80     
