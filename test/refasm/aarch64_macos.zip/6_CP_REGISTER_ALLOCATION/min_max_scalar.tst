min_max_scalar(i0, i1, i2, i3)
     0 : sub                    i31, i31, 64    
     1 : spill                  1, i2           
     2 : spill                  0, i3           
     3 : spill                  5, i25          
     4 : spill                  6, i26          
     5 : mov                    i25, 0          
     6 : mov                    i26, 0          
     7 : spill                  3, i26          
     8 : mov                    i26, 0          
     9 : spill                  2, i26          
    10 : load.i32               i2, i0          
    11 : mov                    i26, i2         
    12 : spill                  4, i26          
    13 : mov                    i3, 4           
    14 : mul                    i1, i1, i3      
    15 : annotation:whilecstart 0               
    16 : cmp                    i25, i1         
    17 : jmp_ge                 __loops_label_2 
    18 : annotation:whilecend                   
    19 : load.i32               i3, i0, i25     
    20 : annotation:ifcstart                    
    21 : cmp                    i3, i2          
    22 : jmp_ge                 __loops_label_4 
    23 : annotation:ifcend                      
    24 : mov                    i2, i3          
    25 : mov                    i26, i25        
    26 : spill                  3, i26          
    27 : annotation:endif       4               
    28 : annotation:ifcstart                    
    29 : unspill                i26, 4          
    30 : cmp                    i3, i26         
    31 : jmp_le                 __loops_label_6 
    32 : annotation:ifcend                      
    33 : mov                    i26, i3         
    34 : spill                  4, i26          
    35 : mov                    i26, i25        
    36 : spill                  2, i26          
    37 : annotation:endif       6               
    38 : add                    i25, i25, 4     
    39 : annotation:endwhile    0, 2            
    40 : mov                    i0, 4           
    41 : unspill                i26, 3          
    42 : div                    i1, i26, i0     
    43 : unspill                i26, 2          
    44 : div                    i0, i26, i0     
    45 : unspill                i26, 1          
    46 : store.i32              i26, i1         
    47 : unspill                i26, 0          
    48 : store.i32              i26, i0         
    49 : mov                    i0, 0           
    50 : ret                                    
    51 : unspill                i25, 5          
    52 : unspill                i26, 6          
    53 : add                    i31, i31, 64    
