nullify_msb_lsb_v(i0, i1, i2, i3)
     0 : sub                    i31, i31, 32    
     1 : spill                  1, i25          
     2 : spill                  2, i26          
     3 : mov                    i26, 0          
     4 : spill                  0, i26          
     5 : mov                    i25, 4          
     6 : mul                    i3, i3, i25     
     7 : mov                    v0, 1           
     8 : annotation:whilecstart 0               
     9 : unspill                i26, 0          
    10 : cmp                    i26, i3         
    11 : jmp_ge                 __loops_label_2 
    12 : annotation:whilecend                   
    13 : unspill                i26, 0          
    14 : vld.u32                v1, i0, i26     
    15 : shr.u32                v2, v1, 1       
    16 : or                     v2, v1, v2      
    17 : shr.u32                v3, v2, 2       
    18 : or                     v2, v2, v3      
    19 : shr.u32                v3, v2, 4       
    20 : or                     v2, v2, v3      
    21 : shr.u32                v3, v2, 8       
    22 : or                     v2, v2, v3      
    23 : shr.u32                v3, v2, 16      
    24 : or                     v2, v2, v3      
    25 : add.u32                v2, v2, v0      
    26 : shr.u32                v2, v2, 1       
    27 : xor                    v2, v2, v1      
    28 : unspill                i26, 0          
    29 : vst.u32                i1, i26, v2     
    30 : sub.u32                v2, v1, v0      
    31 : not                    v2, v2          
    32 : and                    v2, v1, v2      
    33 : xor                    v1, v2, v1      
    34 : unspill                i26, 0          
    35 : vst.u32                i2, i26, v1     
    36 : unspill                i26, 0          
    37 : add                    i26, i26, 16    
    38 : spill                  0, i26          
    39 : annotation:endwhile    0, 2            
    40 : ret                                    
    41 : unspill                i25, 1          
    42 : unspill                i26, 2          
    43 : add                    i31, i31, 32    
