fixed_power_0(i0)
     0 : mov i0, 1  
     1 : mov i0, i0 
     2 : ret        
