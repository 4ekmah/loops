has_in_join_cascade(i0, i1, i2)
     0 : sub                    i31, i31, 128    
     1 : spill                  6, i0            
     2 : spill                  5, i1            
     3 : spill                  4, i2            
     4 : spill                  13, i25          
     5 : spill                  14, i26          
     6 : spill                  15, i27          
     7 : mov                    i26, 0           
     8 : spill                  0, i26           
     9 : unspill                i26, 6           
    10 : load.i64               i27, i26, 16     
    11 : spill                  3, i27           
    12 : unspill                i26, 6           
    13 : load.i64               i27, i26, 0      
    14 : spill                  2, i27           
    15 : unspill                i26, 6           
    16 : load.i64               i27, i26, 8      
    17 : spill                  1, i27           
    18 : annotation:whilecstart 0                
    19 : unspill                i26, 3           
    20 : cmp                    i26, 0           
    21 : jmp_le                 __loops_label_2  
    22 : annotation:whilecend                    
    23 : unspill                i26, 2           
    24 : load.i32               i27, i26         
    25 : spill                  11, i27          
    26 : unspill                i26, 2           
    27 : add                    i26, i26, 4      
    28 : spill                  2, i26           
    29 : unspill                i26, 1           
    30 : load.i32               i27, i26         
    31 : spill                  10, i27          
    32 : unspill                i26, 1           
    33 : add                    i26, i26, 4      
    34 : spill                  1, i26           
    35 : unspill                i26, 3           
    36 : sub                    i26, i26, 1      
    37 : spill                  3, i26           
    38 : unspill                i26, 6           
    39 : load.i64               i27, i26, 40     
    40 : spill                  9, i27           
    41 : unspill                i26, 6           
    42 : load.i64               i27, i26, 24     
    43 : spill                  8, i27           
    44 : unspill                i26, 6           
    45 : load.i64               i27, i26, 32     
    46 : spill                  7, i27           
    47 : annotation:whilecstart 3                
    48 : unspill                i26, 9           
    49 : cmp                    i26, 0           
    50 : jmp_le                 __loops_label_5  
    51 : annotation:whilecend                    
    52 : unspill                i26, 8           
    53 : load.i32               i0, i26          
    54 : unspill                i26, 8           
    55 : add                    i26, i26, 4      
    56 : spill                  8, i26           
    57 : unspill                i26, 7           
    58 : load.i32               i1, i26          
    59 : unspill                i26, 7           
    60 : add                    i26, i26, 4      
    61 : spill                  7, i26           
    62 : unspill                i26, 9           
    63 : sub                    i26, i26, 1      
    64 : spill                  9, i26           
    65 : annotation:ifcstart                     
    66 : unspill                i26, 11          
    67 : cmp                    i1, i26          
    68 : jmp_le                 __loops_label_7  
    69 : annotation:ifcend                       
    70 : annotation:break       3                
    71 : annotation:else        7, 8             
    72 : annotation:ifcstart                     
    73 : unspill                i26, 11          
    74 : cmp                    i1, i26          
    75 : jmp_ne                 __loops_label_10 
    76 : annotation:ifcend                       
    77 : unspill                i26, 6           
    78 : load.i64               i1, i26, 64      
    79 : unspill                i26, 6           
    80 : load.i64               i2, i26, 48      
    81 : unspill                i26, 6           
    82 : load.i64               i27, i26, 56     
    83 : spill                  12, i27          
    84 : annotation:whilecstart 11               
    85 : cmp                    i1, 0            
    86 : jmp_le                 __loops_label_13 
    87 : annotation:whilecend                    
    88 : load.i32               i3, i2           
    89 : add                    i2, i2, 4        
    90 : unspill                i26, 12          
    91 : load.i32               i25, i26         
    92 : unspill                i26, 12          
    93 : add                    i26, i26, 4      
    94 : spill                  12, i26          
    95 : sub                    i1, i1, 1        
    96 : annotation:ifcstart                     
    97 : unspill                i26, 10          
    98 : cmp                    i3, i26          
    99 : jmp_le                 __loops_label_15 
   100 : annotation:ifcend                       
   101 : annotation:break       11               
   102 : annotation:else        15, 16           
   103 : annotation:ifcstart                     
   104 : unspill                i26, 10          
   105 : cmp                    i3, i26          
   106 : jmp_ne                 __loops_label_18 
   107 : unspill                i26, 5           
   108 : cmp                    i0, i26          
   109 : jmp_ne                 __loops_label_18 
   110 : unspill                i26, 4           
   111 : cmp                    i25, i26         
   112 : jmp_ne                 __loops_label_18 
   113 : annotation:ifcend                       
   114 : mov                    i26, 1           
   115 : spill                  0, i26           
   116 : annotation:break       2                
   117 : annotation:endif       16               
   118 : annotation:endif       18               
   119 : annotation:endwhile    11, 13           
   120 : annotation:endif       8                
   121 : annotation:endif       10               
   122 : annotation:endwhile    3, 5             
   123 : annotation:endwhile    0, 2             
   124 : unspill                i26, 0           
   125 : mov                    i0, i26          
   126 : ret                                     
   127 : unspill                i25, 13          
   128 : unspill                i26, 14          
   129 : unspill                i27, 15          
   130 : add                    i31, i31, 128    
