fixed_power_v_int32_t_0(i0, i1, i2)
     0 : sub                    i31, i31, 16    
     1 : spill                  0, i25          
     2 : mov                    i3, 0           
     3 : mov                    i25, 4          
     4 : mul                    i2, i2, i25     
     5 : annotation:whilecstart 0               
     6 : cmp                    i3, i2          
     7 : jmp_ge                 __loops_label_2 
     8 : annotation:whilecend                   
     9 : vld.i32                v0, i0, i3      
    10 : mov                    v0, 1           
    11 : vst.i32                i1, i3, v0      
    12 : add                    i3, i3, 16      
    13 : annotation:endwhile    0, 2            
    14 : mov                    i0, 0           
    15 : ret                                    
    16 : unspill                i25, 0          
    17 : add                    i31, i31, 16    
