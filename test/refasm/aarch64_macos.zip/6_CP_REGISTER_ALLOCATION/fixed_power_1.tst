fixed_power_1(i0)
     0 : mov i0, i0 
     1 : ret        
