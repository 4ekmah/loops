fixed_power_v_uint32_t_4(i0, i1, i2)
     0 : sub                    i31, i31, 16    
     1 : spill                  0, i25          
     2 : mov                    i3, 0           
     3 : mov                    i25, 4          
     4 : mul                    i2, i2, i25     
     5 : annotation:whilecstart 0               
     6 : cmp                    i3, i2          
     7 : jmp_ge                 __loops_label_2 
     8 : annotation:whilecend                   
     9 : vld.u32                v0, i0, i3      
    10 : mul.u32                v0, v0, v0      
    11 : mul.u32                v0, v0, v0      
    12 : vst.u32                i1, i3, v0      
    13 : add                    i3, i3, 16      
    14 : annotation:endwhile    0, 2            
    15 : mov                    i0, 0           
    16 : ret                                    
    17 : unspill                i25, 0          
    18 : add                    i31, i31, 16    
