snake(i0, i1, i2)
     0 : sub                    i31, i31, 512      
     1 : spill                  58, i25            
     2 : spill                  59, i26            
     3 : spill                  60, i27            
     4 : arm_stp                i31, 496, i29, i30 
     5 : mov                    i29, i31           
     6 : spill                  57, i0             
     7 : spill                  56, i1             
     8 : spill                  55, i2             
     9 : unspill                i26, 56            
    10 : unspill                i27, 55            
    11 : add                    i3, i26, i27       
    12 : sub                    i26, i3, 1         
    13 : spill                  54, i26            
    14 : mov                    i26, 0             
    15 : spill                  53, i26            
    16 : mov                    i26, 1             
    17 : spill                  50, i26            
    18 : unspill                i26, 50            
    19 : neg                    i27, i26           
    20 : spill                  51, i27            
    21 : mov                    i26, 0             
    22 : spill                  52, i26            
    23 : annotation:whilecstart 0                  
    24 : unspill                i27, 54            
    25 : unspill                i26, 52            
    26 : cmp                    i26, i27           
    27 : jmp_ge                 __loops_label_2    
    28 : annotation:whilecend                      
    29 : mov                    i25, 0             
    30 : mov                    i3, 0              
    31 : annotation:ifcstart                       
    32 : unspill                i26, 52            
    33 : and                    i2, i26, 1         
    34 : cmp                    i2, 0              
    35 : jmp_eq                 __loops_label_4    
    36 : annotation:ifcend                         
    37 : unspill                i26, 55            
    38 : sub                    i2, i26, 1         
    39 : unspill                i26, 52            
    40 : min                    i25, i2, i26       
    41 : unspill                i26, 52            
    42 : sub                    i1, i26, i2        
    43 : mov                    i0, 0              
    44 : unspill                i26, 52            
    45 : cmp                    i26, i2            
    46 : select_gt              i3, i1, i0         
    47 : annotation:else        4, 5               
    48 : unspill                i26, 56            
    49 : sub                    i0, i26, 1         
    50 : unspill                i26, 52            
    51 : sub                    i1, i26, i0        
    52 : mov                    i2, 0              
    53 : unspill                i26, 52            
    54 : cmp                    i26, i0            
    55 : select_gt              i25, i1, i2        
    56 : unspill                i26, 52            
    57 : min                    i3, i0, i26        
    58 : annotation:endif       5                  
    59 : annotation:whilecstart 6                  
    60 : cmp                    i25, 0             
    61 : jmp_gt                 __loops_label_8    
    62 : unspill                i26, 55            
    63 : cmp                    i25, i26           
    64 : jmp_ge                 __loops_label_8    
    65 : cmp                    i3, 0              
    66 : jmp_gt                 __loops_label_8    
    67 : unspill                i26, 56            
    68 : cmp                    i3, i26            
    69 : jmp_ge                 __loops_label_8    
    70 : annotation:whilecend                      
    71 : mov                    i0, 25616          
    72 : arm_movk               i0, 248, 16        
    73 : arm_movk               i0, 1, 32          
    74 : call_noret             [i0](i25, i3)      
    75 : unspill                i26, 55            
    76 : mul                    i0, i3, i26        
    77 : add                    i0, i0, i25        
    78 : unspill                i26, 57            
    79 : unspill                i27, 53            
    80 : store.u8               i26, i0, i27       
    81 : unspill                i26, 53            
    82 : add                    i26, i26, 1        
    83 : spill                  53, i26            
    84 : unspill                i26, 50            
    85 : add                    i25, i25, i26      
    86 : unspill                i26, 51            
    87 : add                    i3, i3, i26        
    88 : annotation:endwhile    6, 8               
    89 : unspill                i26, 50            
    90 : neg                    i26, i26           
    91 : spill                  50, i26            
    92 : unspill                i26, 51            
    93 : neg                    i26, i26           
    94 : spill                  51, i26            
    95 : unspill                i26, 52            
    96 : add                    i26, i26, 1        
    97 : spill                  52, i26            
    98 : annotation:endwhile    0, 2               
    99 : ret                                       
   100 : arm_ldp                i29, i30, i31, 496 
   101 : unspill                i25, 58            
   102 : unspill                i26, 59            
   103 : unspill                i27, 60            
   104 : add                    i31, i31, 512      
