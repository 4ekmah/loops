conditionpainter(i0)
     0 : sub                    i31, i31, 64    
     1 : spill                  5, i25          
     2 : spill                  6, i26          
     3 : spill                  1, i0           
     4 : mov                    i26, -5         
     5 : spill                  0, i26          
     6 : annotation:whilecstart 0               
     7 : unspill                i26, 0          
     8 : cmp                    i26, 5          
     9 : jmp_gt                 __loops_label_2 
    10 : annotation:whilecend                   
    11 : unspill                i26, 0          
    12 : add                    i2, i26, 5      
    13 : mov                    i3, 11          
    14 : mul                    i2, i2, i3      
    15 : mov                    i3, 8           
    16 : mul                    i26, i2, i3     
    17 : spill                  3, i26          
    18 : mov                    i26, -5         
    19 : spill                  2, i26          
    20 : annotation:whilecstart 3               
    21 : unspill                i26, 2          
    22 : cmp                    i26, 5          
    23 : jmp_gt                 __loops_label_5 
    24 : annotation:whilecend                   
    25 : unspill                i26, 2          
    26 : add                    i25, i26, 3     
    27 : unspill                i26, 0          
    28 : cmp                    i26, i25        
    29 : iverson_ge             i25             
    30 : unspill                i26, 0          
    31 : cmp                    i26, 4          
    32 : iverson_le             i1              
    33 : and                    i1, i25, i1     
    34 : mov                    i25, -2         
    35 : unspill                i26, 2          
    36 : cmp                    i26, i25        
    37 : iverson_ge             i25             
    38 : and                    i1, i1, i25     
    39 : unspill                i26, 2          
    40 : cmp                    i26, 0          
    41 : iverson_le             i25             
    42 : and                    i1, i1, i25     
    43 : unspill                i26, 2          
    44 : sub                    i25, i26, 1     
    45 : unspill                i26, 0          
    46 : cmp                    i26, i25        
    47 : iverson_le             i25             
    48 : unspill                i26, 2          
    49 : cmp                    i26, 0          
    50 : iverson_ge             i0              
    51 : and                    i0, i25, i0     
    52 : unspill                i26, 0          
    53 : cmp                    i26, 0          
    54 : iverson_le             i25             
    55 : and                    i0, i0, i25     
    56 : unspill                i26, 2          
    57 : mul                    i25, i26, i26   
    58 : unspill                i26, 0          
    59 : mul                    i3, i26, i26    
    60 : add                    i3, i25, i3     
    61 : cmp                    i3, 9           
    62 : iverson_le             i3              
    63 : and                    i0, i0, i3      
    64 : or                     i26, i1, i0     
    65 : spill                  4, i26          
    66 : mov                    i1, 2           
    67 : mov                    i3, 0           
    68 : unspill                i26, 2          
    69 : cmp                    i26, 2          
    70 : iverson_ge             i25             
    71 : unspill                i26, 2          
    72 : cmp                    i26, 4          
    73 : iverson_le             i2              
    74 : and                    i2, i25, i2     
    75 : unspill                i26, 0          
    76 : cmp                    i26, 1          
    77 : iverson_ge             i25             
    78 : unspill                i26, 0          
    79 : cmp                    i26, 3          
    80 : iverson_le             i0              
    81 : and                    i0, i25, i0     
    82 : or                     i0, i2, i0      
    83 : unspill                i26, 2          
    84 : mul                    i2, i26, i26    
    85 : unspill                i26, 0          
    86 : mul                    i25, i26, i26   
    87 : add                    i2, i2, i25     
    88 : cmp                    i2, 16          
    89 : iverson_le             i2              
    90 : and                    i0, i0, i2      
    91 : cmp                    i0, 0           
    92 : select_ne              i0, i1, i3      
    93 : unspill                i26, 4          
    94 : add                    i0, i26, i0     
    95 : annotation:ifcstart                    
    96 : mov                    i1, 2           
    97 : unspill                i26, 0          
    98 : mul                    i1, i26, i1     
    99 : unspill                i26, 2          
   100 : cmp                    i1, i26         
   101 : jmp_gt                 __loops_label_8 
   102 : unspill                i26, 2          
   103 : add                    i1, i26, 3      
   104 : neg                    i1, i1          
   105 : unspill                i26, 2          
   106 : add                    i2, i26, 3      
   107 : mul                    i1, i1, i2      
   108 : unspill                i26, 0          
   109 : cmp                    i26, i1         
   110 : jmp_le                 __loops_label_9 
   111 : __loops_label_8:                       
   112 : mov                    i1, 2           
   113 : unspill                i26, 2          
   114 : mul                    i1, i26, i1     
   115 : unspill                i26, 0          
   116 : cmp                    i26, i1         
   117 : jmp_gt                 __loops_label_7 
   118 : unspill                i26, 2          
   119 : add                    i1, i26, 3      
   120 : neg                    i1, i1          
   121 : unspill                i26, 2          
   122 : add                    i2, i26, 3      
   123 : mul                    i1, i1, i2      
   124 : unspill                i26, 0          
   125 : cmp                    i26, i1         
   126 : jmp_gt                 __loops_label_7 
   127 : __loops_label_9:                       
   128 : unspill                i26, 2          
   129 : cmp                    i26, 0          
   130 : jmp_gt                 __loops_label_7 
   131 : annotation:ifcend                      
   132 : add                    i0, i0, 3       
   133 : annotation:endif       7               
   134 : unspill                i26, 2          
   135 : add                    i1, i26, 5      
   136 : shl                    i1, i1, 3       
   137 : unspill                i26, 3          
   138 : add                    i1, i26, i1     
   139 : unspill                i26, 1          
   140 : store.i64              i26, i1, i0     
   141 : unspill                i26, 2          
   142 : add                    i26, i26, 1     
   143 : spill                  2, i26          
   144 : annotation:endwhile    3, 5            
   145 : unspill                i26, 0          
   146 : add                    i26, i26, 1     
   147 : spill                  0, i26          
   148 : annotation:endwhile    0, 2            
   149 : ret                                    
   150 : unspill                i25, 5          
   151 : unspill                i26, 6          
   152 : add                    i31, i31, 64    
