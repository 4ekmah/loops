exp_f32(i0, i1, i2)
     0 : sub                    i31, i31, 48       
     1 : spill                  2, v16             
     2 : spill                  4, v17             
     3 : mov                    i3, 49317          
     4 : arm_movk               i3, 49840, 16      
     5 : broadcast.fp32         v0, i3             
     6 : mov                    i3, 49317          
     7 : arm_movk               i3, 17072, 16      
     8 : broadcast.fp32         v1, i3             
     9 : mov                    i3, 0              
    10 : arm_movk               i3, 16128, 16      
    11 : broadcast.fp32         v2, i3             
    12 : mov                    i3, 0              
    13 : arm_movk               i3, 16256, 16      
    14 : broadcast.fp32         v3, i3             
    15 : mov                    i3, 43579          
    16 : arm_movk               i3, 16312, 16      
    17 : broadcast.fp32         v4, i3             
    18 : mov                    i3, 32768          
    19 : arm_movk               i3, 48945, 16      
    20 : broadcast.fp32         v5, i3             
    21 : mov                    i3, 32899          
    22 : arm_movk               i3, 14686, 16      
    23 : broadcast.fp32         v6, i3             
    24 : mov                    i3, 26983          
    25 : arm_movk               i3, 14672, 16      
    26 : broadcast.fp32         v7, i3             
    27 : mov                    i3, 17358          
    28 : arm_movk               i3, 15031, 16      
    29 : broadcast.fp32         v8, i3             
    30 : mov                    i3, 35080          
    31 : arm_movk               i3, 15368, 16      
    32 : broadcast.fp32         v9, i3             
    33 : mov                    i3, 43457          
    34 : arm_movk               i3, 15658, 16      
    35 : broadcast.fp32         v10, i3            
    36 : mov                    i3, 43690          
    37 : arm_movk               i3, 15914, 16      
    38 : broadcast.fp32         v11, i3            
    39 : mov                    i3, 0              
    40 : arm_movk               i3, 16128, 16      
    41 : broadcast.fp32         v12, i3            
    42 : mov                    v13, 127           
    43 : mov                    i3, 0              
    44 : annotation:whilecstart 0                  
    45 : cmp                    i2, 0              
    46 : jmp_le                 __loops_label_2    
    47 : annotation:whilecend                      
    48 : vld.fp32               v14, i1, i3        
    49 : min.fp32               v14, v14, v1       
    50 : max.fp32               v14, v14, v0       
    51 : fma.fp32               v15, v2, v14, v4   
    52 : floor.fp32_i32         v15, v15           
    53 : cast.i32_fp32          v16, v15           
    54 : fma.fp32               v14, v14, v16, v5  
    55 : fma.fp32               v14, v14, v16, v6  
    56 : fma.fp32               v16, v8, v14, v7   
    57 : fma.fp32               v16, v9, v16, v14  
    58 : fma.fp32               v16, v10, v16, v14 
    59 : fma.fp32               v16, v11, v16, v14 
    60 : fma.fp32               v16, v12, v16, v14 
    61 : mul.fp32               v17, v14, v14      
    62 : fma.fp32               v14, v14, v16, v17 
    63 : add.fp32               v14, v14, v3       
    64 : add.i32                v15, v15, v13      
    65 : sal.i32                v15, v15, 23       
    66 : mul.fp32               v14, v14, v15      
    67 : vst.fp32               i0, i3, v14        
    68 : add                    i3, i3, 16         
    69 : sub                    i2, i2, 4          
    70 : annotation:endwhile    0, 2               
    71 : ret                                       
    72 : unspill                v16, 2             
    73 : unspill                v17, 4             
    74 : add                    i31, i31, 48       
