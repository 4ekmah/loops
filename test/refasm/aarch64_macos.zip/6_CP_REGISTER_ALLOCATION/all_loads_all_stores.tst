all_loads_all_stores(i0, i1, i2, i3, i4)
     0 : sub                    i31, i31, 64     
     1 : spill                  5, i25           
     2 : spill                  6, i26           
     3 : spill                  7, i27           
     4 : spill                  3, i4            
     5 : mov                    i26, 0           
     6 : spill                  2, i26           
     7 : mov                    i26, 0           
     8 : spill                  0, i26           
     9 : mov                    i26, 0           
    10 : spill                  1, i26           
    11 : mov                    i25, 2           
    12 : mov                    i4, 1            
    13 : cmp                    i1, 1            
    14 : select_gt              i4, i25, i4      
    15 : mov                    i25, 4           
    16 : cmp                    i1, 3            
    17 : select_gt              i4, i25, i4      
    18 : mov                    i25, 8           
    19 : cmp                    i1, 5            
    20 : select_gt              i26, i25, i4     
    21 : spill                  4, i26           
    22 : mov                    i25, 2           
    23 : mov                    i4, 1            
    24 : cmp                    i3, 1            
    25 : select_gt              i4, i25, i4      
    26 : mov                    i25, 4           
    27 : cmp                    i3, 3            
    28 : select_gt              i4, i25, i4      
    29 : mov                    i25, 8           
    30 : cmp                    i3, 5            
    31 : select_gt              i4, i25, i4      
    32 : annotation:whilecstart 0                
    33 : unspill                i27, 3           
    34 : unspill                i26, 2           
    35 : cmp                    i26, i27         
    36 : jmp_ge                 __loops_label_2  
    37 : annotation:whilecend                    
    38 : def                    i25              
    39 : annotation:ifcstart                     
    40 : cmp                    i1, 0            
    41 : jmp_ne                 __loops_label_4  
    42 : annotation:ifcend                       
    43 : unspill                i26, 0           
    44 : load.u8                i25, i0, i26     
    45 : annotation:else        4, 5             
    46 : annotation:ifcstart                     
    47 : cmp                    i1, 1            
    48 : jmp_ne                 __loops_label_7  
    49 : annotation:ifcend                       
    50 : unspill                i26, 0           
    51 : load.i8                i25, i0, i26     
    52 : annotation:else        7, 8             
    53 : annotation:ifcstart                     
    54 : cmp                    i1, 2            
    55 : jmp_ne                 __loops_label_10 
    56 : annotation:ifcend                       
    57 : unspill                i26, 0           
    58 : load.u16               i25, i0, i26     
    59 : annotation:else        10, 11           
    60 : annotation:ifcstart                     
    61 : cmp                    i1, 3            
    62 : jmp_ne                 __loops_label_13 
    63 : annotation:ifcend                       
    64 : unspill                i26, 0           
    65 : load.i16               i25, i0, i26     
    66 : annotation:else        13, 14           
    67 : annotation:ifcstart                     
    68 : cmp                    i1, 4            
    69 : jmp_ne                 __loops_label_16 
    70 : annotation:ifcend                       
    71 : unspill                i26, 0           
    72 : load.u32               i25, i0, i26     
    73 : annotation:else        16, 17           
    74 : annotation:ifcstart                     
    75 : cmp                    i1, 5            
    76 : jmp_ne                 __loops_label_19 
    77 : annotation:ifcend                       
    78 : unspill                i26, 0           
    79 : load.i32               i25, i0, i26     
    80 : annotation:else        19, 20           
    81 : annotation:ifcstart                     
    82 : cmp                    i1, 6            
    83 : jmp_ne                 __loops_label_22 
    84 : annotation:ifcend                       
    85 : unspill                i26, 0           
    86 : load.u64               i25, i0, i26     
    87 : annotation:else        22, 23           
    88 : unspill                i26, 0           
    89 : load.i64               i25, i0, i26     
    90 : annotation:endif       5                
    91 : annotation:endif       8                
    92 : annotation:endif       11               
    93 : annotation:endif       14               
    94 : annotation:endif       17               
    95 : annotation:endif       20               
    96 : annotation:endif       23               
    97 : annotation:ifcstart                     
    98 : cmp                    i3, 0            
    99 : jmp_ne                 __loops_label_25 
   100 : annotation:ifcend                       
   101 : unspill                i26, 1           
   102 : store.u8               i2, i26, i25     
   103 : annotation:else        25, 26           
   104 : annotation:ifcstart                     
   105 : cmp                    i3, 1            
   106 : jmp_ne                 __loops_label_28 
   107 : annotation:ifcend                       
   108 : unspill                i26, 1           
   109 : store.i8               i2, i26, i25     
   110 : annotation:else        28, 29           
   111 : annotation:ifcstart                     
   112 : cmp                    i3, 2            
   113 : jmp_ne                 __loops_label_31 
   114 : annotation:ifcend                       
   115 : unspill                i26, 1           
   116 : store.u16              i2, i26, i25     
   117 : annotation:else        31, 32           
   118 : annotation:ifcstart                     
   119 : cmp                    i3, 3            
   120 : jmp_ne                 __loops_label_34 
   121 : annotation:ifcend                       
   122 : unspill                i26, 1           
   123 : store.i16              i2, i26, i25     
   124 : annotation:else        34, 35           
   125 : annotation:ifcstart                     
   126 : cmp                    i3, 4            
   127 : jmp_ne                 __loops_label_37 
   128 : annotation:ifcend                       
   129 : unspill                i26, 1           
   130 : store.u32              i2, i26, i25     
   131 : annotation:else        37, 38           
   132 : annotation:ifcstart                     
   133 : cmp                    i3, 5            
   134 : jmp_ne                 __loops_label_40 
   135 : annotation:ifcend                       
   136 : unspill                i26, 1           
   137 : store.i32              i2, i26, i25     
   138 : annotation:else        40, 41           
   139 : annotation:ifcstart                     
   140 : cmp                    i3, 6            
   141 : jmp_ne                 __loops_label_43 
   142 : annotation:ifcend                       
   143 : unspill                i26, 1           
   144 : store.u64              i2, i26, i25     
   145 : annotation:else        43, 44           
   146 : unspill                i26, 1           
   147 : store.i64              i2, i26, i25     
   148 : annotation:endif       26               
   149 : annotation:endif       29               
   150 : annotation:endif       32               
   151 : annotation:endif       35               
   152 : annotation:endif       38               
   153 : annotation:endif       41               
   154 : annotation:endif       44               
   155 : unspill                i26, 0           
   156 : unspill                i27, 4           
   157 : add                    i26, i26, i27    
   158 : spill                  0, i26           
   159 : unspill                i26, 1           
   160 : add                    i26, i26, i4     
   161 : spill                  1, i26           
   162 : unspill                i26, 2           
   163 : add                    i26, i26, 1      
   164 : spill                  2, i26           
   165 : annotation:endwhile    0, 2             
   166 : unspill                i25, 5           
   167 : unspill                i26, 6           
   168 : unspill                i27, 7           
   169 : add                    i31, i31, 64     
