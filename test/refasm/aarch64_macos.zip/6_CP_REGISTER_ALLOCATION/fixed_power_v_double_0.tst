fixed_power_v_double_0(i0, i1, i2)
     0 : sub                    i31, i31, 16    
     1 : spill                  0, i25          
     2 : mov                    i3, 0           
     3 : mov                    i25, 8          
     4 : mul                    i2, i2, i25     
     5 : annotation:whilecstart 0               
     6 : cmp                    i3, i2          
     7 : jmp_ge                 __loops_label_2 
     8 : annotation:whilecend                   
     9 : vld.fp64               v0, i0, i3      
    10 : mov                    i25, 0          
    11 : arm_movk               i25, 16368, 48  
    12 : broadcast.fp64         v0, i25         
    13 : vst.fp64               i1, i3, v0      
    14 : add                    i3, i3, 16      
    15 : annotation:endwhile    0, 2            
    16 : mov                    i0, 0           
    17 : ret                                    
    18 : unspill                i25, 0          
    19 : add                    i31, i31, 16    
