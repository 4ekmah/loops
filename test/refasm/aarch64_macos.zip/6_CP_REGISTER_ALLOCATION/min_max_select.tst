min_max_select(i0, i1, i2, i3)
     0 : sub                    i31, i31, 64    
     1 : spill                  1, i2           
     2 : spill                  0, i3           
     3 : spill                  5, i25          
     4 : spill                  6, i26          
     5 : mov                    i25, 0          
     6 : mov                    i26, 0          
     7 : spill                  3, i26          
     8 : mov                    i26, 0          
     9 : spill                  2, i26          
    10 : load.i32               i2, i0          
    11 : mov                    i3, i2          
    12 : shl                    i26, i1, 2      
    13 : spill                  4, i26          
    14 : annotation:whilecstart 0               
    15 : unspill                i26, 4          
    16 : cmp                    i25, i26        
    17 : jmp_ge                 __loops_label_2 
    18 : annotation:whilecend                   
    19 : load.i32               i1, i0, i25     
    20 : cmp                    i1, i2          
    21 : unspill                i26, 3          
    22 : select_gt              i26, i25, i26   
    23 : spill                  3, i26          
    24 : min                    i2, i1, i2      
    25 : cmp                    i1, i3          
    26 : unspill                i26, 2          
    27 : select_gt              i26, i25, i26   
    28 : spill                  2, i26          
    29 : max                    i3, i1, i3      
    30 : add                    i25, i25, 4     
    31 : annotation:endwhile    0, 2            
    32 : unspill                i26, 3          
    33 : sar                    i0, i26, 2      
    34 : unspill                i26, 2          
    35 : sar                    i1, i26, 2      
    36 : unspill                i26, 1          
    37 : store.i32              i26, i0         
    38 : unspill                i26, 0          
    39 : store.i32              i26, i1         
    40 : mov                    i0, 0           
    41 : ret                                    
    42 : unspill                i25, 5          
    43 : unspill                i26, 6          
    44 : add                    i31, i31, 64    
