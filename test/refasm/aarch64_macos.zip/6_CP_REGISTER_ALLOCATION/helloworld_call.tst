helloworld_call()
     0 : sub        i31, i31, 416      
     1 : arm_stp    i31, 400, i29, i30 
     2 : mov        i29, i31           
     3 : mov        i0, 35092          
     4 : arm_movk   i0, 1045, 16       
     5 : arm_movk   i0, 1, 32          
     6 : call_noret [i0]()             
     7 : ret                           
     8 : arm_ldp    i29, i30, i31, 400 
     9 : add        i31, i31, 416      
