triangle_types(i0, i1, i2)
     0 : sub                 i31, i31, 32     
     1 : spill               1, i25           
     2 : spill               2, i26           
     3 : spill               0, i1            
     4 : annotation:ifcstart                  
     5 : cmp                 i0, 0            
     6 : jmp_le              __loops_label_0  
     7 : unspill             i26, 0           
     8 : cmp                 i26, 0           
     9 : jmp_le              __loops_label_0  
    10 : cmp                 i2, 0            
    11 : jmp_gt              __loops_label_1  
    12 : __loops_label_0:                     
    13 : annotation:ifcend                    
    14 : mov                 i0, 0            
    15 : ret                                  
    16 : annotation:else     1, 2             
    17 : annotation:ifcstart                  
    18 : unspill             i26, 0           
    19 : add                 i3, i26, i2      
    20 : cmp                 i0, i3           
    21 : jmp_gt              __loops_label_3  
    22 : add                 i3, i0, i2       
    23 : unspill             i26, 0           
    24 : cmp                 i26, i3          
    25 : jmp_gt              __loops_label_3  
    26 : unspill             i26, 0           
    27 : add                 i3, i0, i26      
    28 : cmp                 i2, i3           
    29 : jmp_le              __loops_label_4  
    30 : __loops_label_3:                     
    31 : annotation:ifcend                    
    32 : mov                 i0, 0            
    33 : ret                                  
    34 : annotation:else     4, 5             
    35 : annotation:ifcstart                  
    36 : unspill             i26, 0           
    37 : cmp                 i0, i26          
    38 : jmp_ne              __loops_label_7  
    39 : cmp                 i0, i2           
    40 : jmp_ne              __loops_label_7  
    41 : annotation:ifcend                    
    42 : mov                 i0, 2            
    43 : ret                                  
    44 : annotation:else     7, 8             
    45 : annotation:ifcstart                  
    46 : unspill             i26, 0           
    47 : cmp                 i0, i26          
    48 : jmp_eq              __loops_label_9  
    49 : cmp                 i0, i2           
    50 : jmp_eq              __loops_label_9  
    51 : unspill             i26, 0           
    52 : cmp                 i26, i2          
    53 : jmp_ne              __loops_label_10 
    54 : __loops_label_9:                     
    55 : annotation:ifcend                    
    56 : mov                 i0, 3            
    57 : ret                                  
    58 : annotation:else     10, 11           
    59 : annotation:ifcstart                  
    60 : mul                 i3, i0, i0       
    61 : unspill             i26, 0           
    62 : mul                 i25, i26, i26    
    63 : mul                 i1, i2, i2       
    64 : add                 i1, i25, i1      
    65 : cmp                 i3, i1           
    66 : jmp_eq              __loops_label_12 
    67 : unspill             i26, 0           
    68 : mul                 i1, i26, i26     
    69 : mul                 i3, i0, i0       
    70 : mul                 i25, i2, i2      
    71 : add                 i3, i3, i25      
    72 : cmp                 i1, i3           
    73 : jmp_eq              __loops_label_12 
    74 : mul                 i1, i2, i2       
    75 : mul                 i3, i0, i0       
    76 : unspill             i26, 0           
    77 : mul                 i25, i26, i26    
    78 : add                 i3, i3, i25      
    79 : cmp                 i1, i3           
    80 : jmp_ne              __loops_label_13 
    81 : __loops_label_12:                    
    82 : annotation:ifcend                    
    83 : mov                 i0, 1            
    84 : ret                                  
    85 : annotation:else     13, 14           
    86 : annotation:ifcstart                  
    87 : mul                 i1, i0, i0       
    88 : unspill             i26, 0           
    89 : mul                 i3, i26, i26     
    90 : mul                 i25, i2, i2      
    91 : add                 i3, i3, i25      
    92 : cmp                 i1, i3           
    93 : jmp_gt              __loops_label_15 
    94 : unspill             i26, 0           
    95 : mul                 i1, i26, i26     
    96 : mul                 i3, i0, i0       
    97 : mul                 i25, i2, i2      
    98 : add                 i3, i3, i25      
    99 : cmp                 i1, i3           
   100 : jmp_gt              __loops_label_15 
   101 : mul                 i1, i2, i2       
   102 : mul                 i0, i0, i0       
   103 : unspill             i26, 0           
   104 : mul                 i2, i26, i26     
   105 : add                 i0, i0, i2       
   106 : cmp                 i1, i0           
   107 : jmp_le              __loops_label_16 
   108 : __loops_label_15:                    
   109 : annotation:ifcend                    
   110 : mov                 i0, 5            
   111 : ret                                  
   112 : annotation:else     16, 17           
   113 : mov                 i0, 4            
   114 : ret                                  
   115 : annotation:endif    2                
   116 : annotation:endif    5                
   117 : annotation:endif    8                
   118 : annotation:endif    11               
   119 : annotation:endif    14               
   120 : annotation:endif    17               
   121 : unspill             i25, 1           
   122 : unspill             i26, 2           
   123 : add                 i31, i31, 32     
