sort_double(i0, i1)
     0 : sub                    i31, i31, 480      
     1 : spill                  53, i0             
     2 : spill                  54, i25            
     3 : spill                  55, i26            
     4 : spill                  56, i27            
     5 : arm_stp                i31, 464, i29, i30 
     6 : mov                    i29, i31           
     7 : shl                    i26, i1, 3         
     8 : spill                  52, i26            
     9 : unspill                i26, 52            
    10 : sub                    i27, i26, 8        
    11 : spill                  51, i27            
    12 : mov                    i26, 0             
    13 : spill                  50, i26            
    14 : annotation:whilecstart 0                  
    15 : unspill                i27, 51            
    16 : unspill                i26, 50            
    17 : cmp                    i26, i27           
    18 : jmp_ge                 __loops_label_2    
    19 : annotation:whilecend                      
    20 : unspill                i26, 50            
    21 : mov                    i25, i26           
    22 : add                    i3, i25, 8         
    23 : annotation:whilecstart 3                  
    24 : unspill                i26, 52            
    25 : cmp                    i3, i26            
    26 : jmp_ge                 __loops_label_5    
    27 : annotation:whilecend                      
    28 : annotation:ifcstart                       
    29 : unspill                i26, 53            
    30 : load.fp64              i2, i26, i3        
    31 : unspill                i26, 53            
    32 : load.fp64              i1, i26, i25       
    33 : mov                    i0, 55664          
    34 : arm_movk               i0, 1045, 16       
    35 : arm_movk               i0, 1, 32          
    36 : call                   [i0](i0, i2, i1)   
    37 : cmp                    i0, 0              
    38 : jmp_eq                 __loops_label_7    
    39 : annotation:ifcend                         
    40 : mov                    i25, i3            
    41 : annotation:endif       7                  
    42 : add                    i3, i3, 8          
    43 : annotation:endwhile    3, 5               
    44 : annotation:ifcstart                       
    45 : unspill                i26, 50            
    46 : cmp                    i25, i26           
    47 : jmp_eq                 __loops_label_9    
    48 : annotation:ifcend                         
    49 : unspill                i26, 53            
    50 : unspill                i27, 50            
    51 : load.fp64              i0, i26, i27       
    52 : unspill                i26, 53            
    53 : load.fp64              i1, i26, i25       
    54 : unspill                i26, 53            
    55 : store.fp64             i26, i25, i0       
    56 : unspill                i26, 53            
    57 : unspill                i27, 50            
    58 : store.fp64             i26, i27, i1       
    59 : annotation:endif       9                  
    60 : unspill                i26, 50            
    61 : add                    i26, i26, 8        
    62 : spill                  50, i26            
    63 : annotation:endwhile    0, 2               
    64 : ret                                       
    65 : arm_ldp                i29, i30, i31, 464 
    66 : unspill                i25, 54            
    67 : unspill                i26, 55            
    68 : unspill                i27, 56            
    69 : add                    i31, i31, 480      
