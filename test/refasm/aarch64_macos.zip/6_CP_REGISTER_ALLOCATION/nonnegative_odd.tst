nonnegative_odd(i0, i1)
     0 : sub                    i31, i31, 48    
     1 : spill                  3, i25          
     2 : spill                  4, i26          
     3 : mov                    i2, 0           
     4 : mov                    i26, -4         
     5 : spill                  2, i26          
     6 : mov                    i25, 4          
     7 : mul                    i1, i1, i25     
     8 : annotation:whilecstart 0               
     9 : cmp                    i2, i1          
    10 : jmp_ge                 __loops_label_2 
    11 : annotation:whilecend                   
    12 : load.i32               i25, i0, i2     
    13 : annotation:ifcstart                    
    14 : cmp                    i25, 0          
    15 : jmp_ge                 __loops_label_4 
    16 : annotation:ifcend                      
    17 : add                    i2, i2, 4       
    18 : annotation:break       0               
    19 : annotation:endif       4               
    20 : mov                    i3, 2           
    21 : mod                    i3, i25, i3     
    22 : annotation:ifcstart                    
    23 : cmp                    i3, 0           
    24 : jmp_eq                 __loops_label_6 
    25 : annotation:ifcend                      
    26 : mov                    i26, i2         
    27 : spill                  2, i26          
    28 : annotation:break       2               
    29 : annotation:endif       6               
    30 : add                    i2, i2, 4       
    31 : annotation:endwhile    0, 2            
    32 : mov                    i0, 4           
    33 : unspill                i26, 2          
    34 : div                    i0, i26, i0     
    35 : mov                    i0, i0          
    36 : ret                                    
    37 : unspill                i25, 3          
    38 : unspill                i26, 4          
    39 : add                    i31, i31, 48    
