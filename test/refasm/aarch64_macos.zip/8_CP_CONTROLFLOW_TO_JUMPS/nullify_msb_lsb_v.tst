nullify_msb_lsb_v(i0, i1, i2, i3)
     0 : sub              i31, i31, 48    
     1 : spill            4, i25          
     2 : spill            5, i26          
     3 : mov              i25, 0          
     4 : mov              i26, 4          
     5 : spill            3, i26          
     6 : unspill          i26, 3          
     7 : mul              i3, i3, i26     
     8 : mov              v0, 1           
     9 : spill            2, i3           
    10 : __loops_label_0:                 
    11 : unspill          i26, 2          
    12 : cmp              i25, i26        
    13 : jmp_ge           __loops_label_2 
    14 : vld.u32          v1, i0, i25     
    15 : shr.u32          v2, v1, 1       
    16 : or               v2, v1, v2      
    17 : shr.u32          v3, v2, 2       
    18 : or               v2, v2, v3      
    19 : shr.u32          v3, v2, 4       
    20 : or               v2, v2, v3      
    21 : shr.u32          v3, v2, 8       
    22 : or               v2, v2, v3      
    23 : shr.u32          v3, v2, 16      
    24 : or               v2, v2, v3      
    25 : add.u32          v2, v2, v0      
    26 : shr.u32          v2, v2, 1       
    27 : xor              v2, v2, v1      
    28 : vst.u32          i1, i25, v2     
    29 : sub.u32          v2, v1, v0      
    30 : not              v2, v2          
    31 : and              v2, v1, v2      
    32 : xor              v1, v2, v1      
    33 : vst.u32          i2, i25, v1     
    34 : add              i25, i25, 16    
    35 : jmp              0               
    36 : __loops_label_2:                 
    37 : unspill          i25, 4          
    38 : unspill          i26, 5          
    39 : add              i31, i31, 48    
    40 : ret                              
