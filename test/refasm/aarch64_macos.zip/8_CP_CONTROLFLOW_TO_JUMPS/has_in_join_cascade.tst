has_in_join_cascade(i0, i1, i2)
     0 : sub               i31, i31, 128    
     1 : spill             13, i25          
     2 : spill             14, i26          
     3 : spill             15, i27          
     4 : mov               i26, 0           
     5 : spill             5, i26           
     6 : load.i64          i26, i0, 16      
     7 : spill             6, i26           
     8 : load.i64          i26, i0, 0       
     9 : spill             7, i26           
    10 : load.i64          i26, i0, 8       
    11 : spill             8, i26           
    12 : __loops_label_0:                   
    13 : unspill           i26, 6           
    14 : cmp               i26, 0           
    15 : jmp_le            __loops_label_2  
    16 : unspill           i26, 7           
    17 : load.i32          i27, i26         
    18 : spill             9, i27           
    19 : unspill           i26, 7           
    20 : add               i26, i26, 4      
    21 : spill             7, i26           
    22 : unspill           i26, 8           
    23 : load.i32          i27, i26         
    24 : spill             4, i27           
    25 : unspill           i26, 8           
    26 : add               i26, i26, 4      
    27 : spill             8, i26           
    28 : unspill           i26, 6           
    29 : sub               i26, i26, 1      
    30 : spill             6, i26           
    31 : load.i64          i26, i0, 40      
    32 : spill             10, i26          
    33 : load.i64          i26, i0, 24      
    34 : spill             11, i26          
    35 : load.i64          i26, i0, 32      
    36 : spill             12, i26          
    37 : __loops_label_3:                   
    38 : unspill           i26, 10          
    39 : cmp               i26, 0           
    40 : jmp_le            __loops_label_5  
    41 : unspill           i26, 11          
    42 : load.i32          i27, i26         
    43 : spill             0, i27           
    44 : unspill           i26, 11          
    45 : add               i26, i26, 4      
    46 : spill             11, i26          
    47 : unspill           i26, 12          
    48 : load.i32          i3, i26          
    49 : unspill           i26, 12          
    50 : add               i26, i26, 4      
    51 : spill             12, i26          
    52 : unspill           i26, 10          
    53 : sub               i26, i26, 1      
    54 : spill             10, i26          
    55 : unspill           i26, 9           
    56 : cmp               i3, i26          
    57 : jmp_le            __loops_label_7  
    58 : jmp               0                
    59 : __loops_label_7:                   
    60 : unspill           i26, 9           
    61 : cmp               i3, i26          
    62 : jmp_ne            __loops_label_10 
    63 : load.i64          i26, i0, 64      
    64 : spill             1, i26           
    65 : load.i64          i26, i0, 48      
    66 : spill             2, i26           
    67 : load.i64          i26, i0, 56      
    68 : spill             3, i26           
    69 : __loops_label_11:                  
    70 : unspill           i26, 1           
    71 : cmp               i26, 0           
    72 : jmp_le            __loops_label_13 
    73 : unspill           i26, 2           
    74 : load.i32          i25, i26         
    75 : unspill           i26, 2           
    76 : add               i26, i26, 4      
    77 : spill             2, i26           
    78 : unspill           i26, 3           
    79 : load.i32          i3, i26          
    80 : unspill           i26, 3           
    81 : add               i26, i26, 4      
    82 : spill             3, i26           
    83 : unspill           i26, 1           
    84 : sub               i26, i26, 1      
    85 : spill             1, i26           
    86 : unspill           i26, 4           
    87 : cmp               i25, i26         
    88 : jmp_le            __loops_label_15 
    89 : jmp               0                
    90 : __loops_label_15:                  
    91 : unspill           i26, 4           
    92 : cmp               i25, i26         
    93 : jmp_ne            __loops_label_18 
    94 : unspill           i26, 0           
    95 : cmp               i26, i1          
    96 : jmp_ne            __loops_label_18 
    97 : cmp               i3, i2           
    98 : jmp_ne            __loops_label_18 
    99 : mov               i26, 1           
   100 : spill             5, i26           
   101 : jmp               2                
   102 : __loops_label_16:                  
   103 : __loops_label_18:                  
   104 : jmp               11               
   105 : __loops_label_13:                  
   106 : __loops_label_8:                   
   107 : __loops_label_10:                  
   108 : jmp               3                
   109 : __loops_label_5:                   
   110 : jmp               0                
   111 : __loops_label_2:                   
   112 : unspill           i26, 5           
   113 : mov               i0, i26          
   114 : unspill           i25, 13          
   115 : unspill           i26, 14          
   116 : unspill           i27, 15          
   117 : add               i31, i31, 128    
   118 : ret                                
