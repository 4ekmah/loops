sibling_loops(i0, i1, i2)
     0 : sub              i31, i31, 32    
     1 : spill            1, i25          
     2 : spill            2, i26          
     3 : mov              i3, 0           
     4 : mov              i26, 0          
     5 : spill            0, i26          
     6 : __loops_label_0:                 
     7 : cmp              i3, i1          
     8 : jmp_ge           __loops_label_2 
     9 : load.i32         i25, i0, i3     
    10 : unspill          i26, 0          
    11 : add              i26, i26, i25   
    12 : spill            0, i26          
    13 : add              i3, i3, 4       
    14 : jmp              0               
    15 : __loops_label_2:                 
    16 : mov              i25, 0          
    17 : __loops_label_3:                 
    18 : cmp              i3, 0           
    19 : jmp_le           __loops_label_5 
    20 : add              i25, i25, 1     
    21 : sub              i3, i3, 4       
    22 : jmp              3               
    23 : __loops_label_5:                 
    24 : unspill          i26, 0          
    25 : store.i32        i2, i26         
    26 : store.i32        i2, 4, i25      
    27 : mov              i0, 0           
    28 : unspill          i25, 1          
    29 : unspill          i26, 2          
    30 : add              i31, i31, 32    
    31 : ret                              
