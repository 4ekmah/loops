fixed_power_v_float_0(i0, i1, i2)
     0 : sub              i31, i31, 48    
     1 : spill            3, i25          
     2 : spill            4, i26          
     3 : mov              i3, 0           
     4 : mov              i25, 4          
     5 : mul              i2, i2, i25     
     6 : spill            2, i2           
     7 : __loops_label_0:                 
     8 : unspill          i26, 2          
     9 : cmp              i3, i26         
    10 : jmp_ge           __loops_label_2 
    11 : vld.fp32         v0, i0, i3      
    12 : mov              i25, 0          
    13 : arm_movk         i25, 16256, 16  
    14 : broadcast.fp32   v0, i25         
    15 : vst.fp32         i1, i3, v0      
    16 : add              i3, i3, 16      
    17 : jmp              0               
    18 : __loops_label_2:                 
    19 : mov              i0, 0           
    20 : unspill          i25, 3          
    21 : unspill          i26, 4          
    22 : add              i31, i31, 48    
    23 : ret                              
