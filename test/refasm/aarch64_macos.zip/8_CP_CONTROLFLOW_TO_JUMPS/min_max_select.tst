min_max_select(i0, i1, i2, i3)
     0 : sub              i31, i31, 96    
     1 : spill            8, i25          
     2 : spill            9, i26          
     3 : spill            10, i27         
     4 : mov              i26, 0          
     5 : spill            7, i26          
     6 : mov              i26, 0          
     7 : spill            2, i26          
     8 : mov              i26, 0          
     9 : spill            3, i26          
    10 : load.i32         i26, i0         
    11 : spill            4, i26          
    12 : unspill          i26, 4          
    13 : mov              i27, i26        
    14 : spill            5, i27          
    15 : shl              i1, i1, 2       
    16 : spill            6, i1           
    17 : __loops_label_0:                 
    18 : unspill          i27, 6          
    19 : unspill          i26, 7          
    20 : cmp              i26, i27        
    21 : jmp_ge           __loops_label_2 
    22 : unspill          i26, 7          
    23 : load.i32         i25, i0, i26    
    24 : unspill          i26, 4          
    25 : cmp              i25, i26        
    26 : unspill          i26, 7          
    27 : unspill          i27, 2          
    28 : select_gt        i27, i26, i27   
    29 : spill            2, i27          
    30 : unspill          i26, 4          
    31 : cmp              i25, i26        
    32 : unspill          i26, 4          
    33 : select_gt        i26, i25, i26   
    34 : spill            4, i26          
    35 : unspill          i26, 5          
    36 : cmp              i25, i26        
    37 : unspill          i26, 7          
    38 : unspill          i27, 3          
    39 : select_gt        i27, i26, i27   
    40 : spill            3, i27          
    41 : unspill          i26, 5          
    42 : cmp              i25, i26        
    43 : unspill          i26, 5          
    44 : select_gt        i26, i25, i26   
    45 : spill            5, i26          
    46 : unspill          i26, 7          
    47 : add              i26, i26, 4     
    48 : spill            7, i26          
    49 : jmp              0               
    50 : __loops_label_2:                 
    51 : unspill          i26, 2          
    52 : sar              i26, i26, 2     
    53 : spill            2, i26          
    54 : unspill          i26, 3          
    55 : sar              i26, i26, 2     
    56 : spill            3, i26          
    57 : unspill          i26, 2          
    58 : store.i32        i2, i26         
    59 : unspill          i26, 3          
    60 : store.i32        i3, i26         
    61 : mov              i0, 0           
    62 : unspill          i25, 8          
    63 : unspill          i26, 9          
    64 : unspill          i27, 10         
    65 : add              i31, i31, 96    
    66 : ret                              
