conditionpainter(i0)
     0 : sub              i31, i31, 64    
     1 : spill            5, i25          
     2 : spill            6, i26          
     3 : mov              i26, -5         
     4 : spill            2, i26          
     5 : __loops_label_0:                 
     6 : unspill          i26, 2          
     7 : cmp              i26, 5          
     8 : jmp_gt           __loops_label_2 
     9 : unspill          i26, 2          
    10 : add              i1, i26, 5      
    11 : mov              i2, 11          
    12 : mul              i1, i1, i2      
    13 : mov              i2, 8           
    14 : mul              i26, i1, i2     
    15 : spill            1, i26          
    16 : mov              i26, -5         
    17 : spill            0, i26          
    18 : __loops_label_3:                 
    19 : unspill          i26, 0          
    20 : cmp              i26, 5          
    21 : jmp_gt           __loops_label_5 
    22 : unspill          i26, 0          
    23 : add              i25, i26, 3     
    24 : unspill          i26, 2          
    25 : cmp              i26, i25        
    26 : iverson_ge       i25             
    27 : unspill          i26, 2          
    28 : cmp              i26, 4          
    29 : iverson_le       i3              
    30 : and              i3, i25, i3     
    31 : mov              i25, -2         
    32 : unspill          i26, 0          
    33 : cmp              i26, i25        
    34 : iverson_ge       i25             
    35 : and              i3, i3, i25     
    36 : unspill          i26, 0          
    37 : cmp              i26, 0          
    38 : iverson_le       i25             
    39 : and              i3, i3, i25     
    40 : unspill          i26, 0          
    41 : sub              i25, i26, 1     
    42 : unspill          i26, 2          
    43 : cmp              i26, i25        
    44 : iverson_le       i25             
    45 : unspill          i26, 0          
    46 : cmp              i26, 0          
    47 : iverson_ge       i2              
    48 : and              i2, i25, i2     
    49 : unspill          i26, 2          
    50 : cmp              i26, 0          
    51 : iverson_le       i25             
    52 : and              i2, i2, i25     
    53 : unspill          i26, 0          
    54 : mul              i25, i26, i26   
    55 : unspill          i26, 2          
    56 : mul              i1, i26, i26    
    57 : add              i1, i25, i1     
    58 : cmp              i1, 9           
    59 : iverson_le       i1              
    60 : and              i1, i2, i1      
    61 : or               i26, i3, i1     
    62 : spill            3, i26          
    63 : mov              i2, 2           
    64 : mov              i26, 0          
    65 : spill            4, i26          
    66 : unspill          i26, 0          
    67 : cmp              i26, 2          
    68 : iverson_ge       i25             
    69 : unspill          i26, 0          
    70 : cmp              i26, 4          
    71 : iverson_le       i1              
    72 : and              i1, i25, i1     
    73 : unspill          i26, 2          
    74 : cmp              i26, 1          
    75 : iverson_ge       i25             
    76 : unspill          i26, 2          
    77 : cmp              i26, 3          
    78 : iverson_le       i3              
    79 : and              i3, i25, i3     
    80 : or               i1, i1, i3      
    81 : unspill          i26, 0          
    82 : mul              i3, i26, i26    
    83 : unspill          i26, 2          
    84 : mul              i25, i26, i26   
    85 : add              i3, i3, i25     
    86 : cmp              i3, 16          
    87 : iverson_le       i3              
    88 : and              i1, i1, i3      
    89 : cmp              i1, 0           
    90 : unspill          i26, 4          
    91 : select_ne        i1, i2, i26     
    92 : unspill          i26, 3          
    93 : add              i1, i26, i1     
    94 : mov              i2, 2           
    95 : unspill          i26, 2          
    96 : mul              i2, i26, i2     
    97 : unspill          i26, 0          
    98 : cmp              i2, i26         
    99 : jmp_gt           __loops_label_8 
   100 : unspill          i26, 0          
   101 : add              i2, i26, 3      
   102 : neg              i2, i2          
   103 : unspill          i26, 0          
   104 : add              i3, i26, 3      
   105 : mul              i2, i2, i3      
   106 : unspill          i26, 2          
   107 : cmp              i26, i2         
   108 : jmp_le           __loops_label_9 
   109 : __loops_label_8:                 
   110 : mov              i2, 2           
   111 : unspill          i26, 0          
   112 : mul              i2, i26, i2     
   113 : unspill          i26, 2          
   114 : cmp              i26, i2         
   115 : jmp_gt           __loops_label_7 
   116 : unspill          i26, 0          
   117 : add              i2, i26, 3      
   118 : neg              i2, i2          
   119 : unspill          i26, 0          
   120 : add              i3, i26, 3      
   121 : mul              i2, i2, i3      
   122 : unspill          i26, 2          
   123 : cmp              i26, i2         
   124 : jmp_gt           __loops_label_7 
   125 : __loops_label_9:                 
   126 : unspill          i26, 0          
   127 : cmp              i26, 0          
   128 : jmp_gt           __loops_label_7 
   129 : add              i1, i1, 3       
   130 : __loops_label_7:                 
   131 : unspill          i26, 0          
   132 : add              i2, i26, 5      
   133 : shl              i2, i2, 3       
   134 : unspill          i26, 1          
   135 : add              i2, i26, i2     
   136 : store.i64        i0, i2, i1      
   137 : unspill          i26, 0          
   138 : add              i26, i26, 1     
   139 : spill            0, i26          
   140 : jmp              3               
   141 : __loops_label_5:                 
   142 : unspill          i26, 2          
   143 : add              i26, i26, 1     
   144 : spill            2, i26          
   145 : jmp              0               
   146 : __loops_label_2:                 
   147 : unspill          i25, 5          
   148 : unspill          i26, 6          
   149 : add              i31, i31, 64    
   150 : ret                              
