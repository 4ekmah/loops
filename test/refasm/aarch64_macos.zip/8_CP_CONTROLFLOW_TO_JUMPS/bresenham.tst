bresenham(i0, i1, i2, i3, i4, i5, i6)
     0 : sub               i31, i31, 80     
     1 : spill             5, i25           
     2 : spill             6, i26           
     3 : spill             7, i27           
     4 : spill             8, i28           
     5 : sub               i25, i4, i2      
     6 : cmp               i25, 0           
     7 : arm_cneg          i26, i25, 33     
     8 : spill             4, i26           
     9 : sub               i25, i4, i2      
    10 : cmp               i25, 0           
    11 : sar               i25, i25, 63     
    12 : arm_cinc          i26, i25, 30     
    13 : spill             0, i26           
    14 : sub               i25, i5, i3      
    15 : cmp               i25, 0           
    16 : arm_cneg          i25, i25, 33     
    17 : neg               i26, i25         
    18 : spill             1, i26           
    19 : sub               i25, i5, i3      
    20 : cmp               i25, 0           
    21 : sar               i25, i25, 63     
    22 : arm_cinc          i26, i25, 30     
    23 : spill             2, i26           
    24 : unspill           i26, 4           
    25 : unspill           i27, 1           
    26 : add               i28, i26, i27    
    27 : spill             3, i28           
    28 : __loops_label_0:                   
    29 : cmp               i0, 0            
    30 : jmp_eq            __loops_label_2  
    31 : mul               i25, i3, i1      
    32 : add               i25, i25, i2     
    33 : store.u8          i0, i25, i6      
    34 : cmp               i2, i4           
    35 : jmp_ne            __loops_label_4  
    36 : cmp               i3, i5           
    37 : jmp_ne            __loops_label_4  
    38 : jmp               2                
    39 : __loops_label_4:                   
    40 : unspill           i26, 3           
    41 : shl               i25, i26, 1      
    42 : unspill           i26, 1           
    43 : cmp               i25, i26         
    44 : jmp_gt            __loops_label_6  
    45 : cmp               i2, i4           
    46 : jmp_ne            __loops_label_8  
    47 : jmp               2                
    48 : __loops_label_8:                   
    49 : unspill           i27, 1           
    50 : unspill           i26, 3           
    51 : add               i26, i26, i27    
    52 : spill             3, i26           
    53 : unspill           i26, 0           
    54 : add               i2, i2, i26      
    55 : __loops_label_6:                   
    56 : unspill           i26, 4           
    57 : cmp               i25, i26         
    58 : jmp_gt            __loops_label_10 
    59 : cmp               i3, i5           
    60 : jmp_ne            __loops_label_12 
    61 : jmp               2                
    62 : __loops_label_12:                  
    63 : unspill           i27, 4           
    64 : unspill           i26, 3           
    65 : add               i26, i26, i27    
    66 : spill             3, i26           
    67 : unspill           i26, 2           
    68 : add               i3, i3, i26      
    69 : __loops_label_10:                  
    70 : jmp               0                
    71 : __loops_label_2:                   
    72 : unspill           i25, 5           
    73 : unspill           i26, 6           
    74 : unspill           i27, 7           
    75 : unspill           i28, 8           
    76 : add               i31, i31, 80     
    77 : ret                                
