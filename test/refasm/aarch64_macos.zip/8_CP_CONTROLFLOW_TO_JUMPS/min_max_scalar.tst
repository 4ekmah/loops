min_max_scalar(i0, i1, i2, i3)
     0 : sub              i31, i31, 96    
     1 : spill            8, i25          
     2 : spill            9, i26          
     3 : spill            10, i27         
     4 : mov              i26, 0          
     5 : spill            7, i26          
     6 : mov              i26, 0          
     7 : spill            2, i26          
     8 : mov              i26, 0          
     9 : spill            3, i26          
    10 : load.i32         i26, i0         
    11 : spill            4, i26          
    12 : unspill          i26, 4          
    13 : mov              i27, i26        
    14 : spill            5, i27          
    15 : mov              i25, 4          
    16 : mul              i1, i1, i25     
    17 : spill            6, i1           
    18 : __loops_label_0:                 
    19 : unspill          i27, 6          
    20 : unspill          i26, 7          
    21 : cmp              i26, i27        
    22 : jmp_ge           __loops_label_2 
    23 : unspill          i26, 7          
    24 : load.i32         i25, i0, i26    
    25 : unspill          i26, 4          
    26 : cmp              i25, i26        
    27 : jmp_ge           __loops_label_4 
    28 : mov              i26, i25        
    29 : spill            4, i26          
    30 : unspill          i26, 7          
    31 : mov              i27, i26        
    32 : spill            2, i27          
    33 : __loops_label_4:                 
    34 : unspill          i26, 5          
    35 : cmp              i25, i26        
    36 : jmp_le           __loops_label_6 
    37 : mov              i26, i25        
    38 : spill            5, i26          
    39 : unspill          i26, 7          
    40 : mov              i27, i26        
    41 : spill            3, i27          
    42 : __loops_label_6:                 
    43 : unspill          i26, 7          
    44 : add              i26, i26, 4     
    45 : spill            7, i26          
    46 : jmp              0               
    47 : __loops_label_2:                 
    48 : mov              i0, 4           
    49 : unspill          i26, 2          
    50 : div              i1, i26, i0     
    51 : unspill          i26, 3          
    52 : div              i0, i26, i0     
    53 : store.i32        i2, i1          
    54 : store.i32        i3, i0          
    55 : mov              i0, 0           
    56 : unspill          i25, 8          
    57 : unspill          i26, 9          
    58 : unspill          i27, 10         
    59 : add              i31, i31, 96    
    60 : ret                              
