all_loads_all_stores(i0, i1, i2, i3, i4)
     0 : sub               i31, i31, 112    
     1 : spill             11, i25          
     2 : spill             12, i26          
     3 : spill             13, i27          
     4 : mov               i26, 0           
     5 : spill             4, i26           
     6 : mov               i26, 0           
     7 : spill             0, i26           
     8 : mov               i26, 0           
     9 : spill             1, i26           
    10 : mov               i25, 2           
    11 : mov               i26, 1           
    12 : spill             5, i26           
    13 : cmp               i1, 1            
    14 : unspill           i26, 5           
    15 : select_gt         i25, i25, i26    
    16 : mov               i26, 4           
    17 : spill             6, i26           
    18 : cmp               i1, 3            
    19 : unspill           i26, 6           
    20 : select_gt         i25, i26, i25    
    21 : mov               i26, 8           
    22 : spill             7, i26           
    23 : cmp               i1, 5            
    24 : unspill           i26, 7           
    25 : select_gt         i27, i26, i25    
    26 : spill             2, i27           
    27 : mov               i25, 2           
    28 : mov               i26, 1           
    29 : spill             8, i26           
    30 : cmp               i3, 1            
    31 : unspill           i26, 8           
    32 : select_gt         i25, i25, i26    
    33 : mov               i26, 4           
    34 : spill             9, i26           
    35 : cmp               i3, 3            
    36 : unspill           i26, 9           
    37 : select_gt         i25, i26, i25    
    38 : mov               i26, 8           
    39 : spill             10, i26          
    40 : cmp               i3, 5            
    41 : unspill           i26, 10          
    42 : select_gt         i27, i26, i25    
    43 : spill             3, i27           
    44 : __loops_label_0:                   
    45 : unspill           i26, 4           
    46 : cmp               i26, i4          
    47 : jmp_ge            __loops_label_2  
    48 : def               i25              
    49 : cmp               i1, 0            
    50 : jmp_ne            __loops_label_4  
    51 : unspill           i26, 0           
    52 : load.u8           i25, i0, i26     
    53 : jmp               5                
    54 : __loops_label_4:                   
    55 : cmp               i1, 1            
    56 : jmp_ne            __loops_label_7  
    57 : unspill           i26, 0           
    58 : load.i8           i25, i0, i26     
    59 : jmp               8                
    60 : __loops_label_7:                   
    61 : cmp               i1, 2            
    62 : jmp_ne            __loops_label_10 
    63 : unspill           i26, 0           
    64 : load.u16          i25, i0, i26     
    65 : jmp               11               
    66 : __loops_label_10:                  
    67 : cmp               i1, 3            
    68 : jmp_ne            __loops_label_13 
    69 : unspill           i26, 0           
    70 : load.i16          i25, i0, i26     
    71 : jmp               14               
    72 : __loops_label_13:                  
    73 : cmp               i1, 4            
    74 : jmp_ne            __loops_label_16 
    75 : unspill           i26, 0           
    76 : load.u32          i25, i0, i26     
    77 : jmp               17               
    78 : __loops_label_16:                  
    79 : cmp               i1, 5            
    80 : jmp_ne            __loops_label_19 
    81 : unspill           i26, 0           
    82 : load.i32          i25, i0, i26     
    83 : jmp               20               
    84 : __loops_label_19:                  
    85 : cmp               i1, 6            
    86 : jmp_ne            __loops_label_22 
    87 : unspill           i26, 0           
    88 : load.u64          i25, i0, i26     
    89 : jmp               23               
    90 : __loops_label_22:                  
    91 : unspill           i26, 0           
    92 : load.i64          i25, i0, i26     
    93 : __loops_label_5:                   
    94 : __loops_label_8:                   
    95 : __loops_label_11:                  
    96 : __loops_label_14:                  
    97 : __loops_label_17:                  
    98 : __loops_label_20:                  
    99 : __loops_label_23:                  
   100 : cmp               i3, 0            
   101 : jmp_ne            __loops_label_25 
   102 : unspill           i26, 1           
   103 : store.u8          i2, i26, i25     
   104 : jmp               26               
   105 : __loops_label_25:                  
   106 : cmp               i3, 1            
   107 : jmp_ne            __loops_label_28 
   108 : unspill           i26, 1           
   109 : store.i8          i2, i26, i25     
   110 : jmp               29               
   111 : __loops_label_28:                  
   112 : cmp               i3, 2            
   113 : jmp_ne            __loops_label_31 
   114 : unspill           i26, 1           
   115 : store.u16         i2, i26, i25     
   116 : jmp               32               
   117 : __loops_label_31:                  
   118 : cmp               i3, 3            
   119 : jmp_ne            __loops_label_34 
   120 : unspill           i26, 1           
   121 : store.i16         i2, i26, i25     
   122 : jmp               35               
   123 : __loops_label_34:                  
   124 : cmp               i3, 4            
   125 : jmp_ne            __loops_label_37 
   126 : unspill           i26, 1           
   127 : store.u32         i2, i26, i25     
   128 : jmp               38               
   129 : __loops_label_37:                  
   130 : cmp               i3, 5            
   131 : jmp_ne            __loops_label_40 
   132 : unspill           i26, 1           
   133 : store.i32         i2, i26, i25     
   134 : jmp               41               
   135 : __loops_label_40:                  
   136 : cmp               i3, 6            
   137 : jmp_ne            __loops_label_43 
   138 : unspill           i26, 1           
   139 : store.u64         i2, i26, i25     
   140 : jmp               44               
   141 : __loops_label_43:                  
   142 : unspill           i26, 1           
   143 : store.i64         i2, i26, i25     
   144 : __loops_label_26:                  
   145 : __loops_label_29:                  
   146 : __loops_label_32:                  
   147 : __loops_label_35:                  
   148 : __loops_label_38:                  
   149 : __loops_label_41:                  
   150 : __loops_label_44:                  
   151 : unspill           i26, 0           
   152 : unspill           i27, 2           
   153 : add               i26, i26, i27    
   154 : spill             0, i26           
   155 : unspill           i26, 1           
   156 : unspill           i27, 3           
   157 : add               i26, i26, i27    
   158 : spill             1, i26           
   159 : unspill           i26, 4           
   160 : add               i26, i26, 1      
   161 : spill             4, i26           
   162 : jmp               0                
   163 : __loops_label_2:                   
   164 : unspill           i25, 11          
   165 : unspill           i26, 12          
   166 : unspill           i27, 13          
   167 : add               i31, i31, 112    
   168 : ret                                
