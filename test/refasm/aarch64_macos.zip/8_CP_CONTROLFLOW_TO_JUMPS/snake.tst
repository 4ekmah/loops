snake(i0, i1, i2)
     0 : sub              i31, i31, 528   
     1 : spill            60, i25         
     2 : spill            61, i26         
     3 : spill            62, i27         
     4 : spill            63, i28         
     5 : spill            64, i29         
     6 : spill            65, i30         
     7 : mov              i29, i31        
     8 : add              i3, i1, i2      
     9 : sub              i26, i3, 1      
    10 : spill            54, i26         
    11 : mov              i3, 0           
    12 : mov              i26, 1          
    13 : spill            53, i26         
    14 : unspill          i26, 53         
    15 : neg              i27, i26        
    16 : spill            50, i27         
    17 : mov              i26, 0          
    18 : spill            55, i26         
    19 : __loops_label_0:                 
    20 : unspill          i27, 54         
    21 : unspill          i26, 55         
    22 : cmp              i26, i27        
    23 : jmp_ge           __loops_label_2 
    24 : mov              i26, 0          
    25 : spill            51, i26         
    26 : mov              i26, 0          
    27 : spill            52, i26         
    28 : unspill          i26, 55         
    29 : and              i25, i26, 1     
    30 : cmp              i25, 0          
    31 : jmp_eq           __loops_label_4 
    32 : sub              i25, i2, 1      
    33 : unspill          i26, 55         
    34 : cmp              i25, i26        
    35 : unspill          i26, 55         
    36 : select_gt        i27, i25, i26   
    37 : spill            51, i27         
    38 : unspill          i26, 55         
    39 : sub              i27, i26, i25   
    40 : spill            56, i27         
    41 : mov              i26, 0          
    42 : spill            57, i26         
    43 : unspill          i26, 55         
    44 : cmp              i26, i25        
    45 : unspill          i26, 56         
    46 : unspill          i27, 57         
    47 : select_gt        i28, i26, i27   
    48 : spill            52, i28         
    49 : jmp              5               
    50 : __loops_label_4:                 
    51 : sub              i26, i1, 1      
    52 : spill            58, i26         
    53 : unspill          i26, 55         
    54 : unspill          i27, 58         
    55 : sub              i25, i26, i27   
    56 : mov              i26, 0          
    57 : spill            59, i26         
    58 : unspill          i26, 55         
    59 : unspill          i27, 58         
    60 : cmp              i26, i27        
    61 : unspill          i26, 59         
    62 : select_gt        i27, i25, i26   
    63 : spill            51, i27         
    64 : unspill          i27, 55         
    65 : unspill          i26, 58         
    66 : cmp              i26, i27        
    67 : unspill          i27, 55         
    68 : unspill          i26, 58         
    69 : select_gt        i28, i26, i27   
    70 : spill            52, i28         
    71 : __loops_label_5:                 
    72 : __loops_label_6:                 
    73 : unspill          i26, 51         
    74 : cmp              i26, 0          
    75 : jmp_gt           __loops_label_8 
    76 : unspill          i26, 51         
    77 : cmp              i26, i2         
    78 : jmp_ge           __loops_label_8 
    79 : unspill          i26, 52         
    80 : cmp              i26, 0          
    81 : jmp_gt           __loops_label_8 
    82 : unspill          i26, 52         
    83 : cmp              i26, i1         
    84 : jmp_ge           __loops_label_8 
    85 : mov              i25, 58780      
    86 : arm_movk         i25, 1088, 16   
    87 : arm_movk         i25, 1, 32      
    88 : unspill          i26, 51         
    89 : unspill          i27, 52         
    90 : call_noret       [i25](i26, i27) 
    91 : unspill          i26, 52         
    92 : mul              i25, i26, i2    
    93 : unspill          i26, 51         
    94 : add              i25, i25, i26   
    95 : store.u8         i0, i25, i3     
    96 : add              i3, i3, 1       
    97 : unspill          i27, 53         
    98 : unspill          i26, 51         
    99 : add              i26, i26, i27   
   100 : spill            51, i26         
   101 : unspill          i27, 50         
   102 : unspill          i26, 52         
   103 : add              i26, i26, i27   
   104 : spill            52, i26         
   105 : jmp              6               
   106 : __loops_label_8:                 
   107 : unspill          i26, 53         
   108 : neg              i26, i26        
   109 : spill            53, i26         
   110 : unspill          i26, 50         
   111 : neg              i26, i26        
   112 : spill            50, i26         
   113 : unspill          i26, 55         
   114 : add              i26, i26, 1     
   115 : spill            55, i26         
   116 : jmp              0               
   117 : __loops_label_2:                 
   118 : unspill          i29, 64         
   119 : unspill          i30, 65         
   120 : unspill          i25, 60         
   121 : unspill          i26, 61         
   122 : unspill          i27, 62         
   123 : unspill          i28, 63         
   124 : add              i31, i31, 528   
   125 : ret                              
