area_sum(i0, i1)
     0 : mov                    i2, 0               
     1 : annotation:whilecstart 0                   
     2 : cmp                    i1, 0               
     3 : jmp_le                 __loops_label_2     
     4 : annotation:whilecend                       
     5 : load.i8                i3, i0              
     6 : mov                    i4, 63788           
     7 : arm_movk               i4, 1045, 16        
     8 : arm_movk               i4, 1, 32           
     9 : mov                    i5, 63940           
    10 : arm_movk               i5, 1045, 16        
    11 : arm_movk               i5, 1, 32           
    12 : mov                    i6, 64056           
    13 : arm_movk               i6, 1045, 16        
    14 : arm_movk               i6, 1, 32           
    15 : cmp                    i3, 1               
    16 : select_eq              i7, i5, i6          
    17 : cmp                    i3, 0               
    18 : select_eq              i8, i4, i7          
    19 : mov                    i9, 64252           
    20 : arm_movk               i9, 1045, 16        
    21 : arm_movk               i9, 1, 32           
    22 : mov                    i10, 64348          
    23 : arm_movk               i10, 1045, 16       
    24 : arm_movk               i10, 1, 32          
    25 : mov                    i11, 64424          
    26 : arm_movk               i11, 1045, 16       
    27 : arm_movk               i11, 1, 32          
    28 : cmp                    i3, 1               
    29 : select_eq              i12, i10, i11       
    30 : cmp                    i3, 0               
    31 : select_eq              i13, i9, i12        
    32 : call_noret             [i8](i0)            
    33 : call                   [i13](i14, i0)      
    34 : mov                    i16, 64560          
    35 : arm_movk               i16, 1045, 16       
    36 : arm_movk               i16, 1, 32          
    37 : call                   [i16](i15, i2, i14) 
    38 : mov                    i2, i15             
    39 : add                    i0, i0, 56          
    40 : sub                    i1, i1, 1           
    41 : annotation:endwhile    0, 2                
    42 : mov                    iR, i2              
    43 : ret                                        
