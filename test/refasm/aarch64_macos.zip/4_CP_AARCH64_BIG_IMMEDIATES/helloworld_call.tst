helloworld_call()
     0 : mov        i0, 35092    
     1 : arm_movk   i0, 1045, 16 
     2 : arm_movk   i0, 1, 32    
     3 : call_noret [i0]()       
     4 : ret                     
