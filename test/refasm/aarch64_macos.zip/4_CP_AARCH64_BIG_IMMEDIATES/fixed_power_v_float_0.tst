fixed_power_v_float_0(i0, i1, i2)
     0 : mov                    i3, 0           
     1 : mov                    i4, 4           
     2 : mul                    i2, i2, i4      
     3 : annotation:whilecstart 0               
     4 : cmp                    i3, i2          
     5 : jmp_ge                 __loops_label_2 
     6 : annotation:whilecend                   
     7 : vld.fp32               v0, i0, i3      
     8 : mov                    i5, 0           
     9 : arm_movk               i5, 16256, 16   
    10 : broadcast.fp32         v1, i5          
    11 : vst.fp32               i1, i3, v1      
    12 : add                    i3, i3, 16      
    13 : annotation:endwhile    0, 2            
    14 : mov                    iR, 0           
    15 : ret                                    
