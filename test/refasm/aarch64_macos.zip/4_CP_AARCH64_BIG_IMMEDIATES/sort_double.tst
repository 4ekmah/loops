sort_double(i0, i1)
     0 : shl                    i1, i1, 3         
     1 : sub                    i2, i1, 8         
     2 : mov                    i3, 0             
     3 : annotation:whilecstart 0                 
     4 : cmp                    i3, i2            
     5 : jmp_ge                 __loops_label_2   
     6 : annotation:whilecend                     
     7 : mov                    i4, i3            
     8 : add                    i5, i4, 8         
     9 : annotation:whilecstart 3                 
    10 : cmp                    i5, i1            
    11 : jmp_ge                 __loops_label_5   
    12 : annotation:whilecend                     
    13 : annotation:ifcstart                      
    14 : load.fp64              i7, i0, i5        
    15 : load.fp64              i8, i0, i4        
    16 : mov                    i11, 55664        
    17 : arm_movk               i11, 1045, 16     
    18 : arm_movk               i11, 1, 32        
    19 : call                   [i11](i6, i7, i8) 
    20 : cmp                    i6, 0             
    21 : jmp_eq                 __loops_label_7   
    22 : annotation:ifcend                        
    23 : mov                    i4, i5            
    24 : annotation:endif       7                 
    25 : add                    i5, i5, 8         
    26 : annotation:endwhile    3, 5              
    27 : annotation:ifcstart                      
    28 : cmp                    i4, i3            
    29 : jmp_eq                 __loops_label_9   
    30 : annotation:ifcend                        
    31 : load.fp64              i9, i0, i3        
    32 : load.fp64              i10, i0, i4       
    33 : store.fp64             i0, i4, i9        
    34 : store.fp64             i0, i3, i10       
    35 : annotation:endif       9                 
    36 : add                    i3, i3, 8         
    37 : annotation:endwhile    0, 2              
    38 : ret                                      
