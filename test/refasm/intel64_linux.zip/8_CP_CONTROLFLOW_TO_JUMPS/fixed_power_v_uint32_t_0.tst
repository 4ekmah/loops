fixed_power_v_uint32_t_0(i0, i1, i2)
     0 : sub              i4, i4, 24      
     1 : mov              i1, 0           
     2 : mov              i2, i2          
     3 : mul              i2, i2, 4       
     4 : spill            1, i2           
     5 : __loops_label_0:                 
     6 : cmp              i1, s1          
     7 : jmp_ge           __loops_label_2 
     8 : vld.u32          v0, i7, i1      
     9 : mov              i0, 1           
    10 : vdef.u32         v0              
    11 : setlane.u32      v0, 0, i0       
    12 : broadcast.u32    v0, v0, 0       
    13 : vst.u32          i6, i1, v0      
    14 : add              i1, i1, 32      
    15 : jmp              0               
    16 : __loops_label_2:                 
    17 : mov              i0, 0           
    18 : add              i4, i4, 24      
    19 : ret                              
