min_max_select(i0, i1, i2, i3)
     0 : sub              i4, i4, 72      
     1 : spill            7, i13          
     2 : mov              s6, 0           
     3 : mov              s1, 0           
     4 : mov              s2, 0           
     5 : load.i32         i13, i7         
     6 : spill            3, i13          
     7 : mov              i13, s3         
     8 : spill            4, i13          
     9 : mov              i6, i6          
    10 : shl              i6, i6, 2       
    11 : spill            5, i6           
    12 : __loops_label_0:                 
    13 : unspill          i13, 5          
    14 : cmp              s6, i13         
    15 : jmp_ge           __loops_label_2 
    16 : unspill          i13, 6          
    17 : load.i32         i0, i7, i13     
    18 : cmp              i0, s3          
    19 : unspill          i13, 1          
    20 : select_gt        i13, s6, i13    
    21 : spill            1, i13          
    22 : cmp              i0, s3          
    23 : unspill          i13, 3          
    24 : select_gt        i13, i0, i13    
    25 : spill            3, i13          
    26 : cmp              i0, s4          
    27 : unspill          i13, 2          
    28 : select_gt        i13, s6, i13    
    29 : spill            2, i13          
    30 : cmp              i0, s4          
    31 : unspill          i13, 4          
    32 : select_gt        i13, i0, i13    
    33 : spill            4, i13          
    34 : add              s6, s6, 4       
    35 : jmp              0               
    36 : __loops_label_2:                 
    37 : sar              s1, s1, 2       
    38 : sar              s2, s2, 2       
    39 : unspill          i13, 1          
    40 : store.i32        i2, i13         
    41 : unspill          i13, 2          
    42 : store.i32        i1, i13         
    43 : mov              i0, 0           
    44 : unspill          i13, 7          
    45 : add              i4, i4, 72      
    46 : ret                              
