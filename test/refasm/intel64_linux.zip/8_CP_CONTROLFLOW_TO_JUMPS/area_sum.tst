area_sum(i0, i1)
     0 : sub              i4, i4, 680       
     1 : spill            83, i13           
     2 : spill            84, i5            
     3 : mov              i5, i4            
     4 : add              i5, i5, 672       
     5 : mov              s80, 0            
     6 : __loops_label_0:                   
     7 : cmp              i6, 0             
     8 : jmp_le           __loops_label_2   
     9 : load.i8          i13, i7           
    10 : spill            81, i13           
    11 : mov              i0, -1655098454   
    12 : mov              i2, -1655098215   
    13 : mov              i1, -1655098042   
    14 : cmp              s81, 1            
    15 : select_eq        i1, i2, i1        
    16 : cmp              s81, 0            
    17 : select_eq        i13, i0, i1       
    18 : spill            82, i13           
    19 : mov              i2, -1655098802   
    20 : mov              i0, -1655098681   
    21 : mov              i1, -1655098618   
    22 : cmp              s81, 1            
    23 : select_eq        i1, i0, i1        
    24 : cmp              s81, 0            
    25 : select_eq        i1, i2, i1        
    26 : unspill          i13, 82           
    27 : call_noret       [i13](i7)         
    28 : spill            82, i13           
    29 : call             [i1](i2, i7)      
    30 : mov              i1, -1655098873   
    31 : unspill          i13, 80           
    32 : call             [i1](i2, i13, i2) 
    33 : mov              s80, i2           
    34 : add              i7, i7, 56        
    35 : sub              i6, i6, 1         
    36 : jmp              0                 
    37 : __loops_label_2:                   
    38 : mov              i0, s80           
    39 : unspill          i5, 84            
    40 : unspill          i13, 83           
    41 : add              i4, i4, 680       
    42 : ret                                
