conditionpainter(i0)
     0 : sub              i4, i4, 56      
     1 : spill            5, i13          
     2 : mov              i13, -5         
     3 : spill            2, i13          
     4 : __loops_label_0:                 
     5 : cmp              s2, 5           
     6 : jmp_gt           __loops_label_2 
     7 : mov              i6, s2          
     8 : add              i6, i6, 5       
     9 : mov              i6, i6          
    10 : mul              i6, i6, 11      
    11 : mov              s1, i6          
    12 : unspill          i13, 1          
    13 : mul              i13, i13, 8     
    14 : spill            1, i13          
    15 : mov              i13, -5         
    16 : spill            0, i13          
    17 : __loops_label_3:                 
    18 : cmp              s0, 5           
    19 : jmp_gt           __loops_label_5 
    20 : mov              i0, s0          
    21 : add              i0, i0, 3       
    22 : mov              i1, 0           
    23 : cmp              s2, i0          
    24 : iverson_ge       i1              
    25 : mov              i0, 0           
    26 : cmp              s2, 4           
    27 : iverson_le       i0              
    28 : mov              i0, i0          
    29 : and              i0, i0, i1      
    30 : mov              i1, 0           
    31 : cmp              s0, -2          
    32 : iverson_ge       i1              
    33 : mov              i1, i1          
    34 : and              i1, i1, i0      
    35 : mov              i0, 0           
    36 : cmp              s0, 0           
    37 : iverson_le       i0              
    38 : mov              i0, i0          
    39 : and              i0, i0, i1      
    40 : unspill          i13, 0          
    41 : sub              i1, i13, 1      
    42 : mov              i2, 0           
    43 : cmp              s2, i1          
    44 : iverson_le       i2              
    45 : mov              i1, 0           
    46 : cmp              s0, 0           
    47 : iverson_ge       i1              
    48 : mov              i1, i1          
    49 : and              i1, i1, i2      
    50 : mov              i2, 0           
    51 : cmp              s2, 0           
    52 : iverson_le       i2              
    53 : mov              i2, i2          
    54 : and              i2, i2, i1      
    55 : mov              i1, s0          
    56 : mul              i1, i1, s0      
    57 : mov              i6, s2          
    58 : mul              i6, i6, s2      
    59 : mov              i6, i6          
    60 : add              i6, i6, i1      
    61 : mov              i1, 0           
    62 : cmp              i6, 9           
    63 : iverson_le       i1              
    64 : mov              i1, i1          
    65 : and              i1, i1, i2      
    66 : mov              s3, i1          
    67 : or               s3, s3, i0      
    68 : mov              i6, 2           
    69 : mov              s4, 0           
    70 : mov              i0, 0           
    71 : cmp              s0, 2           
    72 : iverson_ge       i0              
    73 : mov              i1, 0           
    74 : cmp              s0, 4           
    75 : iverson_le       i1              
    76 : mov              i1, i1          
    77 : and              i1, i1, i0      
    78 : mov              i0, 0           
    79 : cmp              s2, 1           
    80 : iverson_ge       i0              
    81 : mov              i2, 0           
    82 : cmp              s2, 3           
    83 : iverson_le       i2              
    84 : mov              i2, i2          
    85 : and              i2, i2, i0      
    86 : mov              i2, i2          
    87 : or               i2, i2, i1      
    88 : mov              i1, s0          
    89 : mul              i1, i1, s0      
    90 : mov              i0, s2          
    91 : mul              i0, i0, s2      
    92 : mov              i0, i0          
    93 : add              i0, i0, i1      
    94 : mov              i1, 0           
    95 : cmp              i0, 16          
    96 : iverson_le       i1              
    97 : mov              i1, i1          
    98 : and              i1, i1, i2      
    99 : cmp              i1, 0           
   100 : unspill          i13, 4          
   101 : select_ne        i6, i6, i13     
   102 : mov              i6, i6          
   103 : add              i6, i6, s3      
   104 : mov              i2, s2          
   105 : mul              i2, i2, 2       
   106 : cmp              i2, s0          
   107 : jmp_gt           __loops_label_8 
   108 : mov              i2, s0          
   109 : add              i2, i2, 3       
   110 : mov              i2, i2          
   111 : neg              i2, i2          
   112 : mov              i1, s0          
   113 : add              i1, i1, 3       
   114 : mov              i1, i1          
   115 : mul              i1, i1, i2      
   116 : cmp              s2, i1          
   117 : jmp_le           __loops_label_9 
   118 : __loops_label_8:                 
   119 : mov              i2, s0          
   120 : mul              i2, i2, 2       
   121 : cmp              s2, i2          
   122 : jmp_gt           __loops_label_7 
   123 : mov              i2, s0          
   124 : add              i2, i2, 3       
   125 : mov              i2, i2          
   126 : neg              i2, i2          
   127 : mov              i1, s0          
   128 : add              i1, i1, 3       
   129 : mov              i1, i1          
   130 : mul              i1, i1, i2      
   131 : cmp              s2, i1          
   132 : jmp_gt           __loops_label_7 
   133 : __loops_label_9:                 
   134 : cmp              s0, 0           
   135 : jmp_gt           __loops_label_7 
   136 : add              i6, i6, 3       
   137 : __loops_label_7:                 
   138 : mov              i2, s0          
   139 : add              i2, i2, 5       
   140 : mov              i2, i2          
   141 : shl              i2, i2, 3       
   142 : mov              i2, i2          
   143 : add              i2, i2, s1      
   144 : store.i64        i7, i2, i6      
   145 : add              s0, s0, 1       
   146 : jmp              3               
   147 : __loops_label_5:                 
   148 : add              s2, s2, 1       
   149 : jmp              0               
   150 : __loops_label_2:                 
   151 : unspill          i13, 5          
   152 : add              i4, i4, 56      
   153 : ret                              
