nullify_msb_lsb_v(i0, i1, i2, i3)
     0 : sub              i4, i4, 40      
     1 : spill            3, i13          
     2 : mov              s2, 0           
     3 : mov              i1, i1          
     4 : mul              i1, i1, 4       
     5 : mov              i0, 1           
     6 : vdef.u32         v1              
     7 : setlane.u32      v1, 0, i0       
     8 : broadcast.u32    v0, v1, 0       
     9 : spill            1, i1           
    10 : __loops_label_0:                 
    11 : unspill          i13, 1          
    12 : cmp              s2, i13         
    13 : jmp_ge           __loops_label_2 
    14 : unspill          i13, 2          
    15 : vld.u32          v1, i7, i13     
    16 : shr.u32          v2, v1, 1       
    17 : or               v2, v1, v2      
    18 : shr.u32          v3, v2, 2       
    19 : or               v2, v2, v3      
    20 : shr.u32          v3, v2, 4       
    21 : or               v2, v2, v3      
    22 : shr.u32          v3, v2, 8       
    23 : or               v2, v2, v3      
    24 : shr.u32          v3, v2, 16      
    25 : or               v2, v2, v3      
    26 : add.u32          v2, v2, v0      
    27 : shr.u32          v2, v2, 1       
    28 : xor              v2, v2, v1      
    29 : unspill          i13, 2          
    30 : vst.u32          i6, i13, v2     
    31 : sub.u32          v2, v1, v0      
    32 : mov              i0, 255         
    33 : vdef.u8          v3              
    34 : setlane.u8       v3, 0, i0       
    35 : broadcast.u8     v3, v3, 0       
    36 : xor              v2, v2, v3      
    37 : and              v2, v1, v2      
    38 : xor              v1, v2, v1      
    39 : unspill          i13, 2          
    40 : vst.u32          i2, i13, v1     
    41 : add              s2, s2, 32      
    42 : jmp              0               
    43 : __loops_label_2:                 
    44 : unspill          i13, 3          
    45 : add              i4, i4, 40      
    46 : ret                              
