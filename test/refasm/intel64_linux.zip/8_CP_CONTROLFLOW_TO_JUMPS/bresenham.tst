bresenham(i0, i1, i2, i3, i4, i5, i6)
     0 : sub               i4, i4, 104      
     1 : spill             10, i13          
     2 : spill             11, i14          
     3 : spill             9, i9            
     4 : sub               i0, i8, i2       
     5 : mov               i9, i0           
     6 : neg               i9, i9           
     7 : select_s          i13, i0, i9      
     8 : spill             1, i13           
     9 : sub               i0, i8, i2       
    10 : mov               i9, i0           
    11 : mov               i0, i0           
    12 : sar               i0, i0, 63       
    13 : mov               i9, i9           
    14 : neg               i9, i9           
    15 : mov               s2, i0           
    16 : x86_adc           s2, s2, i0       
    17 : unspill           i13, 9           
    18 : sub               i0, i13, i1      
    19 : mov               i9, i0           
    20 : neg               i9, i9           
    21 : select_s          i9, i0, i9       
    22 : mov               s3, i9           
    23 : neg               s3, s3           
    24 : unspill           i13, 9           
    25 : sub               i0, i13, i1      
    26 : mov               i9, i0           
    27 : mov               i0, i0           
    28 : sar               i0, i0, 63       
    29 : mov               i9, i9           
    30 : neg               i9, i9           
    31 : mov               i9, i0           
    32 : x86_adc           i9, i9, i0       
    33 : mov               i13, s1          
    34 : spill             5, i13           
    35 : unspill           i13, 3           
    36 : add               s5, s5, i13      
    37 : spill             4, i9            
    38 : __loops_label_0:                   
    39 : cmp               i7, 0            
    40 : jmp_eq            __loops_label_2  
    41 : mov               s6, i1           
    42 : unspill           i13, 6           
    43 : mul               i13, i13, i6     
    44 : spill             6, i13           
    45 : mov               i13, s6          
    46 : spill             7, i13           
    47 : add               s7, s7, i2       
    48 : unspill           i14, 14          
    49 : unspill           i13, 7           
    50 : store.u8          i7, i13, i14     
    51 : cmp               i2, i8           
    52 : jmp_ne            __loops_label_4  
    53 : cmp               i1, s9           
    54 : jmp_ne            __loops_label_4  
    55 : jmp               2                
    56 : __loops_label_4:                   
    57 : mov               i13, s5          
    58 : spill             8, i13           
    59 : shl               s8, s8, 1        
    60 : unspill           i13, 3           
    61 : cmp               s8, i13          
    62 : jmp_gt            __loops_label_6  
    63 : cmp               i2, i8           
    64 : jmp_ne            __loops_label_8  
    65 : jmp               2                
    66 : __loops_label_8:                   
    67 : unspill           i13, 3           
    68 : add               s5, s5, i13      
    69 : add               i2, i2, s2       
    70 : __loops_label_6:                   
    71 : unspill           i13, 1           
    72 : cmp               s8, i13          
    73 : jmp_gt            __loops_label_10 
    74 : cmp               i1, s9           
    75 : jmp_ne            __loops_label_12 
    76 : jmp               2                
    77 : __loops_label_12:                  
    78 : unspill           i13, 1           
    79 : add               s5, s5, i13      
    80 : add               i1, i1, s4       
    81 : __loops_label_10:                  
    82 : jmp               0                
    83 : __loops_label_2:                   
    84 : unspill           i13, 10          
    85 : unspill           i14, 11          
    86 : add               i4, i4, 104      
    87 : ret                                
