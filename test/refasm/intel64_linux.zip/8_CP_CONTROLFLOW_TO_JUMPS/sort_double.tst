sort_double(i0, i1)
     0 : sub              i4, i4, 696      
     1 : spill            85, i13          
     2 : spill            86, i5           
     3 : mov              i5, i4           
     4 : add              i5, i5, 688      
     5 : mov              s82, i6          
     6 : shl              s82, s82, 3      
     7 : unspill          i13, 82          
     8 : sub              s83, i13, 8      
     9 : mov              s84, 0           
    10 : __loops_label_0:                  
    11 : unspill          i13, 83          
    12 : cmp              s84, i13         
    13 : jmp_ge           __loops_label_2  
    14 : mov              i13, s84         
    15 : spill            81, i13          
    16 : mov              i13, s81         
    17 : spill            80, i13          
    18 : add              s80, s80, 8      
    19 : __loops_label_3:                  
    20 : unspill          i13, 82          
    21 : cmp              s80, i13         
    22 : jmp_ge           __loops_label_5  
    23 : unspill          i13, 80          
    24 : load.fp64        i0, i7, i13      
    25 : unspill          i13, 81          
    26 : load.fp64        i1, i7, i13      
    27 : mov              i2, -1655104486  
    28 : call             [i2](i2, i0, i1) 
    29 : cmp              i2, 0            
    30 : jmp_eq           __loops_label_7  
    31 : mov              i13, s80         
    32 : spill            81, i13          
    33 : __loops_label_7:                  
    34 : add              s80, s80, 8      
    35 : jmp              3                
    36 : __loops_label_5:                  
    37 : unspill          i13, 84          
    38 : cmp              s81, i13         
    39 : jmp_eq           __loops_label_9  
    40 : unspill          i13, 84          
    41 : load.fp64        i2, i7, i13      
    42 : unspill          i13, 81          
    43 : load.fp64        i1, i7, i13      
    44 : unspill          i13, 81          
    45 : store.fp64       i7, i13, i2      
    46 : unspill          i13, 84          
    47 : store.fp64       i7, i13, i1      
    48 : __loops_label_9:                  
    49 : add              s84, s84, 8      
    50 : jmp              0                
    51 : __loops_label_2:                  
    52 : unspill          i5, 86           
    53 : unspill          i13, 85          
    54 : add              i4, i4, 696      
    55 : ret                               
