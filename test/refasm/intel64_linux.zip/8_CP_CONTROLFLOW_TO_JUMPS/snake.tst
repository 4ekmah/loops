snake(i0, i1, i2)
     0 : sub              i4, i4, 744     
     1 : spill            90, i13         
     2 : spill            91, i14         
     3 : spill            92, i5          
     4 : mov              i5, i4          
     5 : add              i5, i5, 736     
     6 : mov              i1, i6          
     7 : add              i1, i1, i2      
     8 : sub              s84, i1, 1      
     9 : mov              i1, 0           
    10 : mov              s83, 1          
    11 : mov              i13, s83        
    12 : spill            80, i13         
    13 : neg              s80, s80        
    14 : mov              s85, 0          
    15 : __loops_label_0:                 
    16 : unspill          i13, 84         
    17 : cmp              s85, i13        
    18 : jmp_ge           __loops_label_2 
    19 : mov              s81, 0          
    20 : mov              s82, 0          
    21 : mov              i0, s85         
    22 : and              i0, i0, 1       
    23 : cmp              i0, 0           
    24 : jmp_eq           __loops_label_4 
    25 : sub              i0, i2, 1       
    26 : cmp              i0, s85         
    27 : unspill          i13, 85         
    28 : select_gt        i14, i0, i13    
    29 : spill            81, i14         
    30 : unspill          i13, 85         
    31 : sub              s86, i13, i0    
    32 : mov              s87, 0          
    33 : cmp              s85, i0         
    34 : unspill          i13, 87         
    35 : select_gt        i14, s86, i13   
    36 : spill            82, i14         
    37 : jmp              5               
    38 : __loops_label_4:                 
    39 : sub              s88, i6, 1      
    40 : unspill          i13, 85         
    41 : sub              i0, i13, s88    
    42 : mov              s89, 0          
    43 : unspill          i13, 88         
    44 : cmp              s85, i13        
    45 : unspill          i13, 89         
    46 : select_gt        i14, i0, i13    
    47 : spill            81, i14         
    48 : unspill          i13, 85         
    49 : cmp              s88, i13        
    50 : unspill          i13, 85         
    51 : select_gt        i14, s88, i13   
    52 : spill            82, i14         
    53 : __loops_label_5:                 
    54 : __loops_label_6:                 
    55 : cmp              s81, 0          
    56 : jmp_gt           __loops_label_8 
    57 : cmp              s81, i2         
    58 : jmp_ge           __loops_label_8 
    59 : cmp              s82, 0          
    60 : jmp_gt           __loops_label_8 
    61 : cmp              s82, i6         
    62 : jmp_ge           __loops_label_8 
    63 : mov              i0, -100345469  
    64 : unspill          i13, 81         
    65 : unspill          i14, 82         
    66 : call_noret       [i0](i13, i14)  
    67 : mov              i0, s82         
    68 : mul              i0, i0, i2      
    69 : mov              i0, i0          
    70 : add              i0, i0, s81     
    71 : store.u8         i7, i0, i1      
    72 : add              i1, i1, 1       
    73 : unspill          i13, 83         
    74 : add              s81, s81, i13   
    75 : unspill          i13, 80         
    76 : add              s82, s82, i13   
    77 : jmp              6               
    78 : __loops_label_8:                 
    79 : neg              s83, s83        
    80 : neg              s80, s80        
    81 : add              s85, s85, 1     
    82 : jmp              0               
    83 : __loops_label_2:                 
    84 : unspill          i5, 92          
    85 : unspill          i13, 90         
    86 : unspill          i14, 91         
    87 : add              i4, i4, 744     
    88 : ret                              
