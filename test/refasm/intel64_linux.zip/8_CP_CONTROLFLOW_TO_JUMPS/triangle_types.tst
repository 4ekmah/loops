triangle_types(i0, i1, i2)
     0 : sub               i4, i4, 40       
     1 : spill             4, i6            
     2 : cmp               i7, 0            
     3 : jmp_le            __loops_label_0  
     4 : cmp               s4, 0            
     5 : jmp_le            __loops_label_0  
     6 : cmp               i2, 0            
     7 : jmp_gt            __loops_label_1  
     8 : __loops_label_0:                   
     9 : mov               i0, 0            
    10 : jmp               18               
    11 : __loops_label_1:                   
    12 : mov               i1, s4           
    13 : add               i1, i1, i2       
    14 : cmp               i7, i1           
    15 : jmp_gt            __loops_label_3  
    16 : mov               i1, i7           
    17 : add               i1, i1, i2       
    18 : cmp               s4, i1           
    19 : jmp_gt            __loops_label_3  
    20 : mov               i1, i7           
    21 : add               i1, i1, s4       
    22 : cmp               i2, i1           
    23 : jmp_le            __loops_label_4  
    24 : __loops_label_3:                   
    25 : mov               i0, 0            
    26 : jmp               18               
    27 : __loops_label_4:                   
    28 : cmp               i7, s4           
    29 : jmp_ne            __loops_label_7  
    30 : cmp               i7, i2           
    31 : jmp_ne            __loops_label_7  
    32 : mov               i0, 2            
    33 : jmp               18               
    34 : __loops_label_7:                   
    35 : cmp               i7, s4           
    36 : jmp_eq            __loops_label_9  
    37 : cmp               i7, i2           
    38 : jmp_eq            __loops_label_9  
    39 : cmp               s4, i2           
    40 : jmp_ne            __loops_label_10 
    41 : __loops_label_9:                   
    42 : mov               i0, 3            
    43 : jmp               18               
    44 : __loops_label_10:                  
    45 : mov               i1, i7           
    46 : mul               i1, i1, i7       
    47 : mov               i0, s4           
    48 : mul               i0, i0, s4       
    49 : mov               i6, i2           
    50 : mul               i6, i6, i2       
    51 : mov               i6, i6           
    52 : add               i6, i6, i0       
    53 : cmp               i1, i6           
    54 : jmp_eq            __loops_label_12 
    55 : mov               i6, s4           
    56 : mul               i6, i6, s4       
    57 : mov               i1, i7           
    58 : mul               i1, i1, i7       
    59 : mov               i0, i2           
    60 : mul               i0, i0, i2       
    61 : mov               i0, i0           
    62 : add               i0, i0, i1       
    63 : cmp               i6, i0           
    64 : jmp_eq            __loops_label_12 
    65 : mov               i6, i2           
    66 : mul               i6, i6, i2       
    67 : mov               i1, i7           
    68 : mul               i1, i1, i7       
    69 : mov               i0, s4           
    70 : mul               i0, i0, s4       
    71 : mov               i0, i0           
    72 : add               i0, i0, i1       
    73 : cmp               i6, i0           
    74 : jmp_ne            __loops_label_13 
    75 : __loops_label_12:                  
    76 : mov               i0, 1            
    77 : jmp               18               
    78 : __loops_label_13:                  
    79 : mov               i6, i7           
    80 : mul               i6, i6, i7       
    81 : mov               i1, s4           
    82 : mul               i1, i1, s4       
    83 : mov               i0, i2           
    84 : mul               i0, i0, i2       
    85 : mov               i0, i0           
    86 : add               i0, i0, i1       
    87 : cmp               i6, i0           
    88 : jmp_gt            __loops_label_15 
    89 : mov               i6, s4           
    90 : mul               i6, i6, s4       
    91 : mov               i1, i7           
    92 : mul               i1, i1, i7       
    93 : mov               i0, i2           
    94 : mul               i0, i0, i2       
    95 : mov               i0, i0           
    96 : add               i0, i0, i1       
    97 : cmp               i6, i0           
    98 : jmp_gt            __loops_label_15 
    99 : mov               i6, i2           
   100 : mul               i6, i6, i2       
   101 : mov               i2, i7           
   102 : mul               i2, i2, i7       
   103 : mov               i7, s4           
   104 : mul               i7, i7, s4       
   105 : mov               i7, i7           
   106 : add               i7, i7, i2       
   107 : cmp               i6, i7           
   108 : jmp_le            __loops_label_16 
   109 : __loops_label_15:                  
   110 : mov               i0, 5            
   111 : jmp               18               
   112 : __loops_label_16:                  
   113 : mov               i0, 4            
   114 : jmp               18               
   115 : __loops_label_2:                   
   116 : __loops_label_5:                   
   117 : __loops_label_8:                   
   118 : __loops_label_11:                  
   119 : __loops_label_14:                  
   120 : __loops_label_17:                  
   121 : __loops_label_18:                  
   122 : add               i4, i4, 40       
   123 : ret                                
