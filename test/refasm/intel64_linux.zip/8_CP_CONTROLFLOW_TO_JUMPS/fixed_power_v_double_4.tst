fixed_power_v_double_4(i0, i1, i2)
     0 : sub              i4, i4, 40      
     1 : mov              i1, 0           
     2 : mov              i2, i2          
     3 : mul              i2, i2, 8       
     4 : mov              i0, i2          
     5 : __loops_label_0:                 
     6 : cmp              i1, i0          
     7 : jmp_ge           __loops_label_2 
     8 : vld.fp64         v0, i7, i1      
     9 : mul.fp64         v0, v0, v0      
    10 : mul.fp64         v0, v0, v0      
    11 : vst.fp64         i6, i1, v0      
    12 : add              i1, i1, 32      
    13 : jmp              0               
    14 : __loops_label_2:                 
    15 : mov              i0, 0           
    16 : add              i4, i4, 40      
    17 : ret                              
