all_loads_all_stores(i0, i1, i2, i3, i4)
     0 : sub               i4, i4, 104      
     1 : spill             11, i13          
     2 : mov               s4, 0            
     3 : mov               s0, 0            
     4 : mov               s1, 0            
     5 : mov               i0, 2            
     6 : mov               s5, 1            
     7 : cmp               i6, 1            
     8 : unspill           i13, 5           
     9 : select_gt         i0, i0, i13      
    10 : mov               s6, 4            
    11 : cmp               i6, 3            
    12 : select_gt         i0, s6, i0       
    13 : mov               s7, 8            
    14 : cmp               i6, 5            
    15 : select_gt         i13, s7, i0      
    16 : spill             2, i13           
    17 : mov               i0, 2            
    18 : mov               s8, 1            
    19 : cmp               i1, 1            
    20 : unspill           i13, 8           
    21 : select_gt         i0, i0, i13      
    22 : mov               s9, 4            
    23 : cmp               i1, 3            
    24 : select_gt         i0, s9, i0       
    25 : mov               s10, 8           
    26 : cmp               i1, 5            
    27 : select_gt         i13, s10, i0     
    28 : spill             3, i13           
    29 : __loops_label_0:                   
    30 : cmp               s4, i8           
    31 : jmp_ge            __loops_label_2  
    32 : def               i0               
    33 : cmp               i6, 0            
    34 : jmp_ne            __loops_label_4  
    35 : unspill           i13, 0           
    36 : load.u8           i0, i7, i13      
    37 : jmp               5                
    38 : __loops_label_4:                   
    39 : cmp               i6, 1            
    40 : jmp_ne            __loops_label_7  
    41 : unspill           i13, 0           
    42 : load.i8           i0, i7, i13      
    43 : jmp               8                
    44 : __loops_label_7:                   
    45 : cmp               i6, 2            
    46 : jmp_ne            __loops_label_10 
    47 : unspill           i13, 0           
    48 : load.u16          i0, i7, i13      
    49 : jmp               11               
    50 : __loops_label_10:                  
    51 : cmp               i6, 3            
    52 : jmp_ne            __loops_label_13 
    53 : unspill           i13, 0           
    54 : load.i16          i0, i7, i13      
    55 : jmp               14               
    56 : __loops_label_13:                  
    57 : cmp               i6, 4            
    58 : jmp_ne            __loops_label_16 
    59 : unspill           i13, 0           
    60 : load.u32          i0, i7, i13      
    61 : jmp               17               
    62 : __loops_label_16:                  
    63 : cmp               i6, 5            
    64 : jmp_ne            __loops_label_19 
    65 : unspill           i13, 0           
    66 : load.i32          i0, i7, i13      
    67 : jmp               20               
    68 : __loops_label_19:                  
    69 : cmp               i6, 6            
    70 : jmp_ne            __loops_label_22 
    71 : unspill           i13, 0           
    72 : load.u64          i0, i7, i13      
    73 : jmp               23               
    74 : __loops_label_22:                  
    75 : unspill           i13, 0           
    76 : load.i64          i0, i7, i13      
    77 : __loops_label_5:                   
    78 : __loops_label_8:                   
    79 : __loops_label_11:                  
    80 : __loops_label_14:                  
    81 : __loops_label_17:                  
    82 : __loops_label_20:                  
    83 : __loops_label_23:                  
    84 : cmp               i1, 0            
    85 : jmp_ne            __loops_label_25 
    86 : unspill           i13, 1           
    87 : store.u8          i2, i13, i0      
    88 : jmp               26               
    89 : __loops_label_25:                  
    90 : cmp               i1, 1            
    91 : jmp_ne            __loops_label_28 
    92 : unspill           i13, 1           
    93 : store.i8          i2, i13, i0      
    94 : jmp               29               
    95 : __loops_label_28:                  
    96 : cmp               i1, 2            
    97 : jmp_ne            __loops_label_31 
    98 : unspill           i13, 1           
    99 : store.u16         i2, i13, i0      
   100 : jmp               32               
   101 : __loops_label_31:                  
   102 : cmp               i1, 3            
   103 : jmp_ne            __loops_label_34 
   104 : unspill           i13, 1           
   105 : store.i16         i2, i13, i0      
   106 : jmp               35               
   107 : __loops_label_34:                  
   108 : cmp               i1, 4            
   109 : jmp_ne            __loops_label_37 
   110 : unspill           i13, 1           
   111 : store.u32         i2, i13, i0      
   112 : jmp               38               
   113 : __loops_label_37:                  
   114 : cmp               i1, 5            
   115 : jmp_ne            __loops_label_40 
   116 : unspill           i13, 1           
   117 : store.i32         i2, i13, i0      
   118 : jmp               41               
   119 : __loops_label_40:                  
   120 : cmp               i1, 6            
   121 : jmp_ne            __loops_label_43 
   122 : unspill           i13, 1           
   123 : store.u64         i2, i13, i0      
   124 : jmp               44               
   125 : __loops_label_43:                  
   126 : unspill           i13, 1           
   127 : store.i64         i2, i13, i0      
   128 : __loops_label_26:                  
   129 : __loops_label_29:                  
   130 : __loops_label_32:                  
   131 : __loops_label_35:                  
   132 : __loops_label_38:                  
   133 : __loops_label_41:                  
   134 : __loops_label_44:                  
   135 : unspill           i13, 2           
   136 : add               s0, s0, i13      
   137 : unspill           i13, 3           
   138 : add               s1, s1, i13      
   139 : add               s4, s4, 1        
   140 : jmp               0                
   141 : __loops_label_2:                   
   142 : unspill           i13, 11          
   143 : add               i4, i4, 104      
   144 : ret                                
