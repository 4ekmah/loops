nonnegative_odd(i0, i1)
     0 : sub              i4, i4, 72      
     1 : spill            8, i13          
     2 : mov              i2, 0           
     3 : mov              i13, -4         
     4 : spill            5, i13          
     5 : mov              s4, i6          
     6 : unspill          i13, 4          
     7 : mul              i13, i13, 4     
     8 : spill            4, i13          
     9 : __loops_label_0:                 
    10 : cmp              i2, s4          
    11 : jmp_ge           __loops_label_2 
    12 : load.i32         i1, i7, i2      
    13 : cmp              i1, 0           
    14 : jmp_ge           __loops_label_4 
    15 : add              i2, i2, 4       
    16 : jmp              0               
    17 : __loops_label_4:                 
    18 : mov              i0, 2           
    19 : spill            7, i2           
    20 : spill            6, i0           
    21 : mov              i0, i1          
    22 : mod              i2, i0, s6      
    23 : mov              i1, i2          
    24 : unspill          i2, 7           
    25 : cmp              i1, 0           
    26 : jmp_eq           __loops_label_6 
    27 : mov              s5, i2          
    28 : jmp              2               
    29 : __loops_label_6:                 
    30 : add              i2, i2, 4       
    31 : jmp              0               
    32 : __loops_label_2:                 
    33 : mov              i1, 4           
    34 : mov              i7, s5          
    35 : mov              i0, i7          
    36 : div              i0, i0, i1      
    37 : mov              i7, i0          
    38 : mov              i0, i7          
    39 : unspill          i13, 8          
    40 : add              i4, i4, 72      
    41 : ret                              
