sibling_loops(i0, i1, i2)
     0 : sub              i4, i4, 24      
     1 : spill            1, i13          
     2 : mov              i1, 0           
     3 : mov              s0, 0           
     4 : __loops_label_0:                 
     5 : cmp              i1, i6          
     6 : jmp_ge           __loops_label_2 
     7 : load.i32         i0, i7, i1      
     8 : add              s0, s0, i0      
     9 : add              i1, i1, 4       
    10 : jmp              0               
    11 : __loops_label_2:                 
    12 : mov              i0, 0           
    13 : __loops_label_3:                 
    14 : cmp              i1, 0           
    15 : jmp_le           __loops_label_5 
    16 : add              i0, i0, 1       
    17 : sub              i1, i1, 4       
    18 : jmp              3               
    19 : __loops_label_5:                 
    20 : unspill          i13, 0          
    21 : store.i32        i2, i13         
    22 : store.i32        i2, 4, i0       
    23 : mov              i0, 0           
    24 : unspill          i13, 1          
    25 : add              i4, i4, 24      
    26 : ret                              
