fixed_power_v_float_0(i0, i1, i2)
     0 : sub          rsp, 0x018                    ; 48 81 ec 18 00 00 00     
     1 : xor          rcx, rcx                      ; 48 31 c9                 
     2 : imul         rdx, 0x004                    ; 48 6b d2 04              
     3 : mov          qword ptr [rsp + 0x008], rdx  ; 48 89 94 24 08 00 00 00  
     4 :              __loops_label_0:              ;                          
     5 : cmp          rcx, qword ptr [rsp + 0x008]  ; 48 3b 8c 24 08 00 00 00  
     6 : jge          __loops_label_2               ; 0f 8d 28 00 00 00        
     7 : vmovups      ymm0, ymmword ptr [rdi + rcx] ; c5 fc 10 04 0f           
     8 : mov          rax, 0x03f800000              ; 48 c7 c0 00 00 80 3f     
     9 : vpinsrd      xmm0, xmm0, eax, 0            ; c4 e3 79 22 c0 00        
    10 : vpbroadcastd ymm0, xmm0                    ; c4 e2 7d 58 c0           
    11 : vmovups      ymmword ptr [rsi + rcx], ymm0 ; c5 fc 11 04 0e           
    12 : add          rcx, 0x020                    ; 48 81 c1 20 00 00 00     
    13 : jmp          __loops_label_0               ; e9 ca ff ff ff           
    14 :              __loops_label_2:              ;                          
    15 : xor          rax, rax                      ; 48 31 c0                 
    16 : add          rsp, 0x018                    ; 48 81 c4 18 00 00 00     
    17 : ret                                        ; c3                       
