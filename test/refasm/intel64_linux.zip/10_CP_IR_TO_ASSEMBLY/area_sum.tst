area_sum(i0, i1)
     0 : sub     rsp, 0x02a8                       ; 48 81 ec a8 02 00 00                 
     1 : mov     qword ptr [rsp + 0x0298], r13     ; 4c 89 ac 24 98 02 00 00              
     2 : mov     qword ptr [rsp + 0x02a0], rbp     ; 48 89 ac 24 a0 02 00 00              
     3 : mov     rbp, rsp                          ; 48 89 e5                             
     4 : add     rbp, 0x02a0                       ; 48 81 c5 a0 02 00 00                 
     5 : mov     qword ptr [rsp + 0x0280], 0       ; 48 c7 84 24 80 02 00 00 00 00 00 00  
     6 :         __loops_label_0:                  ;                                      
     7 : cmp     rsi, 0                            ; 48 83 fe 00                          
     8 : jle     __loops_label_2                   ; 0f 8e e3 05 00 00                    
     9 : movsx   r13, byte ptr [rdi]               ; 4c 0f be 2f                          
    10 : mov     qword ptr [rsp + 0x0288], r13     ; 4c 89 ac 24 88 02 00 00              
    11 : mov     rax, 0x056049d5933aa              ; 48 b8 aa 33 59 9d 04 56 00 00        
    12 : mov     rdx, 0x056049d593499              ; 48 ba 99 34 59 9d 04 56 00 00        
    13 : mov     rcx, 0x056049d593546              ; 48 b9 46 35 59 9d 04 56 00 00        
    14 : cmp     qword ptr [rsp + 0x0288], 0x001   ; 48 81 bc 24 88 02 00 00 01 00 00 00  
    15 : cmove   rcx, rdx                          ; 48 0f 44 ca                          
    16 : cmp     qword ptr [rsp + 0x0288], 0       ; 48 81 bc 24 88 02 00 00 00 00 00 00  
    17 : mov     r13, rcx                          ; 49 89 cd                             
    18 : cmove   r13, rax                          ; 4c 0f 44 e8                          
    19 : mov     qword ptr [rsp + 0x0290], r13     ; 4c 89 ac 24 90 02 00 00              
    20 : mov     rdx, 0x056049d59324e              ; 48 ba 4e 32 59 9d 04 56 00 00        
    21 : mov     rax, 0x056049d5932c7              ; 48 b8 c7 32 59 9d 04 56 00 00        
    22 : mov     rcx, 0x056049d593306              ; 48 b9 06 33 59 9d 04 56 00 00        
    23 : cmp     qword ptr [rsp + 0x0288], 0x001   ; 48 81 bc 24 88 02 00 00 01 00 00 00  
    24 : cmove   rcx, rax                          ; 48 0f 44 c8                          
    25 : cmp     qword ptr [rsp + 0x0288], 0       ; 48 81 bc 24 88 02 00 00 00 00 00 00  
    26 : cmove   rcx, rdx                          ; 48 0f 44 ca                          
    27 : mov     r13, qword ptr [rsp + 0x0290]     ; 4c 8b ac 24 90 02 00 00              
    28 : mov     qword ptr [rsp], rax              ; 48 89 84 24 00 00 00 00              
    29 : mov     qword ptr [rsp + 0x008], rcx      ; 48 89 8c 24 08 00 00 00              
    30 : mov     qword ptr [rsp + 0x010], rdx      ; 48 89 94 24 10 00 00 00              
    31 : mov     qword ptr [rsp + 0x018], rsi      ; 48 89 b4 24 18 00 00 00              
    32 : mov     qword ptr [rsp + 0x020], rdi      ; 48 89 bc 24 20 00 00 00              
    33 : mov     qword ptr [rsp + 0x028], r8       ; 4c 89 84 24 28 00 00 00              
    34 : mov     qword ptr [rsp + 0x030], r9       ; 4c 89 8c 24 30 00 00 00              
    35 : mov     qword ptr [rsp + 0x038], r10      ; 4c 89 94 24 38 00 00 00              
    36 : mov     qword ptr [rsp + 0x040], r11      ; 4c 89 9c 24 40 00 00 00              
    37 : vmovdqu ymmword ptr [rsp + 0x060], ymm0   ; c5 fe 7f 84 24 60 00 00 00           
    38 : vmovdqu ymmword ptr [rsp + 0x080], ymm1   ; c5 fe 7f 8c 24 80 00 00 00           
    39 : vmovdqu ymmword ptr [rsp + 0x0a0], ymm2   ; c5 fe 7f 94 24 a0 00 00 00           
    40 : vmovdqu ymmword ptr [rsp + 0x0c0], ymm3   ; c5 fe 7f 9c 24 c0 00 00 00           
    41 : vmovdqu ymmword ptr [rsp + 0x0e0], ymm4   ; c5 fe 7f a4 24 e0 00 00 00           
    42 : vmovdqu ymmword ptr [rsp + 0x0100], ymm5  ; c5 fe 7f ac 24 00 01 00 00           
    43 : vmovdqu ymmword ptr [rsp + 0x0120], ymm6  ; c5 fe 7f b4 24 20 01 00 00           
    44 : vmovdqu ymmword ptr [rsp + 0x0140], ymm7  ; c5 fe 7f bc 24 40 01 00 00           
    45 : vmovdqu ymmword ptr [rsp + 0x0160], ymm8  ; c5 7e 7f 84 24 60 01 00 00           
    46 : vmovdqu ymmword ptr [rsp + 0x0180], ymm9  ; c5 7e 7f 8c 24 80 01 00 00           
    47 : vmovdqu ymmword ptr [rsp + 0x01a0], ymm10 ; c5 7e 7f 94 24 a0 01 00 00           
    48 : vmovdqu ymmword ptr [rsp + 0x01c0], ymm11 ; c5 7e 7f 9c 24 c0 01 00 00           
    49 : vmovdqu ymmword ptr [rsp + 0x01e0], ymm12 ; c5 7e 7f a4 24 e0 01 00 00           
    50 : vmovdqu ymmword ptr [rsp + 0x0200], ymm13 ; c5 7e 7f ac 24 00 02 00 00           
    51 : vmovdqu ymmword ptr [rsp + 0x0220], ymm14 ; c5 7e 7f b4 24 20 02 00 00           
    52 : vmovdqu ymmword ptr [rsp + 0x0240], ymm15 ; c5 7e 7f bc 24 40 02 00 00           
    53 : call    r13                               ; 41 ff d5                             
    54 : mov     rax, qword ptr [rsp]              ; 48 8b 84 24 00 00 00 00              
    55 : mov     rcx, qword ptr [rsp + 0x008]      ; 48 8b 8c 24 08 00 00 00              
    56 : mov     rdx, qword ptr [rsp + 0x010]      ; 48 8b 94 24 10 00 00 00              
    57 : mov     rsi, qword ptr [rsp + 0x018]      ; 48 8b b4 24 18 00 00 00              
    58 : mov     rdi, qword ptr [rsp + 0x020]      ; 48 8b bc 24 20 00 00 00              
    59 : mov     r8, qword ptr [rsp + 0x028]       ; 4c 8b 84 24 28 00 00 00              
    60 : mov     r9, qword ptr [rsp + 0x030]       ; 4c 8b 8c 24 30 00 00 00              
    61 : mov     r10, qword ptr [rsp + 0x038]      ; 4c 8b 94 24 38 00 00 00              
    62 : mov     r11, qword ptr [rsp + 0x040]      ; 4c 8b 9c 24 40 00 00 00              
    63 : vmovdqu ymm0, ymmword ptr [rsp + 0x060]   ; c5 fe 6f 84 24 60 00 00 00           
    64 : vmovdqu ymm1, ymmword ptr [rsp + 0x080]   ; c5 fe 6f 8c 24 80 00 00 00           
    65 : vmovdqu ymm2, ymmword ptr [rsp + 0x0a0]   ; c5 fe 6f 94 24 a0 00 00 00           
    66 : vmovdqu ymm3, ymmword ptr [rsp + 0x0c0]   ; c5 fe 6f 9c 24 c0 00 00 00           
    67 : vmovdqu ymm4, ymmword ptr [rsp + 0x0e0]   ; c5 fe 6f a4 24 e0 00 00 00           
    68 : vmovdqu ymm5, ymmword ptr [rsp + 0x0100]  ; c5 fe 6f ac 24 00 01 00 00           
    69 : vmovdqu ymm6, ymmword ptr [rsp + 0x0120]  ; c5 fe 6f b4 24 20 01 00 00           
    70 : vmovdqu ymm7, ymmword ptr [rsp + 0x0140]  ; c5 fe 6f bc 24 40 01 00 00           
    71 : vmovdqu ymm8, ymmword ptr [rsp + 0x0160]  ; c5 7e 6f 84 24 60 01 00 00           
    72 : vmovdqu ymm9, ymmword ptr [rsp + 0x0180]  ; c5 7e 6f 8c 24 80 01 00 00           
    73 : vmovdqu ymm10, ymmword ptr [rsp + 0x01a0] ; c5 7e 6f 94 24 a0 01 00 00           
    74 : vmovdqu ymm11, ymmword ptr [rsp + 0x01c0] ; c5 7e 6f 9c 24 c0 01 00 00           
    75 : vmovdqu ymm12, ymmword ptr [rsp + 0x01e0] ; c5 7e 6f a4 24 e0 01 00 00           
    76 : vmovdqu ymm13, ymmword ptr [rsp + 0x0200] ; c5 7e 6f ac 24 00 02 00 00           
    77 : vmovdqu ymm14, ymmword ptr [rsp + 0x0220] ; c5 7e 6f b4 24 20 02 00 00           
    78 : vmovdqu ymm15, ymmword ptr [rsp + 0x0240] ; c5 7e 6f bc 24 40 02 00 00           
    79 : mov     qword ptr [rsp + 0x0290], r13     ; 4c 89 ac 24 90 02 00 00              
    80 : mov     qword ptr [rsp], rax              ; 48 89 84 24 00 00 00 00              
    81 : mov     qword ptr [rsp + 0x008], rcx      ; 48 89 8c 24 08 00 00 00              
    82 : mov     qword ptr [rsp + 0x010], rdx      ; 48 89 94 24 10 00 00 00              
    83 : mov     qword ptr [rsp + 0x018], rsi      ; 48 89 b4 24 18 00 00 00              
    84 : mov     qword ptr [rsp + 0x020], rdi      ; 48 89 bc 24 20 00 00 00              
    85 : mov     qword ptr [rsp + 0x028], r8       ; 4c 89 84 24 28 00 00 00              
    86 : mov     qword ptr [rsp + 0x030], r9       ; 4c 89 8c 24 30 00 00 00              
    87 : mov     qword ptr [rsp + 0x038], r10      ; 4c 89 94 24 38 00 00 00              
    88 : mov     qword ptr [rsp + 0x040], r11      ; 4c 89 9c 24 40 00 00 00              
    89 : vmovdqu ymmword ptr [rsp + 0x060], ymm0   ; c5 fe 7f 84 24 60 00 00 00           
    90 : vmovdqu ymmword ptr [rsp + 0x080], ymm1   ; c5 fe 7f 8c 24 80 00 00 00           
    91 : vmovdqu ymmword ptr [rsp + 0x0a0], ymm2   ; c5 fe 7f 94 24 a0 00 00 00           
    92 : vmovdqu ymmword ptr [rsp + 0x0c0], ymm3   ; c5 fe 7f 9c 24 c0 00 00 00           
    93 : vmovdqu ymmword ptr [rsp + 0x0e0], ymm4   ; c5 fe 7f a4 24 e0 00 00 00           
    94 : vmovdqu ymmword ptr [rsp + 0x0100], ymm5  ; c5 fe 7f ac 24 00 01 00 00           
    95 : vmovdqu ymmword ptr [rsp + 0x0120], ymm6  ; c5 fe 7f b4 24 20 01 00 00           
    96 : vmovdqu ymmword ptr [rsp + 0x0140], ymm7  ; c5 fe 7f bc 24 40 01 00 00           
    97 : vmovdqu ymmword ptr [rsp + 0x0160], ymm8  ; c5 7e 7f 84 24 60 01 00 00           
    98 : vmovdqu ymmword ptr [rsp + 0x0180], ymm9  ; c5 7e 7f 8c 24 80 01 00 00           
    99 : vmovdqu ymmword ptr [rsp + 0x01a0], ymm10 ; c5 7e 7f 94 24 a0 01 00 00           
   100 : vmovdqu ymmword ptr [rsp + 0x01c0], ymm11 ; c5 7e 7f 9c 24 c0 01 00 00           
   101 : vmovdqu ymmword ptr [rsp + 0x01e0], ymm12 ; c5 7e 7f a4 24 e0 01 00 00           
   102 : vmovdqu ymmword ptr [rsp + 0x0200], ymm13 ; c5 7e 7f ac 24 00 02 00 00           
   103 : vmovdqu ymmword ptr [rsp + 0x0220], ymm14 ; c5 7e 7f b4 24 20 02 00 00           
   104 : vmovdqu ymmword ptr [rsp + 0x0240], ymm15 ; c5 7e 7f bc 24 40 02 00 00           
   105 : call    rcx                               ; ff d1                                
   106 : mov     rdx, rax                          ; 48 89 c2                             
   107 : mov     rax, qword ptr [rsp]              ; 48 8b 84 24 00 00 00 00              
   108 : mov     rcx, qword ptr [rsp + 0x008]      ; 48 8b 8c 24 08 00 00 00              
   109 : mov     rsi, qword ptr [rsp + 0x018]      ; 48 8b b4 24 18 00 00 00              
   110 : mov     rdi, qword ptr [rsp + 0x020]      ; 48 8b bc 24 20 00 00 00              
   111 : mov     r8, qword ptr [rsp + 0x028]       ; 4c 8b 84 24 28 00 00 00              
   112 : mov     r9, qword ptr [rsp + 0x030]       ; 4c 8b 8c 24 30 00 00 00              
   113 : mov     r10, qword ptr [rsp + 0x038]      ; 4c 8b 94 24 38 00 00 00              
   114 : mov     r11, qword ptr [rsp + 0x040]      ; 4c 8b 9c 24 40 00 00 00              
   115 : vmovdqu ymm0, ymmword ptr [rsp + 0x060]   ; c5 fe 6f 84 24 60 00 00 00           
   116 : vmovdqu ymm1, ymmword ptr [rsp + 0x080]   ; c5 fe 6f 8c 24 80 00 00 00           
   117 : vmovdqu ymm2, ymmword ptr [rsp + 0x0a0]   ; c5 fe 6f 94 24 a0 00 00 00           
   118 : vmovdqu ymm3, ymmword ptr [rsp + 0x0c0]   ; c5 fe 6f 9c 24 c0 00 00 00           
   119 : vmovdqu ymm4, ymmword ptr [rsp + 0x0e0]   ; c5 fe 6f a4 24 e0 00 00 00           
   120 : vmovdqu ymm5, ymmword ptr [rsp + 0x0100]  ; c5 fe 6f ac 24 00 01 00 00           
   121 : vmovdqu ymm6, ymmword ptr [rsp + 0x0120]  ; c5 fe 6f b4 24 20 01 00 00           
   122 : vmovdqu ymm7, ymmword ptr [rsp + 0x0140]  ; c5 fe 6f bc 24 40 01 00 00           
   123 : vmovdqu ymm8, ymmword ptr [rsp + 0x0160]  ; c5 7e 6f 84 24 60 01 00 00           
   124 : vmovdqu ymm9, ymmword ptr [rsp + 0x0180]  ; c5 7e 6f 8c 24 80 01 00 00           
   125 : vmovdqu ymm10, ymmword ptr [rsp + 0x01a0] ; c5 7e 6f 94 24 a0 01 00 00           
   126 : vmovdqu ymm11, ymmword ptr [rsp + 0x01c0] ; c5 7e 6f 9c 24 c0 01 00 00           
   127 : vmovdqu ymm12, ymmword ptr [rsp + 0x01e0] ; c5 7e 6f a4 24 e0 01 00 00           
   128 : vmovdqu ymm13, ymmword ptr [rsp + 0x0200] ; c5 7e 6f ac 24 00 02 00 00           
   129 : vmovdqu ymm14, ymmword ptr [rsp + 0x0220] ; c5 7e 6f b4 24 20 02 00 00           
   130 : vmovdqu ymm15, ymmword ptr [rsp + 0x0240] ; c5 7e 6f bc 24 40 02 00 00           
   131 : mov     rcx, 0x056049d593207              ; 48 b9 07 32 59 9d 04 56 00 00        
   132 : mov     r13, qword ptr [rsp + 0x0280]     ; 4c 8b ac 24 80 02 00 00              
   133 : mov     qword ptr [rsp], rax              ; 48 89 84 24 00 00 00 00              
   134 : mov     qword ptr [rsp + 0x008], rcx      ; 48 89 8c 24 08 00 00 00              
   135 : mov     qword ptr [rsp + 0x010], rdx      ; 48 89 94 24 10 00 00 00              
   136 : mov     qword ptr [rsp + 0x018], rsi      ; 48 89 b4 24 18 00 00 00              
   137 : mov     qword ptr [rsp + 0x020], rdi      ; 48 89 bc 24 20 00 00 00              
   138 : mov     qword ptr [rsp + 0x028], r8       ; 4c 89 84 24 28 00 00 00              
   139 : mov     qword ptr [rsp + 0x030], r9       ; 4c 89 8c 24 30 00 00 00              
   140 : mov     qword ptr [rsp + 0x038], r10      ; 4c 89 94 24 38 00 00 00              
   141 : mov     qword ptr [rsp + 0x040], r11      ; 4c 89 9c 24 40 00 00 00              
   142 : vmovdqu ymmword ptr [rsp + 0x060], ymm0   ; c5 fe 7f 84 24 60 00 00 00           
   143 : vmovdqu ymmword ptr [rsp + 0x080], ymm1   ; c5 fe 7f 8c 24 80 00 00 00           
   144 : vmovdqu ymmword ptr [rsp + 0x0a0], ymm2   ; c5 fe 7f 94 24 a0 00 00 00           
   145 : vmovdqu ymmword ptr [rsp + 0x0c0], ymm3   ; c5 fe 7f 9c 24 c0 00 00 00           
   146 : vmovdqu ymmword ptr [rsp + 0x0e0], ymm4   ; c5 fe 7f a4 24 e0 00 00 00           
   147 : vmovdqu ymmword ptr [rsp + 0x0100], ymm5  ; c5 fe 7f ac 24 00 01 00 00           
   148 : vmovdqu ymmword ptr [rsp + 0x0120], ymm6  ; c5 fe 7f b4 24 20 01 00 00           
   149 : vmovdqu ymmword ptr [rsp + 0x0140], ymm7  ; c5 fe 7f bc 24 40 01 00 00           
   150 : vmovdqu ymmword ptr [rsp + 0x0160], ymm8  ; c5 7e 7f 84 24 60 01 00 00           
   151 : vmovdqu ymmword ptr [rsp + 0x0180], ymm9  ; c5 7e 7f 8c 24 80 01 00 00           
   152 : vmovdqu ymmword ptr [rsp + 0x01a0], ymm10 ; c5 7e 7f 94 24 a0 01 00 00           
   153 : vmovdqu ymmword ptr [rsp + 0x01c0], ymm11 ; c5 7e 7f 9c 24 c0 01 00 00           
   154 : vmovdqu ymmword ptr [rsp + 0x01e0], ymm12 ; c5 7e 7f a4 24 e0 01 00 00           
   155 : vmovdqu ymmword ptr [rsp + 0x0200], ymm13 ; c5 7e 7f ac 24 00 02 00 00           
   156 : vmovdqu ymmword ptr [rsp + 0x0220], ymm14 ; c5 7e 7f b4 24 20 02 00 00           
   157 : vmovdqu ymmword ptr [rsp + 0x0240], ymm15 ; c5 7e 7f bc 24 40 02 00 00           
   158 : mov     rdi, r13                          ; 4c 89 ef                             
   159 : mov     rsi, rdx                          ; 48 89 d6                             
   160 : call    rcx                               ; ff d1                                
   161 : mov     rdx, rax                          ; 48 89 c2                             
   162 : mov     rax, qword ptr [rsp]              ; 48 8b 84 24 00 00 00 00              
   163 : mov     rcx, qword ptr [rsp + 0x008]      ; 48 8b 8c 24 08 00 00 00              
   164 : mov     rsi, qword ptr [rsp + 0x018]      ; 48 8b b4 24 18 00 00 00              
   165 : mov     rdi, qword ptr [rsp + 0x020]      ; 48 8b bc 24 20 00 00 00              
   166 : mov     r8, qword ptr [rsp + 0x028]       ; 4c 8b 84 24 28 00 00 00              
   167 : mov     r9, qword ptr [rsp + 0x030]       ; 4c 8b 8c 24 30 00 00 00              
   168 : mov     r10, qword ptr [rsp + 0x038]      ; 4c 8b 94 24 38 00 00 00              
   169 : mov     r11, qword ptr [rsp + 0x040]      ; 4c 8b 9c 24 40 00 00 00              
   170 : vmovdqu ymm0, ymmword ptr [rsp + 0x060]   ; c5 fe 6f 84 24 60 00 00 00           
   171 : vmovdqu ymm1, ymmword ptr [rsp + 0x080]   ; c5 fe 6f 8c 24 80 00 00 00           
   172 : vmovdqu ymm2, ymmword ptr [rsp + 0x0a0]   ; c5 fe 6f 94 24 a0 00 00 00           
   173 : vmovdqu ymm3, ymmword ptr [rsp + 0x0c0]   ; c5 fe 6f 9c 24 c0 00 00 00           
   174 : vmovdqu ymm4, ymmword ptr [rsp + 0x0e0]   ; c5 fe 6f a4 24 e0 00 00 00           
   175 : vmovdqu ymm5, ymmword ptr [rsp + 0x0100]  ; c5 fe 6f ac 24 00 01 00 00           
   176 : vmovdqu ymm6, ymmword ptr [rsp + 0x0120]  ; c5 fe 6f b4 24 20 01 00 00           
   177 : vmovdqu ymm7, ymmword ptr [rsp + 0x0140]  ; c5 fe 6f bc 24 40 01 00 00           
   178 : vmovdqu ymm8, ymmword ptr [rsp + 0x0160]  ; c5 7e 6f 84 24 60 01 00 00           
   179 : vmovdqu ymm9, ymmword ptr [rsp + 0x0180]  ; c5 7e 6f 8c 24 80 01 00 00           
   180 : vmovdqu ymm10, ymmword ptr [rsp + 0x01a0] ; c5 7e 6f 94 24 a0 01 00 00           
   181 : vmovdqu ymm11, ymmword ptr [rsp + 0x01c0] ; c5 7e 6f 9c 24 c0 01 00 00           
   182 : vmovdqu ymm12, ymmword ptr [rsp + 0x01e0] ; c5 7e 6f a4 24 e0 01 00 00           
   183 : vmovdqu ymm13, ymmword ptr [rsp + 0x0200] ; c5 7e 6f ac 24 00 02 00 00           
   184 : vmovdqu ymm14, ymmword ptr [rsp + 0x0220] ; c5 7e 6f b4 24 20 02 00 00           
   185 : vmovdqu ymm15, ymmword ptr [rsp + 0x0240] ; c5 7e 6f bc 24 40 02 00 00           
   186 : mov     qword ptr [rsp + 0x0280], rdx     ; 48 89 94 24 80 02 00 00              
   187 : add     rdi, 0x038                        ; 48 81 c7 38 00 00 00                 
   188 : sub     rsi, 0x001                        ; 48 81 ee 01 00 00 00                 
   189 : jmp     __loops_label_0                   ; e9 13 fa ff ff                       
   190 :         __loops_label_2:                  ;                                      
   191 : mov     rax, qword ptr [rsp + 0x0280]     ; 48 8b 84 24 80 02 00 00              
   192 : mov     rbp, qword ptr [rsp + 0x02a0]     ; 48 8b ac 24 a0 02 00 00              
   193 : mov     r13, qword ptr [rsp + 0x0298]     ; 4c 8b ac 24 98 02 00 00              
   194 : add     rsp, 0x02a8                       ; 48 81 c4 a8 02 00 00                 
   195 : ret                                       ; c3                                   
