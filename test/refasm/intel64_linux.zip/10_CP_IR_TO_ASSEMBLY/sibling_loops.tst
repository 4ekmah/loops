sibling_loops(i0, i1, i2)
     0 : sub    rsp, 0x018                   ; 48 81 ec 18 00 00 00                 
     1 : mov    qword ptr [rsp + 0x008], r13 ; 4c 89 ac 24 08 00 00 00              
     2 : xor    rcx, rcx                     ; 48 31 c9                             
     3 : mov    qword ptr [rsp], 0           ; 48 c7 84 24 00 00 00 00 00 00 00 00  
     4 :        __loops_label_0:             ;                                      
     5 : cmp    rcx, rsi                     ; 48 39 f1                             
     6 : jge    __loops_label_2              ; 0f 8d 18 00 00 00                    
     7 : movsxd rax, dword ptr [rdi + rcx]   ; 48 63 04 0f                          
     8 : add    qword ptr [rsp], rax         ; 48 01 84 24 00 00 00 00              
     9 : add    rcx, 0x004                   ; 48 81 c1 04 00 00 00                 
    10 : jmp    __loops_label_0              ; e9 df ff ff ff                       
    11 :        __loops_label_2:             ;                                      
    12 : xor    rax, rax                     ; 48 31 c0                             
    13 :        __loops_label_3:             ;                                      
    14 : cmp    rcx, 0                       ; 48 83 f9 00                          
    15 : jle    __loops_label_5              ; 0f 8e 12 00 00 00                    
    16 : add    rax, 0x001                   ; 48 05 01 00 00 00                    
    17 : sub    rcx, 0x004                   ; 48 81 e9 04 00 00 00                 
    18 : jmp    __loops_label_3              ; e9 e4 ff ff ff                       
    19 :        __loops_label_5:             ;                                      
    20 : mov    r13, qword ptr [rsp]         ; 4c 8b ac 24 00 00 00 00              
    21 : mov    dword ptr [rdx], r13d        ; 44 89 2a                             
    22 : mov    dword ptr [rdx + 0x004], eax ; 89 82 04 00 00 00                    
    23 : xor    rax, rax                     ; 48 31 c0                             
    24 : mov    r13, qword ptr [rsp + 0x008] ; 4c 8b ac 24 08 00 00 00              
    25 : add    rsp, 0x018                   ; 48 81 c4 18 00 00 00                 
    26 : ret                                 ; c3                                   
