nonnegative_odd(i0, i1)
     0 : sub    rsp, 0x038                   ; 48 81 ec 38 00 00 00     
     1 : mov    qword ptr [rsp + 0x028], r13 ; 4c 89 ac 24 28 00 00 00  
     2 : xor    rdx, rdx                     ; 48 31 d2                 
     3 : mov    r13, 0x0fffffffffffffffc     ; 49 c7 c5 fc ff ff ff     
     4 : mov    qword ptr [rsp + 0x010], r13 ; 4c 89 ac 24 10 00 00 00  
     5 : mov    qword ptr [rsp + 0x008], rsi ; 48 89 b4 24 08 00 00 00  
     6 : mov    r13, qword ptr [rsp + 0x008] ; 4c 8b ac 24 08 00 00 00  
     7 : imul   r13, 0x004                   ; 4d 6b ed 04              
     8 : mov    qword ptr [rsp + 0x008], r13 ; 4c 89 ac 24 08 00 00 00  
     9 :        __loops_label_0:             ;                          
    10 : cmp    rdx, qword ptr [rsp + 0x008] ; 48 3b 94 24 08 00 00 00  
    11 : jge    __loops_label_2              ; 0f 8d 6c 00 00 00        
    12 : movsxd rcx, dword ptr [rdi + rdx]   ; 48 63 0c 17              
    13 : cmp    rcx, 0                       ; 48 83 f9 00              
    14 : jge    __loops_label_4              ; 0f 8d 0c 00 00 00        
    15 : add    rdx, 0x004                   ; 48 81 c2 04 00 00 00     
    16 : jmp    __loops_label_0              ; e9 d8 ff ff ff           
    17 :        __loops_label_4:             ;                          
    18 : mov    rax, 0x002                   ; 48 c7 c0 02 00 00 00     
    19 : mov    qword ptr [rsp + 0x020], rdx ; 48 89 94 24 20 00 00 00  
    20 : mov    qword ptr [rsp + 0x018], rax ; 48 89 84 24 18 00 00 00  
    21 : mov    rax, rcx                     ; 48 89 c8                 
    22 : cqo                                 ; 48 99                    
    23 : idiv   qword ptr [rsp + 0x018]      ; 48 f7 bc 24 18 00 00 00  
    24 : mov    rcx, rdx                     ; 48 89 d1                 
    25 : mov    rdx, qword ptr [rsp + 0x020] ; 48 8b 94 24 20 00 00 00  
    26 : cmp    rcx, 0                       ; 48 83 f9 00              
    27 : je     __loops_label_6              ; 0f 84 0d 00 00 00        
    28 : mov    qword ptr [rsp + 0x010], rdx ; 48 89 94 24 10 00 00 00  
    29 : jmp    __loops_label_2              ; e9 0c 00 00 00           
    30 :        __loops_label_6:             ;                          
    31 : add    rdx, 0x004                   ; 48 81 c2 04 00 00 00     
    32 : jmp    __loops_label_0              ; e9 86 ff ff ff           
    33 :        __loops_label_2:             ;                          
    34 : mov    rcx, 0x004                   ; 48 c7 c1 04 00 00 00     
    35 : mov    rdi, qword ptr [rsp + 0x010] ; 48 8b bc 24 10 00 00 00  
    36 : mov    rax, rdi                     ; 48 89 f8                 
    37 : cqo                                 ; 48 99                    
    38 : idiv   rcx                          ; 48 f7 f9                 
    39 : mov    rdi, rax                     ; 48 89 c7                 
    40 : mov    rax, rdi                     ; 48 89 f8                 
    41 : mov    r13, qword ptr [rsp + 0x028] ; 4c 8b ac 24 28 00 00 00  
    42 : add    rsp, 0x038                   ; 48 81 c4 38 00 00 00     
    43 : ret                                 ; c3                       
