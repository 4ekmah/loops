has_in_join_cascade(i0, i1, i2)
     0 : sub    rsp, 0x078                     ; 48 81 ec 78 00 00 00                 
     1 : mov    qword ptr [rsp + 0x068], r13   ; 4c 89 ac 24 68 00 00 00              
     2 : mov    qword ptr [rsp + 0x070], r14   ; 4c 89 b4 24 70 00 00 00              
     3 : mov    qword ptr [rsp + 0x028], 0     ; 48 c7 84 24 28 00 00 00 00 00 00 00  
     4 : mov    r13, qword ptr [rdi + 0x010]   ; 4c 8b af 10 00 00 00                 
     5 : mov    qword ptr [rsp + 0x030], r13   ; 4c 89 ac 24 30 00 00 00              
     6 : mov    r13, qword ptr [rdi + 0]       ; 4c 8b af 00 00 00 00                 
     7 : mov    qword ptr [rsp + 0x038], r13   ; 4c 89 ac 24 38 00 00 00              
     8 : mov    r13, qword ptr [rdi + 0x008]   ; 4c 8b af 08 00 00 00                 
     9 : mov    qword ptr [rsp + 0x040], r13   ; 4c 89 ac 24 40 00 00 00              
    10 :        __loops_label_0:               ;                                      
    11 : cmp    qword ptr [rsp + 0x030], 0     ; 48 81 bc 24 30 00 00 00 00 00 00 00  
    12 : jle    __loops_label_2                ; 0f 8e c3 01 00 00                    
    13 : mov    r13, qword ptr [rsp + 0x038]   ; 4c 8b ac 24 38 00 00 00              
    14 : movsxd r14, dword ptr [r13]           ; 4d 63 75 00                          
    15 : mov    qword ptr [rsp + 0x048], r14   ; 4c 89 b4 24 48 00 00 00              
    16 : add    qword ptr [rsp + 0x038], 0x004 ; 48 81 84 24 38 00 00 00 04 00 00 00  
    17 : mov    r13, qword ptr [rsp + 0x040]   ; 4c 8b ac 24 40 00 00 00              
    18 : movsxd r14, dword ptr [r13]           ; 4d 63 75 00                          
    19 : mov    qword ptr [rsp + 0x020], r14   ; 4c 89 b4 24 20 00 00 00              
    20 : add    qword ptr [rsp + 0x040], 0x004 ; 48 81 84 24 40 00 00 00 04 00 00 00  
    21 : sub    qword ptr [rsp + 0x030], 0x001 ; 48 81 ac 24 30 00 00 00 01 00 00 00  
    22 : mov    r13, qword ptr [rdi + 0x028]   ; 4c 8b af 28 00 00 00                 
    23 : mov    qword ptr [rsp + 0x050], r13   ; 4c 89 ac 24 50 00 00 00              
    24 : mov    r13, qword ptr [rdi + 0x018]   ; 4c 8b af 18 00 00 00                 
    25 : mov    qword ptr [rsp + 0x058], r13   ; 4c 89 ac 24 58 00 00 00              
    26 : mov    r13, qword ptr [rdi + 0x020]   ; 4c 8b af 20 00 00 00                 
    27 : mov    qword ptr [rsp + 0x060], r13   ; 4c 89 ac 24 60 00 00 00              
    28 :        __loops_label_3:               ;                                      
    29 : cmp    qword ptr [rsp + 0x050], 0     ; 48 81 bc 24 50 00 00 00 00 00 00 00  
    30 : jle    __loops_label_5                ; 0f 8e 33 01 00 00                    
    31 : mov    r13, qword ptr [rsp + 0x058]   ; 4c 8b ac 24 58 00 00 00              
    32 : movsxd r14, dword ptr [r13]           ; 4d 63 75 00                          
    33 : mov    qword ptr [rsp], r14           ; 4c 89 b4 24 00 00 00 00              
    34 : add    qword ptr [rsp + 0x058], 0x004 ; 48 81 84 24 58 00 00 00 04 00 00 00  
    35 : mov    r13, qword ptr [rsp + 0x060]   ; 4c 8b ac 24 60 00 00 00              
    36 : movsxd rcx, dword ptr [r13]           ; 49 63 4d 00                          
    37 : add    qword ptr [rsp + 0x060], 0x004 ; 48 81 84 24 60 00 00 00 04 00 00 00  
    38 : sub    qword ptr [rsp + 0x050], 0x001 ; 48 81 ac 24 50 00 00 00 01 00 00 00  
    39 : cmp    rcx, qword ptr [rsp + 0x048]   ; 48 3b 8c 24 48 00 00 00              
    40 : jle    __loops_label_7                ; 0f 8e 05 00 00 00                    
    41 : jmp    __loops_label_0                ; e9 0c ff ff ff                       
    42 :        __loops_label_7:               ;                                      
    43 : cmp    rcx, qword ptr [rsp + 0x048]   ; 48 3b 8c 24 48 00 00 00              
    44 : jne    __loops_label_10               ; 0f 85 c9 00 00 00                    
    45 : mov    r13, qword ptr [rdi + 0x040]   ; 4c 8b af 40 00 00 00                 
    46 : mov    qword ptr [rsp + 0x008], r13   ; 4c 89 ac 24 08 00 00 00              
    47 : mov    r13, qword ptr [rdi + 0x030]   ; 4c 8b af 30 00 00 00                 
    48 : mov    qword ptr [rsp + 0x010], r13   ; 4c 89 ac 24 10 00 00 00              
    49 : mov    r13, qword ptr [rdi + 0x038]   ; 4c 8b af 38 00 00 00                 
    50 : mov    qword ptr [rsp + 0x018], r13   ; 4c 89 ac 24 18 00 00 00              
    51 :        __loops_label_11:              ;                                      
    52 : cmp    qword ptr [rsp + 0x008], 0     ; 48 81 bc 24 08 00 00 00 00 00 00 00  
    53 : jle    __loops_label_10               ; 0f 8e 8a 00 00 00                    
    54 : mov    r13, qword ptr [rsp + 0x010]   ; 4c 8b ac 24 10 00 00 00              
    55 : movsxd rax, dword ptr [r13]           ; 49 63 45 00                          
    56 : add    qword ptr [rsp + 0x010], 0x004 ; 48 81 84 24 10 00 00 00 04 00 00 00  
    57 : mov    r13, qword ptr [rsp + 0x018]   ; 4c 8b ac 24 18 00 00 00              
    58 : movsxd rcx, dword ptr [r13]           ; 49 63 4d 00                          
    59 : add    qword ptr [rsp + 0x018], 0x004 ; 48 81 84 24 18 00 00 00 04 00 00 00  
    60 : sub    qword ptr [rsp + 0x008], 0x001 ; 48 81 ac 24 08 00 00 00 01 00 00 00  
    61 : cmp    rax, qword ptr [rsp + 0x020]   ; 48 3b 84 24 20 00 00 00              
    62 : jle    __loops_label_15               ; 0f 8e 05 00 00 00                    
    63 : jmp    __loops_label_0                ; e9 70 fe ff ff                       
    64 :        __loops_label_15:              ;                                      
    65 : cmp    rax, qword ptr [rsp + 0x020]   ; 48 3b 84 24 20 00 00 00              
    66 : jne    __loops_label_18               ; 0f 85 28 00 00 00                    
    67 : cmp    qword ptr [rsp], rsi           ; 48 39 b4 24 00 00 00 00              
    68 : jne    __loops_label_18               ; 0f 85 1a 00 00 00                    
    69 : cmp    rcx, rdx                       ; 48 39 d1                             
    70 : jne    __loops_label_18               ; 0f 85 11 00 00 00                    
    71 : mov    qword ptr [rsp + 0x028], 0x001 ; 48 c7 84 24 28 00 00 00 01 00 00 00  
    72 : jmp    __loops_label_2                ; e9 0f 00 00 00                       
    73 :        __loops_label_16:              ;                                      
    74 :        __loops_label_18:              ;                                      
    75 : jmp    __loops_label_11               ; e9 64 ff ff ff                       
    76 :        __loops_label_13:              ;                                      
    77 :        __loops_label_8:               ;                                      
    78 :        __loops_label_10:              ;                                      
    79 : jmp    __loops_label_3                ; e9 bb fe ff ff                       
    80 :        __loops_label_5:               ;                                      
    81 : jmp    __loops_label_0                ; e9 2b fe ff ff                       
    82 :        __loops_label_2:               ;                                      
    83 : mov    rax, qword ptr [rsp + 0x028]   ; 48 8b 84 24 28 00 00 00              
    84 : mov    r13, qword ptr [rsp + 0x068]   ; 4c 8b ac 24 68 00 00 00              
    85 : mov    r14, qword ptr [rsp + 0x070]   ; 4c 8b b4 24 70 00 00 00              
    86 : add    rsp, 0x078                     ; 48 81 c4 78 00 00 00                 
    87 : ret                                   ; c3                                   
