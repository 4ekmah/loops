triangle_types(i0, i1, i2)
     0 : sub  rsp, 0x018                   ; 48 81 ec 18 00 00 00                 
     1 : mov  qword ptr [rsp + 0x008], rsi ; 48 89 b4 24 08 00 00 00              
     2 : cmp  rdi, 0                       ; 48 83 ff 00                          
     3 : jle  __loops_label_0              ; 0f 8e 1c 00 00 00                    
     4 : cmp  qword ptr [rsp + 0x008], 0   ; 48 81 bc 24 08 00 00 00 00 00 00 00  
     5 : jle  __loops_label_0              ; 0f 8e 0a 00 00 00                    
     6 : cmp  rdx, 0                       ; 48 83 fa 00                          
     7 : jg   __loops_label_1              ; 0f 8f 08 00 00 00                    
     8 :      __loops_label_0:             ;                                      
     9 : xor  rax, rax                     ; 48 31 c0                             
    10 : jmp  __loops_label_18             ; e9 be 01 00 00                       
    11 :      __loops_label_1:             ;                                      
    12 : mov  rcx, qword ptr [rsp + 0x008] ; 48 8b 8c 24 08 00 00 00              
    13 : add  rcx, rdx                     ; 48 01 d1                             
    14 : cmp  rdi, rcx                     ; 48 39 cf                             
    15 : jg   __loops_label_3              ; 0f 8f 28 00 00 00                    
    16 : mov  rcx, rdi                     ; 48 89 f9                             
    17 : add  rcx, rdx                     ; 48 01 d1                             
    18 : cmp  qword ptr [rsp + 0x008], rcx ; 48 39 8c 24 08 00 00 00              
    19 : jg   __loops_label_3              ; 0f 8f 14 00 00 00                    
    20 : mov  rcx, rdi                     ; 48 89 f9                             
    21 : add  rcx, qword ptr [rsp + 0x008] ; 48 03 8c 24 08 00 00 00              
    22 : cmp  rdx, rcx                     ; 48 39 ca                             
    23 : jle  __loops_label_4              ; 0f 8e 08 00 00 00                    
    24 :      __loops_label_3:             ;                                      
    25 : xor  rax, rax                     ; 48 31 c0                             
    26 : jmp  __loops_label_18             ; e9 7a 01 00 00                       
    27 :      __loops_label_4:             ;                                      
    28 : cmp  rdi, qword ptr [rsp + 0x008] ; 48 3b bc 24 08 00 00 00              
    29 : jne  __loops_label_7              ; 0f 85 15 00 00 00                    
    30 : cmp  rdi, rdx                     ; 48 39 d7                             
    31 : jne  __loops_label_7              ; 0f 85 0c 00 00 00                    
    32 : mov  rax, 0x002                   ; 48 c7 c0 02 00 00 00                 
    33 : jmp  __loops_label_18             ; e9 57 01 00 00                       
    34 :      __loops_label_7:             ;                                      
    35 : cmp  rdi, qword ptr [rsp + 0x008] ; 48 3b bc 24 08 00 00 00              
    36 : je   __loops_label_9              ; 0f 84 17 00 00 00                    
    37 : cmp  rdi, rdx                     ; 48 39 d7                             
    38 : je   __loops_label_9              ; 0f 84 0e 00 00 00                    
    39 : cmp  qword ptr [rsp + 0x008], rdx ; 48 39 94 24 08 00 00 00              
    40 : jne  __loops_label_10             ; 0f 85 0c 00 00 00                    
    41 :      __loops_label_9:             ;                                      
    42 : mov  rax, 0x003                   ; 48 c7 c0 03 00 00 00                 
    43 : jmp  __loops_label_18             ; e9 26 01 00 00                       
    44 :      __loops_label_10:            ;                                      
    45 : mov  rcx, rdi                     ; 48 89 f9                             
    46 : imul rcx, rdi                     ; 48 0f af cf                          
    47 : mov  rax, qword ptr [rsp + 0x008] ; 48 8b 84 24 08 00 00 00              
    48 : imul rax, qword ptr [rsp + 0x008] ; 48 0f af 84 24 08 00 00 00           
    49 : mov  rsi, rdx                     ; 48 89 d6                             
    50 : imul rsi, rdx                     ; 48 0f af f2                          
    51 : add  rsi, rax                     ; 48 01 c6                             
    52 : cmp  rcx, rsi                     ; 48 39 f1                             
    53 : je   __loops_label_12             ; 0f 84 56 00 00 00                    
    54 : mov  rsi, qword ptr [rsp + 0x008] ; 48 8b b4 24 08 00 00 00              
    55 : imul rsi, qword ptr [rsp + 0x008] ; 48 0f af b4 24 08 00 00 00           
    56 : mov  rcx, rdi                     ; 48 89 f9                             
    57 : imul rcx, rdi                     ; 48 0f af cf                          
    58 : mov  rax, rdx                     ; 48 89 d0                             
    59 : imul rax, rdx                     ; 48 0f af c2                          
    60 : add  rax, rcx                     ; 48 01 c8                             
    61 : cmp  rsi, rax                     ; 48 39 c6                             
    62 : je   __loops_label_12             ; 0f 84 2b 00 00 00                    
    63 : mov  rsi, rdx                     ; 48 89 d6                             
    64 : imul rsi, rdx                     ; 48 0f af f2                          
    65 : mov  rcx, rdi                     ; 48 89 f9                             
    66 : imul rcx, rdi                     ; 48 0f af cf                          
    67 : mov  rax, qword ptr [rsp + 0x008] ; 48 8b 84 24 08 00 00 00              
    68 : imul rax, qword ptr [rsp + 0x008] ; 48 0f af 84 24 08 00 00 00           
    69 : add  rax, rcx                     ; 48 01 c8                             
    70 : cmp  rsi, rax                     ; 48 39 c6                             
    71 : jne  __loops_label_13             ; 0f 85 0c 00 00 00                    
    72 :      __loops_label_12:            ;                                      
    73 : mov  rax, 0x001                   ; 48 c7 c0 01 00 00 00                 
    74 : jmp  __loops_label_18             ; e9 99 00 00 00                       
    75 :      __loops_label_13:            ;                                      
    76 : mov  rsi, rdi                     ; 48 89 fe                             
    77 : imul rsi, rdi                     ; 48 0f af f7                          
    78 : mov  rcx, qword ptr [rsp + 0x008] ; 48 8b 8c 24 08 00 00 00              
    79 : imul rcx, qword ptr [rsp + 0x008] ; 48 0f af 8c 24 08 00 00 00           
    80 : mov  rax, rdx                     ; 48 89 d0                             
    81 : imul rax, rdx                     ; 48 0f af c2                          
    82 : add  rax, rcx                     ; 48 01 c8                             
    83 : cmp  rsi, rax                     ; 48 39 c6                             
    84 : jg   __loops_label_15             ; 0f 8f 56 00 00 00                    
    85 : mov  rsi, qword ptr [rsp + 0x008] ; 48 8b b4 24 08 00 00 00              
    86 : imul rsi, qword ptr [rsp + 0x008] ; 48 0f af b4 24 08 00 00 00           
    87 : mov  rcx, rdi                     ; 48 89 f9                             
    88 : imul rcx, rdi                     ; 48 0f af cf                          
    89 : mov  rax, rdx                     ; 48 89 d0                             
    90 : imul rax, rdx                     ; 48 0f af c2                          
    91 : add  rax, rcx                     ; 48 01 c8                             
    92 : cmp  rsi, rax                     ; 48 39 c6                             
    93 : jg   __loops_label_15             ; 0f 8f 2b 00 00 00                    
    94 : mov  rsi, rdx                     ; 48 89 d6                             
    95 : imul rsi, rdx                     ; 48 0f af f2                          
    96 : mov  rdx, rdi                     ; 48 89 fa                             
    97 : imul rdx, rdi                     ; 48 0f af d7                          
    98 : mov  rdi, qword ptr [rsp + 0x008] ; 48 8b bc 24 08 00 00 00              
    99 : imul rdi, qword ptr [rsp + 0x008] ; 48 0f af bc 24 08 00 00 00           
   100 : add  rdi, rdx                     ; 48 01 d7                             
   101 : cmp  rsi, rdi                     ; 48 39 fe                             
   102 : jle  __loops_label_16             ; 0f 8e 0c 00 00 00                    
   103 :      __loops_label_15:            ;                                      
   104 : mov  rax, 0x005                   ; 48 c7 c0 05 00 00 00                 
   105 : jmp  __loops_label_18             ; e9 0c 00 00 00                       
   106 :      __loops_label_16:            ;                                      
   107 : mov  rax, 0x004                   ; 48 c7 c0 04 00 00 00                 
   108 : jmp  __loops_label_18             ; e9 00 00 00 00                       
   109 :      __loops_label_2:             ;                                      
   110 :      __loops_label_5:             ;                                      
   111 :      __loops_label_8:             ;                                      
   112 :      __loops_label_11:            ;                                      
   113 :      __loops_label_14:            ;                                      
   114 :      __loops_label_17:            ;                                      
   115 :      __loops_label_18:            ;                                      
   116 : add  rsp, 0x018                   ; 48 81 c4 18 00 00 00                 
   117 : ret                               ; c3                                   
