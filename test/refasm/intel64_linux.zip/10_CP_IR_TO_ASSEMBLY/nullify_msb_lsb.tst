nullify_msb_lsb(i0, i1, i2)
     0 : mov rcx, rdi             ; 48 89 f9              
     1 : shr rcx, 0x001           ; 48 c1 e9 01           
     2 : or  rcx, rdi             ; 48 09 f9              
     3 : mov rax, rcx             ; 48 89 c8              
     4 : shr rax, 0x002           ; 48 c1 e8 02           
     5 : or  rax, rcx             ; 48 09 c8              
     6 : mov rcx, rax             ; 48 89 c1              
     7 : shr rcx, 0x004           ; 48 c1 e9 04           
     8 : or  rcx, rax             ; 48 09 c1              
     9 : mov rax, rcx             ; 48 89 c8              
    10 : shr rax, 0x008           ; 48 c1 e8 08           
    11 : or  rax, rcx             ; 48 09 c8              
    12 : mov rcx, rax             ; 48 89 c1              
    13 : shr rcx, 0x010           ; 48 c1 e9 10           
    14 : or  rcx, rax             ; 48 09 c1              
    15 : mov rax, rcx             ; 48 89 c8              
    16 : shr rax, 0x020           ; 48 c1 e8 20           
    17 : or  rax, rcx             ; 48 09 c8              
    18 : add rax, 0x001           ; 48 05 01 00 00 00     
    19 : shr rax, 0x001           ; 48 c1 e8 01           
    20 : xor rax, rdi             ; 48 31 f8              
    21 : mov qword ptr [rdx], rax ; 48 89 02              
    22 : mov rdx, rdi             ; 48 89 fa              
    23 : sub rdx, 0x001           ; 48 81 ea 01 00 00 00  
    24 : not rdx                  ; 48 f7 d2              
    25 : and rdx, rdi             ; 48 21 fa              
    26 : xor rdi, rdx             ; 48 31 d7              
    27 : mov qword ptr [rsi], rdi ; 48 89 3e              
    28 : ret                      ; c3                    
