bresenham(i0, i1, i2, i3, i4, i5, i6)
     0 : sub   rsp, 0x078                     ; 48 81 ec 78 00 00 00        
     1 : mov   qword ptr [rsp + 0x068], r13   ; 4c 89 ac 24 68 00 00 00     
     2 : mov   qword ptr [rsp + 0x070], r14   ; 4c 89 b4 24 70 00 00 00     
     3 : mov   qword ptr [rsp + 0x060], r9    ; 4c 89 8c 24 60 00 00 00     
     4 : mov   rax, r8                        ; 4c 89 c0                    
     5 : sub   rax, rdx                       ; 48 29 d0                    
     6 : mov   r9, rax                        ; 49 89 c1                    
     7 : neg   r9                             ; 49 f7 d9                    
     8 : mov   r13, r9                        ; 4d 89 cd                    
     9 : cmovs r13, rax                       ; 4c 0f 48 e8                 
    10 : mov   qword ptr [rsp + 0x020], r13   ; 4c 89 ac 24 20 00 00 00     
    11 : mov   rax, r8                        ; 4c 89 c0                    
    12 : sub   rax, rdx                       ; 48 29 d0                    
    13 : mov   r9, rax                        ; 49 89 c1                    
    14 : sar   rax, 0x03f                     ; 48 c1 f8 3f                 
    15 : neg   r9                             ; 49 f7 d9                    
    16 : mov   qword ptr [rsp + 0x028], rax   ; 48 89 84 24 28 00 00 00     
    17 : adc   qword ptr [rsp + 0x028], rax   ; 48 11 84 24 28 00 00 00     
    18 : mov   r13, qword ptr [rsp + 0x060]   ; 4c 8b ac 24 60 00 00 00     
    19 : mov   rax, r13                       ; 4c 89 e8                    
    20 : sub   rax, rcx                       ; 48 29 c8                    
    21 : mov   r9, rax                        ; 49 89 c1                    
    22 : neg   r9                             ; 49 f7 d9                    
    23 : cmovs r9, rax                        ; 4c 0f 48 c8                 
    24 : mov   qword ptr [rsp + 0x030], r9    ; 4c 89 8c 24 30 00 00 00     
    25 : neg   qword ptr [rsp + 0x030]        ; 48 f7 9c 24 30 00 00 00     
    26 : mov   r13, qword ptr [rsp + 0x060]   ; 4c 8b ac 24 60 00 00 00     
    27 : mov   rax, r13                       ; 4c 89 e8                    
    28 : sub   rax, rcx                       ; 48 29 c8                    
    29 : mov   r9, rax                        ; 49 89 c1                    
    30 : sar   rax, 0x03f                     ; 48 c1 f8 3f                 
    31 : neg   r9                             ; 49 f7 d9                    
    32 : mov   r9, rax                        ; 49 89 c1                    
    33 : adc   r9, rax                        ; 49 11 c1                    
    34 : mov   r13, qword ptr [rsp + 0x020]   ; 4c 8b ac 24 20 00 00 00     
    35 : mov   qword ptr [rsp + 0x040], r13   ; 4c 89 ac 24 40 00 00 00     
    36 : mov   r13, qword ptr [rsp + 0x030]   ; 4c 8b ac 24 30 00 00 00     
    37 : add   qword ptr [rsp + 0x040], r13   ; 4c 01 ac 24 40 00 00 00     
    38 : mov   qword ptr [rsp + 0x038], r9    ; 4c 89 8c 24 38 00 00 00     
    39 :       __loops_label_0:               ;                             
    40 : cmp   rdi, 0                         ; 48 83 ff 00                 
    41 : je    __loops_label_2                ; 0f 84 ff 00 00 00           
    42 : mov   qword ptr [rsp + 0x048], rcx   ; 48 89 8c 24 48 00 00 00     
    43 : mov   r13, qword ptr [rsp + 0x048]   ; 4c 8b ac 24 48 00 00 00     
    44 : imul  r13, rsi                       ; 4c 0f af ee                 
    45 : mov   qword ptr [rsp + 0x048], r13   ; 4c 89 ac 24 48 00 00 00     
    46 : mov   r13, qword ptr [rsp + 0x048]   ; 4c 8b ac 24 48 00 00 00     
    47 : mov   qword ptr [rsp + 0x050], r13   ; 4c 89 ac 24 50 00 00 00     
    48 : add   qword ptr [rsp + 0x050], rdx   ; 48 01 94 24 50 00 00 00     
    49 : mov   r14, qword ptr [rsp + 0x080]   ; 4c 8b b4 24 80 00 00 00     
    50 : mov   r13, qword ptr [rsp + 0x050]   ; 4c 8b ac 24 50 00 00 00     
    51 : mov   byte ptr [rdi + r13], r14b     ; 46 88 34 2f                 
    52 : cmp   rdx, r8                        ; 4c 39 c2                    
    53 : jne   __loops_label_4                ; 0f 85 13 00 00 00           
    54 : cmp   rcx, qword ptr [rsp + 0x060]   ; 48 3b 8c 24 60 00 00 00     
    55 : jne   __loops_label_4                ; 0f 85 05 00 00 00           
    56 : jmp   __loops_label_2                ; e9 9b 00 00 00              
    57 :       __loops_label_4:               ;                             
    58 : mov   r13, qword ptr [rsp + 0x040]   ; 4c 8b ac 24 40 00 00 00     
    59 : mov   qword ptr [rsp + 0x058], r13   ; 4c 89 ac 24 58 00 00 00     
    60 : shl   qword ptr [rsp + 0x058], 0x001 ; 48 c1 a4 24 58 00 00 00 01  
    61 : mov   r13, qword ptr [rsp + 0x030]   ; 4c 8b ac 24 30 00 00 00     
    62 : cmp   qword ptr [rsp + 0x058], r13   ; 4c 39 ac 24 58 00 00 00     
    63 : jl    __loops_label_6                ; 0f 8c 26 00 00 00           
    64 : cmp   rdx, r8                        ; 4c 39 c2                    
    65 : jne   __loops_label_8                ; 0f 85 05 00 00 00           
    66 : jmp   __loops_label_2                ; e9 5e 00 00 00              
    67 :       __loops_label_8:               ;                             
    68 : mov   r13, qword ptr [rsp + 0x030]   ; 4c 8b ac 24 30 00 00 00     
    69 : add   qword ptr [rsp + 0x040], r13   ; 4c 01 ac 24 40 00 00 00     
    70 : add   rdx, qword ptr [rsp + 0x028]   ; 48 03 94 24 28 00 00 00     
    71 :       __loops_label_6:               ;                             
    72 : mov   r13, qword ptr [rsp + 0x020]   ; 4c 8b ac 24 20 00 00 00     
    73 : cmp   qword ptr [rsp + 0x058], r13   ; 4c 39 ac 24 58 00 00 00     
    74 : jg    __loops_label_10               ; 0f 8f 2b 00 00 00           
    75 : cmp   rcx, qword ptr [rsp + 0x060]   ; 48 3b 8c 24 60 00 00 00     
    76 : jne   __loops_label_12               ; 0f 85 05 00 00 00           
    77 : jmp   __loops_label_2                ; e9 1d 00 00 00              
    78 :       __loops_label_12:              ;                             
    79 : mov   r13, qword ptr [rsp + 0x020]   ; 4c 8b ac 24 20 00 00 00     
    80 : add   qword ptr [rsp + 0x040], r13   ; 4c 01 ac 24 40 00 00 00     
    81 : add   rcx, qword ptr [rsp + 0x038]   ; 48 03 8c 24 38 00 00 00     
    82 :       __loops_label_10:              ;                             
    83 : jmp   __loops_label_0                ; e9 f7 fe ff ff              
    84 :       __loops_label_2:               ;                             
    85 : mov   r13, qword ptr [rsp + 0x068]   ; 4c 8b ac 24 68 00 00 00     
    86 : mov   r14, qword ptr [rsp + 0x070]   ; 4c 8b b4 24 70 00 00 00     
    87 : add   rsp, 0x078                     ; 48 81 c4 78 00 00 00        
    88 : ret                                  ; c3                          
