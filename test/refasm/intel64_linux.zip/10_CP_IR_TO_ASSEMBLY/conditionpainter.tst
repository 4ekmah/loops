conditionpainter(i0)
     0 : sub   rsp, 0x038                           ; 48 81 ec 38 00 00 00                 
     1 : mov   qword ptr [rsp + 0x028], r13         ; 4c 89 ac 24 28 00 00 00              
     2 : mov   r13, 0x0fffffffffffffffb             ; 49 c7 c5 fb ff ff ff                 
     3 : mov   qword ptr [rsp + 0x010], r13         ; 4c 89 ac 24 10 00 00 00              
     4 :       __loops_label_0:                     ;                                      
     5 : cmp   qword ptr [rsp + 0x010], 0x005       ; 48 81 bc 24 10 00 00 00 05 00 00 00  
     6 : jg    __loops_label_2                      ; 0f 8f d9 02 00 00                    
     7 : mov   rsi, qword ptr [rsp + 0x010]         ; 48 8b b4 24 10 00 00 00              
     8 : add   rsi, 0x005                           ; 48 81 c6 05 00 00 00                 
     9 : imul  rsi, 0x00b                           ; 48 6b f6 0b                          
    10 : mov   qword ptr [rsp + 0x008], rsi         ; 48 89 b4 24 08 00 00 00              
    11 : mov   r13, qword ptr [rsp + 0x008]         ; 4c 8b ac 24 08 00 00 00              
    12 : imul  r13, 0x008                           ; 4d 6b ed 08                          
    13 : mov   qword ptr [rsp + 0x008], r13         ; 4c 89 ac 24 08 00 00 00              
    14 : mov   r13, 0x0fffffffffffffffb             ; 49 c7 c5 fb ff ff ff                 
    15 : mov   qword ptr [rsp], r13                 ; 4c 89 ac 24 00 00 00 00              
    16 :       __loops_label_3:                     ;                                      
    17 : cmp   qword ptr [rsp], 0x005               ; 48 81 bc 24 00 00 00 00 05 00 00 00  
    18 : jg    __loops_label_5                      ; 0f 8f 78 02 00 00                    
    19 : mov   rax, qword ptr [rsp]                 ; 48 8b 84 24 00 00 00 00              
    20 : add   rax, 0x003                           ; 48 05 03 00 00 00                    
    21 : xor   rcx, rcx                             ; 48 31 c9                             
    22 : cmp   qword ptr [rsp + 0x010], rax         ; 48 39 84 24 10 00 00 00              
    23 : setge cl                                   ; 0f 9d c1                             
    24 : xor   rax, rax                             ; 48 31 c0                             
    25 : cmp   qword ptr [rsp + 0x010], 0x004       ; 48 81 bc 24 10 00 00 00 04 00 00 00  
    26 : setle al                                   ; 0f 9e c0                             
    27 : and   rax, rcx                             ; 48 21 c8                             
    28 : xor   rcx, rcx                             ; 48 31 c9                             
    29 : cmp   qword ptr [rsp], 0x0fffffffffffffffe ; 48 81 bc 24 00 00 00 00 fe ff ff ff  
    30 : setge cl                                   ; 0f 9d c1                             
    31 : and   rcx, rax                             ; 48 21 c1                             
    32 : xor   rax, rax                             ; 48 31 c0                             
    33 : cmp   qword ptr [rsp], 0                   ; 48 81 bc 24 00 00 00 00 00 00 00 00  
    34 : setle al                                   ; 0f 9e c0                             
    35 : and   rax, rcx                             ; 48 21 c8                             
    36 : mov   r13, qword ptr [rsp]                 ; 4c 8b ac 24 00 00 00 00              
    37 : mov   rcx, r13                             ; 4c 89 e9                             
    38 : sub   rcx, 0x001                           ; 48 81 e9 01 00 00 00                 
    39 : xor   rdx, rdx                             ; 48 31 d2                             
    40 : cmp   qword ptr [rsp + 0x010], rcx         ; 48 39 8c 24 10 00 00 00              
    41 : setle dl                                   ; 0f 9e c2                             
    42 : xor   rcx, rcx                             ; 48 31 c9                             
    43 : cmp   qword ptr [rsp], 0                   ; 48 81 bc 24 00 00 00 00 00 00 00 00  
    44 : setge cl                                   ; 0f 9d c1                             
    45 : and   rcx, rdx                             ; 48 21 d1                             
    46 : xor   rdx, rdx                             ; 48 31 d2                             
    47 : cmp   qword ptr [rsp + 0x010], 0           ; 48 81 bc 24 10 00 00 00 00 00 00 00  
    48 : setle dl                                   ; 0f 9e c2                             
    49 : and   rdx, rcx                             ; 48 21 ca                             
    50 : mov   rcx, qword ptr [rsp]                 ; 48 8b 8c 24 00 00 00 00              
    51 : imul  rcx, qword ptr [rsp]                 ; 48 0f af 8c 24 00 00 00 00           
    52 : mov   rsi, qword ptr [rsp + 0x010]         ; 48 8b b4 24 10 00 00 00              
    53 : imul  rsi, qword ptr [rsp + 0x010]         ; 48 0f af b4 24 10 00 00 00           
    54 : add   rsi, rcx                             ; 48 01 ce                             
    55 : xor   rcx, rcx                             ; 48 31 c9                             
    56 : cmp   rsi, 0x009                           ; 48 83 fe 09                          
    57 : setle cl                                   ; 0f 9e c1                             
    58 : and   rcx, rdx                             ; 48 21 d1                             
    59 : mov   qword ptr [rsp + 0x018], rcx         ; 48 89 8c 24 18 00 00 00              
    60 : or    qword ptr [rsp + 0x018], rax         ; 48 09 84 24 18 00 00 00              
    61 : mov   rsi, 0x002                           ; 48 c7 c6 02 00 00 00                 
    62 : mov   qword ptr [rsp + 0x020], 0           ; 48 c7 84 24 20 00 00 00 00 00 00 00  
    63 : xor   rax, rax                             ; 48 31 c0                             
    64 : cmp   qword ptr [rsp], 0x002               ; 48 81 bc 24 00 00 00 00 02 00 00 00  
    65 : setge al                                   ; 0f 9d c0                             
    66 : xor   rcx, rcx                             ; 48 31 c9                             
    67 : cmp   qword ptr [rsp], 0x004               ; 48 81 bc 24 00 00 00 00 04 00 00 00  
    68 : setle cl                                   ; 0f 9e c1                             
    69 : and   rcx, rax                             ; 48 21 c1                             
    70 : xor   rax, rax                             ; 48 31 c0                             
    71 : cmp   qword ptr [rsp + 0x010], 0x001       ; 48 81 bc 24 10 00 00 00 01 00 00 00  
    72 : setge al                                   ; 0f 9d c0                             
    73 : xor   rdx, rdx                             ; 48 31 d2                             
    74 : cmp   qword ptr [rsp + 0x010], 0x003       ; 48 81 bc 24 10 00 00 00 03 00 00 00  
    75 : setle dl                                   ; 0f 9e c2                             
    76 : and   rdx, rax                             ; 48 21 c2                             
    77 : or    rdx, rcx                             ; 48 09 ca                             
    78 : mov   rcx, qword ptr [rsp]                 ; 48 8b 8c 24 00 00 00 00              
    79 : imul  rcx, qword ptr [rsp]                 ; 48 0f af 8c 24 00 00 00 00           
    80 : mov   rax, qword ptr [rsp + 0x010]         ; 48 8b 84 24 10 00 00 00              
    81 : imul  rax, qword ptr [rsp + 0x010]         ; 48 0f af 84 24 10 00 00 00           
    82 : add   rax, rcx                             ; 48 01 c8                             
    83 : xor   rcx, rcx                             ; 48 31 c9                             
    84 : cmp   rax, 0x010                           ; 48 83 f8 10                          
    85 : setle cl                                   ; 0f 9e c1                             
    86 : and   rcx, rdx                             ; 48 21 d1                             
    87 : cmp   rcx, 0                               ; 48 83 f9 00                          
    88 : mov   r13, qword ptr [rsp + 0x020]         ; 4c 8b ac 24 20 00 00 00              
    89 : cmove rsi, r13                             ; 49 0f 44 f5                          
    90 : add   rsi, qword ptr [rsp + 0x018]         ; 48 03 b4 24 18 00 00 00              
    91 : mov   rdx, qword ptr [rsp + 0x010]         ; 48 8b 94 24 10 00 00 00              
    92 : imul  rdx, 0x002                           ; 48 6b d2 02                          
    93 : cmp   rdx, qword ptr [rsp]                 ; 48 3b 94 24 00 00 00 00              
    94 : jl    __loops_label_8                      ; 0f 8c 33 00 00 00                    
    95 : mov   rdx, qword ptr [rsp]                 ; 48 8b 94 24 00 00 00 00              
    96 : add   rdx, 0x003                           ; 48 81 c2 03 00 00 00                 
    97 : neg   rdx                                  ; 48 f7 da                             
    98 : mov   rcx, qword ptr [rsp]                 ; 48 8b 8c 24 00 00 00 00              
    99 : add   rcx, 0x003                           ; 48 81 c1 03 00 00 00                 
   100 : imul  rcx, rdx                             ; 48 0f af ca                          
   101 : cmp   qword ptr [rsp + 0x010], rcx         ; 48 39 8c 24 10 00 00 00              
   102 : jle   __loops_label_9                      ; 0f 8e 4d 00 00 00                    
   103 :       __loops_label_8:                     ;                                      
   104 : mov   rdx, qword ptr [rsp]                 ; 48 8b 94 24 00 00 00 00              
   105 : imul  rdx, 0x002                           ; 48 6b d2 02                          
   106 : cmp   qword ptr [rsp + 0x010], rdx         ; 48 39 94 24 10 00 00 00              
   107 : jg    __loops_label_7                      ; 0f 8f 4c 00 00 00                    
   108 : mov   rdx, qword ptr [rsp]                 ; 48 8b 94 24 00 00 00 00              
   109 : add   rdx, 0x003                           ; 48 81 c2 03 00 00 00                 
   110 : neg   rdx                                  ; 48 f7 da                             
   111 : mov   rcx, qword ptr [rsp]                 ; 48 8b 8c 24 00 00 00 00              
   112 : add   rcx, 0x003                           ; 48 81 c1 03 00 00 00                 
   113 : imul  rcx, rdx                             ; 48 0f af ca                          
   114 : cmp   qword ptr [rsp + 0x010], rcx         ; 48 39 8c 24 10 00 00 00              
   115 : jl    __loops_label_7                      ; 0f 8c 19 00 00 00                    
   116 :       __loops_label_9:                     ;                                      
   117 : cmp   qword ptr [rsp], 0                   ; 48 81 bc 24 00 00 00 00 00 00 00 00  
   118 : jg    __loops_label_7                      ; 0f 8f 07 00 00 00                    
   119 : add   rsi, 0x003                           ; 48 81 c6 03 00 00 00                 
   120 :       __loops_label_7:                     ;                                      
   121 : mov   rdx, qword ptr [rsp]                 ; 48 8b 94 24 00 00 00 00              
   122 : add   rdx, 0x005                           ; 48 81 c2 05 00 00 00                 
   123 : shl   rdx, 0x003                           ; 48 c1 e2 03                          
   124 : add   rdx, qword ptr [rsp + 0x008]         ; 48 03 94 24 08 00 00 00              
   125 : mov   qword ptr [rdi + rdx], rsi           ; 48 89 34 17                          
   126 : add   qword ptr [rsp], 0x001               ; 48 81 84 24 00 00 00 00 01 00 00 00  
   127 : jmp   __loops_label_3                      ; e9 76 fd ff ff                       
   128 :       __loops_label_5:                     ;                                      
   129 : add   qword ptr [rsp + 0x010], 0x001       ; 48 81 84 24 10 00 00 00 01 00 00 00  
   130 : jmp   __loops_label_0                      ; e9 15 fd ff ff                       
   131 :       __loops_label_2:                     ;                                      
   132 : mov   r13, qword ptr [rsp + 0x028]         ; 4c 8b ac 24 28 00 00 00              
   133 : add   rsp, 0x038                           ; 48 81 c4 38 00 00 00                 
   134 : ret                                        ; c3                                   
