min_max_scalar(i0, i1, i2, i3)
     0 : sub    rsp, 0x068                     ; 48 81 ec 68 00 00 00                 
     1 : mov    qword ptr [rsp + 0x060], r13   ; 4c 89 ac 24 60 00 00 00              
     2 : mov    qword ptr [rsp + 0x048], 0     ; 48 c7 84 24 48 00 00 00 00 00 00 00  
     3 : mov    qword ptr [rsp + 0x020], 0     ; 48 c7 84 24 20 00 00 00 00 00 00 00  
     4 : mov    qword ptr [rsp + 0x028], 0     ; 48 c7 84 24 28 00 00 00 00 00 00 00  
     5 : movsxd r13, dword ptr [rdi]           ; 4c 63 2f                             
     6 : mov    qword ptr [rsp + 0x030], r13   ; 4c 89 ac 24 30 00 00 00              
     7 : mov    r13, qword ptr [rsp + 0x030]   ; 4c 8b ac 24 30 00 00 00              
     8 : mov    qword ptr [rsp + 0x038], r13   ; 4c 89 ac 24 38 00 00 00              
     9 : imul   rsi, 0x004                     ; 48 6b f6 04                          
    10 : mov    qword ptr [rsp + 0x040], rsi   ; 48 89 b4 24 40 00 00 00              
    11 :        __loops_label_0:               ;                                      
    12 : mov    r13, qword ptr [rsp + 0x040]   ; 4c 8b ac 24 40 00 00 00              
    13 : cmp    qword ptr [rsp + 0x048], r13   ; 4c 39 ac 24 48 00 00 00              
    14 : jge    __loops_label_2                ; 0f 8d 69 00 00 00                    
    15 : mov    r13, qword ptr [rsp + 0x048]   ; 4c 8b ac 24 48 00 00 00              
    16 : movsxd rax, dword ptr [rdi + r13]     ; 4a 63 04 2f                          
    17 : cmp    rax, qword ptr [rsp + 0x030]   ; 48 3b 84 24 30 00 00 00              
    18 : jge    __loops_label_4                ; 0f 8d 18 00 00 00                    
    19 : mov    qword ptr [rsp + 0x030], rax   ; 48 89 84 24 30 00 00 00              
    20 : mov    r13, qword ptr [rsp + 0x048]   ; 4c 8b ac 24 48 00 00 00              
    21 : mov    qword ptr [rsp + 0x020], r13   ; 4c 89 ac 24 20 00 00 00              
    22 :        __loops_label_4:               ;                                      
    23 : cmp    rax, qword ptr [rsp + 0x038]   ; 48 3b 84 24 38 00 00 00              
    24 : jle    __loops_label_6                ; 0f 8e 18 00 00 00                    
    25 : mov    qword ptr [rsp + 0x038], rax   ; 48 89 84 24 38 00 00 00              
    26 : mov    r13, qword ptr [rsp + 0x048]   ; 4c 8b ac 24 48 00 00 00              
    27 : mov    qword ptr [rsp + 0x028], r13   ; 4c 89 ac 24 28 00 00 00              
    28 :        __loops_label_6:               ;                                      
    29 : add    qword ptr [rsp + 0x048], 0x004 ; 48 81 84 24 48 00 00 00 04 00 00 00  
    30 : jmp    __loops_label_0                ; e9 81 ff ff ff                       
    31 :        __loops_label_2:               ;                                      
    32 : mov    qword ptr [rsp + 0x050], 0x004 ; 48 c7 84 24 50 00 00 00 04 00 00 00  
    33 : mov    rdi, qword ptr [rsp + 0x020]   ; 48 8b bc 24 20 00 00 00              
    34 : mov    qword ptr [rsp + 0x058], rdx   ; 48 89 94 24 58 00 00 00              
    35 : mov    rax, rdi                       ; 48 89 f8                             
    36 : cqo                                   ; 48 99                                
    37 : idiv   qword ptr [rsp + 0x050]        ; 48 f7 bc 24 50 00 00 00              
    38 : mov    rdx, qword ptr [rsp + 0x058]   ; 48 8b 94 24 58 00 00 00              
    39 : mov    rdi, rax                       ; 48 89 c7                             
    40 : mov    rsi, qword ptr [rsp + 0x028]   ; 48 8b b4 24 28 00 00 00              
    41 : mov    qword ptr [rsp + 0x058], rdx   ; 48 89 94 24 58 00 00 00              
    42 : mov    rax, rsi                       ; 48 89 f0                             
    43 : cqo                                   ; 48 99                                
    44 : idiv   qword ptr [rsp + 0x050]        ; 48 f7 bc 24 50 00 00 00              
    45 : mov    rdx, qword ptr [rsp + 0x058]   ; 48 8b 94 24 58 00 00 00              
    46 : mov    rsi, rax                       ; 48 89 c6                             
    47 : mov    dword ptr [rdx], edi           ; 89 3a                                
    48 : mov    dword ptr [rcx], esi           ; 89 31                                
    49 : xor    rax, rax                       ; 48 31 c0                             
    50 : mov    r13, qword ptr [rsp + 0x060]   ; 4c 8b ac 24 60 00 00 00              
    51 : add    rsp, 0x068                     ; 48 81 c4 68 00 00 00                 
    52 : ret                                   ; c3                                   
