fixed_power_9(i0)
     0 : mov  rsi, rdi ; 48 89 fe     
     1 : imul rsi, rdi ; 48 0f af f7  
     2 : mov  rdx, rsi ; 48 89 f2     
     3 : imul rdx, rsi ; 48 0f af d6  
     4 : mov  rsi, rdx ; 48 89 d6     
     5 : imul rsi, rdx ; 48 0f af f2  
     6 : imul rsi, rdi ; 48 0f af f7  
     7 : mov  rax, rsi ; 48 89 f0     
     8 : ret           ; c3           
