fixed_power_v_double_4(i0, i1, i2)
     0 : sub     rsp, 0x008                    ; 48 81 ec 08 00 00 00  
     1 : xor     rcx, rcx                      ; 48 31 c9              
     2 : imul    rdx, 0x008                    ; 48 6b d2 08           
     3 : mov     rax, rdx                      ; 48 89 d0              
     4 :         __loops_label_0:              ;                       
     5 : cmp     rcx, rax                      ; 48 39 c1              
     6 : jge     __loops_label_2               ; 0f 8d 1e 00 00 00     
     7 : vmovupd ymm0, ymmword ptr [rdi + rcx] ; c5 fd 10 04 0f        
     8 : vmulpd  ymm0, ymm0, ymm0              ; c5 fd 59 c0           
     9 : vmulpd  ymm0, ymm0, ymm0              ; c5 fd 59 c0           
    10 : vmovupd ymmword ptr [rsi + rcx], ymm0 ; c5 fd 11 04 0e        
    11 : add     rcx, 0x020                    ; 48 81 c1 20 00 00 00  
    12 : jmp     __loops_label_0               ; e9 d9 ff ff ff        
    13 :         __loops_label_2:              ;                       
    14 : xor     rax, rax                      ; 48 31 c0              
    15 : add     rsp, 0x008                    ; 48 81 c4 08 00 00 00  
    16 : ret                                   ; c3                    
