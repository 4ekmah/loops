fixed_power_v_double_9(i0, i1, i2)
     0 : sub     rsp, 0x028                    ; 48 81 ec 28 00 00 00  
     1 : xor     rcx, rcx                      ; 48 31 c9              
     2 : imul    rdx, 0x008                    ; 48 6b d2 08           
     3 : mov     rax, rdx                      ; 48 89 d0              
     4 :         __loops_label_0:              ;                       
     5 : cmp     rcx, rax                      ; 48 39 c1              
     6 : jge     __loops_label_2               ; 0f 8d 26 00 00 00     
     7 : vmovupd ymm0, ymmword ptr [rdi + rcx] ; c5 fd 10 04 0f        
     8 : vmulpd  ymm1, ymm0, ymm0              ; c5 fd 59 c8           
     9 : vmulpd  ymm1, ymm1, ymm1              ; c5 f5 59 c9           
    10 : vmulpd  ymm1, ymm1, ymm1              ; c5 f5 59 c9           
    11 : vmulpd  ymm0, ymm0, ymm1              ; c5 fd 59 c1           
    12 : vmovupd ymmword ptr [rsi + rcx], ymm0 ; c5 fd 11 04 0e        
    13 : add     rcx, 0x020                    ; 48 81 c1 20 00 00 00  
    14 : jmp     __loops_label_0               ; e9 d1 ff ff ff        
    15 :         __loops_label_2:              ;                       
    16 : xor     rax, rax                      ; 48 31 c0              
    17 : add     rsp, 0x028                    ; 48 81 c4 28 00 00 00  
    18 : ret                                   ; c3                    
