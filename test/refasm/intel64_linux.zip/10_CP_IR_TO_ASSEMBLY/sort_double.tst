sort_double(i0, i1)
     0 : sub     rsp, 0x02b8                       ; 48 81 ec b8 02 00 00                 
     1 : mov     qword ptr [rsp + 0x02a8], r13     ; 4c 89 ac 24 a8 02 00 00              
     2 : mov     qword ptr [rsp + 0x02b0], rbp     ; 48 89 ac 24 b0 02 00 00              
     3 : mov     rbp, rsp                          ; 48 89 e5                             
     4 : add     rbp, 0x02b0                       ; 48 81 c5 b0 02 00 00                 
     5 : mov     qword ptr [rsp + 0x0290], rsi     ; 48 89 b4 24 90 02 00 00              
     6 : shl     qword ptr [rsp + 0x0290], 0x003   ; 48 c1 a4 24 90 02 00 00 03           
     7 : mov     r13, qword ptr [rsp + 0x0290]     ; 4c 8b ac 24 90 02 00 00              
     8 : mov     qword ptr [rsp + 0x0298], r13     ; 4c 89 ac 24 98 02 00 00              
     9 : sub     qword ptr [rsp + 0x0298], 0x008   ; 48 81 ac 24 98 02 00 00 08 00 00 00  
    10 : mov     qword ptr [rsp + 0x02a0], 0       ; 48 c7 84 24 a0 02 00 00 00 00 00 00  
    11 :         __loops_label_0:                  ;                                      
    12 : mov     r13, qword ptr [rsp + 0x0298]     ; 4c 8b ac 24 98 02 00 00              
    13 : cmp     qword ptr [rsp + 0x02a0], r13     ; 4c 39 ac 24 a0 02 00 00              
    14 : jge     __loops_label_2                   ; 0f 8d 99 02 00 00                    
    15 : mov     r13, qword ptr [rsp + 0x02a0]     ; 4c 8b ac 24 a0 02 00 00              
    16 : mov     qword ptr [rsp + 0x0288], r13     ; 4c 89 ac 24 88 02 00 00              
    17 : mov     r13, qword ptr [rsp + 0x0288]     ; 4c 8b ac 24 88 02 00 00              
    18 : mov     qword ptr [rsp + 0x0280], r13     ; 4c 89 ac 24 80 02 00 00              
    19 : add     qword ptr [rsp + 0x0280], 0x008   ; 48 81 84 24 80 02 00 00 08 00 00 00  
    20 :         __loops_label_3:                  ;                                      
    21 : mov     r13, qword ptr [rsp + 0x0290]     ; 4c 8b ac 24 90 02 00 00              
    22 : cmp     qword ptr [rsp + 0x0280], r13     ; 4c 39 ac 24 80 02 00 00              
    23 : jge     __loops_label_5                   ; 0f 8d 00 02 00 00                    
    24 : mov     r13, qword ptr [rsp + 0x0280]     ; 4c 8b ac 24 80 02 00 00              
    25 : mov     rax, qword ptr [rdi + r13]        ; 4a 8b 04 2f                          
    26 : mov     r13, qword ptr [rsp + 0x0288]     ; 4c 8b ac 24 88 02 00 00              
    27 : mov     rcx, qword ptr [rdi + r13]        ; 4a 8b 0c 2f                          
    28 : mov     rdx, 0x055acfa04fc1a              ; 48 ba 1a fc 04 fa ac 55 00 00        
    29 : mov     qword ptr [rsp], rax              ; 48 89 84 24 00 00 00 00              
    30 : mov     qword ptr [rsp + 0x008], rcx      ; 48 89 8c 24 08 00 00 00              
    31 : mov     qword ptr [rsp + 0x010], rdx      ; 48 89 94 24 10 00 00 00              
    32 : mov     qword ptr [rsp + 0x018], rsi      ; 48 89 b4 24 18 00 00 00              
    33 : mov     qword ptr [rsp + 0x020], rdi      ; 48 89 bc 24 20 00 00 00              
    34 : mov     qword ptr [rsp + 0x028], r8       ; 4c 89 84 24 28 00 00 00              
    35 : mov     qword ptr [rsp + 0x030], r9       ; 4c 89 8c 24 30 00 00 00              
    36 : mov     qword ptr [rsp + 0x038], r10      ; 4c 89 94 24 38 00 00 00              
    37 : mov     qword ptr [rsp + 0x040], r11      ; 4c 89 9c 24 40 00 00 00              
    38 : vmovdqu ymmword ptr [rsp + 0x060], ymm0   ; c5 fe 7f 84 24 60 00 00 00           
    39 : vmovdqu ymmword ptr [rsp + 0x080], ymm1   ; c5 fe 7f 8c 24 80 00 00 00           
    40 : vmovdqu ymmword ptr [rsp + 0x0a0], ymm2   ; c5 fe 7f 94 24 a0 00 00 00           
    41 : vmovdqu ymmword ptr [rsp + 0x0c0], ymm3   ; c5 fe 7f 9c 24 c0 00 00 00           
    42 : vmovdqu ymmword ptr [rsp + 0x0e0], ymm4   ; c5 fe 7f a4 24 e0 00 00 00           
    43 : vmovdqu ymmword ptr [rsp + 0x0100], ymm5  ; c5 fe 7f ac 24 00 01 00 00           
    44 : vmovdqu ymmword ptr [rsp + 0x0120], ymm6  ; c5 fe 7f b4 24 20 01 00 00           
    45 : vmovdqu ymmword ptr [rsp + 0x0140], ymm7  ; c5 fe 7f bc 24 40 01 00 00           
    46 : vmovdqu ymmword ptr [rsp + 0x0160], ymm8  ; c5 7e 7f 84 24 60 01 00 00           
    47 : vmovdqu ymmword ptr [rsp + 0x0180], ymm9  ; c5 7e 7f 8c 24 80 01 00 00           
    48 : vmovdqu ymmword ptr [rsp + 0x01a0], ymm10 ; c5 7e 7f 94 24 a0 01 00 00           
    49 : vmovdqu ymmword ptr [rsp + 0x01c0], ymm11 ; c5 7e 7f 9c 24 c0 01 00 00           
    50 : vmovdqu ymmword ptr [rsp + 0x01e0], ymm12 ; c5 7e 7f a4 24 e0 01 00 00           
    51 : vmovdqu ymmword ptr [rsp + 0x0200], ymm13 ; c5 7e 7f ac 24 00 02 00 00           
    52 : vmovdqu ymmword ptr [rsp + 0x0220], ymm14 ; c5 7e 7f b4 24 20 02 00 00           
    53 : vmovdqu ymmword ptr [rsp + 0x0240], ymm15 ; c5 7e 7f bc 24 40 02 00 00           
    54 : mov     rdi, rax                          ; 48 89 c7                             
    55 : mov     rsi, rcx                          ; 48 89 ce                             
    56 : call    rdx                               ; ff d2                                
    57 : mov     rdx, rax                          ; 48 89 c2                             
    58 : mov     rax, qword ptr [rsp]              ; 48 8b 84 24 00 00 00 00              
    59 : mov     rcx, qword ptr [rsp + 0x008]      ; 48 8b 8c 24 08 00 00 00              
    60 : mov     rsi, qword ptr [rsp + 0x018]      ; 48 8b b4 24 18 00 00 00              
    61 : mov     rdi, qword ptr [rsp + 0x020]      ; 48 8b bc 24 20 00 00 00              
    62 : mov     r8, qword ptr [rsp + 0x028]       ; 4c 8b 84 24 28 00 00 00              
    63 : mov     r9, qword ptr [rsp + 0x030]       ; 4c 8b 8c 24 30 00 00 00              
    64 : mov     r10, qword ptr [rsp + 0x038]      ; 4c 8b 94 24 38 00 00 00              
    65 : mov     r11, qword ptr [rsp + 0x040]      ; 4c 8b 9c 24 40 00 00 00              
    66 : vmovdqu ymm0, ymmword ptr [rsp + 0x060]   ; c5 fe 6f 84 24 60 00 00 00           
    67 : vmovdqu ymm1, ymmword ptr [rsp + 0x080]   ; c5 fe 6f 8c 24 80 00 00 00           
    68 : vmovdqu ymm2, ymmword ptr [rsp + 0x0a0]   ; c5 fe 6f 94 24 a0 00 00 00           
    69 : vmovdqu ymm3, ymmword ptr [rsp + 0x0c0]   ; c5 fe 6f 9c 24 c0 00 00 00           
    70 : vmovdqu ymm4, ymmword ptr [rsp + 0x0e0]   ; c5 fe 6f a4 24 e0 00 00 00           
    71 : vmovdqu ymm5, ymmword ptr [rsp + 0x0100]  ; c5 fe 6f ac 24 00 01 00 00           
    72 : vmovdqu ymm6, ymmword ptr [rsp + 0x0120]  ; c5 fe 6f b4 24 20 01 00 00           
    73 : vmovdqu ymm7, ymmword ptr [rsp + 0x0140]  ; c5 fe 6f bc 24 40 01 00 00           
    74 : vmovdqu ymm8, ymmword ptr [rsp + 0x0160]  ; c5 7e 6f 84 24 60 01 00 00           
    75 : vmovdqu ymm9, ymmword ptr [rsp + 0x0180]  ; c5 7e 6f 8c 24 80 01 00 00           
    76 : vmovdqu ymm10, ymmword ptr [rsp + 0x01a0] ; c5 7e 6f 94 24 a0 01 00 00           
    77 : vmovdqu ymm11, ymmword ptr [rsp + 0x01c0] ; c5 7e 6f 9c 24 c0 01 00 00           
    78 : vmovdqu ymm12, ymmword ptr [rsp + 0x01e0] ; c5 7e 6f a4 24 e0 01 00 00           
    79 : vmovdqu ymm13, ymmword ptr [rsp + 0x0200] ; c5 7e 6f ac 24 00 02 00 00           
    80 : vmovdqu ymm14, ymmword ptr [rsp + 0x0220] ; c5 7e 6f b4 24 20 02 00 00           
    81 : vmovdqu ymm15, ymmword ptr [rsp + 0x0240] ; c5 7e 6f bc 24 40 02 00 00           
    82 : cmp     rdx, 0                            ; 48 83 fa 00                          
    83 : je      __loops_label_7                   ; 0f 84 10 00 00 00                    
    84 : mov     r13, qword ptr [rsp + 0x0280]     ; 4c 8b ac 24 80 02 00 00              
    85 : mov     qword ptr [rsp + 0x0288], r13     ; 4c 89 ac 24 88 02 00 00              
    86 :         __loops_label_7:                  ;                                      
    87 : add     qword ptr [rsp + 0x0280], 0x008   ; 48 81 84 24 80 02 00 00 08 00 00 00  
    88 : jmp     __loops_label_3                   ; e9 ea fd ff ff                       
    89 :         __loops_label_5:                  ;                                      
    90 : mov     r13, qword ptr [rsp + 0x02a0]     ; 4c 8b ac 24 a0 02 00 00              
    91 : cmp     qword ptr [rsp + 0x0288], r13     ; 4c 39 ac 24 88 02 00 00              
    92 : je      __loops_label_9                   ; 0f 84 30 00 00 00                    
    93 : mov     r13, qword ptr [rsp + 0x02a0]     ; 4c 8b ac 24 a0 02 00 00              
    94 : mov     rdx, qword ptr [rdi + r13]        ; 4a 8b 14 2f                          
    95 : mov     r13, qword ptr [rsp + 0x0288]     ; 4c 8b ac 24 88 02 00 00              
    96 : mov     rcx, qword ptr [rdi + r13]        ; 4a 8b 0c 2f                          
    97 : mov     r13, qword ptr [rsp + 0x0288]     ; 4c 8b ac 24 88 02 00 00              
    98 : mov     qword ptr [rdi + r13], rdx        ; 4a 89 14 2f                          
    99 : mov     r13, qword ptr [rsp + 0x02a0]     ; 4c 8b ac 24 a0 02 00 00              
   100 : mov     qword ptr [rdi + r13], rcx        ; 4a 89 0c 2f                          
   101 :         __loops_label_9:                  ;                                      
   102 : add     qword ptr [rsp + 0x02a0], 0x008   ; 48 81 84 24 a0 02 00 00 08 00 00 00  
   103 : jmp     __loops_label_0                   ; e9 51 fd ff ff                       
   104 :         __loops_label_2:                  ;                                      
   105 : mov     rbp, qword ptr [rsp + 0x02b0]     ; 48 8b ac 24 b0 02 00 00              
   106 : mov     r13, qword ptr [rsp + 0x02a8]     ; 4c 8b ac 24 a8 02 00 00              
   107 : add     rsp, 0x02b8                       ; 48 81 c4 b8 02 00 00                 
   108 : ret                                       ; c3                                   
