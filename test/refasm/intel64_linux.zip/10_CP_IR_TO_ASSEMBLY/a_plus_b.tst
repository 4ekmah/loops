a_plus_b(i0, i1)
     0 : add rsi, rdi ; 48 01 fe  
     1 : mov rax, rsi ; 48 89 f0  
     2 : ret          ; c3        
