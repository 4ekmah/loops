fixed_power_v_double_0(i0, i1, i2)
     0 : sub          rsp, 0x028                    ; 48 81 ec 28 00 00 00           
     1 : xor          rcx, rcx                      ; 48 31 c9                       
     2 : imul         rdx, 0x008                    ; 48 6b d2 08                    
     3 : mov          qword ptr [rsp + 0x020], rdx  ; 48 89 94 24 20 00 00 00        
     4 :              __loops_label_0:              ;                                
     5 : cmp          rcx, qword ptr [rsp + 0x020]  ; 48 3b 8c 24 20 00 00 00        
     6 : jge          __loops_label_2               ; 0f 8d 2b 00 00 00              
     7 : vmovupd      ymm0, ymmword ptr [rdi + rcx] ; c5 fd 10 04 0f                 
     8 : mov          rax, 0x03ff0000000000000      ; 48 b8 00 00 00 00 00 00 f0 3f  
     9 : vpinsrq      xmm0, xmm0, rax, 0            ; c4 e3 f9 22 c0 00              
    10 : vpbroadcastq ymm0, xmm0                    ; c4 e2 7d 59 c0                 
    11 : vmovupd      ymmword ptr [rsi + rcx], ymm0 ; c5 fd 11 04 0e                 
    12 : add          rcx, 0x020                    ; 48 81 c1 20 00 00 00           
    13 : jmp          __loops_label_0               ; e9 c7 ff ff ff                 
    14 :              __loops_label_2:              ;                                
    15 : xor          rax, rax                      ; 48 31 c0                       
    16 : add          rsp, 0x028                    ; 48 81 c4 28 00 00 00           
    17 : ret                                        ; c3                             
