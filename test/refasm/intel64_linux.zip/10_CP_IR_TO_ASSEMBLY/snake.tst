snake(i0, i1, i2)
     0 : sub     rsp, 0x02e8                       ; 48 81 ec e8 02 00 00                 
     1 : mov     qword ptr [rsp + 0x02d0], r13     ; 4c 89 ac 24 d0 02 00 00              
     2 : mov     qword ptr [rsp + 0x02d8], r14     ; 4c 89 b4 24 d8 02 00 00              
     3 : mov     qword ptr [rsp + 0x02e0], rbp     ; 48 89 ac 24 e0 02 00 00              
     4 : mov     rbp, rsp                          ; 48 89 e5                             
     5 : add     rbp, 0x02e0                       ; 48 81 c5 e0 02 00 00                 
     6 : mov     rcx, rsi                          ; 48 89 f1                             
     7 : add     rcx, rdx                          ; 48 01 d1                             
     8 : mov     qword ptr [rsp + 0x02a0], rcx     ; 48 89 8c 24 a0 02 00 00              
     9 : sub     qword ptr [rsp + 0x02a0], 0x001   ; 48 81 ac 24 a0 02 00 00 01 00 00 00  
    10 : xor     rcx, rcx                          ; 48 31 c9                             
    11 : mov     qword ptr [rsp + 0x0298], 0x001   ; 48 c7 84 24 98 02 00 00 01 00 00 00  
    12 : mov     r13, qword ptr [rsp + 0x0298]     ; 4c 8b ac 24 98 02 00 00              
    13 : mov     qword ptr [rsp + 0x0280], r13     ; 4c 89 ac 24 80 02 00 00              
    14 : neg     qword ptr [rsp + 0x0280]          ; 48 f7 9c 24 80 02 00 00              
    15 : mov     qword ptr [rsp + 0x02a8], 0       ; 48 c7 84 24 a8 02 00 00 00 00 00 00  
    16 :         __loops_label_0:                  ;                                      
    17 : mov     r13, qword ptr [rsp + 0x02a0]     ; 4c 8b ac 24 a0 02 00 00              
    18 : cmp     qword ptr [rsp + 0x02a8], r13     ; 4c 39 ac 24 a8 02 00 00              
    19 : jge     __loops_label_2                   ; 0f 8d a1 03 00 00                    
    20 : mov     qword ptr [rsp + 0x0288], 0       ; 48 c7 84 24 88 02 00 00 00 00 00 00  
    21 : mov     qword ptr [rsp + 0x0290], 0       ; 48 c7 84 24 90 02 00 00 00 00 00 00  
    22 : mov     rax, qword ptr [rsp + 0x02a8]     ; 48 8b 84 24 a8 02 00 00              
    23 : and     rax, 0x001                        ; 48 25 01 00 00 00                    
    24 : cmp     rax, 0                            ; 48 83 f8 00                          
    25 : je      __loops_label_4                   ; 0f 84 75 00 00 00                    
    26 : mov     rax, rdx                          ; 48 89 d0                             
    27 : sub     rax, 0x001                        ; 48 2d 01 00 00 00                    
    28 : cmp     rax, qword ptr [rsp + 0x02a8]     ; 48 3b 84 24 a8 02 00 00              
    29 : mov     r13, qword ptr [rsp + 0x02a8]     ; 4c 8b ac 24 a8 02 00 00              
    30 : mov     r14, r13                          ; 4d 89 ee                             
    31 : cmovl   r14, rax                          ; 4c 0f 4c f0                          
    32 : mov     qword ptr [rsp + 0x0288], r14     ; 4c 89 b4 24 88 02 00 00              
    33 : mov     r13, qword ptr [rsp + 0x02a8]     ; 4c 8b ac 24 a8 02 00 00              
    34 : mov     qword ptr [rsp + 0x02b0], r13     ; 4c 89 ac 24 b0 02 00 00              
    35 : sub     qword ptr [rsp + 0x02b0], rax     ; 48 29 84 24 b0 02 00 00              
    36 : mov     qword ptr [rsp + 0x02b8], 0       ; 48 c7 84 24 b8 02 00 00 00 00 00 00  
    37 : cmp     qword ptr [rsp + 0x02a8], rax     ; 48 39 84 24 a8 02 00 00              
    38 : mov     r13, qword ptr [rsp + 0x02b8]     ; 4c 8b ac 24 b8 02 00 00              
    39 : mov     r14, r13                          ; 4d 89 ee                             
    40 : cmovg   r14, qword ptr [rsp + 0x02b0]     ; 4c 0f 4f b4 24 b0 02 00 00           
    41 : mov     qword ptr [rsp + 0x0290], r14     ; 4c 89 b4 24 90 02 00 00              
    42 : jmp     __loops_label_6                   ; e9 86 00 00 00                       
    43 :         __loops_label_4:                  ;                                      
    44 : mov     qword ptr [rsp + 0x02c0], rsi     ; 48 89 b4 24 c0 02 00 00              
    45 : sub     qword ptr [rsp + 0x02c0], 0x001   ; 48 81 ac 24 c0 02 00 00 01 00 00 00  
    46 : mov     r13, qword ptr [rsp + 0x02a8]     ; 4c 8b ac 24 a8 02 00 00              
    47 : mov     rax, r13                          ; 4c 89 e8                             
    48 : sub     rax, qword ptr [rsp + 0x02c0]     ; 48 2b 84 24 c0 02 00 00              
    49 : mov     qword ptr [rsp + 0x02c8], 0       ; 48 c7 84 24 c8 02 00 00 00 00 00 00  
    50 : mov     r13, qword ptr [rsp + 0x02c0]     ; 4c 8b ac 24 c0 02 00 00              
    51 : cmp     qword ptr [rsp + 0x02a8], r13     ; 4c 39 ac 24 a8 02 00 00              
    52 : mov     r13, qword ptr [rsp + 0x02c8]     ; 4c 8b ac 24 c8 02 00 00              
    53 : mov     r14, r13                          ; 4d 89 ee                             
    54 : cmovg   r14, rax                          ; 4c 0f 4f f0                          
    55 : mov     qword ptr [rsp + 0x0288], r14     ; 4c 89 b4 24 88 02 00 00              
    56 : mov     r13, qword ptr [rsp + 0x02a8]     ; 4c 8b ac 24 a8 02 00 00              
    57 : cmp     qword ptr [rsp + 0x02c0], r13     ; 4c 39 ac 24 c0 02 00 00              
    58 : mov     r13, qword ptr [rsp + 0x02a8]     ; 4c 8b ac 24 a8 02 00 00              
    59 : mov     r14, r13                          ; 4d 89 ee                             
    60 : cmovl   r14, qword ptr [rsp + 0x02c0]     ; 4c 0f 4c b4 24 c0 02 00 00           
    61 : mov     qword ptr [rsp + 0x0290], r14     ; 4c 89 b4 24 90 02 00 00              
    62 :         __loops_label_5:                  ;                                      
    63 :         __loops_label_6:                  ;                                      
    64 : cmp     qword ptr [rsp + 0x0288], 0       ; 48 81 bc 24 88 02 00 00 00 00 00 00  
    65 : jl      __loops_label_8                   ; 0f 8c 43 02 00 00                    
    66 : cmp     qword ptr [rsp + 0x0288], rdx     ; 48 39 94 24 88 02 00 00              
    67 : jge     __loops_label_8                   ; 0f 8d 35 02 00 00                    
    68 : cmp     qword ptr [rsp + 0x0290], 0       ; 48 81 bc 24 90 02 00 00 00 00 00 00  
    69 : jl      __loops_label_8                   ; 0f 8c 23 02 00 00                    
    70 : cmp     qword ptr [rsp + 0x0290], rsi     ; 48 39 b4 24 90 02 00 00              
    71 : jge     __loops_label_8                   ; 0f 8d 15 02 00 00                    
    72 : mov     rax, 0x056049d58f983              ; 48 b8 83 f9 58 9d 04 56 00 00        
    73 : mov     r13, qword ptr [rsp + 0x0288]     ; 4c 8b ac 24 88 02 00 00              
    74 : mov     r14, qword ptr [rsp + 0x0290]     ; 4c 8b b4 24 90 02 00 00              
    75 : mov     qword ptr [rsp], rax              ; 48 89 84 24 00 00 00 00              
    76 : mov     qword ptr [rsp + 0x008], rcx      ; 48 89 8c 24 08 00 00 00              
    77 : mov     qword ptr [rsp + 0x010], rdx      ; 48 89 94 24 10 00 00 00              
    78 : mov     qword ptr [rsp + 0x018], rsi      ; 48 89 b4 24 18 00 00 00              
    79 : mov     qword ptr [rsp + 0x020], rdi      ; 48 89 bc 24 20 00 00 00              
    80 : mov     qword ptr [rsp + 0x028], r8       ; 4c 89 84 24 28 00 00 00              
    81 : mov     qword ptr [rsp + 0x030], r9       ; 4c 89 8c 24 30 00 00 00              
    82 : mov     qword ptr [rsp + 0x038], r10      ; 4c 89 94 24 38 00 00 00              
    83 : mov     qword ptr [rsp + 0x040], r11      ; 4c 89 9c 24 40 00 00 00              
    84 : vmovdqu ymmword ptr [rsp + 0x060], ymm0   ; c5 fe 7f 84 24 60 00 00 00           
    85 : vmovdqu ymmword ptr [rsp + 0x080], ymm1   ; c5 fe 7f 8c 24 80 00 00 00           
    86 : vmovdqu ymmword ptr [rsp + 0x0a0], ymm2   ; c5 fe 7f 94 24 a0 00 00 00           
    87 : vmovdqu ymmword ptr [rsp + 0x0c0], ymm3   ; c5 fe 7f 9c 24 c0 00 00 00           
    88 : vmovdqu ymmword ptr [rsp + 0x0e0], ymm4   ; c5 fe 7f a4 24 e0 00 00 00           
    89 : vmovdqu ymmword ptr [rsp + 0x0100], ymm5  ; c5 fe 7f ac 24 00 01 00 00           
    90 : vmovdqu ymmword ptr [rsp + 0x0120], ymm6  ; c5 fe 7f b4 24 20 01 00 00           
    91 : vmovdqu ymmword ptr [rsp + 0x0140], ymm7  ; c5 fe 7f bc 24 40 01 00 00           
    92 : vmovdqu ymmword ptr [rsp + 0x0160], ymm8  ; c5 7e 7f 84 24 60 01 00 00           
    93 : vmovdqu ymmword ptr [rsp + 0x0180], ymm9  ; c5 7e 7f 8c 24 80 01 00 00           
    94 : vmovdqu ymmword ptr [rsp + 0x01a0], ymm10 ; c5 7e 7f 94 24 a0 01 00 00           
    95 : vmovdqu ymmword ptr [rsp + 0x01c0], ymm11 ; c5 7e 7f 9c 24 c0 01 00 00           
    96 : vmovdqu ymmword ptr [rsp + 0x01e0], ymm12 ; c5 7e 7f a4 24 e0 01 00 00           
    97 : vmovdqu ymmword ptr [rsp + 0x0200], ymm13 ; c5 7e 7f ac 24 00 02 00 00           
    98 : vmovdqu ymmword ptr [rsp + 0x0220], ymm14 ; c5 7e 7f b4 24 20 02 00 00           
    99 : vmovdqu ymmword ptr [rsp + 0x0240], ymm15 ; c5 7e 7f bc 24 40 02 00 00           
   100 : mov     rdi, r13                          ; 4c 89 ef                             
   101 : mov     rsi, r14                          ; 4c 89 f6                             
   102 : call    rax                               ; ff d0                                
   103 : mov     rax, qword ptr [rsp]              ; 48 8b 84 24 00 00 00 00              
   104 : mov     rcx, qword ptr [rsp + 0x008]      ; 48 8b 8c 24 08 00 00 00              
   105 : mov     rdx, qword ptr [rsp + 0x010]      ; 48 8b 94 24 10 00 00 00              
   106 : mov     rsi, qword ptr [rsp + 0x018]      ; 48 8b b4 24 18 00 00 00              
   107 : mov     rdi, qword ptr [rsp + 0x020]      ; 48 8b bc 24 20 00 00 00              
   108 : mov     r8, qword ptr [rsp + 0x028]       ; 4c 8b 84 24 28 00 00 00              
   109 : mov     r9, qword ptr [rsp + 0x030]       ; 4c 8b 8c 24 30 00 00 00              
   110 : mov     r10, qword ptr [rsp + 0x038]      ; 4c 8b 94 24 38 00 00 00              
   111 : mov     r11, qword ptr [rsp + 0x040]      ; 4c 8b 9c 24 40 00 00 00              
   112 : vmovdqu ymm0, ymmword ptr [rsp + 0x060]   ; c5 fe 6f 84 24 60 00 00 00           
   113 : vmovdqu ymm1, ymmword ptr [rsp + 0x080]   ; c5 fe 6f 8c 24 80 00 00 00           
   114 : vmovdqu ymm2, ymmword ptr [rsp + 0x0a0]   ; c5 fe 6f 94 24 a0 00 00 00           
   115 : vmovdqu ymm3, ymmword ptr [rsp + 0x0c0]   ; c5 fe 6f 9c 24 c0 00 00 00           
   116 : vmovdqu ymm4, ymmword ptr [rsp + 0x0e0]   ; c5 fe 6f a4 24 e0 00 00 00           
   117 : vmovdqu ymm5, ymmword ptr [rsp + 0x0100]  ; c5 fe 6f ac 24 00 01 00 00           
   118 : vmovdqu ymm6, ymmword ptr [rsp + 0x0120]  ; c5 fe 6f b4 24 20 01 00 00           
   119 : vmovdqu ymm7, ymmword ptr [rsp + 0x0140]  ; c5 fe 6f bc 24 40 01 00 00           
   120 : vmovdqu ymm8, ymmword ptr [rsp + 0x0160]  ; c5 7e 6f 84 24 60 01 00 00           
   121 : vmovdqu ymm9, ymmword ptr [rsp + 0x0180]  ; c5 7e 6f 8c 24 80 01 00 00           
   122 : vmovdqu ymm10, ymmword ptr [rsp + 0x01a0] ; c5 7e 6f 94 24 a0 01 00 00           
   123 : vmovdqu ymm11, ymmword ptr [rsp + 0x01c0] ; c5 7e 6f 9c 24 c0 01 00 00           
   124 : vmovdqu ymm12, ymmword ptr [rsp + 0x01e0] ; c5 7e 6f a4 24 e0 01 00 00           
   125 : vmovdqu ymm13, ymmword ptr [rsp + 0x0200] ; c5 7e 6f ac 24 00 02 00 00           
   126 : vmovdqu ymm14, ymmword ptr [rsp + 0x0220] ; c5 7e 6f b4 24 20 02 00 00           
   127 : vmovdqu ymm15, ymmword ptr [rsp + 0x0240] ; c5 7e 6f bc 24 40 02 00 00           
   128 : mov     rax, qword ptr [rsp + 0x0290]     ; 48 8b 84 24 90 02 00 00              
   129 : imul    rax, rdx                          ; 48 0f af c2                          
   130 : add     rax, qword ptr [rsp + 0x0288]     ; 48 03 84 24 88 02 00 00              
   131 : mov     byte ptr [rdi + rax], cl          ; 88 0c 07                             
   132 : add     rcx, 0x001                        ; 48 81 c1 01 00 00 00                 
   133 : mov     r13, qword ptr [rsp + 0x0298]     ; 4c 8b ac 24 98 02 00 00              
   134 : add     qword ptr [rsp + 0x0288], r13     ; 4c 01 ac 24 88 02 00 00              
   135 : mov     r13, qword ptr [rsp + 0x0280]     ; 4c 8b ac 24 80 02 00 00              
   136 : add     qword ptr [rsp + 0x0290], r13     ; 4c 01 ac 24 90 02 00 00              
   137 : jmp     __loops_label_6                   ; e9 ab fd ff ff                       
   138 :         __loops_label_8:                  ;                                      
   139 : neg     qword ptr [rsp + 0x0298]          ; 48 f7 9c 24 98 02 00 00              
   140 : neg     qword ptr [rsp + 0x0280]          ; 48 f7 9c 24 80 02 00 00              
   141 : add     qword ptr [rsp + 0x02a8], 0x001   ; 48 81 84 24 a8 02 00 00 01 00 00 00  
   142 : jmp     __loops_label_0                   ; e9 49 fc ff ff                       
   143 :         __loops_label_2:                  ;                                      
   144 : mov     rbp, qword ptr [rsp + 0x02e0]     ; 48 8b ac 24 e0 02 00 00              
   145 : mov     r13, qword ptr [rsp + 0x02d0]     ; 4c 8b ac 24 d0 02 00 00              
   146 : mov     r14, qword ptr [rsp + 0x02d8]     ; 4c 8b b4 24 d8 02 00 00              
   147 : add     rsp, 0x02e8                       ; 48 81 c4 e8 02 00 00                 
   148 : ret                                       ; c3                                   
