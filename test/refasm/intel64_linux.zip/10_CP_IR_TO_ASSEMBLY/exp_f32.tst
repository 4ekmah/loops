exp_f32(i0, i1, i2)
     0 : sub          rsp, 0x0a8                       ; 48 81 ec a8 00 00 00           
     1 : mov          rcx, 0x0c2b0c0a5                 ; 48 b9 a5 c0 b0 c2 00 00 00 00  
     2 : vpinsrd      xmm1, xmm1, ecx, 0               ; c4 e3 71 22 c9 00              
     3 : vpbroadcastd ymm0, xmm1                       ; c4 e2 7d 58 c1                 
     4 : mov          rcx, 0x042b0c0a5                 ; 48 c7 c1 a5 c0 b0 42           
     5 : vpinsrd      xmm2, xmm2, ecx, 0               ; c4 e3 69 22 d1 00              
     6 : vpbroadcastd ymm1, xmm2                       ; c4 e2 7d 58 ca                 
     7 : mov          rcx, 0x03f000000                 ; 48 c7 c1 00 00 00 3f           
     8 : vpinsrd      xmm3, xmm3, ecx, 0               ; c4 e3 61 22 d9 00              
     9 : vpbroadcastd ymm2, xmm3                       ; c4 e2 7d 58 d3                 
    10 : mov          rcx, 0x03f800000                 ; 48 c7 c1 00 00 80 3f           
    11 : vpinsrd      xmm4, xmm4, ecx, 0               ; c4 e3 59 22 e1 00              
    12 : vpbroadcastd ymm3, xmm4                       ; c4 e2 7d 58 dc                 
    13 : mov          rcx, 0x03fb8aa3b                 ; 48 c7 c1 3b aa b8 3f           
    14 : vpinsrd      xmm5, xmm5, ecx, 0               ; c4 e3 51 22 e9 00              
    15 : vpbroadcastd ymm4, xmm5                       ; c4 e2 7d 58 e5                 
    16 : mov          rcx, 0x0bf318000                 ; 48 b9 00 80 31 bf 00 00 00 00  
    17 : vpinsrd      xmm6, xmm6, ecx, 0               ; c4 e3 49 22 f1 00              
    18 : vpbroadcastd ymm5, xmm6                       ; c4 e2 7d 58 ee                 
    19 : mov          rcx, 0x0395e8083                 ; 48 c7 c1 83 80 5e 39           
    20 : vpinsrd      xmm7, xmm7, ecx, 0               ; c4 e3 41 22 f9 00              
    21 : vpbroadcastd ymm6, xmm7                       ; c4 e2 7d 58 f7                 
    22 : mov          rcx, 0x039506967                 ; 48 c7 c1 67 69 50 39           
    23 : vpinsrd      xmm8, xmm8, ecx, 0               ; c4 63 39 22 c1 00              
    24 : vpbroadcastd ymm7, xmm8                       ; c4 c2 7d 58 f8                 
    25 : mov          rcx, 0x03ab743ce                 ; 48 c7 c1 ce 43 b7 3a           
    26 : vpinsrd      xmm9, xmm9, ecx, 0               ; c4 63 31 22 c9 00              
    27 : vpbroadcastd ymm8, xmm9                       ; c4 42 7d 58 c1                 
    28 : mov          rcx, 0x03c088908                 ; 48 c7 c1 08 89 08 3c           
    29 : vpinsrd      xmm9, xmm9, ecx, 0               ; c4 63 31 22 c9 00              
    30 : vpbroadcastd ymm13, xmm9                      ; c4 42 7d 58 e9                 
    31 : vmovups      ymmword ptr [rsp + 0x080], ymm13 ; c5 7c 11 ac 24 80 00 00 00     
    32 : mov          rcx, 0x03d2aa9c1                 ; 48 c7 c1 c1 a9 2a 3d           
    33 : vpinsrd      xmm9, xmm9, ecx, 0               ; c4 63 31 22 c9 00              
    34 : vpbroadcastd ymm13, xmm9                      ; c4 42 7d 58 e9                 
    35 : vmovups      ymmword ptr [rsp + 0x060], ymm13 ; c5 7c 11 ac 24 60 00 00 00     
    36 : mov          rcx, 0x03e2aaaaa                 ; 48 c7 c1 aa aa 2a 3e           
    37 : vpinsrd      xmm9, xmm9, ecx, 0               ; c4 63 31 22 c9 00              
    38 : vpbroadcastd ymm13, xmm9                      ; c4 42 7d 58 e9                 
    39 : vmovups      ymmword ptr [rsp + 0x040], ymm13 ; c5 7c 11 ac 24 40 00 00 00     
    40 : mov          rcx, 0x03f000000                 ; 48 c7 c1 00 00 00 3f           
    41 : vpinsrd      xmm9, xmm9, ecx, 0               ; c4 63 31 22 c9 00              
    42 : vpbroadcastd ymm13, xmm9                      ; c4 42 7d 58 e9                 
    43 : vmovups      ymmword ptr [rsp + 0x020], ymm13 ; c5 7c 11 ac 24 20 00 00 00     
    44 : mov          rcx, 0x07f                       ; 48 c7 c1 7f 00 00 00           
    45 : vpinsrd      xmm9, xmm9, ecx, 0               ; c4 63 31 22 c9 00              
    46 : vpbroadcastd ymm13, xmm9                      ; c4 42 7d 58 e9                 
    47 : vmovdqu      ymmword ptr [rsp + 0], ymm13     ; c5 7e 7f ac 24 00 00 00 00     
    48 : xor          rcx, rcx                         ; 48 31 c9                       
    49 :              __loops_label_0:                 ;                                
    50 : cmp          rdx, 0                           ; 48 83 fa 00                    
    51 : jle          __loops_label_2                  ; 0f 8e c5 00 00 00              
    52 : vmovups      ymm12, ymmword ptr [rsi + rcx]   ; c5 7c 10 24 0e                 
    53 : vminps       ymm12, ymm12, ymm1               ; c5 1c 5d e1                    
    54 : vmaxps       ymm12, ymm12, ymm0               ; c5 1c 5f e0                    
    55 : vmovups      ymm11, ymm2                      ; c5 7c 10 da                    
    56 : vfmadd231ps  ymm11, ymm12, ymm4               ; c4 62 1d b8 dc                 
    57 : vroundps     ymm11, ymm11, 0x001              ; c4 43 7d 08 db 01              
    58 : vcvtps2dq    ymm11, ymm11                     ; c4 41 7d 5b db                 
    59 : vcvtdq2ps    ymm10, ymm11                     ; c4 41 7c 5b d3                 
    60 : vfmadd231ps  ymm12, ymm10, ymm5               ; c4 62 2d b8 e5                 
    61 : vfmadd231ps  ymm12, ymm10, ymm6               ; c4 62 2d b8 e6                 
    62 : vmovups      ymm10, ymm8                      ; c4 41 7c 10 d0                 
    63 : vfmadd231ps  ymm10, ymm12, ymm7               ; c4 62 1d b8 d7                 
    64 : vmovups      ymm13, ymmword ptr [rsp + 0x080] ; c5 7c 10 ac 24 80 00 00 00     
    65 : vmovups      ymm9, ymm13                      ; c4 41 7c 10 cd                 
    66 : vfmadd231ps  ymm9, ymm10, ymm12               ; c4 42 2d b8 cc                 
    67 : vmovups      ymm13, ymmword ptr [rsp + 0x060] ; c5 7c 10 ac 24 60 00 00 00     
    68 : vmovups      ymm10, ymm13                     ; c4 41 7c 10 d5                 
    69 : vfmadd231ps  ymm10, ymm9, ymm12               ; c4 42 35 b8 d4                 
    70 : vmovups      ymm13, ymmword ptr [rsp + 0x040] ; c5 7c 10 ac 24 40 00 00 00     
    71 : vmovups      ymm9, ymm13                      ; c4 41 7c 10 cd                 
    72 : vfmadd231ps  ymm9, ymm10, ymm12               ; c4 42 2d b8 cc                 
    73 : vmovups      ymm13, ymmword ptr [rsp + 0x020] ; c5 7c 10 ac 24 20 00 00 00     
    74 : vmovups      ymm10, ymm13                     ; c4 41 7c 10 d5                 
    75 : vfmadd231ps  ymm10, ymm9, ymm12               ; c4 42 35 b8 d4                 
    76 : vmulps       ymm9, ymm12, ymm12               ; c4 41 1c 59 cc                 
    77 : vfmadd231ps  ymm12, ymm10, ymm9               ; c4 42 2d b8 e1                 
    78 : vaddps       ymm9, ymm12, ymm3                ; c5 1c 58 cb                    
    79 : vmovdqu      ymm13, ymmword ptr [rsp + 0]     ; c5 7e 6f ac 24 00 00 00 00     
    80 : vpaddd       ymm10, ymm11, ymm13              ; c4 41 25 fe d5                 
    81 : vpslld       ymm10, ymm10, 0x017              ; c4 c1 2d 72 f2 17              
    82 : vmulps       ymm9, ymm9, ymm10                ; c4 41 34 59 ca                 
    83 : vmovups      ymmword ptr [rdi + rcx], ymm9    ; c5 7c 11 0c 0f                 
    84 : add          rcx, 0x020                       ; 48 81 c1 20 00 00 00           
    85 : sub          rdx, 0x008                       ; 48 81 ea 08 00 00 00           
    86 : jmp          __loops_label_0                  ; e9 31 ff ff ff                 
    87 :              __loops_label_2:                 ;                                
    88 : add          rsp, 0x0a8                       ; 48 81 c4 a8 00 00 00           
    89 : ret                                           ; c3                             
