ten_args_to_sum(i0, i1, i2, i3, i4, i5, i6, i7, i8, i9)
     0 : sub  rsp, 0x028                   ; 48 81 ec 28 00 00 00     
     1 : mov  rax, qword ptr [rsp + 0x030] ; 48 8b 84 24 30 00 00 00  
     2 : imul rdi, 0x001                   ; 48 6b ff 01              
     3 : imul rsi, 0x002                   ; 48 6b f6 02              
     4 : add  rsi, rdi                     ; 48 01 fe                 
     5 : imul rdx, 0x003                   ; 48 6b d2 03              
     6 : add  rdx, rsi                     ; 48 01 f2                 
     7 : imul rcx, 0x004                   ; 48 6b c9 04              
     8 : add  rcx, rdx                     ; 48 01 d1                 
     9 : imul r8, 0x005                    ; 4d 6b c0 05              
    10 : add  r8, rcx                      ; 49 01 c8                 
    11 : imul r9, 0x006                    ; 4d 6b c9 06              
    12 : add  r9, r8                       ; 4d 01 c1                 
    13 : imul rax, 0x007                   ; 48 6b c0 07              
    14 : add  rax, r9                      ; 4c 01 c8                 
    15 : mov  rdi, qword ptr [rsp + 0x038] ; 48 8b bc 24 38 00 00 00  
    16 : imul rdi, 0x008                   ; 48 6b ff 08              
    17 : add  rdi, rax                     ; 48 01 c7                 
    18 : mov  rsi, qword ptr [rsp + 0x040] ; 48 8b b4 24 40 00 00 00  
    19 : imul rsi, 0x003                   ; 48 6b f6 03              
    20 : add  rsi, rdi                     ; 48 01 fe                 
    21 : mov  rdi, qword ptr [rsp + 0x048] ; 48 8b bc 24 48 00 00 00  
    22 : imul rdi, 0x002                   ; 48 6b ff 02              
    23 : add  rdi, rsi                     ; 48 01 f7                 
    24 : mov  rax, rdi                     ; 48 89 f8                 
    25 : add  rsp, 0x028                   ; 48 81 c4 28 00 00 00     
    26 : ret                               ; c3                       
