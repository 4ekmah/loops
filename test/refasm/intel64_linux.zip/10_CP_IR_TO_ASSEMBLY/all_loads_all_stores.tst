all_loads_all_stores(i0, i1, i2, i3, i4)
     0 : sub    rsp, 0x068                     ; 48 81 ec 68 00 00 00                 
     1 : mov    qword ptr [rsp + 0x058], r13   ; 4c 89 ac 24 58 00 00 00              
     2 : mov    qword ptr [rsp + 0x020], 0     ; 48 c7 84 24 20 00 00 00 00 00 00 00  
     3 : mov    qword ptr [rsp], 0             ; 48 c7 84 24 00 00 00 00 00 00 00 00  
     4 : mov    qword ptr [rsp + 0x008], 0     ; 48 c7 84 24 08 00 00 00 00 00 00 00  
     5 : mov    rax, 0x002                     ; 48 c7 c0 02 00 00 00                 
     6 : mov    qword ptr [rsp + 0x028], 0x001 ; 48 c7 84 24 28 00 00 00 01 00 00 00  
     7 : cmp    rsi, 0x001                     ; 48 83 fe 01                          
     8 : mov    r13, qword ptr [rsp + 0x028]   ; 4c 8b ac 24 28 00 00 00              
     9 : cmovle rax, r13                       ; 49 0f 4e c5                          
    10 : mov    qword ptr [rsp + 0x030], 0x004 ; 48 c7 84 24 30 00 00 00 04 00 00 00  
    11 : cmp    rsi, 0x003                     ; 48 83 fe 03                          
    12 : cmovg  rax, qword ptr [rsp + 0x030]   ; 48 0f 4f 84 24 30 00 00 00           
    13 : mov    qword ptr [rsp + 0x038], 0x008 ; 48 c7 84 24 38 00 00 00 08 00 00 00  
    14 : cmp    rsi, 0x005                     ; 48 83 fe 05                          
    15 : mov    r13, rax                       ; 49 89 c5                             
    16 : cmovg  r13, qword ptr [rsp + 0x038]   ; 4c 0f 4f ac 24 38 00 00 00           
    17 : mov    qword ptr [rsp + 0x010], r13   ; 4c 89 ac 24 10 00 00 00              
    18 : mov    rax, 0x002                     ; 48 c7 c0 02 00 00 00                 
    19 : mov    qword ptr [rsp + 0x040], 0x001 ; 48 c7 84 24 40 00 00 00 01 00 00 00  
    20 : cmp    rcx, 0x001                     ; 48 83 f9 01                          
    21 : mov    r13, qword ptr [rsp + 0x040]   ; 4c 8b ac 24 40 00 00 00              
    22 : cmovle rax, r13                       ; 49 0f 4e c5                          
    23 : mov    qword ptr [rsp + 0x048], 0x004 ; 48 c7 84 24 48 00 00 00 04 00 00 00  
    24 : cmp    rcx, 0x003                     ; 48 83 f9 03                          
    25 : cmovg  rax, qword ptr [rsp + 0x048]   ; 48 0f 4f 84 24 48 00 00 00           
    26 : mov    qword ptr [rsp + 0x050], 0x008 ; 48 c7 84 24 50 00 00 00 08 00 00 00  
    27 : cmp    rcx, 0x005                     ; 48 83 f9 05                          
    28 : mov    r13, rax                       ; 49 89 c5                             
    29 : cmovg  r13, qword ptr [rsp + 0x050]   ; 4c 0f 4f ac 24 50 00 00 00           
    30 : mov    qword ptr [rsp + 0x018], r13   ; 4c 89 ac 24 18 00 00 00              
    31 :        __loops_label_0:               ;                                      
    32 : cmp    qword ptr [rsp + 0x020], r8    ; 4c 39 84 24 20 00 00 00              
    33 : jge    __loops_label_2                ; 0f 8d c9 01 00 00                    
    34 : cmp    rsi, 0                         ; 48 83 fe 00                          
    35 : jne    __loops_label_4                ; 0f 85 12 00 00 00                    
    36 : mov    r13, qword ptr [rsp]           ; 4c 8b ac 24 00 00 00 00              
    37 : movzx  rax, byte ptr [rdi + r13]      ; 4a 0f b6 04 2f                       
    38 : jmp    __loops_label_23               ; e9 b1 00 00 00                       
    39 :        __loops_label_4:               ;                                      
    40 : cmp    rsi, 0x001                     ; 48 83 fe 01                          
    41 : jne    __loops_label_7                ; 0f 85 12 00 00 00                    
    42 : mov    r13, qword ptr [rsp]           ; 4c 8b ac 24 00 00 00 00              
    43 : movsx  rax, byte ptr [rdi + r13]      ; 4a 0f be 04 2f                       
    44 : jmp    __loops_label_23               ; e9 95 00 00 00                       
    45 :        __loops_label_7:               ;                                      
    46 : cmp    rsi, 0x002                     ; 48 83 fe 02                          
    47 : jne    __loops_label_10               ; 0f 85 12 00 00 00                    
    48 : mov    r13, qword ptr [rsp]           ; 4c 8b ac 24 00 00 00 00              
    49 : movzx  rax, word ptr [rdi + r13]      ; 4a 0f b7 04 2f                       
    50 : jmp    __loops_label_23               ; e9 79 00 00 00                       
    51 :        __loops_label_10:              ;                                      
    52 : cmp    rsi, 0x003                     ; 48 83 fe 03                          
    53 : jne    __loops_label_13               ; 0f 85 12 00 00 00                    
    54 : mov    r13, qword ptr [rsp]           ; 4c 8b ac 24 00 00 00 00              
    55 : movsx  rax, word ptr [rdi + r13]      ; 4a 0f bf 04 2f                       
    56 : jmp    __loops_label_23               ; e9 5d 00 00 00                       
    57 :        __loops_label_13:              ;                                      
    58 : cmp    rsi, 0x004                     ; 48 83 fe 04                          
    59 : jne    __loops_label_16               ; 0f 85 11 00 00 00                    
    60 : mov    r13, qword ptr [rsp]           ; 4c 8b ac 24 00 00 00 00              
    61 : mov    eax, dword ptr [rdi + r13]     ; 42 8b 04 2f                          
    62 : jmp    __loops_label_23               ; e9 42 00 00 00                       
    63 :        __loops_label_16:              ;                                      
    64 : cmp    rsi, 0x005                     ; 48 83 fe 05                          
    65 : jne    __loops_label_19               ; 0f 85 11 00 00 00                    
    66 : mov    r13, qword ptr [rsp]           ; 4c 8b ac 24 00 00 00 00              
    67 : movsxd rax, dword ptr [rdi + r13]     ; 4a 63 04 2f                          
    68 : jmp    __loops_label_23               ; e9 27 00 00 00                       
    69 :        __loops_label_19:              ;                                      
    70 : cmp    rsi, 0x006                     ; 48 83 fe 06                          
    71 : jne    __loops_label_22               ; 0f 85 11 00 00 00                    
    72 : mov    r13, qword ptr [rsp]           ; 4c 8b ac 24 00 00 00 00              
    73 : mov    rax, qword ptr [rdi + r13]     ; 4a 8b 04 2f                          
    74 : jmp    __loops_label_23               ; e9 0c 00 00 00                       
    75 :        __loops_label_22:              ;                                      
    76 : mov    r13, qword ptr [rsp]           ; 4c 8b ac 24 00 00 00 00              
    77 : mov    rax, qword ptr [rdi + r13]     ; 4a 8b 04 2f                          
    78 :        __loops_label_5:               ;                                      
    79 :        __loops_label_8:               ;                                      
    80 :        __loops_label_11:              ;                                      
    81 :        __loops_label_14:              ;                                      
    82 :        __loops_label_17:              ;                                      
    83 :        __loops_label_20:              ;                                      
    84 :        __loops_label_23:              ;                                      
    85 : cmp    rcx, 0                         ; 48 83 f9 00                          
    86 : jne    __loops_label_25               ; 0f 85 11 00 00 00                    
    87 : mov    r13, qword ptr [rsp + 0x008]   ; 4c 8b ac 24 08 00 00 00              
    88 : mov    byte ptr [rdx + r13], al       ; 42 88 04 2a                          
    89 : jmp    __loops_label_44               ; e9 b0 00 00 00                       
    90 :        __loops_label_25:              ;                                      
    91 : cmp    rcx, 0x001                     ; 48 83 f9 01                          
    92 : jne    __loops_label_28               ; 0f 85 11 00 00 00                    
    93 : mov    r13, qword ptr [rsp + 0x008]   ; 4c 8b ac 24 08 00 00 00              
    94 : mov    byte ptr [rdx + r13], al       ; 42 88 04 2a                          
    95 : jmp    __loops_label_44               ; e9 95 00 00 00                       
    96 :        __loops_label_28:              ;                                      
    97 : cmp    rcx, 0x002                     ; 48 83 f9 02                          
    98 : jne    __loops_label_31               ; 0f 85 12 00 00 00                    
    99 : mov    r13, qword ptr [rsp + 0x008]   ; 4c 8b ac 24 08 00 00 00              
   100 : mov    word ptr [rdx + r13], ax       ; 66 42 89 04 2a                       
   101 : jmp    __loops_label_44               ; e9 79 00 00 00                       
   102 :        __loops_label_31:              ;                                      
   103 : cmp    rcx, 0x003                     ; 48 83 f9 03                          
   104 : jne    __loops_label_34               ; 0f 85 12 00 00 00                    
   105 : mov    r13, qword ptr [rsp + 0x008]   ; 4c 8b ac 24 08 00 00 00              
   106 : mov    word ptr [rdx + r13], ax       ; 66 42 89 04 2a                       
   107 : jmp    __loops_label_44               ; e9 5d 00 00 00                       
   108 :        __loops_label_34:              ;                                      
   109 : cmp    rcx, 0x004                     ; 48 83 f9 04                          
   110 : jne    __loops_label_37               ; 0f 85 11 00 00 00                    
   111 : mov    r13, qword ptr [rsp + 0x008]   ; 4c 8b ac 24 08 00 00 00              
   112 : mov    dword ptr [rdx + r13], eax     ; 42 89 04 2a                          
   113 : jmp    __loops_label_44               ; e9 42 00 00 00                       
   114 :        __loops_label_37:              ;                                      
   115 : cmp    rcx, 0x005                     ; 48 83 f9 05                          
   116 : jne    __loops_label_40               ; 0f 85 11 00 00 00                    
   117 : mov    r13, qword ptr [rsp + 0x008]   ; 4c 8b ac 24 08 00 00 00              
   118 : mov    dword ptr [rdx + r13], eax     ; 42 89 04 2a                          
   119 : jmp    __loops_label_44               ; e9 27 00 00 00                       
   120 :        __loops_label_40:              ;                                      
   121 : cmp    rcx, 0x006                     ; 48 83 f9 06                          
   122 : jne    __loops_label_43               ; 0f 85 11 00 00 00                    
   123 : mov    r13, qword ptr [rsp + 0x008]   ; 4c 8b ac 24 08 00 00 00              
   124 : mov    qword ptr [rdx + r13], rax     ; 4a 89 04 2a                          
   125 : jmp    __loops_label_44               ; e9 0c 00 00 00                       
   126 :        __loops_label_43:              ;                                      
   127 : mov    r13, qword ptr [rsp + 0x008]   ; 4c 8b ac 24 08 00 00 00              
   128 : mov    qword ptr [rdx + r13], rax     ; 4a 89 04 2a                          
   129 :        __loops_label_26:              ;                                      
   130 :        __loops_label_29:              ;                                      
   131 :        __loops_label_32:              ;                                      
   132 :        __loops_label_35:              ;                                      
   133 :        __loops_label_38:              ;                                      
   134 :        __loops_label_41:              ;                                      
   135 :        __loops_label_44:              ;                                      
   136 : mov    r13, qword ptr [rsp + 0x010]   ; 4c 8b ac 24 10 00 00 00              
   137 : add    qword ptr [rsp], r13           ; 4c 01 ac 24 00 00 00 00              
   138 : mov    r13, qword ptr [rsp + 0x018]   ; 4c 8b ac 24 18 00 00 00              
   139 : add    qword ptr [rsp + 0x008], r13   ; 4c 01 ac 24 08 00 00 00              
   140 : add    qword ptr [rsp + 0x020], 0x001 ; 48 81 84 24 20 00 00 00 01 00 00 00  
   141 : jmp    __loops_label_0                ; e9 29 fe ff ff                       
   142 :        __loops_label_2:               ;                                      
   143 : mov    r13, qword ptr [rsp + 0x058]   ; 4c 8b ac 24 58 00 00 00              
   144 : add    rsp, 0x068                     ; 48 81 c4 68 00 00 00                 
   145 : ret                                   ; c3                                   
