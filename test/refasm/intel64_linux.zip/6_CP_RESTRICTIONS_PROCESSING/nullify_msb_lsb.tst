nullify_msb_lsb(i0, i1, i2)
     0 : mov       i12, i0       
     1 : shr       i12, i12, 1   
     2 : mov       i3, i12       
     3 : or        i3, i3, i0    
     4 : mov       i13, i3       
     5 : shr       i13, i13, 2   
     6 : mov       i4, i13       
     7 : or        i4, i4, i3    
     8 : mov       i14, i4       
     9 : shr       i14, i14, 4   
    10 : mov       i5, i14       
    11 : or        i5, i5, i4    
    12 : mov       i15, i5       
    13 : shr       i15, i15, 8   
    14 : mov       i6, i15       
    15 : or        i6, i6, i5    
    16 : mov       i16, i6       
    17 : shr       i16, i16, 16  
    18 : mov       i7, i16       
    19 : or        i7, i7, i6    
    20 : mov       i17, i7       
    21 : shr       i17, i17, 32  
    22 : mov       i8, i17       
    23 : or        i8, i8, i7    
    24 : mov       i9, i8        
    25 : add       i9, i9, 1     
    26 : mov       i10, i9       
    27 : shr       i10, i10, 1   
    28 : mov       i11, i10      
    29 : xor       i11, i11, i0  
    30 : store.u64 i2, i11       
    31 : sub       i21, i0, 1    
    32 : mov       i20, i21      
    33 : not       i20, i20      
    34 : mov       i18, i20      
    35 : and       i18, i18, i0  
    36 : mov       i19, i0       
    37 : xor       i19, i19, i18 
    38 : store.u64 i1, i19       
    39 : ret                     
