min_max_select(i0, i1, i2, i3)
     0 : mov                    i5, 0           
     1 : mov                    i6, 0           
     2 : mov                    i7, 0           
     3 : load.i32               i8, i0          
     4 : mov                    i9, i8          
     5 : mov                    i4, i1          
     6 : shl                    i4, i4, 2       
     7 : annotation:whilecstart 0               
     8 : cmp                    i5, i4          
     9 : jmp_ge                 __loops_label_2 
    10 : annotation:whilecend                   
    11 : load.i32               i10, i0, i5     
    12 : cmp                    i10, i8         
    13 : select_gt              i6, i5, i6      
    14 : cmp                    i10, i8         
    15 : select_gt              i8, i10, i8     
    16 : cmp                    i10, i9         
    17 : select_gt              i7, i5, i7      
    18 : cmp                    i10, i9         
    19 : select_gt              i9, i10, i9     
    20 : add                    i5, i5, 4       
    21 : annotation:endwhile    0, 2            
    22 : sar                    i6, i6, 2       
    23 : sar                    i7, i7, 2       
    24 : store.i32              i2, i6          
    25 : store.i32              i3, i7          
    26 : mov                    iR, 0           
    27 : ret                                    
