nullify_msb_lsb_v(i0, i1, i2, i3)
     0 : mov                    i5, 0           
     1 : mov                    i4, i3          
     2 : mul                    i4, i4, 4       
     3 : mov                    i6, 1           
     4 : vdef.u32               v19             
     5 : setlane.u32            v19, 0, i6      
     6 : broadcast.u32          v0, v19, 0      
     7 : annotation:whilecstart 0               
     8 : cmp                    i5, i4          
     9 : jmp_ge                 __loops_label_2 
    10 : annotation:whilecend                   
    11 : vld.u32                v1, i0, i5      
    12 : shr.u32                v10, v1, 1      
    13 : or                     v2, v1, v10     
    14 : shr.u32                v11, v2, 2      
    15 : or                     v3, v2, v11     
    16 : shr.u32                v12, v3, 4      
    17 : or                     v4, v3, v12     
    18 : shr.u32                v13, v4, 8      
    19 : or                     v5, v4, v13     
    20 : shr.u32                v14, v5, 16     
    21 : or                     v6, v5, v14     
    22 : add.u32                v7, v6, v0      
    23 : shr.u32                v8, v7, 1       
    24 : xor                    v9, v8, v1      
    25 : vst.u32                i1, i5, v9      
    26 : sub.u32                v18, v1, v0     
    27 : mov                    i7, 255         
    28 : vdef.u8                v20             
    29 : setlane.u8             v20, 0, i7      
    30 : broadcast.u8           v21, v20, 0     
    31 : xor                    v17, v18, v21   
    32 : and                    v15, v1, v17    
    33 : xor                    v16, v15, v1    
    34 : vst.u32                i2, i5, v16     
    35 : add                    i5, i5, 32      
    36 : annotation:endwhile    0, 2            
    37 : ret                                    
