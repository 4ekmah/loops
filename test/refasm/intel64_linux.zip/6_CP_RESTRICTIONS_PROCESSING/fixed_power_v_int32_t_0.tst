fixed_power_v_int32_t_0(i0, i1, i2)
     0 : mov                    i4, 0           
     1 : mov                    i3, i2          
     2 : mul                    i3, i3, 4       
     3 : annotation:whilecstart 0               
     4 : cmp                    i4, i3          
     5 : jmp_ge                 __loops_label_2 
     6 : annotation:whilecend                   
     7 : vld.i32                v0, i0, i4      
     8 : mov                    i5, 1           
     9 : vdef.i32               v2              
    10 : setlane.i32            v2, 0, i5       
    11 : broadcast.i32          v1, v2, 0       
    12 : vst.i32                i1, i4, v1      
    13 : add                    i4, i4, 32      
    14 : annotation:endwhile    0, 2            
    15 : mov                    iR, 0           
    16 : ret                                    
