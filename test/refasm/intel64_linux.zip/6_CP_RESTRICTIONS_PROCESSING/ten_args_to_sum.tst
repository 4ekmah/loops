ten_args_to_sum(i0, i1, i2, i3, i4, i5, i6, i7, i8, i9)
     0 : mov i10, i0       
     1 : mul i10, i10, 1   
     2 : mov i20, i1       
     3 : mul i20, i20, 2   
     4 : mov i11, i20      
     5 : add i11, i11, i10 
     6 : mov i21, i2       
     7 : mul i21, i21, 3   
     8 : mov i12, i21      
     9 : add i12, i12, i11 
    10 : mov i22, i3       
    11 : mul i22, i22, 4   
    12 : mov i13, i22      
    13 : add i13, i13, i12 
    14 : mov i23, i4       
    15 : mul i23, i23, 5   
    16 : mov i14, i23      
    17 : add i14, i14, i13 
    18 : mov i24, i5       
    19 : mul i24, i24, 6   
    20 : mov i15, i24      
    21 : add i15, i15, i14 
    22 : mov i25, i6       
    23 : mul i25, i25, 7   
    24 : mov i16, i25      
    25 : add i16, i16, i15 
    26 : mov i26, i7       
    27 : mul i26, i26, 8   
    28 : mov i17, i26      
    29 : add i17, i17, i16 
    30 : mov i27, i8       
    31 : mul i27, i27, 3   
    32 : mov i18, i27      
    33 : add i18, i18, i17 
    34 : mov i28, i9       
    35 : mul i28, i28, 2   
    36 : mov i19, i28      
    37 : add i19, i19, i18 
    38 : mov iR, i19       
    39 : ret               
