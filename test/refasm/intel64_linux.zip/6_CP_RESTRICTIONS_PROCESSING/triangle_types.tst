triangle_types(i0, i1, i2)
     0 : annotation:ifcstart                  
     1 : cmp                 i0, 0            
     2 : jmp_le              __loops_label_0  
     3 : cmp                 i1, 0            
     4 : jmp_le              __loops_label_0  
     5 : cmp                 i2, 0            
     6 : jmp_gt              __loops_label_1  
     7 : __loops_label_0:                     
     8 : annotation:ifcend                    
     9 : mov                 iR, 0            
    10 : ret                                  
    11 : annotation:else     1, 2             
    12 : annotation:ifcstart                  
    13 : mov                 i3, i1           
    14 : add                 i3, i3, i2       
    15 : cmp                 i0, i3           
    16 : jmp_gt              __loops_label_3  
    17 : mov                 i4, i0           
    18 : add                 i4, i4, i2       
    19 : cmp                 i1, i4           
    20 : jmp_gt              __loops_label_3  
    21 : mov                 i5, i0           
    22 : add                 i5, i5, i1       
    23 : cmp                 i2, i5           
    24 : jmp_le              __loops_label_4  
    25 : __loops_label_3:                     
    26 : annotation:ifcend                    
    27 : mov                 iR, 0            
    28 : ret                                  
    29 : annotation:else     4, 5             
    30 : annotation:ifcstart                  
    31 : cmp                 i0, i1           
    32 : jmp_ne              __loops_label_7  
    33 : cmp                 i0, i2           
    34 : jmp_ne              __loops_label_7  
    35 : annotation:ifcend                    
    36 : mov                 iR, 2            
    37 : ret                                  
    38 : annotation:else     7, 8             
    39 : annotation:ifcstart                  
    40 : cmp                 i0, i1           
    41 : jmp_eq              __loops_label_9  
    42 : cmp                 i0, i2           
    43 : jmp_eq              __loops_label_9  
    44 : cmp                 i1, i2           
    45 : jmp_ne              __loops_label_10 
    46 : __loops_label_9:                     
    47 : annotation:ifcend                    
    48 : mov                 iR, 3            
    49 : ret                                  
    50 : annotation:else     10, 11           
    51 : annotation:ifcstart                  
    52 : mov                 i6, i0           
    53 : mul                 i6, i6, i0       
    54 : mov                 i8, i1           
    55 : mul                 i8, i8, i1       
    56 : mov                 i9, i2           
    57 : mul                 i9, i9, i2       
    58 : mov                 i7, i9           
    59 : add                 i7, i7, i8       
    60 : cmp                 i6, i7           
    61 : jmp_eq              __loops_label_12 
    62 : mov                 i10, i1          
    63 : mul                 i10, i10, i1     
    64 : mov                 i12, i0          
    65 : mul                 i12, i12, i0     
    66 : mov                 i13, i2          
    67 : mul                 i13, i13, i2     
    68 : mov                 i11, i13         
    69 : add                 i11, i11, i12    
    70 : cmp                 i10, i11         
    71 : jmp_eq              __loops_label_12 
    72 : mov                 i14, i2          
    73 : mul                 i14, i14, i2     
    74 : mov                 i16, i0          
    75 : mul                 i16, i16, i0     
    76 : mov                 i17, i1          
    77 : mul                 i17, i17, i1     
    78 : mov                 i15, i17         
    79 : add                 i15, i15, i16    
    80 : cmp                 i14, i15         
    81 : jmp_ne              __loops_label_13 
    82 : __loops_label_12:                    
    83 : annotation:ifcend                    
    84 : mov                 iR, 1            
    85 : ret                                  
    86 : annotation:else     13, 14           
    87 : annotation:ifcstart                  
    88 : mov                 i18, i0          
    89 : mul                 i18, i18, i0     
    90 : mov                 i20, i1          
    91 : mul                 i20, i20, i1     
    92 : mov                 i21, i2          
    93 : mul                 i21, i21, i2     
    94 : mov                 i19, i21         
    95 : add                 i19, i19, i20    
    96 : cmp                 i18, i19         
    97 : jmp_gt              __loops_label_15 
    98 : mov                 i22, i1          
    99 : mul                 i22, i22, i1     
   100 : mov                 i24, i0          
   101 : mul                 i24, i24, i0     
   102 : mov                 i25, i2          
   103 : mul                 i25, i25, i2     
   104 : mov                 i23, i25         
   105 : add                 i23, i23, i24    
   106 : cmp                 i22, i23         
   107 : jmp_gt              __loops_label_15 
   108 : mov                 i26, i2          
   109 : mul                 i26, i26, i2     
   110 : mov                 i28, i0          
   111 : mul                 i28, i28, i0     
   112 : mov                 i29, i1          
   113 : mul                 i29, i29, i1     
   114 : mov                 i27, i29         
   115 : add                 i27, i27, i28    
   116 : cmp                 i26, i27         
   117 : jmp_le              __loops_label_16 
   118 : __loops_label_15:                    
   119 : annotation:ifcend                    
   120 : mov                 iR, 5            
   121 : ret                                  
   122 : annotation:else     16, 17           
   123 : mov                 iR, 4            
   124 : ret                                  
   125 : annotation:endif    2                
   126 : annotation:endif    5                
   127 : annotation:endif    8                
   128 : annotation:endif    11               
   129 : annotation:endif    14               
   130 : annotation:endif    17               
