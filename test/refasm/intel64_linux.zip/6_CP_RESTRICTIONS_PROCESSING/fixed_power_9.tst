fixed_power_9(i0)
     0 : mov i4, i0     
     1 : mul i4, i4, i0 
     2 : mov i3, i4     
     3 : mul i3, i3, i4 
     4 : mov i2, i3     
     5 : mul i2, i2, i3 
     6 : mov i1, i2     
     7 : mul i1, i1, i0 
     8 : mov iR, i1     
     9 : ret            
