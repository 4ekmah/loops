sort_double(i0, i1)
     0 : mov                    i2, i1            
     1 : shl                    i2, i2, 3         
     2 : sub                    i3, i2, 8         
     3 : mov                    i4, 0             
     4 : annotation:whilecstart 0                 
     5 : cmp                    i4, i3            
     6 : jmp_ge                 __loops_label_2   
     7 : annotation:whilecend                     
     8 : mov                    i5, i4            
     9 : mov                    i6, i5            
    10 : add                    i6, i6, 8         
    11 : annotation:whilecstart 3                 
    12 : cmp                    i6, i2            
    13 : jmp_ge                 __loops_label_5   
    14 : annotation:whilecend                     
    15 : annotation:ifcstart                      
    16 : load.fp64              i8, i0, i6        
    17 : load.fp64              i9, i0, i5        
    18 : mov                    i12, -100336614   
    19 : call                   [i12](i7, i8, i9) 
    20 : cmp                    i7, 0             
    21 : jmp_eq                 __loops_label_7   
    22 : annotation:ifcend                        
    23 : mov                    i5, i6            
    24 : annotation:endif       7                 
    25 : add                    i6, i6, 8         
    26 : annotation:endwhile    3, 5              
    27 : annotation:ifcstart                      
    28 : cmp                    i5, i4            
    29 : jmp_eq                 __loops_label_9   
    30 : annotation:ifcend                        
    31 : load.fp64              i10, i0, i4       
    32 : load.fp64              i11, i0, i5       
    33 : store.fp64             i0, i5, i10       
    34 : store.fp64             i0, i4, i11       
    35 : annotation:endif       9                 
    36 : add                    i4, i4, 8         
    37 : annotation:endwhile    0, 2              
    38 : ret                                      
