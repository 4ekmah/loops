snake(i0, i1, i2)
     0 : mov                    i4, i1           
     1 : add                    i4, i4, i2       
     2 : sub                    i3, i4, 1        
     3 : mov                    i5, 0            
     4 : mov                    i6, 1            
     5 : mov                    i7, i6           
     6 : neg                    i7, i7           
     7 : mov                    i8, 0            
     8 : annotation:whilecstart 0                
     9 : cmp                    i8, i3           
    10 : jmp_ge                 __loops_label_2  
    11 : annotation:whilecend                    
    12 : mov                    i9, 0            
    13 : mov                    i10, 0           
    14 : annotation:ifcstart                     
    15 : mov                    i11, i8          
    16 : and                    i11, i11, 1      
    17 : cmp                    i11, 0           
    18 : jmp_eq                 __loops_label_4  
    19 : annotation:ifcend                       
    20 : sub                    i12, i2, 1       
    21 : cmp                    i12, i8          
    22 : select_gt              i9, i12, i8      
    23 : sub                    i13, i8, i12     
    24 : mov                    i14, 0           
    25 : cmp                    i8, i12          
    26 : select_gt              i10, i13, i14    
    27 : annotation:else        4, 5             
    28 : sub                    i15, i1, 1       
    29 : sub                    i16, i8, i15     
    30 : mov                    i17, 0           
    31 : cmp                    i8, i15          
    32 : select_gt              i9, i16, i17     
    33 : cmp                    i15, i8          
    34 : select_gt              i10, i15, i8     
    35 : annotation:endif       5                
    36 : annotation:whilecstart 6                
    37 : cmp                    i9, 0            
    38 : jmp_gt                 __loops_label_8  
    39 : cmp                    i9, i2           
    40 : jmp_ge                 __loops_label_8  
    41 : cmp                    i10, 0           
    42 : jmp_gt                 __loops_label_8  
    43 : cmp                    i10, i1          
    44 : jmp_ge                 __loops_label_8  
    45 : annotation:whilecend                    
    46 : mov                    i20, -1655113341 
    47 : call_noret             [i20](i9, i10)   
    48 : mov                    i19, i10         
    49 : mul                    i19, i19, i2     
    50 : mov                    i18, i19         
    51 : add                    i18, i18, i9     
    52 : store.u8               i0, i18, i5      
    53 : add                    i5, i5, 1        
    54 : add                    i9, i9, i6       
    55 : add                    i10, i10, i7     
    56 : annotation:endwhile    6, 8             
    57 : neg                    i6, i6           
    58 : neg                    i7, i7           
    59 : add                    i8, i8, 1        
    60 : annotation:endwhile    0, 2             
    61 : ret                                     
