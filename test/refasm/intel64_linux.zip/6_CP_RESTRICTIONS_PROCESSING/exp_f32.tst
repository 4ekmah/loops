exp_f32(i0, i1, i2)
     0 : mov                    i4, -1028603739    
     1 : vdef.fp32              v34                
     2 : setlane.fp32           v34, 0, i4         
     3 : broadcast.fp32         v0, v34, 0         
     4 : mov                    i5, 1118879909     
     5 : vdef.fp32              v35                
     6 : setlane.fp32           v35, 0, i5         
     7 : broadcast.fp32         v1, v35, 0         
     8 : mov                    i6, 1056964608     
     9 : vdef.fp32              v36                
    10 : setlane.fp32           v36, 0, i6         
    11 : broadcast.fp32         v2, v36, 0         
    12 : mov                    i7, 1065353216     
    13 : vdef.fp32              v37                
    14 : setlane.fp32           v37, 0, i7         
    15 : broadcast.fp32         v3, v37, 0         
    16 : mov                    i8, 1069066811     
    17 : vdef.fp32              v38                
    18 : setlane.fp32           v38, 0, i8         
    19 : broadcast.fp32         v4, v38, 0         
    20 : mov                    i9, -1087275008    
    21 : vdef.fp32              v39                
    22 : setlane.fp32           v39, 0, i9         
    23 : broadcast.fp32         v5, v39, 0         
    24 : mov                    i10, 962494595     
    25 : vdef.fp32              v40                
    26 : setlane.fp32           v40, 0, i10        
    27 : broadcast.fp32         v6, v40, 0         
    28 : mov                    i11, 961571175     
    29 : vdef.fp32              v41                
    30 : setlane.fp32           v41, 0, i11        
    31 : broadcast.fp32         v7, v41, 0         
    32 : mov                    i12, 985088974     
    33 : vdef.fp32              v42                
    34 : setlane.fp32           v42, 0, i12        
    35 : broadcast.fp32         v8, v42, 0         
    36 : mov                    i13, 1007192328    
    37 : vdef.fp32              v43                
    38 : setlane.fp32           v43, 0, i13        
    39 : broadcast.fp32         v9, v43, 0         
    40 : mov                    i14, 1026206145    
    41 : vdef.fp32              v44                
    42 : setlane.fp32           v44, 0, i14        
    43 : broadcast.fp32         v10, v44, 0        
    44 : mov                    i15, 1042983594    
    45 : vdef.fp32              v45                
    46 : setlane.fp32           v45, 0, i15        
    47 : broadcast.fp32         v11, v45, 0        
    48 : mov                    i16, 1056964608    
    49 : vdef.fp32              v46                
    50 : setlane.fp32           v46, 0, i16        
    51 : broadcast.fp32         v12, v46, 0        
    52 : mov                    i17, 127           
    53 : vdef.i32               v47                
    54 : setlane.i32            v47, 0, i17        
    55 : broadcast.i32          v13, v47, 0        
    56 : mov                    i3, 0              
    57 : annotation:whilecstart 0                  
    58 : cmp                    i2, 0              
    59 : jmp_le                 __loops_label_2    
    60 : annotation:whilecend                      
    61 : vld.fp32               v14, i1, i3        
    62 : min.fp32               v21, v14, v1       
    63 : max.fp32               v20, v21, v0       
    64 : mov                    v25, v2            
    65 : fma.fp32               v25, v25, v20, v4  
    66 : floor.fp32_fp32        v23, v25           
    67 : cast.fp32_i32          v24, v23           
    68 : cast.i32_fp32          v22, v24           
    69 : mov                    v19, v20           
    70 : fma.fp32               v19, v19, v22, v5  
    71 : mov                    v18, v19           
    72 : fma.fp32               v18, v18, v22, v6  
    73 : mov                    v30, v8            
    74 : fma.fp32               v30, v30, v18, v7  
    75 : mov                    v29, v9            
    76 : fma.fp32               v29, v29, v30, v18 
    77 : mov                    v28, v10           
    78 : fma.fp32               v28, v28, v29, v18 
    79 : mov                    v27, v11           
    80 : fma.fp32               v27, v27, v28, v18 
    81 : mov                    v26, v12           
    82 : fma.fp32               v26, v26, v27, v18 
    83 : mul.fp32               v31, v18, v18      
    84 : mov                    v17, v18           
    85 : fma.fp32               v17, v17, v26, v31 
    86 : add.fp32               v16, v17, v3       
    87 : add.i32                v33, v24, v13      
    88 : sal.i32                v32, v33, 23       
    89 : mul.fp32               v15, v16, v32      
    90 : vst.fp32               i0, i3, v15        
    91 : add                    i3, i3, 32         
    92 : sub                    i2, i2, 8          
    93 : annotation:endwhile    0, 2               
    94 : ret                                       
