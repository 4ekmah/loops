bresenham(i0, i1, i2, i3, i4, i5, i6)
     0 : sub                    i9, i4, i2       
     1 : mov                    i7, i9           
     2 : neg                    i7, i7           
     3 : select_s               i8, i9, i7       
     4 : sub                    i12, i4, i2      
     5 : mov                    i24, i12         
     6 : mov                    i10, i12         
     7 : sar                    i10, i10, 63     
     8 : mov                    i25, i24         
     9 : neg                    i25, i25         
    10 : mov                    i11, i10         
    11 : x86_adc                i11, i11, i10    
    12 : sub                    i16, i5, i3      
    13 : mov                    i14, i16         
    14 : neg                    i14, i14         
    15 : select_s               i15, i16, i14    
    16 : mov                    i13, i15         
    17 : neg                    i13, i13         
    18 : sub                    i19, i5, i3      
    19 : mov                    i26, i19         
    20 : mov                    i17, i19         
    21 : sar                    i17, i17, 63     
    22 : mov                    i27, i26         
    23 : neg                    i27, i27         
    24 : mov                    i18, i17         
    25 : x86_adc                i18, i18, i17    
    26 : mov                    i20, i8          
    27 : add                    i20, i20, i13    
    28 : annotation:whilecstart 0                
    29 : cmp                    i0, 0            
    30 : jmp_eq                 __loops_label_2  
    31 : annotation:whilecend                    
    32 : mov                    i22, i3          
    33 : mul                    i22, i22, i1     
    34 : mov                    i21, i22         
    35 : add                    i21, i21, i2     
    36 : store.u8               i0, i21, i6      
    37 : annotation:ifcstart                     
    38 : cmp                    i2, i4           
    39 : jmp_ne                 __loops_label_4  
    40 : cmp                    i3, i5           
    41 : jmp_ne                 __loops_label_4  
    42 : annotation:ifcend                       
    43 : annotation:break       2                
    44 : annotation:endif       4                
    45 : mov                    i23, i20         
    46 : shl                    i23, i23, 1      
    47 : annotation:ifcstart                     
    48 : cmp                    i23, i13         
    49 : jmp_gt                 __loops_label_6  
    50 : annotation:ifcend                       
    51 : annotation:ifcstart                     
    52 : cmp                    i2, i4           
    53 : jmp_ne                 __loops_label_8  
    54 : annotation:ifcend                       
    55 : annotation:break       2                
    56 : annotation:endif       8                
    57 : add                    i20, i20, i13    
    58 : add                    i2, i2, i11      
    59 : annotation:endif       6                
    60 : annotation:ifcstart                     
    61 : cmp                    i23, i8          
    62 : jmp_gt                 __loops_label_10 
    63 : annotation:ifcend                       
    64 : annotation:ifcstart                     
    65 : cmp                    i3, i5           
    66 : jmp_ne                 __loops_label_12 
    67 : annotation:ifcend                       
    68 : annotation:break       2                
    69 : annotation:endif       12               
    70 : add                    i20, i20, i8     
    71 : add                    i3, i3, i18      
    72 : annotation:endif       10               
    73 : annotation:endwhile    0, 2             
    74 : ret                                     
