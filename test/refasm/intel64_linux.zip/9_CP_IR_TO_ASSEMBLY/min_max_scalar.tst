min_max_scalar(i0, i1, i2, i3)
     0 : sub    rsp, 0x058                   ; 48 81 ec 58 00 00 00                 
     1 : mov    qword ptr [rsp + 0x028], rdx ; 48 89 94 24 28 00 00 00              
     2 : mov    qword ptr [rsp + 0x020], rcx ; 48 89 8c 24 20 00 00 00              
     3 : mov    qword ptr [rsp + 0x048], r13 ; 4c 89 ac 24 48 00 00 00              
     4 : xor    rax, rax                     ; 48 31 c0                             
     5 : mov    qword ptr [rsp + 0x038], 0   ; 48 c7 84 24 38 00 00 00 00 00 00 00  
     6 : mov    qword ptr [rsp + 0x030], 0   ; 48 c7 84 24 30 00 00 00 00 00 00 00  
     7 : movsxd rdx, dword ptr [rdi]         ; 48 63 17                             
     8 : mov    rcx, rdx                     ; 48 89 d1                             
     9 : mov    r13, rsi                     ; 49 89 f5                             
    10 : imul   r13, 0x004                   ; 4d 6b ed 04                          
    11 : mov    qword ptr [rsp + 0x040], r13 ; 4c 89 ac 24 40 00 00 00              
    12 :        __loops_label_0:             ;                                      
    13 : cmp    rax, qword ptr [rsp + 0x040] ; 48 3b 84 24 40 00 00 00              
    14 : jge    __loops_label_2              ; 0f 8d 37 00 00 00                    
    15 : movsxd rsi, dword ptr [rdi + rax]   ; 48 63 34 07                          
    16 : cmp    rsi, rdx                     ; 48 39 d6                             
    17 : jge    __loops_label_4              ; 0f 8d 0b 00 00 00                    
    18 : mov    rdx, rsi                     ; 48 89 f2                             
    19 : mov    qword ptr [rsp + 0x038], rax ; 48 89 84 24 38 00 00 00              
    20 :        __loops_label_4:             ;                                      
    21 : cmp    rsi, rcx                     ; 48 39 ce                             
    22 : jle    __loops_label_6              ; 0f 8e 0b 00 00 00                    
    23 : mov    rcx, rsi                     ; 48 89 f1                             
    24 : mov    qword ptr [rsp + 0x030], rax ; 48 89 84 24 30 00 00 00              
    25 :        __loops_label_6:             ;                                      
    26 : add    rax, 0x004                   ; 48 05 04 00 00 00                    
    27 : jmp    __loops_label_0              ; e9 bb ff ff ff                       
    28 :        __loops_label_2:             ;                                      
    29 : mov    rdi, 0x004                   ; 48 c7 c7 04 00 00 00                 
    30 : mov    r13, qword ptr [rsp + 0x038] ; 4c 8b ac 24 38 00 00 00              
    31 : mov    qword ptr [rsp], rax         ; 48 89 84 24 00 00 00 00              
    32 : mov    qword ptr [rsp + 0x008], rdx ; 48 89 94 24 08 00 00 00              
    33 : mov    rax, r13                     ; 4c 89 e8                             
    34 : cqo                                 ; 48 99                                
    35 : idiv   rdi                          ; 48 f7 ff                             
    36 : mov    rsi, rax                     ; 48 89 c6                             
    37 : mov    rax, qword ptr [rsp]         ; 48 8b 84 24 00 00 00 00              
    38 : mov    rdx, qword ptr [rsp + 0x008] ; 48 8b 94 24 08 00 00 00              
    39 : mov    r13, qword ptr [rsp + 0x030] ; 4c 8b ac 24 30 00 00 00              
    40 : mov    qword ptr [rsp], rax         ; 48 89 84 24 00 00 00 00              
    41 : mov    qword ptr [rsp + 0x008], rdx ; 48 89 94 24 08 00 00 00              
    42 : mov    rax, r13                     ; 4c 89 e8                             
    43 : cqo                                 ; 48 99                                
    44 : idiv   rdi                          ; 48 f7 ff                             
    45 : mov    rdi, rax                     ; 48 89 c7                             
    46 : mov    rax, qword ptr [rsp]         ; 48 8b 84 24 00 00 00 00              
    47 : mov    rdx, qword ptr [rsp + 0x008] ; 48 8b 94 24 08 00 00 00              
    48 : mov    r13, qword ptr [rsp + 0x028] ; 4c 8b ac 24 28 00 00 00              
    49 : mov    dword ptr [r13], esi         ; 41 89 75 00                          
    50 : mov    r13, qword ptr [rsp + 0x020] ; 4c 8b ac 24 20 00 00 00              
    51 : mov    dword ptr [r13], edi         ; 41 89 7d 00                          
    52 : xor    rax, rax                     ; 48 31 c0                             
    53 : mov    r13, qword ptr [rsp + 0x048] ; 4c 8b ac 24 48 00 00 00              
    54 : add    rsp, 0x058                   ; 48 81 c4 58 00 00 00                 
    55 : ret                                 ; c3                                   
