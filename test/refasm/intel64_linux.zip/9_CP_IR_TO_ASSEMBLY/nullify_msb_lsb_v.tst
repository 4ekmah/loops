nullify_msb_lsb_v(i0, i1, i2, i3)
     0 : sub          rsp, 0x018                    ; 48 81 ec 18 00 00 00     
     1 : mov          qword ptr [rsp + 0x008], r13  ; 4c 89 ac 24 08 00 00 00  
     2 : xor          rax, rax                      ; 48 31 c0                 
     3 : mov          r13, rcx                      ; 49 89 cd                 
     4 : imul         r13, 0x004                    ; 4d 6b ed 04              
     5 : mov          qword ptr [rsp], r13          ; 4c 89 ac 24 00 00 00 00  
     6 : mov          rcx, 0x001                    ; 48 c7 c1 01 00 00 00     
     7 : vpinsrd      xmm0, xmm0, ecx, 0            ; c4 e3 79 22 c1 00        
     8 : vpbroadcastd ymm0, xmm0                    ; c4 e2 7d 58 c0           
     9 :              __loops_label_0:              ;                          
    10 : cmp          rax, qword ptr [rsp]          ; 48 3b 84 24 00 00 00 00  
    11 : jge          __loops_label_2               ; 0f 8d 76 00 00 00        
    12 : vmovdqu      ymm1, ymmword ptr [rdi + rax] ; c5 fe 6f 0c 07           
    13 : vpsrld       ymm2, ymm1, 0x001             ; c5 ed 72 d1 01           
    14 : vpor         ymm2, ymm1, ymm2              ; c5 f5 eb d2              
    15 : vpsrld       ymm3, ymm2, 0x002             ; c5 e5 72 d2 02           
    16 : vpor         ymm2, ymm2, ymm3              ; c5 ed eb d3              
    17 : vpsrld       ymm3, ymm2, 0x004             ; c5 e5 72 d2 04           
    18 : vpor         ymm2, ymm2, ymm3              ; c5 ed eb d3              
    19 : vpsrld       ymm3, ymm2, 0x008             ; c5 e5 72 d2 08           
    20 : vpor         ymm2, ymm2, ymm3              ; c5 ed eb d3              
    21 : vpsrld       ymm3, ymm2, 0x010             ; c5 e5 72 d2 10           
    22 : vpor         ymm2, ymm2, ymm3              ; c5 ed eb d3              
    23 : vpaddd       ymm2, ymm2, ymm0              ; c5 ed fe d0              
    24 : vpsrld       ymm2, ymm2, 0x001             ; c5 ed 72 d2 01           
    25 : vpxor        ymm2, ymm2, ymm1              ; c5 ed ef d1              
    26 : vmovdqu      ymmword ptr [rsi + rax], ymm2 ; c5 fe 7f 14 06           
    27 : vpsubd       ymm2, ymm1, ymm0              ; c5 f5 fa d0              
    28 : mov          rcx, 0x0ff                    ; 48 c7 c1 ff 00 00 00     
    29 : vpinsrb      xmm3, xmm3, ecx, 0            ; c4 e3 61 20 d9 00        
    30 : vpbroadcastb ymm3, xmm3                    ; c4 e2 7d 78 db           
    31 : vpxor        ymm2, ymm2, ymm3              ; c5 ed ef d3              
    32 : vpand        ymm2, ymm1, ymm2              ; c5 f5 db d2              
    33 : vpxor        ymm1, ymm2, ymm1              ; c5 ed ef c9              
    34 : vmovdqu      ymmword ptr [rdx + rax], ymm1 ; c5 fe 7f 0c 02           
    35 : add          rax, 0x020                    ; 48 05 20 00 00 00        
    36 : jmp          __loops_label_0               ; e9 7c ff ff ff           
    37 :              __loops_label_2:              ;                          
    38 : mov          r13, qword ptr [rsp + 0x008]  ; 4c 8b ac 24 08 00 00 00  
    39 : add          rsp, 0x018                    ; 48 81 c4 18 00 00 00     
    40 : ret                                        ; c3                       
