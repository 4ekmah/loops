sort_double(i0, i1)
     0 : sub     rsp, 0x02b8                       ; 48 81 ec b8 02 00 00                 
     1 : mov     qword ptr [rsp + 0x02a0], r13     ; 4c 89 ac 24 a0 02 00 00              
     2 : mov     qword ptr [rsp + 0x02a8], r14     ; 4c 89 b4 24 a8 02 00 00              
     3 : mov     qword ptr [rsp + 0x02b0], rbp     ; 48 89 ac 24 b0 02 00 00              
     4 : mov     rbp, rsp                          ; 48 89 e5                             
     5 : add     rbp, 0x02b0                       ; 48 81 c5 b0 02 00 00                 
     6 : mov     qword ptr [rsp + 0x0298], rdi     ; 48 89 bc 24 98 02 00 00              
     7 : mov     qword ptr [rsp + 0x0290], rsi     ; 48 89 b4 24 90 02 00 00              
     8 : shl     qword ptr [rsp + 0x0290], 0x003   ; 48 c1 a4 24 90 02 00 00 03           
     9 : mov     r13, qword ptr [rsp + 0x0290]     ; 4c 8b ac 24 90 02 00 00              
    10 : mov     qword ptr [rsp + 0x0288], r13     ; 4c 89 ac 24 88 02 00 00              
    11 : sub     qword ptr [rsp + 0x0288], 0x008   ; 48 81 ac 24 88 02 00 00 08 00 00 00  
    12 : mov     qword ptr [rsp + 0x0280], 0       ; 48 c7 84 24 80 02 00 00 00 00 00 00  
    13 :         __loops_label_0:                  ;                                      
    14 : mov     r13, qword ptr [rsp + 0x0288]     ; 4c 8b ac 24 88 02 00 00              
    15 : cmp     qword ptr [rsp + 0x0280], r13     ; 4c 39 ac 24 80 02 00 00              
    16 : jge     __loops_label_2                   ; 0f 8d 79 02 00 00                    
    17 : mov     rax, qword ptr [rsp + 0x0280]     ; 48 8b 84 24 80 02 00 00              
    18 : mov     rcx, rax                          ; 48 89 c1                             
    19 : add     rcx, 0x008                        ; 48 81 c1 08 00 00 00                 
    20 :         __loops_label_3:                  ;                                      
    21 : cmp     rcx, qword ptr [rsp + 0x0290]     ; 48 3b 8c 24 90 02 00 00              
    22 : jge     __loops_label_5                   ; 0f 8d f6 01 00 00                    
    23 : mov     r13, qword ptr [rsp + 0x0298]     ; 4c 8b ac 24 98 02 00 00              
    24 : mov     rdx, qword ptr [r13 + rcx]        ; 49 8b 54 0d 00                       
    25 : mov     r13, qword ptr [rsp + 0x0298]     ; 4c 8b ac 24 98 02 00 00              
    26 : mov     rsi, qword ptr [r13 + rax]        ; 49 8b 74 05 00                       
    27 : mov     rdi, 0x0559d086e73a8              ; 48 bf a8 73 6e 08 9d 55 00 00        
    28 : mov     qword ptr [rsp], rax              ; 48 89 84 24 00 00 00 00              
    29 : mov     qword ptr [rsp + 0x008], rcx      ; 48 89 8c 24 08 00 00 00              
    30 : mov     qword ptr [rsp + 0x010], rdx      ; 48 89 94 24 10 00 00 00              
    31 : mov     qword ptr [rsp + 0x018], rsi      ; 48 89 b4 24 18 00 00 00              
    32 : mov     qword ptr [rsp + 0x020], rdi      ; 48 89 bc 24 20 00 00 00              
    33 : mov     qword ptr [rsp + 0x028], r8       ; 4c 89 84 24 28 00 00 00              
    34 : mov     qword ptr [rsp + 0x030], r9       ; 4c 89 8c 24 30 00 00 00              
    35 : mov     qword ptr [rsp + 0x038], r10      ; 4c 89 94 24 38 00 00 00              
    36 : mov     qword ptr [rsp + 0x040], r11      ; 4c 89 9c 24 40 00 00 00              
    37 : vmovdqu ymmword ptr [rsp + 0x060], ymm0   ; c5 fe 7f 84 24 60 00 00 00           
    38 : vmovdqu ymmword ptr [rsp + 0x080], ymm1   ; c5 fe 7f 8c 24 80 00 00 00           
    39 : vmovdqu ymmword ptr [rsp + 0x0a0], ymm2   ; c5 fe 7f 94 24 a0 00 00 00           
    40 : vmovdqu ymmword ptr [rsp + 0x0c0], ymm3   ; c5 fe 7f 9c 24 c0 00 00 00           
    41 : vmovdqu ymmword ptr [rsp + 0x0e0], ymm4   ; c5 fe 7f a4 24 e0 00 00 00           
    42 : vmovdqu ymmword ptr [rsp + 0x0100], ymm5  ; c5 fe 7f ac 24 00 01 00 00           
    43 : vmovdqu ymmword ptr [rsp + 0x0120], ymm6  ; c5 fe 7f b4 24 20 01 00 00           
    44 : vmovdqu ymmword ptr [rsp + 0x0140], ymm7  ; c5 fe 7f bc 24 40 01 00 00           
    45 : vmovdqu ymmword ptr [rsp + 0x0160], ymm8  ; c5 7e 7f 84 24 60 01 00 00           
    46 : vmovdqu ymmword ptr [rsp + 0x0180], ymm9  ; c5 7e 7f 8c 24 80 01 00 00           
    47 : vmovdqu ymmword ptr [rsp + 0x01a0], ymm10 ; c5 7e 7f 94 24 a0 01 00 00           
    48 : vmovdqu ymmword ptr [rsp + 0x01c0], ymm11 ; c5 7e 7f 9c 24 c0 01 00 00           
    49 : vmovdqu ymmword ptr [rsp + 0x01e0], ymm12 ; c5 7e 7f a4 24 e0 01 00 00           
    50 : vmovdqu ymmword ptr [rsp + 0x0200], ymm13 ; c5 7e 7f ac 24 00 02 00 00           
    51 : vmovdqu ymmword ptr [rsp + 0x0220], ymm14 ; c5 7e 7f b4 24 20 02 00 00           
    52 : vmovdqu ymmword ptr [rsp + 0x0240], ymm15 ; c5 7e 7f bc 24 40 02 00 00           
    53 : mov     rdi, rdx                          ; 48 89 d7                             
    54 : mov     r10, qword ptr [rsp + 0x020]      ; 4c 8b 94 24 20 00 00 00              
    55 : call    r10                               ; 41 ff d2                             
    56 : mov     rdi, rax                          ; 48 89 c7                             
    57 : mov     rax, qword ptr [rsp]              ; 48 8b 84 24 00 00 00 00              
    58 : mov     rcx, qword ptr [rsp + 0x008]      ; 48 8b 8c 24 08 00 00 00              
    59 : mov     rdx, qword ptr [rsp + 0x010]      ; 48 8b 94 24 10 00 00 00              
    60 : mov     rsi, qword ptr [rsp + 0x018]      ; 48 8b b4 24 18 00 00 00              
    61 : mov     r8, qword ptr [rsp + 0x028]       ; 4c 8b 84 24 28 00 00 00              
    62 : mov     r9, qword ptr [rsp + 0x030]       ; 4c 8b 8c 24 30 00 00 00              
    63 : mov     r10, qword ptr [rsp + 0x038]      ; 4c 8b 94 24 38 00 00 00              
    64 : mov     r11, qword ptr [rsp + 0x040]      ; 4c 8b 9c 24 40 00 00 00              
    65 : vmovdqu ymm0, ymmword ptr [rsp + 0x060]   ; c5 fe 6f 84 24 60 00 00 00           
    66 : vmovdqu ymm1, ymmword ptr [rsp + 0x080]   ; c5 fe 6f 8c 24 80 00 00 00           
    67 : vmovdqu ymm2, ymmword ptr [rsp + 0x0a0]   ; c5 fe 6f 94 24 a0 00 00 00           
    68 : vmovdqu ymm3, ymmword ptr [rsp + 0x0c0]   ; c5 fe 6f 9c 24 c0 00 00 00           
    69 : vmovdqu ymm4, ymmword ptr [rsp + 0x0e0]   ; c5 fe 6f a4 24 e0 00 00 00           
    70 : vmovdqu ymm5, ymmword ptr [rsp + 0x0100]  ; c5 fe 6f ac 24 00 01 00 00           
    71 : vmovdqu ymm6, ymmword ptr [rsp + 0x0120]  ; c5 fe 6f b4 24 20 01 00 00           
    72 : vmovdqu ymm7, ymmword ptr [rsp + 0x0140]  ; c5 fe 6f bc 24 40 01 00 00           
    73 : vmovdqu ymm8, ymmword ptr [rsp + 0x0160]  ; c5 7e 6f 84 24 60 01 00 00           
    74 : vmovdqu ymm9, ymmword ptr [rsp + 0x0180]  ; c5 7e 6f 8c 24 80 01 00 00           
    75 : vmovdqu ymm10, ymmword ptr [rsp + 0x01a0] ; c5 7e 6f 94 24 a0 01 00 00           
    76 : vmovdqu ymm11, ymmword ptr [rsp + 0x01c0] ; c5 7e 6f 9c 24 c0 01 00 00           
    77 : vmovdqu ymm12, ymmword ptr [rsp + 0x01e0] ; c5 7e 6f a4 24 e0 01 00 00           
    78 : vmovdqu ymm13, ymmword ptr [rsp + 0x0200] ; c5 7e 6f ac 24 00 02 00 00           
    79 : vmovdqu ymm14, ymmword ptr [rsp + 0x0220] ; c5 7e 6f b4 24 20 02 00 00           
    80 : vmovdqu ymm15, ymmword ptr [rsp + 0x0240] ; c5 7e 6f bc 24 40 02 00 00           
    81 : cmp     rdi, 0                            ; 48 83 ff 00                          
    82 : je      __loops_label_7                   ; 0f 84 03 00 00 00                    
    83 : mov     rax, rcx                          ; 48 89 c8                             
    84 :         __loops_label_7:                  ;                                      
    85 : add     rcx, 0x008                        ; 48 81 c1 08 00 00 00                 
    86 : jmp     __loops_label_3                   ; e9 fc fd ff ff                       
    87 :         __loops_label_5:                  ;                                      
    88 : cmp     rax, qword ptr [rsp + 0x0280]     ; 48 3b 84 24 80 02 00 00              
    89 : je      __loops_label_9                   ; 0f 84 44 00 00 00                    
    90 : mov     r13, qword ptr [rsp + 0x0298]     ; 4c 8b ac 24 98 02 00 00              
    91 : mov     r14, qword ptr [rsp + 0x0280]     ; 4c 8b b4 24 80 02 00 00              
    92 : mov     rdi, qword ptr [r13 + r14]        ; 4b 8b 7c 35 00                       
    93 : mov     r13, qword ptr [rsp + 0x0298]     ; 4c 8b ac 24 98 02 00 00              
    94 : mov     rsi, qword ptr [r13 + rax]        ; 49 8b 74 05 00                       
    95 : mov     r13, qword ptr [rsp + 0x0298]     ; 4c 8b ac 24 98 02 00 00              
    96 : mov     qword ptr [r13 + rax], rdi        ; 49 89 7c 05 00                       
    97 : mov     r13, qword ptr [rsp + 0x0298]     ; 4c 8b ac 24 98 02 00 00              
    98 : mov     r14, qword ptr [rsp + 0x0280]     ; 4c 8b b4 24 80 02 00 00              
    99 : mov     qword ptr [r13 + r14], rsi        ; 4b 89 74 35 00                       
   100 :         __loops_label_9:                  ;                                      
   101 : add     qword ptr [rsp + 0x0280], 0x008   ; 48 81 84 24 80 02 00 00 08 00 00 00  
   102 : jmp     __loops_label_0                   ; e9 71 fd ff ff                       
   103 :         __loops_label_2:                  ;                                      
   104 : mov     rbp, qword ptr [rsp + 0x02b0]     ; 48 8b ac 24 b0 02 00 00              
   105 : mov     r13, qword ptr [rsp + 0x02a0]     ; 4c 8b ac 24 a0 02 00 00              
   106 : mov     r14, qword ptr [rsp + 0x02a8]     ; 4c 8b b4 24 a8 02 00 00              
   107 : add     rsp, 0x02b8                       ; 48 81 c4 b8 02 00 00                 
   108 : ret                                       ; c3                                   
