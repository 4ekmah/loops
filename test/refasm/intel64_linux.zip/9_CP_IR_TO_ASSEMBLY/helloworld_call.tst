helloworld_call()
     0 : sub     rsp, 0x0288                       ; 48 81 ec 88 02 00 00           
     1 : mov     qword ptr [rsp + 0x0280], rbp     ; 48 89 ac 24 80 02 00 00        
     2 : mov     rbp, rsp                          ; 48 89 e5                       
     3 : add     rbp, 0x0280                       ; 48 81 c5 80 02 00 00           
     4 : mov     rdi, 0x055afb1b3d6ea              ; 48 bf ea d6 b3 b1 af 55 00 00  
     5 : mov     qword ptr [rsp], rax              ; 48 89 84 24 00 00 00 00        
     6 : mov     qword ptr [rsp + 0x008], rcx      ; 48 89 8c 24 08 00 00 00        
     7 : mov     qword ptr [rsp + 0x010], rdx      ; 48 89 94 24 10 00 00 00        
     8 : mov     qword ptr [rsp + 0x018], rsi      ; 48 89 b4 24 18 00 00 00        
     9 : mov     qword ptr [rsp + 0x020], rdi      ; 48 89 bc 24 20 00 00 00        
    10 : mov     qword ptr [rsp + 0x028], r8       ; 4c 89 84 24 28 00 00 00        
    11 : mov     qword ptr [rsp + 0x030], r9       ; 4c 89 8c 24 30 00 00 00        
    12 : mov     qword ptr [rsp + 0x038], r10      ; 4c 89 94 24 38 00 00 00        
    13 : mov     qword ptr [rsp + 0x040], r11      ; 4c 89 9c 24 40 00 00 00        
    14 : vmovdqu ymmword ptr [rsp + 0x060], ymm0   ; c5 fe 7f 84 24 60 00 00 00     
    15 : vmovdqu ymmword ptr [rsp + 0x080], ymm1   ; c5 fe 7f 8c 24 80 00 00 00     
    16 : vmovdqu ymmword ptr [rsp + 0x0a0], ymm2   ; c5 fe 7f 94 24 a0 00 00 00     
    17 : vmovdqu ymmword ptr [rsp + 0x0c0], ymm3   ; c5 fe 7f 9c 24 c0 00 00 00     
    18 : vmovdqu ymmword ptr [rsp + 0x0e0], ymm4   ; c5 fe 7f a4 24 e0 00 00 00     
    19 : vmovdqu ymmword ptr [rsp + 0x0100], ymm5  ; c5 fe 7f ac 24 00 01 00 00     
    20 : vmovdqu ymmword ptr [rsp + 0x0120], ymm6  ; c5 fe 7f b4 24 20 01 00 00     
    21 : vmovdqu ymmword ptr [rsp + 0x0140], ymm7  ; c5 fe 7f bc 24 40 01 00 00     
    22 : vmovdqu ymmword ptr [rsp + 0x0160], ymm8  ; c5 7e 7f 84 24 60 01 00 00     
    23 : vmovdqu ymmword ptr [rsp + 0x0180], ymm9  ; c5 7e 7f 8c 24 80 01 00 00     
    24 : vmovdqu ymmword ptr [rsp + 0x01a0], ymm10 ; c5 7e 7f 94 24 a0 01 00 00     
    25 : vmovdqu ymmword ptr [rsp + 0x01c0], ymm11 ; c5 7e 7f 9c 24 c0 01 00 00     
    26 : vmovdqu ymmword ptr [rsp + 0x01e0], ymm12 ; c5 7e 7f a4 24 e0 01 00 00     
    27 : vmovdqu ymmword ptr [rsp + 0x0200], ymm13 ; c5 7e 7f ac 24 00 02 00 00     
    28 : vmovdqu ymmword ptr [rsp + 0x0220], ymm14 ; c5 7e 7f b4 24 20 02 00 00     
    29 : vmovdqu ymmword ptr [rsp + 0x0240], ymm15 ; c5 7e 7f bc 24 40 02 00 00     
    30 : call    rdi                               ; ff d7                          
    31 : mov     rax, qword ptr [rsp]              ; 48 8b 84 24 00 00 00 00        
    32 : mov     rcx, qword ptr [rsp + 0x008]      ; 48 8b 8c 24 08 00 00 00        
    33 : mov     rdx, qword ptr [rsp + 0x010]      ; 48 8b 94 24 10 00 00 00        
    34 : mov     rsi, qword ptr [rsp + 0x018]      ; 48 8b b4 24 18 00 00 00        
    35 : mov     rdi, qword ptr [rsp + 0x020]      ; 48 8b bc 24 20 00 00 00        
    36 : mov     r8, qword ptr [rsp + 0x028]       ; 4c 8b 84 24 28 00 00 00        
    37 : mov     r9, qword ptr [rsp + 0x030]       ; 4c 8b 8c 24 30 00 00 00        
    38 : mov     r10, qword ptr [rsp + 0x038]      ; 4c 8b 94 24 38 00 00 00        
    39 : mov     r11, qword ptr [rsp + 0x040]      ; 4c 8b 9c 24 40 00 00 00        
    40 : vmovdqu ymm0, ymmword ptr [rsp + 0x060]   ; c5 fe 6f 84 24 60 00 00 00     
    41 : vmovdqu ymm1, ymmword ptr [rsp + 0x080]   ; c5 fe 6f 8c 24 80 00 00 00     
    42 : vmovdqu ymm2, ymmword ptr [rsp + 0x0a0]   ; c5 fe 6f 94 24 a0 00 00 00     
    43 : vmovdqu ymm3, ymmword ptr [rsp + 0x0c0]   ; c5 fe 6f 9c 24 c0 00 00 00     
    44 : vmovdqu ymm4, ymmword ptr [rsp + 0x0e0]   ; c5 fe 6f a4 24 e0 00 00 00     
    45 : vmovdqu ymm5, ymmword ptr [rsp + 0x0100]  ; c5 fe 6f ac 24 00 01 00 00     
    46 : vmovdqu ymm6, ymmword ptr [rsp + 0x0120]  ; c5 fe 6f b4 24 20 01 00 00     
    47 : vmovdqu ymm7, ymmword ptr [rsp + 0x0140]  ; c5 fe 6f bc 24 40 01 00 00     
    48 : vmovdqu ymm8, ymmword ptr [rsp + 0x0160]  ; c5 7e 6f 84 24 60 01 00 00     
    49 : vmovdqu ymm9, ymmword ptr [rsp + 0x0180]  ; c5 7e 6f 8c 24 80 01 00 00     
    50 : vmovdqu ymm10, ymmword ptr [rsp + 0x01a0] ; c5 7e 6f 94 24 a0 01 00 00     
    51 : vmovdqu ymm11, ymmword ptr [rsp + 0x01c0] ; c5 7e 6f 9c 24 c0 01 00 00     
    52 : vmovdqu ymm12, ymmword ptr [rsp + 0x01e0] ; c5 7e 6f a4 24 e0 01 00 00     
    53 : vmovdqu ymm13, ymmword ptr [rsp + 0x0200] ; c5 7e 6f ac 24 00 02 00 00     
    54 : vmovdqu ymm14, ymmword ptr [rsp + 0x0220] ; c5 7e 6f b4 24 20 02 00 00     
    55 : vmovdqu ymm15, ymmword ptr [rsp + 0x0240] ; c5 7e 6f bc 24 40 02 00 00     
    56 : mov     rbp, qword ptr [rsp + 0x0280]     ; 48 8b ac 24 80 02 00 00        
    57 : add     rsp, 0x0288                       ; 48 81 c4 88 02 00 00           
    58 : ret                                       ; c3                             
