has_in_join_cascade(i0, i1, i2)
     0 : sub    rsp, 0x078                     ; 48 81 ec 78 00 00 00                 
     1 : mov    qword ptr [rsp + 0x068], r13   ; 4c 89 ac 24 68 00 00 00              
     2 : mov    qword ptr [rsp + 0x070], r14   ; 4c 89 b4 24 70 00 00 00              
     3 : mov    qword ptr [rsp + 0x030], rdi   ; 48 89 bc 24 30 00 00 00              
     4 : mov    qword ptr [rsp + 0x028], rsi   ; 48 89 b4 24 28 00 00 00              
     5 : mov    qword ptr [rsp + 0x020], rdx   ; 48 89 94 24 20 00 00 00              
     6 : mov    qword ptr [rsp], 0             ; 48 c7 84 24 00 00 00 00 00 00 00 00  
     7 : mov    r13, qword ptr [rsp + 0x030]   ; 4c 8b ac 24 30 00 00 00              
     8 : mov    r14, qword ptr [r13 + 0x010]   ; 4d 8b b5 10 00 00 00                 
     9 : mov    qword ptr [rsp + 0x018], r14   ; 4c 89 b4 24 18 00 00 00              
    10 : mov    r13, qword ptr [rsp + 0x030]   ; 4c 8b ac 24 30 00 00 00              
    11 : mov    r14, qword ptr [r13 + 0]       ; 4d 8b b5 00 00 00 00                 
    12 : mov    qword ptr [rsp + 0x010], r14   ; 4c 89 b4 24 10 00 00 00              
    13 : mov    r13, qword ptr [rsp + 0x030]   ; 4c 8b ac 24 30 00 00 00              
    14 : mov    r14, qword ptr [r13 + 0x008]   ; 4d 8b b5 08 00 00 00                 
    15 : mov    qword ptr [rsp + 0x008], r14   ; 4c 89 b4 24 08 00 00 00              
    16 :        __loops_label_0:               ;                                      
    17 : cmp    qword ptr [rsp + 0x018], 0     ; 48 81 bc 24 18 00 00 00 00 00 00 00  
    18 : jle    __loops_label_2                ; 0f 8e c5 01 00 00                    
    19 : mov    r13, qword ptr [rsp + 0x010]   ; 4c 8b ac 24 10 00 00 00              
    20 : movsxd r14, dword ptr [r13]           ; 4d 63 75 00                          
    21 : mov    qword ptr [rsp + 0x058], r14   ; 4c 89 b4 24 58 00 00 00              
    22 : add    qword ptr [rsp + 0x010], 0x004 ; 48 81 84 24 10 00 00 00 04 00 00 00  
    23 : mov    r13, qword ptr [rsp + 0x008]   ; 4c 8b ac 24 08 00 00 00              
    24 : movsxd r14, dword ptr [r13]           ; 4d 63 75 00                          
    25 : mov    qword ptr [rsp + 0x050], r14   ; 4c 89 b4 24 50 00 00 00              
    26 : add    qword ptr [rsp + 0x008], 0x004 ; 48 81 84 24 08 00 00 00 04 00 00 00  
    27 : sub    qword ptr [rsp + 0x018], 0x001 ; 48 81 ac 24 18 00 00 00 01 00 00 00  
    28 : mov    r13, qword ptr [rsp + 0x030]   ; 4c 8b ac 24 30 00 00 00              
    29 : mov    r14, qword ptr [r13 + 0x028]   ; 4d 8b b5 28 00 00 00                 
    30 : mov    qword ptr [rsp + 0x048], r14   ; 4c 89 b4 24 48 00 00 00              
    31 : mov    r13, qword ptr [rsp + 0x030]   ; 4c 8b ac 24 30 00 00 00              
    32 : mov    r14, qword ptr [r13 + 0x018]   ; 4d 8b b5 18 00 00 00                 
    33 : mov    qword ptr [rsp + 0x040], r14   ; 4c 89 b4 24 40 00 00 00              
    34 : mov    r13, qword ptr [rsp + 0x030]   ; 4c 8b ac 24 30 00 00 00              
    35 : mov    r14, qword ptr [r13 + 0x020]   ; 4d 8b b5 20 00 00 00                 
    36 : mov    qword ptr [rsp + 0x038], r14   ; 4c 89 b4 24 38 00 00 00              
    37 :        __loops_label_3:               ;                                      
    38 : cmp    qword ptr [rsp + 0x048], 0     ; 48 81 bc 24 48 00 00 00 00 00 00 00  
    39 : jle    __loops_label_5                ; 0f 8e 1d 01 00 00                    
    40 : mov    r13, qword ptr [rsp + 0x040]   ; 4c 8b ac 24 40 00 00 00              
    41 : movsxd rdi, dword ptr [r13]           ; 49 63 7d 00                          
    42 : add    qword ptr [rsp + 0x040], 0x004 ; 48 81 84 24 40 00 00 00 04 00 00 00  
    43 : mov    r13, qword ptr [rsp + 0x038]   ; 4c 8b ac 24 38 00 00 00              
    44 : movsxd rsi, dword ptr [r13]           ; 49 63 75 00                          
    45 : add    qword ptr [rsp + 0x038], 0x004 ; 48 81 84 24 38 00 00 00 04 00 00 00  
    46 : sub    qword ptr [rsp + 0x048], 0x001 ; 48 81 ac 24 48 00 00 00 01 00 00 00  
    47 : cmp    rsi, qword ptr [rsp + 0x058]   ; 48 3b b4 24 58 00 00 00              
    48 : jle    __loops_label_7                ; 0f 8e 05 00 00 00                    
    49 : jmp    __loops_label_3                ; e9 9f ff ff ff                       
    50 :        __loops_label_7:               ;                                      
    51 : cmp    rsi, qword ptr [rsp + 0x058]   ; 48 3b b4 24 58 00 00 00              
    52 : jne    __loops_label_10               ; 0f 85 bb 00 00 00                    
    53 : mov    r13, qword ptr [rsp + 0x030]   ; 4c 8b ac 24 30 00 00 00              
    54 : mov    rsi, qword ptr [r13 + 0x040]   ; 49 8b b5 40 00 00 00                 
    55 : mov    r13, qword ptr [rsp + 0x030]   ; 4c 8b ac 24 30 00 00 00              
    56 : mov    rdx, qword ptr [r13 + 0x030]   ; 49 8b 95 30 00 00 00                 
    57 : mov    r13, qword ptr [rsp + 0x030]   ; 4c 8b ac 24 30 00 00 00              
    58 : mov    r14, qword ptr [r13 + 0x038]   ; 4d 8b b5 38 00 00 00                 
    59 : mov    qword ptr [rsp + 0x060], r14   ; 4c 89 b4 24 60 00 00 00              
    60 :        __loops_label_11:              ;                                      
    61 : cmp    rsi, 0                         ; 48 83 fe 00                          
    62 : jle    __loops_label_10               ; 0f 8e 7c 00 00 00                    
    63 : movsxd rcx, dword ptr [rdx]           ; 48 63 0a                             
    64 : add    rdx, 0x004                     ; 48 81 c2 04 00 00 00                 
    65 : mov    r13, qword ptr [rsp + 0x060]   ; 4c 8b ac 24 60 00 00 00              
    66 : movsxd rax, dword ptr [r13]           ; 49 63 45 00                          
    67 : add    qword ptr [rsp + 0x060], 0x004 ; 48 81 84 24 60 00 00 00 04 00 00 00  
    68 : sub    rsi, 0x001                     ; 48 81 ee 01 00 00 00                 
    69 : cmp    rcx, qword ptr [rsp + 0x050]   ; 48 3b 8c 24 50 00 00 00              
    70 : jle    __loops_label_15               ; 0f 8e 05 00 00 00                    
    71 : jmp    __loops_label_11               ; e9 ba ff ff ff                       
    72 :        __loops_label_15:              ;                                      
    73 : cmp    rcx, qword ptr [rsp + 0x050]   ; 48 3b 8c 24 50 00 00 00              
    74 : jne    __loops_label_18               ; 0f 85 2d 00 00 00                    
    75 : cmp    rdi, qword ptr [rsp + 0x028]   ; 48 3b bc 24 28 00 00 00              
    76 : jne    __loops_label_18               ; 0f 85 1f 00 00 00                    
    77 : cmp    rax, qword ptr [rsp + 0x020]   ; 48 3b 84 24 20 00 00 00              
    78 : jne    __loops_label_18               ; 0f 85 11 00 00 00                    
    79 : mov    qword ptr [rsp], 0x001         ; 48 c7 84 24 00 00 00 00 01 00 00 00  
    80 : jmp    __loops_label_2                ; e9 0f 00 00 00                       
    81 :        __loops_label_16:              ;                                      
    82 :        __loops_label_18:              ;                                      
    83 : jmp    __loops_label_11               ; e9 7a ff ff ff                       
    84 :        __loops_label_13:              ;                                      
    85 :        __loops_label_8:               ;                                      
    86 :        __loops_label_10:              ;                                      
    87 : jmp    __loops_label_3                ; e9 d1 fe ff ff                       
    88 :        __loops_label_5:               ;                                      
    89 : jmp    __loops_label_0                ; e9 29 fe ff ff                       
    90 :        __loops_label_2:               ;                                      
    91 : mov    rax, qword ptr [rsp]           ; 48 8b 84 24 00 00 00 00              
    92 : mov    r13, qword ptr [rsp + 0x068]   ; 4c 8b ac 24 68 00 00 00              
    93 : mov    r14, qword ptr [rsp + 0x070]   ; 4c 8b b4 24 70 00 00 00              
    94 : add    rsp, 0x078                     ; 48 81 c4 78 00 00 00                 
    95 : ret                                   ; c3                                   
