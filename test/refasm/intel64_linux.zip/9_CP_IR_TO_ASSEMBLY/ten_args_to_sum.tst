ten_args_to_sum(i0, i1, i2, i3, i4, i5, i6, i7, i8, i9)
     0 : sub  rsp, 0x008                   ; 48 81 ec 08 00 00 00     
     1 : mov  qword ptr [rsp], r13         ; 4c 89 ac 24 00 00 00 00  
     2 : mov  rax, qword ptr [rsp + 0x010] ; 48 8b 84 24 10 00 00 00  
     3 : imul rdi, 0x001                   ; 48 6b ff 01              
     4 : imul rsi, 0x002                   ; 48 6b f6 02              
     5 : add  rdi, rsi                     ; 48 01 f7                 
     6 : imul rdx, 0x003                   ; 48 6b d2 03              
     7 : add  rdi, rdx                     ; 48 01 d7                 
     8 : imul rcx, 0x004                   ; 48 6b c9 04              
     9 : add  rdi, rcx                     ; 48 01 cf                 
    10 : imul r8, 0x005                    ; 4d 6b c0 05              
    11 : add  rdi, r8                      ; 4c 01 c7                 
    12 : imul r9, 0x006                    ; 4d 6b c9 06              
    13 : add  rdi, r9                      ; 4c 01 cf                 
    14 : imul rax, 0x007                   ; 48 6b c0 07              
    15 : add  rdi, rax                     ; 48 01 c7                 
    16 : mov  r13, qword ptr [rsp + 0x018] ; 4c 8b ac 24 18 00 00 00  
    17 : mov  rsi, r13                     ; 4c 89 ee                 
    18 : imul rsi, 0x008                   ; 48 6b f6 08              
    19 : add  rdi, rsi                     ; 48 01 f7                 
    20 : mov  r13, qword ptr [rsp + 0x020] ; 4c 8b ac 24 20 00 00 00  
    21 : mov  rsi, r13                     ; 4c 89 ee                 
    22 : imul rsi, 0x003                   ; 48 6b f6 03              
    23 : add  rdi, rsi                     ; 48 01 f7                 
    24 : mov  r13, qword ptr [rsp + 0x028] ; 4c 8b ac 24 28 00 00 00  
    25 : mov  rsi, r13                     ; 4c 89 ee                 
    26 : imul rsi, 0x002                   ; 48 6b f6 02              
    27 : add  rdi, rsi                     ; 48 01 f7                 
    28 : mov  rax, rdi                     ; 48 89 f8                 
    29 : mov  r13, qword ptr [rsp]         ; 4c 8b ac 24 00 00 00 00  
    30 : add  rsp, 0x008                   ; 48 81 c4 08 00 00 00     
    31 : ret                               ; c3                       
