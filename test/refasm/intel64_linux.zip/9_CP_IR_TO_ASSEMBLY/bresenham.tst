bresenham(i0, i1, i2, i3, i4, i5, i6)
     0 : sub   rsp, 0x058                   ; 48 81 ec 58 00 00 00        
     1 : mov   qword ptr [rsp + 0x048], r13 ; 4c 89 ac 24 48 00 00 00     
     2 : mov   qword ptr [rsp + 0x050], r14 ; 4c 89 b4 24 50 00 00 00     
     3 : mov   rax, r8                      ; 4c 89 c0                    
     4 : sub   rax, rdx                     ; 48 29 d0                    
     5 : mov   r13, rax                     ; 49 89 c5                    
     6 : neg   r13                          ; 49 f7 dd                    
     7 : cmovs r13, rax                     ; 4c 0f 48 e8                 
     8 : mov   qword ptr [rsp + 0x020], r13 ; 4c 89 ac 24 20 00 00 00     
     9 : mov   rax, r8                      ; 4c 89 c0                    
    10 : sub   rax, rdx                     ; 48 29 d0                    
    11 : mov   qword ptr [rsp], rcx         ; 48 89 8c 24 00 00 00 00     
    12 : mov   r13, rax                     ; 49 89 c5                    
    13 : mov   rcx, r13                     ; 4c 89 e9                    
    14 : sar   r13, 0x03f                   ; 49 c1 fd 3f                 
    15 : neg   rcx                          ; 48 f7 d9                    
    16 : adc   r13, r13                     ; 4d 11 ed                    
    17 : mov   rcx, qword ptr [rsp]         ; 48 8b 8c 24 00 00 00 00     
    18 : mov   qword ptr [rsp + 0x028], r13 ; 4c 89 ac 24 28 00 00 00     
    19 : mov   rax, r9                      ; 4c 89 c8                    
    20 : sub   rax, rcx                     ; 48 29 c8                    
    21 : mov   qword ptr [rsp], rax         ; 48 89 84 24 00 00 00 00     
    22 : neg   rax                          ; 48 f7 d8                    
    23 : cmovs rax, qword ptr [rsp]         ; 48 0f 48 84 24 00 00 00 00  
    24 : mov   qword ptr [rsp + 0x030], rax ; 48 89 84 24 30 00 00 00     
    25 : neg   qword ptr [rsp + 0x030]      ; 48 f7 9c 24 30 00 00 00     
    26 : mov   rax, r9                      ; 4c 89 c8                    
    27 : sub   rax, rcx                     ; 48 29 c8                    
    28 : mov   qword ptr [rsp], rcx         ; 48 89 8c 24 00 00 00 00     
    29 : mov   r13, rax                     ; 49 89 c5                    
    30 : mov   rcx, r13                     ; 4c 89 e9                    
    31 : sar   r13, 0x03f                   ; 49 c1 fd 3f                 
    32 : neg   rcx                          ; 48 f7 d9                    
    33 : adc   r13, r13                     ; 4d 11 ed                    
    34 : mov   rcx, qword ptr [rsp]         ; 48 8b 8c 24 00 00 00 00     
    35 : mov   qword ptr [rsp + 0x040], r13 ; 4c 89 ac 24 40 00 00 00     
    36 : mov   r13, qword ptr [rsp + 0x020] ; 4c 8b ac 24 20 00 00 00     
    37 : mov   r14, qword ptr [rsp + 0x030] ; 4c 8b b4 24 30 00 00 00     
    38 : mov   qword ptr [rsp + 0x038], r13 ; 4c 89 ac 24 38 00 00 00     
    39 : add   qword ptr [rsp + 0x038], r14 ; 4c 01 b4 24 38 00 00 00     
    40 :       __loops_label_0:             ;                             
    41 : cmp   rdi, 0                       ; 48 83 ff 00                 
    42 : je    __loops_label_2              ; 0f 84 a9 00 00 00           
    43 : mov   rax, rcx                     ; 48 89 c8                    
    44 : imul  rax, rsi                     ; 48 0f af c6                 
    45 : add   rax, rdx                     ; 48 01 d0                    
    46 : mov   r13, qword ptr [rsp + 0x060] ; 4c 8b ac 24 60 00 00 00     
    47 : mov   byte ptr [rdi + rax], r13b   ; 44 88 2c 07                 
    48 : cmp   rdx, r8                      ; 4c 39 c2                    
    49 : jne   __loops_label_4              ; 0f 85 0e 00 00 00           
    50 : cmp   rcx, r9                      ; 4c 39 c9                    
    51 : jne   __loops_label_4              ; 0f 85 05 00 00 00           
    52 : jmp   __loops_label_2              ; e9 7c 00 00 00              
    53 :       __loops_label_4:             ;                             
    54 : mov   r13, qword ptr [rsp + 0x038] ; 4c 8b ac 24 38 00 00 00     
    55 : mov   rax, r13                     ; 4c 89 e8                    
    56 : shl   rax, 0x001                   ; 48 c1 e0 01                 
    57 : cmp   rax, qword ptr [rsp + 0x030] ; 48 3b 84 24 30 00 00 00     
    58 : jl    __loops_label_6              ; 0f 8c 26 00 00 00           
    59 : cmp   rdx, r8                      ; 4c 39 c2                    
    60 : jne   __loops_label_8              ; 0f 85 05 00 00 00           
    61 : jmp   __loops_label_2              ; e9 51 00 00 00              
    62 :       __loops_label_8:             ;                             
    63 : mov   r13, qword ptr [rsp + 0x030] ; 4c 8b ac 24 30 00 00 00     
    64 : add   qword ptr [rsp + 0x038], r13 ; 4c 01 ac 24 38 00 00 00     
    65 : add   rdx, qword ptr [rsp + 0x028] ; 48 03 94 24 28 00 00 00     
    66 :       __loops_label_6:             ;                             
    67 : cmp   rax, qword ptr [rsp + 0x020] ; 48 3b 84 24 20 00 00 00     
    68 : jg    __loops_label_10             ; 0f 8f 26 00 00 00           
    69 : cmp   rcx, r9                      ; 4c 39 c9                    
    70 : jne   __loops_label_12             ; 0f 85 05 00 00 00           
    71 : jmp   __loops_label_2              ; e9 1d 00 00 00              
    72 :       __loops_label_12:            ;                             
    73 : mov   r13, qword ptr [rsp + 0x020] ; 4c 8b ac 24 20 00 00 00     
    74 : add   qword ptr [rsp + 0x038], r13 ; 4c 01 ac 24 38 00 00 00     
    75 : add   rcx, qword ptr [rsp + 0x040] ; 48 03 8c 24 40 00 00 00     
    76 :       __loops_label_10:            ;                             
    77 : jmp   __loops_label_0              ; e9 4d ff ff ff              
    78 :       __loops_label_2:             ;                             
    79 : mov   r13, qword ptr [rsp + 0x048] ; 4c 8b ac 24 48 00 00 00     
    80 : mov   r14, qword ptr [rsp + 0x050] ; 4c 8b b4 24 50 00 00 00     
    81 : add   rsp, 0x058                   ; 48 81 c4 58 00 00 00        
    82 : ret                                ; c3                          
