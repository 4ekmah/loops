fixed_power_v_float_4(i0, i1, i2)
     0 : xor     rcx, rcx                      ; 48 31 c9              
     1 : imul    rdx, 0x004                    ; 48 6b d2 04           
     2 :         __loops_label_0:              ;                       
     3 : cmp     rcx, rdx                      ; 48 39 d1              
     4 : jge     __loops_label_2               ; 0f 8d 1e 00 00 00     
     5 : vmovups ymm0, ymmword ptr [rdi + rcx] ; c5 fc 10 04 0f        
     6 : vmulps  ymm0, ymm0, ymm0              ; c5 fc 59 c0           
     7 : vmulps  ymm0, ymm0, ymm0              ; c5 fc 59 c0           
     8 : vmovups ymmword ptr [rsi + rcx], ymm0 ; c5 fc 11 04 0e        
     9 : add     rcx, 0x020                    ; 48 81 c1 20 00 00 00  
    10 : jmp     __loops_label_0               ; e9 d9 ff ff ff        
    11 :         __loops_label_2:              ;                       
    12 : xor     rax, rax                      ; 48 31 c0              
    13 : ret                                   ; c3                    
