fixed_power_v_uint32_t_9(i0, i1, i2)
     0 : xor     rcx, rcx                      ; 48 31 c9              
     1 : imul    rdx, 0x004                    ; 48 6b d2 04           
     2 :         __loops_label_0:              ;                       
     3 : cmp     rcx, rdx                      ; 48 39 d1              
     4 : jge     __loops_label_2               ; 0f 8d 2a 00 00 00     
     5 : vmovdqu ymm0, ymmword ptr [rdi + rcx] ; c5 fe 6f 04 0f        
     6 : vpmulld ymm1, ymm0, ymm0              ; c4 e2 7d 40 c8        
     7 : vpmulld ymm1, ymm1, ymm1              ; c4 e2 75 40 c9        
     8 : vpmulld ymm1, ymm1, ymm1              ; c4 e2 75 40 c9        
     9 : vpmulld ymm0, ymm0, ymm1              ; c4 e2 7d 40 c1        
    10 : vmovdqu ymmword ptr [rsi + rcx], ymm0 ; c5 fe 7f 04 0e        
    11 : add     rcx, 0x020                    ; 48 81 c1 20 00 00 00  
    12 : jmp     __loops_label_0               ; e9 cd ff ff ff        
    13 :         __loops_label_2:              ;                       
    14 : xor     rax, rax                      ; 48 31 c0              
    15 : ret                                   ; c3                    
