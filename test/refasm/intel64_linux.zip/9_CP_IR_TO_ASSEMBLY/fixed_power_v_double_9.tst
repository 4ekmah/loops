fixed_power_v_double_9(i0, i1, i2)
     0 : xor     rcx, rcx                      ; 48 31 c9              
     1 : imul    rdx, 0x008                    ; 48 6b d2 08           
     2 :         __loops_label_0:              ;                       
     3 : cmp     rcx, rdx                      ; 48 39 d1              
     4 : jge     __loops_label_2               ; 0f 8d 26 00 00 00     
     5 : vmovupd ymm0, ymmword ptr [rdi + rcx] ; c5 fd 10 04 0f        
     6 : vmulpd  ymm1, ymm0, ymm0              ; c5 fd 59 c8           
     7 : vmulpd  ymm1, ymm1, ymm1              ; c5 f5 59 c9           
     8 : vmulpd  ymm1, ymm1, ymm1              ; c5 f5 59 c9           
     9 : vmulpd  ymm0, ymm0, ymm1              ; c5 fd 59 c1           
    10 : vmovupd ymmword ptr [rsi + rcx], ymm0 ; c5 fd 11 04 0e        
    11 : add     rcx, 0x020                    ; 48 81 c1 20 00 00 00  
    12 : jmp     __loops_label_0               ; e9 d1 ff ff ff        
    13 :         __loops_label_2:              ;                       
    14 : xor     rax, rax                      ; 48 31 c0              
    15 : ret                                   ; c3                    
