conditionpainter(i0)
     0 : sub    rsp, 0x038                                   ; 48 81 ec 38 00 00 00                 
     1 : mov    qword ptr [rsp + 0x008], rdi                 ; 48 89 bc 24 08 00 00 00              
     2 : mov    qword ptr [rsp + 0x028], r13                 ; 4c 89 ac 24 28 00 00 00              
     3 : mov    r13, 0x0fffffffffffffffb                     ; 49 c7 c5 fb ff ff ff                 
     4 : mov    qword ptr [rsp], r13                         ; 4c 89 ac 24 00 00 00 00              
     5 :        __loops_label_0:                             ;                                      
     6 : cmp    qword ptr [rsp], 0x005                       ; 48 81 bc 24 00 00 00 00 05 00 00 00  
     7 : jg     __loops_label_2                              ; 0f 8f f3 02 00 00                    
     8 : mov    r13, qword ptr [rsp]                         ; 4c 8b ac 24 00 00 00 00              
     9 : mov    rdx, r13                                     ; 4c 89 ea                             
    10 : add    rdx, 0x005                                   ; 48 81 c2 05 00 00 00                 
    11 : imul   rdx, 0x00b                                   ; 48 6b d2 0b                          
    12 : mov    r13, rdx                                     ; 49 89 d5                             
    13 : imul   r13, 0x008                                   ; 4d 6b ed 08                          
    14 : mov    qword ptr [rsp + 0x018], r13                 ; 4c 89 ac 24 18 00 00 00              
    15 : mov    r13, 0x0fffffffffffffffb                     ; 49 c7 c5 fb ff ff ff                 
    16 : mov    qword ptr [rsp + 0x010], r13                 ; 4c 89 ac 24 10 00 00 00              
    17 :        __loops_label_3:                             ;                                      
    18 : cmp    qword ptr [rsp + 0x010], 0x005               ; 48 81 bc 24 10 00 00 00 05 00 00 00  
    19 : jg     __loops_label_5                              ; 0f 8f 9c 02 00 00                    
    20 : mov    r13, qword ptr [rsp + 0x010]                 ; 4c 8b ac 24 10 00 00 00              
    21 : mov    rax, r13                                     ; 4c 89 e8                             
    22 : add    rax, 0x003                                   ; 48 05 03 00 00 00                    
    23 : xor    rsi, rsi                                     ; 48 31 f6                             
    24 : cmp    qword ptr [rsp], rax                         ; 48 39 84 24 00 00 00 00              
    25 : setge  sil                                          ; 40 0f 9d c6                          
    26 : xor    rax, rax                                     ; 48 31 c0                             
    27 : cmp    qword ptr [rsp], 0x004                       ; 48 81 bc 24 00 00 00 00 04 00 00 00  
    28 : setle  al                                           ; 0f 9e c0                             
    29 : and    rsi, rax                                     ; 48 21 c6                             
    30 : xor    rax, rax                                     ; 48 31 c0                             
    31 : cmp    qword ptr [rsp + 0x010], 0x0fffffffffffffffe ; 48 81 bc 24 10 00 00 00 fe ff ff ff  
    32 : setge  al                                           ; 0f 9d c0                             
    33 : and    rsi, rax                                     ; 48 21 c6                             
    34 : xor    rax, rax                                     ; 48 31 c0                             
    35 : cmp    qword ptr [rsp + 0x010], 0                   ; 48 81 bc 24 10 00 00 00 00 00 00 00  
    36 : setle  al                                           ; 0f 9e c0                             
    37 : and    rsi, rax                                     ; 48 21 c6                             
    38 : mov    r13, qword ptr [rsp + 0x010]                 ; 4c 8b ac 24 10 00 00 00              
    39 : mov    rax, r13                                     ; 4c 89 e8                             
    40 : sub    rax, 0x001                                   ; 48 2d 01 00 00 00                    
    41 : xor    rdi, rdi                                     ; 48 31 ff                             
    42 : cmp    qword ptr [rsp], rax                         ; 48 39 84 24 00 00 00 00              
    43 : setle  dil                                          ; 40 0f 9e c7                          
    44 : xor    rax, rax                                     ; 48 31 c0                             
    45 : cmp    qword ptr [rsp + 0x010], 0                   ; 48 81 bc 24 10 00 00 00 00 00 00 00  
    46 : setge  al                                           ; 0f 9d c0                             
    47 : and    rdi, rax                                     ; 48 21 c7                             
    48 : xor    rax, rax                                     ; 48 31 c0                             
    49 : cmp    qword ptr [rsp], 0                           ; 48 81 bc 24 00 00 00 00 00 00 00 00  
    50 : setle  al                                           ; 0f 9e c0                             
    51 : and    rdi, rax                                     ; 48 21 c7                             
    52 : mov    r13, qword ptr [rsp + 0x010]                 ; 4c 8b ac 24 10 00 00 00              
    53 : mov    rax, r13                                     ; 4c 89 e8                             
    54 : imul   rax, qword ptr [rsp + 0x010]                 ; 48 0f af 84 24 10 00 00 00           
    55 : mov    r13, qword ptr [rsp]                         ; 4c 8b ac 24 00 00 00 00              
    56 : mov    rcx, r13                                     ; 4c 89 e9                             
    57 : imul   rcx, qword ptr [rsp]                         ; 48 0f af 8c 24 00 00 00 00           
    58 : add    rax, rcx                                     ; 48 01 c8                             
    59 : xor    rcx, rcx                                     ; 48 31 c9                             
    60 : cmp    rax, 0x009                                   ; 48 83 f8 09                          
    61 : setle  cl                                           ; 0f 9e c1                             
    62 : and    rdi, rcx                                     ; 48 21 cf                             
    63 : mov    qword ptr [rsp + 0x020], rsi                 ; 48 89 b4 24 20 00 00 00              
    64 : or     qword ptr [rsp + 0x020], rdi                 ; 48 09 bc 24 20 00 00 00              
    65 : mov    rdi, 0x002                                   ; 48 c7 c7 02 00 00 00                 
    66 : xor    rcx, rcx                                     ; 48 31 c9                             
    67 : xor    rax, rax                                     ; 48 31 c0                             
    68 : cmp    qword ptr [rsp + 0x010], 0x002               ; 48 81 bc 24 10 00 00 00 02 00 00 00  
    69 : setge  al                                           ; 0f 9d c0                             
    70 : xor    rdx, rdx                                     ; 48 31 d2                             
    71 : cmp    qword ptr [rsp + 0x010], 0x004               ; 48 81 bc 24 10 00 00 00 04 00 00 00  
    72 : setle  dl                                           ; 0f 9e c2                             
    73 : and    rax, rdx                                     ; 48 21 d0                             
    74 : xor    rdx, rdx                                     ; 48 31 d2                             
    75 : cmp    qword ptr [rsp], 0x001                       ; 48 81 bc 24 00 00 00 00 01 00 00 00  
    76 : setge  dl                                           ; 0f 9d c2                             
    77 : xor    rsi, rsi                                     ; 48 31 f6                             
    78 : cmp    qword ptr [rsp], 0x003                       ; 48 81 bc 24 00 00 00 00 03 00 00 00  
    79 : setle  sil                                          ; 40 0f 9e c6                          
    80 : and    rdx, rsi                                     ; 48 21 f2                             
    81 : or     rax, rdx                                     ; 48 09 d0                             
    82 : mov    r13, qword ptr [rsp + 0x010]                 ; 4c 8b ac 24 10 00 00 00              
    83 : mov    rsi, r13                                     ; 4c 89 ee                             
    84 : imul   rsi, qword ptr [rsp + 0x010]                 ; 48 0f af b4 24 10 00 00 00           
    85 : mov    r13, qword ptr [rsp]                         ; 4c 8b ac 24 00 00 00 00              
    86 : mov    rdx, r13                                     ; 4c 89 ea                             
    87 : imul   rdx, qword ptr [rsp]                         ; 48 0f af 94 24 00 00 00 00           
    88 : add    rsi, rdx                                     ; 48 01 d6                             
    89 : xor    rdx, rdx                                     ; 48 31 d2                             
    90 : cmp    rsi, 0x010                                   ; 48 83 fe 10                          
    91 : setle  dl                                           ; 0f 9e c2                             
    92 : and    rax, rdx                                     ; 48 21 d0                             
    93 : cmp    rax, 0                                       ; 48 83 f8 00                          
    94 : cmovne rcx, rdi                                     ; 48 0f 45 cf                          
    95 : mov    r13, qword ptr [rsp + 0x020]                 ; 4c 8b ac 24 20 00 00 00              
    96 : add    rcx, r13                                     ; 4c 01 e9                             
    97 : mov    r13, qword ptr [rsp]                         ; 4c 8b ac 24 00 00 00 00              
    98 : mov    rdi, r13                                     ; 4c 89 ef                             
    99 : imul   rdi, 0x002                                   ; 48 6b ff 02                          
   100 : cmp    rdi, qword ptr [rsp + 0x010]                 ; 48 3b bc 24 10 00 00 00              
   101 : jl     __loops_label_8                              ; 0f 8c 39 00 00 00                    
   102 : mov    r13, qword ptr [rsp + 0x010]                 ; 4c 8b ac 24 10 00 00 00              
   103 : mov    rdi, r13                                     ; 4c 89 ef                             
   104 : add    rdi, 0x003                                   ; 48 81 c7 03 00 00 00                 
   105 : neg    rdi                                          ; 48 f7 df                             
   106 : mov    r13, qword ptr [rsp + 0x010]                 ; 4c 8b ac 24 10 00 00 00              
   107 : mov    rsi, r13                                     ; 4c 89 ee                             
   108 : add    rsi, 0x003                                   ; 48 81 c6 03 00 00 00                 
   109 : imul   rdi, rsi                                     ; 48 0f af fe                          
   110 : cmp    qword ptr [rsp], rdi                         ; 48 39 bc 24 00 00 00 00              
   111 : jle    __loops_label_9                              ; 0f 8e 56 00 00 00                    
   112 :        __loops_label_8:                             ;                                      
   113 : mov    r13, qword ptr [rsp + 0x010]                 ; 4c 8b ac 24 10 00 00 00              
   114 : mov    rdi, r13                                     ; 4c 89 ef                             
   115 : imul   rdi, 0x002                                   ; 48 6b ff 02                          
   116 : cmp    qword ptr [rsp], rdi                         ; 48 39 bc 24 00 00 00 00              
   117 : jg     __loops_label_7                              ; 0f 8f 52 00 00 00                    
   118 : mov    r13, qword ptr [rsp + 0x010]                 ; 4c 8b ac 24 10 00 00 00              
   119 : mov    rdi, r13                                     ; 4c 89 ef                             
   120 : add    rdi, 0x003                                   ; 48 81 c7 03 00 00 00                 
   121 : neg    rdi                                          ; 48 f7 df                             
   122 : mov    r13, qword ptr [rsp + 0x010]                 ; 4c 8b ac 24 10 00 00 00              
   123 : mov    rsi, r13                                     ; 4c 89 ee                             
   124 : add    rsi, 0x003                                   ; 48 81 c6 03 00 00 00                 
   125 : imul   rdi, rsi                                     ; 48 0f af fe                          
   126 : cmp    qword ptr [rsp], rdi                         ; 48 39 bc 24 00 00 00 00              
   127 : jl     __loops_label_7                              ; 0f 8c 19 00 00 00                    
   128 :        __loops_label_9:                             ;                                      
   129 : cmp    qword ptr [rsp + 0x010], 0                   ; 48 81 bc 24 10 00 00 00 00 00 00 00  
   130 : jg     __loops_label_7                              ; 0f 8f 07 00 00 00                    
   131 : add    rcx, 0x003                                   ; 48 81 c1 03 00 00 00                 
   132 :        __loops_label_7:                             ;                                      
   133 : mov    r13, qword ptr [rsp + 0x010]                 ; 4c 8b ac 24 10 00 00 00              
   134 : mov    rdi, r13                                     ; 4c 89 ef                             
   135 : add    rdi, 0x005                                   ; 48 81 c7 05 00 00 00                 
   136 : shl    rdi, 0x003                                   ; 48 c1 e7 03                          
   137 : mov    r13, qword ptr [rsp + 0x018]                 ; 4c 8b ac 24 18 00 00 00              
   138 : add    rdi, r13                                     ; 4c 01 ef                             
   139 : mov    r13, qword ptr [rsp + 0x008]                 ; 4c 8b ac 24 08 00 00 00              
   140 : mov    qword ptr [r13 + rdi], rcx                   ; 49 89 4c 3d 00                       
   141 : add    qword ptr [rsp + 0x010], 0x001               ; 48 81 84 24 10 00 00 00 01 00 00 00  
   142 : jmp    __loops_label_3                              ; e9 52 fd ff ff                       
   143 :        __loops_label_5:                             ;                                      
   144 : add    qword ptr [rsp], 0x001                       ; 48 81 84 24 00 00 00 00 01 00 00 00  
   145 : jmp    __loops_label_0                              ; e9 fb fc ff ff                       
   146 :        __loops_label_2:                             ;                                      
   147 : mov    r13, qword ptr [rsp + 0x028]                 ; 4c 8b ac 24 28 00 00 00              
   148 : add    rsp, 0x038                                   ; 48 81 c4 38 00 00 00                 
   149 : ret                                                 ; c3                                   
