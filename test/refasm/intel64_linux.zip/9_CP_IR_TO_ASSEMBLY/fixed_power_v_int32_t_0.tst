fixed_power_v_int32_t_0(i0, i1, i2)
     0 : xor          rcx, rcx                      ; 48 31 c9              
     1 : imul         rdx, 0x004                    ; 48 6b d2 04           
     2 :              __loops_label_0:              ;                       
     3 : cmp          rcx, rdx                      ; 48 39 d1              
     4 : jge          __loops_label_2               ; 0f 8d 28 00 00 00     
     5 : vmovdqu      ymm0, ymmword ptr [rdi + rcx] ; c5 fe 6f 04 0f        
     6 : mov          rax, 0x001                    ; 48 c7 c0 01 00 00 00  
     7 : vpinsrd      xmm0, xmm0, eax, 0            ; c4 e3 79 22 c0 00     
     8 : vpbroadcastd ymm0, xmm0                    ; c4 e2 7d 58 c0        
     9 : vmovdqu      ymmword ptr [rsi + rcx], ymm0 ; c5 fe 7f 04 0e        
    10 : add          rcx, 0x020                    ; 48 81 c1 20 00 00 00  
    11 : jmp          __loops_label_0               ; e9 cf ff ff ff        
    12 :              __loops_label_2:              ;                       
    13 : xor          rax, rax                      ; 48 31 c0              
    14 : ret                                        ; c3                    
