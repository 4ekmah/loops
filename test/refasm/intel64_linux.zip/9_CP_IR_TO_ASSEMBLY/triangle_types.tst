triangle_types(i0, i1, i2)
     0 : sub  rsp, 0x018                   ; 48 81 ec 18 00 00 00                 
     1 : mov  qword ptr [rsp + 0x008], r13 ; 4c 89 ac 24 08 00 00 00              
     2 : mov  qword ptr [rsp], rsi         ; 48 89 b4 24 00 00 00 00              
     3 : cmp  rdi, 0                       ; 48 83 ff 00                          
     4 : jle  __loops_label_0              ; 0f 8e 1c 00 00 00                    
     5 : cmp  qword ptr [rsp], 0           ; 48 81 bc 24 00 00 00 00 00 00 00 00  
     6 : jle  __loops_label_0              ; 0f 8e 0a 00 00 00                    
     7 : cmp  rdx, 0                       ; 48 83 fa 00                          
     8 : jg   __loops_label_1              ; 0f 8f 08 00 00 00                    
     9 :      __loops_label_0:             ;                                      
    10 : xor  rax, rax                     ; 48 31 c0                             
    11 : jmp  __loops_label_18             ; e9 cd 01 00 00                       
    12 :      __loops_label_1:             ;                                      
    13 : mov  r13, qword ptr [rsp]         ; 4c 8b ac 24 00 00 00 00              
    14 : mov  rcx, r13                     ; 4c 89 e9                             
    15 : add  rcx, rdx                     ; 48 01 d1                             
    16 : cmp  rdi, rcx                     ; 48 39 cf                             
    17 : jg   __loops_label_3              ; 0f 8f 28 00 00 00                    
    18 : mov  rcx, rdi                     ; 48 89 f9                             
    19 : add  rcx, rdx                     ; 48 01 d1                             
    20 : cmp  qword ptr [rsp], rcx         ; 48 39 8c 24 00 00 00 00              
    21 : jg   __loops_label_3              ; 0f 8f 14 00 00 00                    
    22 : mov  rcx, rdi                     ; 48 89 f9                             
    23 : add  rcx, qword ptr [rsp]         ; 48 03 8c 24 00 00 00 00              
    24 : cmp  rdx, rcx                     ; 48 39 ca                             
    25 : jle  __loops_label_4              ; 0f 8e 08 00 00 00                    
    26 :      __loops_label_3:             ;                                      
    27 : xor  rax, rax                     ; 48 31 c0                             
    28 : jmp  __loops_label_18             ; e9 86 01 00 00                       
    29 :      __loops_label_4:             ;                                      
    30 : cmp  rdi, qword ptr [rsp]         ; 48 3b bc 24 00 00 00 00              
    31 : jne  __loops_label_7              ; 0f 85 15 00 00 00                    
    32 : cmp  rdi, rdx                     ; 48 39 d7                             
    33 : jne  __loops_label_7              ; 0f 85 0c 00 00 00                    
    34 : mov  rax, 0x002                   ; 48 c7 c0 02 00 00 00                 
    35 : jmp  __loops_label_18             ; e9 63 01 00 00                       
    36 :      __loops_label_7:             ;                                      
    37 : cmp  rdi, qword ptr [rsp]         ; 48 3b bc 24 00 00 00 00              
    38 : je   __loops_label_9              ; 0f 84 17 00 00 00                    
    39 : cmp  rdi, rdx                     ; 48 39 d7                             
    40 : je   __loops_label_9              ; 0f 84 0e 00 00 00                    
    41 : cmp  qword ptr [rsp], rdx         ; 48 39 94 24 00 00 00 00              
    42 : jne  __loops_label_10             ; 0f 85 0c 00 00 00                    
    43 :      __loops_label_9:             ;                                      
    44 : mov  rax, 0x003                   ; 48 c7 c0 03 00 00 00                 
    45 : jmp  __loops_label_18             ; e9 32 01 00 00                       
    46 :      __loops_label_10:            ;                                      
    47 : mov  rcx, rdi                     ; 48 89 f9                             
    48 : imul rcx, rdi                     ; 48 0f af cf                          
    49 : mov  r13, qword ptr [rsp]         ; 4c 8b ac 24 00 00 00 00              
    50 : mov  rax, r13                     ; 4c 89 e8                             
    51 : imul rax, qword ptr [rsp]         ; 48 0f af 84 24 00 00 00 00           
    52 : mov  rsi, rdx                     ; 48 89 d6                             
    53 : imul rsi, rdx                     ; 48 0f af f2                          
    54 : add  rax, rsi                     ; 48 01 f0                             
    55 : cmp  rcx, rax                     ; 48 39 c1                             
    56 : je   __loops_label_12             ; 0f 84 5c 00 00 00                    
    57 : mov  r13, qword ptr [rsp]         ; 4c 8b ac 24 00 00 00 00              
    58 : mov  rsi, r13                     ; 4c 89 ee                             
    59 : imul rsi, qword ptr [rsp]         ; 48 0f af b4 24 00 00 00 00           
    60 : mov  rcx, rdi                     ; 48 89 f9                             
    61 : imul rcx, rdi                     ; 48 0f af cf                          
    62 : mov  rax, rdx                     ; 48 89 d0                             
    63 : imul rax, rdx                     ; 48 0f af c2                          
    64 : add  rcx, rax                     ; 48 01 c1                             
    65 : cmp  rsi, rcx                     ; 48 39 ce                             
    66 : je   __loops_label_12             ; 0f 84 2e 00 00 00                    
    67 : mov  rsi, rdx                     ; 48 89 d6                             
    68 : imul rsi, rdx                     ; 48 0f af f2                          
    69 : mov  rcx, rdi                     ; 48 89 f9                             
    70 : imul rcx, rdi                     ; 48 0f af cf                          
    71 : mov  r13, qword ptr [rsp]         ; 4c 8b ac 24 00 00 00 00              
    72 : mov  rax, r13                     ; 4c 89 e8                             
    73 : imul rax, qword ptr [rsp]         ; 48 0f af 84 24 00 00 00 00           
    74 : add  rcx, rax                     ; 48 01 c1                             
    75 : cmp  rsi, rcx                     ; 48 39 ce                             
    76 : jne  __loops_label_13             ; 0f 85 0c 00 00 00                    
    77 :      __loops_label_12:            ;                                      
    78 : mov  rax, 0x001                   ; 48 c7 c0 01 00 00 00                 
    79 : jmp  __loops_label_18             ; e9 9c 00 00 00                       
    80 :      __loops_label_13:            ;                                      
    81 : mov  rsi, rdi                     ; 48 89 fe                             
    82 : imul rsi, rdi                     ; 48 0f af f7                          
    83 : mov  r13, qword ptr [rsp]         ; 4c 8b ac 24 00 00 00 00              
    84 : mov  rcx, r13                     ; 4c 89 e9                             
    85 : imul rcx, qword ptr [rsp]         ; 48 0f af 8c 24 00 00 00 00           
    86 : mov  rax, rdx                     ; 48 89 d0                             
    87 : imul rax, rdx                     ; 48 0f af c2                          
    88 : add  rcx, rax                     ; 48 01 c1                             
    89 : cmp  rsi, rcx                     ; 48 39 ce                             
    90 : jg   __loops_label_15             ; 0f 8f 56 00 00 00                    
    91 : mov  r13, qword ptr [rsp]         ; 4c 8b ac 24 00 00 00 00              
    92 : mov  rsi, r13                     ; 4c 89 ee                             
    93 : imul rsi, qword ptr [rsp]         ; 48 0f af b4 24 00 00 00 00           
    94 : mov  rcx, rdi                     ; 48 89 f9                             
    95 : imul rcx, rdi                     ; 48 0f af cf                          
    96 : mov  rax, rdx                     ; 48 89 d0                             
    97 : imul rax, rdx                     ; 48 0f af c2                          
    98 : add  rcx, rax                     ; 48 01 c1                             
    99 : cmp  rsi, rcx                     ; 48 39 ce                             
   100 : jg   __loops_label_15             ; 0f 8f 28 00 00 00                    
   101 : imul rdx, rdx                     ; 48 0f af d2                          
   102 : imul rdi, rdi                     ; 48 0f af ff                          
   103 : mov  r13, qword ptr [rsp]         ; 4c 8b ac 24 00 00 00 00              
   104 : mov  rsi, r13                     ; 4c 89 ee                             
   105 : imul rsi, qword ptr [rsp]         ; 48 0f af b4 24 00 00 00 00           
   106 : add  rdi, rsi                     ; 48 01 f7                             
   107 : cmp  rdx, rdi                     ; 48 39 fa                             
   108 : jle  __loops_label_16             ; 0f 8e 0c 00 00 00                    
   109 :      __loops_label_15:            ;                                      
   110 : mov  rax, 0x005                   ; 48 c7 c0 05 00 00 00                 
   111 : jmp  __loops_label_18             ; e9 0c 00 00 00                       
   112 :      __loops_label_16:            ;                                      
   113 : mov  rax, 0x004                   ; 48 c7 c0 04 00 00 00                 
   114 : jmp  __loops_label_18             ; e9 00 00 00 00                       
   115 :      __loops_label_2:             ;                                      
   116 :      __loops_label_5:             ;                                      
   117 :      __loops_label_8:             ;                                      
   118 :      __loops_label_11:            ;                                      
   119 :      __loops_label_14:            ;                                      
   120 :      __loops_label_17:            ;                                      
   121 :      __loops_label_18:            ;                                      
   122 : mov  r13, qword ptr [rsp + 0x008] ; 4c 8b ac 24 08 00 00 00              
   123 : add  rsp, 0x018                   ; 48 81 c4 18 00 00 00                 
   124 : ret                               ; c3                                   
