nonnegative_odd(i0, i1)
     0 : sub    rsp, 0x038                   ; 48 81 ec 38 00 00 00     
     1 : mov    qword ptr [rsp + 0x028], r13 ; 4c 89 ac 24 28 00 00 00  
     2 : xor    rdx, rdx                     ; 48 31 d2                 
     3 : mov    r13, 0x0fffffffffffffffc     ; 49 c7 c5 fc ff ff ff     
     4 : mov    qword ptr [rsp + 0x020], r13 ; 4c 89 ac 24 20 00 00 00  
     5 : imul   rsi, 0x004                   ; 48 6b f6 04              
     6 :        __loops_label_0:             ;                          
     7 : cmp    rdx, rsi                     ; 48 39 f2                 
     8 : jge    __loops_label_2              ; 0f 8d 6c 00 00 00        
     9 : movsxd rax, dword ptr [rdi + rdx]   ; 48 63 04 17              
    10 : cmp    rax, 0                       ; 48 83 f8 00              
    11 : jge    __loops_label_4              ; 0f 8d 0c 00 00 00        
    12 : add    rdx, 0x004                   ; 48 81 c2 04 00 00 00     
    13 : jmp    __loops_label_0              ; e9 dd ff ff ff           
    14 :        __loops_label_4:             ;                          
    15 : mov    rcx, 0x002                   ; 48 c7 c1 02 00 00 00     
    16 : mov    qword ptr [rsp], rax         ; 48 89 84 24 00 00 00 00  
    17 : mov    qword ptr [rsp + 0x008], rdx ; 48 89 94 24 08 00 00 00  
    18 : cqo                                 ; 48 99                    
    19 : idiv   rcx                          ; 48 f7 f9                 
    20 : mov    rcx, rdx                     ; 48 89 d1                 
    21 : mov    rax, qword ptr [rsp]         ; 48 8b 84 24 00 00 00 00  
    22 : mov    rdx, qword ptr [rsp + 0x008] ; 48 8b 94 24 08 00 00 00  
    23 : cmp    rcx, 0                       ; 48 83 f9 00              
    24 : je     __loops_label_6              ; 0f 84 0d 00 00 00        
    25 : mov    qword ptr [rsp + 0x020], rdx ; 48 89 94 24 20 00 00 00  
    26 : jmp    __loops_label_2              ; e9 0c 00 00 00           
    27 :        __loops_label_6:             ;                          
    28 : add    rdx, 0x004                   ; 48 81 c2 04 00 00 00     
    29 : jmp    __loops_label_0              ; e9 8b ff ff ff           
    30 :        __loops_label_2:             ;                          
    31 : mov    rdi, 0x004                   ; 48 c7 c7 04 00 00 00     
    32 : mov    r13, qword ptr [rsp + 0x020] ; 4c 8b ac 24 20 00 00 00  
    33 : mov    qword ptr [rsp], rax         ; 48 89 84 24 00 00 00 00  
    34 : mov    qword ptr [rsp + 0x008], rdx ; 48 89 94 24 08 00 00 00  
    35 : mov    rax, r13                     ; 4c 89 e8                 
    36 : cqo                                 ; 48 99                    
    37 : idiv   rdi                          ; 48 f7 ff                 
    38 : mov    rdi, rax                     ; 48 89 c7                 
    39 : mov    rax, qword ptr [rsp]         ; 48 8b 84 24 00 00 00 00  
    40 : mov    rdx, qword ptr [rsp + 0x008] ; 48 8b 94 24 08 00 00 00  
    41 : mov    rax, rdi                     ; 48 89 f8                 
    42 : mov    r13, qword ptr [rsp + 0x028] ; 4c 8b ac 24 28 00 00 00  
    43 : add    rsp, 0x038                   ; 48 81 c4 38 00 00 00     
    44 : ret                                 ; c3                       
