all_loads_all_stores(i0, i1, i2, i3, i4)
     0 : sub    rsp, 0x038                     ; 48 81 ec 38 00 00 00                 
     1 : mov    qword ptr [rsp + 0x018], r8    ; 4c 89 84 24 18 00 00 00              
     2 : mov    qword ptr [rsp + 0x028], r13   ; 4c 89 ac 24 28 00 00 00              
     3 : mov    qword ptr [rsp + 0x010], 0     ; 48 c7 84 24 10 00 00 00 00 00 00 00  
     4 : mov    qword ptr [rsp], 0             ; 48 c7 84 24 00 00 00 00 00 00 00 00  
     5 : mov    qword ptr [rsp + 0x008], 0     ; 48 c7 84 24 08 00 00 00 00 00 00 00  
     6 : mov    rax, 0x002                     ; 48 c7 c0 02 00 00 00                 
     7 : mov    r8, 0x001                      ; 49 c7 c0 01 00 00 00                 
     8 : cmp    rsi, 0x001                     ; 48 83 fe 01                          
     9 : cmovg  r8, rax                        ; 4c 0f 4f c0                          
    10 : mov    rax, 0x004                     ; 48 c7 c0 04 00 00 00                 
    11 : cmp    rsi, 0x003                     ; 48 83 fe 03                          
    12 : cmovg  r8, rax                        ; 4c 0f 4f c0                          
    13 : mov    rax, 0x008                     ; 48 c7 c0 08 00 00 00                 
    14 : cmp    rsi, 0x005                     ; 48 83 fe 05                          
    15 : mov    r13, r8                        ; 4d 89 c5                             
    16 : cmovg  r13, rax                       ; 4c 0f 4f e8                          
    17 : mov    qword ptr [rsp + 0x020], r13   ; 4c 89 ac 24 20 00 00 00              
    18 : mov    rax, 0x002                     ; 48 c7 c0 02 00 00 00                 
    19 : mov    r8, 0x001                      ; 49 c7 c0 01 00 00 00                 
    20 : cmp    rcx, 0x001                     ; 48 83 f9 01                          
    21 : cmovg  r8, rax                        ; 4c 0f 4f c0                          
    22 : mov    rax, 0x004                     ; 48 c7 c0 04 00 00 00                 
    23 : cmp    rcx, 0x003                     ; 48 83 f9 03                          
    24 : cmovg  r8, rax                        ; 4c 0f 4f c0                          
    25 : mov    rax, 0x008                     ; 48 c7 c0 08 00 00 00                 
    26 : cmp    rcx, 0x005                     ; 48 83 f9 05                          
    27 : cmovg  r8, rax                        ; 4c 0f 4f c0                          
    28 :        __loops_label_0:               ;                                      
    29 : mov    r13, qword ptr [rsp + 0x018]   ; 4c 8b ac 24 18 00 00 00              
    30 : cmp    qword ptr [rsp + 0x010], r13   ; 4c 39 ac 24 10 00 00 00              
    31 : jge    __loops_label_2                ; 0f 8d c1 01 00 00                    
    32 : cmp    rsi, 0                         ; 48 83 fe 00                          
    33 : jne    __loops_label_4                ; 0f 85 12 00 00 00                    
    34 : mov    r13, qword ptr [rsp]           ; 4c 8b ac 24 00 00 00 00              
    35 : movzx  rax, byte ptr [rdi + r13]      ; 4a 0f b6 04 2f                       
    36 : jmp    __loops_label_23               ; e9 b1 00 00 00                       
    37 :        __loops_label_4:               ;                                      
    38 : cmp    rsi, 0x001                     ; 48 83 fe 01                          
    39 : jne    __loops_label_7                ; 0f 85 12 00 00 00                    
    40 : mov    r13, qword ptr [rsp]           ; 4c 8b ac 24 00 00 00 00              
    41 : movsx  rax, byte ptr [rdi + r13]      ; 4a 0f be 04 2f                       
    42 : jmp    __loops_label_23               ; e9 95 00 00 00                       
    43 :        __loops_label_7:               ;                                      
    44 : cmp    rsi, 0x002                     ; 48 83 fe 02                          
    45 : jne    __loops_label_10               ; 0f 85 12 00 00 00                    
    46 : mov    r13, qword ptr [rsp]           ; 4c 8b ac 24 00 00 00 00              
    47 : movzx  rax, word ptr [rdi + r13]      ; 4a 0f b7 04 2f                       
    48 : jmp    __loops_label_23               ; e9 79 00 00 00                       
    49 :        __loops_label_10:              ;                                      
    50 : cmp    rsi, 0x003                     ; 48 83 fe 03                          
    51 : jne    __loops_label_13               ; 0f 85 12 00 00 00                    
    52 : mov    r13, qword ptr [rsp]           ; 4c 8b ac 24 00 00 00 00              
    53 : movsx  rax, word ptr [rdi + r13]      ; 4a 0f bf 04 2f                       
    54 : jmp    __loops_label_23               ; e9 5d 00 00 00                       
    55 :        __loops_label_13:              ;                                      
    56 : cmp    rsi, 0x004                     ; 48 83 fe 04                          
    57 : jne    __loops_label_16               ; 0f 85 11 00 00 00                    
    58 : mov    r13, qword ptr [rsp]           ; 4c 8b ac 24 00 00 00 00              
    59 : mov    eax, dword ptr [rdi + r13]     ; 42 8b 04 2f                          
    60 : jmp    __loops_label_23               ; e9 42 00 00 00                       
    61 :        __loops_label_16:              ;                                      
    62 : cmp    rsi, 0x005                     ; 48 83 fe 05                          
    63 : jne    __loops_label_19               ; 0f 85 11 00 00 00                    
    64 : mov    r13, qword ptr [rsp]           ; 4c 8b ac 24 00 00 00 00              
    65 : movsxd rax, dword ptr [rdi + r13]     ; 4a 63 04 2f                          
    66 : jmp    __loops_label_23               ; e9 27 00 00 00                       
    67 :        __loops_label_19:              ;                                      
    68 : cmp    rsi, 0x006                     ; 48 83 fe 06                          
    69 : jne    __loops_label_22               ; 0f 85 11 00 00 00                    
    70 : mov    r13, qword ptr [rsp]           ; 4c 8b ac 24 00 00 00 00              
    71 : mov    rax, qword ptr [rdi + r13]     ; 4a 8b 04 2f                          
    72 : jmp    __loops_label_23               ; e9 0c 00 00 00                       
    73 :        __loops_label_22:              ;                                      
    74 : mov    r13, qword ptr [rsp]           ; 4c 8b ac 24 00 00 00 00              
    75 : mov    rax, qword ptr [rdi + r13]     ; 4a 8b 04 2f                          
    76 :        __loops_label_5:               ;                                      
    77 :        __loops_label_8:               ;                                      
    78 :        __loops_label_11:              ;                                      
    79 :        __loops_label_14:              ;                                      
    80 :        __loops_label_17:              ;                                      
    81 :        __loops_label_20:              ;                                      
    82 :        __loops_label_23:              ;                                      
    83 : cmp    rcx, 0                         ; 48 83 f9 00                          
    84 : jne    __loops_label_25               ; 0f 85 11 00 00 00                    
    85 : mov    r13, qword ptr [rsp + 0x008]   ; 4c 8b ac 24 08 00 00 00              
    86 : mov    byte ptr [rdx + r13], al       ; 42 88 04 2a                          
    87 : jmp    __loops_label_44               ; e9 b0 00 00 00                       
    88 :        __loops_label_25:              ;                                      
    89 : cmp    rcx, 0x001                     ; 48 83 f9 01                          
    90 : jne    __loops_label_28               ; 0f 85 11 00 00 00                    
    91 : mov    r13, qword ptr [rsp + 0x008]   ; 4c 8b ac 24 08 00 00 00              
    92 : mov    byte ptr [rdx + r13], al       ; 42 88 04 2a                          
    93 : jmp    __loops_label_44               ; e9 95 00 00 00                       
    94 :        __loops_label_28:              ;                                      
    95 : cmp    rcx, 0x002                     ; 48 83 f9 02                          
    96 : jne    __loops_label_31               ; 0f 85 12 00 00 00                    
    97 : mov    r13, qword ptr [rsp + 0x008]   ; 4c 8b ac 24 08 00 00 00              
    98 : mov    word ptr [rdx + r13], ax       ; 66 42 89 04 2a                       
    99 : jmp    __loops_label_44               ; e9 79 00 00 00                       
   100 :        __loops_label_31:              ;                                      
   101 : cmp    rcx, 0x003                     ; 48 83 f9 03                          
   102 : jne    __loops_label_34               ; 0f 85 12 00 00 00                    
   103 : mov    r13, qword ptr [rsp + 0x008]   ; 4c 8b ac 24 08 00 00 00              
   104 : mov    word ptr [rdx + r13], ax       ; 66 42 89 04 2a                       
   105 : jmp    __loops_label_44               ; e9 5d 00 00 00                       
   106 :        __loops_label_34:              ;                                      
   107 : cmp    rcx, 0x004                     ; 48 83 f9 04                          
   108 : jne    __loops_label_37               ; 0f 85 11 00 00 00                    
   109 : mov    r13, qword ptr [rsp + 0x008]   ; 4c 8b ac 24 08 00 00 00              
   110 : mov    dword ptr [rdx + r13], eax     ; 42 89 04 2a                          
   111 : jmp    __loops_label_44               ; e9 42 00 00 00                       
   112 :        __loops_label_37:              ;                                      
   113 : cmp    rcx, 0x005                     ; 48 83 f9 05                          
   114 : jne    __loops_label_40               ; 0f 85 11 00 00 00                    
   115 : mov    r13, qword ptr [rsp + 0x008]   ; 4c 8b ac 24 08 00 00 00              
   116 : mov    dword ptr [rdx + r13], eax     ; 42 89 04 2a                          
   117 : jmp    __loops_label_44               ; e9 27 00 00 00                       
   118 :        __loops_label_40:              ;                                      
   119 : cmp    rcx, 0x006                     ; 48 83 f9 06                          
   120 : jne    __loops_label_43               ; 0f 85 11 00 00 00                    
   121 : mov    r13, qword ptr [rsp + 0x008]   ; 4c 8b ac 24 08 00 00 00              
   122 : mov    qword ptr [rdx + r13], rax     ; 4a 89 04 2a                          
   123 : jmp    __loops_label_44               ; e9 0c 00 00 00                       
   124 :        __loops_label_43:              ;                                      
   125 : mov    r13, qword ptr [rsp + 0x008]   ; 4c 8b ac 24 08 00 00 00              
   126 : mov    qword ptr [rdx + r13], rax     ; 4a 89 04 2a                          
   127 :        __loops_label_26:              ;                                      
   128 :        __loops_label_29:              ;                                      
   129 :        __loops_label_32:              ;                                      
   130 :        __loops_label_35:              ;                                      
   131 :        __loops_label_38:              ;                                      
   132 :        __loops_label_41:              ;                                      
   133 :        __loops_label_44:              ;                                      
   134 : mov    r13, qword ptr [rsp + 0x020]   ; 4c 8b ac 24 20 00 00 00              
   135 : add    qword ptr [rsp], r13           ; 4c 01 ac 24 00 00 00 00              
   136 : add    qword ptr [rsp + 0x008], r8    ; 4c 01 84 24 08 00 00 00              
   137 : add    qword ptr [rsp + 0x010], 0x001 ; 48 81 84 24 10 00 00 00 01 00 00 00  
   138 : jmp    __loops_label_0                ; e9 29 fe ff ff                       
   139 :        __loops_label_2:               ;                                      
   140 : mov    r13, qword ptr [rsp + 0x028]   ; 4c 8b ac 24 28 00 00 00              
   141 : add    rsp, 0x038                     ; 48 81 c4 38 00 00 00                 
   142 : ret                                   ; c3                                   
