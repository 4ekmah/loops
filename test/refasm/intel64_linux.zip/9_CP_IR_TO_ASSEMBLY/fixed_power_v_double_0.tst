fixed_power_v_double_0(i0, i1, i2)
     0 : xor          rcx, rcx                      ; 48 31 c9                       
     1 : imul         rdx, 0x008                    ; 48 6b d2 08                    
     2 :              __loops_label_0:              ;                                
     3 : cmp          rcx, rdx                      ; 48 39 d1                       
     4 : jge          __loops_label_2               ; 0f 8d 2b 00 00 00              
     5 : vmovupd      ymm0, ymmword ptr [rdi + rcx] ; c5 fd 10 04 0f                 
     6 : mov          rax, 0x03ff0000000000000      ; 48 b8 00 00 00 00 00 00 f0 3f  
     7 : vpinsrq      xmm0, xmm0, rax, 0            ; c4 e3 f9 22 c0 00              
     8 : vpbroadcastq ymm0, xmm0                    ; c4 e2 7d 59 c0                 
     9 : vmovupd      ymmword ptr [rsi + rcx], ymm0 ; c5 fd 11 04 0e                 
    10 : add          rcx, 0x020                    ; 48 81 c1 20 00 00 00           
    11 : jmp          __loops_label_0               ; e9 cc ff ff ff                 
    12 :              __loops_label_2:              ;                                
    13 : xor          rax, rax                      ; 48 31 c0                       
    14 : ret                                        ; c3                             
