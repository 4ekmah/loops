snake(i0, i1, i2)
     0 : sub     rsp, 0x02d8                       ; 48 81 ec d8 02 00 00                 
     1 : mov     qword ptr [rsp + 0x02b8], rdi     ; 48 89 bc 24 b8 02 00 00              
     2 : mov     qword ptr [rsp + 0x02b0], rsi     ; 48 89 b4 24 b0 02 00 00              
     3 : mov     qword ptr [rsp + 0x02a8], rdx     ; 48 89 94 24 a8 02 00 00              
     4 : mov     qword ptr [rsp + 0x02c0], r13     ; 4c 89 ac 24 c0 02 00 00              
     5 : mov     qword ptr [rsp + 0x02c8], r14     ; 4c 89 b4 24 c8 02 00 00              
     6 : mov     qword ptr [rsp + 0x02d0], rbp     ; 48 89 ac 24 d0 02 00 00              
     7 : mov     rbp, rsp                          ; 48 89 e5                             
     8 : add     rbp, 0x02d0                       ; 48 81 c5 d0 02 00 00                 
     9 : mov     r13, qword ptr [rsp + 0x02b0]     ; 4c 8b ac 24 b0 02 00 00              
    10 : mov     rcx, r13                          ; 4c 89 e9                             
    11 : add     rcx, qword ptr [rsp + 0x02a8]     ; 48 03 8c 24 a8 02 00 00              
    12 : mov     qword ptr [rsp + 0x02a0], rcx     ; 48 89 8c 24 a0 02 00 00              
    13 : sub     qword ptr [rsp + 0x02a0], 0x001   ; 48 81 ac 24 a0 02 00 00 01 00 00 00  
    14 : mov     qword ptr [rsp + 0x0298], 0       ; 48 c7 84 24 98 02 00 00 00 00 00 00  
    15 : mov     qword ptr [rsp + 0x0280], 0x001   ; 48 c7 84 24 80 02 00 00 01 00 00 00  
    16 : mov     r13, qword ptr [rsp + 0x0280]     ; 4c 8b ac 24 80 02 00 00              
    17 : neg     r13                               ; 49 f7 dd                             
    18 : mov     qword ptr [rsp + 0x0288], r13     ; 4c 89 ac 24 88 02 00 00              
    19 : mov     qword ptr [rsp + 0x0290], 0       ; 48 c7 84 24 90 02 00 00 00 00 00 00  
    20 :         __loops_label_0:                  ;                                      
    21 : mov     r13, qword ptr [rsp + 0x02a0]     ; 4c 8b ac 24 a0 02 00 00              
    22 : cmp     qword ptr [rsp + 0x0290], r13     ; 4c 39 ac 24 90 02 00 00              
    23 : jge     __loops_label_2                   ; 0f 8d 10 03 00 00                    
    24 : xor     rax, rax                          ; 48 31 c0                             
    25 : xor     rcx, rcx                          ; 48 31 c9                             
    26 : mov     r13, qword ptr [rsp + 0x0290]     ; 4c 8b ac 24 90 02 00 00              
    27 : mov     rdx, r13                          ; 4c 89 ea                             
    28 : and     rdx, 0x001                        ; 48 81 e2 01 00 00 00                 
    29 : cmp     rdx, 0                            ; 48 83 fa 00                          
    30 : je      __loops_label_4                   ; 0f 84 49 00 00 00                    
    31 : mov     r13, qword ptr [rsp + 0x02a8]     ; 4c 8b ac 24 a8 02 00 00              
    32 : mov     rdx, r13                          ; 4c 89 ea                             
    33 : sub     rdx, 0x001                        ; 48 81 ea 01 00 00 00                 
    34 : mov     r13, qword ptr [rsp + 0x0290]     ; 4c 8b ac 24 90 02 00 00              
    35 : mov     rax, r13                          ; 4c 89 e8                             
    36 : cmp     rax, rdx                          ; 48 39 d0                             
    37 : cmovg   rax, rdx                          ; 48 0f 4f c2                          
    38 : mov     r13, qword ptr [rsp + 0x0290]     ; 4c 8b ac 24 90 02 00 00              
    39 : mov     rsi, r13                          ; 4c 89 ee                             
    40 : sub     rsi, rdx                          ; 48 29 d6                             
    41 : xor     rdi, rdi                          ; 48 31 ff                             
    42 : cmp     qword ptr [rsp + 0x0290], rdx     ; 48 39 94 24 90 02 00 00              
    43 : mov     rcx, rdi                          ; 48 89 f9                             
    44 : cmovg   rcx, rsi                          ; 48 0f 4f ce                          
    45 : jmp     __loops_label_6                   ; e9 44 00 00 00                       
    46 :         __loops_label_4:                  ;                                      
    47 : mov     r13, qword ptr [rsp + 0x02b0]     ; 4c 8b ac 24 b0 02 00 00              
    48 : mov     rdi, r13                          ; 4c 89 ef                             
    49 : sub     rdi, 0x001                        ; 48 81 ef 01 00 00 00                 
    50 : mov     r13, qword ptr [rsp + 0x0290]     ; 4c 8b ac 24 90 02 00 00              
    51 : mov     rsi, r13                          ; 4c 89 ee                             
    52 : sub     rsi, rdi                          ; 48 29 fe                             
    53 : xor     rdx, rdx                          ; 48 31 d2                             
    54 : cmp     qword ptr [rsp + 0x0290], rdi     ; 48 39 bc 24 90 02 00 00              
    55 : mov     rax, rdx                          ; 48 89 d0                             
    56 : cmovg   rax, rsi                          ; 48 0f 4f c6                          
    57 : mov     r13, qword ptr [rsp + 0x0290]     ; 4c 8b ac 24 90 02 00 00              
    58 : mov     rcx, r13                          ; 4c 89 e9                             
    59 : cmp     rcx, rdi                          ; 48 39 f9                             
    60 : cmovg   rcx, rdi                          ; 48 0f 4f cf                          
    61 :         __loops_label_5:                  ;                                      
    62 :         __loops_label_6:                  ;                                      
    63 : cmp     rax, 0                            ; 48 83 f8 00                          
    64 : jl      __loops_label_8                   ; 0f 8c 36 02 00 00                    
    65 : cmp     rax, qword ptr [rsp + 0x02a8]     ; 48 3b 84 24 a8 02 00 00              
    66 : jge     __loops_label_8                   ; 0f 8d 28 02 00 00                    
    67 : cmp     rcx, 0                            ; 48 83 f9 00                          
    68 : jl      __loops_label_8                   ; 0f 8c 1e 02 00 00                    
    69 : cmp     rcx, qword ptr [rsp + 0x02b0]     ; 48 3b 8c 24 b0 02 00 00              
    70 : jge     __loops_label_8                   ; 0f 8d 10 02 00 00                    
    71 : mov     rdi, 0x055e3950aaf81              ; 48 bf 81 af 0a 95 e3 55 00 00        
    72 : mov     qword ptr [rsp], rax              ; 48 89 84 24 00 00 00 00              
    73 : mov     qword ptr [rsp + 0x008], rcx      ; 48 89 8c 24 08 00 00 00              
    74 : mov     qword ptr [rsp + 0x010], rdx      ; 48 89 94 24 10 00 00 00              
    75 : mov     qword ptr [rsp + 0x018], rsi      ; 48 89 b4 24 18 00 00 00              
    76 : mov     qword ptr [rsp + 0x020], rdi      ; 48 89 bc 24 20 00 00 00              
    77 : mov     qword ptr [rsp + 0x028], r8       ; 4c 89 84 24 28 00 00 00              
    78 : mov     qword ptr [rsp + 0x030], r9       ; 4c 89 8c 24 30 00 00 00              
    79 : mov     qword ptr [rsp + 0x038], r10      ; 4c 89 94 24 38 00 00 00              
    80 : mov     qword ptr [rsp + 0x040], r11      ; 4c 89 9c 24 40 00 00 00              
    81 : vmovdqu ymmword ptr [rsp + 0x060], ymm0   ; c5 fe 7f 84 24 60 00 00 00           
    82 : vmovdqu ymmword ptr [rsp + 0x080], ymm1   ; c5 fe 7f 8c 24 80 00 00 00           
    83 : vmovdqu ymmword ptr [rsp + 0x0a0], ymm2   ; c5 fe 7f 94 24 a0 00 00 00           
    84 : vmovdqu ymmword ptr [rsp + 0x0c0], ymm3   ; c5 fe 7f 9c 24 c0 00 00 00           
    85 : vmovdqu ymmword ptr [rsp + 0x0e0], ymm4   ; c5 fe 7f a4 24 e0 00 00 00           
    86 : vmovdqu ymmword ptr [rsp + 0x0100], ymm5  ; c5 fe 7f ac 24 00 01 00 00           
    87 : vmovdqu ymmword ptr [rsp + 0x0120], ymm6  ; c5 fe 7f b4 24 20 01 00 00           
    88 : vmovdqu ymmword ptr [rsp + 0x0140], ymm7  ; c5 fe 7f bc 24 40 01 00 00           
    89 : vmovdqu ymmword ptr [rsp + 0x0160], ymm8  ; c5 7e 7f 84 24 60 01 00 00           
    90 : vmovdqu ymmword ptr [rsp + 0x0180], ymm9  ; c5 7e 7f 8c 24 80 01 00 00           
    91 : vmovdqu ymmword ptr [rsp + 0x01a0], ymm10 ; c5 7e 7f 94 24 a0 01 00 00           
    92 : vmovdqu ymmword ptr [rsp + 0x01c0], ymm11 ; c5 7e 7f 9c 24 c0 01 00 00           
    93 : vmovdqu ymmword ptr [rsp + 0x01e0], ymm12 ; c5 7e 7f a4 24 e0 01 00 00           
    94 : vmovdqu ymmword ptr [rsp + 0x0200], ymm13 ; c5 7e 7f ac 24 00 02 00 00           
    95 : vmovdqu ymmword ptr [rsp + 0x0220], ymm14 ; c5 7e 7f b4 24 20 02 00 00           
    96 : vmovdqu ymmword ptr [rsp + 0x0240], ymm15 ; c5 7e 7f bc 24 40 02 00 00           
    97 : mov     rdi, rax                          ; 48 89 c7                             
    98 : mov     rsi, rcx                          ; 48 89 ce                             
    99 : mov     r10, qword ptr [rsp + 0x020]      ; 4c 8b 94 24 20 00 00 00              
   100 : call    r10                               ; 41 ff d2                             
   101 : mov     rax, qword ptr [rsp]              ; 48 8b 84 24 00 00 00 00              
   102 : mov     rcx, qword ptr [rsp + 0x008]      ; 48 8b 8c 24 08 00 00 00              
   103 : mov     rdx, qword ptr [rsp + 0x010]      ; 48 8b 94 24 10 00 00 00              
   104 : mov     rsi, qword ptr [rsp + 0x018]      ; 48 8b b4 24 18 00 00 00              
   105 : mov     rdi, qword ptr [rsp + 0x020]      ; 48 8b bc 24 20 00 00 00              
   106 : mov     r8, qword ptr [rsp + 0x028]       ; 4c 8b 84 24 28 00 00 00              
   107 : mov     r9, qword ptr [rsp + 0x030]       ; 4c 8b 8c 24 30 00 00 00              
   108 : mov     r10, qword ptr [rsp + 0x038]      ; 4c 8b 94 24 38 00 00 00              
   109 : mov     r11, qword ptr [rsp + 0x040]      ; 4c 8b 9c 24 40 00 00 00              
   110 : vmovdqu ymm0, ymmword ptr [rsp + 0x060]   ; c5 fe 6f 84 24 60 00 00 00           
   111 : vmovdqu ymm1, ymmword ptr [rsp + 0x080]   ; c5 fe 6f 8c 24 80 00 00 00           
   112 : vmovdqu ymm2, ymmword ptr [rsp + 0x0a0]   ; c5 fe 6f 94 24 a0 00 00 00           
   113 : vmovdqu ymm3, ymmword ptr [rsp + 0x0c0]   ; c5 fe 6f 9c 24 c0 00 00 00           
   114 : vmovdqu ymm4, ymmword ptr [rsp + 0x0e0]   ; c5 fe 6f a4 24 e0 00 00 00           
   115 : vmovdqu ymm5, ymmword ptr [rsp + 0x0100]  ; c5 fe 6f ac 24 00 01 00 00           
   116 : vmovdqu ymm6, ymmword ptr [rsp + 0x0120]  ; c5 fe 6f b4 24 20 01 00 00           
   117 : vmovdqu ymm7, ymmword ptr [rsp + 0x0140]  ; c5 fe 6f bc 24 40 01 00 00           
   118 : vmovdqu ymm8, ymmword ptr [rsp + 0x0160]  ; c5 7e 6f 84 24 60 01 00 00           
   119 : vmovdqu ymm9, ymmword ptr [rsp + 0x0180]  ; c5 7e 6f 8c 24 80 01 00 00           
   120 : vmovdqu ymm10, ymmword ptr [rsp + 0x01a0] ; c5 7e 6f 94 24 a0 01 00 00           
   121 : vmovdqu ymm11, ymmword ptr [rsp + 0x01c0] ; c5 7e 6f 9c 24 c0 01 00 00           
   122 : vmovdqu ymm12, ymmword ptr [rsp + 0x01e0] ; c5 7e 6f a4 24 e0 01 00 00           
   123 : vmovdqu ymm13, ymmword ptr [rsp + 0x0200] ; c5 7e 6f ac 24 00 02 00 00           
   124 : vmovdqu ymm14, ymmword ptr [rsp + 0x0220] ; c5 7e 6f b4 24 20 02 00 00           
   125 : vmovdqu ymm15, ymmword ptr [rsp + 0x0240] ; c5 7e 6f bc 24 40 02 00 00           
   126 : mov     rdi, rcx                          ; 48 89 cf                             
   127 : imul    rdi, qword ptr [rsp + 0x02a8]     ; 48 0f af bc 24 a8 02 00 00           
   128 : add     rdi, rax                          ; 48 01 c7                             
   129 : mov     r13, qword ptr [rsp + 0x02b8]     ; 4c 8b ac 24 b8 02 00 00              
   130 : mov     r14, qword ptr [rsp + 0x0298]     ; 4c 8b b4 24 98 02 00 00              
   131 : mov     byte ptr [r13 + rdi], r14b        ; 45 88 74 3d 00                       
   132 : add     qword ptr [rsp + 0x0298], 0x001   ; 48 81 84 24 98 02 00 00 01 00 00 00  
   133 : add     rax, qword ptr [rsp + 0x0280]     ; 48 03 84 24 80 02 00 00              
   134 : add     rcx, qword ptr [rsp + 0x0288]     ; 48 03 8c 24 88 02 00 00              
   135 : jmp     __loops_label_6                   ; e9 c0 fd ff ff                       
   136 :         __loops_label_8:                  ;                                      
   137 : neg     qword ptr [rsp + 0x0280]          ; 48 f7 9c 24 80 02 00 00              
   138 : neg     qword ptr [rsp + 0x0288]          ; 48 f7 9c 24 88 02 00 00              
   139 : add     qword ptr [rsp + 0x0290], 0x001   ; 48 81 84 24 90 02 00 00 01 00 00 00  
   140 : jmp     __loops_label_0                   ; e9 da fc ff ff                       
   141 :         __loops_label_2:                  ;                                      
   142 : mov     rbp, qword ptr [rsp + 0x02d0]     ; 48 8b ac 24 d0 02 00 00              
   143 : mov     r13, qword ptr [rsp + 0x02c0]     ; 4c 8b ac 24 c0 02 00 00              
   144 : mov     r14, qword ptr [rsp + 0x02c8]     ; 4c 8b b4 24 c8 02 00 00              
   145 : add     rsp, 0x02d8                       ; 48 81 c4 d8 02 00 00                 
   146 : ret                                       ; c3                                   
