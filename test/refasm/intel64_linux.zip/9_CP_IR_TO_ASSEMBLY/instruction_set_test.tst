instruction_set_test()
     0 : mov          rax, 0x010fffffff                  ; 48 b8 ff ff ff 0f 01 00 00 00        
     1 : mov          rdi, 0x010fffffff                  ; 48 bf ff ff ff 0f 01 00 00 00        
     2 : mov          r8, 0x010fffffff                   ; 49 b8 ff ff ff 0f 01 00 00 00        
     3 : mov          r15, 0x010fffffff                  ; 49 bf ff ff ff 0f 01 00 00 00        
     4 : mov          qword ptr [rsp + 0x0100], rax      ; 48 89 84 24 00 01 00 00              
     5 : mov          qword ptr [rsp + 0x0100], rdi      ; 48 89 bc 24 00 01 00 00              
     6 : mov          qword ptr [rsp + 0x0100], r8       ; 4c 89 84 24 00 01 00 00              
     7 : mov          qword ptr [rsp + 0x0100], r15      ; 4c 89 bc 24 00 01 00 00              
     8 : mov          qword ptr [rsp + 0x0100], 0x0101   ; 48 c7 84 24 00 01 00 00 01 01 00 00  
     9 : add          rax, 0x0100                        ; 48 05 00 01 00 00                    
    10 : add          rcx, 0x0100                        ; 48 81 c1 00 01 00 00                 
    11 : add          rdi, 0x0100                        ; 48 81 c7 00 01 00 00                 
    12 : add          r8, 0x0100                         ; 49 81 c0 00 01 00 00                 
    13 : add          r15, 0x0100                        ; 49 81 c7 00 01 00 00                 
    14 : add          rax, qword ptr [rsp + 0x0100]      ; 48 03 84 24 00 01 00 00              
    15 : add          rdi, qword ptr [rsp + 0x0100]      ; 48 03 bc 24 00 01 00 00              
    16 : add          r8, qword ptr [rsp + 0x0100]       ; 4c 03 84 24 00 01 00 00              
    17 : add          r15, qword ptr [rsp + 0x0100]      ; 4c 03 bc 24 00 01 00 00              
    18 : add          qword ptr [rsp + 0x0100], rax      ; 48 01 84 24 00 01 00 00              
    19 : add          qword ptr [rsp + 0x0100], rdi      ; 48 01 bc 24 00 01 00 00              
    20 : add          qword ptr [rsp + 0x0100], r8       ; 4c 01 84 24 00 01 00 00              
    21 : add          qword ptr [rsp + 0x0100], r15      ; 4c 01 bc 24 00 01 00 00              
    22 : add          qword ptr [rsp + 0x0100], 0x0101   ; 48 81 84 24 00 01 00 00 01 01 00 00  
    23 : sub          rax, 0x0100                        ; 48 2d 00 01 00 00                    
    24 : sub          rcx, 0x0100                        ; 48 81 e9 00 01 00 00                 
    25 : sub          rdi, 0x0100                        ; 48 81 ef 00 01 00 00                 
    26 : sub          r8, 0x0100                         ; 49 81 e8 00 01 00 00                 
    27 : sub          r15, 0x0100                        ; 49 81 ef 00 01 00 00                 
    28 : sub          rax, qword ptr [rsp + 0x0100]      ; 48 2b 84 24 00 01 00 00              
    29 : sub          rdi, qword ptr [rsp + 0x0100]      ; 48 2b bc 24 00 01 00 00              
    30 : sub          r8, qword ptr [rsp + 0x0100]       ; 4c 2b 84 24 00 01 00 00              
    31 : sub          r15, qword ptr [rsp + 0x0100]      ; 4c 2b bc 24 00 01 00 00              
    32 : sub          qword ptr [rsp + 0x0100], rax      ; 48 29 84 24 00 01 00 00              
    33 : sub          qword ptr [rsp + 0x0100], rdi      ; 48 29 bc 24 00 01 00 00              
    34 : sub          qword ptr [rsp + 0x0100], r8       ; 4c 29 84 24 00 01 00 00              
    35 : sub          qword ptr [rsp + 0x0100], r15      ; 4c 29 bc 24 00 01 00 00              
    36 : sub          qword ptr [rsp + 0x0100], 0x0101   ; 48 81 ac 24 00 01 00 00 01 01 00 00  
    37 : imul         rax, qword ptr [rsp + 0x0100]      ; 48 0f af 84 24 00 01 00 00           
    38 : imul         rdi, qword ptr [rsp + 0x0100]      ; 48 0f af bc 24 00 01 00 00           
    39 : imul         r8, qword ptr [rsp + 0x0100]       ; 4c 0f af 84 24 00 01 00 00           
    40 : imul         r15, qword ptr [rsp + 0x0100]      ; 4c 0f af bc 24 00 01 00 00           
    41 : idiv         qword ptr [rsp + 0x0100]           ; 48 f7 bc 24 00 01 00 00              
    42 : neg          qword ptr [rsp + 0x0100]           ; 48 f7 9c 24 00 01 00 00              
    43 : mov          qword ptr [rax], 0x0100            ; 48 c7 00 00 01 00 00                 
    44 : mov          qword ptr [rax], 0x0100            ; 48 c7 00 00 01 00 00                 
    45 : mov          qword ptr [rdi], 0x0100            ; 48 c7 07 00 01 00 00                 
    46 : mov          qword ptr [r8], 0x0100             ; 49 c7 00 00 01 00 00                 
    47 : mov          qword ptr [r12], 0x0100            ; 49 c7 04 24 00 01 00 00              
    48 : mov          qword ptr [r13], 0x0100            ; 49 c7 45 00 00 01 00 00              
    49 : mov          dword ptr [rax], 0x0100            ; c7 00 00 01 00 00                    
    50 : mov          dword ptr [rax], 0x0100            ; c7 00 00 01 00 00                    
    51 : mov          dword ptr [rdi], 0x0100            ; c7 07 00 01 00 00                    
    52 : mov          dword ptr [r8], 0x0100             ; 41 c7 00 00 01 00 00                 
    53 : mov          dword ptr [r12], 0x0100            ; 41 c7 04 24 00 01 00 00              
    54 : mov          dword ptr [r13], 0x0100            ; 41 c7 45 00 00 01 00 00              
    55 : mov          word ptr [rax], 0x0100             ; 66 c7 00 00 01                       
    56 : mov          word ptr [rax], 0x0100             ; 66 c7 00 00 01                       
    57 : mov          word ptr [rdi], 0x0100             ; 66 c7 07 00 01                       
    58 : mov          word ptr [r8], 0x0100              ; 66 41 c7 00 00 01                    
    59 : mov          word ptr [r12], 0x0100             ; 66 41 c7 04 24 00 01                 
    60 : mov          word ptr [r13], 0x0100             ; 66 41 c7 45 00 00 01                 
    61 : mov          byte ptr [rax], 0x0ff              ; c6 00 ff                             
    62 : mov          byte ptr [rax], 0x0ff              ; c6 00 ff                             
    63 : mov          byte ptr [rdi], 0x0ff              ; c6 07 ff                             
    64 : mov          byte ptr [r8], 0x0ff               ; 41 c6 00 ff                          
    65 : mov          byte ptr [r12], 0x0ff              ; 41 c6 04 24 ff                       
    66 : mov          byte ptr [r13], 0x0ff              ; 41 c6 45 00 ff                       
    67 : mov          qword ptr [rax], rax               ; 48 89 00                             
    68 : mov          qword ptr [rax], rax               ; 48 89 00                             
    69 : mov          qword ptr [rax], rdi               ; 48 89 38                             
    70 : mov          qword ptr [rax], r8                ; 4c 89 00                             
    71 : mov          qword ptr [rdi], rax               ; 48 89 07                             
    72 : mov          qword ptr [r8], rax                ; 49 89 00                             
    73 : mov          qword ptr [r8], r8                 ; 4d 89 00                             
    74 : mov          qword ptr [r12], rax               ; 49 89 04 24                          
    75 : mov          qword ptr [r12], rdi               ; 49 89 3c 24                          
    76 : mov          qword ptr [r12], r8                ; 4d 89 04 24                          
    77 : mov          qword ptr [r13], rax               ; 49 89 45 00                          
    78 : mov          qword ptr [r13], rdi               ; 49 89 7d 00                          
    79 : mov          qword ptr [r13], r8                ; 4d 89 45 00                          
    80 : mov          word ptr [rax], ax                 ; 66 89 00                             
    81 : mov          word ptr [rax], ax                 ; 66 89 00                             
    82 : mov          word ptr [rax], di                 ; 66 89 38                             
    83 : mov          word ptr [rax], r8w                ; 66 44 89 00                          
    84 : mov          word ptr [rdi], ax                 ; 66 89 07                             
    85 : mov          word ptr [r8], ax                  ; 66 41 89 00                          
    86 : mov          word ptr [r8], r8w                 ; 66 45 89 00                          
    87 : mov          word ptr [r12], ax                 ; 66 41 89 04 24                       
    88 : mov          word ptr [r12], di                 ; 66 41 89 3c 24                       
    89 : mov          word ptr [r12], r8w                ; 66 45 89 04 24                       
    90 : mov          word ptr [r13], ax                 ; 66 41 89 45 00                       
    91 : mov          word ptr [r13], di                 ; 66 41 89 7d 00                       
    92 : mov          word ptr [r13], r8w                ; 66 45 89 45 00                       
    93 : mov          byte ptr [rax], al                 ; 88 00                                
    94 : mov          byte ptr [rax], al                 ; 88 00                                
    95 : mov          byte ptr [rax], dil                ; 40 88 38                             
    96 : mov          byte ptr [rax], r8b                ; 44 88 00                             
    97 : mov          byte ptr [rdi], al                 ; 88 07                                
    98 : mov          byte ptr [r8], al                  ; 41 88 00                             
    99 : mov          byte ptr [r8], r8b                 ; 45 88 00                             
   100 : mov          byte ptr [r12], al                 ; 41 88 04 24                          
   101 : mov          byte ptr [r12], dil                ; 41 88 3c 24                          
   102 : mov          byte ptr [r12], r8b                ; 45 88 04 24                          
   103 : mov          byte ptr [r13], al                 ; 41 88 45 00                          
   104 : mov          byte ptr [r13], dil                ; 41 88 7d 00                          
   105 : mov          byte ptr [r13], r8b                ; 45 88 45 00                          
   106 : mov          qword ptr [rax + rax], rax         ; 48 89 04 00                          
   107 : mov          qword ptr [rax + rax], rax         ; 48 89 04 00                          
   108 : mov          qword ptr [rax + rax], rdi         ; 48 89 3c 00                          
   109 : mov          qword ptr [rax + rax], r8          ; 4c 89 04 00                          
   110 : mov          qword ptr [rax + rdi], rax         ; 48 89 04 38                          
   111 : mov          qword ptr [rax + r8], rax          ; 4a 89 04 00                          
   112 : mov          qword ptr [rax + r8], r8           ; 4e 89 04 00                          
   113 : mov          qword ptr [rdi + rax], rax         ; 48 89 04 07                          
   114 : mov          qword ptr [r8 + rax], rax          ; 49 89 04 00                          
   115 : mov          qword ptr [r8 + rax], r8           ; 4d 89 04 00                          
   116 : mov          qword ptr [r8 + r8], rax           ; 4b 89 04 00                          
   117 : mov          qword ptr [r8 + r8], r8            ; 4f 89 04 00                          
   118 : mov          qword ptr [r13 + rax], rax         ; 49 89 44 05 00                       
   119 : mov          qword ptr [r13 + rax], r8          ; 4d 89 44 05 00                       
   120 : mov          qword ptr [r13 + r8], rax          ; 4b 89 44 05 00                       
   121 : mov          qword ptr [r13 + r8], r8           ; 4f 89 44 05 00                       
   122 : mov          dword ptr [rax + rax], eax         ; 89 04 00                             
   123 : mov          dword ptr [rax + rax], eax         ; 89 04 00                             
   124 : mov          dword ptr [rax + rax], edi         ; 89 3c 00                             
   125 : mov          dword ptr [rax + rax], r8d         ; 44 89 04 00                          
   126 : mov          dword ptr [rax + rdi], eax         ; 89 04 38                             
   127 : mov          dword ptr [rax + r8], eax          ; 42 89 04 00                          
   128 : mov          dword ptr [rax + r8], r8d          ; 46 89 04 00                          
   129 : mov          dword ptr [rdi + rax], eax         ; 89 04 07                             
   130 : mov          dword ptr [r8 + rax], eax          ; 41 89 04 00                          
   131 : mov          dword ptr [r8 + rax], r8d          ; 45 89 04 00                          
   132 : mov          dword ptr [r8 + r8], eax           ; 43 89 04 00                          
   133 : mov          dword ptr [r8 + r8], r8d           ; 47 89 04 00                          
   134 : mov          dword ptr [r13 + rax], eax         ; 41 89 44 05 00                       
   135 : mov          dword ptr [r13 + rax], r8d         ; 45 89 44 05 00                       
   136 : mov          dword ptr [r13 + r8], eax          ; 43 89 44 05 00                       
   137 : mov          dword ptr [r13 + r8], r8d          ; 47 89 44 05 00                       
   138 : mov          word ptr [rax + rax], ax           ; 66 89 04 00                          
   139 : mov          word ptr [rax + rax], ax           ; 66 89 04 00                          
   140 : mov          word ptr [rax + rax], di           ; 66 89 3c 00                          
   141 : mov          word ptr [rax + rax], r8w          ; 66 44 89 04 00                       
   142 : mov          word ptr [rax + rdi], ax           ; 66 89 04 38                          
   143 : mov          word ptr [rax + r8], ax            ; 66 42 89 04 00                       
   144 : mov          word ptr [rax + r8], r8w           ; 66 46 89 04 00                       
   145 : mov          word ptr [rdi + rax], ax           ; 66 89 04 07                          
   146 : mov          word ptr [r8 + rax], ax            ; 66 41 89 04 00                       
   147 : mov          word ptr [r8 + rax], r8w           ; 66 45 89 04 00                       
   148 : mov          word ptr [r8 + r8], ax             ; 66 43 89 04 00                       
   149 : mov          word ptr [r8 + r8], r8w            ; 66 47 89 04 00                       
   150 : mov          word ptr [r13 + rax], ax           ; 66 41 89 44 05 00                    
   151 : mov          word ptr [r13 + r8], ax            ; 66 43 89 44 05 00                    
   152 : mov          word ptr [r13 + rax], r8w          ; 66 45 89 44 05 00                    
   153 : mov          word ptr [r13 + r8], r8w           ; 66 47 89 44 05 00                    
   154 : mov          byte ptr [rax + rax], al           ; 88 04 00                             
   155 : mov          byte ptr [rax + rax], al           ; 88 04 00                             
   156 : mov          byte ptr [rax + rax], dil          ; 40 88 3c 00                          
   157 : mov          byte ptr [rax + rax], r8b          ; 44 88 04 00                          
   158 : mov          byte ptr [rax + rdi], al           ; 88 04 38                             
   159 : mov          byte ptr [rax + r8], al            ; 42 88 04 00                          
   160 : mov          byte ptr [rax + r8], dil           ; 42 88 3c 00                          
   161 : mov          byte ptr [rax + r8], r8b           ; 46 88 04 00                          
   162 : mov          byte ptr [rdi + rax], al           ; 88 04 07                             
   163 : mov          byte ptr [r8 + rax], al            ; 41 88 04 00                          
   164 : mov          byte ptr [r8 + rax], dil           ; 41 88 3c 00                          
   165 : mov          byte ptr [r8 + rax], r8b           ; 45 88 04 00                          
   166 : mov          byte ptr [r8 + r8], al             ; 43 88 04 00                          
   167 : mov          byte ptr [r8 + r8], r8b            ; 47 88 04 00                          
   168 : mov          byte ptr [r8 + r8], dil            ; 43 88 3c 00                          
   169 : mov          byte ptr [r13 + rax], al           ; 41 88 44 05 00                       
   170 : mov          byte ptr [r13 + rax], r8b          ; 45 88 44 05 00                       
   171 : mov          byte ptr [r13 + r8], al            ; 43 88 44 05 00                       
   172 : mov          byte ptr [r13 + r8], r8b           ; 47 88 44 05 00                       
   173 : mov          qword ptr [rax + 0x0100], rax      ; 48 89 80 00 01 00 00                 
   174 : mov          qword ptr [rax + 0x0100], rax      ; 48 89 80 00 01 00 00                 
   175 : mov          qword ptr [rax + 0x0100], rdi      ; 48 89 b8 00 01 00 00                 
   176 : mov          qword ptr [rax + 0x0100], r8       ; 4c 89 80 00 01 00 00                 
   177 : mov          qword ptr [rdi + 0x0100], rax      ; 48 89 87 00 01 00 00                 
   178 : mov          qword ptr [r8 + 0x0100], rax       ; 49 89 80 00 01 00 00                 
   179 : mov          qword ptr [r8 + 0x0100], r8        ; 4d 89 80 00 01 00 00                 
   180 : mov          qword ptr [r12 + 0x0100], rax      ; 49 89 84 24 00 01 00 00              
   181 : mov          qword ptr [r12 + 0x0100], rdi      ; 49 89 bc 24 00 01 00 00              
   182 : mov          qword ptr [r12 + 0x0100], r8       ; 4d 89 84 24 00 01 00 00              
   183 : mov          dword ptr [rax + 0x0100], eax      ; 89 80 00 01 00 00                    
   184 : mov          dword ptr [rax + 0x0100], eax      ; 89 80 00 01 00 00                    
   185 : mov          dword ptr [rax + 0x0100], edi      ; 89 b8 00 01 00 00                    
   186 : mov          dword ptr [rax + 0x0100], r8d      ; 44 89 80 00 01 00 00                 
   187 : mov          dword ptr [rdi + 0x0100], eax      ; 89 87 00 01 00 00                    
   188 : mov          dword ptr [r8 + 0x0100], eax       ; 41 89 80 00 01 00 00                 
   189 : mov          dword ptr [r8 + 0x0100], r8d       ; 45 89 80 00 01 00 00                 
   190 : mov          dword ptr [r12 + 0x0100], eax      ; 41 89 84 24 00 01 00 00              
   191 : mov          dword ptr [r12 + 0x0100], r8d      ; 45 89 84 24 00 01 00 00              
   192 : mov          word ptr [rax + 0x0100], ax        ; 66 89 80 00 01 00 00                 
   193 : mov          word ptr [rax + 0x0100], ax        ; 66 89 80 00 01 00 00                 
   194 : mov          word ptr [rax + 0x0100], di        ; 66 89 b8 00 01 00 00                 
   195 : mov          word ptr [rax + 0x0100], r8w       ; 66 44 89 80 00 01 00 00              
   196 : mov          word ptr [rdi + 0x0100], ax        ; 66 89 87 00 01 00 00                 
   197 : mov          word ptr [r8 + 0x0100], ax         ; 66 41 89 80 00 01 00 00              
   198 : mov          word ptr [r8 + 0x0100], r8w        ; 66 45 89 80 00 01 00 00              
   199 : mov          word ptr [r12 + 0x0100], ax        ; 66 41 89 84 24 00 01 00 00           
   200 : mov          word ptr [r12 + 0x0100], r8w       ; 66 45 89 84 24 00 01 00 00           
   201 : mov          byte ptr [rax + 0x0100], al        ; 88 80 00 01 00 00                    
   202 : mov          byte ptr [rax + 0x0100], al        ; 88 80 00 01 00 00                    
   203 : mov          byte ptr [rax + 0x0100], dil       ; 40 88 b8 00 01 00 00                 
   204 : mov          byte ptr [rax + 0x0100], r8b       ; 44 88 80 00 01 00 00                 
   205 : mov          byte ptr [rdi + 0x0100], al        ; 88 87 00 01 00 00                    
   206 : mov          byte ptr [r8 + 0x0100], al         ; 41 88 80 00 01 00 00                 
   207 : mov          byte ptr [r8 + 0x0100], r8b        ; 45 88 80 00 01 00 00                 
   208 : mov          byte ptr [r12 + 0x0100], al        ; 41 88 84 24 00 01 00 00              
   209 : mov          byte ptr [r12 + 0x0100], r8b       ; 45 88 84 24 00 01 00 00              
   210 : mov          qword ptr [rax + rax], 0x0100      ; 48 c7 04 00 00 01 00 00              
   211 : mov          qword ptr [rax + rax], 0x0100      ; 48 c7 04 00 00 01 00 00              
   212 : mov          qword ptr [rax + rdi], 0x0100      ; 48 c7 04 38 00 01 00 00              
   213 : mov          qword ptr [rax + r8], 0x0100       ; 4a c7 04 00 00 01 00 00              
   214 : mov          qword ptr [rdi + rax], 0x0100      ; 48 c7 04 07 00 01 00 00              
   215 : mov          qword ptr [r8 + rax], 0x0100       ; 49 c7 04 00 00 01 00 00              
   216 : mov          qword ptr [r8 + r8], 0x0100        ; 4b c7 04 00 00 01 00 00              
   217 : mov          qword ptr [r13 + rax], 0x0100      ; 49 c7 44 05 00 00 01 00 00           
   218 : mov          qword ptr [r13 + r8], 0x0100       ; 4b c7 44 05 00 00 01 00 00           
   219 : mov          dword ptr [rax + rax], 0x0100      ; c7 04 00 00 01 00 00                 
   220 : mov          dword ptr [rax + rax], 0x0100      ; c7 04 00 00 01 00 00                 
   221 : mov          dword ptr [rax + rdi], 0x0100      ; c7 04 38 00 01 00 00                 
   222 : mov          dword ptr [rax + r8], 0x0100       ; 42 c7 04 00 00 01 00 00              
   223 : mov          dword ptr [rdi + rax], 0x0100      ; c7 04 07 00 01 00 00                 
   224 : mov          dword ptr [r8 + rax], 0x0100       ; 41 c7 04 00 00 01 00 00              
   225 : mov          dword ptr [r8 + r8], 0x0100        ; 43 c7 04 00 00 01 00 00              
   226 : mov          dword ptr [r13 + rax], 0x0100      ; 41 c7 44 05 00 00 01 00 00           
   227 : mov          dword ptr [r13 + r8], 0x0100       ; 43 c7 44 05 00 00 01 00 00           
   228 : mov          word ptr [rax + rax], 0x0100       ; 66 c7 04 00 00 01                    
   229 : mov          word ptr [rax + rax], 0x0100       ; 66 c7 04 00 00 01                    
   230 : mov          word ptr [rax + rdi], 0x0100       ; 66 c7 04 38 00 01                    
   231 : mov          word ptr [rax + r8], 0x0100        ; 66 42 c7 04 00 00 01                 
   232 : mov          word ptr [rdi + rax], 0x0100       ; 66 c7 04 07 00 01                    
   233 : mov          word ptr [r8 + rax], 0x0100        ; 66 41 c7 04 00 00 01                 
   234 : mov          word ptr [r8 + r8], 0x0100         ; 66 43 c7 04 00 00 01                 
   235 : mov          word ptr [r13 + rax], 0x0100       ; 66 41 c7 44 05 00 00 01              
   236 : mov          word ptr [r13 + r8], 0x0100        ; 66 43 c7 44 05 00 00 01              
   237 : mov          byte ptr [rax + rax], 0x0ff        ; c6 04 00 ff                          
   238 : mov          byte ptr [rax + rax], 0x0ff        ; c6 04 00 ff                          
   239 : mov          byte ptr [rax + rdi], 0x0ff        ; c6 04 38 ff                          
   240 : mov          byte ptr [rax + r8], 0x0ff         ; 42 c6 04 00 ff                       
   241 : mov          byte ptr [rdi + rax], 0x0ff        ; c6 04 07 ff                          
   242 : mov          byte ptr [r8 + rax], 0x0ff         ; 41 c6 04 00 ff                       
   243 : mov          byte ptr [r8 + r8], 0x0ff          ; 43 c6 04 00 ff                       
   244 : mov          byte ptr [r13 + rax], 0x0ff        ; 41 c6 44 05 00 ff                    
   245 : mov          byte ptr [r13 + r8], 0x0ff         ; 43 c6 44 05 00 ff                    
   246 : mov          qword ptr [rax + 0x0101], 0x0100   ; 48 c7 80 01 01 00 00 00 01 00 00     
   247 : mov          qword ptr [rax + 0x0101], 0x0100   ; 48 c7 80 01 01 00 00 00 01 00 00     
   248 : mov          qword ptr [rsp + 0x0101], 0x0100   ; 48 c7 84 24 01 01 00 00 00 01 00 00  
   249 : mov          qword ptr [rdi + 0x0101], 0x0100   ; 48 c7 87 01 01 00 00 00 01 00 00     
   250 : mov          qword ptr [r8 + 0x0101], 0x0100    ; 49 c7 80 01 01 00 00 00 01 00 00     
   251 : mov          qword ptr [r12 + 0x0101], 0x0100   ; 49 c7 84 24 01 01 00 00 00 01 00 00  
   252 : mov          dword ptr [rax + 0x0101], 0x0100   ; c7 80 01 01 00 00 00 01 00 00        
   253 : mov          dword ptr [rax + 0x0101], 0x0100   ; c7 80 01 01 00 00 00 01 00 00        
   254 : mov          dword ptr [rsp + 0x0101], 0x0100   ; c7 84 24 01 01 00 00 00 01 00 00     
   255 : mov          dword ptr [rdi + 0x0101], 0x0100   ; c7 87 01 01 00 00 00 01 00 00        
   256 : mov          dword ptr [r8 + 0x0101], 0x0100    ; 41 c7 80 01 01 00 00 00 01 00 00     
   257 : mov          dword ptr [r12 + 0x0101], 0x0100   ; 41 c7 84 24 01 01 00 00 00 01 00 00  
   258 : mov          word ptr [rax + 0x0101], 0x0100    ; 66 c7 80 01 01 00 00 00 01           
   259 : mov          word ptr [rax + 0x0101], 0x0100    ; 66 c7 80 01 01 00 00 00 01           
   260 : mov          word ptr [rsp + 0x0101], 0x0100    ; 66 c7 84 24 01 01 00 00 00 01        
   261 : mov          word ptr [rdi + 0x0101], 0x0100    ; 66 c7 87 01 01 00 00 00 01           
   262 : mov          word ptr [r8 + 0x0101], 0x0100     ; 66 41 c7 80 01 01 00 00 00 01        
   263 : mov          word ptr [r12 + 0x0101], 0x0100    ; 66 41 c7 84 24 01 01 00 00 00 01     
   264 : mov          byte ptr [rax + 0x0101], 0x0ff     ; c6 80 01 01 00 00 ff                 
   265 : mov          byte ptr [rsp + 0x0101], 0x0ff     ; c6 84 24 01 01 00 00 ff              
   266 : mov          byte ptr [rax + 0x0101], 0x0ff     ; c6 80 01 01 00 00 ff                 
   267 : mov          byte ptr [rdi + 0x0101], 0x0ff     ; c6 87 01 01 00 00 ff                 
   268 : mov          byte ptr [r8 + 0x0101], 0x0ff      ; 41 c6 80 01 01 00 00 ff              
   269 : mov          byte ptr [r12 + 0x0101], 0x0ff     ; 41 c6 84 24 01 01 00 00 ff           
   270 : mov          rax, qword ptr [rax]               ; 48 8b 00                             
   271 : mov          rax, qword ptr [rax]               ; 48 8b 00                             
   272 : mov          rdi, qword ptr [rax]               ; 48 8b 38                             
   273 : mov          rax, qword ptr [rdi]               ; 48 8b 07                             
   274 : mov          rax, qword ptr [rax]               ; 48 8b 00                             
   275 : mov          r8, qword ptr [rax]                ; 4c 8b 00                             
   276 : mov          rax, qword ptr [r8]                ; 49 8b 00                             
   277 : mov          rax, qword ptr [r12]               ; 49 8b 04 24                          
   278 : mov          rax, qword ptr [r13]               ; 49 8b 45 00                          
   279 : mov          r8, qword ptr [r8]                 ; 4d 8b 00                             
   280 : mov          r8, qword ptr [r12]                ; 4d 8b 04 24                          
   281 : mov          r8, qword ptr [r13]                ; 4d 8b 45 00                          
   282 : mov          eax, dword ptr [rax]               ; 8b 00                                
   283 : mov          edi, dword ptr [rax]               ; 8b 38                                
   284 : mov          eax, dword ptr [rdi]               ; 8b 07                                
   285 : mov          eax, dword ptr [rax]               ; 8b 00                                
   286 : mov          r8d, dword ptr [rax]               ; 44 8b 00                             
   287 : mov          eax, dword ptr [r8]                ; 41 8b 00                             
   288 : mov          eax, dword ptr [r12]               ; 41 8b 04 24                          
   289 : mov          eax, dword ptr [r13]               ; 41 8b 45 00                          
   290 : mov          r8d, dword ptr [r8]                ; 45 8b 00                             
   291 : mov          r8d, dword ptr [r12]               ; 45 8b 04 24                          
   292 : mov          r8d, dword ptr [r13]               ; 45 8b 45 00                          
   293 : movsxd       rax, dword ptr [rax]               ; 48 63 00                             
   294 : movsxd       rdi, dword ptr [rax]               ; 48 63 38                             
   295 : movsxd       rax, dword ptr [rdi]               ; 48 63 07                             
   296 : movsxd       r8, dword ptr [rax]                ; 4c 63 00                             
   297 : movsxd       rax, dword ptr [r8]                ; 49 63 00                             
   298 : movsxd       rax, dword ptr [r12]               ; 49 63 04 24                          
   299 : movsxd       rax, dword ptr [r13]               ; 49 63 45 00                          
   300 : movsxd       r8, dword ptr [r8]                 ; 4d 63 00                             
   301 : movsxd       r8, dword ptr [r12]                ; 4d 63 04 24                          
   302 : movsxd       r8, dword ptr [r13]                ; 4d 63 45 00                          
   303 : movzx        rax, word ptr [rax]                ; 48 0f b7 00                          
   304 : movzx        rdi, word ptr [rax]                ; 48 0f b7 38                          
   305 : movzx        rax, word ptr [rdi]                ; 48 0f b7 07                          
   306 : movzx        r8, word ptr [rax]                 ; 4c 0f b7 00                          
   307 : movzx        rax, word ptr [r8]                 ; 49 0f b7 00                          
   308 : movzx        rax, word ptr [r12]                ; 49 0f b7 04 24                       
   309 : movzx        rax, word ptr [r13]                ; 49 0f b7 45 00                       
   310 : movzx        r8, word ptr [r8]                  ; 4d 0f b7 00                          
   311 : movzx        r8, word ptr [r12]                 ; 4d 0f b7 04 24                       
   312 : movzx        r8, word ptr [r13]                 ; 4d 0f b7 45 00                       
   313 : movsx        rax, word ptr [rax]                ; 48 0f bf 00                          
   314 : movsx        rdi, word ptr [rax]                ; 48 0f bf 38                          
   315 : movsx        rax, word ptr [rdi]                ; 48 0f bf 07                          
   316 : movsx        r8, word ptr [rax]                 ; 4c 0f bf 00                          
   317 : movsx        rax, word ptr [r8]                 ; 49 0f bf 00                          
   318 : movsx        rax, word ptr [r12]                ; 49 0f bf 04 24                       
   319 : movsx        rax, word ptr [r13]                ; 49 0f bf 45 00                       
   320 : movsx        r8, word ptr [r8]                  ; 4d 0f bf 00                          
   321 : movsx        r8, word ptr [r12]                 ; 4d 0f bf 04 24                       
   322 : movsx        r8, word ptr [r13]                 ; 4d 0f bf 45 00                       
   323 : movzx        rax, byte ptr [rax]                ; 48 0f b6 00                          
   324 : movzx        rdi, byte ptr [rax]                ; 48 0f b6 38                          
   325 : movzx        rax, byte ptr [rdi]                ; 48 0f b6 07                          
   326 : movzx        r8, byte ptr [rax]                 ; 4c 0f b6 00                          
   327 : movzx        rax, byte ptr [r8]                 ; 49 0f b6 00                          
   328 : movzx        rax, byte ptr [r12]                ; 49 0f b6 04 24                       
   329 : movzx        rax, byte ptr [r13]                ; 49 0f b6 45 00                       
   330 : movzx        r8, byte ptr [r8]                  ; 4d 0f b6 00                          
   331 : movzx        r8, byte ptr [r12]                 ; 4d 0f b6 04 24                       
   332 : movzx        r8, byte ptr [r13]                 ; 4d 0f b6 45 00                       
   333 : movsx        rax, byte ptr [rax]                ; 48 0f be 00                          
   334 : movsx        rdi, byte ptr [rax]                ; 48 0f be 38                          
   335 : movsx        rax, byte ptr [rdi]                ; 48 0f be 07                          
   336 : movsx        r8, byte ptr [rax]                 ; 4c 0f be 00                          
   337 : movsx        rax, byte ptr [r8]                 ; 49 0f be 00                          
   338 : movsx        rax, byte ptr [r12]                ; 49 0f be 04 24                       
   339 : movsx        rax, byte ptr [r13]                ; 49 0f be 45 00                       
   340 : movsx        r8, byte ptr [r8]                  ; 4d 0f be 00                          
   341 : movsx        r8, byte ptr [r12]                 ; 4d 0f be 04 24                       
   342 : movsx        r8, byte ptr [r13]                 ; 4d 0f be 45 00                       
   343 : mov          rax, qword ptr [rax + 0x0100]      ; 48 8b 80 00 01 00 00                 
   344 : mov          rax, qword ptr [rax + 0x0100]      ; 48 8b 80 00 01 00 00                 
   345 : mov          rdi, qword ptr [rax + 0x0100]      ; 48 8b b8 00 01 00 00                 
   346 : mov          rax, qword ptr [rsp + 0x0100]      ; 48 8b 84 24 00 01 00 00              
   347 : mov          rax, qword ptr [rdi + 0x0100]      ; 48 8b 87 00 01 00 00                 
   348 : mov          rax, qword ptr [rax + 0x0100]      ; 48 8b 80 00 01 00 00                 
   349 : mov          r8, qword ptr [rax + 0x0100]       ; 4c 8b 80 00 01 00 00                 
   350 : mov          rax, qword ptr [r8 + 0x0100]       ; 49 8b 80 00 01 00 00                 
   351 : mov          rax, qword ptr [r12 + 0x0100]      ; 49 8b 84 24 00 01 00 00              
   352 : mov          r8, qword ptr [r8 + 0x0100]        ; 4d 8b 80 00 01 00 00                 
   353 : mov          r8, qword ptr [r12 + 0x0100]       ; 4d 8b 84 24 00 01 00 00              
   354 : mov          eax, dword ptr [rax + 0x0100]      ; 8b 80 00 01 00 00                    
   355 : mov          edi, dword ptr [rax + 0x0100]      ; 8b b8 00 01 00 00                    
   356 : mov          eax, dword ptr [rsp + 0x0100]      ; 8b 84 24 00 01 00 00                 
   357 : mov          eax, dword ptr [rdi + 0x0100]      ; 8b 87 00 01 00 00                    
   358 : mov          r8d, dword ptr [rax + 0x0100]      ; 44 8b 80 00 01 00 00                 
   359 : mov          eax, dword ptr [r8 + 0x0100]       ; 41 8b 80 00 01 00 00                 
   360 : mov          eax, dword ptr [r12 + 0x0100]      ; 41 8b 84 24 00 01 00 00              
   361 : mov          r8d, dword ptr [r8 + 0x0100]       ; 45 8b 80 00 01 00 00                 
   362 : mov          r8d, dword ptr [r12 + 0x0100]      ; 45 8b 84 24 00 01 00 00              
   363 : movsxd       rax, dword ptr [rax + 0x0100]      ; 48 63 80 00 01 00 00                 
   364 : movsxd       rdi, dword ptr [rax + 0x0100]      ; 48 63 b8 00 01 00 00                 
   365 : movsxd       rax, dword ptr [rsp + 0x0100]      ; 48 63 84 24 00 01 00 00              
   366 : movsxd       rax, dword ptr [rdi + 0x0100]      ; 48 63 87 00 01 00 00                 
   367 : movsxd       r8, dword ptr [rax + 0x0100]       ; 4c 63 80 00 01 00 00                 
   368 : movsxd       rax, dword ptr [r8 + 0x0100]       ; 49 63 80 00 01 00 00                 
   369 : movsxd       rax, dword ptr [r12 + 0x0100]      ; 49 63 84 24 00 01 00 00              
   370 : movsxd       r8, dword ptr [r8 + 0x0100]        ; 4d 63 80 00 01 00 00                 
   371 : movsxd       r8, dword ptr [r12 + 0x0100]       ; 4d 63 84 24 00 01 00 00              
   372 : movzx        rax, word ptr [rax + 0x0100]       ; 48 0f b7 80 00 01 00 00              
   373 : movzx        rdi, word ptr [rax + 0x0100]       ; 48 0f b7 b8 00 01 00 00              
   374 : movzx        rax, word ptr [rsp + 0x0100]       ; 48 0f b7 84 24 00 01 00 00           
   375 : movzx        rax, word ptr [rdi + 0x0100]       ; 48 0f b7 87 00 01 00 00              
   376 : movzx        r8, word ptr [rax + 0x0100]        ; 4c 0f b7 80 00 01 00 00              
   377 : movzx        rax, word ptr [r8 + 0x0100]        ; 49 0f b7 80 00 01 00 00              
   378 : movzx        rax, word ptr [r12 + 0x0100]       ; 49 0f b7 84 24 00 01 00 00           
   379 : movzx        r8, word ptr [r8 + 0x0100]         ; 4d 0f b7 80 00 01 00 00              
   380 : movzx        r8, word ptr [r12 + 0x0100]        ; 4d 0f b7 84 24 00 01 00 00           
   381 : movsx        rax, word ptr [rax + 0x0100]       ; 48 0f bf 80 00 01 00 00              
   382 : movsx        rdi, word ptr [rax + 0x0100]       ; 48 0f bf b8 00 01 00 00              
   383 : movsx        rax, word ptr [rsp + 0x0100]       ; 48 0f bf 84 24 00 01 00 00           
   384 : movsx        rax, word ptr [rdi + 0x0100]       ; 48 0f bf 87 00 01 00 00              
   385 : movsx        r8, word ptr [rax + 0x0100]        ; 4c 0f bf 80 00 01 00 00              
   386 : movsx        rax, word ptr [r8 + 0x0100]        ; 49 0f bf 80 00 01 00 00              
   387 : movsx        rax, word ptr [r12 + 0x0100]       ; 49 0f bf 84 24 00 01 00 00           
   388 : movsx        r8, word ptr [r8 + 0x0100]         ; 4d 0f bf 80 00 01 00 00              
   389 : movsx        r8, word ptr [r12 + 0x0100]        ; 4d 0f bf 84 24 00 01 00 00           
   390 : movzx        rax, byte ptr [rax + 0x0100]       ; 48 0f b6 80 00 01 00 00              
   391 : movzx        rdi, byte ptr [rax + 0x0100]       ; 48 0f b6 b8 00 01 00 00              
   392 : movzx        rax, byte ptr [rsp + 0x0100]       ; 48 0f b6 84 24 00 01 00 00           
   393 : movzx        rax, byte ptr [rdi + 0x0100]       ; 48 0f b6 87 00 01 00 00              
   394 : movzx        r8, byte ptr [rax + 0x0100]        ; 4c 0f b6 80 00 01 00 00              
   395 : movzx        rax, byte ptr [r8 + 0x0100]        ; 49 0f b6 80 00 01 00 00              
   396 : movzx        rax, byte ptr [r12 + 0x0100]       ; 49 0f b6 84 24 00 01 00 00           
   397 : movzx        r8, byte ptr [r8 + 0x0100]         ; 4d 0f b6 80 00 01 00 00              
   398 : movzx        r8, byte ptr [r12 + 0x0100]        ; 4d 0f b6 84 24 00 01 00 00           
   399 : movsx        rax, byte ptr [rax + 0x0100]       ; 48 0f be 80 00 01 00 00              
   400 : movsx        rdi, byte ptr [rax + 0x0100]       ; 48 0f be b8 00 01 00 00              
   401 : movsx        rax, byte ptr [rsp + 0x0100]       ; 48 0f be 84 24 00 01 00 00           
   402 : movsx        rax, byte ptr [rdi + 0x0100]       ; 48 0f be 87 00 01 00 00              
   403 : movsx        r8, byte ptr [rax + 0x0100]        ; 4c 0f be 80 00 01 00 00              
   404 : movsx        rax, byte ptr [r8 + 0x0100]        ; 49 0f be 80 00 01 00 00              
   405 : movsx        rax, byte ptr [r12 + 0x0100]       ; 49 0f be 84 24 00 01 00 00           
   406 : movsx        r8, byte ptr [r8 + 0x0100]         ; 4d 0f be 80 00 01 00 00              
   407 : movsx        r8, byte ptr [r12 + 0x0100]        ; 4d 0f be 84 24 00 01 00 00           
   408 : mov          rax, qword ptr [rax + rax]         ; 48 8b 04 00                          
   409 : mov          rax, qword ptr [rax + rax]         ; 48 8b 04 00                          
   410 : mov          rdi, qword ptr [rax + rax]         ; 48 8b 3c 00                          
   411 : mov          rax, qword ptr [rdi + rax]         ; 48 8b 04 07                          
   412 : mov          rax, qword ptr [rax + rdi]         ; 48 8b 04 38                          
   413 : mov          rax, qword ptr [rax + rax]         ; 48 8b 04 00                          
   414 : mov          r8, qword ptr [rax + rax]          ; 4c 8b 04 00                          
   415 : mov          rax, qword ptr [r8 + rax]          ; 49 8b 04 00                          
   416 : mov          r8, qword ptr [r8 + rax]           ; 4d 8b 04 00                          
   417 : mov          rax, qword ptr [r13 + rax]         ; 49 8b 44 05 00                       
   418 : mov          r8, qword ptr [r13 + rax]          ; 4d 8b 44 05 00                       
   419 : mov          rax, qword ptr [rax + r8]          ; 4a 8b 04 00                          
   420 : mov          r8, qword ptr [rax + r8]           ; 4e 8b 04 00                          
   421 : mov          rax, qword ptr [r8 + r8]           ; 4b 8b 04 00                          
   422 : mov          r8, qword ptr [r8 + r8]            ; 4f 8b 04 00                          
   423 : mov          rax, qword ptr [r13 + r8]          ; 4b 8b 44 05 00                       
   424 : mov          r8, qword ptr [r13 + r8]           ; 4f 8b 44 05 00                       
   425 : mov          eax, dword ptr [rax + rax]         ; 8b 04 00                             
   426 : mov          edi, dword ptr [rax + rax]         ; 8b 3c 00                             
   427 : mov          eax, dword ptr [rdi + rax]         ; 8b 04 07                             
   428 : mov          eax, dword ptr [rax + rdi]         ; 8b 04 38                             
   429 : mov          r8d, dword ptr [rax + rax]         ; 44 8b 04 00                          
   430 : mov          eax, dword ptr [r8 + rax]          ; 41 8b 04 00                          
   431 : mov          r8d, dword ptr [r8 + rax]          ; 45 8b 04 00                          
   432 : mov          eax, dword ptr [r13 + rax]         ; 41 8b 44 05 00                       
   433 : mov          r8d, dword ptr [r13 + rax]         ; 45 8b 44 05 00                       
   434 : mov          eax, dword ptr [rax + r8]          ; 42 8b 04 00                          
   435 : mov          r8d, dword ptr [rax + r8]          ; 46 8b 04 00                          
   436 : mov          eax, dword ptr [r8 + r8]           ; 43 8b 04 00                          
   437 : mov          r8d, dword ptr [r8 + r8]           ; 47 8b 04 00                          
   438 : mov          eax, dword ptr [r13 + r8]          ; 43 8b 44 05 00                       
   439 : mov          r8d, dword ptr [r13 + r8]          ; 47 8b 44 05 00                       
   440 : movsxd       rax, dword ptr [rax + rax]         ; 48 63 04 00                          
   441 : movsxd       rdi, dword ptr [rax + rax]         ; 48 63 3c 00                          
   442 : movsxd       rax, dword ptr [rdi + rax]         ; 48 63 04 07                          
   443 : movsxd       rax, dword ptr [rax + rdi]         ; 48 63 04 38                          
   444 : movsxd       r8, dword ptr [rax + rax]          ; 4c 63 04 00                          
   445 : movsxd       rax, dword ptr [r8 + rax]          ; 49 63 04 00                          
   446 : movsxd       r8, dword ptr [r8 + rax]           ; 4d 63 04 00                          
   447 : movsxd       rax, dword ptr [r13 + rax]         ; 49 63 44 05 00                       
   448 : movsxd       r8, dword ptr [r13 + rax]          ; 4d 63 44 05 00                       
   449 : movsxd       rax, dword ptr [rax + r8]          ; 4a 63 04 00                          
   450 : movsxd       r8, dword ptr [rax + r8]           ; 4e 63 04 00                          
   451 : movsxd       rax, dword ptr [r8 + r8]           ; 4b 63 04 00                          
   452 : movsxd       r8, dword ptr [r8 + r8]            ; 4f 63 04 00                          
   453 : movsxd       rax, dword ptr [r13 + r8]          ; 4b 63 44 05 00                       
   454 : movsxd       r8, dword ptr [r13 + r8]           ; 4f 63 44 05 00                       
   455 : movzx        rax, word ptr [rax + rax]          ; 48 0f b7 04 00                       
   456 : movzx        rdi, word ptr [rax + rax]          ; 48 0f b7 3c 00                       
   457 : movzx        rax, word ptr [rdi + rax]          ; 48 0f b7 04 07                       
   458 : movzx        rax, word ptr [rax + rdi]          ; 48 0f b7 04 38                       
   459 : movzx        r8, word ptr [rax + rax]           ; 4c 0f b7 04 00                       
   460 : movzx        rax, word ptr [r8 + rax]           ; 49 0f b7 04 00                       
   461 : movzx        r8, word ptr [r8 + rax]            ; 4d 0f b7 04 00                       
   462 : movzx        rax, word ptr [r13 + rax]          ; 49 0f b7 44 05 00                    
   463 : movzx        r8, word ptr [r13 + rax]           ; 4d 0f b7 44 05 00                    
   464 : movzx        rax, word ptr [rax + r8]           ; 4a 0f b7 04 00                       
   465 : movzx        r8, word ptr [rax + r8]            ; 4e 0f b7 04 00                       
   466 : movzx        rax, word ptr [r8 + r8]            ; 4b 0f b7 04 00                       
   467 : movzx        r8, word ptr [r8 + r8]             ; 4f 0f b7 04 00                       
   468 : movzx        rax, word ptr [r13 + r8]           ; 4b 0f b7 44 05 00                    
   469 : movzx        r8, word ptr [r13 + r8]            ; 4f 0f b7 44 05 00                    
   470 : movsx        rax, word ptr [rax + rax]          ; 48 0f bf 04 00                       
   471 : movsx        rdi, word ptr [rax + rax]          ; 48 0f bf 3c 00                       
   472 : movsx        rax, word ptr [rdi + rax]          ; 48 0f bf 04 07                       
   473 : movsx        rax, word ptr [rax + rdi]          ; 48 0f bf 04 38                       
   474 : movsx        r8, word ptr [rax + rax]           ; 4c 0f bf 04 00                       
   475 : movsx        rax, word ptr [r8 + rax]           ; 49 0f bf 04 00                       
   476 : movsx        r8, word ptr [r8 + rax]            ; 4d 0f bf 04 00                       
   477 : movsx        rax, word ptr [r13 + rax]          ; 49 0f bf 44 05 00                    
   478 : movsx        r8, word ptr [r13 + rax]           ; 4d 0f bf 44 05 00                    
   479 : movsx        rax, word ptr [rax + r8]           ; 4a 0f bf 04 00                       
   480 : movsx        r8, word ptr [rax + r8]            ; 4e 0f bf 04 00                       
   481 : movsx        rax, word ptr [r8 + r8]            ; 4b 0f bf 04 00                       
   482 : movsx        r8, word ptr [r8 + r8]             ; 4f 0f bf 04 00                       
   483 : movsx        rax, word ptr [r13 + r8]           ; 4b 0f bf 44 05 00                    
   484 : movsx        r8, word ptr [r13 + r8]            ; 4f 0f bf 44 05 00                    
   485 : movzx        rax, byte ptr [rax + rax]          ; 48 0f b6 04 00                       
   486 : movzx        rdi, byte ptr [rax + rax]          ; 48 0f b6 3c 00                       
   487 : movzx        rax, byte ptr [rdi + rax]          ; 48 0f b6 04 07                       
   488 : movzx        rax, byte ptr [rax + rdi]          ; 48 0f b6 04 38                       
   489 : movzx        r8, byte ptr [rax + rax]           ; 4c 0f b6 04 00                       
   490 : movzx        rax, byte ptr [r8 + rax]           ; 49 0f b6 04 00                       
   491 : movzx        r8, byte ptr [r8 + rax]            ; 4d 0f b6 04 00                       
   492 : movzx        rax, byte ptr [r13 + rax]          ; 49 0f b6 44 05 00                    
   493 : movzx        r8, byte ptr [r13 + rax]           ; 4d 0f b6 44 05 00                    
   494 : movzx        rax, byte ptr [rax + r8]           ; 4a 0f b6 04 00                       
   495 : movzx        r8, byte ptr [rax + r8]            ; 4e 0f b6 04 00                       
   496 : movzx        rax, byte ptr [r8 + r8]            ; 4b 0f b6 04 00                       
   497 : movzx        r8, byte ptr [r8 + r8]             ; 4f 0f b6 04 00                       
   498 : movzx        rax, byte ptr [r13 + r8]           ; 4b 0f b6 44 05 00                    
   499 : movzx        r8, byte ptr [r13 + r8]            ; 4f 0f b6 44 05 00                    
   500 : movsx        rax, byte ptr [rax + rax]          ; 48 0f be 04 00                       
   501 : movsx        rdi, byte ptr [rax + rax]          ; 48 0f be 3c 00                       
   502 : movsx        rax, byte ptr [rdi + rax]          ; 48 0f be 04 07                       
   503 : movsx        rax, byte ptr [rax + rdi]          ; 48 0f be 04 38                       
   504 : movsx        r8, byte ptr [rax + rax]           ; 4c 0f be 04 00                       
   505 : movsx        rax, byte ptr [r8 + rax]           ; 49 0f be 04 00                       
   506 : movsx        r8, byte ptr [r8 + rax]            ; 4d 0f be 04 00                       
   507 : movsx        rax, byte ptr [r13 + rax]          ; 49 0f be 44 05 00                    
   508 : movsx        r8, byte ptr [r13 + rax]           ; 4d 0f be 44 05 00                    
   509 : movsx        rax, byte ptr [rax + r8]           ; 4a 0f be 04 00                       
   510 : movsx        r8, byte ptr [rax + r8]            ; 4e 0f be 04 00                       
   511 : movsx        rax, byte ptr [r8 + r8]            ; 4b 0f be 04 00                       
   512 : movsx        r8, byte ptr [r8 + r8]             ; 4f 0f be 04 00                       
   513 : movsx        rax, byte ptr [r13 + r8]           ; 4b 0f be 44 05 00                    
   514 : movsx        r8, byte ptr [r13 + r8]            ; 4f 0f be 44 05 00                    
   515 : xchg         rax, rax                           ; 48 90                                
   516 : xchg         rax, rdi                           ; 48 97                                
   517 : xchg         rax, r8                            ; 49 90                                
   518 : xchg         rcx, rcx                           ; 48 87 c9                             
   519 : xchg         rdi, rcx                           ; 48 87 cf                             
   520 : xchg         rcx, rdi                           ; 48 87 f9                             
   521 : xchg         rcx, rcx                           ; 48 87 c9                             
   522 : xchg         r8, rcx                            ; 49 87 c8                             
   523 : xchg         rcx, r8                            ; 4c 87 c1                             
   524 : xchg         r8, r8                             ; 4d 87 c0                             
   525 : xchg         rcx, qword ptr [rsp + 0x0100]      ; 48 87 8c 24 00 01 00 00              
   526 : xchg         rdi, qword ptr [rsp + 0x0100]      ; 48 87 bc 24 00 01 00 00              
   527 : xchg         r8, qword ptr [rsp + 0x0100]       ; 4c 87 84 24 00 01 00 00              
   528 : xchg         r15, qword ptr [rsp + 0x0100]      ; 4c 87 bc 24 00 01 00 00              
   529 : xchg         qword ptr [rsp + 0x0100], rcx      ; 48 87 8c 24 00 01 00 00              
   530 : xchg         qword ptr [rsp + 0x0100], rdi      ; 48 87 bc 24 00 01 00 00              
   531 : xchg         qword ptr [rsp + 0x0100], r8       ; 4c 87 84 24 00 01 00 00              
   532 : xchg         qword ptr [rsp + 0x0100], r15      ; 4c 87 bc 24 00 01 00 00              
   533 : shl          rax, 0x00f                         ; 48 c1 e0 0f                          
   534 : shl          rdi, 0x00f                         ; 48 c1 e7 0f                          
   535 : shl          r8, 0x00f                          ; 49 c1 e0 0f                          
   536 : shl          qword ptr [rsp + 0x0100], 0x00f    ; 48 c1 a4 24 00 01 00 00 0f           
   537 : shl          rax, cl                            ; 48 d3 e0                             
   538 : shl          rdi, cl                            ; 48 d3 e7                             
   539 : shl          r8, cl                             ; 49 d3 e0                             
   540 : shl          qword ptr [rsp + 0x0100], cl       ; 48 d3 a4 24 00 01 00 00              
   541 : shr          rax, 0x00f                         ; 48 c1 e8 0f                          
   542 : shr          rdi, 0x00f                         ; 48 c1 ef 0f                          
   543 : shr          r8, 0x00f                          ; 49 c1 e8 0f                          
   544 : shr          qword ptr [rsp + 0x0100], 0x00f    ; 48 c1 ac 24 00 01 00 00 0f           
   545 : shr          rax, cl                            ; 48 d3 e8                             
   546 : shr          rdi, cl                            ; 48 d3 ef                             
   547 : shr          r8, cl                             ; 49 d3 e8                             
   548 : shr          qword ptr [rsp + 0x0100], cl       ; 48 d3 ac 24 00 01 00 00              
   549 : sar          rax, 0x00f                         ; 48 c1 f8 0f                          
   550 : sar          rdi, 0x00f                         ; 48 c1 ff 0f                          
   551 : sar          r8, 0x00f                          ; 49 c1 f8 0f                          
   552 : sar          qword ptr [rsp + 0x0100], 0x00f    ; 48 c1 bc 24 00 01 00 00 0f           
   553 : sar          rax, cl                            ; 48 d3 f8                             
   554 : sar          rdi, cl                            ; 48 d3 ff                             
   555 : sar          r8, cl                             ; 49 d3 f8                             
   556 : sar          qword ptr [rsp + 0x0100], cl       ; 48 d3 bc 24 00 01 00 00              
   557 : and          rax, rax                           ; 48 21 c0                             
   558 : and          rax, rdi                           ; 48 21 f8                             
   559 : and          rdi, rax                           ; 48 21 c7                             
   560 : and          rax, r8                            ; 4c 21 c0                             
   561 : and          r8, rax                            ; 49 21 c0                             
   562 : and          r8, r8                             ; 4d 21 c0                             
   563 : and          rax, qword ptr [rsp + 0x0100]      ; 48 23 84 24 00 01 00 00              
   564 : and          rdi, qword ptr [rsp + 0x0100]      ; 48 23 bc 24 00 01 00 00              
   565 : and          r8, qword ptr [rsp + 0x0100]       ; 4c 23 84 24 00 01 00 00              
   566 : and          rax, 0x0100                        ; 48 25 00 01 00 00                    
   567 : and          rcx, 0x0100                        ; 48 81 e1 00 01 00 00                 
   568 : and          rdi, 0x0100                        ; 48 81 e7 00 01 00 00                 
   569 : and          r8, 0x0100                         ; 49 81 e0 00 01 00 00                 
   570 : and          qword ptr [rsp + 0x0100], rax      ; 48 21 84 24 00 01 00 00              
   571 : and          qword ptr [rsp + 0x0100], rdi      ; 48 21 bc 24 00 01 00 00              
   572 : and          qword ptr [rsp + 0x0100], r8       ; 4c 21 84 24 00 01 00 00              
   573 : and          qword ptr [rsp + 0x0100], 0x0101   ; 48 81 a4 24 00 01 00 00 01 01 00 00  
   574 : or           rax, rax                           ; 48 09 c0                             
   575 : or           rax, rdi                           ; 48 09 f8                             
   576 : or           rdi, rax                           ; 48 09 c7                             
   577 : or           rax, r8                            ; 4c 09 c0                             
   578 : or           r8, rax                            ; 49 09 c0                             
   579 : or           qword ptr [rsp + 0x0100], rax      ; 48 09 84 24 00 01 00 00              
   580 : or           qword ptr [rsp + 0x0100], r8       ; 4c 09 84 24 00 01 00 00              
   581 : or           rax, qword ptr [rsp + 0x0100]      ; 48 0b 84 24 00 01 00 00              
   582 : or           r8, qword ptr [rsp + 0x0100]       ; 4c 0b 84 24 00 01 00 00              
   583 : or           rax, 0x0100                        ; 48 0d 00 01 00 00                    
   584 : or           r8, 0x0100                         ; 49 81 c8 00 01 00 00                 
   585 : or           qword ptr [rsp + 0x0100], 0x0101   ; 48 81 8c 24 00 01 00 00 01 01 00 00  
   586 : xor          rax, rax                           ; 48 31 c0                             
   587 : xor          rax, rdi                           ; 48 31 f8                             
   588 : xor          rdi, rax                           ; 48 31 c7                             
   589 : xor          rax, r8                            ; 4c 31 c0                             
   590 : xor          r8, rax                            ; 49 31 c0                             
   591 : xor          r8, r8                             ; 4d 31 c0                             
   592 : xor          rax, qword ptr [rsp + 0x0100]      ; 48 33 84 24 00 01 00 00              
   593 : xor          rdi, qword ptr [rsp + 0x0100]      ; 48 33 bc 24 00 01 00 00              
   594 : xor          r8, qword ptr [rsp + 0x0100]       ; 4c 33 84 24 00 01 00 00              
   595 : xor          rax, 0x0100                        ; 48 35 00 01 00 00                    
   596 : xor          rcx, 0x0100                        ; 48 81 f1 00 01 00 00                 
   597 : xor          rdi, 0x0100                        ; 48 81 f7 00 01 00 00                 
   598 : xor          r8, 0x0100                         ; 49 81 f0 00 01 00 00                 
   599 : xor          qword ptr [rsp + 0x0100], rax      ; 48 31 84 24 00 01 00 00              
   600 : xor          qword ptr [rsp + 0x0100], rdi      ; 48 31 bc 24 00 01 00 00              
   601 : xor          qword ptr [rsp + 0x0100], r8       ; 4c 31 84 24 00 01 00 00              
   602 : xor          qword ptr [rsp + 0x0100], 0x0101   ; 48 81 b4 24 00 01 00 00 01 01 00 00  
   603 : cmovne       rax, rax                           ; 48 0f 45 c0                          
   604 : cmove        rax, rax                           ; 48 0f 44 c0                          
   605 : cmovl        rax, rax                           ; 48 0f 4c c0                          
   606 : cmovg        rax, rax                           ; 48 0f 4f c0                          
   607 : cmovge       rax, rax                           ; 48 0f 4d c0                          
   608 : cmova        rax, rax                           ; 48 0f 47 c0                          
   609 : cmovle       rax, rax                           ; 48 0f 4e c0                          
   610 : cmovbe       rax, rax                           ; 48 0f 46 c0                          
   611 : cmovs        rax, rax                           ; 48 0f 48 c0                          
   612 : cmovns       rax, rax                           ; 48 0f 49 c0                          
   613 : cmove        rdi, rax                           ; 48 0f 44 f8                          
   614 : cmove        rax, rdi                           ; 48 0f 44 c7                          
   615 : cmove        r8, rax                            ; 4c 0f 44 c0                          
   616 : cmove        rax, r8                            ; 49 0f 44 c0                          
   617 : cmove        r8, r8                             ; 4d 0f 44 c0                          
   618 : cmove        rax, qword ptr [rsp + 0x0100]      ; 48 0f 44 84 24 00 01 00 00           
   619 : cmove        rdi, qword ptr [rsp + 0x0100]      ; 48 0f 44 bc 24 00 01 00 00           
   620 : cmove        r8, qword ptr [rsp + 0x0100]       ; 4c 0f 44 84 24 00 01 00 00           
   621 : setne        al                                 ; 0f 95 c0                             
   622 : sete         al                                 ; 0f 94 c0                             
   623 : setl         al                                 ; 0f 9c c0                             
   624 : setg         al                                 ; 0f 9f c0                             
   625 : setge        al                                 ; 0f 9d c0                             
   626 : seta         al                                 ; 0f 97 c0                             
   627 : setle        al                                 ; 0f 9e c0                             
   628 : setbe        al                                 ; 0f 96 c0                             
   629 : sets         al                                 ; 0f 98 c0                             
   630 : setns        al                                 ; 0f 99 c0                             
   631 : sete         dil                                ; 40 0f 94 c7                          
   632 : sete         r8b                                ; 41 0f 94 c0                          
   633 : sete         byte ptr [rsp + 0x0100]            ; 0f 94 84 24 00 01 00 00              
   634 : adc          rax, rax                           ; 48 11 c0                             
   635 : adc          rdi, rax                           ; 48 11 c7                             
   636 : adc          rax, rdi                           ; 48 11 f8                             
   637 : adc          r8, rax                            ; 49 11 c0                             
   638 : adc          rax, r8                            ; 4c 11 c0                             
   639 : adc          r8, r8                             ; 4d 11 c0                             
   640 : adc          rax, 0x0100                        ; 48 15 00 01 00 00                    
   641 : adc          rcx, 0x0100                        ; 48 81 d1 00 01 00 00                 
   642 : adc          rdi, 0x0100                        ; 48 81 d7 00 01 00 00                 
   643 : adc          r8, 0x0100                         ; 49 81 d0 00 01 00 00                 
   644 : adc          rax, qword ptr [rsp + 0x0100]      ; 48 13 84 24 00 01 00 00              
   645 : adc          rdi, qword ptr [rsp + 0x0100]      ; 48 13 bc 24 00 01 00 00              
   646 : adc          r8, qword ptr [rsp + 0x0100]       ; 4c 13 84 24 00 01 00 00              
   647 : adc          qword ptr [rsp + 0x0100], rax      ; 48 11 84 24 00 01 00 00              
   648 : adc          qword ptr [rsp + 0x0100], rdi      ; 48 11 bc 24 00 01 00 00              
   649 : adc          qword ptr [rsp + 0x0100], r8       ; 4c 11 84 24 00 01 00 00              
   650 : adc          qword ptr [rsp + 0x0100], 0x0100   ; 48 81 94 24 00 01 00 00 00 01 00 00  
   651 : cmp          rax, qword ptr [rsp + 0x0fff8]     ; 48 3b 84 24 f8 ff 00 00              
   652 : cmp          rdi, qword ptr [rsp + 0x0fff8]     ; 48 3b bc 24 f8 ff 00 00              
   653 : cmp          r8, qword ptr [rsp + 0x0fff8]      ; 4c 3b 84 24 f8 ff 00 00              
   654 : cmp          r15, qword ptr [rsp + 0x0fff8]     ; 4c 3b bc 24 f8 ff 00 00              
   655 : cmp          qword ptr [rsp + 0x0fff8], rax     ; 48 39 84 24 f8 ff 00 00              
   656 : cmp          qword ptr [rsp + 0x0fff8], rdi     ; 48 39 bc 24 f8 ff 00 00              
   657 : cmp          qword ptr [rsp + 0x0fff8], r8      ; 4c 39 84 24 f8 ff 00 00              
   658 : cmp          qword ptr [rsp + 0x0fff8], r15     ; 4c 39 bc 24 f8 ff 00 00              
   659 : cmp          qword ptr [rsp + 0x0fff8], 0x08888 ; 48 81 bc 24 f8 ff 00 00 88 88 00 00  
   660 : vmovdqu      ymm0, ymm0                         ; c5 fe 6f c0                          
   661 : vmovdqu      ymm7, ymm0                         ; c5 fe 6f f8                          
   662 : vmovdqu      ymm0, ymm7                         ; c5 fe 6f c7                          
   663 : vmovdqu      ymm8, ymm0                         ; c5 7e 6f c0                          
   664 : vmovdqu      ymm15, ymm0                        ; c5 7e 6f f8                          
   665 : vmovdqu      ymm8, ymm7                         ; c5 7e 6f c7                          
   666 : vmovdqu      ymm0, ymm8                         ; c4 c1 7e 6f c0                       
   667 : vmovdqu      ymm7, ymm8                         ; c4 c1 7e 6f f8                       
   668 : vmovdqu      ymm0, ymm15                        ; c4 c1 7e 6f c7                       
   669 : vmovdqu      ymm8, ymm8                         ; c4 41 7e 6f c0                       
   670 : vmovdqu      ymm15, ymm8                        ; c4 41 7e 6f f8                       
   671 : vmovdqu      ymm8, ymm15                        ; c4 41 7e 6f c7                       
   672 : vmovups      ymm0, ymm0                         ; c5 fc 10 c0                          
   673 : vmovups      ymm7, ymm0                         ; c5 fc 10 f8                          
   674 : vmovups      ymm0, ymm7                         ; c5 fc 10 c7                          
   675 : vmovups      ymm8, ymm0                         ; c5 7c 10 c0                          
   676 : vmovups      ymm15, ymm0                        ; c5 7c 10 f8                          
   677 : vmovups      ymm8, ymm7                         ; c5 7c 10 c7                          
   678 : vmovups      ymm0, ymm8                         ; c4 c1 7c 10 c0                       
   679 : vmovups      ymm7, ymm8                         ; c4 c1 7c 10 f8                       
   680 : vmovups      ymm0, ymm15                        ; c4 c1 7c 10 c7                       
   681 : vmovups      ymm8, ymm8                         ; c4 41 7c 10 c0                       
   682 : vmovups      ymm15, ymm8                        ; c4 41 7c 10 f8                       
   683 : vmovups      ymm8, ymm15                        ; c4 41 7c 10 c7                       
   684 : vmovupd      ymm0, ymm0                         ; c5 fd 10 c0                          
   685 : vmovupd      ymm7, ymm0                         ; c5 fd 10 f8                          
   686 : vmovupd      ymm0, ymm7                         ; c5 fd 10 c7                          
   687 : vmovupd      ymm8, ymm0                         ; c5 7d 10 c0                          
   688 : vmovupd      ymm15, ymm0                        ; c5 7d 10 f8                          
   689 : vmovupd      ymm8, ymm7                         ; c5 7d 10 c7                          
   690 : vmovupd      ymm0, ymm8                         ; c4 c1 7d 10 c0                       
   691 : vmovupd      ymm7, ymm8                         ; c4 c1 7d 10 f8                       
   692 : vmovupd      ymm0, ymm15                        ; c4 c1 7d 10 c7                       
   693 : vmovupd      ymm8, ymm8                         ; c4 41 7d 10 c0                       
   694 : vmovupd      ymm15, ymm8                        ; c4 41 7d 10 f8                       
   695 : vmovupd      ymm8, ymm15                        ; c4 41 7d 10 c7                       
   696 : vmovdqu      ymm0, ymmword ptr [rax]            ; c5 fe 6f 00                          
   697 : vmovdqu      ymm7, ymmword ptr [rax]            ; c5 fe 6f 38                          
   698 : vmovdqu      ymm0, ymmword ptr [rsp]            ; c5 fe 6f 04 24                       
   699 : vmovdqu      ymm0, ymmword ptr [rbp]            ; c5 fe 6f 45 00                       
   700 : vmovdqu      ymm0, ymmword ptr [rdi]            ; c5 fe 6f 07                          
   701 : vmovdqu      ymm8, ymmword ptr [rax]            ; c5 7e 6f 00                          
   702 : vmovdqu      ymm15, ymmword ptr [rax]           ; c5 7e 6f 38                          
   703 : vmovdqu      ymm8, ymmword ptr [rsp]            ; c5 7e 6f 04 24                       
   704 : vmovdqu      ymm8, ymmword ptr [rbp]            ; c5 7e 6f 45 00                       
   705 : vmovdqu      ymm8, ymmword ptr [rdi]            ; c5 7e 6f 07                          
   706 : vmovdqu      ymm0, ymmword ptr [r8]             ; c4 c1 7e 6f 00                       
   707 : vmovdqu      ymm7, ymmword ptr [r8]             ; c4 c1 7e 6f 38                       
   708 : vmovdqu      ymm0, ymmword ptr [r12]            ; c4 c1 7e 6f 04 24                    
   709 : vmovdqu      ymm0, ymmword ptr [r13]            ; c4 c1 7e 6f 45 00                    
   710 : vmovdqu      ymm0, ymmword ptr [r15]            ; c4 c1 7e 6f 07                       
   711 : vmovdqu      ymm8, ymmword ptr [r8]             ; c4 41 7e 6f 00                       
   712 : vmovdqu      ymm15, ymmword ptr [r8]            ; c4 41 7e 6f 38                       
   713 : vmovdqu      ymm8, ymmword ptr [r12]            ; c4 41 7e 6f 04 24                    
   714 : vmovdqu      ymm8, ymmword ptr [r13]            ; c4 41 7e 6f 45 00                    
   715 : vmovdqu      ymm8, ymmword ptr [r15]            ; c4 41 7e 6f 07                       
   716 : vmovups      ymm0, ymmword ptr [rax]            ; c5 fc 10 00                          
   717 : vmovups      ymm7, ymmword ptr [rax]            ; c5 fc 10 38                          
   718 : vmovups      ymm0, ymmword ptr [rsp]            ; c5 fc 10 04 24                       
   719 : vmovups      ymm0, ymmword ptr [rbp]            ; c5 fc 10 45 00                       
   720 : vmovups      ymm0, ymmword ptr [rdi]            ; c5 fc 10 07                          
   721 : vmovups      ymm8, ymmword ptr [rax]            ; c5 7c 10 00                          
   722 : vmovups      ymm15, ymmword ptr [rax]           ; c5 7c 10 38                          
   723 : vmovups      ymm8, ymmword ptr [rsp]            ; c5 7c 10 04 24                       
   724 : vmovups      ymm8, ymmword ptr [rbp]            ; c5 7c 10 45 00                       
   725 : vmovups      ymm8, ymmword ptr [rdi]            ; c5 7c 10 07                          
   726 : vmovups      ymm0, ymmword ptr [r8]             ; c4 c1 7c 10 00                       
   727 : vmovups      ymm7, ymmword ptr [r8]             ; c4 c1 7c 10 38                       
   728 : vmovups      ymm0, ymmword ptr [r12]            ; c4 c1 7c 10 04 24                    
   729 : vmovups      ymm0, ymmword ptr [r13]            ; c4 c1 7c 10 45 00                    
   730 : vmovups      ymm0, ymmword ptr [r15]            ; c4 c1 7c 10 07                       
   731 : vmovups      ymm8, ymmword ptr [r8]             ; c4 41 7c 10 00                       
   732 : vmovups      ymm15, ymmword ptr [r8]            ; c4 41 7c 10 38                       
   733 : vmovups      ymm8, ymmword ptr [r12]            ; c4 41 7c 10 04 24                    
   734 : vmovups      ymm8, ymmword ptr [r13]            ; c4 41 7c 10 45 00                    
   735 : vmovups      ymm8, ymmword ptr [r15]            ; c4 41 7c 10 07                       
   736 : vmovupd      ymm0, ymmword ptr [rax]            ; c5 fd 10 00                          
   737 : vmovupd      ymm7, ymmword ptr [rax]            ; c5 fd 10 38                          
   738 : vmovupd      ymm0, ymmword ptr [rsp]            ; c5 fd 10 04 24                       
   739 : vmovupd      ymm0, ymmword ptr [rbp]            ; c5 fd 10 45 00                       
   740 : vmovupd      ymm0, ymmword ptr [rdi]            ; c5 fd 10 07                          
   741 : vmovupd      ymm8, ymmword ptr [rax]            ; c5 7d 10 00                          
   742 : vmovupd      ymm15, ymmword ptr [rax]           ; c5 7d 10 38                          
   743 : vmovupd      ymm8, ymmword ptr [rsp]            ; c5 7d 10 04 24                       
   744 : vmovupd      ymm8, ymmword ptr [rbp]            ; c5 7d 10 45 00                       
   745 : vmovupd      ymm8, ymmword ptr [rdi]            ; c5 7d 10 07                          
   746 : vmovupd      ymm0, ymmword ptr [r8]             ; c4 c1 7d 10 00                       
   747 : vmovupd      ymm7, ymmword ptr [r8]             ; c4 c1 7d 10 38                       
   748 : vmovupd      ymm0, ymmword ptr [r12]            ; c4 c1 7d 10 04 24                    
   749 : vmovupd      ymm0, ymmword ptr [r13]            ; c4 c1 7d 10 45 00                    
   750 : vmovupd      ymm0, ymmword ptr [r15]            ; c4 c1 7d 10 07                       
   751 : vmovupd      ymm8, ymmword ptr [r8]             ; c4 41 7d 10 00                       
   752 : vmovupd      ymm15, ymmword ptr [r8]            ; c4 41 7d 10 38                       
   753 : vmovupd      ymm8, ymmword ptr [r12]            ; c4 41 7d 10 04 24                    
   754 : vmovupd      ymm8, ymmword ptr [r13]            ; c4 41 7d 10 45 00                    
   755 : vmovupd      ymm8, ymmword ptr [r15]            ; c4 41 7d 10 07                       
   756 : vmovdqu      ymm0, ymmword ptr [rax + rax]      ; c5 fe 6f 04 00                       
   757 : vmovdqu      ymm7, ymmword ptr [rax + rax]      ; c5 fe 6f 3c 00                       
   758 : vmovdqu      ymm0, ymmword ptr [rbp + rax]      ; c5 fe 6f 44 05 00                    
   759 : vmovdqu      ymm0, ymmword ptr [rdi + rax]      ; c5 fe 6f 04 07                       
   760 : vmovdqu      ymm0, ymmword ptr [rax + rbp]      ; c5 fe 6f 04 28                       
   761 : vmovdqu      ymm0, ymmword ptr [rax + rdi]      ; c5 fe 6f 04 38                       
   762 : vmovdqu      ymm8, ymmword ptr [rax + rax]      ; c5 7e 6f 04 00                       
   763 : vmovdqu      ymm15, ymmword ptr [rax + rax]     ; c5 7e 6f 3c 00                       
   764 : vmovdqu      ymm8, ymmword ptr [rbp + rax]      ; c5 7e 6f 44 05 00                    
   765 : vmovdqu      ymm8, ymmword ptr [rdi + rax]      ; c5 7e 6f 04 07                       
   766 : vmovdqu      ymm8, ymmword ptr [rax + rbp]      ; c5 7e 6f 04 28                       
   767 : vmovdqu      ymm8, ymmword ptr [rax + rdi]      ; c5 7e 6f 04 38                       
   768 : vmovdqu      ymm0, ymmword ptr [r8 + rax]       ; c4 c1 7e 6f 04 00                    
   769 : vmovdqu      ymm7, ymmword ptr [r8 + rax]       ; c4 c1 7e 6f 3c 00                    
   770 : vmovdqu      ymm0, ymmword ptr [r13 + rax]      ; c4 c1 7e 6f 44 05 00                 
   771 : vmovdqu      ymm0, ymmword ptr [r15 + rax]      ; c4 c1 7e 6f 04 07                    
   772 : vmovdqu      ymm0, ymmword ptr [rax + rbp]      ; c5 fe 6f 04 28                       
   773 : vmovdqu      ymm0, ymmword ptr [rax + rdi]      ; c5 fe 6f 04 38                       
   774 : vmovdqu      ymm0, ymmword ptr [rax + r8]       ; c4 a1 7e 6f 04 00                    
   775 : vmovdqu      ymm7, ymmword ptr [rax + r8]       ; c4 a1 7e 6f 3c 00                    
   776 : vmovdqu      ymm0, ymmword ptr [rbp + r8]       ; c4 a1 7e 6f 44 05 00                 
   777 : vmovdqu      ymm0, ymmword ptr [rdi + r8]       ; c4 a1 7e 6f 04 07                    
   778 : vmovdqu      ymm0, ymmword ptr [rax + r13]      ; c4 a1 7e 6f 04 28                    
   779 : vmovdqu      ymm0, ymmword ptr [rax + r15]      ; c4 a1 7e 6f 04 38                    
   780 : vmovdqu      ymm8, ymmword ptr [r8 + rax]       ; c4 41 7e 6f 04 00                    
   781 : vmovdqu      ymm15, ymmword ptr [r8 + rax]      ; c4 41 7e 6f 3c 00                    
   782 : vmovdqu      ymm8, ymmword ptr [r13 + rax]      ; c4 41 7e 6f 44 05 00                 
   783 : vmovdqu      ymm8, ymmword ptr [r15 + rax]      ; c4 41 7e 6f 04 07                    
   784 : vmovdqu      ymm8, ymmword ptr [r8 + rbp]       ; c4 41 7e 6f 04 28                    
   785 : vmovdqu      ymm8, ymmword ptr [r8 + rdi]       ; c4 41 7e 6f 04 38                    
   786 : vmovdqu      ymm8, ymmword ptr [rax + r8]       ; c4 21 7e 6f 04 00                    
   787 : vmovdqu      ymm15, ymmword ptr [rax + r8]      ; c4 21 7e 6f 3c 00                    
   788 : vmovdqu      ymm8, ymmword ptr [rbp + r8]       ; c4 21 7e 6f 44 05 00                 
   789 : vmovdqu      ymm8, ymmword ptr [rdi + r8]       ; c4 21 7e 6f 04 07                    
   790 : vmovdqu      ymm8, ymmword ptr [rax + r13]      ; c4 21 7e 6f 04 28                    
   791 : vmovdqu      ymm8, ymmword ptr [rax + r15]      ; c4 21 7e 6f 04 38                    
   792 : vmovdqu      ymm0, ymmword ptr [r8 + r8]        ; c4 81 7e 6f 04 00                    
   793 : vmovdqu      ymm7, ymmword ptr [r8 + r8]        ; c4 81 7e 6f 3c 00                    
   794 : vmovdqu      ymm0, ymmword ptr [r13 + r8]       ; c4 81 7e 6f 44 05 00                 
   795 : vmovdqu      ymm0, ymmword ptr [r15 + r8]       ; c4 81 7e 6f 04 07                    
   796 : vmovdqu      ymm0, ymmword ptr [rax + r13]      ; c4 a1 7e 6f 04 28                    
   797 : vmovdqu      ymm0, ymmword ptr [rax + r15]      ; c4 a1 7e 6f 04 38                    
   798 : vmovdqu      ymm8, ymmword ptr [r8 + r8]        ; c4 01 7e 6f 04 00                    
   799 : vmovdqu      ymm15, ymmword ptr [r8 + r8]       ; c4 01 7e 6f 3c 00                    
   800 : vmovdqu      ymm8, ymmword ptr [r13 + r8]       ; c4 01 7e 6f 44 05 00                 
   801 : vmovdqu      ymm8, ymmword ptr [r15 + r8]       ; c4 01 7e 6f 04 07                    
   802 : vmovdqu      ymm8, ymmword ptr [r8 + r13]       ; c4 01 7e 6f 04 28                    
   803 : vmovdqu      ymm8, ymmword ptr [r8 + r15]       ; c4 01 7e 6f 04 38                    
   804 : vmovups      ymm0, ymmword ptr [rax + rax]      ; c5 fc 10 04 00                       
   805 : vmovups      ymm7, ymmword ptr [rax + rax]      ; c5 fc 10 3c 00                       
   806 : vmovups      ymm0, ymmword ptr [rbp + rax]      ; c5 fc 10 44 05 00                    
   807 : vmovups      ymm0, ymmword ptr [rdi + rax]      ; c5 fc 10 04 07                       
   808 : vmovups      ymm0, ymmword ptr [rax + rbp]      ; c5 fc 10 04 28                       
   809 : vmovups      ymm0, ymmword ptr [rax + rdi]      ; c5 fc 10 04 38                       
   810 : vmovups      ymm8, ymmword ptr [rax + rax]      ; c5 7c 10 04 00                       
   811 : vmovups      ymm15, ymmword ptr [rax + rax]     ; c5 7c 10 3c 00                       
   812 : vmovups      ymm8, ymmword ptr [rbp + rax]      ; c5 7c 10 44 05 00                    
   813 : vmovups      ymm8, ymmword ptr [rdi + rax]      ; c5 7c 10 04 07                       
   814 : vmovups      ymm8, ymmword ptr [rax + rbp]      ; c5 7c 10 04 28                       
   815 : vmovups      ymm8, ymmword ptr [rax + rdi]      ; c5 7c 10 04 38                       
   816 : vmovups      ymm0, ymmword ptr [r8 + rax]       ; c4 c1 7c 10 04 00                    
   817 : vmovups      ymm7, ymmword ptr [r8 + rax]       ; c4 c1 7c 10 3c 00                    
   818 : vmovups      ymm0, ymmword ptr [r13 + rax]      ; c4 c1 7c 10 44 05 00                 
   819 : vmovups      ymm0, ymmword ptr [r15 + rax]      ; c4 c1 7c 10 04 07                    
   820 : vmovups      ymm0, ymmword ptr [rax + rbp]      ; c5 fc 10 04 28                       
   821 : vmovups      ymm0, ymmword ptr [rax + rdi]      ; c5 fc 10 04 38                       
   822 : vmovups      ymm0, ymmword ptr [rax + r8]       ; c4 a1 7c 10 04 00                    
   823 : vmovups      ymm7, ymmword ptr [rax + r8]       ; c4 a1 7c 10 3c 00                    
   824 : vmovups      ymm0, ymmword ptr [rbp + r8]       ; c4 a1 7c 10 44 05 00                 
   825 : vmovups      ymm0, ymmword ptr [rdi + r8]       ; c4 a1 7c 10 04 07                    
   826 : vmovups      ymm0, ymmword ptr [rax + r13]      ; c4 a1 7c 10 04 28                    
   827 : vmovups      ymm0, ymmword ptr [rax + r15]      ; c4 a1 7c 10 04 38                    
   828 : vmovups      ymm8, ymmword ptr [r8 + rax]       ; c4 41 7c 10 04 00                    
   829 : vmovups      ymm15, ymmword ptr [r8 + rax]      ; c4 41 7c 10 3c 00                    
   830 : vmovups      ymm8, ymmword ptr [r13 + rax]      ; c4 41 7c 10 44 05 00                 
   831 : vmovups      ymm8, ymmword ptr [r15 + rax]      ; c4 41 7c 10 04 07                    
   832 : vmovups      ymm8, ymmword ptr [r8 + rbp]       ; c4 41 7c 10 04 28                    
   833 : vmovups      ymm8, ymmword ptr [r8 + rdi]       ; c4 41 7c 10 04 38                    
   834 : vmovups      ymm8, ymmword ptr [rax + r8]       ; c4 21 7c 10 04 00                    
   835 : vmovups      ymm15, ymmword ptr [rax + r8]      ; c4 21 7c 10 3c 00                    
   836 : vmovups      ymm8, ymmword ptr [rbp + r8]       ; c4 21 7c 10 44 05 00                 
   837 : vmovups      ymm8, ymmword ptr [rdi + r8]       ; c4 21 7c 10 04 07                    
   838 : vmovups      ymm8, ymmword ptr [rax + r13]      ; c4 21 7c 10 04 28                    
   839 : vmovups      ymm8, ymmword ptr [rax + r15]      ; c4 21 7c 10 04 38                    
   840 : vmovups      ymm0, ymmword ptr [r8 + r8]        ; c4 81 7c 10 04 00                    
   841 : vmovups      ymm7, ymmword ptr [r8 + r8]        ; c4 81 7c 10 3c 00                    
   842 : vmovups      ymm0, ymmword ptr [r13 + r8]       ; c4 81 7c 10 44 05 00                 
   843 : vmovups      ymm0, ymmword ptr [r15 + r8]       ; c4 81 7c 10 04 07                    
   844 : vmovups      ymm0, ymmword ptr [rax + r13]      ; c4 a1 7c 10 04 28                    
   845 : vmovups      ymm0, ymmword ptr [rax + r15]      ; c4 a1 7c 10 04 38                    
   846 : vmovups      ymm8, ymmword ptr [r8 + r8]        ; c4 01 7c 10 04 00                    
   847 : vmovups      ymm15, ymmword ptr [r8 + r8]       ; c4 01 7c 10 3c 00                    
   848 : vmovups      ymm8, ymmword ptr [r13 + r8]       ; c4 01 7c 10 44 05 00                 
   849 : vmovups      ymm8, ymmword ptr [r15 + r8]       ; c4 01 7c 10 04 07                    
   850 : vmovups      ymm8, ymmword ptr [r8 + r13]       ; c4 01 7c 10 04 28                    
   851 : vmovups      ymm8, ymmword ptr [r8 + r15]       ; c4 01 7c 10 04 38                    
   852 : vmovupd      ymm0, ymmword ptr [rax + rax]      ; c5 fd 10 04 00                       
   853 : vmovupd      ymm7, ymmword ptr [rax + rax]      ; c5 fd 10 3c 00                       
   854 : vmovupd      ymm0, ymmword ptr [rbp + rax]      ; c5 fd 10 44 05 00                    
   855 : vmovupd      ymm0, ymmword ptr [rdi + rax]      ; c5 fd 10 04 07                       
   856 : vmovupd      ymm0, ymmword ptr [rax + rbp]      ; c5 fd 10 04 28                       
   857 : vmovupd      ymm0, ymmword ptr [rax + rdi]      ; c5 fd 10 04 38                       
   858 : vmovupd      ymm8, ymmword ptr [rax + rax]      ; c5 7d 10 04 00                       
   859 : vmovupd      ymm15, ymmword ptr [rax + rax]     ; c5 7d 10 3c 00                       
   860 : vmovupd      ymm8, ymmword ptr [rbp + rax]      ; c5 7d 10 44 05 00                    
   861 : vmovupd      ymm8, ymmword ptr [rdi + rax]      ; c5 7d 10 04 07                       
   862 : vmovupd      ymm8, ymmword ptr [rax + rbp]      ; c5 7d 10 04 28                       
   863 : vmovupd      ymm8, ymmword ptr [rax + rdi]      ; c5 7d 10 04 38                       
   864 : vmovupd      ymm0, ymmword ptr [r8 + rax]       ; c4 c1 7d 10 04 00                    
   865 : vmovupd      ymm7, ymmword ptr [r8 + rax]       ; c4 c1 7d 10 3c 00                    
   866 : vmovupd      ymm0, ymmword ptr [r13 + rax]      ; c4 c1 7d 10 44 05 00                 
   867 : vmovupd      ymm0, ymmword ptr [r15 + rax]      ; c4 c1 7d 10 04 07                    
   868 : vmovupd      ymm0, ymmword ptr [rax + rbp]      ; c5 fd 10 04 28                       
   869 : vmovupd      ymm0, ymmword ptr [rax + rdi]      ; c5 fd 10 04 38                       
   870 : vmovupd      ymm0, ymmword ptr [rax + r8]       ; c4 a1 7d 10 04 00                    
   871 : vmovupd      ymm7, ymmword ptr [rax + r8]       ; c4 a1 7d 10 3c 00                    
   872 : vmovupd      ymm0, ymmword ptr [rbp + r8]       ; c4 a1 7d 10 44 05 00                 
   873 : vmovupd      ymm0, ymmword ptr [rdi + r8]       ; c4 a1 7d 10 04 07                    
   874 : vmovupd      ymm0, ymmword ptr [rax + r13]      ; c4 a1 7d 10 04 28                    
   875 : vmovupd      ymm0, ymmword ptr [rax + r15]      ; c4 a1 7d 10 04 38                    
   876 : vmovupd      ymm8, ymmword ptr [r8 + rax]       ; c4 41 7d 10 04 00                    
   877 : vmovupd      ymm15, ymmword ptr [r8 + rax]      ; c4 41 7d 10 3c 00                    
   878 : vmovupd      ymm8, ymmword ptr [r13 + rax]      ; c4 41 7d 10 44 05 00                 
   879 : vmovupd      ymm8, ymmword ptr [r15 + rax]      ; c4 41 7d 10 04 07                    
   880 : vmovupd      ymm8, ymmword ptr [r8 + rbp]       ; c4 41 7d 10 04 28                    
   881 : vmovupd      ymm8, ymmword ptr [r8 + rdi]       ; c4 41 7d 10 04 38                    
   882 : vmovupd      ymm8, ymmword ptr [rax + r8]       ; c4 21 7d 10 04 00                    
   883 : vmovupd      ymm15, ymmword ptr [rax + r8]      ; c4 21 7d 10 3c 00                    
   884 : vmovupd      ymm8, ymmword ptr [rbp + r8]       ; c4 21 7d 10 44 05 00                 
   885 : vmovupd      ymm8, ymmword ptr [rdi + r8]       ; c4 21 7d 10 04 07                    
   886 : vmovupd      ymm8, ymmword ptr [rax + r13]      ; c4 21 7d 10 04 28                    
   887 : vmovupd      ymm8, ymmword ptr [rax + r15]      ; c4 21 7d 10 04 38                    
   888 : vmovupd      ymm0, ymmword ptr [r8 + r8]        ; c4 81 7d 10 04 00                    
   889 : vmovupd      ymm7, ymmword ptr [r8 + r8]        ; c4 81 7d 10 3c 00                    
   890 : vmovupd      ymm0, ymmword ptr [r13 + r8]       ; c4 81 7d 10 44 05 00                 
   891 : vmovupd      ymm0, ymmword ptr [r15 + r8]       ; c4 81 7d 10 04 07                    
   892 : vmovupd      ymm0, ymmword ptr [rax + r13]      ; c4 a1 7d 10 04 28                    
   893 : vmovupd      ymm0, ymmword ptr [rax + r15]      ; c4 a1 7d 10 04 38                    
   894 : vmovupd      ymm8, ymmword ptr [r8 + r8]        ; c4 01 7d 10 04 00                    
   895 : vmovupd      ymm15, ymmword ptr [r8 + r8]       ; c4 01 7d 10 3c 00                    
   896 : vmovupd      ymm8, ymmword ptr [r13 + r8]       ; c4 01 7d 10 44 05 00                 
   897 : vmovupd      ymm8, ymmword ptr [r15 + r8]       ; c4 01 7d 10 04 07                    
   898 : vmovupd      ymm8, ymmword ptr [r8 + r13]       ; c4 01 7d 10 04 28                    
   899 : vmovupd      ymm8, ymmword ptr [r8 + r15]       ; c4 01 7d 10 04 38                    
   900 : vmovdqu      ymm0, ymmword ptr [rax + 0x0100]   ; c5 fe 6f 80 00 01 00 00              
   901 : vmovdqu      ymm7, ymmword ptr [rax + 0x0100]   ; c5 fe 6f b8 00 01 00 00              
   902 : vmovdqu      ymm0, ymmword ptr [rsp + 0x0100]   ; c5 fe 6f 84 24 00 01 00 00           
   903 : vmovdqu      ymm0, ymmword ptr [rdi + 0x0100]   ; c5 fe 6f 87 00 01 00 00              
   904 : vmovdqu      ymm8, ymmword ptr [rax + 0x0100]   ; c5 7e 6f 80 00 01 00 00              
   905 : vmovdqu      ymm15, ymmword ptr [rax + 0x0100]  ; c5 7e 6f b8 00 01 00 00              
   906 : vmovdqu      ymm8, ymmword ptr [rsp + 0x0100]   ; c5 7e 6f 84 24 00 01 00 00           
   907 : vmovdqu      ymm8, ymmword ptr [rdi + 0x0100]   ; c5 7e 6f 87 00 01 00 00              
   908 : vmovdqu      ymm0, ymmword ptr [r8 + 0x0100]    ; c4 c1 7e 6f 80 00 01 00 00           
   909 : vmovdqu      ymm7, ymmword ptr [r8 + 0x0100]    ; c4 c1 7e 6f b8 00 01 00 00           
   910 : vmovdqu      ymm0, ymmword ptr [r12 + 0x0100]   ; c4 c1 7e 6f 84 24 00 01 00 00        
   911 : vmovdqu      ymm0, ymmword ptr [r15 + 0x0100]   ; c4 c1 7e 6f 87 00 01 00 00           
   912 : vmovdqu      ymm8, ymmword ptr [r8 + 0x0100]    ; c4 41 7e 6f 80 00 01 00 00           
   913 : vmovdqu      ymm15, ymmword ptr [r8 + 0x0100]   ; c4 41 7e 6f b8 00 01 00 00           
   914 : vmovdqu      ymm8, ymmword ptr [r12 + 0x0100]   ; c4 41 7e 6f 84 24 00 01 00 00        
   915 : vmovdqu      ymm8, ymmword ptr [r15 + 0x0100]   ; c4 41 7e 6f 87 00 01 00 00           
   916 : vmovups      ymm0, ymmword ptr [rax + 0x0100]   ; c5 fc 10 80 00 01 00 00              
   917 : vmovups      ymm7, ymmword ptr [rax + 0x0100]   ; c5 fc 10 b8 00 01 00 00              
   918 : vmovups      ymm0, ymmword ptr [rsp + 0x0100]   ; c5 fc 10 84 24 00 01 00 00           
   919 : vmovups      ymm0, ymmword ptr [rdi + 0x0100]   ; c5 fc 10 87 00 01 00 00              
   920 : vmovups      ymm8, ymmword ptr [rax + 0x0100]   ; c5 7c 10 80 00 01 00 00              
   921 : vmovups      ymm15, ymmword ptr [rax + 0x0100]  ; c5 7c 10 b8 00 01 00 00              
   922 : vmovups      ymm8, ymmword ptr [rsp + 0x0100]   ; c5 7c 10 84 24 00 01 00 00           
   923 : vmovups      ymm8, ymmword ptr [rdi + 0x0100]   ; c5 7c 10 87 00 01 00 00              
   924 : vmovups      ymm0, ymmword ptr [r8 + 0x0100]    ; c4 c1 7c 10 80 00 01 00 00           
   925 : vmovups      ymm7, ymmword ptr [r8 + 0x0100]    ; c4 c1 7c 10 b8 00 01 00 00           
   926 : vmovups      ymm0, ymmword ptr [r12 + 0x0100]   ; c4 c1 7c 10 84 24 00 01 00 00        
   927 : vmovups      ymm0, ymmword ptr [r15 + 0x0100]   ; c4 c1 7c 10 87 00 01 00 00           
   928 : vmovups      ymm8, ymmword ptr [r8 + 0x0100]    ; c4 41 7c 10 80 00 01 00 00           
   929 : vmovups      ymm15, ymmword ptr [r8 + 0x0100]   ; c4 41 7c 10 b8 00 01 00 00           
   930 : vmovups      ymm8, ymmword ptr [r12 + 0x0100]   ; c4 41 7c 10 84 24 00 01 00 00        
   931 : vmovups      ymm8, ymmword ptr [r15 + 0x0100]   ; c4 41 7c 10 87 00 01 00 00           
   932 : vmovupd      ymm0, ymmword ptr [rax + 0x0100]   ; c5 fd 10 80 00 01 00 00              
   933 : vmovupd      ymm7, ymmword ptr [rax + 0x0100]   ; c5 fd 10 b8 00 01 00 00              
   934 : vmovupd      ymm0, ymmword ptr [rsp + 0x0100]   ; c5 fd 10 84 24 00 01 00 00           
   935 : vmovupd      ymm0, ymmword ptr [rdi + 0x0100]   ; c5 fd 10 87 00 01 00 00              
   936 : vmovupd      ymm8, ymmword ptr [rax + 0x0100]   ; c5 7d 10 80 00 01 00 00              
   937 : vmovupd      ymm15, ymmword ptr [rax + 0x0100]  ; c5 7d 10 b8 00 01 00 00              
   938 : vmovupd      ymm8, ymmword ptr [rsp + 0x0100]   ; c5 7d 10 84 24 00 01 00 00           
   939 : vmovupd      ymm8, ymmword ptr [rdi + 0x0100]   ; c5 7d 10 87 00 01 00 00              
   940 : vmovupd      ymm0, ymmword ptr [r8 + 0x0100]    ; c4 c1 7d 10 80 00 01 00 00           
   941 : vmovupd      ymm7, ymmword ptr [r8 + 0x0100]    ; c4 c1 7d 10 b8 00 01 00 00           
   942 : vmovupd      ymm0, ymmword ptr [r12 + 0x0100]   ; c4 c1 7d 10 84 24 00 01 00 00        
   943 : vmovupd      ymm0, ymmword ptr [r15 + 0x0100]   ; c4 c1 7d 10 87 00 01 00 00           
   944 : vmovupd      ymm8, ymmword ptr [r8 + 0x0100]    ; c4 41 7d 10 80 00 01 00 00           
   945 : vmovupd      ymm15, ymmword ptr [r8 + 0x0100]   ; c4 41 7d 10 b8 00 01 00 00           
   946 : vmovupd      ymm8, ymmword ptr [r12 + 0x0100]   ; c4 41 7d 10 84 24 00 01 00 00        
   947 : vmovupd      ymm8, ymmword ptr [r15 + 0x0100]   ; c4 41 7d 10 87 00 01 00 00           
   948 : vmovdqu      ymmword ptr [rax], ymm0            ; c5 fe 7f 00                          
   949 : vmovdqu      ymmword ptr [rsp], ymm0            ; c5 fe 7f 04 24                       
   950 : vmovdqu      ymmword ptr [rbp], ymm0            ; c5 fe 7f 45 00                       
   951 : vmovdqu      ymmword ptr [rdi], ymm0            ; c5 fe 7f 07                          
   952 : vmovdqu      ymmword ptr [rax], ymm7            ; c5 fe 7f 38                          
   953 : vmovdqu      ymmword ptr [rax], ymm8            ; c5 7e 7f 00                          
   954 : vmovdqu      ymmword ptr [rsp], ymm8            ; c5 7e 7f 04 24                       
   955 : vmovdqu      ymmword ptr [rbp], ymm8            ; c5 7e 7f 45 00                       
   956 : vmovdqu      ymmword ptr [rdi], ymm8            ; c5 7e 7f 07                          
   957 : vmovdqu      ymmword ptr [rax], ymm15           ; c5 7e 7f 38                          
   958 : vmovdqu      ymmword ptr [r8], ymm0             ; c4 c1 7e 7f 00                       
   959 : vmovdqu      ymmword ptr [r12], ymm0            ; c4 c1 7e 7f 04 24                    
   960 : vmovdqu      ymmword ptr [r13], ymm0            ; c4 c1 7e 7f 45 00                    
   961 : vmovdqu      ymmword ptr [r15], ymm0            ; c4 c1 7e 7f 07                       
   962 : vmovdqu      ymmword ptr [r8], ymm7             ; c4 c1 7e 7f 38                       
   963 : vmovdqu      ymmword ptr [r8], ymm8             ; c4 41 7e 7f 00                       
   964 : vmovdqu      ymmword ptr [r12], ymm8            ; c4 41 7e 7f 04 24                    
   965 : vmovdqu      ymmword ptr [r13], ymm8            ; c4 41 7e 7f 45 00                    
   966 : vmovdqu      ymmword ptr [r15], ymm8            ; c4 41 7e 7f 07                       
   967 : vmovdqu      ymmword ptr [r8], ymm15            ; c4 41 7e 7f 38                       
   968 : vmovups      ymmword ptr [rax], ymm0            ; c5 fc 11 00                          
   969 : vmovups      ymmword ptr [rsp], ymm0            ; c5 fc 11 04 24                       
   970 : vmovups      ymmword ptr [rbp], ymm0            ; c5 fc 11 45 00                       
   971 : vmovups      ymmword ptr [rdi], ymm0            ; c5 fc 11 07                          
   972 : vmovups      ymmword ptr [rax], ymm7            ; c5 fc 11 38                          
   973 : vmovups      ymmword ptr [rax], ymm8            ; c5 7c 11 00                          
   974 : vmovups      ymmword ptr [rsp], ymm8            ; c5 7c 11 04 24                       
   975 : vmovups      ymmword ptr [rbp], ymm8            ; c5 7c 11 45 00                       
   976 : vmovups      ymmword ptr [rdi], ymm8            ; c5 7c 11 07                          
   977 : vmovups      ymmword ptr [rax], ymm15           ; c5 7c 11 38                          
   978 : vmovups      ymmword ptr [r8], ymm0             ; c4 c1 7c 11 00                       
   979 : vmovups      ymmword ptr [r12], ymm0            ; c4 c1 7c 11 04 24                    
   980 : vmovups      ymmword ptr [r13], ymm0            ; c4 c1 7c 11 45 00                    
   981 : vmovups      ymmword ptr [r15], ymm0            ; c4 c1 7c 11 07                       
   982 : vmovups      ymmword ptr [r8], ymm7             ; c4 c1 7c 11 38                       
   983 : vmovups      ymmword ptr [r8], ymm8             ; c4 41 7c 11 00                       
   984 : vmovups      ymmword ptr [r12], ymm8            ; c4 41 7c 11 04 24                    
   985 : vmovups      ymmword ptr [r13], ymm8            ; c4 41 7c 11 45 00                    
   986 : vmovups      ymmword ptr [r15], ymm8            ; c4 41 7c 11 07                       
   987 : vmovups      ymmword ptr [r8], ymm15            ; c4 41 7c 11 38                       
   988 : vmovupd      ymmword ptr [rax], ymm0            ; c5 fd 11 00                          
   989 : vmovupd      ymmword ptr [rsp], ymm0            ; c5 fd 11 04 24                       
   990 : vmovupd      ymmword ptr [rbp], ymm0            ; c5 fd 11 45 00                       
   991 : vmovupd      ymmword ptr [rdi], ymm0            ; c5 fd 11 07                          
   992 : vmovupd      ymmword ptr [rax], ymm7            ; c5 fd 11 38                          
   993 : vmovupd      ymmword ptr [rax], ymm8            ; c5 7d 11 00                          
   994 : vmovupd      ymmword ptr [rsp], ymm8            ; c5 7d 11 04 24                       
   995 : vmovupd      ymmword ptr [rbp], ymm8            ; c5 7d 11 45 00                       
   996 : vmovupd      ymmword ptr [rdi], ymm8            ; c5 7d 11 07                          
   997 : vmovupd      ymmword ptr [rax], ymm15           ; c5 7d 11 38                          
   998 : vmovupd      ymmword ptr [r8], ymm0             ; c4 c1 7d 11 00                       
   999 : vmovupd      ymmword ptr [r12], ymm0            ; c4 c1 7d 11 04 24                    
  1000 : vmovupd      ymmword ptr [r13], ymm0            ; c4 c1 7d 11 45 00                    
  1001 : vmovupd      ymmword ptr [r15], ymm0            ; c4 c1 7d 11 07                       
  1002 : vmovupd      ymmword ptr [r8], ymm7             ; c4 c1 7d 11 38                       
  1003 : vmovupd      ymmword ptr [r8], ymm8             ; c4 41 7d 11 00                       
  1004 : vmovupd      ymmword ptr [r12], ymm8            ; c4 41 7d 11 04 24                    
  1005 : vmovupd      ymmword ptr [r13], ymm8            ; c4 41 7d 11 45 00                    
  1006 : vmovupd      ymmword ptr [r15], ymm8            ; c4 41 7d 11 07                       
  1007 : vmovupd      ymmword ptr [r8], ymm15            ; c4 41 7d 11 38                       
  1008 : vmovdqu      ymmword ptr [rax + rax], ymm0      ; c5 fe 7f 04 00                       
  1009 : vmovdqu      ymmword ptr [rbp + rax], ymm0      ; c5 fe 7f 44 05 00                    
  1010 : vmovdqu      ymmword ptr [rdi + rax], ymm0      ; c5 fe 7f 04 07                       
  1011 : vmovdqu      ymmword ptr [rax + rdi], ymm0      ; c5 fe 7f 04 38                       
  1012 : vmovdqu      ymmword ptr [rax + rax], ymm7      ; c5 fe 7f 3c 00                       
  1013 : vmovdqu      ymmword ptr [rax + rax], ymm8      ; c5 7e 7f 04 00                       
  1014 : vmovdqu      ymmword ptr [rbp + rax], ymm8      ; c5 7e 7f 44 05 00                    
  1015 : vmovdqu      ymmword ptr [rdi + rax], ymm8      ; c5 7e 7f 04 07                       
  1016 : vmovdqu      ymmword ptr [rax + rdi], ymm8      ; c5 7e 7f 04 38                       
  1017 : vmovdqu      ymmword ptr [rax + rax], ymm15     ; c5 7e 7f 3c 00                       
  1018 : vmovdqu      ymmword ptr [r8 + rax], ymm0       ; c4 c1 7e 7f 04 00                    
  1019 : vmovdqu      ymmword ptr [r13 + rax], ymm0      ; c4 c1 7e 7f 44 05 00                 
  1020 : vmovdqu      ymmword ptr [r15 + rax], ymm0      ; c4 c1 7e 7f 04 07                    
  1021 : vmovdqu      ymmword ptr [rax + rdi], ymm0      ; c5 fe 7f 04 38                       
  1022 : vmovdqu      ymmword ptr [r8 + rax], ymm7       ; c4 c1 7e 7f 3c 00                    
  1023 : vmovdqu      ymmword ptr [rax + r8], ymm0       ; c4 a1 7e 7f 04 00                    
  1024 : vmovdqu      ymmword ptr [rbp + r8], ymm0       ; c4 a1 7e 7f 44 05 00                 
  1025 : vmovdqu      ymmword ptr [rdi + r8], ymm0       ; c4 a1 7e 7f 04 07                    
  1026 : vmovdqu      ymmword ptr [rax + r15], ymm0      ; c4 a1 7e 7f 04 38                    
  1027 : vmovdqu      ymmword ptr [rax + r8], ymm7       ; c4 a1 7e 7f 3c 00                    
  1028 : vmovdqu      ymmword ptr [r8 + rax], ymm8       ; c4 41 7e 7f 04 00                    
  1029 : vmovdqu      ymmword ptr [r13 + rax], ymm8      ; c4 41 7e 7f 44 05 00                 
  1030 : vmovdqu      ymmword ptr [r15 + rax], ymm8      ; c4 41 7e 7f 04 07                    
  1031 : vmovdqu      ymmword ptr [r8 + rdi], ymm8       ; c4 41 7e 7f 04 38                    
  1032 : vmovdqu      ymmword ptr [r8 + rax], ymm15      ; c4 41 7e 7f 3c 00                    
  1033 : vmovdqu      ymmword ptr [rax + r8], ymm8       ; c4 21 7e 7f 04 00                    
  1034 : vmovdqu      ymmword ptr [rbp + r8], ymm8       ; c4 21 7e 7f 44 05 00                 
  1035 : vmovdqu      ymmword ptr [rdi + r8], ymm8       ; c4 21 7e 7f 04 07                    
  1036 : vmovdqu      ymmword ptr [rax + r15], ymm8      ; c4 21 7e 7f 04 38                    
  1037 : vmovdqu      ymmword ptr [rax + r8], ymm15      ; c4 21 7e 7f 3c 00                    
  1038 : vmovdqu      ymmword ptr [r8 + r8], ymm0        ; c4 81 7e 7f 04 00                    
  1039 : vmovdqu      ymmword ptr [r13 + r8], ymm0       ; c4 81 7e 7f 44 05 00                 
  1040 : vmovdqu      ymmword ptr [r15 + r8], ymm0       ; c4 81 7e 7f 04 07                    
  1041 : vmovdqu      ymmword ptr [rax + r15], ymm0      ; c4 a1 7e 7f 04 38                    
  1042 : vmovdqu      ymmword ptr [r8 + r8], ymm7        ; c4 81 7e 7f 3c 00                    
  1043 : vmovdqu      ymmword ptr [r8 + r8], ymm8        ; c4 01 7e 7f 04 00                    
  1044 : vmovdqu      ymmword ptr [r13 + r8], ymm8       ; c4 01 7e 7f 44 05 00                 
  1045 : vmovdqu      ymmword ptr [r15 + r8], ymm8       ; c4 01 7e 7f 04 07                    
  1046 : vmovdqu      ymmword ptr [r8 + r15], ymm8       ; c4 01 7e 7f 04 38                    
  1047 : vmovdqu      ymmword ptr [r8 + r8], ymm15       ; c4 01 7e 7f 3c 00                    
  1048 : vmovups      ymmword ptr [rax + rax], ymm0      ; c5 fc 11 04 00                       
  1049 : vmovups      ymmword ptr [rbp + rax], ymm0      ; c5 fc 11 44 05 00                    
  1050 : vmovups      ymmword ptr [rdi + rax], ymm0      ; c5 fc 11 04 07                       
  1051 : vmovups      ymmword ptr [rax + rdi], ymm0      ; c5 fc 11 04 38                       
  1052 : vmovups      ymmword ptr [rax + rax], ymm7      ; c5 fc 11 3c 00                       
  1053 : vmovups      ymmword ptr [rax + rax], ymm8      ; c5 7c 11 04 00                       
  1054 : vmovups      ymmword ptr [rbp + rax], ymm8      ; c5 7c 11 44 05 00                    
  1055 : vmovups      ymmword ptr [rdi + rax], ymm8      ; c5 7c 11 04 07                       
  1056 : vmovups      ymmword ptr [rax + rdi], ymm8      ; c5 7c 11 04 38                       
  1057 : vmovups      ymmword ptr [rax + rax], ymm15     ; c5 7c 11 3c 00                       
  1058 : vmovups      ymmword ptr [r8 + rax], ymm0       ; c4 c1 7c 11 04 00                    
  1059 : vmovups      ymmword ptr [r13 + rax], ymm0      ; c4 c1 7c 11 44 05 00                 
  1060 : vmovups      ymmword ptr [r15 + rax], ymm0      ; c4 c1 7c 11 04 07                    
  1061 : vmovups      ymmword ptr [rax + rdi], ymm0      ; c5 fc 11 04 38                       
  1062 : vmovups      ymmword ptr [r8 + rax], ymm7       ; c4 c1 7c 11 3c 00                    
  1063 : vmovups      ymmword ptr [rax + r8], ymm0       ; c4 a1 7c 11 04 00                    
  1064 : vmovups      ymmword ptr [rbp + r8], ymm0       ; c4 a1 7c 11 44 05 00                 
  1065 : vmovups      ymmword ptr [rdi + r8], ymm0       ; c4 a1 7c 11 04 07                    
  1066 : vmovups      ymmword ptr [rax + r15], ymm0      ; c4 a1 7c 11 04 38                    
  1067 : vmovups      ymmword ptr [rax + r8], ymm7       ; c4 a1 7c 11 3c 00                    
  1068 : vmovups      ymmword ptr [r8 + rax], ymm8       ; c4 41 7c 11 04 00                    
  1069 : vmovups      ymmword ptr [r13 + rax], ymm8      ; c4 41 7c 11 44 05 00                 
  1070 : vmovups      ymmword ptr [r15 + rax], ymm8      ; c4 41 7c 11 04 07                    
  1071 : vmovups      ymmword ptr [r8 + rdi], ymm8       ; c4 41 7c 11 04 38                    
  1072 : vmovups      ymmword ptr [r8 + rax], ymm15      ; c4 41 7c 11 3c 00                    
  1073 : vmovups      ymmword ptr [rax + r8], ymm8       ; c4 21 7c 11 04 00                    
  1074 : vmovups      ymmword ptr [rbp + r8], ymm8       ; c4 21 7c 11 44 05 00                 
  1075 : vmovups      ymmword ptr [rdi + r8], ymm8       ; c4 21 7c 11 04 07                    
  1076 : vmovups      ymmword ptr [rax + r15], ymm8      ; c4 21 7c 11 04 38                    
  1077 : vmovups      ymmword ptr [rax + r8], ymm15      ; c4 21 7c 11 3c 00                    
  1078 : vmovups      ymmword ptr [r8 + r8], ymm0        ; c4 81 7c 11 04 00                    
  1079 : vmovups      ymmword ptr [r13 + r8], ymm0       ; c4 81 7c 11 44 05 00                 
  1080 : vmovups      ymmword ptr [r15 + r8], ymm0       ; c4 81 7c 11 04 07                    
  1081 : vmovups      ymmword ptr [rax + r15], ymm0      ; c4 a1 7c 11 04 38                    
  1082 : vmovups      ymmword ptr [r8 + r8], ymm7        ; c4 81 7c 11 3c 00                    
  1083 : vmovups      ymmword ptr [r8 + r8], ymm8        ; c4 01 7c 11 04 00                    
  1084 : vmovups      ymmword ptr [r13 + r8], ymm8       ; c4 01 7c 11 44 05 00                 
  1085 : vmovups      ymmword ptr [r15 + r8], ymm8       ; c4 01 7c 11 04 07                    
  1086 : vmovups      ymmword ptr [r8 + r15], ymm8       ; c4 01 7c 11 04 38                    
  1087 : vmovups      ymmword ptr [r8 + r8], ymm15       ; c4 01 7c 11 3c 00                    
  1088 : vmovupd      ymmword ptr [rax + rax], ymm0      ; c5 fd 11 04 00                       
  1089 : vmovupd      ymmword ptr [rbp + rax], ymm0      ; c5 fd 11 44 05 00                    
  1090 : vmovupd      ymmword ptr [rdi + rax], ymm0      ; c5 fd 11 04 07                       
  1091 : vmovupd      ymmword ptr [rax + rdi], ymm0      ; c5 fd 11 04 38                       
  1092 : vmovupd      ymmword ptr [rax + rax], ymm7      ; c5 fd 11 3c 00                       
  1093 : vmovupd      ymmword ptr [rax + rax], ymm8      ; c5 7d 11 04 00                       
  1094 : vmovupd      ymmword ptr [rbp + rax], ymm8      ; c5 7d 11 44 05 00                    
  1095 : vmovupd      ymmword ptr [rdi + rax], ymm8      ; c5 7d 11 04 07                       
  1096 : vmovupd      ymmword ptr [rax + rdi], ymm8      ; c5 7d 11 04 38                       
  1097 : vmovupd      ymmword ptr [rax + rax], ymm15     ; c5 7d 11 3c 00                       
  1098 : vmovupd      ymmword ptr [r8 + rax], ymm0       ; c4 c1 7d 11 04 00                    
  1099 : vmovupd      ymmword ptr [r13 + rax], ymm0      ; c4 c1 7d 11 44 05 00                 
  1100 : vmovupd      ymmword ptr [r15 + rax], ymm0      ; c4 c1 7d 11 04 07                    
  1101 : vmovupd      ymmword ptr [rax + rdi], ymm0      ; c5 fd 11 04 38                       
  1102 : vmovupd      ymmword ptr [r8 + rax], ymm7       ; c4 c1 7d 11 3c 00                    
  1103 : vmovupd      ymmword ptr [rax + r8], ymm0       ; c4 a1 7d 11 04 00                    
  1104 : vmovupd      ymmword ptr [rbp + r8], ymm0       ; c4 a1 7d 11 44 05 00                 
  1105 : vmovupd      ymmword ptr [rdi + r8], ymm0       ; c4 a1 7d 11 04 07                    
  1106 : vmovupd      ymmword ptr [rax + r15], ymm0      ; c4 a1 7d 11 04 38                    
  1107 : vmovupd      ymmword ptr [rax + r8], ymm7       ; c4 a1 7d 11 3c 00                    
  1108 : vmovupd      ymmword ptr [r8 + rax], ymm8       ; c4 41 7d 11 04 00                    
  1109 : vmovupd      ymmword ptr [r13 + rax], ymm8      ; c4 41 7d 11 44 05 00                 
  1110 : vmovupd      ymmword ptr [r15 + rax], ymm8      ; c4 41 7d 11 04 07                    
  1111 : vmovupd      ymmword ptr [r8 + rdi], ymm8       ; c4 41 7d 11 04 38                    
  1112 : vmovupd      ymmword ptr [r8 + rax], ymm15      ; c4 41 7d 11 3c 00                    
  1113 : vmovupd      ymmword ptr [rax + r8], ymm8       ; c4 21 7d 11 04 00                    
  1114 : vmovupd      ymmword ptr [rbp + r8], ymm8       ; c4 21 7d 11 44 05 00                 
  1115 : vmovupd      ymmword ptr [rdi + r8], ymm8       ; c4 21 7d 11 04 07                    
  1116 : vmovupd      ymmword ptr [rax + r15], ymm8      ; c4 21 7d 11 04 38                    
  1117 : vmovupd      ymmword ptr [rax + r8], ymm15      ; c4 21 7d 11 3c 00                    
  1118 : vmovupd      ymmword ptr [r8 + r8], ymm0        ; c4 81 7d 11 04 00                    
  1119 : vmovupd      ymmword ptr [r13 + r8], ymm0       ; c4 81 7d 11 44 05 00                 
  1120 : vmovupd      ymmword ptr [r15 + r8], ymm0       ; c4 81 7d 11 04 07                    
  1121 : vmovupd      ymmword ptr [rax + r15], ymm0      ; c4 a1 7d 11 04 38                    
  1122 : vmovupd      ymmword ptr [r8 + r8], ymm7        ; c4 81 7d 11 3c 00                    
  1123 : vmovupd      ymmword ptr [r8 + r8], ymm8        ; c4 01 7d 11 04 00                    
  1124 : vmovupd      ymmword ptr [r13 + r8], ymm8       ; c4 01 7d 11 44 05 00                 
  1125 : vmovupd      ymmword ptr [r15 + r8], ymm8       ; c4 01 7d 11 04 07                    
  1126 : vmovupd      ymmword ptr [r8 + r15], ymm8       ; c4 01 7d 11 04 38                    
  1127 : vmovupd      ymmword ptr [r8 + r8], ymm15       ; c4 01 7d 11 3c 00                    
  1128 : vmovdqu      ymmword ptr [rax + 0x0100], ymm0   ; c5 fe 7f 80 00 01 00 00              
  1129 : vmovdqu      ymmword ptr [rsp + 0x0100], ymm0   ; c5 fe 7f 84 24 00 01 00 00           
  1130 : vmovdqu      ymmword ptr [rdi + 0x0100], ymm0   ; c5 fe 7f 87 00 01 00 00              
  1131 : vmovdqu      ymmword ptr [rax + 0x0100], ymm7   ; c5 fe 7f b8 00 01 00 00              
  1132 : vmovdqu      ymmword ptr [rax + 0x0100], ymm8   ; c5 7e 7f 80 00 01 00 00              
  1133 : vmovdqu      ymmword ptr [rsp + 0x0100], ymm8   ; c5 7e 7f 84 24 00 01 00 00           
  1134 : vmovdqu      ymmword ptr [rdi + 0x0100], ymm8   ; c5 7e 7f 87 00 01 00 00              
  1135 : vmovdqu      ymmword ptr [rax + 0x0100], ymm15  ; c5 7e 7f b8 00 01 00 00              
  1136 : vmovdqu      ymmword ptr [r8 + 0x0100], ymm0    ; c4 c1 7e 7f 80 00 01 00 00           
  1137 : vmovdqu      ymmword ptr [r12 + 0x0100], ymm0   ; c4 c1 7e 7f 84 24 00 01 00 00        
  1138 : vmovdqu      ymmword ptr [r15 + 0x0100], ymm0   ; c4 c1 7e 7f 87 00 01 00 00           
  1139 : vmovdqu      ymmword ptr [r8 + 0x0100], ymm7    ; c4 c1 7e 7f b8 00 01 00 00           
  1140 : vmovdqu      ymmword ptr [r8 + 0x0100], ymm8    ; c4 41 7e 7f 80 00 01 00 00           
  1141 : vmovdqu      ymmword ptr [r12 + 0x0100], ymm8   ; c4 41 7e 7f 84 24 00 01 00 00        
  1142 : vmovdqu      ymmword ptr [r15 + 0x0100], ymm8   ; c4 41 7e 7f 87 00 01 00 00           
  1143 : vmovdqu      ymmword ptr [r8 + 0x0100], ymm15   ; c4 41 7e 7f b8 00 01 00 00           
  1144 : vmovups      ymmword ptr [rax + 0x0100], ymm0   ; c5 fc 11 80 00 01 00 00              
  1145 : vmovups      ymmword ptr [rsp + 0x0100], ymm0   ; c5 fc 11 84 24 00 01 00 00           
  1146 : vmovups      ymmword ptr [rdi + 0x0100], ymm0   ; c5 fc 11 87 00 01 00 00              
  1147 : vmovups      ymmword ptr [rax + 0x0100], ymm7   ; c5 fc 11 b8 00 01 00 00              
  1148 : vmovups      ymmword ptr [rax + 0x0100], ymm8   ; c5 7c 11 80 00 01 00 00              
  1149 : vmovups      ymmword ptr [rsp + 0x0100], ymm8   ; c5 7c 11 84 24 00 01 00 00           
  1150 : vmovups      ymmword ptr [rdi + 0x0100], ymm8   ; c5 7c 11 87 00 01 00 00              
  1151 : vmovups      ymmword ptr [rax + 0x0100], ymm15  ; c5 7c 11 b8 00 01 00 00              
  1152 : vmovups      ymmword ptr [r8 + 0x0100], ymm0    ; c4 c1 7c 11 80 00 01 00 00           
  1153 : vmovups      ymmword ptr [r12 + 0x0100], ymm0   ; c4 c1 7c 11 84 24 00 01 00 00        
  1154 : vmovups      ymmword ptr [r15 + 0x0100], ymm0   ; c4 c1 7c 11 87 00 01 00 00           
  1155 : vmovups      ymmword ptr [r8 + 0x0100], ymm7    ; c4 c1 7c 11 b8 00 01 00 00           
  1156 : vmovups      ymmword ptr [r8 + 0x0100], ymm8    ; c4 41 7c 11 80 00 01 00 00           
  1157 : vmovups      ymmword ptr [r12 + 0x0100], ymm8   ; c4 41 7c 11 84 24 00 01 00 00        
  1158 : vmovups      ymmword ptr [r15 + 0x0100], ymm8   ; c4 41 7c 11 87 00 01 00 00           
  1159 : vmovups      ymmword ptr [r8 + 0x0100], ymm15   ; c4 41 7c 11 b8 00 01 00 00           
  1160 : vmovupd      ymmword ptr [rax + 0x0100], ymm0   ; c5 fd 11 80 00 01 00 00              
  1161 : vmovupd      ymmword ptr [rsp + 0x0100], ymm0   ; c5 fd 11 84 24 00 01 00 00           
  1162 : vmovupd      ymmword ptr [rdi + 0x0100], ymm0   ; c5 fd 11 87 00 01 00 00              
  1163 : vmovupd      ymmword ptr [rax + 0x0100], ymm7   ; c5 fd 11 b8 00 01 00 00              
  1164 : vmovupd      ymmword ptr [rax + 0x0100], ymm8   ; c5 7d 11 80 00 01 00 00              
  1165 : vmovupd      ymmword ptr [rsp + 0x0100], ymm8   ; c5 7d 11 84 24 00 01 00 00           
  1166 : vmovupd      ymmword ptr [rdi + 0x0100], ymm8   ; c5 7d 11 87 00 01 00 00              
  1167 : vmovupd      ymmword ptr [rax + 0x0100], ymm15  ; c5 7d 11 b8 00 01 00 00              
  1168 : vmovupd      ymmword ptr [r8 + 0x0100], ymm0    ; c4 c1 7d 11 80 00 01 00 00           
  1169 : vmovupd      ymmword ptr [r12 + 0x0100], ymm0   ; c4 c1 7d 11 84 24 00 01 00 00        
  1170 : vmovupd      ymmword ptr [r15 + 0x0100], ymm0   ; c4 c1 7d 11 87 00 01 00 00           
  1171 : vmovupd      ymmword ptr [r8 + 0x0100], ymm7    ; c4 c1 7d 11 b8 00 01 00 00           
  1172 : vmovupd      ymmword ptr [r8 + 0x0100], ymm8    ; c4 41 7d 11 80 00 01 00 00           
  1173 : vmovupd      ymmword ptr [r12 + 0x0100], ymm8   ; c4 41 7d 11 84 24 00 01 00 00        
  1174 : vmovupd      ymmword ptr [r15 + 0x0100], ymm8   ; c4 41 7d 11 87 00 01 00 00           
  1175 : vmovupd      ymmword ptr [r8 + 0x0100], ymm15   ; c4 41 7d 11 b8 00 01 00 00           
  1176 : vpaddb       ymm0, ymm0, ymm0                   ; c5 fd fc c0                          
  1177 : vpaddb       ymm7, ymm0, ymm0                   ; c5 fd fc f8                          
  1178 : vpaddb       ymm0, ymm7, ymm0                   ; c5 c5 fc c0                          
  1179 : vpaddb       ymm0, ymm0, ymm7                   ; c5 fd fc c7                          
  1180 : vpaddb       ymm8, ymm0, ymm0                   ; c5 7d fc c0                          
  1181 : vpaddb       ymm15, ymm0, ymm0                  ; c5 7d fc f8                          
  1182 : vpaddb       ymm8, ymm7, ymm0                   ; c5 45 fc c0                          
  1183 : vpaddb       ymm8, ymm0, ymm7                   ; c5 7d fc c7                          
  1184 : vpaddb       ymm0, ymm8, ymm0                   ; c5 bd fc c0                          
  1185 : vpaddb       ymm7, ymm8, ymm0                   ; c5 bd fc f8                          
  1186 : vpaddb       ymm0, ymm15, ymm0                  ; c5 85 fc c0                          
  1187 : vpaddb       ymm0, ymm8, ymm7                   ; c5 bd fc c7                          
  1188 : vpaddb       ymm0, ymm0, ymm8                   ; c4 c1 7d fc c0                       
  1189 : vpaddb       ymm7, ymm0, ymm8                   ; c4 c1 7d fc f8                       
  1190 : vpaddb       ymm0, ymm7, ymm8                   ; c4 c1 45 fc c0                       
  1191 : vpaddb       ymm0, ymm0, ymm15                  ; c4 c1 7d fc c7                       
  1192 : vpaddw       ymm0, ymm0, ymm0                   ; c5 fd fd c0                          
  1193 : vpaddw       ymm7, ymm0, ymm0                   ; c5 fd fd f8                          
  1194 : vpaddw       ymm0, ymm7, ymm0                   ; c5 c5 fd c0                          
  1195 : vpaddw       ymm0, ymm0, ymm7                   ; c5 fd fd c7                          
  1196 : vpaddw       ymm8, ymm0, ymm0                   ; c5 7d fd c0                          
  1197 : vpaddw       ymm15, ymm0, ymm0                  ; c5 7d fd f8                          
  1198 : vpaddw       ymm8, ymm7, ymm0                   ; c5 45 fd c0                          
  1199 : vpaddw       ymm8, ymm0, ymm7                   ; c5 7d fd c7                          
  1200 : vpaddw       ymm0, ymm8, ymm0                   ; c5 bd fd c0                          
  1201 : vpaddw       ymm7, ymm8, ymm0                   ; c5 bd fd f8                          
  1202 : vpaddw       ymm0, ymm15, ymm0                  ; c5 85 fd c0                          
  1203 : vpaddw       ymm0, ymm8, ymm7                   ; c5 bd fd c7                          
  1204 : vpaddw       ymm0, ymm0, ymm8                   ; c4 c1 7d fd c0                       
  1205 : vpaddw       ymm7, ymm0, ymm8                   ; c4 c1 7d fd f8                       
  1206 : vpaddw       ymm0, ymm7, ymm8                   ; c4 c1 45 fd c0                       
  1207 : vpaddw       ymm0, ymm0, ymm15                  ; c4 c1 7d fd c7                       
  1208 : vpaddd       ymm0, ymm0, ymm0                   ; c5 fd fe c0                          
  1209 : vpaddd       ymm7, ymm0, ymm0                   ; c5 fd fe f8                          
  1210 : vpaddd       ymm0, ymm7, ymm0                   ; c5 c5 fe c0                          
  1211 : vpaddd       ymm0, ymm0, ymm7                   ; c5 fd fe c7                          
  1212 : vpaddd       ymm8, ymm0, ymm0                   ; c5 7d fe c0                          
  1213 : vpaddd       ymm15, ymm0, ymm0                  ; c5 7d fe f8                          
  1214 : vpaddd       ymm8, ymm7, ymm0                   ; c5 45 fe c0                          
  1215 : vpaddd       ymm8, ymm0, ymm7                   ; c5 7d fe c7                          
  1216 : vpaddd       ymm0, ymm8, ymm0                   ; c5 bd fe c0                          
  1217 : vpaddd       ymm7, ymm8, ymm0                   ; c5 bd fe f8                          
  1218 : vpaddd       ymm0, ymm15, ymm0                  ; c5 85 fe c0                          
  1219 : vpaddd       ymm0, ymm8, ymm7                   ; c5 bd fe c7                          
  1220 : vpaddd       ymm0, ymm0, ymm8                   ; c4 c1 7d fe c0                       
  1221 : vpaddd       ymm7, ymm0, ymm8                   ; c4 c1 7d fe f8                       
  1222 : vpaddd       ymm0, ymm7, ymm8                   ; c4 c1 45 fe c0                       
  1223 : vpaddd       ymm0, ymm0, ymm15                  ; c4 c1 7d fe c7                       
  1224 : vpaddq       ymm0, ymm0, ymm0                   ; c5 fd d4 c0                          
  1225 : vpaddq       ymm7, ymm0, ymm0                   ; c5 fd d4 f8                          
  1226 : vpaddq       ymm0, ymm7, ymm0                   ; c5 c5 d4 c0                          
  1227 : vpaddq       ymm0, ymm0, ymm7                   ; c5 fd d4 c7                          
  1228 : vpaddq       ymm8, ymm0, ymm0                   ; c5 7d d4 c0                          
  1229 : vpaddq       ymm15, ymm0, ymm0                  ; c5 7d d4 f8                          
  1230 : vpaddq       ymm8, ymm7, ymm0                   ; c5 45 d4 c0                          
  1231 : vpaddq       ymm8, ymm0, ymm7                   ; c5 7d d4 c7                          
  1232 : vpaddq       ymm0, ymm8, ymm0                   ; c5 bd d4 c0                          
  1233 : vpaddq       ymm7, ymm8, ymm0                   ; c5 bd d4 f8                          
  1234 : vpaddq       ymm0, ymm15, ymm0                  ; c5 85 d4 c0                          
  1235 : vpaddq       ymm0, ymm8, ymm7                   ; c5 bd d4 c7                          
  1236 : vpaddq       ymm0, ymm0, ymm8                   ; c4 c1 7d d4 c0                       
  1237 : vpaddq       ymm7, ymm0, ymm8                   ; c4 c1 7d d4 f8                       
  1238 : vpaddq       ymm0, ymm7, ymm8                   ; c4 c1 45 d4 c0                       
  1239 : vpaddq       ymm0, ymm0, ymm15                  ; c4 c1 7d d4 c7                       
  1240 : vaddps       ymm0, ymm0, ymm0                   ; c5 fc 58 c0                          
  1241 : vaddps       ymm7, ymm0, ymm0                   ; c5 fc 58 f8                          
  1242 : vaddps       ymm0, ymm7, ymm0                   ; c5 c4 58 c0                          
  1243 : vaddps       ymm0, ymm0, ymm7                   ; c5 fc 58 c7                          
  1244 : vaddps       ymm8, ymm0, ymm0                   ; c5 7c 58 c0                          
  1245 : vaddps       ymm15, ymm0, ymm0                  ; c5 7c 58 f8                          
  1246 : vaddps       ymm8, ymm7, ymm0                   ; c5 44 58 c0                          
  1247 : vaddps       ymm8, ymm0, ymm7                   ; c5 7c 58 c7                          
  1248 : vaddps       ymm0, ymm8, ymm0                   ; c5 bc 58 c0                          
  1249 : vaddps       ymm7, ymm8, ymm0                   ; c5 bc 58 f8                          
  1250 : vaddps       ymm0, ymm15, ymm0                  ; c5 84 58 c0                          
  1251 : vaddps       ymm0, ymm8, ymm7                   ; c5 bc 58 c7                          
  1252 : vaddps       ymm0, ymm0, ymm8                   ; c4 c1 7c 58 c0                       
  1253 : vaddps       ymm7, ymm0, ymm8                   ; c4 c1 7c 58 f8                       
  1254 : vaddps       ymm0, ymm7, ymm8                   ; c4 c1 44 58 c0                       
  1255 : vaddps       ymm0, ymm0, ymm15                  ; c4 c1 7c 58 c7                       
  1256 : vaddpd       ymm0, ymm0, ymm0                   ; c5 fd 58 c0                          
  1257 : vaddpd       ymm7, ymm0, ymm0                   ; c5 fd 58 f8                          
  1258 : vaddpd       ymm0, ymm7, ymm0                   ; c5 c5 58 c0                          
  1259 : vaddpd       ymm0, ymm0, ymm7                   ; c5 fd 58 c7                          
  1260 : vaddpd       ymm8, ymm0, ymm0                   ; c5 7d 58 c0                          
  1261 : vaddpd       ymm15, ymm0, ymm0                  ; c5 7d 58 f8                          
  1262 : vaddpd       ymm8, ymm7, ymm0                   ; c5 45 58 c0                          
  1263 : vaddpd       ymm8, ymm0, ymm7                   ; c5 7d 58 c7                          
  1264 : vaddpd       ymm0, ymm8, ymm0                   ; c5 bd 58 c0                          
  1265 : vaddpd       ymm7, ymm8, ymm0                   ; c5 bd 58 f8                          
  1266 : vaddpd       ymm0, ymm15, ymm0                  ; c5 85 58 c0                          
  1267 : vaddpd       ymm0, ymm8, ymm7                   ; c5 bd 58 c7                          
  1268 : vaddpd       ymm0, ymm0, ymm8                   ; c4 c1 7d 58 c0                       
  1269 : vaddpd       ymm7, ymm0, ymm8                   ; c4 c1 7d 58 f8                       
  1270 : vaddpd       ymm0, ymm7, ymm8                   ; c4 c1 45 58 c0                       
  1271 : vaddpd       ymm0, ymm0, ymm15                  ; c4 c1 7d 58 c7                       
  1272 : vpsubb       ymm0, ymm0, ymm0                   ; c5 fd f8 c0                          
  1273 : vpsubb       ymm7, ymm0, ymm0                   ; c5 fd f8 f8                          
  1274 : vpsubb       ymm0, ymm7, ymm0                   ; c5 c5 f8 c0                          
  1275 : vpsubb       ymm0, ymm0, ymm7                   ; c5 fd f8 c7                          
  1276 : vpsubb       ymm8, ymm0, ymm0                   ; c5 7d f8 c0                          
  1277 : vpsubb       ymm15, ymm0, ymm0                  ; c5 7d f8 f8                          
  1278 : vpsubb       ymm8, ymm7, ymm0                   ; c5 45 f8 c0                          
  1279 : vpsubb       ymm8, ymm0, ymm7                   ; c5 7d f8 c7                          
  1280 : vpsubb       ymm0, ymm8, ymm0                   ; c5 bd f8 c0                          
  1281 : vpsubb       ymm7, ymm8, ymm0                   ; c5 bd f8 f8                          
  1282 : vpsubb       ymm0, ymm15, ymm0                  ; c5 85 f8 c0                          
  1283 : vpsubb       ymm0, ymm8, ymm7                   ; c5 bd f8 c7                          
  1284 : vpsubb       ymm0, ymm0, ymm8                   ; c4 c1 7d f8 c0                       
  1285 : vpsubb       ymm7, ymm0, ymm8                   ; c4 c1 7d f8 f8                       
  1286 : vpsubb       ymm0, ymm7, ymm8                   ; c4 c1 45 f8 c0                       
  1287 : vpsubb       ymm0, ymm0, ymm15                  ; c4 c1 7d f8 c7                       
  1288 : vpsubw       ymm0, ymm0, ymm0                   ; c5 fd f9 c0                          
  1289 : vpsubw       ymm7, ymm0, ymm0                   ; c5 fd f9 f8                          
  1290 : vpsubw       ymm0, ymm7, ymm0                   ; c5 c5 f9 c0                          
  1291 : vpsubw       ymm0, ymm0, ymm7                   ; c5 fd f9 c7                          
  1292 : vpsubw       ymm8, ymm0, ymm0                   ; c5 7d f9 c0                          
  1293 : vpsubw       ymm15, ymm0, ymm0                  ; c5 7d f9 f8                          
  1294 : vpsubw       ymm8, ymm7, ymm0                   ; c5 45 f9 c0                          
  1295 : vpsubw       ymm8, ymm0, ymm7                   ; c5 7d f9 c7                          
  1296 : vpsubw       ymm0, ymm8, ymm0                   ; c5 bd f9 c0                          
  1297 : vpsubw       ymm7, ymm8, ymm0                   ; c5 bd f9 f8                          
  1298 : vpsubw       ymm0, ymm15, ymm0                  ; c5 85 f9 c0                          
  1299 : vpsubw       ymm0, ymm8, ymm7                   ; c5 bd f9 c7                          
  1300 : vpsubw       ymm0, ymm0, ymm8                   ; c4 c1 7d f9 c0                       
  1301 : vpsubw       ymm7, ymm0, ymm8                   ; c4 c1 7d f9 f8                       
  1302 : vpsubw       ymm0, ymm7, ymm8                   ; c4 c1 45 f9 c0                       
  1303 : vpsubw       ymm0, ymm0, ymm15                  ; c4 c1 7d f9 c7                       
  1304 : vpsubd       ymm0, ymm0, ymm0                   ; c5 fd fa c0                          
  1305 : vpsubd       ymm7, ymm0, ymm0                   ; c5 fd fa f8                          
  1306 : vpsubd       ymm0, ymm7, ymm0                   ; c5 c5 fa c0                          
  1307 : vpsubd       ymm0, ymm0, ymm7                   ; c5 fd fa c7                          
  1308 : vpsubd       ymm8, ymm0, ymm0                   ; c5 7d fa c0                          
  1309 : vpsubd       ymm15, ymm0, ymm0                  ; c5 7d fa f8                          
  1310 : vpsubd       ymm8, ymm7, ymm0                   ; c5 45 fa c0                          
  1311 : vpsubd       ymm8, ymm0, ymm7                   ; c5 7d fa c7                          
  1312 : vpsubd       ymm0, ymm8, ymm0                   ; c5 bd fa c0                          
  1313 : vpsubd       ymm7, ymm8, ymm0                   ; c5 bd fa f8                          
  1314 : vpsubd       ymm0, ymm15, ymm0                  ; c5 85 fa c0                          
  1315 : vpsubd       ymm0, ymm8, ymm7                   ; c5 bd fa c7                          
  1316 : vpsubd       ymm0, ymm0, ymm8                   ; c4 c1 7d fa c0                       
  1317 : vpsubd       ymm7, ymm0, ymm8                   ; c4 c1 7d fa f8                       
  1318 : vpsubd       ymm0, ymm7, ymm8                   ; c4 c1 45 fa c0                       
  1319 : vpsubd       ymm0, ymm0, ymm15                  ; c4 c1 7d fa c7                       
  1320 : vpsubq       ymm0, ymm0, ymm0                   ; c5 fd fb c0                          
  1321 : vpsubq       ymm7, ymm0, ymm0                   ; c5 fd fb f8                          
  1322 : vpsubq       ymm0, ymm7, ymm0                   ; c5 c5 fb c0                          
  1323 : vpsubq       ymm0, ymm0, ymm7                   ; c5 fd fb c7                          
  1324 : vpsubq       ymm8, ymm0, ymm0                   ; c5 7d fb c0                          
  1325 : vpsubq       ymm15, ymm0, ymm0                  ; c5 7d fb f8                          
  1326 : vpsubq       ymm8, ymm7, ymm0                   ; c5 45 fb c0                          
  1327 : vpsubq       ymm8, ymm0, ymm7                   ; c5 7d fb c7                          
  1328 : vpsubq       ymm0, ymm8, ymm0                   ; c5 bd fb c0                          
  1329 : vpsubq       ymm7, ymm8, ymm0                   ; c5 bd fb f8                          
  1330 : vpsubq       ymm0, ymm15, ymm0                  ; c5 85 fb c0                          
  1331 : vpsubq       ymm0, ymm8, ymm7                   ; c5 bd fb c7                          
  1332 : vpsubq       ymm0, ymm0, ymm8                   ; c4 c1 7d fb c0                       
  1333 : vpsubq       ymm7, ymm0, ymm8                   ; c4 c1 7d fb f8                       
  1334 : vpsubq       ymm0, ymm7, ymm8                   ; c4 c1 45 fb c0                       
  1335 : vpsubq       ymm0, ymm0, ymm15                  ; c4 c1 7d fb c7                       
  1336 : vsubps       ymm0, ymm0, ymm0                   ; c5 fc 5c c0                          
  1337 : vsubps       ymm7, ymm0, ymm0                   ; c5 fc 5c f8                          
  1338 : vsubps       ymm0, ymm7, ymm0                   ; c5 c4 5c c0                          
  1339 : vsubps       ymm0, ymm0, ymm7                   ; c5 fc 5c c7                          
  1340 : vsubps       ymm8, ymm0, ymm0                   ; c5 7c 5c c0                          
  1341 : vsubps       ymm15, ymm0, ymm0                  ; c5 7c 5c f8                          
  1342 : vsubps       ymm8, ymm7, ymm0                   ; c5 44 5c c0                          
  1343 : vsubps       ymm8, ymm0, ymm7                   ; c5 7c 5c c7                          
  1344 : vsubps       ymm0, ymm8, ymm0                   ; c5 bc 5c c0                          
  1345 : vsubps       ymm7, ymm8, ymm0                   ; c5 bc 5c f8                          
  1346 : vsubps       ymm0, ymm15, ymm0                  ; c5 84 5c c0                          
  1347 : vsubps       ymm0, ymm8, ymm7                   ; c5 bc 5c c7                          
  1348 : vsubps       ymm0, ymm0, ymm8                   ; c4 c1 7c 5c c0                       
  1349 : vsubps       ymm7, ymm0, ymm8                   ; c4 c1 7c 5c f8                       
  1350 : vsubps       ymm0, ymm7, ymm8                   ; c4 c1 44 5c c0                       
  1351 : vsubps       ymm0, ymm0, ymm15                  ; c4 c1 7c 5c c7                       
  1352 : vsubpd       ymm0, ymm0, ymm0                   ; c5 fd 5c c0                          
  1353 : vsubpd       ymm7, ymm0, ymm0                   ; c5 fd 5c f8                          
  1354 : vsubpd       ymm0, ymm7, ymm0                   ; c5 c5 5c c0                          
  1355 : vsubpd       ymm0, ymm0, ymm7                   ; c5 fd 5c c7                          
  1356 : vsubpd       ymm8, ymm0, ymm0                   ; c5 7d 5c c0                          
  1357 : vsubpd       ymm15, ymm0, ymm0                  ; c5 7d 5c f8                          
  1358 : vsubpd       ymm8, ymm7, ymm0                   ; c5 45 5c c0                          
  1359 : vsubpd       ymm8, ymm0, ymm7                   ; c5 7d 5c c7                          
  1360 : vsubpd       ymm0, ymm8, ymm0                   ; c5 bd 5c c0                          
  1361 : vsubpd       ymm7, ymm8, ymm0                   ; c5 bd 5c f8                          
  1362 : vsubpd       ymm0, ymm15, ymm0                  ; c5 85 5c c0                          
  1363 : vsubpd       ymm0, ymm8, ymm7                   ; c5 bd 5c c7                          
  1364 : vsubpd       ymm0, ymm0, ymm8                   ; c4 c1 7d 5c c0                       
  1365 : vsubpd       ymm7, ymm0, ymm8                   ; c4 c1 7d 5c f8                       
  1366 : vsubpd       ymm0, ymm7, ymm8                   ; c4 c1 45 5c c0                       
  1367 : vsubpd       ymm0, ymm0, ymm15                  ; c4 c1 7d 5c c7                       
  1368 : vpmullw      ymm0, ymm0, ymm0                   ; c5 fd d5 c0                          
  1369 : vpmullw      ymm7, ymm0, ymm0                   ; c5 fd d5 f8                          
  1370 : vpmullw      ymm0, ymm7, ymm0                   ; c5 c5 d5 c0                          
  1371 : vpmullw      ymm0, ymm0, ymm7                   ; c5 fd d5 c7                          
  1372 : vpmullw      ymm8, ymm0, ymm0                   ; c5 7d d5 c0                          
  1373 : vpmullw      ymm15, ymm0, ymm0                  ; c5 7d d5 f8                          
  1374 : vpmullw      ymm8, ymm7, ymm0                   ; c5 45 d5 c0                          
  1375 : vpmullw      ymm8, ymm0, ymm7                   ; c5 7d d5 c7                          
  1376 : vpmullw      ymm0, ymm8, ymm0                   ; c5 bd d5 c0                          
  1377 : vpmullw      ymm7, ymm8, ymm0                   ; c5 bd d5 f8                          
  1378 : vpmullw      ymm0, ymm15, ymm0                  ; c5 85 d5 c0                          
  1379 : vpmullw      ymm0, ymm8, ymm7                   ; c5 bd d5 c7                          
  1380 : vpmullw      ymm0, ymm0, ymm8                   ; c4 c1 7d d5 c0                       
  1381 : vpmullw      ymm7, ymm0, ymm8                   ; c4 c1 7d d5 f8                       
  1382 : vpmullw      ymm0, ymm7, ymm8                   ; c4 c1 45 d5 c0                       
  1383 : vpmullw      ymm0, ymm0, ymm15                  ; c4 c1 7d d5 c7                       
  1384 : vpmulld      ymm0, ymm0, ymm0                   ; c4 e2 7d 40 c0                       
  1385 : vpmulld      ymm7, ymm0, ymm0                   ; c4 e2 7d 40 f8                       
  1386 : vpmulld      ymm0, ymm7, ymm0                   ; c4 e2 45 40 c0                       
  1387 : vpmulld      ymm0, ymm0, ymm7                   ; c4 e2 7d 40 c7                       
  1388 : vpmulld      ymm8, ymm0, ymm0                   ; c4 62 7d 40 c0                       
  1389 : vpmulld      ymm15, ymm0, ymm0                  ; c4 62 7d 40 f8                       
  1390 : vpmulld      ymm8, ymm7, ymm0                   ; c4 62 45 40 c0                       
  1391 : vpmulld      ymm8, ymm0, ymm7                   ; c4 62 7d 40 c7                       
  1392 : vpmulld      ymm0, ymm8, ymm0                   ; c4 e2 3d 40 c0                       
  1393 : vpmulld      ymm7, ymm8, ymm0                   ; c4 e2 3d 40 f8                       
  1394 : vpmulld      ymm0, ymm15, ymm0                  ; c4 e2 05 40 c0                       
  1395 : vpmulld      ymm0, ymm8, ymm7                   ; c4 e2 3d 40 c7                       
  1396 : vpmulld      ymm0, ymm0, ymm8                   ; c4 c2 7d 40 c0                       
  1397 : vpmulld      ymm7, ymm0, ymm8                   ; c4 c2 7d 40 f8                       
  1398 : vpmulld      ymm0, ymm7, ymm8                   ; c4 c2 45 40 c0                       
  1399 : vpmulld      ymm0, ymm0, ymm15                  ; c4 c2 7d 40 c7                       
  1400 : vmulps       ymm0, ymm0, ymm0                   ; c5 fc 59 c0                          
  1401 : vmulps       ymm7, ymm0, ymm0                   ; c5 fc 59 f8                          
  1402 : vmulps       ymm0, ymm7, ymm0                   ; c5 c4 59 c0                          
  1403 : vmulps       ymm0, ymm0, ymm7                   ; c5 fc 59 c7                          
  1404 : vmulps       ymm8, ymm0, ymm0                   ; c5 7c 59 c0                          
  1405 : vmulps       ymm15, ymm0, ymm0                  ; c5 7c 59 f8                          
  1406 : vmulps       ymm8, ymm7, ymm0                   ; c5 44 59 c0                          
  1407 : vmulps       ymm8, ymm0, ymm7                   ; c5 7c 59 c7                          
  1408 : vmulps       ymm0, ymm8, ymm0                   ; c5 bc 59 c0                          
  1409 : vmulps       ymm7, ymm8, ymm0                   ; c5 bc 59 f8                          
  1410 : vmulps       ymm0, ymm15, ymm0                  ; c5 84 59 c0                          
  1411 : vmulps       ymm0, ymm8, ymm7                   ; c5 bc 59 c7                          
  1412 : vmulps       ymm0, ymm0, ymm8                   ; c4 c1 7c 59 c0                       
  1413 : vmulps       ymm7, ymm0, ymm8                   ; c4 c1 7c 59 f8                       
  1414 : vmulps       ymm0, ymm7, ymm8                   ; c4 c1 44 59 c0                       
  1415 : vmulps       ymm0, ymm0, ymm15                  ; c4 c1 7c 59 c7                       
  1416 : vmulpd       ymm0, ymm0, ymm0                   ; c5 fd 59 c0                          
  1417 : vmulpd       ymm7, ymm0, ymm0                   ; c5 fd 59 f8                          
  1418 : vmulpd       ymm0, ymm7, ymm0                   ; c5 c5 59 c0                          
  1419 : vmulpd       ymm0, ymm0, ymm7                   ; c5 fd 59 c7                          
  1420 : vmulpd       ymm8, ymm0, ymm0                   ; c5 7d 59 c0                          
  1421 : vmulpd       ymm15, ymm0, ymm0                  ; c5 7d 59 f8                          
  1422 : vmulpd       ymm8, ymm7, ymm0                   ; c5 45 59 c0                          
  1423 : vmulpd       ymm8, ymm0, ymm7                   ; c5 7d 59 c7                          
  1424 : vmulpd       ymm0, ymm8, ymm0                   ; c5 bd 59 c0                          
  1425 : vmulpd       ymm7, ymm8, ymm0                   ; c5 bd 59 f8                          
  1426 : vmulpd       ymm0, ymm15, ymm0                  ; c5 85 59 c0                          
  1427 : vmulpd       ymm0, ymm8, ymm7                   ; c5 bd 59 c7                          
  1428 : vmulpd       ymm0, ymm0, ymm8                   ; c4 c1 7d 59 c0                       
  1429 : vmulpd       ymm7, ymm0, ymm8                   ; c4 c1 7d 59 f8                       
  1430 : vmulpd       ymm0, ymm7, ymm8                   ; c4 c1 45 59 c0                       
  1431 : vmulpd       ymm0, ymm0, ymm15                  ; c4 c1 7d 59 c7                       
  1432 : vdivps       ymm0, ymm0, ymm0                   ; c5 fc 5e c0                          
  1433 : vdivps       ymm7, ymm0, ymm0                   ; c5 fc 5e f8                          
  1434 : vdivps       ymm0, ymm7, ymm0                   ; c5 c4 5e c0                          
  1435 : vdivps       ymm0, ymm0, ymm7                   ; c5 fc 5e c7                          
  1436 : vdivps       ymm8, ymm0, ymm0                   ; c5 7c 5e c0                          
  1437 : vdivps       ymm15, ymm0, ymm0                  ; c5 7c 5e f8                          
  1438 : vdivps       ymm8, ymm7, ymm0                   ; c5 44 5e c0                          
  1439 : vdivps       ymm8, ymm0, ymm7                   ; c5 7c 5e c7                          
  1440 : vdivps       ymm0, ymm8, ymm0                   ; c5 bc 5e c0                          
  1441 : vdivps       ymm7, ymm8, ymm0                   ; c5 bc 5e f8                          
  1442 : vdivps       ymm0, ymm15, ymm0                  ; c5 84 5e c0                          
  1443 : vdivps       ymm0, ymm8, ymm7                   ; c5 bc 5e c7                          
  1444 : vdivps       ymm0, ymm0, ymm8                   ; c4 c1 7c 5e c0                       
  1445 : vdivps       ymm7, ymm0, ymm8                   ; c4 c1 7c 5e f8                       
  1446 : vdivps       ymm0, ymm7, ymm8                   ; c4 c1 44 5e c0                       
  1447 : vdivps       ymm0, ymm0, ymm15                  ; c4 c1 7c 5e c7                       
  1448 : vdivpd       ymm0, ymm0, ymm0                   ; c5 fd 5e c0                          
  1449 : vdivpd       ymm7, ymm0, ymm0                   ; c5 fd 5e f8                          
  1450 : vdivpd       ymm0, ymm7, ymm0                   ; c5 c5 5e c0                          
  1451 : vdivpd       ymm0, ymm0, ymm7                   ; c5 fd 5e c7                          
  1452 : vdivpd       ymm8, ymm0, ymm0                   ; c5 7d 5e c0                          
  1453 : vdivpd       ymm15, ymm0, ymm0                  ; c5 7d 5e f8                          
  1454 : vdivpd       ymm8, ymm7, ymm0                   ; c5 45 5e c0                          
  1455 : vdivpd       ymm8, ymm0, ymm7                   ; c5 7d 5e c7                          
  1456 : vdivpd       ymm0, ymm8, ymm0                   ; c5 bd 5e c0                          
  1457 : vdivpd       ymm7, ymm8, ymm0                   ; c5 bd 5e f8                          
  1458 : vdivpd       ymm0, ymm15, ymm0                  ; c5 85 5e c0                          
  1459 : vdivpd       ymm0, ymm8, ymm7                   ; c5 bd 5e c7                          
  1460 : vdivpd       ymm0, ymm0, ymm8                   ; c4 c1 7d 5e c0                       
  1461 : vdivpd       ymm7, ymm0, ymm8                   ; c4 c1 7d 5e f8                       
  1462 : vdivpd       ymm0, ymm7, ymm8                   ; c4 c1 45 5e c0                       
  1463 : vdivpd       ymm0, ymm0, ymm15                  ; c4 c1 7d 5e c7                       
  1464 : vfmadd231ps  ymm0, ymm0, ymm0                   ; c4 e2 7d b8 c0                       
  1465 : vfmadd231ps  ymm7, ymm0, ymm0                   ; c4 e2 7d b8 f8                       
  1466 : vfmadd231ps  ymm0, ymm7, ymm0                   ; c4 e2 45 b8 c0                       
  1467 : vfmadd231ps  ymm0, ymm0, ymm7                   ; c4 e2 7d b8 c7                       
  1468 : vfmadd231ps  ymm8, ymm0, ymm0                   ; c4 62 7d b8 c0                       
  1469 : vfmadd231ps  ymm15, ymm0, ymm0                  ; c4 62 7d b8 f8                       
  1470 : vfmadd231ps  ymm8, ymm7, ymm0                   ; c4 62 45 b8 c0                       
  1471 : vfmadd231ps  ymm8, ymm0, ymm7                   ; c4 62 7d b8 c7                       
  1472 : vfmadd231ps  ymm0, ymm8, ymm0                   ; c4 e2 3d b8 c0                       
  1473 : vfmadd231ps  ymm7, ymm8, ymm0                   ; c4 e2 3d b8 f8                       
  1474 : vfmadd231ps  ymm0, ymm15, ymm0                  ; c4 e2 05 b8 c0                       
  1475 : vfmadd231ps  ymm0, ymm8, ymm7                   ; c4 e2 3d b8 c7                       
  1476 : vfmadd231ps  ymm0, ymm0, ymm8                   ; c4 c2 7d b8 c0                       
  1477 : vfmadd231ps  ymm7, ymm0, ymm8                   ; c4 c2 7d b8 f8                       
  1478 : vfmadd231ps  ymm0, ymm7, ymm8                   ; c4 c2 45 b8 c0                       
  1479 : vfmadd231ps  ymm0, ymm0, ymm15                  ; c4 c2 7d b8 c7                       
  1480 : vfmadd231pd  ymm0, ymm0, ymm0                   ; c4 e2 fd b8 c0                       
  1481 : vfmadd231pd  ymm7, ymm0, ymm0                   ; c4 e2 fd b8 f8                       
  1482 : vfmadd231pd  ymm0, ymm7, ymm0                   ; c4 e2 c5 b8 c0                       
  1483 : vfmadd231pd  ymm0, ymm0, ymm7                   ; c4 e2 fd b8 c7                       
  1484 : vfmadd231pd  ymm8, ymm0, ymm0                   ; c4 62 fd b8 c0                       
  1485 : vfmadd231pd  ymm15, ymm0, ymm0                  ; c4 62 fd b8 f8                       
  1486 : vfmadd231pd  ymm8, ymm7, ymm0                   ; c4 62 c5 b8 c0                       
  1487 : vfmadd231pd  ymm8, ymm0, ymm7                   ; c4 62 fd b8 c7                       
  1488 : vfmadd231pd  ymm0, ymm8, ymm0                   ; c4 e2 bd b8 c0                       
  1489 : vfmadd231pd  ymm7, ymm8, ymm0                   ; c4 e2 bd b8 f8                       
  1490 : vfmadd231pd  ymm0, ymm15, ymm0                  ; c4 e2 85 b8 c0                       
  1491 : vfmadd231pd  ymm0, ymm8, ymm7                   ; c4 e2 bd b8 c7                       
  1492 : vfmadd231pd  ymm0, ymm0, ymm8                   ; c4 c2 fd b8 c0                       
  1493 : vfmadd231pd  ymm7, ymm0, ymm8                   ; c4 c2 fd b8 f8                       
  1494 : vfmadd231pd  ymm0, ymm7, ymm8                   ; c4 c2 c5 b8 c0                       
  1495 : vfmadd231pd  ymm0, ymm0, ymm15                  ; c4 c2 fd b8 c7                       
  1496 : vpminub      ymm0, ymm0, ymm0                   ; c5 fd da c0                          
  1497 : vpminub      ymm7, ymm0, ymm0                   ; c5 fd da f8                          
  1498 : vpminub      ymm0, ymm7, ymm0                   ; c5 c5 da c0                          
  1499 : vpminub      ymm0, ymm0, ymm7                   ; c5 fd da c7                          
  1500 : vpminub      ymm8, ymm0, ymm0                   ; c5 7d da c0                          
  1501 : vpminub      ymm15, ymm0, ymm0                  ; c5 7d da f8                          
  1502 : vpminub      ymm8, ymm7, ymm0                   ; c5 45 da c0                          
  1503 : vpminub      ymm8, ymm0, ymm7                   ; c5 7d da c7                          
  1504 : vpminub      ymm0, ymm8, ymm0                   ; c5 bd da c0                          
  1505 : vpminub      ymm7, ymm8, ymm0                   ; c5 bd da f8                          
  1506 : vpminub      ymm0, ymm15, ymm0                  ; c5 85 da c0                          
  1507 : vpminub      ymm0, ymm8, ymm7                   ; c5 bd da c7                          
  1508 : vpminub      ymm0, ymm0, ymm8                   ; c4 c1 7d da c0                       
  1509 : vpminub      ymm7, ymm0, ymm8                   ; c4 c1 7d da f8                       
  1510 : vpminub      ymm0, ymm7, ymm8                   ; c4 c1 45 da c0                       
  1511 : vpminub      ymm0, ymm0, ymm15                  ; c4 c1 7d da c7                       
  1512 : vpminsb      ymm0, ymm0, ymm0                   ; c4 e2 7d 38 c0                       
  1513 : vpminsb      ymm7, ymm0, ymm0                   ; c4 e2 7d 38 f8                       
  1514 : vpminsb      ymm0, ymm7, ymm0                   ; c4 e2 45 38 c0                       
  1515 : vpminsb      ymm0, ymm0, ymm7                   ; c4 e2 7d 38 c7                       
  1516 : vpminsb      ymm8, ymm0, ymm0                   ; c4 62 7d 38 c0                       
  1517 : vpminsb      ymm15, ymm0, ymm0                  ; c4 62 7d 38 f8                       
  1518 : vpminsb      ymm8, ymm7, ymm0                   ; c4 62 45 38 c0                       
  1519 : vpminsb      ymm8, ymm0, ymm7                   ; c4 62 7d 38 c7                       
  1520 : vpminsb      ymm0, ymm8, ymm0                   ; c4 e2 3d 38 c0                       
  1521 : vpminsb      ymm7, ymm8, ymm0                   ; c4 e2 3d 38 f8                       
  1522 : vpminsb      ymm0, ymm15, ymm0                  ; c4 e2 05 38 c0                       
  1523 : vpminsb      ymm0, ymm8, ymm7                   ; c4 e2 3d 38 c7                       
  1524 : vpminsb      ymm0, ymm0, ymm8                   ; c4 c2 7d 38 c0                       
  1525 : vpminsb      ymm7, ymm0, ymm8                   ; c4 c2 7d 38 f8                       
  1526 : vpminsb      ymm0, ymm7, ymm8                   ; c4 c2 45 38 c0                       
  1527 : vpminsb      ymm0, ymm0, ymm15                  ; c4 c2 7d 38 c7                       
  1528 : vpminuw      ymm0, ymm0, ymm0                   ; c4 e2 7d 3a c0                       
  1529 : vpminuw      ymm7, ymm0, ymm0                   ; c4 e2 7d 3a f8                       
  1530 : vpminuw      ymm0, ymm7, ymm0                   ; c4 e2 45 3a c0                       
  1531 : vpminuw      ymm0, ymm0, ymm7                   ; c4 e2 7d 3a c7                       
  1532 : vpminuw      ymm8, ymm0, ymm0                   ; c4 62 7d 3a c0                       
  1533 : vpminuw      ymm15, ymm0, ymm0                  ; c4 62 7d 3a f8                       
  1534 : vpminuw      ymm8, ymm7, ymm0                   ; c4 62 45 3a c0                       
  1535 : vpminuw      ymm8, ymm0, ymm7                   ; c4 62 7d 3a c7                       
  1536 : vpminuw      ymm0, ymm8, ymm0                   ; c4 e2 3d 3a c0                       
  1537 : vpminuw      ymm7, ymm8, ymm0                   ; c4 e2 3d 3a f8                       
  1538 : vpminuw      ymm0, ymm15, ymm0                  ; c4 e2 05 3a c0                       
  1539 : vpminuw      ymm0, ymm8, ymm7                   ; c4 e2 3d 3a c7                       
  1540 : vpminuw      ymm0, ymm0, ymm8                   ; c4 c2 7d 3a c0                       
  1541 : vpminuw      ymm7, ymm0, ymm8                   ; c4 c2 7d 3a f8                       
  1542 : vpminuw      ymm0, ymm7, ymm8                   ; c4 c2 45 3a c0                       
  1543 : vpminuw      ymm0, ymm0, ymm15                  ; c4 c2 7d 3a c7                       
  1544 : vpminsw      ymm0, ymm0, ymm0                   ; c5 fd ea c0                          
  1545 : vpminsw      ymm7, ymm0, ymm0                   ; c5 fd ea f8                          
  1546 : vpminsw      ymm0, ymm7, ymm0                   ; c5 c5 ea c0                          
  1547 : vpminsw      ymm0, ymm0, ymm7                   ; c5 fd ea c7                          
  1548 : vpminsw      ymm8, ymm0, ymm0                   ; c5 7d ea c0                          
  1549 : vpminsw      ymm15, ymm0, ymm0                  ; c5 7d ea f8                          
  1550 : vpminsw      ymm8, ymm7, ymm0                   ; c5 45 ea c0                          
  1551 : vpminsw      ymm8, ymm0, ymm7                   ; c5 7d ea c7                          
  1552 : vpminsw      ymm0, ymm8, ymm0                   ; c5 bd ea c0                          
  1553 : vpminsw      ymm7, ymm8, ymm0                   ; c5 bd ea f8                          
  1554 : vpminsw      ymm0, ymm15, ymm0                  ; c5 85 ea c0                          
  1555 : vpminsw      ymm0, ymm8, ymm7                   ; c5 bd ea c7                          
  1556 : vpminsw      ymm0, ymm0, ymm8                   ; c4 c1 7d ea c0                       
  1557 : vpminsw      ymm7, ymm0, ymm8                   ; c4 c1 7d ea f8                       
  1558 : vpminsw      ymm0, ymm7, ymm8                   ; c4 c1 45 ea c0                       
  1559 : vpminsw      ymm0, ymm0, ymm15                  ; c4 c1 7d ea c7                       
  1560 : vpminud      ymm0, ymm0, ymm0                   ; c4 e2 7d 3b c0                       
  1561 : vpminud      ymm7, ymm0, ymm0                   ; c4 e2 7d 3b f8                       
  1562 : vpminud      ymm0, ymm7, ymm0                   ; c4 e2 45 3b c0                       
  1563 : vpminud      ymm0, ymm0, ymm7                   ; c4 e2 7d 3b c7                       
  1564 : vpminud      ymm8, ymm0, ymm0                   ; c4 62 7d 3b c0                       
  1565 : vpminud      ymm15, ymm0, ymm0                  ; c4 62 7d 3b f8                       
  1566 : vpminud      ymm8, ymm7, ymm0                   ; c4 62 45 3b c0                       
  1567 : vpminud      ymm8, ymm0, ymm7                   ; c4 62 7d 3b c7                       
  1568 : vpminud      ymm0, ymm8, ymm0                   ; c4 e2 3d 3b c0                       
  1569 : vpminud      ymm7, ymm8, ymm0                   ; c4 e2 3d 3b f8                       
  1570 : vpminud      ymm0, ymm15, ymm0                  ; c4 e2 05 3b c0                       
  1571 : vpminud      ymm0, ymm8, ymm7                   ; c4 e2 3d 3b c7                       
  1572 : vpminud      ymm0, ymm0, ymm8                   ; c4 c2 7d 3b c0                       
  1573 : vpminud      ymm7, ymm0, ymm8                   ; c4 c2 7d 3b f8                       
  1574 : vpminud      ymm0, ymm7, ymm8                   ; c4 c2 45 3b c0                       
  1575 : vpminud      ymm0, ymm0, ymm15                  ; c4 c2 7d 3b c7                       
  1576 : vpminsd      ymm0, ymm0, ymm0                   ; c4 e2 7d 39 c0                       
  1577 : vpminsd      ymm7, ymm0, ymm0                   ; c4 e2 7d 39 f8                       
  1578 : vpminsd      ymm0, ymm7, ymm0                   ; c4 e2 45 39 c0                       
  1579 : vpminsd      ymm0, ymm0, ymm7                   ; c4 e2 7d 39 c7                       
  1580 : vpminsd      ymm8, ymm0, ymm0                   ; c4 62 7d 39 c0                       
  1581 : vpminsd      ymm15, ymm0, ymm0                  ; c4 62 7d 39 f8                       
  1582 : vpminsd      ymm8, ymm7, ymm0                   ; c4 62 45 39 c0                       
  1583 : vpminsd      ymm8, ymm0, ymm7                   ; c4 62 7d 39 c7                       
  1584 : vpminsd      ymm0, ymm8, ymm0                   ; c4 e2 3d 39 c0                       
  1585 : vpminsd      ymm7, ymm8, ymm0                   ; c4 e2 3d 39 f8                       
  1586 : vpminsd      ymm0, ymm15, ymm0                  ; c4 e2 05 39 c0                       
  1587 : vpminsd      ymm0, ymm8, ymm7                   ; c4 e2 3d 39 c7                       
  1588 : vpminsd      ymm0, ymm0, ymm8                   ; c4 c2 7d 39 c0                       
  1589 : vpminsd      ymm7, ymm0, ymm8                   ; c4 c2 7d 39 f8                       
  1590 : vpminsd      ymm0, ymm7, ymm8                   ; c4 c2 45 39 c0                       
  1591 : vpminsd      ymm0, ymm0, ymm15                  ; c4 c2 7d 39 c7                       
  1592 : vminps       ymm0, ymm0, ymm0                   ; c5 fc 5d c0                          
  1593 : vminps       ymm7, ymm0, ymm0                   ; c5 fc 5d f8                          
  1594 : vminps       ymm0, ymm7, ymm0                   ; c5 c4 5d c0                          
  1595 : vminps       ymm0, ymm0, ymm7                   ; c5 fc 5d c7                          
  1596 : vminps       ymm8, ymm0, ymm0                   ; c5 7c 5d c0                          
  1597 : vminps       ymm15, ymm0, ymm0                  ; c5 7c 5d f8                          
  1598 : vminps       ymm8, ymm7, ymm0                   ; c5 44 5d c0                          
  1599 : vminps       ymm8, ymm0, ymm7                   ; c5 7c 5d c7                          
  1600 : vminps       ymm0, ymm8, ymm0                   ; c5 bc 5d c0                          
  1601 : vminps       ymm7, ymm8, ymm0                   ; c5 bc 5d f8                          
  1602 : vminps       ymm0, ymm15, ymm0                  ; c5 84 5d c0                          
  1603 : vminps       ymm0, ymm8, ymm7                   ; c5 bc 5d c7                          
  1604 : vminps       ymm0, ymm0, ymm8                   ; c4 c1 7c 5d c0                       
  1605 : vminps       ymm7, ymm0, ymm8                   ; c4 c1 7c 5d f8                       
  1606 : vminps       ymm0, ymm7, ymm8                   ; c4 c1 44 5d c0                       
  1607 : vminps       ymm0, ymm0, ymm15                  ; c4 c1 7c 5d c7                       
  1608 : vminpd       ymm0, ymm0, ymm0                   ; c5 fd 5d c0                          
  1609 : vminpd       ymm7, ymm0, ymm0                   ; c5 fd 5d f8                          
  1610 : vminpd       ymm0, ymm7, ymm0                   ; c5 c5 5d c0                          
  1611 : vminpd       ymm0, ymm0, ymm7                   ; c5 fd 5d c7                          
  1612 : vminpd       ymm8, ymm0, ymm0                   ; c5 7d 5d c0                          
  1613 : vminpd       ymm15, ymm0, ymm0                  ; c5 7d 5d f8                          
  1614 : vminpd       ymm8, ymm7, ymm0                   ; c5 45 5d c0                          
  1615 : vminpd       ymm8, ymm0, ymm7                   ; c5 7d 5d c7                          
  1616 : vminpd       ymm0, ymm8, ymm0                   ; c5 bd 5d c0                          
  1617 : vminpd       ymm7, ymm8, ymm0                   ; c5 bd 5d f8                          
  1618 : vminpd       ymm0, ymm15, ymm0                  ; c5 85 5d c0                          
  1619 : vminpd       ymm0, ymm8, ymm7                   ; c5 bd 5d c7                          
  1620 : vminpd       ymm0, ymm0, ymm8                   ; c4 c1 7d 5d c0                       
  1621 : vminpd       ymm7, ymm0, ymm8                   ; c4 c1 7d 5d f8                       
  1622 : vminpd       ymm0, ymm7, ymm8                   ; c4 c1 45 5d c0                       
  1623 : vminpd       ymm0, ymm0, ymm15                  ; c4 c1 7d 5d c7                       
  1624 : vpmaxub      ymm0, ymm0, ymm0                   ; c5 fd de c0                          
  1625 : vpmaxub      ymm7, ymm0, ymm0                   ; c5 fd de f8                          
  1626 : vpmaxub      ymm0, ymm7, ymm0                   ; c5 c5 de c0                          
  1627 : vpmaxub      ymm0, ymm0, ymm7                   ; c5 fd de c7                          
  1628 : vpmaxub      ymm8, ymm0, ymm0                   ; c5 7d de c0                          
  1629 : vpmaxub      ymm15, ymm0, ymm0                  ; c5 7d de f8                          
  1630 : vpmaxub      ymm8, ymm7, ymm0                   ; c5 45 de c0                          
  1631 : vpmaxub      ymm8, ymm0, ymm7                   ; c5 7d de c7                          
  1632 : vpmaxub      ymm0, ymm8, ymm0                   ; c5 bd de c0                          
  1633 : vpmaxub      ymm7, ymm8, ymm0                   ; c5 bd de f8                          
  1634 : vpmaxub      ymm0, ymm15, ymm0                  ; c5 85 de c0                          
  1635 : vpmaxub      ymm0, ymm8, ymm7                   ; c5 bd de c7                          
  1636 : vpmaxub      ymm0, ymm0, ymm8                   ; c4 c1 7d de c0                       
  1637 : vpmaxub      ymm7, ymm0, ymm8                   ; c4 c1 7d de f8                       
  1638 : vpmaxub      ymm0, ymm7, ymm8                   ; c4 c1 45 de c0                       
  1639 : vpmaxub      ymm0, ymm0, ymm15                  ; c4 c1 7d de c7                       
  1640 : vpmaxsb      ymm0, ymm0, ymm0                   ; c4 e2 7d 3c c0                       
  1641 : vpmaxsb      ymm7, ymm0, ymm0                   ; c4 e2 7d 3c f8                       
  1642 : vpmaxsb      ymm0, ymm7, ymm0                   ; c4 e2 45 3c c0                       
  1643 : vpmaxsb      ymm0, ymm0, ymm7                   ; c4 e2 7d 3c c7                       
  1644 : vpmaxsb      ymm8, ymm0, ymm0                   ; c4 62 7d 3c c0                       
  1645 : vpmaxsb      ymm15, ymm0, ymm0                  ; c4 62 7d 3c f8                       
  1646 : vpmaxsb      ymm8, ymm7, ymm0                   ; c4 62 45 3c c0                       
  1647 : vpmaxsb      ymm8, ymm0, ymm7                   ; c4 62 7d 3c c7                       
  1648 : vpmaxsb      ymm0, ymm8, ymm0                   ; c4 e2 3d 3c c0                       
  1649 : vpmaxsb      ymm7, ymm8, ymm0                   ; c4 e2 3d 3c f8                       
  1650 : vpmaxsb      ymm0, ymm15, ymm0                  ; c4 e2 05 3c c0                       
  1651 : vpmaxsb      ymm0, ymm8, ymm7                   ; c4 e2 3d 3c c7                       
  1652 : vpmaxsb      ymm0, ymm0, ymm8                   ; c4 c2 7d 3c c0                       
  1653 : vpmaxsb      ymm7, ymm0, ymm8                   ; c4 c2 7d 3c f8                       
  1654 : vpmaxsb      ymm0, ymm7, ymm8                   ; c4 c2 45 3c c0                       
  1655 : vpmaxsb      ymm0, ymm0, ymm15                  ; c4 c2 7d 3c c7                       
  1656 : vpmaxuw      ymm0, ymm0, ymm0                   ; c4 e2 7d 3e c0                       
  1657 : vpmaxuw      ymm7, ymm0, ymm0                   ; c4 e2 7d 3e f8                       
  1658 : vpmaxuw      ymm0, ymm7, ymm0                   ; c4 e2 45 3e c0                       
  1659 : vpmaxuw      ymm0, ymm0, ymm7                   ; c4 e2 7d 3e c7                       
  1660 : vpmaxuw      ymm8, ymm0, ymm0                   ; c4 62 7d 3e c0                       
  1661 : vpmaxuw      ymm15, ymm0, ymm0                  ; c4 62 7d 3e f8                       
  1662 : vpmaxuw      ymm8, ymm7, ymm0                   ; c4 62 45 3e c0                       
  1663 : vpmaxuw      ymm8, ymm0, ymm7                   ; c4 62 7d 3e c7                       
  1664 : vpmaxuw      ymm0, ymm8, ymm0                   ; c4 e2 3d 3e c0                       
  1665 : vpmaxuw      ymm7, ymm8, ymm0                   ; c4 e2 3d 3e f8                       
  1666 : vpmaxuw      ymm0, ymm15, ymm0                  ; c4 e2 05 3e c0                       
  1667 : vpmaxuw      ymm0, ymm8, ymm7                   ; c4 e2 3d 3e c7                       
  1668 : vpmaxuw      ymm0, ymm0, ymm8                   ; c4 c2 7d 3e c0                       
  1669 : vpmaxuw      ymm7, ymm0, ymm8                   ; c4 c2 7d 3e f8                       
  1670 : vpmaxuw      ymm0, ymm7, ymm8                   ; c4 c2 45 3e c0                       
  1671 : vpmaxuw      ymm0, ymm0, ymm15                  ; c4 c2 7d 3e c7                       
  1672 : vpmaxsw      ymm0, ymm0, ymm0                   ; c5 fd ee c0                          
  1673 : vpmaxsw      ymm7, ymm0, ymm0                   ; c5 fd ee f8                          
  1674 : vpmaxsw      ymm0, ymm7, ymm0                   ; c5 c5 ee c0                          
  1675 : vpmaxsw      ymm0, ymm0, ymm7                   ; c5 fd ee c7                          
  1676 : vpmaxsw      ymm8, ymm0, ymm0                   ; c5 7d ee c0                          
  1677 : vpmaxsw      ymm15, ymm0, ymm0                  ; c5 7d ee f8                          
  1678 : vpmaxsw      ymm8, ymm7, ymm0                   ; c5 45 ee c0                          
  1679 : vpmaxsw      ymm8, ymm0, ymm7                   ; c5 7d ee c7                          
  1680 : vpmaxsw      ymm0, ymm8, ymm0                   ; c5 bd ee c0                          
  1681 : vpmaxsw      ymm7, ymm8, ymm0                   ; c5 bd ee f8                          
  1682 : vpmaxsw      ymm0, ymm15, ymm0                  ; c5 85 ee c0                          
  1683 : vpmaxsw      ymm0, ymm8, ymm7                   ; c5 bd ee c7                          
  1684 : vpmaxsw      ymm0, ymm0, ymm8                   ; c4 c1 7d ee c0                       
  1685 : vpmaxsw      ymm7, ymm0, ymm8                   ; c4 c1 7d ee f8                       
  1686 : vpmaxsw      ymm0, ymm7, ymm8                   ; c4 c1 45 ee c0                       
  1687 : vpmaxsw      ymm0, ymm0, ymm15                  ; c4 c1 7d ee c7                       
  1688 : vpmaxud      ymm0, ymm0, ymm0                   ; c4 e2 7d 3f c0                       
  1689 : vpmaxud      ymm7, ymm0, ymm0                   ; c4 e2 7d 3f f8                       
  1690 : vpmaxud      ymm0, ymm7, ymm0                   ; c4 e2 45 3f c0                       
  1691 : vpmaxud      ymm0, ymm0, ymm7                   ; c4 e2 7d 3f c7                       
  1692 : vpmaxud      ymm8, ymm0, ymm0                   ; c4 62 7d 3f c0                       
  1693 : vpmaxud      ymm15, ymm0, ymm0                  ; c4 62 7d 3f f8                       
  1694 : vpmaxud      ymm8, ymm7, ymm0                   ; c4 62 45 3f c0                       
  1695 : vpmaxud      ymm8, ymm0, ymm7                   ; c4 62 7d 3f c7                       
  1696 : vpmaxud      ymm0, ymm8, ymm0                   ; c4 e2 3d 3f c0                       
  1697 : vpmaxud      ymm7, ymm8, ymm0                   ; c4 e2 3d 3f f8                       
  1698 : vpmaxud      ymm0, ymm15, ymm0                  ; c4 e2 05 3f c0                       
  1699 : vpmaxud      ymm0, ymm8, ymm7                   ; c4 e2 3d 3f c7                       
  1700 : vpmaxud      ymm0, ymm0, ymm8                   ; c4 c2 7d 3f c0                       
  1701 : vpmaxud      ymm7, ymm0, ymm8                   ; c4 c2 7d 3f f8                       
  1702 : vpmaxud      ymm0, ymm7, ymm8                   ; c4 c2 45 3f c0                       
  1703 : vpmaxud      ymm0, ymm0, ymm15                  ; c4 c2 7d 3f c7                       
  1704 : vpmaxsd      ymm0, ymm0, ymm0                   ; c4 e2 7d 3d c0                       
  1705 : vpmaxsd      ymm7, ymm0, ymm0                   ; c4 e2 7d 3d f8                       
  1706 : vpmaxsd      ymm0, ymm7, ymm0                   ; c4 e2 45 3d c0                       
  1707 : vpmaxsd      ymm0, ymm0, ymm7                   ; c4 e2 7d 3d c7                       
  1708 : vpmaxsd      ymm8, ymm0, ymm0                   ; c4 62 7d 3d c0                       
  1709 : vpmaxsd      ymm15, ymm0, ymm0                  ; c4 62 7d 3d f8                       
  1710 : vpmaxsd      ymm8, ymm7, ymm0                   ; c4 62 45 3d c0                       
  1711 : vpmaxsd      ymm8, ymm0, ymm7                   ; c4 62 7d 3d c7                       
  1712 : vpmaxsd      ymm0, ymm8, ymm0                   ; c4 e2 3d 3d c0                       
  1713 : vpmaxsd      ymm7, ymm8, ymm0                   ; c4 e2 3d 3d f8                       
  1714 : vpmaxsd      ymm0, ymm15, ymm0                  ; c4 e2 05 3d c0                       
  1715 : vpmaxsd      ymm0, ymm8, ymm7                   ; c4 e2 3d 3d c7                       
  1716 : vpmaxsd      ymm0, ymm0, ymm8                   ; c4 c2 7d 3d c0                       
  1717 : vpmaxsd      ymm7, ymm0, ymm8                   ; c4 c2 7d 3d f8                       
  1718 : vpmaxsd      ymm0, ymm7, ymm8                   ; c4 c2 45 3d c0                       
  1719 : vpmaxsd      ymm0, ymm0, ymm15                  ; c4 c2 7d 3d c7                       
  1720 : vmaxps       ymm0, ymm0, ymm0                   ; c5 fc 5f c0                          
  1721 : vmaxps       ymm7, ymm0, ymm0                   ; c5 fc 5f f8                          
  1722 : vmaxps       ymm0, ymm7, ymm0                   ; c5 c4 5f c0                          
  1723 : vmaxps       ymm0, ymm0, ymm7                   ; c5 fc 5f c7                          
  1724 : vmaxps       ymm8, ymm0, ymm0                   ; c5 7c 5f c0                          
  1725 : vmaxps       ymm15, ymm0, ymm0                  ; c5 7c 5f f8                          
  1726 : vmaxps       ymm8, ymm7, ymm0                   ; c5 44 5f c0                          
  1727 : vmaxps       ymm8, ymm0, ymm7                   ; c5 7c 5f c7                          
  1728 : vmaxps       ymm0, ymm8, ymm0                   ; c5 bc 5f c0                          
  1729 : vmaxps       ymm7, ymm8, ymm0                   ; c5 bc 5f f8                          
  1730 : vmaxps       ymm0, ymm15, ymm0                  ; c5 84 5f c0                          
  1731 : vmaxps       ymm0, ymm8, ymm7                   ; c5 bc 5f c7                          
  1732 : vmaxps       ymm0, ymm0, ymm8                   ; c4 c1 7c 5f c0                       
  1733 : vmaxps       ymm7, ymm0, ymm8                   ; c4 c1 7c 5f f8                       
  1734 : vmaxps       ymm0, ymm7, ymm8                   ; c4 c1 44 5f c0                       
  1735 : vmaxps       ymm0, ymm0, ymm15                  ; c4 c1 7c 5f c7                       
  1736 : vmaxpd       ymm0, ymm0, ymm0                   ; c5 fd 5f c0                          
  1737 : vmaxpd       ymm7, ymm0, ymm0                   ; c5 fd 5f f8                          
  1738 : vmaxpd       ymm0, ymm7, ymm0                   ; c5 c5 5f c0                          
  1739 : vmaxpd       ymm0, ymm0, ymm7                   ; c5 fd 5f c7                          
  1740 : vmaxpd       ymm8, ymm0, ymm0                   ; c5 7d 5f c0                          
  1741 : vmaxpd       ymm15, ymm0, ymm0                  ; c5 7d 5f f8                          
  1742 : vmaxpd       ymm8, ymm7, ymm0                   ; c5 45 5f c0                          
  1743 : vmaxpd       ymm8, ymm0, ymm7                   ; c5 7d 5f c7                          
  1744 : vmaxpd       ymm0, ymm8, ymm0                   ; c5 bd 5f c0                          
  1745 : vmaxpd       ymm7, ymm8, ymm0                   ; c5 bd 5f f8                          
  1746 : vmaxpd       ymm0, ymm15, ymm0                  ; c5 85 5f c0                          
  1747 : vmaxpd       ymm0, ymm8, ymm7                   ; c5 bd 5f c7                          
  1748 : vmaxpd       ymm0, ymm0, ymm8                   ; c4 c1 7d 5f c0                       
  1749 : vmaxpd       ymm7, ymm0, ymm8                   ; c4 c1 7d 5f f8                       
  1750 : vmaxpd       ymm0, ymm7, ymm8                   ; c4 c1 45 5f c0                       
  1751 : vmaxpd       ymm0, ymm0, ymm15                  ; c4 c1 7d 5f c7                       
  1752 : vroundps     ymm0, ymm0, 0x001                  ; c4 e3 7d 08 c0 01                    
  1753 : vroundps     ymm7, ymm0, 0x001                  ; c4 e3 7d 08 f8 01                    
  1754 : vroundps     ymm0, ymm7, 0x001                  ; c4 e3 7d 08 c7 01                    
  1755 : vroundps     ymm8, ymm0, 0x001                  ; c4 63 7d 08 c0 01                    
  1756 : vroundps     ymm15, ymm0, 0x001                 ; c4 63 7d 08 f8 01                    
  1757 : vroundps     ymm8, ymm7, 0x001                  ; c4 63 7d 08 c7 01                    
  1758 : vroundps     ymm0, ymm8, 0x001                  ; c4 c3 7d 08 c0 01                    
  1759 : vroundps     ymm7, ymm8, 0x001                  ; c4 c3 7d 08 f8 01                    
  1760 : vroundps     ymm0, ymm15, 0x001                 ; c4 c3 7d 08 c7 01                    
  1761 : vroundps     ymm8, ymm8, 0x001                  ; c4 43 7d 08 c0 01                    
  1762 : vroundps     ymm15, ymm8, 0x001                 ; c4 43 7d 08 f8 01                    
  1763 : vroundps     ymm8, ymm15, 0x001                 ; c4 43 7d 08 c7 01                    
  1764 : vroundpd     ymm0, ymm0, 0x001                  ; c4 e3 7d 09 c0 01                    
  1765 : vroundpd     ymm7, ymm0, 0x001                  ; c4 e3 7d 09 f8 01                    
  1766 : vroundpd     ymm0, ymm7, 0x001                  ; c4 e3 7d 09 c7 01                    
  1767 : vroundpd     ymm8, ymm0, 0x001                  ; c4 63 7d 09 c0 01                    
  1768 : vroundpd     ymm15, ymm0, 0x001                 ; c4 63 7d 09 f8 01                    
  1769 : vroundpd     ymm8, ymm7, 0x001                  ; c4 63 7d 09 c7 01                    
  1770 : vroundpd     ymm0, ymm8, 0x001                  ; c4 c3 7d 09 c0 01                    
  1771 : vroundpd     ymm7, ymm8, 0x001                  ; c4 c3 7d 09 f8 01                    
  1772 : vroundpd     ymm0, ymm15, 0x001                 ; c4 c3 7d 09 c7 01                    
  1773 : vroundpd     ymm8, ymm8, 0x001                  ; c4 43 7d 09 c0 01                    
  1774 : vroundpd     ymm15, ymm8, 0x001                 ; c4 43 7d 09 f8 01                    
  1775 : vroundpd     ymm8, ymm15, 0x001                 ; c4 43 7d 09 c7 01                    
  1776 : vroundps     ymm0, ymm0, 0x003                  ; c4 e3 7d 08 c0 03                    
  1777 : vroundps     ymm7, ymm0, 0x003                  ; c4 e3 7d 08 f8 03                    
  1778 : vroundps     ymm0, ymm7, 0x003                  ; c4 e3 7d 08 c7 03                    
  1779 : vroundps     ymm8, ymm0, 0x003                  ; c4 63 7d 08 c0 03                    
  1780 : vroundps     ymm15, ymm0, 0x003                 ; c4 63 7d 08 f8 03                    
  1781 : vroundps     ymm8, ymm7, 0x003                  ; c4 63 7d 08 c7 03                    
  1782 : vroundps     ymm0, ymm8, 0x003                  ; c4 c3 7d 08 c0 03                    
  1783 : vroundps     ymm7, ymm8, 0x003                  ; c4 c3 7d 08 f8 03                    
  1784 : vroundps     ymm0, ymm15, 0x003                 ; c4 c3 7d 08 c7 03                    
  1785 : vroundps     ymm8, ymm8, 0x003                  ; c4 43 7d 08 c0 03                    
  1786 : vroundps     ymm15, ymm8, 0x003                 ; c4 43 7d 08 f8 03                    
  1787 : vroundps     ymm8, ymm15, 0x003                 ; c4 43 7d 08 c7 03                    
  1788 : vroundpd     ymm0, ymm0, 0x003                  ; c4 e3 7d 09 c0 03                    
  1789 : vroundpd     ymm7, ymm0, 0x003                  ; c4 e3 7d 09 f8 03                    
  1790 : vroundpd     ymm0, ymm7, 0x003                  ; c4 e3 7d 09 c7 03                    
  1791 : vroundpd     ymm8, ymm0, 0x003                  ; c4 63 7d 09 c0 03                    
  1792 : vroundpd     ymm15, ymm0, 0x003                 ; c4 63 7d 09 f8 03                    
  1793 : vroundpd     ymm8, ymm7, 0x003                  ; c4 63 7d 09 c7 03                    
  1794 : vroundpd     ymm0, ymm8, 0x003                  ; c4 c3 7d 09 c0 03                    
  1795 : vroundpd     ymm7, ymm8, 0x003                  ; c4 c3 7d 09 f8 03                    
  1796 : vroundpd     ymm0, ymm15, 0x003                 ; c4 c3 7d 09 c7 03                    
  1797 : vroundpd     ymm8, ymm8, 0x003                  ; c4 43 7d 09 c0 03                    
  1798 : vroundpd     ymm15, ymm8, 0x003                 ; c4 43 7d 09 f8 03                    
  1799 : vroundpd     ymm8, ymm15, 0x003                 ; c4 43 7d 09 c7 03                    
  1800 : vcvtps2dq    ymm0, ymm0                         ; c5 fd 5b c0                          
  1801 : vcvtps2dq    ymm7, ymm0                         ; c5 fd 5b f8                          
  1802 : vcvtps2dq    ymm0, ymm7                         ; c5 fd 5b c7                          
  1803 : vcvtps2dq    ymm8, ymm0                         ; c5 7d 5b c0                          
  1804 : vcvtps2dq    ymm15, ymm0                        ; c5 7d 5b f8                          
  1805 : vcvtps2dq    ymm8, ymm7                         ; c5 7d 5b c7                          
  1806 : vcvtps2dq    ymm0, ymm8                         ; c4 c1 7d 5b c0                       
  1807 : vcvtps2dq    ymm7, ymm8                         ; c4 c1 7d 5b f8                       
  1808 : vcvtps2dq    ymm0, ymm15                        ; c4 c1 7d 5b c7                       
  1809 : vcvtps2dq    ymm8, ymm8                         ; c4 41 7d 5b c0                       
  1810 : vcvtps2dq    ymm15, ymm8                        ; c4 41 7d 5b f8                       
  1811 : vcvtps2dq    ymm8, ymm15                        ; c4 41 7d 5b c7                       
  1812 : vcvtpd2dq    xmm0, ymm0                         ; c5 ff e6 c0                          
  1813 : vcvtpd2dq    xmm7, ymm0                         ; c5 ff e6 f8                          
  1814 : vcvtpd2dq    xmm0, ymm7                         ; c5 ff e6 c7                          
  1815 : vcvtpd2dq    xmm8, ymm0                         ; c5 7f e6 c0                          
  1816 : vcvtpd2dq    xmm15, ymm0                        ; c5 7f e6 f8                          
  1817 : vcvtpd2dq    xmm8, ymm7                         ; c5 7f e6 c7                          
  1818 : vcvtpd2dq    xmm0, ymm8                         ; c4 c1 7f e6 c0                       
  1819 : vcvtpd2dq    xmm7, ymm8                         ; c4 c1 7f e6 f8                       
  1820 : vcvtpd2dq    xmm0, ymm15                        ; c4 c1 7f e6 c7                       
  1821 : vcvtpd2dq    xmm8, ymm8                         ; c4 41 7f e6 c0                       
  1822 : vcvtpd2dq    xmm15, ymm8                        ; c4 41 7f e6 f8                       
  1823 : vcvtpd2dq    xmm8, ymm15                        ; c4 41 7f e6 c7                       
  1824 : vcvtdq2ps    ymm0, ymm0                         ; c5 fc 5b c0                          
  1825 : vcvtdq2ps    ymm7, ymm0                         ; c5 fc 5b f8                          
  1826 : vcvtdq2ps    ymm0, ymm7                         ; c5 fc 5b c7                          
  1827 : vcvtdq2ps    ymm8, ymm0                         ; c5 7c 5b c0                          
  1828 : vcvtdq2ps    ymm15, ymm0                        ; c5 7c 5b f8                          
  1829 : vcvtdq2ps    ymm8, ymm7                         ; c5 7c 5b c7                          
  1830 : vcvtdq2ps    ymm0, ymm8                         ; c4 c1 7c 5b c0                       
  1831 : vcvtdq2ps    ymm7, ymm8                         ; c4 c1 7c 5b f8                       
  1832 : vcvtdq2ps    ymm0, ymm15                        ; c4 c1 7c 5b c7                       
  1833 : vcvtdq2ps    ymm8, ymm8                         ; c4 41 7c 5b c0                       
  1834 : vcvtdq2ps    ymm15, ymm8                        ; c4 41 7c 5b f8                       
  1835 : vcvtdq2ps    ymm8, ymm15                        ; c4 41 7c 5b c7                       
  1836 : vpmovsxbw    ymm0, xmm0                         ; c4 e2 7d 20 c0                       
  1837 : vpmovsxbw    ymm7, xmm0                         ; c4 e2 7d 20 f8                       
  1838 : vpmovsxbw    ymm0, xmm7                         ; c4 e2 7d 20 c7                       
  1839 : vpmovsxbw    ymm8, xmm0                         ; c4 62 7d 20 c0                       
  1840 : vpmovsxbw    ymm15, xmm0                        ; c4 62 7d 20 f8                       
  1841 : vpmovsxbw    ymm8, xmm7                         ; c4 62 7d 20 c7                       
  1842 : vpmovsxbw    ymm0, xmm8                         ; c4 c2 7d 20 c0                       
  1843 : vpmovsxbw    ymm7, xmm8                         ; c4 c2 7d 20 f8                       
  1844 : vpmovsxbw    ymm0, xmm15                        ; c4 c2 7d 20 c7                       
  1845 : vpmovsxbw    ymm8, xmm8                         ; c4 42 7d 20 c0                       
  1846 : vpmovsxbw    ymm15, xmm8                        ; c4 42 7d 20 f8                       
  1847 : vpmovsxbw    ymm8, xmm15                        ; c4 42 7d 20 c7                       
  1848 : vpmovsxwd    ymm0, xmm0                         ; c4 e2 7d 23 c0                       
  1849 : vpmovsxwd    ymm7, xmm0                         ; c4 e2 7d 23 f8                       
  1850 : vpmovsxwd    ymm0, xmm7                         ; c4 e2 7d 23 c7                       
  1851 : vpmovsxwd    ymm8, xmm0                         ; c4 62 7d 23 c0                       
  1852 : vpmovsxwd    ymm15, xmm0                        ; c4 62 7d 23 f8                       
  1853 : vpmovsxwd    ymm8, xmm7                         ; c4 62 7d 23 c7                       
  1854 : vpmovsxwd    ymm0, xmm8                         ; c4 c2 7d 23 c0                       
  1855 : vpmovsxwd    ymm7, xmm8                         ; c4 c2 7d 23 f8                       
  1856 : vpmovsxwd    ymm0, xmm15                        ; c4 c2 7d 23 c7                       
  1857 : vpmovsxwd    ymm8, xmm8                         ; c4 42 7d 23 c0                       
  1858 : vpmovsxwd    ymm15, xmm8                        ; c4 42 7d 23 f8                       
  1859 : vpmovsxwd    ymm8, xmm15                        ; c4 42 7d 23 c7                       
  1860 : vpmovsxdq    ymm0, xmm0                         ; c4 e2 7d 25 c0                       
  1861 : vpmovsxdq    ymm7, xmm0                         ; c4 e2 7d 25 f8                       
  1862 : vpmovsxdq    ymm0, xmm7                         ; c4 e2 7d 25 c7                       
  1863 : vpmovsxdq    ymm8, xmm0                         ; c4 62 7d 25 c0                       
  1864 : vpmovsxdq    ymm15, xmm0                        ; c4 62 7d 25 f8                       
  1865 : vpmovsxdq    ymm8, xmm7                         ; c4 62 7d 25 c7                       
  1866 : vpmovsxdq    ymm0, xmm8                         ; c4 c2 7d 25 c0                       
  1867 : vpmovsxdq    ymm7, xmm8                         ; c4 c2 7d 25 f8                       
  1868 : vpmovsxdq    ymm0, xmm15                        ; c4 c2 7d 25 c7                       
  1869 : vpmovsxdq    ymm8, xmm8                         ; c4 42 7d 25 c0                       
  1870 : vpmovsxdq    ymm15, xmm8                        ; c4 42 7d 25 f8                       
  1871 : vpmovsxdq    ymm8, xmm15                        ; c4 42 7d 25 c7                       
  1872 : vpmovzxbw    ymm0, xmm0                         ; c4 e2 7d 30 c0                       
  1873 : vpmovzxbw    ymm7, xmm0                         ; c4 e2 7d 30 f8                       
  1874 : vpmovzxbw    ymm0, xmm7                         ; c4 e2 7d 30 c7                       
  1875 : vpmovzxbw    ymm8, xmm0                         ; c4 62 7d 30 c0                       
  1876 : vpmovzxbw    ymm15, xmm0                        ; c4 62 7d 30 f8                       
  1877 : vpmovzxbw    ymm8, xmm7                         ; c4 62 7d 30 c7                       
  1878 : vpmovzxbw    ymm0, xmm8                         ; c4 c2 7d 30 c0                       
  1879 : vpmovzxbw    ymm7, xmm8                         ; c4 c2 7d 30 f8                       
  1880 : vpmovzxbw    ymm0, xmm15                        ; c4 c2 7d 30 c7                       
  1881 : vpmovzxbw    ymm8, xmm8                         ; c4 42 7d 30 c0                       
  1882 : vpmovzxbw    ymm15, xmm8                        ; c4 42 7d 30 f8                       
  1883 : vpmovzxbw    ymm8, xmm15                        ; c4 42 7d 30 c7                       
  1884 : vpmovzxwd    ymm0, xmm0                         ; c4 e2 7d 33 c0                       
  1885 : vpmovzxwd    ymm7, xmm0                         ; c4 e2 7d 33 f8                       
  1886 : vpmovzxwd    ymm0, xmm7                         ; c4 e2 7d 33 c7                       
  1887 : vpmovzxwd    ymm8, xmm0                         ; c4 62 7d 33 c0                       
  1888 : vpmovzxwd    ymm15, xmm0                        ; c4 62 7d 33 f8                       
  1889 : vpmovzxwd    ymm8, xmm7                         ; c4 62 7d 33 c7                       
  1890 : vpmovzxwd    ymm0, xmm8                         ; c4 c2 7d 33 c0                       
  1891 : vpmovzxwd    ymm7, xmm8                         ; c4 c2 7d 33 f8                       
  1892 : vpmovzxwd    ymm0, xmm15                        ; c4 c2 7d 33 c7                       
  1893 : vpmovzxwd    ymm8, xmm8                         ; c4 42 7d 33 c0                       
  1894 : vpmovzxwd    ymm15, xmm8                        ; c4 42 7d 33 f8                       
  1895 : vpmovzxwd    ymm8, xmm15                        ; c4 42 7d 33 c7                       
  1896 : vpmovzxdq    ymm0, xmm0                         ; c4 e2 7d 35 c0                       
  1897 : vpmovzxdq    ymm7, xmm0                         ; c4 e2 7d 35 f8                       
  1898 : vpmovzxdq    ymm0, xmm7                         ; c4 e2 7d 35 c7                       
  1899 : vpmovzxdq    ymm8, xmm0                         ; c4 62 7d 35 c0                       
  1900 : vpmovzxdq    ymm15, xmm0                        ; c4 62 7d 35 f8                       
  1901 : vpmovzxdq    ymm8, xmm7                         ; c4 62 7d 35 c7                       
  1902 : vpmovzxdq    ymm0, xmm8                         ; c4 c2 7d 35 c0                       
  1903 : vpmovzxdq    ymm7, xmm8                         ; c4 c2 7d 35 f8                       
  1904 : vpmovzxdq    ymm0, xmm15                        ; c4 c2 7d 35 c7                       
  1905 : vpmovzxdq    ymm8, xmm8                         ; c4 42 7d 35 c0                       
  1906 : vpmovzxdq    ymm15, xmm8                        ; c4 42 7d 35 f8                       
  1907 : vpmovzxdq    ymm8, xmm15                        ; c4 42 7d 35 c7                       
  1908 : vcvtps2pd    ymm0, xmm0                         ; c5 fc 5a c0                          
  1909 : vcvtps2pd    ymm7, xmm0                         ; c5 fc 5a f8                          
  1910 : vcvtps2pd    ymm0, xmm7                         ; c5 fc 5a c7                          
  1911 : vcvtps2pd    ymm8, xmm0                         ; c5 7c 5a c0                          
  1912 : vcvtps2pd    ymm15, xmm0                        ; c5 7c 5a f8                          
  1913 : vcvtps2pd    ymm8, xmm7                         ; c5 7c 5a c7                          
  1914 : vcvtps2pd    ymm0, xmm8                         ; c4 c1 7c 5a c0                       
  1915 : vcvtps2pd    ymm7, xmm8                         ; c4 c1 7c 5a f8                       
  1916 : vcvtps2pd    ymm0, xmm15                        ; c4 c1 7c 5a c7                       
  1917 : vcvtps2pd    ymm8, xmm8                         ; c4 41 7c 5a c0                       
  1918 : vcvtps2pd    ymm15, xmm8                        ; c4 41 7c 5a f8                       
  1919 : vcvtps2pd    ymm8, xmm15                        ; c4 41 7c 5a c7                       
  1920 : vpand        ymm0, ymm0, ymm0                   ; c5 fd db c0                          
  1921 : vpand        ymm7, ymm0, ymm0                   ; c5 fd db f8                          
  1922 : vpand        ymm0, ymm7, ymm0                   ; c5 c5 db c0                          
  1923 : vpand        ymm0, ymm0, ymm7                   ; c5 fd db c7                          
  1924 : vpand        ymm8, ymm0, ymm0                   ; c5 7d db c0                          
  1925 : vpand        ymm15, ymm0, ymm0                  ; c5 7d db f8                          
  1926 : vpand        ymm8, ymm7, ymm0                   ; c5 45 db c0                          
  1927 : vpand        ymm8, ymm0, ymm7                   ; c5 7d db c7                          
  1928 : vpand        ymm0, ymm8, ymm0                   ; c5 bd db c0                          
  1929 : vpand        ymm7, ymm8, ymm0                   ; c5 bd db f8                          
  1930 : vpand        ymm0, ymm15, ymm0                  ; c5 85 db c0                          
  1931 : vpand        ymm0, ymm8, ymm7                   ; c5 bd db c7                          
  1932 : vpand        ymm0, ymm0, ymm8                   ; c4 c1 7d db c0                       
  1933 : vpand        ymm7, ymm0, ymm8                   ; c4 c1 7d db f8                       
  1934 : vpand        ymm0, ymm7, ymm8                   ; c4 c1 45 db c0                       
  1935 : vpand        ymm0, ymm0, ymm15                  ; c4 c1 7d db c7                       
  1936 : vpor         ymm0, ymm0, ymm0                   ; c5 fd eb c0                          
  1937 : vpor         ymm7, ymm0, ymm0                   ; c5 fd eb f8                          
  1938 : vpor         ymm0, ymm7, ymm0                   ; c5 c5 eb c0                          
  1939 : vpor         ymm0, ymm0, ymm7                   ; c5 fd eb c7                          
  1940 : vpor         ymm8, ymm0, ymm0                   ; c5 7d eb c0                          
  1941 : vpor         ymm15, ymm0, ymm0                  ; c5 7d eb f8                          
  1942 : vpor         ymm8, ymm7, ymm0                   ; c5 45 eb c0                          
  1943 : vpor         ymm8, ymm0, ymm7                   ; c5 7d eb c7                          
  1944 : vpor         ymm0, ymm8, ymm0                   ; c5 bd eb c0                          
  1945 : vpor         ymm7, ymm8, ymm0                   ; c5 bd eb f8                          
  1946 : vpor         ymm0, ymm15, ymm0                  ; c5 85 eb c0                          
  1947 : vpor         ymm0, ymm8, ymm7                   ; c5 bd eb c7                          
  1948 : vpor         ymm0, ymm0, ymm8                   ; c4 c1 7d eb c0                       
  1949 : vpor         ymm7, ymm0, ymm8                   ; c4 c1 7d eb f8                       
  1950 : vpor         ymm0, ymm7, ymm8                   ; c4 c1 45 eb c0                       
  1951 : vpor         ymm0, ymm0, ymm15                  ; c4 c1 7d eb c7                       
  1952 : vpxor        ymm0, ymm0, ymm0                   ; c5 fd ef c0                          
  1953 : vpxor        ymm7, ymm0, ymm0                   ; c5 fd ef f8                          
  1954 : vpxor        ymm0, ymm7, ymm0                   ; c5 c5 ef c0                          
  1955 : vpxor        ymm0, ymm0, ymm7                   ; c5 fd ef c7                          
  1956 : vpxor        ymm8, ymm0, ymm0                   ; c5 7d ef c0                          
  1957 : vpxor        ymm15, ymm0, ymm0                  ; c5 7d ef f8                          
  1958 : vpxor        ymm8, ymm7, ymm0                   ; c5 45 ef c0                          
  1959 : vpxor        ymm8, ymm0, ymm7                   ; c5 7d ef c7                          
  1960 : vpxor        ymm0, ymm8, ymm0                   ; c5 bd ef c0                          
  1961 : vpxor        ymm7, ymm8, ymm0                   ; c5 bd ef f8                          
  1962 : vpxor        ymm0, ymm15, ymm0                  ; c5 85 ef c0                          
  1963 : vpxor        ymm0, ymm8, ymm7                   ; c5 bd ef c7                          
  1964 : vpxor        ymm0, ymm0, ymm8                   ; c4 c1 7d ef c0                       
  1965 : vpxor        ymm7, ymm0, ymm8                   ; c4 c1 7d ef f8                       
  1966 : vpxor        ymm0, ymm7, ymm8                   ; c4 c1 45 ef c0                       
  1967 : vpxor        ymm0, ymm0, ymm15                  ; c4 c1 7d ef c7                       
  1968 : vpsllw       ymm0, ymm0, 0x00f                  ; c5 fd 71 f0 0f                       
  1969 : vpsllw       ymm7, ymm0, 0x00f                  ; c5 c5 71 f0 0f                       
  1970 : vpsllw       ymm0, ymm7, 0x00f                  ; c5 fd 71 f7 0f                       
  1971 : vpsllw       ymm8, ymm0, 0x00f                  ; c5 bd 71 f0 0f                       
  1972 : vpsllw       ymm15, ymm0, 0x00f                 ; c5 85 71 f0 0f                       
  1973 : vpsllw       ymm8, ymm7, 0x00f                  ; c5 bd 71 f7 0f                       
  1974 : vpsllw       ymm0, ymm8, 0x00f                  ; c4 c1 7d 71 f0 0f                    
  1975 : vpsllw       ymm7, ymm8, 0x00f                  ; c4 c1 45 71 f0 0f                    
  1976 : vpsllw       ymm0, ymm15, 0x00f                 ; c4 c1 7d 71 f7 0f                    
  1977 : vpsllw       ymm8, ymm8, 0x00f                  ; c4 c1 3d 71 f0 0f                    
  1978 : vpsllw       ymm15, ymm8, 0x00f                 ; c4 c1 05 71 f0 0f                    
  1979 : vpsllw       ymm8, ymm15, 0x00f                 ; c4 c1 3d 71 f7 0f                    
  1980 : vpslld       ymm0, ymm0, 0x00f                  ; c5 fd 72 f0 0f                       
  1981 : vpslld       ymm7, ymm0, 0x00f                  ; c5 c5 72 f0 0f                       
  1982 : vpslld       ymm0, ymm7, 0x00f                  ; c5 fd 72 f7 0f                       
  1983 : vpslld       ymm8, ymm0, 0x00f                  ; c5 bd 72 f0 0f                       
  1984 : vpslld       ymm15, ymm0, 0x00f                 ; c5 85 72 f0 0f                       
  1985 : vpslld       ymm8, ymm7, 0x00f                  ; c5 bd 72 f7 0f                       
  1986 : vpslld       ymm0, ymm8, 0x00f                  ; c4 c1 7d 72 f0 0f                    
  1987 : vpslld       ymm7, ymm8, 0x00f                  ; c4 c1 45 72 f0 0f                    
  1988 : vpslld       ymm0, ymm15, 0x00f                 ; c4 c1 7d 72 f7 0f                    
  1989 : vpslld       ymm8, ymm8, 0x00f                  ; c4 c1 3d 72 f0 0f                    
  1990 : vpslld       ymm15, ymm8, 0x00f                 ; c4 c1 05 72 f0 0f                    
  1991 : vpslld       ymm8, ymm15, 0x00f                 ; c4 c1 3d 72 f7 0f                    
  1992 : vpsllq       ymm0, ymm0, 0x00f                  ; c5 fd 73 f0 0f                       
  1993 : vpsllq       ymm7, ymm0, 0x00f                  ; c5 c5 73 f0 0f                       
  1994 : vpsllq       ymm0, ymm7, 0x00f                  ; c5 fd 73 f7 0f                       
  1995 : vpsllq       ymm8, ymm0, 0x00f                  ; c5 bd 73 f0 0f                       
  1996 : vpsllq       ymm15, ymm0, 0x00f                 ; c5 85 73 f0 0f                       
  1997 : vpsllq       ymm8, ymm7, 0x00f                  ; c5 bd 73 f7 0f                       
  1998 : vpsllq       ymm0, ymm8, 0x00f                  ; c4 c1 7d 73 f0 0f                    
  1999 : vpsllq       ymm7, ymm8, 0x00f                  ; c4 c1 45 73 f0 0f                    
  2000 : vpsllq       ymm0, ymm15, 0x00f                 ; c4 c1 7d 73 f7 0f                    
  2001 : vpsllq       ymm8, ymm8, 0x00f                  ; c4 c1 3d 73 f0 0f                    
  2002 : vpsllq       ymm15, ymm8, 0x00f                 ; c4 c1 05 73 f0 0f                    
  2003 : vpsllq       ymm8, ymm15, 0x00f                 ; c4 c1 3d 73 f7 0f                    
  2004 : vpsllvd      ymm0, ymm0, ymm0                   ; c4 e2 7d 47 c0                       
  2005 : vpsllvd      ymm7, ymm0, ymm0                   ; c4 e2 7d 47 f8                       
  2006 : vpsllvd      ymm0, ymm7, ymm0                   ; c4 e2 45 47 c0                       
  2007 : vpsllvd      ymm0, ymm0, ymm7                   ; c4 e2 7d 47 c7                       
  2008 : vpsllvd      ymm8, ymm0, ymm0                   ; c4 62 7d 47 c0                       
  2009 : vpsllvd      ymm15, ymm0, ymm0                  ; c4 62 7d 47 f8                       
  2010 : vpsllvd      ymm8, ymm7, ymm0                   ; c4 62 45 47 c0                       
  2011 : vpsllvd      ymm8, ymm0, ymm7                   ; c4 62 7d 47 c7                       
  2012 : vpsllvd      ymm0, ymm8, ymm0                   ; c4 e2 3d 47 c0                       
  2013 : vpsllvd      ymm7, ymm8, ymm0                   ; c4 e2 3d 47 f8                       
  2014 : vpsllvd      ymm0, ymm15, ymm0                  ; c4 e2 05 47 c0                       
  2015 : vpsllvd      ymm0, ymm8, ymm7                   ; c4 e2 3d 47 c7                       
  2016 : vpsllvd      ymm0, ymm0, ymm8                   ; c4 c2 7d 47 c0                       
  2017 : vpsllvd      ymm7, ymm0, ymm8                   ; c4 c2 7d 47 f8                       
  2018 : vpsllvd      ymm0, ymm7, ymm8                   ; c4 c2 45 47 c0                       
  2019 : vpsllvd      ymm0, ymm0, ymm15                  ; c4 c2 7d 47 c7                       
  2020 : vpsllvq      ymm0, ymm0, ymm0                   ; c4 e2 fd 47 c0                       
  2021 : vpsllvq      ymm7, ymm0, ymm0                   ; c4 e2 fd 47 f8                       
  2022 : vpsllvq      ymm0, ymm7, ymm0                   ; c4 e2 c5 47 c0                       
  2023 : vpsllvq      ymm0, ymm0, ymm7                   ; c4 e2 fd 47 c7                       
  2024 : vpsllvq      ymm8, ymm0, ymm0                   ; c4 62 fd 47 c0                       
  2025 : vpsllvq      ymm15, ymm0, ymm0                  ; c4 62 fd 47 f8                       
  2026 : vpsllvq      ymm8, ymm7, ymm0                   ; c4 62 c5 47 c0                       
  2027 : vpsllvq      ymm8, ymm0, ymm7                   ; c4 62 fd 47 c7                       
  2028 : vpsllvq      ymm0, ymm8, ymm0                   ; c4 e2 bd 47 c0                       
  2029 : vpsllvq      ymm7, ymm8, ymm0                   ; c4 e2 bd 47 f8                       
  2030 : vpsllvq      ymm0, ymm15, ymm0                  ; c4 e2 85 47 c0                       
  2031 : vpsllvq      ymm0, ymm8, ymm7                   ; c4 e2 bd 47 c7                       
  2032 : vpsllvq      ymm0, ymm0, ymm8                   ; c4 c2 fd 47 c0                       
  2033 : vpsllvq      ymm7, ymm0, ymm8                   ; c4 c2 fd 47 f8                       
  2034 : vpsllvq      ymm0, ymm7, ymm8                   ; c4 c2 c5 47 c0                       
  2035 : vpsllvq      ymm0, ymm0, ymm15                  ; c4 c2 fd 47 c7                       
  2036 : vpsraw       ymm0, ymm0, 0x00f                  ; c5 fd 71 e0 0f                       
  2037 : vpsraw       ymm7, ymm0, 0x00f                  ; c5 c5 71 e0 0f                       
  2038 : vpsraw       ymm0, ymm7, 0x00f                  ; c5 fd 71 e7 0f                       
  2039 : vpsraw       ymm8, ymm0, 0x00f                  ; c5 bd 71 e0 0f                       
  2040 : vpsraw       ymm15, ymm0, 0x00f                 ; c5 85 71 e0 0f                       
  2041 : vpsraw       ymm8, ymm7, 0x00f                  ; c5 bd 71 e7 0f                       
  2042 : vpsraw       ymm0, ymm8, 0x00f                  ; c4 c1 7d 71 e0 0f                    
  2043 : vpsraw       ymm7, ymm8, 0x00f                  ; c4 c1 45 71 e0 0f                    
  2044 : vpsraw       ymm0, ymm15, 0x00f                 ; c4 c1 7d 71 e7 0f                    
  2045 : vpsraw       ymm8, ymm8, 0x00f                  ; c4 c1 3d 71 e0 0f                    
  2046 : vpsraw       ymm15, ymm8, 0x00f                 ; c4 c1 05 71 e0 0f                    
  2047 : vpsraw       ymm8, ymm15, 0x00f                 ; c4 c1 3d 71 e7 0f                    
  2048 : vpsrad       ymm0, ymm0, 0x00f                  ; c5 fd 72 e0 0f                       
  2049 : vpsrad       ymm7, ymm0, 0x00f                  ; c5 c5 72 e0 0f                       
  2050 : vpsrad       ymm0, ymm7, 0x00f                  ; c5 fd 72 e7 0f                       
  2051 : vpsrad       ymm8, ymm0, 0x00f                  ; c5 bd 72 e0 0f                       
  2052 : vpsrad       ymm15, ymm0, 0x00f                 ; c5 85 72 e0 0f                       
  2053 : vpsrad       ymm8, ymm7, 0x00f                  ; c5 bd 72 e7 0f                       
  2054 : vpsrad       ymm0, ymm8, 0x00f                  ; c4 c1 7d 72 e0 0f                    
  2055 : vpsrad       ymm7, ymm8, 0x00f                  ; c4 c1 45 72 e0 0f                    
  2056 : vpsrad       ymm0, ymm15, 0x00f                 ; c4 c1 7d 72 e7 0f                    
  2057 : vpsrad       ymm8, ymm8, 0x00f                  ; c4 c1 3d 72 e0 0f                    
  2058 : vpsrad       ymm15, ymm8, 0x00f                 ; c4 c1 05 72 e0 0f                    
  2059 : vpsrad       ymm8, ymm15, 0x00f                 ; c4 c1 3d 72 e7 0f                    
  2060 : vpsravd      ymm0, ymm0, ymm0                   ; c4 e2 7d 46 c0                       
  2061 : vpsravd      ymm7, ymm0, ymm0                   ; c4 e2 7d 46 f8                       
  2062 : vpsravd      ymm0, ymm7, ymm0                   ; c4 e2 45 46 c0                       
  2063 : vpsravd      ymm0, ymm0, ymm7                   ; c4 e2 7d 46 c7                       
  2064 : vpsravd      ymm8, ymm0, ymm0                   ; c4 62 7d 46 c0                       
  2065 : vpsravd      ymm15, ymm0, ymm0                  ; c4 62 7d 46 f8                       
  2066 : vpsravd      ymm8, ymm7, ymm0                   ; c4 62 45 46 c0                       
  2067 : vpsravd      ymm8, ymm0, ymm7                   ; c4 62 7d 46 c7                       
  2068 : vpsravd      ymm0, ymm8, ymm0                   ; c4 e2 3d 46 c0                       
  2069 : vpsravd      ymm7, ymm8, ymm0                   ; c4 e2 3d 46 f8                       
  2070 : vpsravd      ymm0, ymm15, ymm0                  ; c4 e2 05 46 c0                       
  2071 : vpsravd      ymm0, ymm8, ymm7                   ; c4 e2 3d 46 c7                       
  2072 : vpsravd      ymm0, ymm0, ymm8                   ; c4 c2 7d 46 c0                       
  2073 : vpsravd      ymm7, ymm0, ymm8                   ; c4 c2 7d 46 f8                       
  2074 : vpsravd      ymm0, ymm7, ymm8                   ; c4 c2 45 46 c0                       
  2075 : vpsravd      ymm0, ymm0, ymm15                  ; c4 c2 7d 46 c7                       
  2076 : vpsrlw       ymm0, ymm0, 0x00f                  ; c5 fd 71 d0 0f                       
  2077 : vpsrlw       ymm7, ymm0, 0x00f                  ; c5 c5 71 d0 0f                       
  2078 : vpsrlw       ymm0, ymm7, 0x00f                  ; c5 fd 71 d7 0f                       
  2079 : vpsrlw       ymm8, ymm0, 0x00f                  ; c5 bd 71 d0 0f                       
  2080 : vpsrlw       ymm15, ymm0, 0x00f                 ; c5 85 71 d0 0f                       
  2081 : vpsrlw       ymm8, ymm7, 0x00f                  ; c5 bd 71 d7 0f                       
  2082 : vpsrlw       ymm0, ymm8, 0x00f                  ; c4 c1 7d 71 d0 0f                    
  2083 : vpsrlw       ymm7, ymm8, 0x00f                  ; c4 c1 45 71 d0 0f                    
  2084 : vpsrlw       ymm0, ymm15, 0x00f                 ; c4 c1 7d 71 d7 0f                    
  2085 : vpsrlw       ymm8, ymm8, 0x00f                  ; c4 c1 3d 71 d0 0f                    
  2086 : vpsrlw       ymm15, ymm8, 0x00f                 ; c4 c1 05 71 d0 0f                    
  2087 : vpsrlw       ymm8, ymm15, 0x00f                 ; c4 c1 3d 71 d7 0f                    
  2088 : vpsrld       ymm0, ymm0, 0x00f                  ; c5 fd 72 d0 0f                       
  2089 : vpsrld       ymm7, ymm0, 0x00f                  ; c5 c5 72 d0 0f                       
  2090 : vpsrld       ymm0, ymm7, 0x00f                  ; c5 fd 72 d7 0f                       
  2091 : vpsrld       ymm8, ymm0, 0x00f                  ; c5 bd 72 d0 0f                       
  2092 : vpsrld       ymm15, ymm0, 0x00f                 ; c5 85 72 d0 0f                       
  2093 : vpsrld       ymm8, ymm7, 0x00f                  ; c5 bd 72 d7 0f                       
  2094 : vpsrld       ymm0, ymm8, 0x00f                  ; c4 c1 7d 72 d0 0f                    
  2095 : vpsrld       ymm7, ymm8, 0x00f                  ; c4 c1 45 72 d0 0f                    
  2096 : vpsrld       ymm0, ymm15, 0x00f                 ; c4 c1 7d 72 d7 0f                    
  2097 : vpsrld       ymm8, ymm8, 0x00f                  ; c4 c1 3d 72 d0 0f                    
  2098 : vpsrld       ymm15, ymm8, 0x00f                 ; c4 c1 05 72 d0 0f                    
  2099 : vpsrld       ymm8, ymm15, 0x00f                 ; c4 c1 3d 72 d7 0f                    
  2100 : vpsrlq       ymm0, ymm0, 0x00f                  ; c5 fd 73 d0 0f                       
  2101 : vpsrlq       ymm7, ymm0, 0x00f                  ; c5 c5 73 d0 0f                       
  2102 : vpsrlq       ymm0, ymm7, 0x00f                  ; c5 fd 73 d7 0f                       
  2103 : vpsrlq       ymm8, ymm0, 0x00f                  ; c5 bd 73 d0 0f                       
  2104 : vpsrlq       ymm15, ymm0, 0x00f                 ; c5 85 73 d0 0f                       
  2105 : vpsrlq       ymm8, ymm7, 0x00f                  ; c5 bd 73 d7 0f                       
  2106 : vpsrlq       ymm0, ymm8, 0x00f                  ; c4 c1 7d 73 d0 0f                    
  2107 : vpsrlq       ymm7, ymm8, 0x00f                  ; c4 c1 45 73 d0 0f                    
  2108 : vpsrlq       ymm0, ymm15, 0x00f                 ; c4 c1 7d 73 d7 0f                    
  2109 : vpsrlq       ymm8, ymm8, 0x00f                  ; c4 c1 3d 73 d0 0f                    
  2110 : vpsrlq       ymm15, ymm8, 0x00f                 ; c4 c1 05 73 d0 0f                    
  2111 : vpsrlq       ymm8, ymm15, 0x00f                 ; c4 c1 3d 73 d7 0f                    
  2112 : vpsrlvd      ymm0, ymm0, ymm0                   ; c4 e2 7d 45 c0                       
  2113 : vpsrlvd      ymm7, ymm0, ymm0                   ; c4 e2 7d 45 f8                       
  2114 : vpsrlvd      ymm0, ymm7, ymm0                   ; c4 e2 45 45 c0                       
  2115 : vpsrlvd      ymm0, ymm0, ymm7                   ; c4 e2 7d 45 c7                       
  2116 : vpsrlvd      ymm8, ymm0, ymm0                   ; c4 62 7d 45 c0                       
  2117 : vpsrlvd      ymm15, ymm0, ymm0                  ; c4 62 7d 45 f8                       
  2118 : vpsrlvd      ymm8, ymm7, ymm0                   ; c4 62 45 45 c0                       
  2119 : vpsrlvd      ymm8, ymm0, ymm7                   ; c4 62 7d 45 c7                       
  2120 : vpsrlvd      ymm0, ymm8, ymm0                   ; c4 e2 3d 45 c0                       
  2121 : vpsrlvd      ymm7, ymm8, ymm0                   ; c4 e2 3d 45 f8                       
  2122 : vpsrlvd      ymm0, ymm15, ymm0                  ; c4 e2 05 45 c0                       
  2123 : vpsrlvd      ymm0, ymm8, ymm7                   ; c4 e2 3d 45 c7                       
  2124 : vpsrlvd      ymm0, ymm0, ymm8                   ; c4 c2 7d 45 c0                       
  2125 : vpsrlvd      ymm7, ymm0, ymm8                   ; c4 c2 7d 45 f8                       
  2126 : vpsrlvd      ymm0, ymm7, ymm8                   ; c4 c2 45 45 c0                       
  2127 : vpsrlvd      ymm0, ymm0, ymm15                  ; c4 c2 7d 45 c7                       
  2128 : vpsrlvq      ymm0, ymm0, ymm0                   ; c4 e2 fd 45 c0                       
  2129 : vpsrlvq      ymm7, ymm0, ymm0                   ; c4 e2 fd 45 f8                       
  2130 : vpsrlvq      ymm0, ymm7, ymm0                   ; c4 e2 c5 45 c0                       
  2131 : vpsrlvq      ymm0, ymm0, ymm7                   ; c4 e2 fd 45 c7                       
  2132 : vpsrlvq      ymm8, ymm0, ymm0                   ; c4 62 fd 45 c0                       
  2133 : vpsrlvq      ymm15, ymm0, ymm0                  ; c4 62 fd 45 f8                       
  2134 : vpsrlvq      ymm8, ymm7, ymm0                   ; c4 62 c5 45 c0                       
  2135 : vpsrlvq      ymm8, ymm0, ymm7                   ; c4 62 fd 45 c7                       
  2136 : vpsrlvq      ymm0, ymm8, ymm0                   ; c4 e2 bd 45 c0                       
  2137 : vpsrlvq      ymm7, ymm8, ymm0                   ; c4 e2 bd 45 f8                       
  2138 : vpsrlvq      ymm0, ymm15, ymm0                  ; c4 e2 85 45 c0                       
  2139 : vpsrlvq      ymm0, ymm8, ymm7                   ; c4 e2 bd 45 c7                       
  2140 : vpsrlvq      ymm0, ymm0, ymm8                   ; c4 c2 fd 45 c0                       
  2141 : vpsrlvq      ymm7, ymm0, ymm8                   ; c4 c2 fd 45 f8                       
  2142 : vpsrlvq      ymm0, ymm7, ymm8                   ; c4 c2 c5 45 c0                       
  2143 : vpsrlvq      ymm0, ymm0, ymm15                  ; c4 c2 fd 45 c7                       
  2144 : vpcmpeqb     ymm0, ymm0, ymm0                   ; c5 fd 74 c0                          
  2145 : vpcmpeqb     ymm7, ymm0, ymm0                   ; c5 fd 74 f8                          
  2146 : vpcmpeqb     ymm0, ymm7, ymm0                   ; c5 c5 74 c0                          
  2147 : vpcmpeqb     ymm0, ymm0, ymm7                   ; c5 fd 74 c7                          
  2148 : vpcmpeqb     ymm8, ymm0, ymm0                   ; c5 7d 74 c0                          
  2149 : vpcmpeqb     ymm15, ymm0, ymm0                  ; c5 7d 74 f8                          
  2150 : vpcmpeqb     ymm8, ymm7, ymm0                   ; c5 45 74 c0                          
  2151 : vpcmpeqb     ymm8, ymm0, ymm7                   ; c5 7d 74 c7                          
  2152 : vpcmpeqb     ymm0, ymm8, ymm0                   ; c5 bd 74 c0                          
  2153 : vpcmpeqb     ymm7, ymm8, ymm0                   ; c5 bd 74 f8                          
  2154 : vpcmpeqb     ymm0, ymm15, ymm0                  ; c5 85 74 c0                          
  2155 : vpcmpeqb     ymm0, ymm8, ymm7                   ; c5 bd 74 c7                          
  2156 : vpcmpeqb     ymm0, ymm0, ymm8                   ; c4 c1 7d 74 c0                       
  2157 : vpcmpeqb     ymm7, ymm0, ymm8                   ; c4 c1 7d 74 f8                       
  2158 : vpcmpeqb     ymm0, ymm7, ymm8                   ; c4 c1 45 74 c0                       
  2159 : vpcmpeqb     ymm0, ymm0, ymm15                  ; c4 c1 7d 74 c7                       
  2160 : vpcmpeqw     ymm0, ymm0, ymm0                   ; c5 fd 75 c0                          
  2161 : vpcmpeqw     ymm7, ymm0, ymm0                   ; c5 fd 75 f8                          
  2162 : vpcmpeqw     ymm0, ymm7, ymm0                   ; c5 c5 75 c0                          
  2163 : vpcmpeqw     ymm0, ymm0, ymm7                   ; c5 fd 75 c7                          
  2164 : vpcmpeqw     ymm8, ymm0, ymm0                   ; c5 7d 75 c0                          
  2165 : vpcmpeqw     ymm15, ymm0, ymm0                  ; c5 7d 75 f8                          
  2166 : vpcmpeqw     ymm8, ymm7, ymm0                   ; c5 45 75 c0                          
  2167 : vpcmpeqw     ymm8, ymm0, ymm7                   ; c5 7d 75 c7                          
  2168 : vpcmpeqw     ymm0, ymm8, ymm0                   ; c5 bd 75 c0                          
  2169 : vpcmpeqw     ymm7, ymm8, ymm0                   ; c5 bd 75 f8                          
  2170 : vpcmpeqw     ymm0, ymm15, ymm0                  ; c5 85 75 c0                          
  2171 : vpcmpeqw     ymm0, ymm8, ymm7                   ; c5 bd 75 c7                          
  2172 : vpcmpeqw     ymm0, ymm0, ymm8                   ; c4 c1 7d 75 c0                       
  2173 : vpcmpeqw     ymm7, ymm0, ymm8                   ; c4 c1 7d 75 f8                       
  2174 : vpcmpeqw     ymm0, ymm7, ymm8                   ; c4 c1 45 75 c0                       
  2175 : vpcmpeqw     ymm0, ymm0, ymm15                  ; c4 c1 7d 75 c7                       
  2176 : vpcmpeqd     ymm0, ymm0, ymm0                   ; c5 fd 76 c0                          
  2177 : vpcmpeqd     ymm7, ymm0, ymm0                   ; c5 fd 76 f8                          
  2178 : vpcmpeqd     ymm0, ymm7, ymm0                   ; c5 c5 76 c0                          
  2179 : vpcmpeqd     ymm0, ymm0, ymm7                   ; c5 fd 76 c7                          
  2180 : vpcmpeqd     ymm8, ymm0, ymm0                   ; c5 7d 76 c0                          
  2181 : vpcmpeqd     ymm15, ymm0, ymm0                  ; c5 7d 76 f8                          
  2182 : vpcmpeqd     ymm8, ymm7, ymm0                   ; c5 45 76 c0                          
  2183 : vpcmpeqd     ymm8, ymm0, ymm7                   ; c5 7d 76 c7                          
  2184 : vpcmpeqd     ymm0, ymm8, ymm0                   ; c5 bd 76 c0                          
  2185 : vpcmpeqd     ymm7, ymm8, ymm0                   ; c5 bd 76 f8                          
  2186 : vpcmpeqd     ymm0, ymm15, ymm0                  ; c5 85 76 c0                          
  2187 : vpcmpeqd     ymm0, ymm8, ymm7                   ; c5 bd 76 c7                          
  2188 : vpcmpeqd     ymm0, ymm0, ymm8                   ; c4 c1 7d 76 c0                       
  2189 : vpcmpeqd     ymm7, ymm0, ymm8                   ; c4 c1 7d 76 f8                       
  2190 : vpcmpeqd     ymm0, ymm7, ymm8                   ; c4 c1 45 76 c0                       
  2191 : vpcmpeqd     ymm0, ymm0, ymm15                  ; c4 c1 7d 76 c7                       
  2192 : vpcmpeqq     ymm0, ymm0, ymm0                   ; c4 e2 7d 29 c0                       
  2193 : vpcmpeqq     ymm7, ymm0, ymm0                   ; c4 e2 7d 29 f8                       
  2194 : vpcmpeqq     ymm0, ymm7, ymm0                   ; c4 e2 45 29 c0                       
  2195 : vpcmpeqq     ymm0, ymm0, ymm7                   ; c4 e2 7d 29 c7                       
  2196 : vpcmpeqq     ymm8, ymm0, ymm0                   ; c4 62 7d 29 c0                       
  2197 : vpcmpeqq     ymm15, ymm0, ymm0                  ; c4 62 7d 29 f8                       
  2198 : vpcmpeqq     ymm8, ymm7, ymm0                   ; c4 62 45 29 c0                       
  2199 : vpcmpeqq     ymm8, ymm0, ymm7                   ; c4 62 7d 29 c7                       
  2200 : vpcmpeqq     ymm0, ymm8, ymm0                   ; c4 e2 3d 29 c0                       
  2201 : vpcmpeqq     ymm7, ymm8, ymm0                   ; c4 e2 3d 29 f8                       
  2202 : vpcmpeqq     ymm0, ymm15, ymm0                  ; c4 e2 05 29 c0                       
  2203 : vpcmpeqq     ymm0, ymm8, ymm7                   ; c4 e2 3d 29 c7                       
  2204 : vpcmpeqq     ymm0, ymm0, ymm8                   ; c4 c2 7d 29 c0                       
  2205 : vpcmpeqq     ymm7, ymm0, ymm8                   ; c4 c2 7d 29 f8                       
  2206 : vpcmpeqq     ymm0, ymm7, ymm8                   ; c4 c2 45 29 c0                       
  2207 : vpcmpeqq     ymm0, ymm0, ymm15                  ; c4 c2 7d 29 c7                       
  2208 : vcmpeqps     ymm0, ymm0, ymm0                   ; c5 fc c2 c0 00                       
  2209 : vcmpeqps     ymm7, ymm0, ymm0                   ; c5 fc c2 f8 00                       
  2210 : vcmpeqps     ymm0, ymm7, ymm0                   ; c5 c4 c2 c0 00                       
  2211 : vcmpeqps     ymm0, ymm0, ymm7                   ; c5 fc c2 c7 00                       
  2212 : vcmpeqps     ymm8, ymm0, ymm0                   ; c5 7c c2 c0 00                       
  2213 : vcmpeqps     ymm15, ymm0, ymm0                  ; c5 7c c2 f8 00                       
  2214 : vcmpeqps     ymm8, ymm7, ymm0                   ; c5 44 c2 c0 00                       
  2215 : vcmpeqps     ymm8, ymm0, ymm7                   ; c5 7c c2 c7 00                       
  2216 : vcmpeqps     ymm0, ymm8, ymm0                   ; c5 bc c2 c0 00                       
  2217 : vcmpeqps     ymm7, ymm8, ymm0                   ; c5 bc c2 f8 00                       
  2218 : vcmpeqps     ymm0, ymm15, ymm0                  ; c5 84 c2 c0 00                       
  2219 : vcmpeqps     ymm0, ymm8, ymm7                   ; c5 bc c2 c7 00                       
  2220 : vcmpeqps     ymm0, ymm0, ymm8                   ; c4 c1 7c c2 c0 00                    
  2221 : vcmpeqps     ymm7, ymm0, ymm8                   ; c4 c1 7c c2 f8 00                    
  2222 : vcmpeqps     ymm0, ymm7, ymm8                   ; c4 c1 44 c2 c0 00                    
  2223 : vcmpeqps     ymm0, ymm0, ymm15                  ; c4 c1 7c c2 c7 00                    
  2224 : vcmpeqpd     ymm0, ymm0, ymm0                   ; c5 fd c2 c0 00                       
  2225 : vcmpeqpd     ymm7, ymm0, ymm0                   ; c5 fd c2 f8 00                       
  2226 : vcmpeqpd     ymm0, ymm7, ymm0                   ; c5 c5 c2 c0 00                       
  2227 : vcmpeqpd     ymm0, ymm0, ymm7                   ; c5 fd c2 c7 00                       
  2228 : vcmpeqpd     ymm8, ymm0, ymm0                   ; c5 7d c2 c0 00                       
  2229 : vcmpeqpd     ymm15, ymm0, ymm0                  ; c5 7d c2 f8 00                       
  2230 : vcmpeqpd     ymm8, ymm7, ymm0                   ; c5 45 c2 c0 00                       
  2231 : vcmpeqpd     ymm8, ymm0, ymm7                   ; c5 7d c2 c7 00                       
  2232 : vcmpeqpd     ymm0, ymm8, ymm0                   ; c5 bd c2 c0 00                       
  2233 : vcmpeqpd     ymm7, ymm8, ymm0                   ; c5 bd c2 f8 00                       
  2234 : vcmpeqpd     ymm0, ymm15, ymm0                  ; c5 85 c2 c0 00                       
  2235 : vcmpeqpd     ymm0, ymm8, ymm7                   ; c5 bd c2 c7 00                       
  2236 : vcmpeqpd     ymm0, ymm0, ymm8                   ; c4 c1 7d c2 c0 00                    
  2237 : vcmpeqpd     ymm7, ymm0, ymm8                   ; c4 c1 7d c2 f8 00                    
  2238 : vcmpeqpd     ymm0, ymm7, ymm8                   ; c4 c1 45 c2 c0 00                    
  2239 : vcmpeqpd     ymm0, ymm0, ymm15                  ; c4 c1 7d c2 c7 00                    
  2240 : vcmpneqps    ymm0, ymm0, ymm0                   ; c5 fc c2 c0 04                       
  2241 : vcmpneqps    ymm7, ymm0, ymm0                   ; c5 fc c2 f8 04                       
  2242 : vcmpneqps    ymm0, ymm7, ymm0                   ; c5 c4 c2 c0 04                       
  2243 : vcmpneqps    ymm0, ymm0, ymm7                   ; c5 fc c2 c7 04                       
  2244 : vcmpneqps    ymm8, ymm0, ymm0                   ; c5 7c c2 c0 04                       
  2245 : vcmpneqps    ymm15, ymm0, ymm0                  ; c5 7c c2 f8 04                       
  2246 : vcmpneqps    ymm8, ymm7, ymm0                   ; c5 44 c2 c0 04                       
  2247 : vcmpneqps    ymm8, ymm0, ymm7                   ; c5 7c c2 c7 04                       
  2248 : vcmpneqps    ymm0, ymm8, ymm0                   ; c5 bc c2 c0 04                       
  2249 : vcmpneqps    ymm7, ymm8, ymm0                   ; c5 bc c2 f8 04                       
  2250 : vcmpneqps    ymm0, ymm15, ymm0                  ; c5 84 c2 c0 04                       
  2251 : vcmpneqps    ymm0, ymm8, ymm7                   ; c5 bc c2 c7 04                       
  2252 : vcmpneqps    ymm0, ymm0, ymm8                   ; c4 c1 7c c2 c0 04                    
  2253 : vcmpneqps    ymm7, ymm0, ymm8                   ; c4 c1 7c c2 f8 04                    
  2254 : vcmpneqps    ymm0, ymm7, ymm8                   ; c4 c1 44 c2 c0 04                    
  2255 : vcmpneqps    ymm0, ymm0, ymm15                  ; c4 c1 7c c2 c7 04                    
  2256 : vcmpneqpd    ymm0, ymm0, ymm0                   ; c5 fd c2 c0 04                       
  2257 : vcmpneqpd    ymm7, ymm0, ymm0                   ; c5 fd c2 f8 04                       
  2258 : vcmpneqpd    ymm0, ymm7, ymm0                   ; c5 c5 c2 c0 04                       
  2259 : vcmpneqpd    ymm0, ymm0, ymm7                   ; c5 fd c2 c7 04                       
  2260 : vcmpneqpd    ymm8, ymm0, ymm0                   ; c5 7d c2 c0 04                       
  2261 : vcmpneqpd    ymm15, ymm0, ymm0                  ; c5 7d c2 f8 04                       
  2262 : vcmpneqpd    ymm8, ymm7, ymm0                   ; c5 45 c2 c0 04                       
  2263 : vcmpneqpd    ymm8, ymm0, ymm7                   ; c5 7d c2 c7 04                       
  2264 : vcmpneqpd    ymm0, ymm8, ymm0                   ; c5 bd c2 c0 04                       
  2265 : vcmpneqpd    ymm7, ymm8, ymm0                   ; c5 bd c2 f8 04                       
  2266 : vcmpneqpd    ymm0, ymm15, ymm0                  ; c5 85 c2 c0 04                       
  2267 : vcmpneqpd    ymm0, ymm8, ymm7                   ; c5 bd c2 c7 04                       
  2268 : vcmpneqpd    ymm0, ymm0, ymm8                   ; c4 c1 7d c2 c0 04                    
  2269 : vcmpneqpd    ymm7, ymm0, ymm8                   ; c4 c1 7d c2 f8 04                    
  2270 : vcmpneqpd    ymm0, ymm7, ymm8                   ; c4 c1 45 c2 c0 04                    
  2271 : vcmpneqpd    ymm0, ymm0, ymm15                  ; c4 c1 7d c2 c7 04                    
  2272 : vcmpltps     ymm0, ymm0, ymm0                   ; c5 fc c2 c0 01                       
  2273 : vcmpltps     ymm7, ymm0, ymm0                   ; c5 fc c2 f8 01                       
  2274 : vcmpltps     ymm0, ymm7, ymm0                   ; c5 c4 c2 c0 01                       
  2275 : vcmpltps     ymm0, ymm0, ymm7                   ; c5 fc c2 c7 01                       
  2276 : vcmpltps     ymm8, ymm0, ymm0                   ; c5 7c c2 c0 01                       
  2277 : vcmpltps     ymm15, ymm0, ymm0                  ; c5 7c c2 f8 01                       
  2278 : vcmpltps     ymm8, ymm7, ymm0                   ; c5 44 c2 c0 01                       
  2279 : vcmpltps     ymm8, ymm0, ymm7                   ; c5 7c c2 c7 01                       
  2280 : vcmpltps     ymm0, ymm8, ymm0                   ; c5 bc c2 c0 01                       
  2281 : vcmpltps     ymm7, ymm8, ymm0                   ; c5 bc c2 f8 01                       
  2282 : vcmpltps     ymm0, ymm15, ymm0                  ; c5 84 c2 c0 01                       
  2283 : vcmpltps     ymm0, ymm8, ymm7                   ; c5 bc c2 c7 01                       
  2284 : vcmpltps     ymm0, ymm0, ymm8                   ; c4 c1 7c c2 c0 01                    
  2285 : vcmpltps     ymm7, ymm0, ymm8                   ; c4 c1 7c c2 f8 01                    
  2286 : vcmpltps     ymm0, ymm7, ymm8                   ; c4 c1 44 c2 c0 01                    
  2287 : vcmpltps     ymm0, ymm0, ymm15                  ; c4 c1 7c c2 c7 01                    
  2288 : vcmpltpd     ymm0, ymm0, ymm0                   ; c5 fd c2 c0 01                       
  2289 : vcmpltpd     ymm7, ymm0, ymm0                   ; c5 fd c2 f8 01                       
  2290 : vcmpltpd     ymm0, ymm7, ymm0                   ; c5 c5 c2 c0 01                       
  2291 : vcmpltpd     ymm0, ymm0, ymm7                   ; c5 fd c2 c7 01                       
  2292 : vcmpltpd     ymm8, ymm0, ymm0                   ; c5 7d c2 c0 01                       
  2293 : vcmpltpd     ymm15, ymm0, ymm0                  ; c5 7d c2 f8 01                       
  2294 : vcmpltpd     ymm8, ymm7, ymm0                   ; c5 45 c2 c0 01                       
  2295 : vcmpltpd     ymm8, ymm0, ymm7                   ; c5 7d c2 c7 01                       
  2296 : vcmpltpd     ymm0, ymm8, ymm0                   ; c5 bd c2 c0 01                       
  2297 : vcmpltpd     ymm7, ymm8, ymm0                   ; c5 bd c2 f8 01                       
  2298 : vcmpltpd     ymm0, ymm15, ymm0                  ; c5 85 c2 c0 01                       
  2299 : vcmpltpd     ymm0, ymm8, ymm7                   ; c5 bd c2 c7 01                       
  2300 : vcmpltpd     ymm0, ymm0, ymm8                   ; c4 c1 7d c2 c0 01                    
  2301 : vcmpltpd     ymm7, ymm0, ymm8                   ; c4 c1 7d c2 f8 01                    
  2302 : vcmpltpd     ymm0, ymm7, ymm8                   ; c4 c1 45 c2 c0 01                    
  2303 : vcmpltpd     ymm0, ymm0, ymm15                  ; c4 c1 7d c2 c7 01                    
  2304 : vcmpleps     ymm0, ymm0, ymm0                   ; c5 fc c2 c0 02                       
  2305 : vcmpleps     ymm7, ymm0, ymm0                   ; c5 fc c2 f8 02                       
  2306 : vcmpleps     ymm0, ymm7, ymm0                   ; c5 c4 c2 c0 02                       
  2307 : vcmpleps     ymm0, ymm0, ymm7                   ; c5 fc c2 c7 02                       
  2308 : vcmpleps     ymm8, ymm0, ymm0                   ; c5 7c c2 c0 02                       
  2309 : vcmpleps     ymm15, ymm0, ymm0                  ; c5 7c c2 f8 02                       
  2310 : vcmpleps     ymm8, ymm7, ymm0                   ; c5 44 c2 c0 02                       
  2311 : vcmpleps     ymm8, ymm0, ymm7                   ; c5 7c c2 c7 02                       
  2312 : vcmpleps     ymm0, ymm8, ymm0                   ; c5 bc c2 c0 02                       
  2313 : vcmpleps     ymm7, ymm8, ymm0                   ; c5 bc c2 f8 02                       
  2314 : vcmpleps     ymm0, ymm15, ymm0                  ; c5 84 c2 c0 02                       
  2315 : vcmpleps     ymm0, ymm8, ymm7                   ; c5 bc c2 c7 02                       
  2316 : vcmpleps     ymm0, ymm0, ymm8                   ; c4 c1 7c c2 c0 02                    
  2317 : vcmpleps     ymm7, ymm0, ymm8                   ; c4 c1 7c c2 f8 02                    
  2318 : vcmpleps     ymm0, ymm7, ymm8                   ; c4 c1 44 c2 c0 02                    
  2319 : vcmpleps     ymm0, ymm0, ymm15                  ; c4 c1 7c c2 c7 02                    
  2320 : vcmplepd     ymm0, ymm0, ymm0                   ; c5 fd c2 c0 02                       
  2321 : vcmplepd     ymm7, ymm0, ymm0                   ; c5 fd c2 f8 02                       
  2322 : vcmplepd     ymm0, ymm7, ymm0                   ; c5 c5 c2 c0 02                       
  2323 : vcmplepd     ymm0, ymm0, ymm7                   ; c5 fd c2 c7 02                       
  2324 : vcmplepd     ymm8, ymm0, ymm0                   ; c5 7d c2 c0 02                       
  2325 : vcmplepd     ymm15, ymm0, ymm0                  ; c5 7d c2 f8 02                       
  2326 : vcmplepd     ymm8, ymm7, ymm0                   ; c5 45 c2 c0 02                       
  2327 : vcmplepd     ymm8, ymm0, ymm7                   ; c5 7d c2 c7 02                       
  2328 : vcmplepd     ymm0, ymm8, ymm0                   ; c5 bd c2 c0 02                       
  2329 : vcmplepd     ymm7, ymm8, ymm0                   ; c5 bd c2 f8 02                       
  2330 : vcmplepd     ymm0, ymm15, ymm0                  ; c5 85 c2 c0 02                       
  2331 : vcmplepd     ymm0, ymm8, ymm7                   ; c5 bd c2 c7 02                       
  2332 : vcmplepd     ymm0, ymm0, ymm8                   ; c4 c1 7d c2 c0 02                    
  2333 : vcmplepd     ymm7, ymm0, ymm8                   ; c4 c1 7d c2 f8 02                    
  2334 : vcmplepd     ymm0, ymm7, ymm8                   ; c4 c1 45 c2 c0 02                    
  2335 : vcmplepd     ymm0, ymm0, ymm15                  ; c4 c1 7d c2 c7 02                    
  2336 : vpcmpgtb     ymm0, ymm0, ymm0                   ; c5 fd 64 c0                          
  2337 : vpcmpgtb     ymm7, ymm0, ymm0                   ; c5 fd 64 f8                          
  2338 : vpcmpgtb     ymm0, ymm7, ymm0                   ; c5 c5 64 c0                          
  2339 : vpcmpgtb     ymm0, ymm0, ymm7                   ; c5 fd 64 c7                          
  2340 : vpcmpgtb     ymm8, ymm0, ymm0                   ; c5 7d 64 c0                          
  2341 : vpcmpgtb     ymm15, ymm0, ymm0                  ; c5 7d 64 f8                          
  2342 : vpcmpgtb     ymm8, ymm7, ymm0                   ; c5 45 64 c0                          
  2343 : vpcmpgtb     ymm8, ymm0, ymm7                   ; c5 7d 64 c7                          
  2344 : vpcmpgtb     ymm0, ymm8, ymm0                   ; c5 bd 64 c0                          
  2345 : vpcmpgtb     ymm7, ymm8, ymm0                   ; c5 bd 64 f8                          
  2346 : vpcmpgtb     ymm0, ymm15, ymm0                  ; c5 85 64 c0                          
  2347 : vpcmpgtb     ymm0, ymm8, ymm7                   ; c5 bd 64 c7                          
  2348 : vpcmpgtb     ymm0, ymm0, ymm8                   ; c4 c1 7d 64 c0                       
  2349 : vpcmpgtb     ymm7, ymm0, ymm8                   ; c4 c1 7d 64 f8                       
  2350 : vpcmpgtb     ymm0, ymm7, ymm8                   ; c4 c1 45 64 c0                       
  2351 : vpcmpgtb     ymm0, ymm0, ymm15                  ; c4 c1 7d 64 c7                       
  2352 : vpcmpgtw     ymm0, ymm0, ymm0                   ; c5 fd 65 c0                          
  2353 : vpcmpgtw     ymm7, ymm0, ymm0                   ; c5 fd 65 f8                          
  2354 : vpcmpgtw     ymm0, ymm7, ymm0                   ; c5 c5 65 c0                          
  2355 : vpcmpgtw     ymm0, ymm0, ymm7                   ; c5 fd 65 c7                          
  2356 : vpcmpgtw     ymm8, ymm0, ymm0                   ; c5 7d 65 c0                          
  2357 : vpcmpgtw     ymm15, ymm0, ymm0                  ; c5 7d 65 f8                          
  2358 : vpcmpgtw     ymm8, ymm7, ymm0                   ; c5 45 65 c0                          
  2359 : vpcmpgtw     ymm8, ymm0, ymm7                   ; c5 7d 65 c7                          
  2360 : vpcmpgtw     ymm0, ymm8, ymm0                   ; c5 bd 65 c0                          
  2361 : vpcmpgtw     ymm7, ymm8, ymm0                   ; c5 bd 65 f8                          
  2362 : vpcmpgtw     ymm0, ymm15, ymm0                  ; c5 85 65 c0                          
  2363 : vpcmpgtw     ymm0, ymm8, ymm7                   ; c5 bd 65 c7                          
  2364 : vpcmpgtw     ymm0, ymm0, ymm8                   ; c4 c1 7d 65 c0                       
  2365 : vpcmpgtw     ymm7, ymm0, ymm8                   ; c4 c1 7d 65 f8                       
  2366 : vpcmpgtw     ymm0, ymm7, ymm8                   ; c4 c1 45 65 c0                       
  2367 : vpcmpgtw     ymm0, ymm0, ymm15                  ; c4 c1 7d 65 c7                       
  2368 : vpcmpgtd     ymm0, ymm0, ymm0                   ; c5 fd 66 c0                          
  2369 : vpcmpgtd     ymm7, ymm0, ymm0                   ; c5 fd 66 f8                          
  2370 : vpcmpgtd     ymm0, ymm7, ymm0                   ; c5 c5 66 c0                          
  2371 : vpcmpgtd     ymm0, ymm0, ymm7                   ; c5 fd 66 c7                          
  2372 : vpcmpgtd     ymm8, ymm0, ymm0                   ; c5 7d 66 c0                          
  2373 : vpcmpgtd     ymm15, ymm0, ymm0                  ; c5 7d 66 f8                          
  2374 : vpcmpgtd     ymm8, ymm7, ymm0                   ; c5 45 66 c0                          
  2375 : vpcmpgtd     ymm8, ymm0, ymm7                   ; c5 7d 66 c7                          
  2376 : vpcmpgtd     ymm0, ymm8, ymm0                   ; c5 bd 66 c0                          
  2377 : vpcmpgtd     ymm7, ymm8, ymm0                   ; c5 bd 66 f8                          
  2378 : vpcmpgtd     ymm0, ymm15, ymm0                  ; c5 85 66 c0                          
  2379 : vpcmpgtd     ymm0, ymm8, ymm7                   ; c5 bd 66 c7                          
  2380 : vpcmpgtd     ymm0, ymm0, ymm8                   ; c4 c1 7d 66 c0                       
  2381 : vpcmpgtd     ymm7, ymm0, ymm8                   ; c4 c1 7d 66 f8                       
  2382 : vpcmpgtd     ymm0, ymm7, ymm8                   ; c4 c1 45 66 c0                       
  2383 : vpcmpgtd     ymm0, ymm0, ymm15                  ; c4 c1 7d 66 c7                       
  2384 : vpcmpgtq     ymm0, ymm0, ymm0                   ; c4 e2 7d 37 c0                       
  2385 : vpcmpgtq     ymm7, ymm0, ymm0                   ; c4 e2 7d 37 f8                       
  2386 : vpcmpgtq     ymm0, ymm7, ymm0                   ; c4 e2 45 37 c0                       
  2387 : vpcmpgtq     ymm0, ymm0, ymm7                   ; c4 e2 7d 37 c7                       
  2388 : vpcmpgtq     ymm8, ymm0, ymm0                   ; c4 62 7d 37 c0                       
  2389 : vpcmpgtq     ymm15, ymm0, ymm0                  ; c4 62 7d 37 f8                       
  2390 : vpcmpgtq     ymm8, ymm7, ymm0                   ; c4 62 45 37 c0                       
  2391 : vpcmpgtq     ymm8, ymm0, ymm7                   ; c4 62 7d 37 c7                       
  2392 : vpcmpgtq     ymm0, ymm8, ymm0                   ; c4 e2 3d 37 c0                       
  2393 : vpcmpgtq     ymm7, ymm8, ymm0                   ; c4 e2 3d 37 f8                       
  2394 : vpcmpgtq     ymm0, ymm15, ymm0                  ; c4 e2 05 37 c0                       
  2395 : vpcmpgtq     ymm0, ymm8, ymm7                   ; c4 e2 3d 37 c7                       
  2396 : vpcmpgtq     ymm0, ymm0, ymm8                   ; c4 c2 7d 37 c0                       
  2397 : vpcmpgtq     ymm7, ymm0, ymm8                   ; c4 c2 7d 37 f8                       
  2398 : vpcmpgtq     ymm0, ymm7, ymm8                   ; c4 c2 45 37 c0                       
  2399 : vpcmpgtq     ymm0, ymm0, ymm15                  ; c4 c2 7d 37 c7                       
  2400 : vpblendvb    ymm0, ymm0, ymm0, ymm0             ; c4 e3 7d 4c c0 00                    
  2401 : vpblendvb    ymm7, ymm0, ymm0, ymm0             ; c4 e3 7d 4c f8 00                    
  2402 : vpblendvb    ymm0, ymm0, ymm0, ymm7             ; c4 e3 7d 4c c0 70                    
  2403 : vpblendvb    ymm0, ymm7, ymm0, ymm0             ; c4 e3 45 4c c0 00                    
  2404 : vpblendvb    ymm0, ymm0, ymm7, ymm0             ; c4 e3 7d 4c c7 00                    
  2405 : vpblendvb    ymm8, ymm0, ymm0, ymm0             ; c4 63 7d 4c c0 00                    
  2406 : vpblendvb    ymm15, ymm0, ymm0, ymm0            ; c4 63 7d 4c f8 00                    
  2407 : vpblendvb    ymm8, ymm0, ymm0, ymm7             ; c4 63 7d 4c c0 70                    
  2408 : vpblendvb    ymm8, ymm7, ymm0, ymm0             ; c4 63 45 4c c0 00                    
  2409 : vpblendvb    ymm8, ymm0, ymm7, ymm0             ; c4 63 7d 4c c7 00                    
  2410 : vpblendvb    ymm0, ymm0, ymm0, ymm8             ; c4 e3 7d 4c c0 80                    
  2411 : vpblendvb    ymm7, ymm0, ymm0, ymm8             ; c4 e3 7d 4c f8 80                    
  2412 : vpblendvb    ymm0, ymm0, ymm0, ymm15            ; c4 e3 7d 4c c0 f0                    
  2413 : vpblendvb    ymm0, ymm7, ymm0, ymm8             ; c4 e3 45 4c c0 80                    
  2414 : vpblendvb    ymm0, ymm0, ymm7, ymm8             ; c4 e3 7d 4c c7 80                    
  2415 : vpblendvb    ymm0, ymm8, ymm0, ymm0             ; c4 e3 3d 4c c0 00                    
  2416 : vpblendvb    ymm7, ymm8, ymm0, ymm0             ; c4 e3 3d 4c f8 00                    
  2417 : vpblendvb    ymm0, ymm8, ymm0, ymm7             ; c4 e3 3d 4c c0 70                    
  2418 : vpblendvb    ymm0, ymm15, ymm0, ymm0            ; c4 e3 05 4c c0 00                    
  2419 : vpblendvb    ymm0, ymm8, ymm7, ymm0             ; c4 e3 3d 4c c7 00                    
  2420 : vpblendvb    ymm0, ymm0, ymm8, ymm0             ; c4 c3 7d 4c c0 00                    
  2421 : vpblendvb    ymm7, ymm0, ymm8, ymm0             ; c4 c3 7d 4c f8 00                    
  2422 : vpblendvb    ymm0, ymm0, ymm8, ymm7             ; c4 c3 7d 4c c0 70                    
  2423 : vpblendvb    ymm0, ymm7, ymm8, ymm0             ; c4 c3 45 4c c0 00                    
  2424 : vpblendvb    ymm0, ymm0, ymm15, ymm0            ; c4 c3 7d 4c c7 00                    
  2425 : vblendvps    ymm0, ymm0, ymm0, ymm0             ; c4 e3 7d 4a c0 00                    
  2426 : vblendvps    ymm7, ymm0, ymm0, ymm0             ; c4 e3 7d 4a f8 00                    
  2427 : vblendvps    ymm0, ymm0, ymm0, ymm7             ; c4 e3 7d 4a c0 70                    
  2428 : vblendvps    ymm0, ymm7, ymm0, ymm0             ; c4 e3 45 4a c0 00                    
  2429 : vblendvps    ymm0, ymm0, ymm7, ymm0             ; c4 e3 7d 4a c7 00                    
  2430 : vblendvps    ymm8, ymm0, ymm0, ymm0             ; c4 63 7d 4a c0 00                    
  2431 : vblendvps    ymm15, ymm0, ymm0, ymm0            ; c4 63 7d 4a f8 00                    
  2432 : vblendvps    ymm8, ymm0, ymm0, ymm7             ; c4 63 7d 4a c0 70                    
  2433 : vblendvps    ymm8, ymm7, ymm0, ymm0             ; c4 63 45 4a c0 00                    
  2434 : vblendvps    ymm8, ymm0, ymm7, ymm0             ; c4 63 7d 4a c7 00                    
  2435 : vblendvps    ymm0, ymm0, ymm0, ymm8             ; c4 e3 7d 4a c0 80                    
  2436 : vblendvps    ymm7, ymm0, ymm0, ymm8             ; c4 e3 7d 4a f8 80                    
  2437 : vblendvps    ymm0, ymm0, ymm0, ymm15            ; c4 e3 7d 4a c0 f0                    
  2438 : vblendvps    ymm0, ymm7, ymm0, ymm8             ; c4 e3 45 4a c0 80                    
  2439 : vblendvps    ymm0, ymm0, ymm7, ymm8             ; c4 e3 7d 4a c7 80                    
  2440 : vblendvps    ymm0, ymm8, ymm0, ymm0             ; c4 e3 3d 4a c0 00                    
  2441 : vblendvps    ymm7, ymm8, ymm0, ymm0             ; c4 e3 3d 4a f8 00                    
  2442 : vblendvps    ymm0, ymm8, ymm0, ymm7             ; c4 e3 3d 4a c0 70                    
  2443 : vblendvps    ymm0, ymm15, ymm0, ymm0            ; c4 e3 05 4a c0 00                    
  2444 : vblendvps    ymm0, ymm8, ymm7, ymm0             ; c4 e3 3d 4a c7 00                    
  2445 : vblendvps    ymm0, ymm0, ymm8, ymm0             ; c4 c3 7d 4a c0 00                    
  2446 : vblendvps    ymm7, ymm0, ymm8, ymm0             ; c4 c3 7d 4a f8 00                    
  2447 : vblendvps    ymm0, ymm0, ymm8, ymm7             ; c4 c3 7d 4a c0 70                    
  2448 : vblendvps    ymm0, ymm7, ymm8, ymm0             ; c4 c3 45 4a c0 00                    
  2449 : vblendvps    ymm0, ymm0, ymm15, ymm0            ; c4 c3 7d 4a c7 00                    
  2450 : vblendvpd    ymm0, ymm0, ymm0, ymm0             ; c4 e3 7d 4b c0 00                    
  2451 : vblendvpd    ymm7, ymm0, ymm0, ymm0             ; c4 e3 7d 4b f8 00                    
  2452 : vblendvpd    ymm0, ymm0, ymm0, ymm7             ; c4 e3 7d 4b c0 70                    
  2453 : vblendvpd    ymm0, ymm7, ymm0, ymm0             ; c4 e3 45 4b c0 00                    
  2454 : vblendvpd    ymm0, ymm0, ymm7, ymm0             ; c4 e3 7d 4b c7 00                    
  2455 : vblendvpd    ymm8, ymm0, ymm0, ymm0             ; c4 63 7d 4b c0 00                    
  2456 : vblendvpd    ymm15, ymm0, ymm0, ymm0            ; c4 63 7d 4b f8 00                    
  2457 : vblendvpd    ymm8, ymm0, ymm0, ymm7             ; c4 63 7d 4b c0 70                    
  2458 : vblendvpd    ymm8, ymm7, ymm0, ymm0             ; c4 63 45 4b c0 00                    
  2459 : vblendvpd    ymm8, ymm0, ymm7, ymm0             ; c4 63 7d 4b c7 00                    
  2460 : vblendvpd    ymm0, ymm0, ymm0, ymm8             ; c4 e3 7d 4b c0 80                    
  2461 : vblendvpd    ymm7, ymm0, ymm0, ymm8             ; c4 e3 7d 4b f8 80                    
  2462 : vblendvpd    ymm0, ymm0, ymm0, ymm15            ; c4 e3 7d 4b c0 f0                    
  2463 : vblendvpd    ymm0, ymm7, ymm0, ymm8             ; c4 e3 45 4b c0 80                    
  2464 : vblendvpd    ymm0, ymm0, ymm7, ymm8             ; c4 e3 7d 4b c7 80                    
  2465 : vblendvpd    ymm0, ymm8, ymm0, ymm0             ; c4 e3 3d 4b c0 00                    
  2466 : vblendvpd    ymm7, ymm8, ymm0, ymm0             ; c4 e3 3d 4b f8 00                    
  2467 : vblendvpd    ymm0, ymm8, ymm0, ymm7             ; c4 e3 3d 4b c0 70                    
  2468 : vblendvpd    ymm0, ymm15, ymm0, ymm0            ; c4 e3 05 4b c0 00                    
  2469 : vblendvpd    ymm0, ymm8, ymm7, ymm0             ; c4 e3 3d 4b c7 00                    
  2470 : vblendvpd    ymm0, ymm0, ymm8, ymm0             ; c4 c3 7d 4b c0 00                    
  2471 : vblendvpd    ymm7, ymm0, ymm8, ymm0             ; c4 c3 7d 4b f8 00                    
  2472 : vblendvpd    ymm0, ymm0, ymm8, ymm7             ; c4 c3 7d 4b c0 70                    
  2473 : vblendvpd    ymm0, ymm7, ymm8, ymm0             ; c4 c3 45 4b c0 00                    
  2474 : vblendvpd    ymm0, ymm0, ymm15, ymm0            ; c4 c3 7d 4b c7 00                    
  2475 : vpbroadcastb ymm0, xmm0                         ; c4 e2 7d 78 c0                       
  2476 : vpbroadcastb ymm7, xmm0                         ; c4 e2 7d 78 f8                       
  2477 : vpbroadcastb ymm0, xmm7                         ; c4 e2 7d 78 c7                       
  2478 : vpbroadcastb ymm8, xmm0                         ; c4 62 7d 78 c0                       
  2479 : vpbroadcastb ymm15, xmm0                        ; c4 62 7d 78 f8                       
  2480 : vpbroadcastb ymm8, xmm7                         ; c4 62 7d 78 c7                       
  2481 : vpbroadcastb ymm0, xmm8                         ; c4 c2 7d 78 c0                       
  2482 : vpbroadcastb ymm7, xmm8                         ; c4 c2 7d 78 f8                       
  2483 : vpbroadcastb ymm0, xmm15                        ; c4 c2 7d 78 c7                       
  2484 : vpbroadcastb ymm8, xmm8                         ; c4 42 7d 78 c0                       
  2485 : vpbroadcastb ymm15, xmm8                        ; c4 42 7d 78 f8                       
  2486 : vpbroadcastb ymm8, xmm15                        ; c4 42 7d 78 c7                       
  2487 : vpbroadcastw ymm0, xmm0                         ; c4 e2 7d 79 c0                       
  2488 : vpbroadcastw ymm7, xmm0                         ; c4 e2 7d 79 f8                       
  2489 : vpbroadcastw ymm0, xmm7                         ; c4 e2 7d 79 c7                       
  2490 : vpbroadcastw ymm8, xmm0                         ; c4 62 7d 79 c0                       
  2491 : vpbroadcastw ymm15, xmm0                        ; c4 62 7d 79 f8                       
  2492 : vpbroadcastw ymm8, xmm7                         ; c4 62 7d 79 c7                       
  2493 : vpbroadcastw ymm0, xmm8                         ; c4 c2 7d 79 c0                       
  2494 : vpbroadcastw ymm7, xmm8                         ; c4 c2 7d 79 f8                       
  2495 : vpbroadcastw ymm0, xmm15                        ; c4 c2 7d 79 c7                       
  2496 : vpbroadcastw ymm8, xmm8                         ; c4 42 7d 79 c0                       
  2497 : vpbroadcastw ymm15, xmm8                        ; c4 42 7d 79 f8                       
  2498 : vpbroadcastw ymm8, xmm15                        ; c4 42 7d 79 c7                       
  2499 : vpbroadcastd ymm0, xmm0                         ; c4 e2 7d 58 c0                       
  2500 : vpbroadcastd ymm7, xmm0                         ; c4 e2 7d 58 f8                       
  2501 : vpbroadcastd ymm0, xmm7                         ; c4 e2 7d 58 c7                       
  2502 : vpbroadcastd ymm8, xmm0                         ; c4 62 7d 58 c0                       
  2503 : vpbroadcastd ymm15, xmm0                        ; c4 62 7d 58 f8                       
  2504 : vpbroadcastd ymm8, xmm7                         ; c4 62 7d 58 c7                       
  2505 : vpbroadcastd ymm0, xmm8                         ; c4 c2 7d 58 c0                       
  2506 : vpbroadcastd ymm7, xmm8                         ; c4 c2 7d 58 f8                       
  2507 : vpbroadcastd ymm0, xmm15                        ; c4 c2 7d 58 c7                       
  2508 : vpbroadcastd ymm8, xmm8                         ; c4 42 7d 58 c0                       
  2509 : vpbroadcastd ymm15, xmm8                        ; c4 42 7d 58 f8                       
  2510 : vpbroadcastd ymm8, xmm15                        ; c4 42 7d 58 c7                       
  2511 : vpbroadcastq ymm0, xmm0                         ; c4 e2 7d 59 c0                       
  2512 : vpbroadcastq ymm7, xmm0                         ; c4 e2 7d 59 f8                       
  2513 : vpbroadcastq ymm0, xmm7                         ; c4 e2 7d 59 c7                       
  2514 : vpbroadcastq ymm8, xmm0                         ; c4 62 7d 59 c0                       
  2515 : vpbroadcastq ymm15, xmm0                        ; c4 62 7d 59 f8                       
  2516 : vpbroadcastq ymm8, xmm7                         ; c4 62 7d 59 c7                       
  2517 : vpbroadcastq ymm0, xmm8                         ; c4 c2 7d 59 c0                       
  2518 : vpbroadcastq ymm7, xmm8                         ; c4 c2 7d 59 f8                       
  2519 : vpbroadcastq ymm0, xmm15                        ; c4 c2 7d 59 c7                       
  2520 : vpbroadcastq ymm8, xmm8                         ; c4 42 7d 59 c0                       
  2521 : vpbroadcastq ymm15, xmm8                        ; c4 42 7d 59 f8                       
  2522 : vpbroadcastq ymm8, xmm15                        ; c4 42 7d 59 c7                       
  2523 : vextracti128 xmm0, ymm0, 0                      ; c4 e3 7d 39 c0 00                    
  2524 : vextracti128 xmm0, ymm0, 0x001                  ; c4 e3 7d 39 c0 01                    
  2525 : vextracti128 xmm7, ymm0, 0x001                  ; c4 e3 7d 39 c7 01                    
  2526 : vextracti128 xmm0, ymm7, 0x001                  ; c4 e3 7d 39 f8 01                    
  2527 : vextracti128 xmm8, ymm0, 0x001                  ; c4 c3 7d 39 c0 01                    
  2528 : vextracti128 xmm15, ymm0, 0x001                 ; c4 c3 7d 39 c7 01                    
  2529 : vextracti128 xmm8, ymm7, 0x001                  ; c4 c3 7d 39 f8 01                    
  2530 : vextracti128 xmm0, ymm8, 0x001                  ; c4 63 7d 39 c0 01                    
  2531 : vextracti128 xmm7, ymm8, 0x001                  ; c4 63 7d 39 c7 01                    
  2532 : vextracti128 xmm0, ymm15, 0x001                 ; c4 63 7d 39 f8 01                    
  2533 : vextracti128 xmm8, ymm8, 0x001                  ; c4 43 7d 39 c0 01                    
  2534 : vextracti128 xmm15, ymm8, 0x001                 ; c4 43 7d 39 c7 01                    
  2535 : vextracti128 xmm8, ymm15, 0x001                 ; c4 43 7d 39 f8 01                    
  2536 : vextractf128 xmm0, ymm0, 0                      ; c4 e3 7d 19 c0 00                    
  2537 : vextractf128 xmm0, ymm0, 0x001                  ; c4 e3 7d 19 c0 01                    
  2538 : vextractf128 xmm7, ymm0, 0x001                  ; c4 e3 7d 19 c7 01                    
  2539 : vextractf128 xmm0, ymm7, 0x001                  ; c4 e3 7d 19 f8 01                    
  2540 : vextractf128 xmm8, ymm0, 0x001                  ; c4 c3 7d 19 c0 01                    
  2541 : vextractf128 xmm15, ymm0, 0x001                 ; c4 c3 7d 19 c7 01                    
  2542 : vextractf128 xmm8, ymm7, 0x001                  ; c4 c3 7d 19 f8 01                    
  2543 : vextractf128 xmm0, ymm8, 0x001                  ; c4 63 7d 19 c0 01                    
  2544 : vextractf128 xmm7, ymm8, 0x001                  ; c4 63 7d 19 c7 01                    
  2545 : vextractf128 xmm0, ymm15, 0x001                 ; c4 63 7d 19 f8 01                    
  2546 : vextractf128 xmm8, ymm8, 0x001                  ; c4 43 7d 19 c0 01                    
  2547 : vextractf128 xmm15, ymm8, 0x001                 ; c4 43 7d 19 c7 01                    
  2548 : vextractf128 xmm8, ymm15, 0x001                 ; c4 43 7d 19 f8 01                    
  2549 : vpextrb      rax, xmm0, 0x001                   ; c4 e3 79 14 c0 01                    
  2550 : vpextrb      rdi, xmm0, 0x001                   ; c4 e3 79 14 c7 01                    
  2551 : vpextrb      rax, xmm7, 0x001                   ; c4 e3 79 14 f8 01                    
  2552 : vpextrb      rax, xmm8, 0x001                   ; c4 63 79 14 c0 01                    
  2553 : vpextrb      rdi, xmm8, 0x001                   ; c4 63 79 14 c7 01                    
  2554 : vpextrb      rax, xmm15, 0x001                  ; c4 63 79 14 f8 01                    
  2555 : vpextrb      r8, xmm0, 0x001                    ; c4 c3 79 14 c0 01                    
  2556 : vpextrb      r15, xmm0, 0x001                   ; c4 c3 79 14 c7 01                    
  2557 : vpextrb      r8, xmm7, 0x001                    ; c4 c3 79 14 f8 01                    
  2558 : vpextrb      r8, xmm8, 0x001                    ; c4 43 79 14 c0 01                    
  2559 : vpextrb      r15, xmm8, 0x001                   ; c4 43 79 14 c7 01                    
  2560 : vpextrb      r8, xmm15, 0x001                   ; c4 43 79 14 f8 01                    
  2561 : vpextrw      rax, xmm0, 0x001                   ; c5 f9 c5 c0 01                       
  2562 : vpextrw      rdi, xmm0, 0x001                   ; c5 f9 c5 f8 01                       
  2563 : vpextrw      rax, xmm7, 0x001                   ; c5 f9 c5 c7 01                       
  2564 : vpextrw      rax, xmm8, 0x001                   ; c4 c1 79 c5 c0 01                    
  2565 : vpextrw      rdi, xmm8, 0x001                   ; c4 c1 79 c5 f8 01                    
  2566 : vpextrw      rax, xmm15, 0x001                  ; c4 c1 79 c5 c7 01                    
  2567 : vpextrw      r8, xmm0, 0x001                    ; c5 79 c5 c0 01                       
  2568 : vpextrw      r15, xmm0, 0x001                   ; c5 79 c5 f8 01                       
  2569 : vpextrw      r8, xmm7, 0x001                    ; c5 79 c5 c7 01                       
  2570 : vpextrw      r8, xmm8, 0x001                    ; c4 41 79 c5 c0 01                    
  2571 : vpextrw      r15, xmm8, 0x001                   ; c4 41 79 c5 f8 01                    
  2572 : vpextrw      r8, xmm15, 0x001                   ; c4 41 79 c5 c7 01                    
  2573 : vpextrd      eax, xmm0, 0x001                   ; c4 e3 79 16 c0 01                    
  2574 : vpextrd      edi, xmm0, 0x001                   ; c4 e3 79 16 c7 01                    
  2575 : vpextrd      eax, xmm7, 0x001                   ; c4 e3 79 16 f8 01                    
  2576 : vpextrd      eax, xmm8, 0x001                   ; c4 63 79 16 c0 01                    
  2577 : vpextrd      edi, xmm8, 0x001                   ; c4 63 79 16 c7 01                    
  2578 : vpextrd      eax, xmm15, 0x001                  ; c4 63 79 16 f8 01                    
  2579 : vpextrd      r8d, xmm0, 0x001                   ; c4 c3 79 16 c0 01                    
  2580 : vpextrd      r15d, xmm0, 0x001                  ; c4 c3 79 16 c7 01                    
  2581 : vpextrd      r8d, xmm7, 0x001                   ; c4 c3 79 16 f8 01                    
  2582 : vpextrd      r8d, xmm8, 0x001                   ; c4 43 79 16 c0 01                    
  2583 : vpextrd      r15d, xmm8, 0x001                  ; c4 43 79 16 c7 01                    
  2584 : vpextrd      r8d, xmm15, 0x001                  ; c4 43 79 16 f8 01                    
  2585 : vpextrq      rax, xmm0, 0x001                   ; c4 e3 f9 16 c0 01                    
  2586 : vpextrq      rdi, xmm0, 0x001                   ; c4 e3 f9 16 c7 01                    
  2587 : vpextrq      rax, xmm7, 0x001                   ; c4 e3 f9 16 f8 01                    
  2588 : vpextrq      rax, xmm8, 0x001                   ; c4 63 f9 16 c0 01                    
  2589 : vpextrq      rdi, xmm8, 0x001                   ; c4 63 f9 16 c7 01                    
  2590 : vpextrq      rax, xmm15, 0x001                  ; c4 63 f9 16 f8 01                    
  2591 : vpextrq      r8, xmm0, 0x001                    ; c4 c3 f9 16 c0 01                    
  2592 : vpextrq      r15, xmm0, 0x001                   ; c4 c3 f9 16 c7 01                    
  2593 : vpextrq      r8, xmm7, 0x001                    ; c4 c3 f9 16 f8 01                    
  2594 : vpextrq      r8, xmm8, 0x001                    ; c4 43 f9 16 c0 01                    
  2595 : vpextrq      r15, xmm8, 0x001                   ; c4 43 f9 16 c7 01                    
  2596 : vpextrq      r8, xmm15, 0x001                   ; c4 43 f9 16 f8 01                    
  2597 : vinserti128  ymm0, ymm0, xmm0, 0                ; c4 e3 7d 38 c0 00                    
  2598 : vinserti128  ymm0, ymm0, xmm0, 0x001            ; c4 e3 7d 38 c0 01                    
  2599 : vinserti128  ymm7, ymm0, xmm0, 0x001            ; c4 e3 7d 38 f8 01                    
  2600 : vinserti128  ymm0, ymm7, xmm0, 0x001            ; c4 e3 45 38 c0 01                    
  2601 : vinserti128  ymm0, ymm0, xmm7, 0x001            ; c4 e3 7d 38 c7 01                    
  2602 : vinserti128  ymm8, ymm0, xmm0, 0x001            ; c4 63 7d 38 c0 01                    
  2603 : vinserti128  ymm15, ymm0, xmm0, 0x001           ; c4 63 7d 38 f8 01                    
  2604 : vinserti128  ymm8, ymm7, xmm0, 0x001            ; c4 63 45 38 c0 01                    
  2605 : vinserti128  ymm8, ymm0, xmm7, 0x001            ; c4 63 7d 38 c7 01                    
  2606 : vinserti128  ymm0, ymm8, xmm0, 0x001            ; c4 e3 3d 38 c0 01                    
  2607 : vinserti128  ymm7, ymm8, xmm0, 0x001            ; c4 e3 3d 38 f8 01                    
  2608 : vinserti128  ymm0, ymm15, xmm0, 0x001           ; c4 e3 05 38 c0 01                    
  2609 : vinserti128  ymm0, ymm8, xmm7, 0x001            ; c4 e3 3d 38 c7 01                    
  2610 : vinserti128  ymm0, ymm0, xmm8, 0x001            ; c4 c3 7d 38 c0 01                    
  2611 : vinserti128  ymm7, ymm0, xmm8, 0x001            ; c4 c3 7d 38 f8 01                    
  2612 : vinserti128  ymm0, ymm7, xmm8, 0x001            ; c4 c3 45 38 c0 01                    
  2613 : vinserti128  ymm0, ymm0, xmm15, 0x001           ; c4 c3 7d 38 c7 01                    
  2614 : vinsertf128  ymm0, ymm0, xmm0, 0                ; c4 e3 7d 18 c0 00                    
  2615 : vinsertf128  ymm0, ymm0, xmm0, 0x001            ; c4 e3 7d 18 c0 01                    
  2616 : vinsertf128  ymm7, ymm0, xmm0, 0x001            ; c4 e3 7d 18 f8 01                    
  2617 : vinsertf128  ymm0, ymm7, xmm0, 0x001            ; c4 e3 45 18 c0 01                    
  2618 : vinsertf128  ymm0, ymm0, xmm7, 0x001            ; c4 e3 7d 18 c7 01                    
  2619 : vinsertf128  ymm8, ymm0, xmm0, 0x001            ; c4 63 7d 18 c0 01                    
  2620 : vinsertf128  ymm15, ymm0, xmm0, 0x001           ; c4 63 7d 18 f8 01                    
  2621 : vinsertf128  ymm8, ymm7, xmm0, 0x001            ; c4 63 45 18 c0 01                    
  2622 : vinsertf128  ymm8, ymm0, xmm7, 0x001            ; c4 63 7d 18 c7 01                    
  2623 : vinsertf128  ymm0, ymm8, xmm0, 0x001            ; c4 e3 3d 18 c0 01                    
  2624 : vinsertf128  ymm7, ymm8, xmm0, 0x001            ; c4 e3 3d 18 f8 01                    
  2625 : vinsertf128  ymm0, ymm15, xmm0, 0x001           ; c4 e3 05 18 c0 01                    
  2626 : vinsertf128  ymm0, ymm8, xmm7, 0x001            ; c4 e3 3d 18 c7 01                    
  2627 : vinsertf128  ymm0, ymm0, xmm8, 0x001            ; c4 c3 7d 18 c0 01                    
  2628 : vinsertf128  ymm7, ymm0, xmm8, 0x001            ; c4 c3 7d 18 f8 01                    
  2629 : vinsertf128  ymm0, ymm7, xmm8, 0x001            ; c4 c3 45 18 c0 01                    
  2630 : vinsertf128  ymm0, ymm0, xmm15, 0x001           ; c4 c3 7d 18 c7 01                    
  2631 : vpinsrb      xmm0, xmm0, eax, 0                 ; c4 e3 79 20 c0 00                    
  2632 : vpinsrb      xmm0, xmm0, eax, 0x001             ; c4 e3 79 20 c0 01                    
  2633 : vpinsrb      xmm7, xmm7, eax, 0x001             ; c4 e3 41 20 f8 01                    
  2634 : vpinsrb      xmm0, xmm0, edi, 0x001             ; c4 e3 79 20 c7 01                    
  2635 : vpinsrb      xmm8, xmm8, eax, 0x001             ; c4 63 39 20 c0 01                    
  2636 : vpinsrb      xmm15, xmm15, eax, 0x001           ; c4 63 01 20 f8 01                    
  2637 : vpinsrb      xmm8, xmm8, edi, 0x001             ; c4 63 39 20 c7 01                    
  2638 : vpinsrb      xmm0, xmm0, r8d, 0x001             ; c4 c3 79 20 c0 01                    
  2639 : vpinsrb      xmm7, xmm7, r8d, 0x001             ; c4 c3 41 20 f8 01                    
  2640 : vpinsrb      xmm0, xmm0, r15d, 0x001            ; c4 c3 79 20 c7 01                    
  2641 : vpinsrb      xmm8, xmm8, r8d, 0x001             ; c4 43 39 20 c0 01                    
  2642 : vpinsrb      xmm15, xmm15, r8d, 0x001           ; c4 43 01 20 f8 01                    
  2643 : vpinsrb      xmm8, xmm8, r15d, 0x001            ; c4 43 39 20 c7 01                    
  2644 : vpinsrw      xmm0, xmm0, eax, 0                 ; c5 f9 c4 c0 00                       
  2645 : vpinsrw      xmm0, xmm0, eax, 0x001             ; c5 f9 c4 c0 01                       
  2646 : vpinsrw      xmm7, xmm7, eax, 0x001             ; c5 c1 c4 f8 01                       
  2647 : vpinsrw      xmm0, xmm0, edi, 0x001             ; c5 f9 c4 c7 01                       
  2648 : vpinsrw      xmm8, xmm8, eax, 0x001             ; c5 39 c4 c0 01                       
  2649 : vpinsrw      xmm15, xmm15, eax, 0x001           ; c5 01 c4 f8 01                       
  2650 : vpinsrw      xmm8, xmm8, edi, 0x001             ; c5 39 c4 c7 01                       
  2651 : vpinsrw      xmm0, xmm0, r8d, 0x001             ; c4 c1 79 c4 c0 01                    
  2652 : vpinsrw      xmm7, xmm7, r8d, 0x001             ; c4 c1 41 c4 f8 01                    
  2653 : vpinsrw      xmm0, xmm0, r15d, 0x001            ; c4 c1 79 c4 c7 01                    
  2654 : vpinsrw      xmm8, xmm8, r8d, 0x001             ; c4 41 39 c4 c0 01                    
  2655 : vpinsrw      xmm15, xmm15, r8d, 0x001           ; c4 41 01 c4 f8 01                    
  2656 : vpinsrw      xmm8, xmm8, r15d, 0x001            ; c4 41 39 c4 c7 01                    
  2657 : vpinsrd      xmm0, xmm0, eax, 0                 ; c4 e3 79 22 c0 00                    
  2658 : vpinsrd      xmm0, xmm0, eax, 0x001             ; c4 e3 79 22 c0 01                    
  2659 : vpinsrd      xmm7, xmm7, eax, 0x001             ; c4 e3 41 22 f8 01                    
  2660 : vpinsrd      xmm0, xmm0, edi, 0x001             ; c4 e3 79 22 c7 01                    
  2661 : vpinsrd      xmm8, xmm8, eax, 0x001             ; c4 63 39 22 c0 01                    
  2662 : vpinsrd      xmm15, xmm15, eax, 0x001           ; c4 63 01 22 f8 01                    
  2663 : vpinsrd      xmm8, xmm8, edi, 0x001             ; c4 63 39 22 c7 01                    
  2664 : vpinsrd      xmm0, xmm0, r8d, 0x001             ; c4 c3 79 22 c0 01                    
  2665 : vpinsrd      xmm7, xmm7, r8d, 0x001             ; c4 c3 41 22 f8 01                    
  2666 : vpinsrd      xmm0, xmm0, r15d, 0x001            ; c4 c3 79 22 c7 01                    
  2667 : vpinsrd      xmm8, xmm8, r8d, 0x001             ; c4 43 39 22 c0 01                    
  2668 : vpinsrd      xmm15, xmm15, r8d, 0x001           ; c4 43 01 22 f8 01                    
  2669 : vpinsrd      xmm8, xmm8, r15d, 0x001            ; c4 43 39 22 c7 01                    
  2670 : vpinsrq      xmm0, xmm0, rax, 0                 ; c4 e3 f9 22 c0 00                    
  2671 : vpinsrq      xmm0, xmm0, rax, 0x001             ; c4 e3 f9 22 c0 01                    
  2672 : vpinsrq      xmm7, xmm7, rax, 0x001             ; c4 e3 c1 22 f8 01                    
  2673 : vpinsrq      xmm0, xmm0, rdi, 0x001             ; c4 e3 f9 22 c7 01                    
  2674 : vpinsrq      xmm8, xmm8, rax, 0x001             ; c4 63 b9 22 c0 01                    
  2675 : vpinsrq      xmm15, xmm15, rax, 0x001           ; c4 63 81 22 f8 01                    
  2676 : vpinsrq      xmm8, xmm8, rdi, 0x001             ; c4 63 b9 22 c7 01                    
  2677 : vpinsrq      xmm0, xmm0, r8, 0x001              ; c4 c3 f9 22 c0 01                    
  2678 : vpinsrq      xmm7, xmm7, r8, 0x001              ; c4 c3 c1 22 f8 01                    
  2679 : vpinsrq      xmm0, xmm0, r15, 0x001             ; c4 c3 f9 22 c7 01                    
  2680 : vpinsrq      xmm8, xmm8, r8, 0x001              ; c4 43 b9 22 c0 01                    
  2681 : vpinsrq      xmm15, xmm15, r8, 0x001            ; c4 43 81 22 f8 01                    
  2682 : vpinsrq      xmm8, xmm8, r15, 0x001             ; c4 43 b9 22 c7 01                    
  2683 : vperm2i128   ymm0, ymm0, ymm0, 0x021            ; c4 e3 7d 46 c0 21                    
  2684 : vperm2i128   ymm0, ymm0, ymm0, 0x021            ; c4 e3 7d 46 c0 21                    
  2685 : vperm2i128   ymm7, ymm0, ymm0, 0x021            ; c4 e3 7d 46 f8 21                    
  2686 : vperm2i128   ymm0, ymm7, ymm0, 0x021            ; c4 e3 45 46 c0 21                    
  2687 : vperm2i128   ymm0, ymm0, ymm7, 0x021            ; c4 e3 7d 46 c7 21                    
  2688 : vperm2i128   ymm8, ymm0, ymm0, 0x021            ; c4 63 7d 46 c0 21                    
  2689 : vperm2i128   ymm15, ymm0, ymm0, 0x021           ; c4 63 7d 46 f8 21                    
  2690 : vperm2i128   ymm8, ymm7, ymm0, 0x021            ; c4 63 45 46 c0 21                    
  2691 : vperm2i128   ymm8, ymm0, ymm7, 0x021            ; c4 63 7d 46 c7 21                    
  2692 : vperm2i128   ymm0, ymm8, ymm0, 0x021            ; c4 e3 3d 46 c0 21                    
  2693 : vperm2i128   ymm7, ymm8, ymm0, 0x021            ; c4 e3 3d 46 f8 21                    
  2694 : vperm2i128   ymm0, ymm15, ymm0, 0x021           ; c4 e3 05 46 c0 21                    
  2695 : vperm2i128   ymm0, ymm8, ymm7, 0x021            ; c4 e3 3d 46 c7 21                    
  2696 : vperm2i128   ymm0, ymm0, ymm8, 0x021            ; c4 c3 7d 46 c0 21                    
  2697 : vperm2i128   ymm7, ymm0, ymm8, 0x021            ; c4 c3 7d 46 f8 21                    
  2698 : vperm2i128   ymm0, ymm7, ymm8, 0x021            ; c4 c3 45 46 c0 21                    
  2699 : vperm2i128   ymm0, ymm0, ymm15, 0x021           ; c4 c3 7d 46 c7 21                    
  2700 : vpalignr     ymm0, ymm0, ymm0, 0x00f            ; c4 e3 7d 0f c0 0f                    
  2701 : vpalignr     ymm0, ymm0, ymm0, 0x00f            ; c4 e3 7d 0f c0 0f                    
  2702 : vpalignr     ymm7, ymm0, ymm0, 0x00f            ; c4 e3 7d 0f f8 0f                    
  2703 : vpalignr     ymm0, ymm7, ymm0, 0x00f            ; c4 e3 45 0f c0 0f                    
  2704 : vpalignr     ymm0, ymm0, ymm7, 0x00f            ; c4 e3 7d 0f c7 0f                    
  2705 : vpalignr     ymm8, ymm0, ymm0, 0x00f            ; c4 63 7d 0f c0 0f                    
  2706 : vpalignr     ymm15, ymm0, ymm0, 0x00f           ; c4 63 7d 0f f8 0f                    
  2707 : vpalignr     ymm8, ymm7, ymm0, 0x00f            ; c4 63 45 0f c0 0f                    
  2708 : vpalignr     ymm8, ymm0, ymm7, 0x00f            ; c4 63 7d 0f c7 0f                    
  2709 : vpalignr     ymm0, ymm8, ymm0, 0x00f            ; c4 e3 3d 0f c0 0f                    
  2710 : vpalignr     ymm7, ymm8, ymm0, 0x00f            ; c4 e3 3d 0f f8 0f                    
  2711 : vpalignr     ymm0, ymm15, ymm0, 0x00f           ; c4 e3 05 0f c0 0f                    
  2712 : vpalignr     ymm0, ymm8, ymm7, 0x00f            ; c4 e3 3d 0f c7 0f                    
  2713 : vpalignr     ymm0, ymm0, ymm8, 0x00f            ; c4 c3 7d 0f c0 0f                    
  2714 : vpalignr     ymm7, ymm0, ymm8, 0x00f            ; c4 c3 7d 0f f8 0f                    
  2715 : vpalignr     ymm0, ymm7, ymm8, 0x00f            ; c4 c3 45 0f c0 0f                    
  2716 : vpalignr     ymm0, ymm0, ymm15, 0x00f           ; c4 c3 7d 0f c7 0f                    
  2717 : vpshufd      xmm0, xmm0, 0x0ee                  ; c5 f9 70 c0 ee                       
  2718 : vpshufd      xmm7, xmm0, 0x0ee                  ; c5 f9 70 f8 ee                       
  2719 : vpshufd      xmm0, xmm7, 0x0ee                  ; c5 f9 70 c7 ee                       
  2720 : vpshufd      xmm8, xmm0, 0x0ee                  ; c5 79 70 c0 ee                       
  2721 : vpshufd      xmm15, xmm0, 0x0ee                 ; c5 79 70 f8 ee                       
  2722 : vpshufd      xmm8, xmm7, 0x0ee                  ; c5 79 70 c7 ee                       
  2723 : vpshufd      xmm0, xmm8, 0x0ee                  ; c4 c1 79 70 c0 ee                    
  2724 : vpshufd      xmm7, xmm8, 0x0ee                  ; c4 c1 79 70 f8 ee                    
  2725 : vpshufd      xmm0, xmm15, 0x0ee                 ; c4 c1 79 70 c7 ee                    
  2726 : vpshufd      xmm8, xmm8, 0x0ee                  ; c4 41 79 70 c0 ee                    
  2727 : vpshufd      xmm15, xmm8, 0x0ee                 ; c4 41 79 70 f8 ee                    
  2728 : vpshufd      xmm8, xmm15, 0x0ee                 ; c4 41 79 70 c7 ee                    
  2729 : vpsadbw      ymm0, ymm0, ymm0                   ; c5 fd f6 c0                          
  2730 : vpsadbw      ymm7, ymm0, ymm0                   ; c5 fd f6 f8                          
  2731 : vpsadbw      ymm0, ymm7, ymm0                   ; c5 c5 f6 c0                          
  2732 : vpsadbw      ymm0, ymm0, ymm7                   ; c5 fd f6 c7                          
  2733 : vpsadbw      ymm8, ymm0, ymm0                   ; c5 7d f6 c0                          
  2734 : vpsadbw      ymm15, ymm0, ymm0                  ; c5 7d f6 f8                          
  2735 : vpsadbw      ymm8, ymm7, ymm0                   ; c5 45 f6 c0                          
  2736 : vpsadbw      ymm8, ymm0, ymm7                   ; c5 7d f6 c7                          
  2737 : vpsadbw      ymm0, ymm8, ymm0                   ; c5 bd f6 c0                          
  2738 : vpsadbw      ymm7, ymm8, ymm0                   ; c5 bd f6 f8                          
  2739 : vpsadbw      ymm0, ymm15, ymm0                  ; c5 85 f6 c0                          
  2740 : vpsadbw      ymm0, ymm8, ymm7                   ; c5 bd f6 c7                          
  2741 : vpsadbw      ymm0, ymm0, ymm8                   ; c4 c1 7d f6 c0                       
  2742 : vpsadbw      ymm7, ymm0, ymm8                   ; c4 c1 7d f6 f8                       
  2743 : vpsadbw      ymm0, ymm7, ymm8                   ; c4 c1 45 f6 c0                       
  2744 : vpsadbw      ymm0, ymm0, ymm15                  ; c4 c1 7d f6 c7                       
  2745 : vphaddd      ymm0, ymm0, ymm0                   ; c4 e2 7d 02 c0                       
  2746 : vphaddd      ymm7, ymm0, ymm0                   ; c4 e2 7d 02 f8                       
  2747 : vphaddd      ymm0, ymm7, ymm0                   ; c4 e2 45 02 c0                       
  2748 : vphaddd      ymm0, ymm0, ymm7                   ; c4 e2 7d 02 c7                       
  2749 : vphaddd      ymm8, ymm0, ymm0                   ; c4 62 7d 02 c0                       
  2750 : vphaddd      ymm15, ymm0, ymm0                  ; c4 62 7d 02 f8                       
  2751 : vphaddd      ymm8, ymm7, ymm0                   ; c4 62 45 02 c0                       
  2752 : vphaddd      ymm8, ymm0, ymm7                   ; c4 62 7d 02 c7                       
  2753 : vphaddd      ymm0, ymm8, ymm0                   ; c4 e2 3d 02 c0                       
  2754 : vphaddd      ymm7, ymm8, ymm0                   ; c4 e2 3d 02 f8                       
  2755 : vphaddd      ymm0, ymm15, ymm0                  ; c4 e2 05 02 c0                       
  2756 : vphaddd      ymm0, ymm8, ymm7                   ; c4 e2 3d 02 c7                       
  2757 : vphaddd      ymm0, ymm0, ymm8                   ; c4 c2 7d 02 c0                       
  2758 : vphaddd      ymm7, ymm0, ymm8                   ; c4 c2 7d 02 f8                       
  2759 : vphaddd      ymm0, ymm7, ymm8                   ; c4 c2 45 02 c0                       
  2760 : vphaddd      ymm0, ymm0, ymm15                  ; c4 c2 7d 02 c7                       
  2761 : vhaddps      ymm0, ymm0, ymm0                   ; c5 ff 7c c0                          
  2762 : vhaddps      ymm7, ymm0, ymm0                   ; c5 ff 7c f8                          
  2763 : vhaddps      ymm0, ymm7, ymm0                   ; c5 c7 7c c0                          
  2764 : vhaddps      ymm0, ymm0, ymm7                   ; c5 ff 7c c7                          
  2765 : vhaddps      ymm8, ymm0, ymm0                   ; c5 7f 7c c0                          
  2766 : vhaddps      ymm15, ymm0, ymm0                  ; c5 7f 7c f8                          
  2767 : vhaddps      ymm8, ymm7, ymm0                   ; c5 47 7c c0                          
  2768 : vhaddps      ymm8, ymm0, ymm7                   ; c5 7f 7c c7                          
  2769 : vhaddps      ymm0, ymm8, ymm0                   ; c5 bf 7c c0                          
  2770 : vhaddps      ymm7, ymm8, ymm0                   ; c5 bf 7c f8                          
  2771 : vhaddps      ymm0, ymm15, ymm0                  ; c5 87 7c c0                          
  2772 : vhaddps      ymm0, ymm8, ymm7                   ; c5 bf 7c c7                          
  2773 : vhaddps      ymm0, ymm0, ymm8                   ; c4 c1 7f 7c c0                       
  2774 : vhaddps      ymm7, ymm0, ymm8                   ; c4 c1 7f 7c f8                       
  2775 : vhaddps      ymm0, ymm7, ymm8                   ; c4 c1 47 7c c0                       
  2776 : vhaddps      ymm0, ymm0, ymm15                  ; c4 c1 7f 7c c7                       
  2777 : vaddss       xmm0, xmm0, xmm0                   ; c5 fa 58 c0                          
  2778 : vaddss       xmm7, xmm0, xmm0                   ; c5 fa 58 f8                          
  2779 : vaddss       xmm0, xmm7, xmm0                   ; c5 c2 58 c0                          
  2780 : vaddss       xmm0, xmm0, xmm7                   ; c5 fa 58 c7                          
  2781 : vaddss       xmm8, xmm0, xmm0                   ; c5 7a 58 c0                          
  2782 : vaddss       xmm15, xmm0, xmm0                  ; c5 7a 58 f8                          
  2783 : vaddss       xmm8, xmm7, xmm0                   ; c5 42 58 c0                          
  2784 : vaddss       xmm8, xmm0, xmm7                   ; c5 7a 58 c7                          
  2785 : vaddss       xmm0, xmm8, xmm0                   ; c5 ba 58 c0                          
  2786 : vaddss       xmm7, xmm8, xmm0                   ; c5 ba 58 f8                          
  2787 : vaddss       xmm0, xmm15, xmm0                  ; c5 82 58 c0                          
  2788 : vaddss       xmm0, xmm8, xmm7                   ; c5 ba 58 c7                          
  2789 : vaddss       xmm0, xmm0, xmm8                   ; c4 c1 7a 58 c0                       
  2790 : vaddss       xmm7, xmm0, xmm8                   ; c4 c1 7a 58 f8                       
  2791 : vaddss       xmm0, xmm7, xmm8                   ; c4 c1 42 58 c0                       
  2792 : vaddss       xmm0, xmm0, xmm15                  ; c4 c1 7a 58 c7                       
  2793 : vhaddpd      ymm0, ymm0, ymm0                   ; c5 fd 7c c0                          
  2794 : vhaddpd      ymm7, ymm0, ymm0                   ; c5 fd 7c f8                          
  2795 : vhaddpd      ymm0, ymm7, ymm0                   ; c5 c5 7c c0                          
  2796 : vhaddpd      ymm0, ymm0, ymm7                   ; c5 fd 7c c7                          
  2797 : vhaddpd      ymm8, ymm0, ymm0                   ; c5 7d 7c c0                          
  2798 : vhaddpd      ymm15, ymm0, ymm0                  ; c5 7d 7c f8                          
  2799 : vhaddpd      ymm8, ymm7, ymm0                   ; c5 45 7c c0                          
  2800 : vhaddpd      ymm8, ymm0, ymm7                   ; c5 7d 7c c7                          
  2801 : vhaddpd      ymm0, ymm8, ymm0                   ; c5 bd 7c c0                          
  2802 : vhaddpd      ymm7, ymm8, ymm0                   ; c5 bd 7c f8                          
  2803 : vhaddpd      ymm0, ymm15, ymm0                  ; c5 85 7c c0                          
  2804 : vhaddpd      ymm0, ymm8, ymm7                   ; c5 bd 7c c7                          
  2805 : vhaddpd      ymm0, ymm0, ymm8                   ; c4 c1 7d 7c c0                       
  2806 : vhaddpd      ymm7, ymm0, ymm8                   ; c4 c1 7d 7c f8                       
  2807 : vhaddpd      ymm0, ymm7, ymm8                   ; c4 c1 45 7c c0                       
  2808 : vhaddpd      ymm0, ymm0, ymm15                  ; c4 c1 7d 7c c7                       
  2809 : vaddsd       xmm0, xmm0, xmm0                   ; c5 fb 58 c0                          
  2810 : vaddsd       xmm7, xmm0, xmm0                   ; c5 fb 58 f8                          
  2811 : vaddsd       xmm0, xmm7, xmm0                   ; c5 c3 58 c0                          
  2812 : vaddsd       xmm0, xmm0, xmm7                   ; c5 fb 58 c7                          
  2813 : vaddsd       xmm8, xmm0, xmm0                   ; c5 7b 58 c0                          
  2814 : vaddsd       xmm15, xmm0, xmm0                  ; c5 7b 58 f8                          
  2815 : vaddsd       xmm8, xmm7, xmm0                   ; c5 43 58 c0                          
  2816 : vaddsd       xmm8, xmm0, xmm7                   ; c5 7b 58 c7                          
  2817 : vaddsd       xmm0, xmm8, xmm0                   ; c5 bb 58 c0                          
  2818 : vaddsd       xmm7, xmm8, xmm0                   ; c5 bb 58 f8                          
  2819 : vaddsd       xmm0, xmm15, xmm0                  ; c5 83 58 c0                          
  2820 : vaddsd       xmm0, xmm8, xmm7                   ; c5 bb 58 c7                          
  2821 : vaddsd       xmm0, xmm0, xmm8                   ; c4 c1 7b 58 c0                       
  2822 : vaddsd       xmm7, xmm0, xmm8                   ; c4 c1 7b 58 f8                       
  2823 : vaddsd       xmm0, xmm7, xmm8                   ; c4 c1 43 58 c0                       
  2824 : vaddsd       xmm0, xmm0, xmm15                  ; c4 c1 7b 58 c7                       
  2825 : call         rax                                ; ff d0                                
  2826 : call         rdi                                ; ff d7                                
  2827 : call         r8                                 ; 41 ff d0                             
  2828 : call         r15                                ; 41 ff d7                             
  2829 : call         qword ptr [rsp + 0x0100]           ; ff 94 24 00 01 00 00                 
