instruction_set_test()
     0 : mov          rax, 0x010fffffff                  ; 48 b8 ff ff ff 0f 01 00 00 00        
     1 : mov          rdi, 0x010fffffff                  ; 48 bf ff ff ff 0f 01 00 00 00        
     2 : mov          r8, 0x010fffffff                   ; 49 b8 ff ff ff 0f 01 00 00 00        
     3 : mov          r15, 0x010fffffff                  ; 49 bf ff ff ff 0f 01 00 00 00        
     4 : mov          qword ptr [rsp + 0x0100], rax      ; 48 89 84 24 00 01 00 00              
     5 : mov          qword ptr [rsp + 0x0100], rdi      ; 48 89 bc 24 00 01 00 00              
     6 : mov          qword ptr [rsp + 0x0100], r8       ; 4c 89 84 24 00 01 00 00              
     7 : mov          qword ptr [rsp + 0x0100], r15      ; 4c 89 bc 24 00 01 00 00              
     8 : mov          qword ptr [rsp + 0x0100], 0x0101   ; 48 c7 84 24 00 01 00 00 01 01 00 00  
     9 : add          rax, 0x0100                        ; 48 05 00 01 00 00                    
    10 : add          rcx, 0x0100                        ; 48 81 c1 00 01 00 00                 
    11 : add          rdi, 0x0100                        ; 48 81 c7 00 01 00 00                 
    12 : add          r8, 0x0100                         ; 49 81 c0 00 01 00 00                 
    13 : add          r15, 0x0100                        ; 49 81 c7 00 01 00 00                 
    14 : add          rax, qword ptr [rsp + 0x0100]      ; 48 03 84 24 00 01 00 00              
    15 : add          rdi, qword ptr [rsp + 0x0100]      ; 48 03 bc 24 00 01 00 00              
    16 : add          r8, qword ptr [rsp + 0x0100]       ; 4c 03 84 24 00 01 00 00              
    17 : add          r15, qword ptr [rsp + 0x0100]      ; 4c 03 bc 24 00 01 00 00              
    18 : add          qword ptr [rsp + 0x0100], rax      ; 48 01 84 24 00 01 00 00              
    19 : add          qword ptr [rsp + 0x0100], rdi      ; 48 01 bc 24 00 01 00 00              
    20 : add          qword ptr [rsp + 0x0100], r8       ; 4c 01 84 24 00 01 00 00              
    21 : add          qword ptr [rsp + 0x0100], r15      ; 4c 01 bc 24 00 01 00 00              
    22 : add          qword ptr [rsp + 0x0100], 0x0101   ; 48 81 84 24 00 01 00 00 01 01 00 00  
    23 : sub          rax, 0x0100                        ; 48 2d 00 01 00 00                    
    24 : sub          rcx, 0x0100                        ; 48 81 e9 00 01 00 00                 
    25 : sub          rdi, 0x0100                        ; 48 81 ef 00 01 00 00                 
    26 : sub          r8, 0x0100                         ; 49 81 e8 00 01 00 00                 
    27 : sub          r15, 0x0100                        ; 49 81 ef 00 01 00 00                 
    28 : sub          rax, qword ptr [rsp + 0x0100]      ; 48 2b 84 24 00 01 00 00              
    29 : sub          rdi, qword ptr [rsp + 0x0100]      ; 48 2b bc 24 00 01 00 00              
    30 : sub          r8, qword ptr [rsp + 0x0100]       ; 4c 2b 84 24 00 01 00 00              
    31 : sub          r15, qword ptr [rsp + 0x0100]      ; 4c 2b bc 24 00 01 00 00              
    32 : sub          qword ptr [rsp + 0x0100], rax      ; 48 29 84 24 00 01 00 00              
    33 : sub          qword ptr [rsp + 0x0100], rdi      ; 48 29 bc 24 00 01 00 00              
    34 : sub          qword ptr [rsp + 0x0100], r8       ; 4c 29 84 24 00 01 00 00              
    35 : sub          qword ptr [rsp + 0x0100], r15      ; 4c 29 bc 24 00 01 00 00              
    36 : sub          qword ptr [rsp + 0x0100], 0x0101   ; 48 81 ac 24 00 01 00 00 01 01 00 00  
    37 : imul         rax, qword ptr [rsp + 0x0100]      ; 48 0f af 84 24 00 01 00 00           
    38 : imul         rdi, qword ptr [rsp + 0x0100]      ; 48 0f af bc 24 00 01 00 00           
    39 : imul         r8, qword ptr [rsp + 0x0100]       ; 4c 0f af 84 24 00 01 00 00           
    40 : imul         r15, qword ptr [rsp + 0x0100]      ; 4c 0f af bc 24 00 01 00 00           
    41 : idiv         qword ptr [rsp + 0x0100]           ; 48 f7 bc 24 00 01 00 00              
    42 : neg          qword ptr [rsp + 0x0100]           ; 48 f7 9c 24 00 01 00 00              
    43 : mov          qword ptr [rax], 0x0100            ; 48 c7 00 00 01 00 00                 
    44 : mov          qword ptr [rax], 0x0100            ; 48 c7 00 00 01 00 00                 
    45 : mov          qword ptr [rdi], 0x0100            ; 48 c7 07 00 01 00 00                 
    46 : mov          qword ptr [r8], 0x0100             ; 49 c7 00 00 01 00 00                 
    47 : mov          qword ptr [r12], 0x0100            ; 49 c7 04 24 00 01 00 00              
    48 : mov          qword ptr [r13], 0x0100            ; 49 c7 45 00 00 01 00 00              
    49 : mov          dword ptr [rax], 0x0100            ; c7 00 00 01 00 00                    
    50 : mov          dword ptr [rax], 0x0100            ; c7 00 00 01 00 00                    
    51 : mov          dword ptr [rdi], 0x0100            ; c7 07 00 01 00 00                    
    52 : mov          dword ptr [r8], 0x0100             ; 41 c7 00 00 01 00 00                 
    53 : mov          dword ptr [r12], 0x0100            ; 41 c7 04 24 00 01 00 00              
    54 : mov          dword ptr [r13], 0x0100            ; 41 c7 45 00 00 01 00 00              
    55 : mov          word ptr [rax], 0x0100             ; 66 c7 00 00 01                       
    56 : mov          word ptr [rax], 0x0100             ; 66 c7 00 00 01                       
    57 : mov          word ptr [rdi], 0x0100             ; 66 c7 07 00 01                       
    58 : mov          word ptr [r8], 0x0100              ; 66 41 c7 00 00 01                    
    59 : mov          word ptr [r12], 0x0100             ; 66 41 c7 04 24 00 01                 
    60 : mov          word ptr [r13], 0x0100             ; 66 41 c7 45 00 00 01                 
    61 : mov          byte ptr [rax], 0x0ff              ; c6 00 ff                             
    62 : mov          byte ptr [rax], 0x0ff              ; c6 00 ff                             
    63 : mov          byte ptr [rdi], 0x0ff              ; c6 07 ff                             
    64 : mov          byte ptr [r8], 0x0ff               ; 41 c6 00 ff                          
    65 : mov          byte ptr [r12], 0x0ff              ; 41 c6 04 24 ff                       
    66 : mov          byte ptr [r13], 0x0ff              ; 41 c6 45 00 ff                       
    67 : mov          qword ptr [rax], rax               ; 48 89 00                             
    68 : mov          qword ptr [rax], rax               ; 48 89 00                             
    69 : mov          qword ptr [rax], rdi               ; 48 89 38                             
    70 : mov          qword ptr [rax], r8                ; 4c 89 00                             
    71 : mov          qword ptr [rdi], rax               ; 48 89 07                             
    72 : mov          qword ptr [r8], rax                ; 49 89 00                             
    73 : mov          qword ptr [r8], r8                 ; 4d 89 00                             
    74 : mov          qword ptr [r12], rax               ; 49 89 04 24                          
    75 : mov          qword ptr [r12], rdi               ; 49 89 3c 24                          
    76 : mov          qword ptr [r12], r8                ; 4d 89 04 24                          
    77 : mov          qword ptr [r13], rax               ; 49 89 45 00                          
    78 : mov          qword ptr [r13], rdi               ; 49 89 7d 00                          
    79 : mov          qword ptr [r13], r8                ; 4d 89 45 00                          
    80 : mov          word ptr [rax], ax                 ; 66 89 00                             
    81 : mov          word ptr [rax], ax                 ; 66 89 00                             
    82 : mov          word ptr [rax], di                 ; 66 89 38                             
    83 : mov          word ptr [rax], r8w                ; 66 44 89 00                          
    84 : mov          word ptr [rdi], ax                 ; 66 89 07                             
    85 : mov          word ptr [r8], ax                  ; 66 41 89 00                          
    86 : mov          word ptr [r8], r8w                 ; 66 45 89 00                          
    87 : mov          word ptr [r12], ax                 ; 66 41 89 04 24                       
    88 : mov          word ptr [r12], di                 ; 66 41 89 3c 24                       
    89 : mov          word ptr [r12], r8w                ; 66 45 89 04 24                       
    90 : mov          word ptr [r13], ax                 ; 66 41 89 45 00                       
    91 : mov          word ptr [r13], di                 ; 66 41 89 7d 00                       
    92 : mov          word ptr [r13], r8w                ; 66 45 89 45 00                       
    93 : mov          byte ptr [rax], al                 ; 88 00                                
    94 : mov          byte ptr [rax], al                 ; 88 00                                
    95 : mov          byte ptr [rax], dil                ; 40 88 38                             
    96 : mov          byte ptr [rax], r8b                ; 44 88 00                             
    97 : mov          byte ptr [rdi], al                 ; 88 07                                
    98 : mov          byte ptr [r8], al                  ; 41 88 00                             
    99 : mov          byte ptr [r8], r8b                 ; 45 88 00                             
   100 : mov          byte ptr [r12], al                 ; 41 88 04 24                          
   101 : mov          byte ptr [r12], dil                ; 41 88 3c 24                          
   102 : mov          byte ptr [r12], r8b                ; 45 88 04 24                          
   103 : mov          byte ptr [r13], al                 ; 41 88 45 00                          
   104 : mov          byte ptr [r13], dil                ; 41 88 7d 00                          
   105 : mov          byte ptr [r13], r8b                ; 45 88 45 00                          
   106 : mov          qword ptr [rax + rax], rax         ; 48 89 04 00                          
   107 : mov          qword ptr [rax + rax], rax         ; 48 89 04 00                          
   108 : mov          qword ptr [rax + rax], rdi         ; 48 89 3c 00                          
   109 : mov          qword ptr [rax + rax], r8          ; 4c 89 04 00                          
   110 : mov          qword ptr [rax + rdi], rax         ; 48 89 04 38                          
   111 : mov          qword ptr [rax + r8], rax          ; 4a 89 04 00                          
   112 : mov          qword ptr [rax + r8], r8           ; 4e 89 04 00                          
   113 : mov          qword ptr [rdi + rax], rax         ; 48 89 04 07                          
   114 : mov          qword ptr [r8 + rax], rax          ; 49 89 04 00                          
   115 : mov          qword ptr [r8 + rax], r8           ; 4d 89 04 00                          
   116 : mov          qword ptr [r8 + r8], rax           ; 4b 89 04 00                          
   117 : mov          qword ptr [r8 + r8], r8            ; 4f 89 04 00                          
   118 : mov          qword ptr [r13 + rax], rax         ; 49 89 44 05 00                       
   119 : mov          qword ptr [r13 + rax], r8          ; 4d 89 44 05 00                       
   120 : mov          qword ptr [r13 + r8], rax          ; 4b 89 44 05 00                       
   121 : mov          qword ptr [r13 + r8], r8           ; 4f 89 44 05 00                       
   122 : mov          dword ptr [rax + rax], eax         ; 89 04 00                             
   123 : mov          dword ptr [rax + rax], eax         ; 89 04 00                             
   124 : mov          dword ptr [rax + rax], edi         ; 89 3c 00                             
   125 : mov          dword ptr [rax + rax], r8d         ; 44 89 04 00                          
   126 : mov          dword ptr [rax + rdi], eax         ; 89 04 38                             
   127 : mov          dword ptr [rax + r8], eax          ; 42 89 04 00                          
   128 : mov          dword ptr [rax + r8], r8d          ; 46 89 04 00                          
   129 : mov          dword ptr [rdi + rax], eax         ; 89 04 07                             
   130 : mov          dword ptr [r8 + rax], eax          ; 41 89 04 00                          
   131 : mov          dword ptr [r8 + rax], r8d          ; 45 89 04 00                          
   132 : mov          dword ptr [r8 + r8], eax           ; 43 89 04 00                          
   133 : mov          dword ptr [r8 + r8], r8d           ; 47 89 04 00                          
   134 : mov          dword ptr [r13 + rax], eax         ; 41 89 44 05 00                       
   135 : mov          dword ptr [r13 + rax], r8d         ; 45 89 44 05 00                       
   136 : mov          dword ptr [r13 + r8], eax          ; 43 89 44 05 00                       
   137 : mov          dword ptr [r13 + r8], r8d          ; 47 89 44 05 00                       
   138 : mov          word ptr [rax + rax], ax           ; 66 89 04 00                          
   139 : mov          word ptr [rax + rax], ax           ; 66 89 04 00                          
   140 : mov          word ptr [rax + rax], di           ; 66 89 3c 00                          
   141 : mov          word ptr [rax + rax], r8w          ; 66 44 89 04 00                       
   142 : mov          word ptr [rax + rdi], ax           ; 66 89 04 38                          
   143 : mov          word ptr [rax + r8], ax            ; 66 42 89 04 00                       
   144 : mov          word ptr [rax + r8], r8w           ; 66 46 89 04 00                       
   145 : mov          word ptr [rdi + rax], ax           ; 66 89 04 07                          
   146 : mov          word ptr [r8 + rax], ax            ; 66 41 89 04 00                       
   147 : mov          word ptr [r8 + rax], r8w           ; 66 45 89 04 00                       
   148 : mov          word ptr [r8 + r8], ax             ; 66 43 89 04 00                       
   149 : mov          word ptr [r8 + r8], r8w            ; 66 47 89 04 00                       
   150 : mov          word ptr [r13 + rax], ax           ; 66 41 89 44 05 00                    
   151 : mov          word ptr [r13 + r8], ax            ; 66 43 89 44 05 00                    
   152 : mov          word ptr [r13 + rax], r8w          ; 66 45 89 44 05 00                    
   153 : mov          word ptr [r13 + r8], r8w           ; 66 47 89 44 05 00                    
   154 : mov          byte ptr [rax + rax], al           ; 88 04 00                             
   155 : mov          byte ptr [rax + rax], al           ; 88 04 00                             
   156 : mov          byte ptr [rax + rax], dil          ; 40 88 3c 00                          
   157 : mov          byte ptr [rax + rax], r8b          ; 44 88 04 00                          
   158 : mov          byte ptr [rax + rdi], al           ; 88 04 38                             
   159 : mov          byte ptr [rax + r8], al            ; 42 88 04 00                          
   160 : mov          byte ptr [rax + r8], dil           ; 42 88 3c 00                          
   161 : mov          byte ptr [rax + r8], r8b           ; 46 88 04 00                          
   162 : mov          byte ptr [rdi + rax], al           ; 88 04 07                             
   163 : mov          byte ptr [r8 + rax], al            ; 41 88 04 00                          
   164 : mov          byte ptr [r8 + rax], dil           ; 41 88 3c 00                          
   165 : mov          byte ptr [r8 + rax], r8b           ; 45 88 04 00                          
   166 : mov          byte ptr [r8 + r8], al             ; 43 88 04 00                          
   167 : mov          byte ptr [r8 + r8], r8b            ; 47 88 04 00                          
   168 : mov          byte ptr [r8 + r8], dil            ; 43 88 3c 00                          
   169 : mov          byte ptr [r13 + rax], al           ; 41 88 44 05 00                       
   170 : mov          byte ptr [r13 + rax], r8b          ; 45 88 44 05 00                       
   171 : mov          byte ptr [r13 + r8], al            ; 43 88 44 05 00                       
   172 : mov          byte ptr [r13 + r8], r8b           ; 47 88 44 05 00                       
   173 : mov          qword ptr [rax + 0x0100], rax      ; 48 89 80 00 01 00 00                 
   174 : mov          qword ptr [rax + 0x0100], rax      ; 48 89 80 00 01 00 00                 
   175 : mov          qword ptr [rax + 0x0100], rdi      ; 48 89 b8 00 01 00 00                 
   176 : mov          qword ptr [rax + 0x0100], r8       ; 4c 89 80 00 01 00 00                 
   177 : mov          qword ptr [rdi + 0x0100], rax      ; 48 89 87 00 01 00 00                 
   178 : mov          qword ptr [r8 + 0x0100], rax       ; 49 89 80 00 01 00 00                 
   179 : mov          qword ptr [r8 + 0x0100], r8        ; 4d 89 80 00 01 00 00                 
   180 : mov          qword ptr [r12 + 0x0100], rax      ; 49 89 84 24 00 01 00 00              
   181 : mov          qword ptr [r12 + 0x0100], rdi      ; 49 89 bc 24 00 01 00 00              
   182 : mov          qword ptr [r12 + 0x0100], r8       ; 4d 89 84 24 00 01 00 00              
   183 : mov          dword ptr [rax + 0x0100], eax      ; 89 80 00 01 00 00                    
   184 : mov          dword ptr [rax + 0x0100], eax      ; 89 80 00 01 00 00                    
   185 : mov          dword ptr [rax + 0x0100], edi      ; 89 b8 00 01 00 00                    
   186 : mov          dword ptr [rax + 0x0100], r8d      ; 44 89 80 00 01 00 00                 
   187 : mov          dword ptr [rdi + 0x0100], eax      ; 89 87 00 01 00 00                    
   188 : mov          dword ptr [r8 + 0x0100], eax       ; 41 89 80 00 01 00 00                 
   189 : mov          dword ptr [r8 + 0x0100], r8d       ; 45 89 80 00 01 00 00                 
   190 : mov          dword ptr [r12 + 0x0100], eax      ; 41 89 84 24 00 01 00 00              
   191 : mov          dword ptr [r12 + 0x0100], r8d      ; 45 89 84 24 00 01 00 00              
   192 : mov          word ptr [rax + 0x0100], ax        ; 66 89 80 00 01 00 00                 
   193 : mov          word ptr [rax + 0x0100], ax        ; 66 89 80 00 01 00 00                 
   194 : mov          word ptr [rax + 0x0100], di        ; 66 89 b8 00 01 00 00                 
   195 : mov          word ptr [rax + 0x0100], r8w       ; 66 44 89 80 00 01 00 00              
   196 : mov          word ptr [rdi + 0x0100], ax        ; 66 89 87 00 01 00 00                 
   197 : mov          word ptr [r8 + 0x0100], ax         ; 66 41 89 80 00 01 00 00              
   198 : mov          word ptr [r8 + 0x0100], r8w        ; 66 45 89 80 00 01 00 00              
   199 : mov          word ptr [r12 + 0x0100], ax        ; 66 41 89 84 24 00 01 00 00           
   200 : mov          word ptr [r12 + 0x0100], r8w       ; 66 45 89 84 24 00 01 00 00           
   201 : mov          byte ptr [rax + 0x0100], al        ; 88 80 00 01 00 00                    
   202 : mov          byte ptr [rax + 0x0100], al        ; 88 80 00 01 00 00                    
   203 : mov          byte ptr [rax + 0x0100], dil       ; 40 88 b8 00 01 00 00                 
   204 : mov          byte ptr [rax + 0x0100], r8b       ; 44 88 80 00 01 00 00                 
   205 : mov          byte ptr [rdi + 0x0100], al        ; 88 87 00 01 00 00                    
   206 : mov          byte ptr [r8 + 0x0100], al         ; 41 88 80 00 01 00 00                 
   207 : mov          byte ptr [r8 + 0x0100], r8b        ; 45 88 80 00 01 00 00                 
   208 : mov          byte ptr [r12 + 0x0100], al        ; 41 88 84 24 00 01 00 00              
   209 : mov          byte ptr [r12 + 0x0100], r8b       ; 45 88 84 24 00 01 00 00              
   210 : mov          qword ptr [rax + rax], 0x0100      ; 48 c7 04 00 00 01 00 00              
   211 : mov          qword ptr [rax + rax], 0x0100      ; 48 c7 04 00 00 01 00 00              
   212 : mov          qword ptr [rax + rdi], 0x0100      ; 48 c7 04 38 00 01 00 00              
   213 : mov          qword ptr [rax + r8], 0x0100       ; 4a c7 04 00 00 01 00 00              
   214 : mov          qword ptr [rdi + rax], 0x0100      ; 48 c7 04 07 00 01 00 00              
   215 : mov          qword ptr [r8 + rax], 0x0100       ; 49 c7 04 00 00 01 00 00              
   216 : mov          qword ptr [r8 + r8], 0x0100        ; 4b c7 04 00 00 01 00 00              
   217 : mov          qword ptr [r13 + rax], 0x0100      ; 49 c7 44 05 00 00 01 00 00           
   218 : mov          qword ptr [r13 + r8], 0x0100       ; 4b c7 44 05 00 00 01 00 00           
   219 : mov          dword ptr [rax + rax], 0x0100      ; c7 04 00 00 01 00 00                 
   220 : mov          dword ptr [rax + rax], 0x0100      ; c7 04 00 00 01 00 00                 
   221 : mov          dword ptr [rax + rdi], 0x0100      ; c7 04 38 00 01 00 00                 
   222 : mov          dword ptr [rax + r8], 0x0100       ; 42 c7 04 00 00 01 00 00              
   223 : mov          dword ptr [rdi + rax], 0x0100      ; c7 04 07 00 01 00 00                 
   224 : mov          dword ptr [r8 + rax], 0x0100       ; 41 c7 04 00 00 01 00 00              
   225 : mov          dword ptr [r8 + r8], 0x0100        ; 43 c7 04 00 00 01 00 00              
   226 : mov          dword ptr [r13 + rax], 0x0100      ; 41 c7 44 05 00 00 01 00 00           
   227 : mov          dword ptr [r13 + r8], 0x0100       ; 43 c7 44 05 00 00 01 00 00           
   228 : mov          word ptr [rax + rax], 0x0100       ; 66 c7 04 00 00 01                    
   229 : mov          word ptr [rax + rax], 0x0100       ; 66 c7 04 00 00 01                    
   230 : mov          word ptr [rax + rdi], 0x0100       ; 66 c7 04 38 00 01                    
   231 : mov          word ptr [rax + r8], 0x0100        ; 66 42 c7 04 00 00 01                 
   232 : mov          word ptr [rdi + rax], 0x0100       ; 66 c7 04 07 00 01                    
   233 : mov          word ptr [r8 + rax], 0x0100        ; 66 41 c7 04 00 00 01                 
   234 : mov          word ptr [r8 + r8], 0x0100         ; 66 43 c7 04 00 00 01                 
   235 : mov          word ptr [r13 + rax], 0x0100       ; 66 41 c7 44 05 00 00 01              
   236 : mov          word ptr [r13 + r8], 0x0100        ; 66 43 c7 44 05 00 00 01              
   237 : mov          byte ptr [rax + rax], 0x0ff        ; c6 04 00 ff                          
   238 : mov          byte ptr [rax + rax], 0x0ff        ; c6 04 00 ff                          
   239 : mov          byte ptr [rax + rdi], 0x0ff        ; c6 04 38 ff                          
   240 : mov          byte ptr [rax + r8], 0x0ff         ; 42 c6 04 00 ff                       
   241 : mov          byte ptr [rdi + rax], 0x0ff        ; c6 04 07 ff                          
   242 : mov          byte ptr [r8 + rax], 0x0ff         ; 41 c6 04 00 ff                       
   243 : mov          byte ptr [r8 + r8], 0x0ff          ; 43 c6 04 00 ff                       
   244 : mov          byte ptr [r13 + rax], 0x0ff        ; 41 c6 44 05 00 ff                    
   245 : mov          byte ptr [r13 + r8], 0x0ff         ; 43 c6 44 05 00 ff                    
   246 : mov          qword ptr [rax + 0x0101], 0x0100   ; 48 c7 80 01 01 00 00 00 01 00 00     
   247 : mov          qword ptr [rax + 0x0101], 0x0100   ; 48 c7 80 01 01 00 00 00 01 00 00     
   248 : mov          qword ptr [rsp + 0x0101], 0x0100   ; 48 c7 84 24 01 01 00 00 00 01 00 00  
   249 : mov          qword ptr [rdi + 0x0101], 0x0100   ; 48 c7 87 01 01 00 00 00 01 00 00     
   250 : mov          qword ptr [r8 + 0x0101], 0x0100    ; 49 c7 80 01 01 00 00 00 01 00 00     
   251 : mov          qword ptr [r12 + 0x0101], 0x0100   ; 49 c7 84 24 01 01 00 00 00 01 00 00  
   252 : mov          dword ptr [rax + 0x0101], 0x0100   ; c7 80 01 01 00 00 00 01 00 00        
   253 : mov          dword ptr [rax + 0x0101], 0x0100   ; c7 80 01 01 00 00 00 01 00 00        
   254 : mov          dword ptr [rsp + 0x0101], 0x0100   ; c7 84 24 01 01 00 00 00 01 00 00     
   255 : mov          dword ptr [rdi + 0x0101], 0x0100   ; c7 87 01 01 00 00 00 01 00 00        
   256 : mov          dword ptr [r8 + 0x0101], 0x0100    ; 41 c7 80 01 01 00 00 00 01 00 00     
   257 : mov          dword ptr [r12 + 0x0101], 0x0100   ; 41 c7 84 24 01 01 00 00 00 01 00 00  
   258 : mov          word ptr [rax + 0x0101], 0x0100    ; 66 c7 80 01 01 00 00 00 01           
   259 : mov          word ptr [rax + 0x0101], 0x0100    ; 66 c7 80 01 01 00 00 00 01           
   260 : mov          word ptr [rsp + 0x0101], 0x0100    ; 66 c7 84 24 01 01 00 00 00 01        
   261 : mov          word ptr [rdi + 0x0101], 0x0100    ; 66 c7 87 01 01 00 00 00 01           
   262 : mov          word ptr [r8 + 0x0101], 0x0100     ; 66 41 c7 80 01 01 00 00 00 01        
   263 : mov          word ptr [r12 + 0x0101], 0x0100    ; 66 41 c7 84 24 01 01 00 00 00 01     
   264 : mov          byte ptr [rax + 0x0101], 0x0ff     ; c6 80 01 01 00 00 ff                 
   265 : mov          byte ptr [rsp + 0x0101], 0x0ff     ; c6 84 24 01 01 00 00 ff              
   266 : mov          byte ptr [rax + 0x0101], 0x0ff     ; c6 80 01 01 00 00 ff                 
   267 : mov          byte ptr [rdi + 0x0101], 0x0ff     ; c6 87 01 01 00 00 ff                 
   268 : mov          byte ptr [r8 + 0x0101], 0x0ff      ; 41 c6 80 01 01 00 00 ff              
   269 : mov          byte ptr [r12 + 0x0101], 0x0ff     ; 41 c6 84 24 01 01 00 00 ff           
   270 : mov          rax, qword ptr [rax]               ; 48 8b 00                             
   271 : mov          rax, qword ptr [rax]               ; 48 8b 00                             
   272 : mov          rdi, qword ptr [rax]               ; 48 8b 38                             
   273 : mov          rax, qword ptr [rdi]               ; 48 8b 07                             
   274 : mov          rax, qword ptr [rax]               ; 48 8b 00                             
   275 : mov          r8, qword ptr [rax]                ; 4c 8b 00                             
   276 : mov          rax, qword ptr [r8]                ; 49 8b 00                             
   277 : mov          rax, qword ptr [r12]               ; 49 8b 04 24                          
   278 : mov          rax, qword ptr [r13]               ; 49 8b 45 00                          
   279 : mov          r8, qword ptr [r8]                 ; 4d 8b 00                             
   280 : mov          r8, qword ptr [r12]                ; 4d 8b 04 24                          
   281 : mov          r8, qword ptr [r13]                ; 4d 8b 45 00                          
   282 : mov          eax, dword ptr [rax]               ; 8b 00                                
   283 : mov          edi, dword ptr [rax]               ; 8b 38                                
   284 : mov          eax, dword ptr [rdi]               ; 8b 07                                
   285 : mov          eax, dword ptr [rax]               ; 8b 00                                
   286 : mov          r8d, dword ptr [rax]               ; 44 8b 00                             
   287 : mov          eax, dword ptr [r8]                ; 41 8b 00                             
   288 : mov          eax, dword ptr [r12]               ; 41 8b 04 24                          
   289 : mov          eax, dword ptr [r13]               ; 41 8b 45 00                          
   290 : mov          r8d, dword ptr [r8]                ; 45 8b 00                             
   291 : mov          r8d, dword ptr [r12]               ; 45 8b 04 24                          
   292 : mov          r8d, dword ptr [r13]               ; 45 8b 45 00                          
   293 : movsxd       rax, dword ptr [rax]               ; 48 63 00                             
   294 : movsxd       rdi, dword ptr [rax]               ; 48 63 38                             
   295 : movsxd       rax, dword ptr [rdi]               ; 48 63 07                             
   296 : movsxd       r8, dword ptr [rax]                ; 4c 63 00                             
   297 : movsxd       rax, dword ptr [r8]                ; 49 63 00                             
   298 : movsxd       rax, dword ptr [r12]               ; 49 63 04 24                          
   299 : movsxd       rax, dword ptr [r13]               ; 49 63 45 00                          
   300 : movsxd       r8, dword ptr [r8]                 ; 4d 63 00                             
   301 : movsxd       r8, dword ptr [r12]                ; 4d 63 04 24                          
   302 : movsxd       r8, dword ptr [r13]                ; 4d 63 45 00                          
   303 : movzx        rax, word ptr [rax]                ; 48 0f b7 00                          
   304 : movzx        rdi, word ptr [rax]                ; 48 0f b7 38                          
   305 : movzx        rax, word ptr [rdi]                ; 48 0f b7 07                          
   306 : movzx        r8, word ptr [rax]                 ; 4c 0f b7 00                          
   307 : movzx        rax, word ptr [r8]                 ; 49 0f b7 00                          
   308 : movzx        rax, word ptr [r12]                ; 49 0f b7 04 24                       
   309 : movzx        rax, word ptr [r13]                ; 49 0f b7 45 00                       
   310 : movzx        r8, word ptr [r8]                  ; 4d 0f b7 00                          
   311 : movzx        r8, word ptr [r12]                 ; 4d 0f b7 04 24                       
   312 : movzx        r8, word ptr [r13]                 ; 4d 0f b7 45 00                       
   313 : movsx        rax, word ptr [rax]                ; 48 0f bf 00                          
   314 : movsx        rdi, word ptr [rax]                ; 48 0f bf 38                          
   315 : movsx        rax, word ptr [rdi]                ; 48 0f bf 07                          
   316 : movsx        r8, word ptr [rax]                 ; 4c 0f bf 00                          
   317 : movsx        rax, word ptr [r8]                 ; 49 0f bf 00                          
   318 : movsx        rax, word ptr [r12]                ; 49 0f bf 04 24                       
   319 : movsx        rax, word ptr [r13]                ; 49 0f bf 45 00                       
   320 : movsx        r8, word ptr [r8]                  ; 4d 0f bf 00                          
   321 : movsx        r8, word ptr [r12]                 ; 4d 0f bf 04 24                       
   322 : movsx        r8, word ptr [r13]                 ; 4d 0f bf 45 00                       
   323 : movzx        rax, byte ptr [rax]                ; 48 0f b6 00                          
   324 : movzx        rdi, byte ptr [rax]                ; 48 0f b6 38                          
   325 : movzx        rax, byte ptr [rdi]                ; 48 0f b6 07                          
   326 : movzx        r8, byte ptr [rax]                 ; 4c 0f b6 00                          
   327 : movzx        rax, byte ptr [r8]                 ; 49 0f b6 00                          
   328 : movzx        rax, byte ptr [r12]                ; 49 0f b6 04 24                       
   329 : movzx        rax, byte ptr [r13]                ; 49 0f b6 45 00                       
   330 : movzx        r8, byte ptr [r8]                  ; 4d 0f b6 00                          
   331 : movzx        r8, byte ptr [r12]                 ; 4d 0f b6 04 24                       
   332 : movzx        r8, byte ptr [r13]                 ; 4d 0f b6 45 00                       
   333 : movsx        rax, byte ptr [rax]                ; 48 0f be 00                          
   334 : movsx        rdi, byte ptr [rax]                ; 48 0f be 38                          
   335 : movsx        rax, byte ptr [rdi]                ; 48 0f be 07                          
   336 : movsx        r8, byte ptr [rax]                 ; 4c 0f be 00                          
   337 : movsx        rax, byte ptr [r8]                 ; 49 0f be 00                          
   338 : movsx        rax, byte ptr [r12]                ; 49 0f be 04 24                       
   339 : movsx        rax, byte ptr [r13]                ; 49 0f be 45 00                       
   340 : movsx        r8, byte ptr [r8]                  ; 4d 0f be 00                          
   341 : movsx        r8, byte ptr [r12]                 ; 4d 0f be 04 24                       
   342 : movsx        r8, byte ptr [r13]                 ; 4d 0f be 45 00                       
   343 : mov          rax, qword ptr [rax + 0x0100]      ; 48 8b 80 00 01 00 00                 
   344 : mov          rax, qword ptr [rax + 0x0100]      ; 48 8b 80 00 01 00 00                 
   345 : mov          rdi, qword ptr [rax + 0x0100]      ; 48 8b b8 00 01 00 00                 
   346 : mov          rax, qword ptr [rsp + 0x0100]      ; 48 8b 84 24 00 01 00 00              
   347 : mov          rax, qword ptr [rdi + 0x0100]      ; 48 8b 87 00 01 00 00                 
   348 : mov          rax, qword ptr [rax + 0x0100]      ; 48 8b 80 00 01 00 00                 
   349 : mov          r8, qword ptr [rax + 0x0100]       ; 4c 8b 80 00 01 00 00                 
   350 : mov          rax, qword ptr [r8 + 0x0100]       ; 49 8b 80 00 01 00 00                 
   351 : mov          rax, qword ptr [r12 + 0x0100]      ; 49 8b 84 24 00 01 00 00              
   352 : mov          r8, qword ptr [r8 + 0x0100]        ; 4d 8b 80 00 01 00 00                 
   353 : mov          r8, qword ptr [r12 + 0x0100]       ; 4d 8b 84 24 00 01 00 00              
   354 : mov          eax, dword ptr [rax + 0x0100]      ; 8b 80 00 01 00 00                    
   355 : mov          edi, dword ptr [rax + 0x0100]      ; 8b b8 00 01 00 00                    
   356 : mov          eax, dword ptr [rsp + 0x0100]      ; 8b 84 24 00 01 00 00                 
   357 : mov          eax, dword ptr [rdi + 0x0100]      ; 8b 87 00 01 00 00                    
   358 : mov          r8d, dword ptr [rax + 0x0100]      ; 44 8b 80 00 01 00 00                 
   359 : mov          eax, dword ptr [r8 + 0x0100]       ; 41 8b 80 00 01 00 00                 
   360 : mov          eax, dword ptr [r12 + 0x0100]      ; 41 8b 84 24 00 01 00 00              
   361 : mov          r8d, dword ptr [r8 + 0x0100]       ; 45 8b 80 00 01 00 00                 
   362 : mov          r8d, dword ptr [r12 + 0x0100]      ; 45 8b 84 24 00 01 00 00              
   363 : movsxd       rax, dword ptr [rax + 0x0100]      ; 48 63 80 00 01 00 00                 
   364 : movsxd       rdi, dword ptr [rax + 0x0100]      ; 48 63 b8 00 01 00 00                 
   365 : movsxd       rax, dword ptr [rsp + 0x0100]      ; 48 63 84 24 00 01 00 00              
   366 : movsxd       rax, dword ptr [rdi + 0x0100]      ; 48 63 87 00 01 00 00                 
   367 : movsxd       r8, dword ptr [rax + 0x0100]       ; 4c 63 80 00 01 00 00                 
   368 : movsxd       rax, dword ptr [r8 + 0x0100]       ; 49 63 80 00 01 00 00                 
   369 : movsxd       rax, dword ptr [r12 + 0x0100]      ; 49 63 84 24 00 01 00 00              
   370 : movsxd       r8, dword ptr [r8 + 0x0100]        ; 4d 63 80 00 01 00 00                 
   371 : movsxd       r8, dword ptr [r12 + 0x0100]       ; 4d 63 84 24 00 01 00 00              
   372 : movzx        rax, word ptr [rax + 0x0100]       ; 48 0f b7 80 00 01 00 00              
   373 : movzx        rdi, word ptr [rax + 0x0100]       ; 48 0f b7 b8 00 01 00 00              
   374 : movzx        rax, word ptr [rsp + 0x0100]       ; 48 0f b7 84 24 00 01 00 00           
   375 : movzx        rax, word ptr [rdi + 0x0100]       ; 48 0f b7 87 00 01 00 00              
   376 : movzx        r8, word ptr [rax + 0x0100]        ; 4c 0f b7 80 00 01 00 00              
   377 : movzx        rax, word ptr [r8 + 0x0100]        ; 49 0f b7 80 00 01 00 00              
   378 : movzx        rax, word ptr [r12 + 0x0100]       ; 49 0f b7 84 24 00 01 00 00           
   379 : movzx        r8, word ptr [r8 + 0x0100]         ; 4d 0f b7 80 00 01 00 00              
   380 : movzx        r8, word ptr [r12 + 0x0100]        ; 4d 0f b7 84 24 00 01 00 00           
   381 : movsx        rax, word ptr [rax + 0x0100]       ; 48 0f bf 80 00 01 00 00              
   382 : movsx        rdi, word ptr [rax + 0x0100]       ; 48 0f bf b8 00 01 00 00              
   383 : movsx        rax, word ptr [rsp + 0x0100]       ; 48 0f bf 84 24 00 01 00 00           
   384 : movsx        rax, word ptr [rdi + 0x0100]       ; 48 0f bf 87 00 01 00 00              
   385 : movsx        r8, word ptr [rax + 0x0100]        ; 4c 0f bf 80 00 01 00 00              
   386 : movsx        rax, word ptr [r8 + 0x0100]        ; 49 0f bf 80 00 01 00 00              
   387 : movsx        rax, word ptr [r12 + 0x0100]       ; 49 0f bf 84 24 00 01 00 00           
   388 : movsx        r8, word ptr [r8 + 0x0100]         ; 4d 0f bf 80 00 01 00 00              
   389 : movsx        r8, word ptr [r12 + 0x0100]        ; 4d 0f bf 84 24 00 01 00 00           
   390 : movzx        rax, byte ptr [rax + 0x0100]       ; 48 0f b6 80 00 01 00 00              
   391 : movzx        rdi, byte ptr [rax + 0x0100]       ; 48 0f b6 b8 00 01 00 00              
   392 : movzx        rax, byte ptr [rsp + 0x0100]       ; 48 0f b6 84 24 00 01 00 00           
   393 : movzx        rax, byte ptr [rdi + 0x0100]       ; 48 0f b6 87 00 01 00 00              
   394 : movzx        r8, byte ptr [rax + 0x0100]        ; 4c 0f b6 80 00 01 00 00              
   395 : movzx        rax, byte ptr [r8 + 0x0100]        ; 49 0f b6 80 00 01 00 00              
   396 : movzx        rax, byte ptr [r12 + 0x0100]       ; 49 0f b6 84 24 00 01 00 00           
   397 : movzx        r8, byte ptr [r8 + 0x0100]         ; 4d 0f b6 80 00 01 00 00              
   398 : movzx        r8, byte ptr [r12 + 0x0100]        ; 4d 0f b6 84 24 00 01 00 00           
   399 : movsx        rax, byte ptr [rax + 0x0100]       ; 48 0f be 80 00 01 00 00              
   400 : movsx        rdi, byte ptr [rax + 0x0100]       ; 48 0f be b8 00 01 00 00              
   401 : movsx        rax, byte ptr [rsp + 0x0100]       ; 48 0f be 84 24 00 01 00 00           
   402 : movsx        rax, byte ptr [rdi + 0x0100]       ; 48 0f be 87 00 01 00 00              
   403 : movsx        r8, byte ptr [rax + 0x0100]        ; 4c 0f be 80 00 01 00 00              
   404 : movsx        rax, byte ptr [r8 + 0x0100]        ; 49 0f be 80 00 01 00 00              
   405 : movsx        rax, byte ptr [r12 + 0x0100]       ; 49 0f be 84 24 00 01 00 00           
   406 : movsx        r8, byte ptr [r8 + 0x0100]         ; 4d 0f be 80 00 01 00 00              
   407 : movsx        r8, byte ptr [r12 + 0x0100]        ; 4d 0f be 84 24 00 01 00 00           
   408 : mov          rax, qword ptr [rax + rax]         ; 48 8b 04 00                          
   409 : mov          rax, qword ptr [rax + rax]         ; 48 8b 04 00                          
   410 : mov          rdi, qword ptr [rax + rax]         ; 48 8b 3c 00                          
   411 : mov          rax, qword ptr [rdi + rax]         ; 48 8b 04 07                          
   412 : mov          rax, qword ptr [rax + rdi]         ; 48 8b 04 38                          
   413 : mov          rax, qword ptr [rax + rax]         ; 48 8b 04 00                          
   414 : mov          r8, qword ptr [rax + rax]          ; 4c 8b 04 00                          
   415 : mov          rax, qword ptr [r8 + rax]          ; 49 8b 04 00                          
   416 : mov          r8, qword ptr [r8 + rax]           ; 4d 8b 04 00                          
   417 : mov          rax, qword ptr [r13 + rax]         ; 49 8b 44 05 00                       
   418 : mov          r8, qword ptr [r13 + rax]          ; 4d 8b 44 05 00                       
   419 : mov          rax, qword ptr [rax + r8]          ; 4a 8b 04 00                          
   420 : mov          r8, qword ptr [rax + r8]           ; 4e 8b 04 00                          
   421 : mov          rax, qword ptr [r8 + r8]           ; 4b 8b 04 00                          
   422 : mov          r8, qword ptr [r8 + r8]            ; 4f 8b 04 00                          
   423 : mov          rax, qword ptr [r13 + r8]          ; 4b 8b 44 05 00                       
   424 : mov          r8, qword ptr [r13 + r8]           ; 4f 8b 44 05 00                       
   425 : mov          eax, dword ptr [rax + rax]         ; 8b 04 00                             
   426 : mov          edi, dword ptr [rax + rax]         ; 8b 3c 00                             
   427 : mov          eax, dword ptr [rdi + rax]         ; 8b 04 07                             
   428 : mov          eax, dword ptr [rax + rdi]         ; 8b 04 38                             
   429 : mov          r8d, dword ptr [rax + rax]         ; 44 8b 04 00                          
   430 : mov          eax, dword ptr [r8 + rax]          ; 41 8b 04 00                          
   431 : mov          r8d, dword ptr [r8 + rax]          ; 45 8b 04 00                          
   432 : mov          eax, dword ptr [r13 + rax]         ; 41 8b 44 05 00                       
   433 : mov          r8d, dword ptr [r13 + rax]         ; 45 8b 44 05 00                       
   434 : mov          eax, dword ptr [rax + r8]          ; 42 8b 04 00                          
   435 : mov          r8d, dword ptr [rax + r8]          ; 46 8b 04 00                          
   436 : mov          eax, dword ptr [r8 + r8]           ; 43 8b 04 00                          
   437 : mov          r8d, dword ptr [r8 + r8]           ; 47 8b 04 00                          
   438 : mov          eax, dword ptr [r13 + r8]          ; 43 8b 44 05 00                       
   439 : mov          r8d, dword ptr [r13 + r8]          ; 47 8b 44 05 00                       
   440 : movsxd       rax, dword ptr [rax + rax]         ; 48 63 04 00                          
   441 : movsxd       rdi, dword ptr [rax + rax]         ; 48 63 3c 00                          
   442 : movsxd       rax, dword ptr [rdi + rax]         ; 48 63 04 07                          
   443 : movsxd       rax, dword ptr [rax + rdi]         ; 48 63 04 38                          
   444 : movsxd       r8, dword ptr [rax + rax]          ; 4c 63 04 00                          
   445 : movsxd       rax, dword ptr [r8 + rax]          ; 49 63 04 00                          
   446 : movsxd       r8, dword ptr [r8 + rax]           ; 4d 63 04 00                          
   447 : movsxd       rax, dword ptr [r13 + rax]         ; 49 63 44 05 00                       
   448 : movsxd       r8, dword ptr [r13 + rax]          ; 4d 63 44 05 00                       
   449 : movsxd       rax, dword ptr [rax + r8]          ; 4a 63 04 00                          
   450 : movsxd       r8, dword ptr [rax + r8]           ; 4e 63 04 00                          
   451 : movsxd       rax, dword ptr [r8 + r8]           ; 4b 63 04 00                          
   452 : movsxd       r8, dword ptr [r8 + r8]            ; 4f 63 04 00                          
   453 : movsxd       rax, dword ptr [r13 + r8]          ; 4b 63 44 05 00                       
   454 : movsxd       r8, dword ptr [r13 + r8]           ; 4f 63 44 05 00                       
   455 : movzx        rax, word ptr [rax + rax]          ; 48 0f b7 04 00                       
   456 : movzx        rdi, word ptr [rax + rax]          ; 48 0f b7 3c 00                       
   457 : movzx        rax, word ptr [rdi + rax]          ; 48 0f b7 04 07                       
   458 : movzx        rax, word ptr [rax + rdi]          ; 48 0f b7 04 38                       
   459 : movzx        r8, word ptr [rax + rax]           ; 4c 0f b7 04 00                       
   460 : movzx        rax, word ptr [r8 + rax]           ; 49 0f b7 04 00                       
   461 : movzx        r8, word ptr [r8 + rax]            ; 4d 0f b7 04 00                       
   462 : movzx        rax, word ptr [r13 + rax]          ; 49 0f b7 44 05 00                    
   463 : movzx        r8, word ptr [r13 + rax]           ; 4d 0f b7 44 05 00                    
   464 : movzx        rax, word ptr [rax + r8]           ; 4a 0f b7 04 00                       
   465 : movzx        r8, word ptr [rax + r8]            ; 4e 0f b7 04 00                       
   466 : movzx        rax, word ptr [r8 + r8]            ; 4b 0f b7 04 00                       
   467 : movzx        r8, word ptr [r8 + r8]             ; 4f 0f b7 04 00                       
   468 : movzx        rax, word ptr [r13 + r8]           ; 4b 0f b7 44 05 00                    
   469 : movzx        r8, word ptr [r13 + r8]            ; 4f 0f b7 44 05 00                    
   470 : movsx        rax, word ptr [rax + rax]          ; 48 0f bf 04 00                       
   471 : movsx        rdi, word ptr [rax + rax]          ; 48 0f bf 3c 00                       
   472 : movsx        rax, word ptr [rdi + rax]          ; 48 0f bf 04 07                       
   473 : movsx        rax, word ptr [rax + rdi]          ; 48 0f bf 04 38                       
   474 : movsx        r8, word ptr [rax + rax]           ; 4c 0f bf 04 00                       
   475 : movsx        rax, word ptr [r8 + rax]           ; 49 0f bf 04 00                       
   476 : movsx        r8, word ptr [r8 + rax]            ; 4d 0f bf 04 00                       
   477 : movsx        rax, word ptr [r13 + rax]          ; 49 0f bf 44 05 00                    
   478 : movsx        r8, word ptr [r13 + rax]           ; 4d 0f bf 44 05 00                    
   479 : movsx        rax, word ptr [rax + r8]           ; 4a 0f bf 04 00                       
   480 : movsx        r8, word ptr [rax + r8]            ; 4e 0f bf 04 00                       
   481 : movsx        rax, word ptr [r8 + r8]            ; 4b 0f bf 04 00                       
   482 : movsx        r8, word ptr [r8 + r8]             ; 4f 0f bf 04 00                       
   483 : movsx        rax, word ptr [r13 + r8]           ; 4b 0f bf 44 05 00                    
   484 : movsx        r8, word ptr [r13 + r8]            ; 4f 0f bf 44 05 00                    
   485 : movzx        rax, byte ptr [rax + rax]          ; 48 0f b6 04 00                       
   486 : movzx        rdi, byte ptr [rax + rax]          ; 48 0f b6 3c 00                       
   487 : movzx        rax, byte ptr [rdi + rax]          ; 48 0f b6 04 07                       
   488 : movzx        rax, byte ptr [rax + rdi]          ; 48 0f b6 04 38                       
   489 : movzx        r8, byte ptr [rax + rax]           ; 4c 0f b6 04 00                       
   490 : movzx        rax, byte ptr [r8 + rax]           ; 49 0f b6 04 00                       
   491 : movzx        r8, byte ptr [r8 + rax]            ; 4d 0f b6 04 00                       
   492 : movzx        rax, byte ptr [r13 + rax]          ; 49 0f b6 44 05 00                    
   493 : movzx        r8, byte ptr [r13 + rax]           ; 4d 0f b6 44 05 00                    
   494 : movzx        rax, byte ptr [rax + r8]           ; 4a 0f b6 04 00                       
   495 : movzx        r8, byte ptr [rax + r8]            ; 4e 0f b6 04 00                       
   496 : movzx        rax, byte ptr [r8 + r8]            ; 4b 0f b6 04 00                       
   497 : movzx        r8, byte ptr [r8 + r8]             ; 4f 0f b6 04 00                       
   498 : movzx        rax, byte ptr [r13 + r8]           ; 4b 0f b6 44 05 00                    
   499 : movzx        r8, byte ptr [r13 + r8]            ; 4f 0f b6 44 05 00                    
   500 : movsx        rax, byte ptr [rax + rax]          ; 48 0f be 04 00                       
   501 : movsx        rdi, byte ptr [rax + rax]          ; 48 0f be 3c 00                       
   502 : movsx        rax, byte ptr [rdi + rax]          ; 48 0f be 04 07                       
   503 : movsx        rax, byte ptr [rax + rdi]          ; 48 0f be 04 38                       
   504 : movsx        r8, byte ptr [rax + rax]           ; 4c 0f be 04 00                       
   505 : movsx        rax, byte ptr [r8 + rax]           ; 49 0f be 04 00                       
   506 : movsx        r8, byte ptr [r8 + rax]            ; 4d 0f be 04 00                       
   507 : movsx        rax, byte ptr [r13 + rax]          ; 49 0f be 44 05 00                    
   508 : movsx        r8, byte ptr [r13 + rax]           ; 4d 0f be 44 05 00                    
   509 : movsx        rax, byte ptr [rax + r8]           ; 4a 0f be 04 00                       
   510 : movsx        r8, byte ptr [rax + r8]            ; 4e 0f be 04 00                       
   511 : movsx        rax, byte ptr [r8 + r8]            ; 4b 0f be 04 00                       
   512 : movsx        r8, byte ptr [r8 + r8]             ; 4f 0f be 04 00                       
   513 : movsx        rax, byte ptr [r13 + r8]           ; 4b 0f be 44 05 00                    
   514 : movsx        r8, byte ptr [r13 + r8]            ; 4f 0f be 44 05 00                    
   515 : xchg         rax, rax                           ; 48 90                                
   516 : xchg         rax, rdi                           ; 48 97                                
   517 : xchg         rax, r8                            ; 49 90                                
   518 : xchg         rcx, rcx                           ; 48 87 c9                             
   519 : xchg         rdi, rcx                           ; 48 87 cf                             
   520 : xchg         rcx, rdi                           ; 48 87 f9                             
   521 : xchg         rcx, rcx                           ; 48 87 c9                             
   522 : xchg         r8, rcx                            ; 49 87 c8                             
   523 : xchg         rcx, r8                            ; 4c 87 c1                             
   524 : xchg         r8, r8                             ; 4d 87 c0                             
   525 : xchg         rcx, qword ptr [rsp + 0x0100]      ; 48 87 8c 24 00 01 00 00              
   526 : xchg         rdi, qword ptr [rsp + 0x0100]      ; 48 87 bc 24 00 01 00 00              
   527 : xchg         r8, qword ptr [rsp + 0x0100]       ; 4c 87 84 24 00 01 00 00              
   528 : xchg         r15, qword ptr [rsp + 0x0100]      ; 4c 87 bc 24 00 01 00 00              
   529 : xchg         qword ptr [rsp + 0x0100], rcx      ; 48 87 8c 24 00 01 00 00              
   530 : xchg         qword ptr [rsp + 0x0100], rdi      ; 48 87 bc 24 00 01 00 00              
   531 : xchg         qword ptr [rsp + 0x0100], r8       ; 4c 87 84 24 00 01 00 00              
   532 : xchg         qword ptr [rsp + 0x0100], r15      ; 4c 87 bc 24 00 01 00 00              
   533 : shl          rax, 0x00f                         ; 48 c1 e0 0f                          
   534 : shl          rdi, 0x00f                         ; 48 c1 e7 0f                          
   535 : shl          r8, 0x00f                          ; 49 c1 e0 0f                          
   536 : shl          qword ptr [rsp + 0x0100], 0x00f    ; 48 c1 a4 24 00 01 00 00 0f           
   537 : shl          rax, cl                            ; 48 d3 e0                             
   538 : shl          rdi, cl                            ; 48 d3 e7                             
   539 : shl          r8, cl                             ; 49 d3 e0                             
   540 : shl          qword ptr [rsp + 0x0100], cl       ; 48 d3 a4 24 00 01 00 00              
   541 : shr          rax, 0x00f                         ; 48 c1 e8 0f                          
   542 : shr          rdi, 0x00f                         ; 48 c1 ef 0f                          
   543 : shr          r8, 0x00f                          ; 49 c1 e8 0f                          
   544 : shr          qword ptr [rsp + 0x0100], 0x00f    ; 48 c1 ac 24 00 01 00 00 0f           
   545 : shr          rax, cl                            ; 48 d3 e8                             
   546 : shr          rdi, cl                            ; 48 d3 ef                             
   547 : shr          r8, cl                             ; 49 d3 e8                             
   548 : shr          qword ptr [rsp + 0x0100], cl       ; 48 d3 ac 24 00 01 00 00              
   549 : sar          rax, 0x00f                         ; 48 c1 f8 0f                          
   550 : sar          rdi, 0x00f                         ; 48 c1 ff 0f                          
   551 : sar          r8, 0x00f                          ; 49 c1 f8 0f                          
   552 : sar          qword ptr [rsp + 0x0100], 0x00f    ; 48 c1 bc 24 00 01 00 00 0f           
   553 : sar          rax, cl                            ; 48 d3 f8                             
   554 : sar          rdi, cl                            ; 48 d3 ff                             
   555 : sar          r8, cl                             ; 49 d3 f8                             
   556 : sar          qword ptr [rsp + 0x0100], cl       ; 48 d3 bc 24 00 01 00 00              
   557 : and          rax, rax                           ; 48 21 c0                             
   558 : and          rax, rdi                           ; 48 21 f8                             
   559 : and          rdi, rax                           ; 48 21 c7                             
   560 : and          rax, r8                            ; 4c 21 c0                             
   561 : and          r8, rax                            ; 49 21 c0                             
   562 : and          r8, r8                             ; 4d 21 c0                             
   563 : and          rax, qword ptr [rsp + 0x0100]      ; 48 23 84 24 00 01 00 00              
   564 : and          rdi, qword ptr [rsp + 0x0100]      ; 48 23 bc 24 00 01 00 00              
   565 : and          r8, qword ptr [rsp + 0x0100]       ; 4c 23 84 24 00 01 00 00              
   566 : and          rax, 0x0100                        ; 48 25 00 01 00 00                    
   567 : and          rcx, 0x0100                        ; 48 81 e1 00 01 00 00                 
   568 : and          rdi, 0x0100                        ; 48 81 e7 00 01 00 00                 
   569 : and          r8, 0x0100                         ; 49 81 e0 00 01 00 00                 
   570 : and          qword ptr [rsp + 0x0100], rax      ; 48 21 84 24 00 01 00 00              
   571 : and          qword ptr [rsp + 0x0100], rdi      ; 48 21 bc 24 00 01 00 00              
   572 : and          qword ptr [rsp + 0x0100], r8       ; 4c 21 84 24 00 01 00 00              
   573 : and          qword ptr [rsp + 0x0100], 0x0101   ; 48 81 a4 24 00 01 00 00 01 01 00 00  
   574 : or           rax, rax                           ; 48 09 c0                             
   575 : or           rax, rdi                           ; 48 09 f8                             
   576 : or           rdi, rax                           ; 48 09 c7                             
   577 : or           rax, r8                            ; 4c 09 c0                             
   578 : or           r8, rax                            ; 49 09 c0                             
   579 : or           qword ptr [rsp + 0x0100], rax      ; 48 09 84 24 00 01 00 00              
   580 : or           qword ptr [rsp + 0x0100], r8       ; 4c 09 84 24 00 01 00 00              
   581 : or           rax, qword ptr [rsp + 0x0100]      ; 48 0b 84 24 00 01 00 00              
   582 : or           r8, qword ptr [rsp + 0x0100]       ; 4c 0b 84 24 00 01 00 00              
   583 : or           rax, 0x0100                        ; 48 0d 00 01 00 00                    
   584 : or           r8, 0x0100                         ; 49 81 c8 00 01 00 00                 
   585 : or           qword ptr [rsp + 0x0100], 0x0101   ; 48 81 8c 24 00 01 00 00 01 01 00 00  
   586 : xor          rax, rax                           ; 48 31 c0                             
   587 : xor          rax, rdi                           ; 48 31 f8                             
   588 : xor          rdi, rax                           ; 48 31 c7                             
   589 : xor          rax, r8                            ; 4c 31 c0                             
   590 : xor          r8, rax                            ; 49 31 c0                             
   591 : xor          r8, r8                             ; 4d 31 c0                             
   592 : xor          rax, qword ptr [rsp + 0x0100]      ; 48 33 84 24 00 01 00 00              
   593 : xor          rdi, qword ptr [rsp + 0x0100]      ; 48 33 bc 24 00 01 00 00              
   594 : xor          r8, qword ptr [rsp + 0x0100]       ; 4c 33 84 24 00 01 00 00              
   595 : xor          rax, 0x0100                        ; 48 35 00 01 00 00                    
   596 : xor          rcx, 0x0100                        ; 48 81 f1 00 01 00 00                 
   597 : xor          rdi, 0x0100                        ; 48 81 f7 00 01 00 00                 
   598 : xor          r8, 0x0100                         ; 49 81 f0 00 01 00 00                 
   599 : xor          qword ptr [rsp + 0x0100], rax      ; 48 31 84 24 00 01 00 00              
   600 : xor          qword ptr [rsp + 0x0100], rdi      ; 48 31 bc 24 00 01 00 00              
   601 : xor          qword ptr [rsp + 0x0100], r8       ; 4c 31 84 24 00 01 00 00              
   602 : xor          qword ptr [rsp + 0x0100], 0x0101   ; 48 81 b4 24 00 01 00 00 01 01 00 00  
   603 : cmove        rax, rax                           ; 48 0f 44 c0                          
   604 : cmovne       rax, rax                           ; 48 0f 45 c0                          
   605 : cmovl        rax, rax                           ; 48 0f 4c c0                          
   606 : cmovg        rax, rax                           ; 48 0f 4f c0                          
   607 : cmovle       rax, rax                           ; 48 0f 4e c0                          
   608 : cmovge       rax, rax                           ; 48 0f 4d c0                          
   609 : cmovs        rax, rax                           ; 48 0f 48 c0                          
   610 : cmovns       rax, rax                           ; 48 0f 49 c0                          
   611 : cmove        rdi, rax                           ; 48 0f 44 f8                          
   612 : cmove        rax, rdi                           ; 48 0f 44 c7                          
   613 : cmove        r8, rax                            ; 4c 0f 44 c0                          
   614 : cmove        rax, r8                            ; 49 0f 44 c0                          
   615 : cmove        r8, r8                             ; 4d 0f 44 c0                          
   616 : cmove        rax, qword ptr [rsp + 0x0100]      ; 48 0f 44 84 24 00 01 00 00           
   617 : cmove        rdi, qword ptr [rsp + 0x0100]      ; 48 0f 44 bc 24 00 01 00 00           
   618 : cmove        r8, qword ptr [rsp + 0x0100]       ; 4c 0f 44 84 24 00 01 00 00           
   619 : sete         al                                 ; 0f 94 c0                             
   620 : setne        al                                 ; 0f 95 c0                             
   621 : setl         al                                 ; 0f 9c c0                             
   622 : setg         al                                 ; 0f 9f c0                             
   623 : setle        al                                 ; 0f 9e c0                             
   624 : setge        al                                 ; 0f 9d c0                             
   625 : sets         al                                 ; 0f 98 c0                             
   626 : setns        al                                 ; 0f 99 c0                             
   627 : sete         dil                                ; 40 0f 94 c7                          
   628 : sete         r8b                                ; 41 0f 94 c0                          
   629 : sete         byte ptr [rsp + 0x0100]            ; 0f 94 84 24 00 01 00 00              
   630 : adc          rax, rax                           ; 48 11 c0                             
   631 : adc          rdi, rax                           ; 48 11 c7                             
   632 : adc          rax, rdi                           ; 48 11 f8                             
   633 : adc          r8, rax                            ; 49 11 c0                             
   634 : adc          rax, r8                            ; 4c 11 c0                             
   635 : adc          r8, r8                             ; 4d 11 c0                             
   636 : adc          rax, 0x0100                        ; 48 15 00 01 00 00                    
   637 : adc          rcx, 0x0100                        ; 48 81 d1 00 01 00 00                 
   638 : adc          rdi, 0x0100                        ; 48 81 d7 00 01 00 00                 
   639 : adc          r8, 0x0100                         ; 49 81 d0 00 01 00 00                 
   640 : adc          rax, qword ptr [rsp + 0x0100]      ; 48 13 84 24 00 01 00 00              
   641 : adc          rdi, qword ptr [rsp + 0x0100]      ; 48 13 bc 24 00 01 00 00              
   642 : adc          r8, qword ptr [rsp + 0x0100]       ; 4c 13 84 24 00 01 00 00              
   643 : adc          qword ptr [rsp + 0x0100], rax      ; 48 11 84 24 00 01 00 00              
   644 : adc          qword ptr [rsp + 0x0100], rdi      ; 48 11 bc 24 00 01 00 00              
   645 : adc          qword ptr [rsp + 0x0100], r8       ; 4c 11 84 24 00 01 00 00              
   646 : adc          qword ptr [rsp + 0x0100], 0x0100   ; 48 81 94 24 00 01 00 00 00 01 00 00  
   647 : cmp          rax, qword ptr [rsp + 0x0fff8]     ; 48 3b 84 24 f8 ff 00 00              
   648 : cmp          rdi, qword ptr [rsp + 0x0fff8]     ; 48 3b bc 24 f8 ff 00 00              
   649 : cmp          r8, qword ptr [rsp + 0x0fff8]      ; 4c 3b 84 24 f8 ff 00 00              
   650 : cmp          r15, qword ptr [rsp + 0x0fff8]     ; 4c 3b bc 24 f8 ff 00 00              
   651 : cmp          qword ptr [rsp + 0x0fff8], rax     ; 48 39 84 24 f8 ff 00 00              
   652 : cmp          qword ptr [rsp + 0x0fff8], rdi     ; 48 39 bc 24 f8 ff 00 00              
   653 : cmp          qword ptr [rsp + 0x0fff8], r8      ; 4c 39 84 24 f8 ff 00 00              
   654 : cmp          qword ptr [rsp + 0x0fff8], r15     ; 4c 39 bc 24 f8 ff 00 00              
   655 : cmp          qword ptr [rsp + 0x0fff8], 0x08888 ; 48 81 bc 24 f8 ff 00 00 88 88 00 00  
   656 : vmovdqu      ymm0, ymm0                         ; c5 fe 6f c0                          
   657 : vmovdqu      ymm7, ymm0                         ; c5 fe 6f f8                          
   658 : vmovdqu      ymm0, ymm7                         ; c5 fe 6f c7                          
   659 : vmovdqu      ymm8, ymm0                         ; c5 7e 6f c0                          
   660 : vmovdqu      ymm15, ymm0                        ; c5 7e 6f f8                          
   661 : vmovdqu      ymm8, ymm7                         ; c5 7e 6f c7                          
   662 : vmovdqu      ymm0, ymm8                         ; c4 c1 7e 6f c0                       
   663 : vmovdqu      ymm7, ymm8                         ; c4 c1 7e 6f f8                       
   664 : vmovdqu      ymm0, ymm15                        ; c4 c1 7e 6f c7                       
   665 : vmovdqu      ymm8, ymm8                         ; c4 41 7e 6f c0                       
   666 : vmovdqu      ymm15, ymm8                        ; c4 41 7e 6f f8                       
   667 : vmovdqu      ymm8, ymm15                        ; c4 41 7e 6f c7                       
   668 : vmovups      ymm0, ymm0                         ; c5 fc 10 c0                          
   669 : vmovups      ymm7, ymm0                         ; c5 fc 10 f8                          
   670 : vmovups      ymm0, ymm7                         ; c5 fc 10 c7                          
   671 : vmovups      ymm8, ymm0                         ; c5 7c 10 c0                          
   672 : vmovups      ymm15, ymm0                        ; c5 7c 10 f8                          
   673 : vmovups      ymm8, ymm7                         ; c5 7c 10 c7                          
   674 : vmovups      ymm0, ymm8                         ; c4 c1 7c 10 c0                       
   675 : vmovups      ymm7, ymm8                         ; c4 c1 7c 10 f8                       
   676 : vmovups      ymm0, ymm15                        ; c4 c1 7c 10 c7                       
   677 : vmovups      ymm8, ymm8                         ; c4 41 7c 10 c0                       
   678 : vmovups      ymm15, ymm8                        ; c4 41 7c 10 f8                       
   679 : vmovups      ymm8, ymm15                        ; c4 41 7c 10 c7                       
   680 : vmovupd      ymm0, ymm0                         ; c5 fd 10 c0                          
   681 : vmovupd      ymm7, ymm0                         ; c5 fd 10 f8                          
   682 : vmovupd      ymm0, ymm7                         ; c5 fd 10 c7                          
   683 : vmovupd      ymm8, ymm0                         ; c5 7d 10 c0                          
   684 : vmovupd      ymm15, ymm0                        ; c5 7d 10 f8                          
   685 : vmovupd      ymm8, ymm7                         ; c5 7d 10 c7                          
   686 : vmovupd      ymm0, ymm8                         ; c4 c1 7d 10 c0                       
   687 : vmovupd      ymm7, ymm8                         ; c4 c1 7d 10 f8                       
   688 : vmovupd      ymm0, ymm15                        ; c4 c1 7d 10 c7                       
   689 : vmovupd      ymm8, ymm8                         ; c4 41 7d 10 c0                       
   690 : vmovupd      ymm15, ymm8                        ; c4 41 7d 10 f8                       
   691 : vmovupd      ymm8, ymm15                        ; c4 41 7d 10 c7                       
   692 : vmovdqu      ymm0, ymmword ptr [rax]            ; c5 fe 6f 00                          
   693 : vmovdqu      ymm7, ymmword ptr [rax]            ; c5 fe 6f 38                          
   694 : vmovdqu      ymm0, ymmword ptr [rsp]            ; c5 fe 6f 04 24                       
   695 : vmovdqu      ymm0, ymmword ptr [rbp]            ; c5 fe 6f 45 00                       
   696 : vmovdqu      ymm0, ymmword ptr [rdi]            ; c5 fe 6f 07                          
   697 : vmovdqu      ymm8, ymmword ptr [rax]            ; c5 7e 6f 00                          
   698 : vmovdqu      ymm15, ymmword ptr [rax]           ; c5 7e 6f 38                          
   699 : vmovdqu      ymm8, ymmword ptr [rsp]            ; c5 7e 6f 04 24                       
   700 : vmovdqu      ymm8, ymmword ptr [rbp]            ; c5 7e 6f 45 00                       
   701 : vmovdqu      ymm8, ymmword ptr [rdi]            ; c5 7e 6f 07                          
   702 : vmovdqu      ymm0, ymmword ptr [r8]             ; c4 c1 7e 6f 00                       
   703 : vmovdqu      ymm7, ymmword ptr [r8]             ; c4 c1 7e 6f 38                       
   704 : vmovdqu      ymm0, ymmword ptr [r12]            ; c4 c1 7e 6f 04 24                    
   705 : vmovdqu      ymm0, ymmword ptr [r13]            ; c4 c1 7e 6f 45 00                    
   706 : vmovdqu      ymm0, ymmword ptr [r15]            ; c4 c1 7e 6f 07                       
   707 : vmovdqu      ymm8, ymmword ptr [r8]             ; c4 41 7e 6f 00                       
   708 : vmovdqu      ymm15, ymmword ptr [r8]            ; c4 41 7e 6f 38                       
   709 : vmovdqu      ymm8, ymmword ptr [r12]            ; c4 41 7e 6f 04 24                    
   710 : vmovdqu      ymm8, ymmword ptr [r13]            ; c4 41 7e 6f 45 00                    
   711 : vmovdqu      ymm8, ymmword ptr [r15]            ; c4 41 7e 6f 07                       
   712 : vmovups      ymm0, ymmword ptr [rax]            ; c5 fc 10 00                          
   713 : vmovups      ymm7, ymmword ptr [rax]            ; c5 fc 10 38                          
   714 : vmovups      ymm0, ymmword ptr [rsp]            ; c5 fc 10 04 24                       
   715 : vmovups      ymm0, ymmword ptr [rbp]            ; c5 fc 10 45 00                       
   716 : vmovups      ymm0, ymmword ptr [rdi]            ; c5 fc 10 07                          
   717 : vmovups      ymm8, ymmword ptr [rax]            ; c5 7c 10 00                          
   718 : vmovups      ymm15, ymmword ptr [rax]           ; c5 7c 10 38                          
   719 : vmovups      ymm8, ymmword ptr [rsp]            ; c5 7c 10 04 24                       
   720 : vmovups      ymm8, ymmword ptr [rbp]            ; c5 7c 10 45 00                       
   721 : vmovups      ymm8, ymmword ptr [rdi]            ; c5 7c 10 07                          
   722 : vmovups      ymm0, ymmword ptr [r8]             ; c4 c1 7c 10 00                       
   723 : vmovups      ymm7, ymmword ptr [r8]             ; c4 c1 7c 10 38                       
   724 : vmovups      ymm0, ymmword ptr [r12]            ; c4 c1 7c 10 04 24                    
   725 : vmovups      ymm0, ymmword ptr [r13]            ; c4 c1 7c 10 45 00                    
   726 : vmovups      ymm0, ymmword ptr [r15]            ; c4 c1 7c 10 07                       
   727 : vmovups      ymm8, ymmword ptr [r8]             ; c4 41 7c 10 00                       
   728 : vmovups      ymm15, ymmword ptr [r8]            ; c4 41 7c 10 38                       
   729 : vmovups      ymm8, ymmword ptr [r12]            ; c4 41 7c 10 04 24                    
   730 : vmovups      ymm8, ymmword ptr [r13]            ; c4 41 7c 10 45 00                    
   731 : vmovups      ymm8, ymmword ptr [r15]            ; c4 41 7c 10 07                       
   732 : vmovupd      ymm0, ymmword ptr [rax]            ; c5 fd 10 00                          
   733 : vmovupd      ymm7, ymmword ptr [rax]            ; c5 fd 10 38                          
   734 : vmovupd      ymm0, ymmword ptr [rsp]            ; c5 fd 10 04 24                       
   735 : vmovupd      ymm0, ymmword ptr [rbp]            ; c5 fd 10 45 00                       
   736 : vmovupd      ymm0, ymmword ptr [rdi]            ; c5 fd 10 07                          
   737 : vmovupd      ymm8, ymmword ptr [rax]            ; c5 7d 10 00                          
   738 : vmovupd      ymm15, ymmword ptr [rax]           ; c5 7d 10 38                          
   739 : vmovupd      ymm8, ymmword ptr [rsp]            ; c5 7d 10 04 24                       
   740 : vmovupd      ymm8, ymmword ptr [rbp]            ; c5 7d 10 45 00                       
   741 : vmovupd      ymm8, ymmword ptr [rdi]            ; c5 7d 10 07                          
   742 : vmovupd      ymm0, ymmword ptr [r8]             ; c4 c1 7d 10 00                       
   743 : vmovupd      ymm7, ymmword ptr [r8]             ; c4 c1 7d 10 38                       
   744 : vmovupd      ymm0, ymmword ptr [r12]            ; c4 c1 7d 10 04 24                    
   745 : vmovupd      ymm0, ymmword ptr [r13]            ; c4 c1 7d 10 45 00                    
   746 : vmovupd      ymm0, ymmword ptr [r15]            ; c4 c1 7d 10 07                       
   747 : vmovupd      ymm8, ymmword ptr [r8]             ; c4 41 7d 10 00                       
   748 : vmovupd      ymm15, ymmword ptr [r8]            ; c4 41 7d 10 38                       
   749 : vmovupd      ymm8, ymmword ptr [r12]            ; c4 41 7d 10 04 24                    
   750 : vmovupd      ymm8, ymmword ptr [r13]            ; c4 41 7d 10 45 00                    
   751 : vmovupd      ymm8, ymmword ptr [r15]            ; c4 41 7d 10 07                       
   752 : vmovdqu      ymm0, ymmword ptr [rax + rax]      ; c5 fe 6f 04 00                       
   753 : vmovdqu      ymm7, ymmword ptr [rax + rax]      ; c5 fe 6f 3c 00                       
   754 : vmovdqu      ymm0, ymmword ptr [rdi + rax]      ; c5 fe 6f 04 07                       
   755 : vmovdqu      ymm0, ymmword ptr [rax + rdi]      ; c5 fe 6f 04 38                       
   756 : vmovdqu      ymm8, ymmword ptr [rax + rax]      ; c5 7e 6f 04 00                       
   757 : vmovdqu      ymm15, ymmword ptr [rax + rax]     ; c5 7e 6f 3c 00                       
   758 : vmovdqu      ymm8, ymmword ptr [rdi + rax]      ; c5 7e 6f 04 07                       
   759 : vmovdqu      ymm8, ymmword ptr [rax + rdi]      ; c5 7e 6f 04 38                       
   760 : vmovdqu      ymm0, ymmword ptr [r8 + rax]       ; c4 c1 7e 6f 04 00                    
   761 : vmovdqu      ymm7, ymmword ptr [r8 + rax]       ; c4 c1 7e 6f 3c 00                    
   762 : vmovdqu      ymm0, ymmword ptr [r15 + rax]      ; c4 c1 7e 6f 04 07                    
   763 : vmovdqu      ymm0, ymmword ptr [rax + rdi]      ; c5 fe 6f 04 38                       
   764 : vmovdqu      ymm0, ymmword ptr [rax + r8]       ; c4 a1 7e 6f 04 00                    
   765 : vmovdqu      ymm7, ymmword ptr [rax + r8]       ; c4 a1 7e 6f 3c 00                    
   766 : vmovdqu      ymm0, ymmword ptr [rdi + r8]       ; c4 a1 7e 6f 04 07                    
   767 : vmovdqu      ymm0, ymmword ptr [rax + r15]      ; c4 a1 7e 6f 04 38                    
   768 : vmovdqu      ymm8, ymmword ptr [r8 + rax]       ; c4 41 7e 6f 04 00                    
   769 : vmovdqu      ymm15, ymmword ptr [r8 + rax]      ; c4 41 7e 6f 3c 00                    
   770 : vmovdqu      ymm8, ymmword ptr [r15 + rax]      ; c4 41 7e 6f 04 07                    
   771 : vmovdqu      ymm8, ymmword ptr [r8 + rdi]       ; c4 41 7e 6f 04 38                    
   772 : vmovdqu      ymm8, ymmword ptr [rax + r8]       ; c4 21 7e 6f 04 00                    
   773 : vmovdqu      ymm15, ymmword ptr [rax + r8]      ; c4 21 7e 6f 3c 00                    
   774 : vmovdqu      ymm8, ymmword ptr [rdi + r8]       ; c4 21 7e 6f 04 07                    
   775 : vmovdqu      ymm8, ymmword ptr [rax + r15]      ; c4 21 7e 6f 04 38                    
   776 : vmovdqu      ymm0, ymmword ptr [r8 + r8]        ; c4 81 7e 6f 04 00                    
   777 : vmovdqu      ymm7, ymmword ptr [r8 + r8]        ; c4 81 7e 6f 3c 00                    
   778 : vmovdqu      ymm0, ymmword ptr [r15 + r8]       ; c4 81 7e 6f 04 07                    
   779 : vmovdqu      ymm0, ymmword ptr [rax + r15]      ; c4 a1 7e 6f 04 38                    
   780 : vmovdqu      ymm8, ymmword ptr [r8 + r8]        ; c4 01 7e 6f 04 00                    
   781 : vmovdqu      ymm15, ymmword ptr [r8 + r8]       ; c4 01 7e 6f 3c 00                    
   782 : vmovdqu      ymm8, ymmword ptr [r15 + r8]       ; c4 01 7e 6f 04 07                    
   783 : vmovdqu      ymm8, ymmword ptr [r8 + r15]       ; c4 01 7e 6f 04 38                    
   784 : vmovups      ymm0, ymmword ptr [rax + rax]      ; c5 fc 10 04 00                       
   785 : vmovups      ymm7, ymmword ptr [rax + rax]      ; c5 fc 10 3c 00                       
   786 : vmovups      ymm0, ymmword ptr [rdi + rax]      ; c5 fc 10 04 07                       
   787 : vmovups      ymm0, ymmword ptr [rax + rdi]      ; c5 fc 10 04 38                       
   788 : vmovups      ymm8, ymmword ptr [rax + rax]      ; c5 7c 10 04 00                       
   789 : vmovups      ymm15, ymmword ptr [rax + rax]     ; c5 7c 10 3c 00                       
   790 : vmovups      ymm8, ymmword ptr [rdi + rax]      ; c5 7c 10 04 07                       
   791 : vmovups      ymm8, ymmword ptr [rax + rdi]      ; c5 7c 10 04 38                       
   792 : vmovups      ymm0, ymmword ptr [r8 + rax]       ; c4 c1 7c 10 04 00                    
   793 : vmovups      ymm7, ymmword ptr [r8 + rax]       ; c4 c1 7c 10 3c 00                    
   794 : vmovups      ymm0, ymmword ptr [r15 + rax]      ; c4 c1 7c 10 04 07                    
   795 : vmovups      ymm0, ymmword ptr [rax + rdi]      ; c5 fc 10 04 38                       
   796 : vmovups      ymm0, ymmword ptr [rax + r8]       ; c4 a1 7c 10 04 00                    
   797 : vmovups      ymm7, ymmword ptr [rax + r8]       ; c4 a1 7c 10 3c 00                    
   798 : vmovups      ymm0, ymmword ptr [rdi + r8]       ; c4 a1 7c 10 04 07                    
   799 : vmovups      ymm0, ymmword ptr [rax + r15]      ; c4 a1 7c 10 04 38                    
   800 : vmovups      ymm8, ymmword ptr [r8 + rax]       ; c4 41 7c 10 04 00                    
   801 : vmovups      ymm15, ymmword ptr [r8 + rax]      ; c4 41 7c 10 3c 00                    
   802 : vmovups      ymm8, ymmword ptr [r15 + rax]      ; c4 41 7c 10 04 07                    
   803 : vmovups      ymm8, ymmword ptr [r8 + rdi]       ; c4 41 7c 10 04 38                    
   804 : vmovups      ymm8, ymmword ptr [rax + r8]       ; c4 21 7c 10 04 00                    
   805 : vmovups      ymm15, ymmword ptr [rax + r8]      ; c4 21 7c 10 3c 00                    
   806 : vmovups      ymm8, ymmword ptr [rdi + r8]       ; c4 21 7c 10 04 07                    
   807 : vmovups      ymm8, ymmword ptr [rax + r15]      ; c4 21 7c 10 04 38                    
   808 : vmovups      ymm0, ymmword ptr [r8 + r8]        ; c4 81 7c 10 04 00                    
   809 : vmovups      ymm7, ymmword ptr [r8 + r8]        ; c4 81 7c 10 3c 00                    
   810 : vmovups      ymm0, ymmword ptr [r15 + r8]       ; c4 81 7c 10 04 07                    
   811 : vmovups      ymm0, ymmword ptr [rax + r15]      ; c4 a1 7c 10 04 38                    
   812 : vmovups      ymm8, ymmword ptr [r8 + r8]        ; c4 01 7c 10 04 00                    
   813 : vmovups      ymm15, ymmword ptr [r8 + r8]       ; c4 01 7c 10 3c 00                    
   814 : vmovups      ymm8, ymmword ptr [r15 + r8]       ; c4 01 7c 10 04 07                    
   815 : vmovups      ymm8, ymmword ptr [r8 + r15]       ; c4 01 7c 10 04 38                    
   816 : vmovupd      ymm0, ymmword ptr [rax + rax]      ; c5 fd 10 04 00                       
   817 : vmovupd      ymm7, ymmword ptr [rax + rax]      ; c5 fd 10 3c 00                       
   818 : vmovupd      ymm0, ymmword ptr [rdi + rax]      ; c5 fd 10 04 07                       
   819 : vmovupd      ymm0, ymmword ptr [rax + rdi]      ; c5 fd 10 04 38                       
   820 : vmovupd      ymm8, ymmword ptr [rax + rax]      ; c5 7d 10 04 00                       
   821 : vmovupd      ymm15, ymmword ptr [rax + rax]     ; c5 7d 10 3c 00                       
   822 : vmovupd      ymm8, ymmword ptr [rdi + rax]      ; c5 7d 10 04 07                       
   823 : vmovupd      ymm8, ymmword ptr [rax + rdi]      ; c5 7d 10 04 38                       
   824 : vmovupd      ymm0, ymmword ptr [r8 + rax]       ; c4 c1 7d 10 04 00                    
   825 : vmovupd      ymm7, ymmword ptr [r8 + rax]       ; c4 c1 7d 10 3c 00                    
   826 : vmovupd      ymm0, ymmword ptr [r15 + rax]      ; c4 c1 7d 10 04 07                    
   827 : vmovupd      ymm0, ymmword ptr [rax + rdi]      ; c5 fd 10 04 38                       
   828 : vmovupd      ymm0, ymmword ptr [rax + r8]       ; c4 a1 7d 10 04 00                    
   829 : vmovupd      ymm7, ymmword ptr [rax + r8]       ; c4 a1 7d 10 3c 00                    
   830 : vmovupd      ymm0, ymmword ptr [rdi + r8]       ; c4 a1 7d 10 04 07                    
   831 : vmovupd      ymm0, ymmword ptr [rax + r15]      ; c4 a1 7d 10 04 38                    
   832 : vmovupd      ymm8, ymmword ptr [r8 + rax]       ; c4 41 7d 10 04 00                    
   833 : vmovupd      ymm15, ymmword ptr [r8 + rax]      ; c4 41 7d 10 3c 00                    
   834 : vmovupd      ymm8, ymmword ptr [r15 + rax]      ; c4 41 7d 10 04 07                    
   835 : vmovupd      ymm8, ymmword ptr [r8 + rdi]       ; c4 41 7d 10 04 38                    
   836 : vmovupd      ymm8, ymmword ptr [rax + r8]       ; c4 21 7d 10 04 00                    
   837 : vmovupd      ymm15, ymmword ptr [rax + r8]      ; c4 21 7d 10 3c 00                    
   838 : vmovupd      ymm8, ymmword ptr [rdi + r8]       ; c4 21 7d 10 04 07                    
   839 : vmovupd      ymm8, ymmword ptr [rax + r15]      ; c4 21 7d 10 04 38                    
   840 : vmovupd      ymm0, ymmword ptr [r8 + r8]        ; c4 81 7d 10 04 00                    
   841 : vmovupd      ymm7, ymmword ptr [r8 + r8]        ; c4 81 7d 10 3c 00                    
   842 : vmovupd      ymm0, ymmword ptr [r15 + r8]       ; c4 81 7d 10 04 07                    
   843 : vmovupd      ymm0, ymmword ptr [rax + r15]      ; c4 a1 7d 10 04 38                    
   844 : vmovupd      ymm8, ymmword ptr [r8 + r8]        ; c4 01 7d 10 04 00                    
   845 : vmovupd      ymm15, ymmword ptr [r8 + r8]       ; c4 01 7d 10 3c 00                    
   846 : vmovupd      ymm8, ymmword ptr [r15 + r8]       ; c4 01 7d 10 04 07                    
   847 : vmovupd      ymm8, ymmword ptr [r8 + r15]       ; c4 01 7d 10 04 38                    
   848 : vmovdqu      ymm0, ymmword ptr [rax + 0x0100]   ; c5 fe 6f 80 00 01 00 00              
   849 : vmovdqu      ymm7, ymmword ptr [rax + 0x0100]   ; c5 fe 6f b8 00 01 00 00              
   850 : vmovdqu      ymm0, ymmword ptr [rsp + 0x0100]   ; c5 fe 6f 84 24 00 01 00 00           
   851 : vmovdqu      ymm0, ymmword ptr [rdi + 0x0100]   ; c5 fe 6f 87 00 01 00 00              
   852 : vmovdqu      ymm8, ymmword ptr [rax + 0x0100]   ; c5 7e 6f 80 00 01 00 00              
   853 : vmovdqu      ymm15, ymmword ptr [rax + 0x0100]  ; c5 7e 6f b8 00 01 00 00              
   854 : vmovdqu      ymm8, ymmword ptr [rsp + 0x0100]   ; c5 7e 6f 84 24 00 01 00 00           
   855 : vmovdqu      ymm8, ymmword ptr [rdi + 0x0100]   ; c5 7e 6f 87 00 01 00 00              
   856 : vmovdqu      ymm0, ymmword ptr [r8 + 0x0100]    ; c4 c1 7e 6f 80 00 01 00 00           
   857 : vmovdqu      ymm7, ymmword ptr [r8 + 0x0100]    ; c4 c1 7e 6f b8 00 01 00 00           
   858 : vmovdqu      ymm0, ymmword ptr [r12 + 0x0100]   ; c4 c1 7e 6f 84 24 00 01 00 00        
   859 : vmovdqu      ymm0, ymmword ptr [r15 + 0x0100]   ; c4 c1 7e 6f 87 00 01 00 00           
   860 : vmovdqu      ymm8, ymmword ptr [r8 + 0x0100]    ; c4 41 7e 6f 80 00 01 00 00           
   861 : vmovdqu      ymm15, ymmword ptr [r8 + 0x0100]   ; c4 41 7e 6f b8 00 01 00 00           
   862 : vmovdqu      ymm8, ymmword ptr [r12 + 0x0100]   ; c4 41 7e 6f 84 24 00 01 00 00        
   863 : vmovdqu      ymm8, ymmword ptr [r15 + 0x0100]   ; c4 41 7e 6f 87 00 01 00 00           
   864 : vmovups      ymm0, ymmword ptr [rax + 0x0100]   ; c5 fc 10 80 00 01 00 00              
   865 : vmovups      ymm7, ymmword ptr [rax + 0x0100]   ; c5 fc 10 b8 00 01 00 00              
   866 : vmovups      ymm0, ymmword ptr [rsp + 0x0100]   ; c5 fc 10 84 24 00 01 00 00           
   867 : vmovups      ymm0, ymmword ptr [rdi + 0x0100]   ; c5 fc 10 87 00 01 00 00              
   868 : vmovups      ymm8, ymmword ptr [rax + 0x0100]   ; c5 7c 10 80 00 01 00 00              
   869 : vmovups      ymm15, ymmword ptr [rax + 0x0100]  ; c5 7c 10 b8 00 01 00 00              
   870 : vmovups      ymm8, ymmword ptr [rsp + 0x0100]   ; c5 7c 10 84 24 00 01 00 00           
   871 : vmovups      ymm8, ymmword ptr [rdi + 0x0100]   ; c5 7c 10 87 00 01 00 00              
   872 : vmovups      ymm0, ymmword ptr [r8 + 0x0100]    ; c4 c1 7c 10 80 00 01 00 00           
   873 : vmovups      ymm7, ymmword ptr [r8 + 0x0100]    ; c4 c1 7c 10 b8 00 01 00 00           
   874 : vmovups      ymm0, ymmword ptr [r12 + 0x0100]   ; c4 c1 7c 10 84 24 00 01 00 00        
   875 : vmovups      ymm0, ymmword ptr [r15 + 0x0100]   ; c4 c1 7c 10 87 00 01 00 00           
   876 : vmovups      ymm8, ymmword ptr [r8 + 0x0100]    ; c4 41 7c 10 80 00 01 00 00           
   877 : vmovups      ymm15, ymmword ptr [r8 + 0x0100]   ; c4 41 7c 10 b8 00 01 00 00           
   878 : vmovups      ymm8, ymmword ptr [r12 + 0x0100]   ; c4 41 7c 10 84 24 00 01 00 00        
   879 : vmovups      ymm8, ymmword ptr [r15 + 0x0100]   ; c4 41 7c 10 87 00 01 00 00           
   880 : vmovupd      ymm0, ymmword ptr [rax + 0x0100]   ; c5 fd 10 80 00 01 00 00              
   881 : vmovupd      ymm7, ymmword ptr [rax + 0x0100]   ; c5 fd 10 b8 00 01 00 00              
   882 : vmovupd      ymm0, ymmword ptr [rsp + 0x0100]   ; c5 fd 10 84 24 00 01 00 00           
   883 : vmovupd      ymm0, ymmword ptr [rdi + 0x0100]   ; c5 fd 10 87 00 01 00 00              
   884 : vmovupd      ymm8, ymmword ptr [rax + 0x0100]   ; c5 7d 10 80 00 01 00 00              
   885 : vmovupd      ymm15, ymmword ptr [rax + 0x0100]  ; c5 7d 10 b8 00 01 00 00              
   886 : vmovupd      ymm8, ymmword ptr [rsp + 0x0100]   ; c5 7d 10 84 24 00 01 00 00           
   887 : vmovupd      ymm8, ymmword ptr [rdi + 0x0100]   ; c5 7d 10 87 00 01 00 00              
   888 : vmovupd      ymm0, ymmword ptr [r8 + 0x0100]    ; c4 c1 7d 10 80 00 01 00 00           
   889 : vmovupd      ymm7, ymmword ptr [r8 + 0x0100]    ; c4 c1 7d 10 b8 00 01 00 00           
   890 : vmovupd      ymm0, ymmword ptr [r12 + 0x0100]   ; c4 c1 7d 10 84 24 00 01 00 00        
   891 : vmovupd      ymm0, ymmword ptr [r15 + 0x0100]   ; c4 c1 7d 10 87 00 01 00 00           
   892 : vmovupd      ymm8, ymmword ptr [r8 + 0x0100]    ; c4 41 7d 10 80 00 01 00 00           
   893 : vmovupd      ymm15, ymmword ptr [r8 + 0x0100]   ; c4 41 7d 10 b8 00 01 00 00           
   894 : vmovupd      ymm8, ymmword ptr [r12 + 0x0100]   ; c4 41 7d 10 84 24 00 01 00 00        
   895 : vmovupd      ymm8, ymmword ptr [r15 + 0x0100]   ; c4 41 7d 10 87 00 01 00 00           
   896 : vmovdqu      ymmword ptr [rax], ymm0            ; c5 fe 7f 00                          
   897 : vmovdqu      ymmword ptr [rsp], ymm0            ; c5 fe 7f 04 24                       
   898 : vmovdqu      ymmword ptr [rbp], ymm0            ; c5 fe 7f 45 00                       
   899 : vmovdqu      ymmword ptr [rdi], ymm0            ; c5 fe 7f 07                          
   900 : vmovdqu      ymmword ptr [rax], ymm7            ; c5 fe 7f 38                          
   901 : vmovdqu      ymmword ptr [rax], ymm8            ; c5 7e 7f 00                          
   902 : vmovdqu      ymmword ptr [rsp], ymm8            ; c5 7e 7f 04 24                       
   903 : vmovdqu      ymmword ptr [rbp], ymm8            ; c5 7e 7f 45 00                       
   904 : vmovdqu      ymmword ptr [rdi], ymm8            ; c5 7e 7f 07                          
   905 : vmovdqu      ymmword ptr [rax], ymm15           ; c5 7e 7f 38                          
   906 : vmovdqu      ymmword ptr [r8], ymm0             ; c4 c1 7e 7f 00                       
   907 : vmovdqu      ymmword ptr [r12], ymm0            ; c4 c1 7e 7f 04 24                    
   908 : vmovdqu      ymmword ptr [r13], ymm0            ; c4 c1 7e 7f 45 00                    
   909 : vmovdqu      ymmword ptr [r15], ymm0            ; c4 c1 7e 7f 07                       
   910 : vmovdqu      ymmword ptr [r8], ymm7             ; c4 c1 7e 7f 38                       
   911 : vmovdqu      ymmword ptr [r8], ymm8             ; c4 41 7e 7f 00                       
   912 : vmovdqu      ymmword ptr [r12], ymm8            ; c4 41 7e 7f 04 24                    
   913 : vmovdqu      ymmword ptr [r13], ymm8            ; c4 41 7e 7f 45 00                    
   914 : vmovdqu      ymmword ptr [r15], ymm8            ; c4 41 7e 7f 07                       
   915 : vmovdqu      ymmword ptr [r8], ymm15            ; c4 41 7e 7f 38                       
   916 : vmovups      ymmword ptr [rax], ymm0            ; c5 fc 11 00                          
   917 : vmovups      ymmword ptr [rsp], ymm0            ; c5 fc 11 04 24                       
   918 : vmovups      ymmword ptr [rbp], ymm0            ; c5 fc 11 45 00                       
   919 : vmovups      ymmword ptr [rdi], ymm0            ; c5 fc 11 07                          
   920 : vmovups      ymmword ptr [rax], ymm7            ; c5 fc 11 38                          
   921 : vmovups      ymmword ptr [rax], ymm8            ; c5 7c 11 00                          
   922 : vmovups      ymmword ptr [rsp], ymm8            ; c5 7c 11 04 24                       
   923 : vmovups      ymmword ptr [rbp], ymm8            ; c5 7c 11 45 00                       
   924 : vmovups      ymmword ptr [rdi], ymm8            ; c5 7c 11 07                          
   925 : vmovups      ymmword ptr [rax], ymm15           ; c5 7c 11 38                          
   926 : vmovups      ymmword ptr [r8], ymm0             ; c4 c1 7c 11 00                       
   927 : vmovups      ymmword ptr [r12], ymm0            ; c4 c1 7c 11 04 24                    
   928 : vmovups      ymmword ptr [r13], ymm0            ; c4 c1 7c 11 45 00                    
   929 : vmovups      ymmword ptr [r15], ymm0            ; c4 c1 7c 11 07                       
   930 : vmovups      ymmword ptr [r8], ymm7             ; c4 c1 7c 11 38                       
   931 : vmovups      ymmword ptr [r8], ymm8             ; c4 41 7c 11 00                       
   932 : vmovups      ymmword ptr [r12], ymm8            ; c4 41 7c 11 04 24                    
   933 : vmovups      ymmword ptr [r13], ymm8            ; c4 41 7c 11 45 00                    
   934 : vmovups      ymmword ptr [r15], ymm8            ; c4 41 7c 11 07                       
   935 : vmovups      ymmword ptr [r8], ymm15            ; c4 41 7c 11 38                       
   936 : vmovupd      ymmword ptr [rax], ymm0            ; c5 fd 11 00                          
   937 : vmovupd      ymmword ptr [rsp], ymm0            ; c5 fd 11 04 24                       
   938 : vmovupd      ymmword ptr [rbp], ymm0            ; c5 fd 11 45 00                       
   939 : vmovupd      ymmword ptr [rdi], ymm0            ; c5 fd 11 07                          
   940 : vmovupd      ymmword ptr [rax], ymm7            ; c5 fd 11 38                          
   941 : vmovupd      ymmword ptr [rax], ymm8            ; c5 7d 11 00                          
   942 : vmovupd      ymmword ptr [rsp], ymm8            ; c5 7d 11 04 24                       
   943 : vmovupd      ymmword ptr [rbp], ymm8            ; c5 7d 11 45 00                       
   944 : vmovupd      ymmword ptr [rdi], ymm8            ; c5 7d 11 07                          
   945 : vmovupd      ymmword ptr [rax], ymm15           ; c5 7d 11 38                          
   946 : vmovupd      ymmword ptr [r8], ymm0             ; c4 c1 7d 11 00                       
   947 : vmovupd      ymmword ptr [r12], ymm0            ; c4 c1 7d 11 04 24                    
   948 : vmovupd      ymmword ptr [r13], ymm0            ; c4 c1 7d 11 45 00                    
   949 : vmovupd      ymmword ptr [r15], ymm0            ; c4 c1 7d 11 07                       
   950 : vmovupd      ymmword ptr [r8], ymm7             ; c4 c1 7d 11 38                       
   951 : vmovupd      ymmword ptr [r8], ymm8             ; c4 41 7d 11 00                       
   952 : vmovupd      ymmword ptr [r12], ymm8            ; c4 41 7d 11 04 24                    
   953 : vmovupd      ymmword ptr [r13], ymm8            ; c4 41 7d 11 45 00                    
   954 : vmovupd      ymmword ptr [r15], ymm8            ; c4 41 7d 11 07                       
   955 : vmovupd      ymmword ptr [r8], ymm15            ; c4 41 7d 11 38                       
   956 : vmovdqu      ymmword ptr [rax + rax], ymm0      ; c5 fe 7f 04 00                       
   957 : vmovdqu      ymmword ptr [rbp + rax], ymm0      ; c5 fe 7f 44 05 00                    
   958 : vmovdqu      ymmword ptr [rdi + rax], ymm0      ; c5 fe 7f 04 07                       
   959 : vmovdqu      ymmword ptr [rax + rdi], ymm0      ; c5 fe 7f 04 38                       
   960 : vmovdqu      ymmword ptr [rax + rax], ymm7      ; c5 fe 7f 3c 00                       
   961 : vmovdqu      ymmword ptr [rax + rax], ymm8      ; c5 7e 7f 04 00                       
   962 : vmovdqu      ymmword ptr [rbp + rax], ymm8      ; c5 7e 7f 44 05 00                    
   963 : vmovdqu      ymmword ptr [rdi + rax], ymm8      ; c5 7e 7f 04 07                       
   964 : vmovdqu      ymmword ptr [rax + rdi], ymm8      ; c5 7e 7f 04 38                       
   965 : vmovdqu      ymmword ptr [rax + rax], ymm15     ; c5 7e 7f 3c 00                       
   966 : vmovdqu      ymmword ptr [r8 + rax], ymm0       ; c4 c1 7e 7f 04 00                    
   967 : vmovdqu      ymmword ptr [r13 + rax], ymm0      ; c4 c1 7e 7f 44 05 00                 
   968 : vmovdqu      ymmword ptr [r15 + rax], ymm0      ; c4 c1 7e 7f 04 07                    
   969 : vmovdqu      ymmword ptr [rax + rdi], ymm0      ; c5 fe 7f 04 38                       
   970 : vmovdqu      ymmword ptr [r8 + rax], ymm7       ; c4 c1 7e 7f 3c 00                    
   971 : vmovdqu      ymmword ptr [rax + r8], ymm0       ; c4 a1 7e 7f 04 00                    
   972 : vmovdqu      ymmword ptr [rbp + r8], ymm0       ; c4 a1 7e 7f 44 05 00                 
   973 : vmovdqu      ymmword ptr [rdi + r8], ymm0       ; c4 a1 7e 7f 04 07                    
   974 : vmovdqu      ymmword ptr [rax + r15], ymm0      ; c4 a1 7e 7f 04 38                    
   975 : vmovdqu      ymmword ptr [rax + r8], ymm7       ; c4 a1 7e 7f 3c 00                    
   976 : vmovdqu      ymmword ptr [r8 + rax], ymm8       ; c4 41 7e 7f 04 00                    
   977 : vmovdqu      ymmword ptr [r13 + rax], ymm8      ; c4 41 7e 7f 44 05 00                 
   978 : vmovdqu      ymmword ptr [r15 + rax], ymm8      ; c4 41 7e 7f 04 07                    
   979 : vmovdqu      ymmword ptr [r8 + rdi], ymm8       ; c4 41 7e 7f 04 38                    
   980 : vmovdqu      ymmword ptr [r8 + rax], ymm15      ; c4 41 7e 7f 3c 00                    
   981 : vmovdqu      ymmword ptr [rax + r8], ymm8       ; c4 21 7e 7f 04 00                    
   982 : vmovdqu      ymmword ptr [rbp + r8], ymm8       ; c4 21 7e 7f 44 05 00                 
   983 : vmovdqu      ymmword ptr [rdi + r8], ymm8       ; c4 21 7e 7f 04 07                    
   984 : vmovdqu      ymmword ptr [rax + r15], ymm8      ; c4 21 7e 7f 04 38                    
   985 : vmovdqu      ymmword ptr [rax + r8], ymm15      ; c4 21 7e 7f 3c 00                    
   986 : vmovdqu      ymmword ptr [r8 + r8], ymm0        ; c4 81 7e 7f 04 00                    
   987 : vmovdqu      ymmword ptr [r13 + r8], ymm0       ; c4 81 7e 7f 44 05 00                 
   988 : vmovdqu      ymmword ptr [r15 + r8], ymm0       ; c4 81 7e 7f 04 07                    
   989 : vmovdqu      ymmword ptr [rax + r15], ymm0      ; c4 a1 7e 7f 04 38                    
   990 : vmovdqu      ymmword ptr [r8 + r8], ymm7        ; c4 81 7e 7f 3c 00                    
   991 : vmovdqu      ymmword ptr [r8 + r8], ymm8        ; c4 01 7e 7f 04 00                    
   992 : vmovdqu      ymmword ptr [r13 + r8], ymm8       ; c4 01 7e 7f 44 05 00                 
   993 : vmovdqu      ymmword ptr [r15 + r8], ymm8       ; c4 01 7e 7f 04 07                    
   994 : vmovdqu      ymmword ptr [r8 + r15], ymm8       ; c4 01 7e 7f 04 38                    
   995 : vmovdqu      ymmword ptr [r8 + r8], ymm15       ; c4 01 7e 7f 3c 00                    
   996 : vmovups      ymmword ptr [rax + rax], ymm0      ; c5 fc 11 04 00                       
   997 : vmovups      ymmword ptr [rbp + rax], ymm0      ; c5 fc 11 44 05 00                    
   998 : vmovups      ymmword ptr [rdi + rax], ymm0      ; c5 fc 11 04 07                       
   999 : vmovups      ymmword ptr [rax + rdi], ymm0      ; c5 fc 11 04 38                       
  1000 : vmovups      ymmword ptr [rax + rax], ymm7      ; c5 fc 11 3c 00                       
  1001 : vmovups      ymmword ptr [rax + rax], ymm8      ; c5 7c 11 04 00                       
  1002 : vmovups      ymmword ptr [rbp + rax], ymm8      ; c5 7c 11 44 05 00                    
  1003 : vmovups      ymmword ptr [rdi + rax], ymm8      ; c5 7c 11 04 07                       
  1004 : vmovups      ymmword ptr [rax + rdi], ymm8      ; c5 7c 11 04 38                       
  1005 : vmovups      ymmword ptr [rax + rax], ymm15     ; c5 7c 11 3c 00                       
  1006 : vmovups      ymmword ptr [r8 + rax], ymm0       ; c4 c1 7c 11 04 00                    
  1007 : vmovups      ymmword ptr [r13 + rax], ymm0      ; c4 c1 7c 11 44 05 00                 
  1008 : vmovups      ymmword ptr [r15 + rax], ymm0      ; c4 c1 7c 11 04 07                    
  1009 : vmovups      ymmword ptr [rax + rdi], ymm0      ; c5 fc 11 04 38                       
  1010 : vmovups      ymmword ptr [r8 + rax], ymm7       ; c4 c1 7c 11 3c 00                    
  1011 : vmovups      ymmword ptr [rax + r8], ymm0       ; c4 a1 7c 11 04 00                    
  1012 : vmovups      ymmword ptr [rbp + r8], ymm0       ; c4 a1 7c 11 44 05 00                 
  1013 : vmovups      ymmword ptr [rdi + r8], ymm0       ; c4 a1 7c 11 04 07                    
  1014 : vmovups      ymmword ptr [rax + r15], ymm0      ; c4 a1 7c 11 04 38                    
  1015 : vmovups      ymmword ptr [rax + r8], ymm7       ; c4 a1 7c 11 3c 00                    
  1016 : vmovups      ymmword ptr [r8 + rax], ymm8       ; c4 41 7c 11 04 00                    
  1017 : vmovups      ymmword ptr [r13 + rax], ymm8      ; c4 41 7c 11 44 05 00                 
  1018 : vmovups      ymmword ptr [r15 + rax], ymm8      ; c4 41 7c 11 04 07                    
  1019 : vmovups      ymmword ptr [r8 + rdi], ymm8       ; c4 41 7c 11 04 38                    
  1020 : vmovups      ymmword ptr [r8 + rax], ymm15      ; c4 41 7c 11 3c 00                    
  1021 : vmovups      ymmword ptr [rax + r8], ymm8       ; c4 21 7c 11 04 00                    
  1022 : vmovups      ymmword ptr [rbp + r8], ymm8       ; c4 21 7c 11 44 05 00                 
  1023 : vmovups      ymmword ptr [rdi + r8], ymm8       ; c4 21 7c 11 04 07                    
  1024 : vmovups      ymmword ptr [rax + r15], ymm8      ; c4 21 7c 11 04 38                    
  1025 : vmovups      ymmword ptr [rax + r8], ymm15      ; c4 21 7c 11 3c 00                    
  1026 : vmovups      ymmword ptr [r8 + r8], ymm0        ; c4 81 7c 11 04 00                    
  1027 : vmovups      ymmword ptr [r13 + r8], ymm0       ; c4 81 7c 11 44 05 00                 
  1028 : vmovups      ymmword ptr [r15 + r8], ymm0       ; c4 81 7c 11 04 07                    
  1029 : vmovups      ymmword ptr [rax + r15], ymm0      ; c4 a1 7c 11 04 38                    
  1030 : vmovups      ymmword ptr [r8 + r8], ymm7        ; c4 81 7c 11 3c 00                    
  1031 : vmovups      ymmword ptr [r8 + r8], ymm8        ; c4 01 7c 11 04 00                    
  1032 : vmovups      ymmword ptr [r13 + r8], ymm8       ; c4 01 7c 11 44 05 00                 
  1033 : vmovups      ymmword ptr [r15 + r8], ymm8       ; c4 01 7c 11 04 07                    
  1034 : vmovups      ymmword ptr [r8 + r15], ymm8       ; c4 01 7c 11 04 38                    
  1035 : vmovups      ymmword ptr [r8 + r8], ymm15       ; c4 01 7c 11 3c 00                    
  1036 : vmovupd      ymmword ptr [rax + rax], ymm0      ; c5 fd 11 04 00                       
  1037 : vmovupd      ymmword ptr [rbp + rax], ymm0      ; c5 fd 11 44 05 00                    
  1038 : vmovupd      ymmword ptr [rdi + rax], ymm0      ; c5 fd 11 04 07                       
  1039 : vmovupd      ymmword ptr [rax + rdi], ymm0      ; c5 fd 11 04 38                       
  1040 : vmovupd      ymmword ptr [rax + rax], ymm7      ; c5 fd 11 3c 00                       
  1041 : vmovupd      ymmword ptr [rax + rax], ymm8      ; c5 7d 11 04 00                       
  1042 : vmovupd      ymmword ptr [rbp + rax], ymm8      ; c5 7d 11 44 05 00                    
  1043 : vmovupd      ymmword ptr [rdi + rax], ymm8      ; c5 7d 11 04 07                       
  1044 : vmovupd      ymmword ptr [rax + rdi], ymm8      ; c5 7d 11 04 38                       
  1045 : vmovupd      ymmword ptr [rax + rax], ymm15     ; c5 7d 11 3c 00                       
  1046 : vmovupd      ymmword ptr [r8 + rax], ymm0       ; c4 c1 7d 11 04 00                    
  1047 : vmovupd      ymmword ptr [r13 + rax], ymm0      ; c4 c1 7d 11 44 05 00                 
  1048 : vmovupd      ymmword ptr [r15 + rax], ymm0      ; c4 c1 7d 11 04 07                    
  1049 : vmovupd      ymmword ptr [rax + rdi], ymm0      ; c5 fd 11 04 38                       
  1050 : vmovupd      ymmword ptr [r8 + rax], ymm7       ; c4 c1 7d 11 3c 00                    
  1051 : vmovupd      ymmword ptr [rax + r8], ymm0       ; c4 a1 7d 11 04 00                    
  1052 : vmovupd      ymmword ptr [rbp + r8], ymm0       ; c4 a1 7d 11 44 05 00                 
  1053 : vmovupd      ymmword ptr [rdi + r8], ymm0       ; c4 a1 7d 11 04 07                    
  1054 : vmovupd      ymmword ptr [rax + r15], ymm0      ; c4 a1 7d 11 04 38                    
  1055 : vmovupd      ymmword ptr [rax + r8], ymm7       ; c4 a1 7d 11 3c 00                    
  1056 : vmovupd      ymmword ptr [r8 + rax], ymm8       ; c4 41 7d 11 04 00                    
  1057 : vmovupd      ymmword ptr [r13 + rax], ymm8      ; c4 41 7d 11 44 05 00                 
  1058 : vmovupd      ymmword ptr [r15 + rax], ymm8      ; c4 41 7d 11 04 07                    
  1059 : vmovupd      ymmword ptr [r8 + rdi], ymm8       ; c4 41 7d 11 04 38                    
  1060 : vmovupd      ymmword ptr [r8 + rax], ymm15      ; c4 41 7d 11 3c 00                    
  1061 : vmovupd      ymmword ptr [rax + r8], ymm8       ; c4 21 7d 11 04 00                    
  1062 : vmovupd      ymmword ptr [rbp + r8], ymm8       ; c4 21 7d 11 44 05 00                 
  1063 : vmovupd      ymmword ptr [rdi + r8], ymm8       ; c4 21 7d 11 04 07                    
  1064 : vmovupd      ymmword ptr [rax + r15], ymm8      ; c4 21 7d 11 04 38                    
  1065 : vmovupd      ymmword ptr [rax + r8], ymm15      ; c4 21 7d 11 3c 00                    
  1066 : vmovupd      ymmword ptr [r8 + r8], ymm0        ; c4 81 7d 11 04 00                    
  1067 : vmovupd      ymmword ptr [r13 + r8], ymm0       ; c4 81 7d 11 44 05 00                 
  1068 : vmovupd      ymmword ptr [r15 + r8], ymm0       ; c4 81 7d 11 04 07                    
  1069 : vmovupd      ymmword ptr [rax + r15], ymm0      ; c4 a1 7d 11 04 38                    
  1070 : vmovupd      ymmword ptr [r8 + r8], ymm7        ; c4 81 7d 11 3c 00                    
  1071 : vmovupd      ymmword ptr [r8 + r8], ymm8        ; c4 01 7d 11 04 00                    
  1072 : vmovupd      ymmword ptr [r13 + r8], ymm8       ; c4 01 7d 11 44 05 00                 
  1073 : vmovupd      ymmword ptr [r15 + r8], ymm8       ; c4 01 7d 11 04 07                    
  1074 : vmovupd      ymmword ptr [r8 + r15], ymm8       ; c4 01 7d 11 04 38                    
  1075 : vmovupd      ymmword ptr [r8 + r8], ymm15       ; c4 01 7d 11 3c 00                    
  1076 : vmovdqu      ymmword ptr [rax + 0x0100], ymm0   ; c5 fe 7f 80 00 01 00 00              
  1077 : vmovdqu      ymmword ptr [rsp + 0x0100], ymm0   ; c5 fe 7f 84 24 00 01 00 00           
  1078 : vmovdqu      ymmword ptr [rdi + 0x0100], ymm0   ; c5 fe 7f 87 00 01 00 00              
  1079 : vmovdqu      ymmword ptr [rax + 0x0100], ymm7   ; c5 fe 7f b8 00 01 00 00              
  1080 : vmovdqu      ymmword ptr [rax + 0x0100], ymm8   ; c5 7e 7f 80 00 01 00 00              
  1081 : vmovdqu      ymmword ptr [rsp + 0x0100], ymm8   ; c5 7e 7f 84 24 00 01 00 00           
  1082 : vmovdqu      ymmword ptr [rdi + 0x0100], ymm8   ; c5 7e 7f 87 00 01 00 00              
  1083 : vmovdqu      ymmword ptr [rax + 0x0100], ymm15  ; c5 7e 7f b8 00 01 00 00              
  1084 : vmovdqu      ymmword ptr [r8 + 0x0100], ymm0    ; c4 c1 7e 7f 80 00 01 00 00           
  1085 : vmovdqu      ymmword ptr [r12 + 0x0100], ymm0   ; c4 c1 7e 7f 84 24 00 01 00 00        
  1086 : vmovdqu      ymmword ptr [r15 + 0x0100], ymm0   ; c4 c1 7e 7f 87 00 01 00 00           
  1087 : vmovdqu      ymmword ptr [r8 + 0x0100], ymm7    ; c4 c1 7e 7f b8 00 01 00 00           
  1088 : vmovdqu      ymmword ptr [r8 + 0x0100], ymm8    ; c4 41 7e 7f 80 00 01 00 00           
  1089 : vmovdqu      ymmword ptr [r12 + 0x0100], ymm8   ; c4 41 7e 7f 84 24 00 01 00 00        
  1090 : vmovdqu      ymmword ptr [r15 + 0x0100], ymm8   ; c4 41 7e 7f 87 00 01 00 00           
  1091 : vmovdqu      ymmword ptr [r8 + 0x0100], ymm15   ; c4 41 7e 7f b8 00 01 00 00           
  1092 : vmovups      ymmword ptr [rax + 0x0100], ymm0   ; c5 fc 11 80 00 01 00 00              
  1093 : vmovups      ymmword ptr [rsp + 0x0100], ymm0   ; c5 fc 11 84 24 00 01 00 00           
  1094 : vmovups      ymmword ptr [rdi + 0x0100], ymm0   ; c5 fc 11 87 00 01 00 00              
  1095 : vmovups      ymmword ptr [rax + 0x0100], ymm7   ; c5 fc 11 b8 00 01 00 00              
  1096 : vmovups      ymmword ptr [rax + 0x0100], ymm8   ; c5 7c 11 80 00 01 00 00              
  1097 : vmovups      ymmword ptr [rsp + 0x0100], ymm8   ; c5 7c 11 84 24 00 01 00 00           
  1098 : vmovups      ymmword ptr [rdi + 0x0100], ymm8   ; c5 7c 11 87 00 01 00 00              
  1099 : vmovups      ymmword ptr [rax + 0x0100], ymm15  ; c5 7c 11 b8 00 01 00 00              
  1100 : vmovups      ymmword ptr [r8 + 0x0100], ymm0    ; c4 c1 7c 11 80 00 01 00 00           
  1101 : vmovups      ymmword ptr [r12 + 0x0100], ymm0   ; c4 c1 7c 11 84 24 00 01 00 00        
  1102 : vmovups      ymmword ptr [r15 + 0x0100], ymm0   ; c4 c1 7c 11 87 00 01 00 00           
  1103 : vmovups      ymmword ptr [r8 + 0x0100], ymm7    ; c4 c1 7c 11 b8 00 01 00 00           
  1104 : vmovups      ymmword ptr [r8 + 0x0100], ymm8    ; c4 41 7c 11 80 00 01 00 00           
  1105 : vmovups      ymmword ptr [r12 + 0x0100], ymm8   ; c4 41 7c 11 84 24 00 01 00 00        
  1106 : vmovups      ymmword ptr [r15 + 0x0100], ymm8   ; c4 41 7c 11 87 00 01 00 00           
  1107 : vmovups      ymmword ptr [r8 + 0x0100], ymm15   ; c4 41 7c 11 b8 00 01 00 00           
  1108 : vmovupd      ymmword ptr [rax + 0x0100], ymm0   ; c5 fd 11 80 00 01 00 00              
  1109 : vmovupd      ymmword ptr [rsp + 0x0100], ymm0   ; c5 fd 11 84 24 00 01 00 00           
  1110 : vmovupd      ymmword ptr [rdi + 0x0100], ymm0   ; c5 fd 11 87 00 01 00 00              
  1111 : vmovupd      ymmword ptr [rax + 0x0100], ymm7   ; c5 fd 11 b8 00 01 00 00              
  1112 : vmovupd      ymmword ptr [rax + 0x0100], ymm8   ; c5 7d 11 80 00 01 00 00              
  1113 : vmovupd      ymmword ptr [rsp + 0x0100], ymm8   ; c5 7d 11 84 24 00 01 00 00           
  1114 : vmovupd      ymmword ptr [rdi + 0x0100], ymm8   ; c5 7d 11 87 00 01 00 00              
  1115 : vmovupd      ymmword ptr [rax + 0x0100], ymm15  ; c5 7d 11 b8 00 01 00 00              
  1116 : vmovupd      ymmword ptr [r8 + 0x0100], ymm0    ; c4 c1 7d 11 80 00 01 00 00           
  1117 : vmovupd      ymmword ptr [r12 + 0x0100], ymm0   ; c4 c1 7d 11 84 24 00 01 00 00        
  1118 : vmovupd      ymmword ptr [r15 + 0x0100], ymm0   ; c4 c1 7d 11 87 00 01 00 00           
  1119 : vmovupd      ymmword ptr [r8 + 0x0100], ymm7    ; c4 c1 7d 11 b8 00 01 00 00           
  1120 : vmovupd      ymmword ptr [r8 + 0x0100], ymm8    ; c4 41 7d 11 80 00 01 00 00           
  1121 : vmovupd      ymmword ptr [r12 + 0x0100], ymm8   ; c4 41 7d 11 84 24 00 01 00 00        
  1122 : vmovupd      ymmword ptr [r15 + 0x0100], ymm8   ; c4 41 7d 11 87 00 01 00 00           
  1123 : vmovupd      ymmword ptr [r8 + 0x0100], ymm15   ; c4 41 7d 11 b8 00 01 00 00           
  1124 : vpaddb       ymm0, ymm0, ymm0                   ; c5 fd fc c0                          
  1125 : vpaddb       ymm7, ymm0, ymm0                   ; c5 fd fc f8                          
  1126 : vpaddb       ymm0, ymm7, ymm0                   ; c5 c5 fc c0                          
  1127 : vpaddb       ymm0, ymm0, ymm7                   ; c5 fd fc c7                          
  1128 : vpaddb       ymm8, ymm0, ymm0                   ; c5 7d fc c0                          
  1129 : vpaddb       ymm15, ymm0, ymm0                  ; c5 7d fc f8                          
  1130 : vpaddb       ymm8, ymm7, ymm0                   ; c5 45 fc c0                          
  1131 : vpaddb       ymm8, ymm0, ymm7                   ; c5 7d fc c7                          
  1132 : vpaddb       ymm0, ymm8, ymm0                   ; c5 bd fc c0                          
  1133 : vpaddb       ymm7, ymm8, ymm0                   ; c5 bd fc f8                          
  1134 : vpaddb       ymm0, ymm15, ymm0                  ; c5 85 fc c0                          
  1135 : vpaddb       ymm0, ymm8, ymm7                   ; c5 bd fc c7                          
  1136 : vpaddb       ymm0, ymm0, ymm8                   ; c4 c1 7d fc c0                       
  1137 : vpaddb       ymm7, ymm0, ymm8                   ; c4 c1 7d fc f8                       
  1138 : vpaddb       ymm0, ymm7, ymm8                   ; c4 c1 45 fc c0                       
  1139 : vpaddb       ymm0, ymm0, ymm15                  ; c4 c1 7d fc c7                       
  1140 : vpaddw       ymm0, ymm0, ymm0                   ; c5 fd fd c0                          
  1141 : vpaddw       ymm7, ymm0, ymm0                   ; c5 fd fd f8                          
  1142 : vpaddw       ymm0, ymm7, ymm0                   ; c5 c5 fd c0                          
  1143 : vpaddw       ymm0, ymm0, ymm7                   ; c5 fd fd c7                          
  1144 : vpaddw       ymm8, ymm0, ymm0                   ; c5 7d fd c0                          
  1145 : vpaddw       ymm15, ymm0, ymm0                  ; c5 7d fd f8                          
  1146 : vpaddw       ymm8, ymm7, ymm0                   ; c5 45 fd c0                          
  1147 : vpaddw       ymm8, ymm0, ymm7                   ; c5 7d fd c7                          
  1148 : vpaddw       ymm0, ymm8, ymm0                   ; c5 bd fd c0                          
  1149 : vpaddw       ymm7, ymm8, ymm0                   ; c5 bd fd f8                          
  1150 : vpaddw       ymm0, ymm15, ymm0                  ; c5 85 fd c0                          
  1151 : vpaddw       ymm0, ymm8, ymm7                   ; c5 bd fd c7                          
  1152 : vpaddw       ymm0, ymm0, ymm8                   ; c4 c1 7d fd c0                       
  1153 : vpaddw       ymm7, ymm0, ymm8                   ; c4 c1 7d fd f8                       
  1154 : vpaddw       ymm0, ymm7, ymm8                   ; c4 c1 45 fd c0                       
  1155 : vpaddw       ymm0, ymm0, ymm15                  ; c4 c1 7d fd c7                       
  1156 : vpaddd       ymm0, ymm0, ymm0                   ; c5 fd fe c0                          
  1157 : vpaddd       ymm7, ymm0, ymm0                   ; c5 fd fe f8                          
  1158 : vpaddd       ymm0, ymm7, ymm0                   ; c5 c5 fe c0                          
  1159 : vpaddd       ymm0, ymm0, ymm7                   ; c5 fd fe c7                          
  1160 : vpaddd       ymm8, ymm0, ymm0                   ; c5 7d fe c0                          
  1161 : vpaddd       ymm15, ymm0, ymm0                  ; c5 7d fe f8                          
  1162 : vpaddd       ymm8, ymm7, ymm0                   ; c5 45 fe c0                          
  1163 : vpaddd       ymm8, ymm0, ymm7                   ; c5 7d fe c7                          
  1164 : vpaddd       ymm0, ymm8, ymm0                   ; c5 bd fe c0                          
  1165 : vpaddd       ymm7, ymm8, ymm0                   ; c5 bd fe f8                          
  1166 : vpaddd       ymm0, ymm15, ymm0                  ; c5 85 fe c0                          
  1167 : vpaddd       ymm0, ymm8, ymm7                   ; c5 bd fe c7                          
  1168 : vpaddd       ymm0, ymm0, ymm8                   ; c4 c1 7d fe c0                       
  1169 : vpaddd       ymm7, ymm0, ymm8                   ; c4 c1 7d fe f8                       
  1170 : vpaddd       ymm0, ymm7, ymm8                   ; c4 c1 45 fe c0                       
  1171 : vpaddd       ymm0, ymm0, ymm15                  ; c4 c1 7d fe c7                       
  1172 : vpaddq       ymm0, ymm0, ymm0                   ; c5 fd d4 c0                          
  1173 : vpaddq       ymm7, ymm0, ymm0                   ; c5 fd d4 f8                          
  1174 : vpaddq       ymm0, ymm7, ymm0                   ; c5 c5 d4 c0                          
  1175 : vpaddq       ymm0, ymm0, ymm7                   ; c5 fd d4 c7                          
  1176 : vpaddq       ymm8, ymm0, ymm0                   ; c5 7d d4 c0                          
  1177 : vpaddq       ymm15, ymm0, ymm0                  ; c5 7d d4 f8                          
  1178 : vpaddq       ymm8, ymm7, ymm0                   ; c5 45 d4 c0                          
  1179 : vpaddq       ymm8, ymm0, ymm7                   ; c5 7d d4 c7                          
  1180 : vpaddq       ymm0, ymm8, ymm0                   ; c5 bd d4 c0                          
  1181 : vpaddq       ymm7, ymm8, ymm0                   ; c5 bd d4 f8                          
  1182 : vpaddq       ymm0, ymm15, ymm0                  ; c5 85 d4 c0                          
  1183 : vpaddq       ymm0, ymm8, ymm7                   ; c5 bd d4 c7                          
  1184 : vpaddq       ymm0, ymm0, ymm8                   ; c4 c1 7d d4 c0                       
  1185 : vpaddq       ymm7, ymm0, ymm8                   ; c4 c1 7d d4 f8                       
  1186 : vpaddq       ymm0, ymm7, ymm8                   ; c4 c1 45 d4 c0                       
  1187 : vpaddq       ymm0, ymm0, ymm15                  ; c4 c1 7d d4 c7                       
  1188 : vaddps       ymm0, ymm0, ymm0                   ; c5 fc 58 c0                          
  1189 : vaddps       ymm7, ymm0, ymm0                   ; c5 fc 58 f8                          
  1190 : vaddps       ymm0, ymm7, ymm0                   ; c5 c4 58 c0                          
  1191 : vaddps       ymm0, ymm0, ymm7                   ; c5 fc 58 c7                          
  1192 : vaddps       ymm8, ymm0, ymm0                   ; c5 7c 58 c0                          
  1193 : vaddps       ymm15, ymm0, ymm0                  ; c5 7c 58 f8                          
  1194 : vaddps       ymm8, ymm7, ymm0                   ; c5 44 58 c0                          
  1195 : vaddps       ymm8, ymm0, ymm7                   ; c5 7c 58 c7                          
  1196 : vaddps       ymm0, ymm8, ymm0                   ; c5 bc 58 c0                          
  1197 : vaddps       ymm7, ymm8, ymm0                   ; c5 bc 58 f8                          
  1198 : vaddps       ymm0, ymm15, ymm0                  ; c5 84 58 c0                          
  1199 : vaddps       ymm0, ymm8, ymm7                   ; c5 bc 58 c7                          
  1200 : vaddps       ymm0, ymm0, ymm8                   ; c4 c1 7c 58 c0                       
  1201 : vaddps       ymm7, ymm0, ymm8                   ; c4 c1 7c 58 f8                       
  1202 : vaddps       ymm0, ymm7, ymm8                   ; c4 c1 44 58 c0                       
  1203 : vaddps       ymm0, ymm0, ymm15                  ; c4 c1 7c 58 c7                       
  1204 : vaddpd       ymm0, ymm0, ymm0                   ; c5 fd 58 c0                          
  1205 : vaddpd       ymm7, ymm0, ymm0                   ; c5 fd 58 f8                          
  1206 : vaddpd       ymm0, ymm7, ymm0                   ; c5 c5 58 c0                          
  1207 : vaddpd       ymm0, ymm0, ymm7                   ; c5 fd 58 c7                          
  1208 : vaddpd       ymm8, ymm0, ymm0                   ; c5 7d 58 c0                          
  1209 : vaddpd       ymm15, ymm0, ymm0                  ; c5 7d 58 f8                          
  1210 : vaddpd       ymm8, ymm7, ymm0                   ; c5 45 58 c0                          
  1211 : vaddpd       ymm8, ymm0, ymm7                   ; c5 7d 58 c7                          
  1212 : vaddpd       ymm0, ymm8, ymm0                   ; c5 bd 58 c0                          
  1213 : vaddpd       ymm7, ymm8, ymm0                   ; c5 bd 58 f8                          
  1214 : vaddpd       ymm0, ymm15, ymm0                  ; c5 85 58 c0                          
  1215 : vaddpd       ymm0, ymm8, ymm7                   ; c5 bd 58 c7                          
  1216 : vaddpd       ymm0, ymm0, ymm8                   ; c4 c1 7d 58 c0                       
  1217 : vaddpd       ymm7, ymm0, ymm8                   ; c4 c1 7d 58 f8                       
  1218 : vaddpd       ymm0, ymm7, ymm8                   ; c4 c1 45 58 c0                       
  1219 : vaddpd       ymm0, ymm0, ymm15                  ; c4 c1 7d 58 c7                       
  1220 : vpsubb       ymm0, ymm0, ymm0                   ; c5 fd f8 c0                          
  1221 : vpsubb       ymm7, ymm0, ymm0                   ; c5 fd f8 f8                          
  1222 : vpsubb       ymm0, ymm7, ymm0                   ; c5 c5 f8 c0                          
  1223 : vpsubb       ymm0, ymm0, ymm7                   ; c5 fd f8 c7                          
  1224 : vpsubb       ymm8, ymm0, ymm0                   ; c5 7d f8 c0                          
  1225 : vpsubb       ymm15, ymm0, ymm0                  ; c5 7d f8 f8                          
  1226 : vpsubb       ymm8, ymm7, ymm0                   ; c5 45 f8 c0                          
  1227 : vpsubb       ymm8, ymm0, ymm7                   ; c5 7d f8 c7                          
  1228 : vpsubb       ymm0, ymm8, ymm0                   ; c5 bd f8 c0                          
  1229 : vpsubb       ymm7, ymm8, ymm0                   ; c5 bd f8 f8                          
  1230 : vpsubb       ymm0, ymm15, ymm0                  ; c5 85 f8 c0                          
  1231 : vpsubb       ymm0, ymm8, ymm7                   ; c5 bd f8 c7                          
  1232 : vpsubb       ymm0, ymm0, ymm8                   ; c4 c1 7d f8 c0                       
  1233 : vpsubb       ymm7, ymm0, ymm8                   ; c4 c1 7d f8 f8                       
  1234 : vpsubb       ymm0, ymm7, ymm8                   ; c4 c1 45 f8 c0                       
  1235 : vpsubb       ymm0, ymm0, ymm15                  ; c4 c1 7d f8 c7                       
  1236 : vpsubw       ymm0, ymm0, ymm0                   ; c5 fd f9 c0                          
  1237 : vpsubw       ymm7, ymm0, ymm0                   ; c5 fd f9 f8                          
  1238 : vpsubw       ymm0, ymm7, ymm0                   ; c5 c5 f9 c0                          
  1239 : vpsubw       ymm0, ymm0, ymm7                   ; c5 fd f9 c7                          
  1240 : vpsubw       ymm8, ymm0, ymm0                   ; c5 7d f9 c0                          
  1241 : vpsubw       ymm15, ymm0, ymm0                  ; c5 7d f9 f8                          
  1242 : vpsubw       ymm8, ymm7, ymm0                   ; c5 45 f9 c0                          
  1243 : vpsubw       ymm8, ymm0, ymm7                   ; c5 7d f9 c7                          
  1244 : vpsubw       ymm0, ymm8, ymm0                   ; c5 bd f9 c0                          
  1245 : vpsubw       ymm7, ymm8, ymm0                   ; c5 bd f9 f8                          
  1246 : vpsubw       ymm0, ymm15, ymm0                  ; c5 85 f9 c0                          
  1247 : vpsubw       ymm0, ymm8, ymm7                   ; c5 bd f9 c7                          
  1248 : vpsubw       ymm0, ymm0, ymm8                   ; c4 c1 7d f9 c0                       
  1249 : vpsubw       ymm7, ymm0, ymm8                   ; c4 c1 7d f9 f8                       
  1250 : vpsubw       ymm0, ymm7, ymm8                   ; c4 c1 45 f9 c0                       
  1251 : vpsubw       ymm0, ymm0, ymm15                  ; c4 c1 7d f9 c7                       
  1252 : vpsubd       ymm0, ymm0, ymm0                   ; c5 fd fa c0                          
  1253 : vpsubd       ymm7, ymm0, ymm0                   ; c5 fd fa f8                          
  1254 : vpsubd       ymm0, ymm7, ymm0                   ; c5 c5 fa c0                          
  1255 : vpsubd       ymm0, ymm0, ymm7                   ; c5 fd fa c7                          
  1256 : vpsubd       ymm8, ymm0, ymm0                   ; c5 7d fa c0                          
  1257 : vpsubd       ymm15, ymm0, ymm0                  ; c5 7d fa f8                          
  1258 : vpsubd       ymm8, ymm7, ymm0                   ; c5 45 fa c0                          
  1259 : vpsubd       ymm8, ymm0, ymm7                   ; c5 7d fa c7                          
  1260 : vpsubd       ymm0, ymm8, ymm0                   ; c5 bd fa c0                          
  1261 : vpsubd       ymm7, ymm8, ymm0                   ; c5 bd fa f8                          
  1262 : vpsubd       ymm0, ymm15, ymm0                  ; c5 85 fa c0                          
  1263 : vpsubd       ymm0, ymm8, ymm7                   ; c5 bd fa c7                          
  1264 : vpsubd       ymm0, ymm0, ymm8                   ; c4 c1 7d fa c0                       
  1265 : vpsubd       ymm7, ymm0, ymm8                   ; c4 c1 7d fa f8                       
  1266 : vpsubd       ymm0, ymm7, ymm8                   ; c4 c1 45 fa c0                       
  1267 : vpsubd       ymm0, ymm0, ymm15                  ; c4 c1 7d fa c7                       
  1268 : vpsubq       ymm0, ymm0, ymm0                   ; c5 fd fb c0                          
  1269 : vpsubq       ymm7, ymm0, ymm0                   ; c5 fd fb f8                          
  1270 : vpsubq       ymm0, ymm7, ymm0                   ; c5 c5 fb c0                          
  1271 : vpsubq       ymm0, ymm0, ymm7                   ; c5 fd fb c7                          
  1272 : vpsubq       ymm8, ymm0, ymm0                   ; c5 7d fb c0                          
  1273 : vpsubq       ymm15, ymm0, ymm0                  ; c5 7d fb f8                          
  1274 : vpsubq       ymm8, ymm7, ymm0                   ; c5 45 fb c0                          
  1275 : vpsubq       ymm8, ymm0, ymm7                   ; c5 7d fb c7                          
  1276 : vpsubq       ymm0, ymm8, ymm0                   ; c5 bd fb c0                          
  1277 : vpsubq       ymm7, ymm8, ymm0                   ; c5 bd fb f8                          
  1278 : vpsubq       ymm0, ymm15, ymm0                  ; c5 85 fb c0                          
  1279 : vpsubq       ymm0, ymm8, ymm7                   ; c5 bd fb c7                          
  1280 : vpsubq       ymm0, ymm0, ymm8                   ; c4 c1 7d fb c0                       
  1281 : vpsubq       ymm7, ymm0, ymm8                   ; c4 c1 7d fb f8                       
  1282 : vpsubq       ymm0, ymm7, ymm8                   ; c4 c1 45 fb c0                       
  1283 : vpsubq       ymm0, ymm0, ymm15                  ; c4 c1 7d fb c7                       
  1284 : vsubps       ymm0, ymm0, ymm0                   ; c5 fc 5c c0                          
  1285 : vsubps       ymm7, ymm0, ymm0                   ; c5 fc 5c f8                          
  1286 : vsubps       ymm0, ymm7, ymm0                   ; c5 c4 5c c0                          
  1287 : vsubps       ymm0, ymm0, ymm7                   ; c5 fc 5c c7                          
  1288 : vsubps       ymm8, ymm0, ymm0                   ; c5 7c 5c c0                          
  1289 : vsubps       ymm15, ymm0, ymm0                  ; c5 7c 5c f8                          
  1290 : vsubps       ymm8, ymm7, ymm0                   ; c5 44 5c c0                          
  1291 : vsubps       ymm8, ymm0, ymm7                   ; c5 7c 5c c7                          
  1292 : vsubps       ymm0, ymm8, ymm0                   ; c5 bc 5c c0                          
  1293 : vsubps       ymm7, ymm8, ymm0                   ; c5 bc 5c f8                          
  1294 : vsubps       ymm0, ymm15, ymm0                  ; c5 84 5c c0                          
  1295 : vsubps       ymm0, ymm8, ymm7                   ; c5 bc 5c c7                          
  1296 : vsubps       ymm0, ymm0, ymm8                   ; c4 c1 7c 5c c0                       
  1297 : vsubps       ymm7, ymm0, ymm8                   ; c4 c1 7c 5c f8                       
  1298 : vsubps       ymm0, ymm7, ymm8                   ; c4 c1 44 5c c0                       
  1299 : vsubps       ymm0, ymm0, ymm15                  ; c4 c1 7c 5c c7                       
  1300 : vsubpd       ymm0, ymm0, ymm0                   ; c5 fd 5c c0                          
  1301 : vsubpd       ymm7, ymm0, ymm0                   ; c5 fd 5c f8                          
  1302 : vsubpd       ymm0, ymm7, ymm0                   ; c5 c5 5c c0                          
  1303 : vsubpd       ymm0, ymm0, ymm7                   ; c5 fd 5c c7                          
  1304 : vsubpd       ymm8, ymm0, ymm0                   ; c5 7d 5c c0                          
  1305 : vsubpd       ymm15, ymm0, ymm0                  ; c5 7d 5c f8                          
  1306 : vsubpd       ymm8, ymm7, ymm0                   ; c5 45 5c c0                          
  1307 : vsubpd       ymm8, ymm0, ymm7                   ; c5 7d 5c c7                          
  1308 : vsubpd       ymm0, ymm8, ymm0                   ; c5 bd 5c c0                          
  1309 : vsubpd       ymm7, ymm8, ymm0                   ; c5 bd 5c f8                          
  1310 : vsubpd       ymm0, ymm15, ymm0                  ; c5 85 5c c0                          
  1311 : vsubpd       ymm0, ymm8, ymm7                   ; c5 bd 5c c7                          
  1312 : vsubpd       ymm0, ymm0, ymm8                   ; c4 c1 7d 5c c0                       
  1313 : vsubpd       ymm7, ymm0, ymm8                   ; c4 c1 7d 5c f8                       
  1314 : vsubpd       ymm0, ymm7, ymm8                   ; c4 c1 45 5c c0                       
  1315 : vsubpd       ymm0, ymm0, ymm15                  ; c4 c1 7d 5c c7                       
  1316 : vpmullw      ymm0, ymm0, ymm0                   ; c5 fd d5 c0                          
  1317 : vpmullw      ymm7, ymm0, ymm0                   ; c5 fd d5 f8                          
  1318 : vpmullw      ymm0, ymm7, ymm0                   ; c5 c5 d5 c0                          
  1319 : vpmullw      ymm0, ymm0, ymm7                   ; c5 fd d5 c7                          
  1320 : vpmullw      ymm8, ymm0, ymm0                   ; c5 7d d5 c0                          
  1321 : vpmullw      ymm15, ymm0, ymm0                  ; c5 7d d5 f8                          
  1322 : vpmullw      ymm8, ymm7, ymm0                   ; c5 45 d5 c0                          
  1323 : vpmullw      ymm8, ymm0, ymm7                   ; c5 7d d5 c7                          
  1324 : vpmullw      ymm0, ymm8, ymm0                   ; c5 bd d5 c0                          
  1325 : vpmullw      ymm7, ymm8, ymm0                   ; c5 bd d5 f8                          
  1326 : vpmullw      ymm0, ymm15, ymm0                  ; c5 85 d5 c0                          
  1327 : vpmullw      ymm0, ymm8, ymm7                   ; c5 bd d5 c7                          
  1328 : vpmullw      ymm0, ymm0, ymm8                   ; c4 c1 7d d5 c0                       
  1329 : vpmullw      ymm7, ymm0, ymm8                   ; c4 c1 7d d5 f8                       
  1330 : vpmullw      ymm0, ymm7, ymm8                   ; c4 c1 45 d5 c0                       
  1331 : vpmullw      ymm0, ymm0, ymm15                  ; c4 c1 7d d5 c7                       
  1332 : vpmulld      ymm0, ymm0, ymm0                   ; c4 e2 7d 40 c0                       
  1333 : vpmulld      ymm7, ymm0, ymm0                   ; c4 e2 7d 40 f8                       
  1334 : vpmulld      ymm0, ymm7, ymm0                   ; c4 e2 45 40 c0                       
  1335 : vpmulld      ymm0, ymm0, ymm7                   ; c4 e2 7d 40 c7                       
  1336 : vpmulld      ymm8, ymm0, ymm0                   ; c4 62 7d 40 c0                       
  1337 : vpmulld      ymm15, ymm0, ymm0                  ; c4 62 7d 40 f8                       
  1338 : vpmulld      ymm8, ymm7, ymm0                   ; c4 62 45 40 c0                       
  1339 : vpmulld      ymm8, ymm0, ymm7                   ; c4 62 7d 40 c7                       
  1340 : vpmulld      ymm0, ymm8, ymm0                   ; c4 e2 3d 40 c0                       
  1341 : vpmulld      ymm7, ymm8, ymm0                   ; c4 e2 3d 40 f8                       
  1342 : vpmulld      ymm0, ymm15, ymm0                  ; c4 e2 05 40 c0                       
  1343 : vpmulld      ymm0, ymm8, ymm7                   ; c4 e2 3d 40 c7                       
  1344 : vpmulld      ymm0, ymm0, ymm8                   ; c4 c2 7d 40 c0                       
  1345 : vpmulld      ymm7, ymm0, ymm8                   ; c4 c2 7d 40 f8                       
  1346 : vpmulld      ymm0, ymm7, ymm8                   ; c4 c2 45 40 c0                       
  1347 : vpmulld      ymm0, ymm0, ymm15                  ; c4 c2 7d 40 c7                       
  1348 : vmulps       ymm0, ymm0, ymm0                   ; c5 fc 59 c0                          
  1349 : vmulps       ymm7, ymm0, ymm0                   ; c5 fc 59 f8                          
  1350 : vmulps       ymm0, ymm7, ymm0                   ; c5 c4 59 c0                          
  1351 : vmulps       ymm0, ymm0, ymm7                   ; c5 fc 59 c7                          
  1352 : vmulps       ymm8, ymm0, ymm0                   ; c5 7c 59 c0                          
  1353 : vmulps       ymm15, ymm0, ymm0                  ; c5 7c 59 f8                          
  1354 : vmulps       ymm8, ymm7, ymm0                   ; c5 44 59 c0                          
  1355 : vmulps       ymm8, ymm0, ymm7                   ; c5 7c 59 c7                          
  1356 : vmulps       ymm0, ymm8, ymm0                   ; c5 bc 59 c0                          
  1357 : vmulps       ymm7, ymm8, ymm0                   ; c5 bc 59 f8                          
  1358 : vmulps       ymm0, ymm15, ymm0                  ; c5 84 59 c0                          
  1359 : vmulps       ymm0, ymm8, ymm7                   ; c5 bc 59 c7                          
  1360 : vmulps       ymm0, ymm0, ymm8                   ; c4 c1 7c 59 c0                       
  1361 : vmulps       ymm7, ymm0, ymm8                   ; c4 c1 7c 59 f8                       
  1362 : vmulps       ymm0, ymm7, ymm8                   ; c4 c1 44 59 c0                       
  1363 : vmulps       ymm0, ymm0, ymm15                  ; c4 c1 7c 59 c7                       
  1364 : vmulpd       ymm0, ymm0, ymm0                   ; c5 fd 59 c0                          
  1365 : vmulpd       ymm7, ymm0, ymm0                   ; c5 fd 59 f8                          
  1366 : vmulpd       ymm0, ymm7, ymm0                   ; c5 c5 59 c0                          
  1367 : vmulpd       ymm0, ymm0, ymm7                   ; c5 fd 59 c7                          
  1368 : vmulpd       ymm8, ymm0, ymm0                   ; c5 7d 59 c0                          
  1369 : vmulpd       ymm15, ymm0, ymm0                  ; c5 7d 59 f8                          
  1370 : vmulpd       ymm8, ymm7, ymm0                   ; c5 45 59 c0                          
  1371 : vmulpd       ymm8, ymm0, ymm7                   ; c5 7d 59 c7                          
  1372 : vmulpd       ymm0, ymm8, ymm0                   ; c5 bd 59 c0                          
  1373 : vmulpd       ymm7, ymm8, ymm0                   ; c5 bd 59 f8                          
  1374 : vmulpd       ymm0, ymm15, ymm0                  ; c5 85 59 c0                          
  1375 : vmulpd       ymm0, ymm8, ymm7                   ; c5 bd 59 c7                          
  1376 : vmulpd       ymm0, ymm0, ymm8                   ; c4 c1 7d 59 c0                       
  1377 : vmulpd       ymm7, ymm0, ymm8                   ; c4 c1 7d 59 f8                       
  1378 : vmulpd       ymm0, ymm7, ymm8                   ; c4 c1 45 59 c0                       
  1379 : vmulpd       ymm0, ymm0, ymm15                  ; c4 c1 7d 59 c7                       
  1380 : vdivps       ymm0, ymm0, ymm0                   ; c5 fc 5e c0                          
  1381 : vdivps       ymm7, ymm0, ymm0                   ; c5 fc 5e f8                          
  1382 : vdivps       ymm0, ymm7, ymm0                   ; c5 c4 5e c0                          
  1383 : vdivps       ymm0, ymm0, ymm7                   ; c5 fc 5e c7                          
  1384 : vdivps       ymm8, ymm0, ymm0                   ; c5 7c 5e c0                          
  1385 : vdivps       ymm15, ymm0, ymm0                  ; c5 7c 5e f8                          
  1386 : vdivps       ymm8, ymm7, ymm0                   ; c5 44 5e c0                          
  1387 : vdivps       ymm8, ymm0, ymm7                   ; c5 7c 5e c7                          
  1388 : vdivps       ymm0, ymm8, ymm0                   ; c5 bc 5e c0                          
  1389 : vdivps       ymm7, ymm8, ymm0                   ; c5 bc 5e f8                          
  1390 : vdivps       ymm0, ymm15, ymm0                  ; c5 84 5e c0                          
  1391 : vdivps       ymm0, ymm8, ymm7                   ; c5 bc 5e c7                          
  1392 : vdivps       ymm0, ymm0, ymm8                   ; c4 c1 7c 5e c0                       
  1393 : vdivps       ymm7, ymm0, ymm8                   ; c4 c1 7c 5e f8                       
  1394 : vdivps       ymm0, ymm7, ymm8                   ; c4 c1 44 5e c0                       
  1395 : vdivps       ymm0, ymm0, ymm15                  ; c4 c1 7c 5e c7                       
  1396 : vdivpd       ymm0, ymm0, ymm0                   ; c5 fd 5e c0                          
  1397 : vdivpd       ymm7, ymm0, ymm0                   ; c5 fd 5e f8                          
  1398 : vdivpd       ymm0, ymm7, ymm0                   ; c5 c5 5e c0                          
  1399 : vdivpd       ymm0, ymm0, ymm7                   ; c5 fd 5e c7                          
  1400 : vdivpd       ymm8, ymm0, ymm0                   ; c5 7d 5e c0                          
  1401 : vdivpd       ymm15, ymm0, ymm0                  ; c5 7d 5e f8                          
  1402 : vdivpd       ymm8, ymm7, ymm0                   ; c5 45 5e c0                          
  1403 : vdivpd       ymm8, ymm0, ymm7                   ; c5 7d 5e c7                          
  1404 : vdivpd       ymm0, ymm8, ymm0                   ; c5 bd 5e c0                          
  1405 : vdivpd       ymm7, ymm8, ymm0                   ; c5 bd 5e f8                          
  1406 : vdivpd       ymm0, ymm15, ymm0                  ; c5 85 5e c0                          
  1407 : vdivpd       ymm0, ymm8, ymm7                   ; c5 bd 5e c7                          
  1408 : vdivpd       ymm0, ymm0, ymm8                   ; c4 c1 7d 5e c0                       
  1409 : vdivpd       ymm7, ymm0, ymm8                   ; c4 c1 7d 5e f8                       
  1410 : vdivpd       ymm0, ymm7, ymm8                   ; c4 c1 45 5e c0                       
  1411 : vdivpd       ymm0, ymm0, ymm15                  ; c4 c1 7d 5e c7                       
  1412 : vfmadd231ps  ymm0, ymm0, ymm0                   ; c4 e2 7d b8 c0                       
  1413 : vfmadd231ps  ymm7, ymm0, ymm0                   ; c4 e2 7d b8 f8                       
  1414 : vfmadd231ps  ymm0, ymm7, ymm0                   ; c4 e2 45 b8 c0                       
  1415 : vfmadd231ps  ymm0, ymm0, ymm7                   ; c4 e2 7d b8 c7                       
  1416 : vfmadd231ps  ymm8, ymm0, ymm0                   ; c4 62 7d b8 c0                       
  1417 : vfmadd231ps  ymm15, ymm0, ymm0                  ; c4 62 7d b8 f8                       
  1418 : vfmadd231ps  ymm8, ymm7, ymm0                   ; c4 62 45 b8 c0                       
  1419 : vfmadd231ps  ymm8, ymm0, ymm7                   ; c4 62 7d b8 c7                       
  1420 : vfmadd231ps  ymm0, ymm8, ymm0                   ; c4 e2 3d b8 c0                       
  1421 : vfmadd231ps  ymm7, ymm8, ymm0                   ; c4 e2 3d b8 f8                       
  1422 : vfmadd231ps  ymm0, ymm15, ymm0                  ; c4 e2 05 b8 c0                       
  1423 : vfmadd231ps  ymm0, ymm8, ymm7                   ; c4 e2 3d b8 c7                       
  1424 : vfmadd231ps  ymm0, ymm0, ymm8                   ; c4 c2 7d b8 c0                       
  1425 : vfmadd231ps  ymm7, ymm0, ymm8                   ; c4 c2 7d b8 f8                       
  1426 : vfmadd231ps  ymm0, ymm7, ymm8                   ; c4 c2 45 b8 c0                       
  1427 : vfmadd231ps  ymm0, ymm0, ymm15                  ; c4 c2 7d b8 c7                       
  1428 : vfmadd231pd  ymm0, ymm0, ymm0                   ; c4 e2 fd b8 c0                       
  1429 : vfmadd231pd  ymm7, ymm0, ymm0                   ; c4 e2 fd b8 f8                       
  1430 : vfmadd231pd  ymm0, ymm7, ymm0                   ; c4 e2 c5 b8 c0                       
  1431 : vfmadd231pd  ymm0, ymm0, ymm7                   ; c4 e2 fd b8 c7                       
  1432 : vfmadd231pd  ymm8, ymm0, ymm0                   ; c4 62 fd b8 c0                       
  1433 : vfmadd231pd  ymm15, ymm0, ymm0                  ; c4 62 fd b8 f8                       
  1434 : vfmadd231pd  ymm8, ymm7, ymm0                   ; c4 62 c5 b8 c0                       
  1435 : vfmadd231pd  ymm8, ymm0, ymm7                   ; c4 62 fd b8 c7                       
  1436 : vfmadd231pd  ymm0, ymm8, ymm0                   ; c4 e2 bd b8 c0                       
  1437 : vfmadd231pd  ymm7, ymm8, ymm0                   ; c4 e2 bd b8 f8                       
  1438 : vfmadd231pd  ymm0, ymm15, ymm0                  ; c4 e2 85 b8 c0                       
  1439 : vfmadd231pd  ymm0, ymm8, ymm7                   ; c4 e2 bd b8 c7                       
  1440 : vfmadd231pd  ymm0, ymm0, ymm8                   ; c4 c2 fd b8 c0                       
  1441 : vfmadd231pd  ymm7, ymm0, ymm8                   ; c4 c2 fd b8 f8                       
  1442 : vfmadd231pd  ymm0, ymm7, ymm8                   ; c4 c2 c5 b8 c0                       
  1443 : vfmadd231pd  ymm0, ymm0, ymm15                  ; c4 c2 fd b8 c7                       
  1444 : vpminub      ymm0, ymm0, ymm0                   ; c5 fd da c0                          
  1445 : vpminub      ymm7, ymm0, ymm0                   ; c5 fd da f8                          
  1446 : vpminub      ymm0, ymm7, ymm0                   ; c5 c5 da c0                          
  1447 : vpminub      ymm0, ymm0, ymm7                   ; c5 fd da c7                          
  1448 : vpminub      ymm8, ymm0, ymm0                   ; c5 7d da c0                          
  1449 : vpminub      ymm15, ymm0, ymm0                  ; c5 7d da f8                          
  1450 : vpminub      ymm8, ymm7, ymm0                   ; c5 45 da c0                          
  1451 : vpminub      ymm8, ymm0, ymm7                   ; c5 7d da c7                          
  1452 : vpminub      ymm0, ymm8, ymm0                   ; c5 bd da c0                          
  1453 : vpminub      ymm7, ymm8, ymm0                   ; c5 bd da f8                          
  1454 : vpminub      ymm0, ymm15, ymm0                  ; c5 85 da c0                          
  1455 : vpminub      ymm0, ymm8, ymm7                   ; c5 bd da c7                          
  1456 : vpminub      ymm0, ymm0, ymm8                   ; c4 c1 7d da c0                       
  1457 : vpminub      ymm7, ymm0, ymm8                   ; c4 c1 7d da f8                       
  1458 : vpminub      ymm0, ymm7, ymm8                   ; c4 c1 45 da c0                       
  1459 : vpminub      ymm0, ymm0, ymm15                  ; c4 c1 7d da c7                       
  1460 : vpminsb      ymm0, ymm0, ymm0                   ; c4 e2 7d 38 c0                       
  1461 : vpminsb      ymm7, ymm0, ymm0                   ; c4 e2 7d 38 f8                       
  1462 : vpminsb      ymm0, ymm7, ymm0                   ; c4 e2 45 38 c0                       
  1463 : vpminsb      ymm0, ymm0, ymm7                   ; c4 e2 7d 38 c7                       
  1464 : vpminsb      ymm8, ymm0, ymm0                   ; c4 62 7d 38 c0                       
  1465 : vpminsb      ymm15, ymm0, ymm0                  ; c4 62 7d 38 f8                       
  1466 : vpminsb      ymm8, ymm7, ymm0                   ; c4 62 45 38 c0                       
  1467 : vpminsb      ymm8, ymm0, ymm7                   ; c4 62 7d 38 c7                       
  1468 : vpminsb      ymm0, ymm8, ymm0                   ; c4 e2 3d 38 c0                       
  1469 : vpminsb      ymm7, ymm8, ymm0                   ; c4 e2 3d 38 f8                       
  1470 : vpminsb      ymm0, ymm15, ymm0                  ; c4 e2 05 38 c0                       
  1471 : vpminsb      ymm0, ymm8, ymm7                   ; c4 e2 3d 38 c7                       
  1472 : vpminsb      ymm0, ymm0, ymm8                   ; c4 c2 7d 38 c0                       
  1473 : vpminsb      ymm7, ymm0, ymm8                   ; c4 c2 7d 38 f8                       
  1474 : vpminsb      ymm0, ymm7, ymm8                   ; c4 c2 45 38 c0                       
  1475 : vpminsb      ymm0, ymm0, ymm15                  ; c4 c2 7d 38 c7                       
  1476 : vpminuw      ymm0, ymm0, ymm0                   ; c4 e2 7d 3a c0                       
  1477 : vpminuw      ymm7, ymm0, ymm0                   ; c4 e2 7d 3a f8                       
  1478 : vpminuw      ymm0, ymm7, ymm0                   ; c4 e2 45 3a c0                       
  1479 : vpminuw      ymm0, ymm0, ymm7                   ; c4 e2 7d 3a c7                       
  1480 : vpminuw      ymm8, ymm0, ymm0                   ; c4 62 7d 3a c0                       
  1481 : vpminuw      ymm15, ymm0, ymm0                  ; c4 62 7d 3a f8                       
  1482 : vpminuw      ymm8, ymm7, ymm0                   ; c4 62 45 3a c0                       
  1483 : vpminuw      ymm8, ymm0, ymm7                   ; c4 62 7d 3a c7                       
  1484 : vpminuw      ymm0, ymm8, ymm0                   ; c4 e2 3d 3a c0                       
  1485 : vpminuw      ymm7, ymm8, ymm0                   ; c4 e2 3d 3a f8                       
  1486 : vpminuw      ymm0, ymm15, ymm0                  ; c4 e2 05 3a c0                       
  1487 : vpminuw      ymm0, ymm8, ymm7                   ; c4 e2 3d 3a c7                       
  1488 : vpminuw      ymm0, ymm0, ymm8                   ; c4 c2 7d 3a c0                       
  1489 : vpminuw      ymm7, ymm0, ymm8                   ; c4 c2 7d 3a f8                       
  1490 : vpminuw      ymm0, ymm7, ymm8                   ; c4 c2 45 3a c0                       
  1491 : vpminuw      ymm0, ymm0, ymm15                  ; c4 c2 7d 3a c7                       
  1492 : vpminsw      ymm0, ymm0, ymm0                   ; c5 fd ea c0                          
  1493 : vpminsw      ymm7, ymm0, ymm0                   ; c5 fd ea f8                          
  1494 : vpminsw      ymm0, ymm7, ymm0                   ; c5 c5 ea c0                          
  1495 : vpminsw      ymm0, ymm0, ymm7                   ; c5 fd ea c7                          
  1496 : vpminsw      ymm8, ymm0, ymm0                   ; c5 7d ea c0                          
  1497 : vpminsw      ymm15, ymm0, ymm0                  ; c5 7d ea f8                          
  1498 : vpminsw      ymm8, ymm7, ymm0                   ; c5 45 ea c0                          
  1499 : vpminsw      ymm8, ymm0, ymm7                   ; c5 7d ea c7                          
  1500 : vpminsw      ymm0, ymm8, ymm0                   ; c5 bd ea c0                          
  1501 : vpminsw      ymm7, ymm8, ymm0                   ; c5 bd ea f8                          
  1502 : vpminsw      ymm0, ymm15, ymm0                  ; c5 85 ea c0                          
  1503 : vpminsw      ymm0, ymm8, ymm7                   ; c5 bd ea c7                          
  1504 : vpminsw      ymm0, ymm0, ymm8                   ; c4 c1 7d ea c0                       
  1505 : vpminsw      ymm7, ymm0, ymm8                   ; c4 c1 7d ea f8                       
  1506 : vpminsw      ymm0, ymm7, ymm8                   ; c4 c1 45 ea c0                       
  1507 : vpminsw      ymm0, ymm0, ymm15                  ; c4 c1 7d ea c7                       
  1508 : vpminud      ymm0, ymm0, ymm0                   ; c4 e2 7d 3b c0                       
  1509 : vpminud      ymm7, ymm0, ymm0                   ; c4 e2 7d 3b f8                       
  1510 : vpminud      ymm0, ymm7, ymm0                   ; c4 e2 45 3b c0                       
  1511 : vpminud      ymm0, ymm0, ymm7                   ; c4 e2 7d 3b c7                       
  1512 : vpminud      ymm8, ymm0, ymm0                   ; c4 62 7d 3b c0                       
  1513 : vpminud      ymm15, ymm0, ymm0                  ; c4 62 7d 3b f8                       
  1514 : vpminud      ymm8, ymm7, ymm0                   ; c4 62 45 3b c0                       
  1515 : vpminud      ymm8, ymm0, ymm7                   ; c4 62 7d 3b c7                       
  1516 : vpminud      ymm0, ymm8, ymm0                   ; c4 e2 3d 3b c0                       
  1517 : vpminud      ymm7, ymm8, ymm0                   ; c4 e2 3d 3b f8                       
  1518 : vpminud      ymm0, ymm15, ymm0                  ; c4 e2 05 3b c0                       
  1519 : vpminud      ymm0, ymm8, ymm7                   ; c4 e2 3d 3b c7                       
  1520 : vpminud      ymm0, ymm0, ymm8                   ; c4 c2 7d 3b c0                       
  1521 : vpminud      ymm7, ymm0, ymm8                   ; c4 c2 7d 3b f8                       
  1522 : vpminud      ymm0, ymm7, ymm8                   ; c4 c2 45 3b c0                       
  1523 : vpminud      ymm0, ymm0, ymm15                  ; c4 c2 7d 3b c7                       
  1524 : vpminsd      ymm0, ymm0, ymm0                   ; c4 e2 7d 39 c0                       
  1525 : vpminsd      ymm7, ymm0, ymm0                   ; c4 e2 7d 39 f8                       
  1526 : vpminsd      ymm0, ymm7, ymm0                   ; c4 e2 45 39 c0                       
  1527 : vpminsd      ymm0, ymm0, ymm7                   ; c4 e2 7d 39 c7                       
  1528 : vpminsd      ymm8, ymm0, ymm0                   ; c4 62 7d 39 c0                       
  1529 : vpminsd      ymm15, ymm0, ymm0                  ; c4 62 7d 39 f8                       
  1530 : vpminsd      ymm8, ymm7, ymm0                   ; c4 62 45 39 c0                       
  1531 : vpminsd      ymm8, ymm0, ymm7                   ; c4 62 7d 39 c7                       
  1532 : vpminsd      ymm0, ymm8, ymm0                   ; c4 e2 3d 39 c0                       
  1533 : vpminsd      ymm7, ymm8, ymm0                   ; c4 e2 3d 39 f8                       
  1534 : vpminsd      ymm0, ymm15, ymm0                  ; c4 e2 05 39 c0                       
  1535 : vpminsd      ymm0, ymm8, ymm7                   ; c4 e2 3d 39 c7                       
  1536 : vpminsd      ymm0, ymm0, ymm8                   ; c4 c2 7d 39 c0                       
  1537 : vpminsd      ymm7, ymm0, ymm8                   ; c4 c2 7d 39 f8                       
  1538 : vpminsd      ymm0, ymm7, ymm8                   ; c4 c2 45 39 c0                       
  1539 : vpminsd      ymm0, ymm0, ymm15                  ; c4 c2 7d 39 c7                       
  1540 : vminps       ymm0, ymm0, ymm0                   ; c5 fc 5d c0                          
  1541 : vminps       ymm7, ymm0, ymm0                   ; c5 fc 5d f8                          
  1542 : vminps       ymm0, ymm7, ymm0                   ; c5 c4 5d c0                          
  1543 : vminps       ymm0, ymm0, ymm7                   ; c5 fc 5d c7                          
  1544 : vminps       ymm8, ymm0, ymm0                   ; c5 7c 5d c0                          
  1545 : vminps       ymm15, ymm0, ymm0                  ; c5 7c 5d f8                          
  1546 : vminps       ymm8, ymm7, ymm0                   ; c5 44 5d c0                          
  1547 : vminps       ymm8, ymm0, ymm7                   ; c5 7c 5d c7                          
  1548 : vminps       ymm0, ymm8, ymm0                   ; c5 bc 5d c0                          
  1549 : vminps       ymm7, ymm8, ymm0                   ; c5 bc 5d f8                          
  1550 : vminps       ymm0, ymm15, ymm0                  ; c5 84 5d c0                          
  1551 : vminps       ymm0, ymm8, ymm7                   ; c5 bc 5d c7                          
  1552 : vminps       ymm0, ymm0, ymm8                   ; c4 c1 7c 5d c0                       
  1553 : vminps       ymm7, ymm0, ymm8                   ; c4 c1 7c 5d f8                       
  1554 : vminps       ymm0, ymm7, ymm8                   ; c4 c1 44 5d c0                       
  1555 : vminps       ymm0, ymm0, ymm15                  ; c4 c1 7c 5d c7                       
  1556 : vminpd       ymm0, ymm0, ymm0                   ; c5 fd 5d c0                          
  1557 : vminpd       ymm7, ymm0, ymm0                   ; c5 fd 5d f8                          
  1558 : vminpd       ymm0, ymm7, ymm0                   ; c5 c5 5d c0                          
  1559 : vminpd       ymm0, ymm0, ymm7                   ; c5 fd 5d c7                          
  1560 : vminpd       ymm8, ymm0, ymm0                   ; c5 7d 5d c0                          
  1561 : vminpd       ymm15, ymm0, ymm0                  ; c5 7d 5d f8                          
  1562 : vminpd       ymm8, ymm7, ymm0                   ; c5 45 5d c0                          
  1563 : vminpd       ymm8, ymm0, ymm7                   ; c5 7d 5d c7                          
  1564 : vminpd       ymm0, ymm8, ymm0                   ; c5 bd 5d c0                          
  1565 : vminpd       ymm7, ymm8, ymm0                   ; c5 bd 5d f8                          
  1566 : vminpd       ymm0, ymm15, ymm0                  ; c5 85 5d c0                          
  1567 : vminpd       ymm0, ymm8, ymm7                   ; c5 bd 5d c7                          
  1568 : vminpd       ymm0, ymm0, ymm8                   ; c4 c1 7d 5d c0                       
  1569 : vminpd       ymm7, ymm0, ymm8                   ; c4 c1 7d 5d f8                       
  1570 : vminpd       ymm0, ymm7, ymm8                   ; c4 c1 45 5d c0                       
  1571 : vminpd       ymm0, ymm0, ymm15                  ; c4 c1 7d 5d c7                       
  1572 : vpmaxub      ymm0, ymm0, ymm0                   ; c5 fd de c0                          
  1573 : vpmaxub      ymm7, ymm0, ymm0                   ; c5 fd de f8                          
  1574 : vpmaxub      ymm0, ymm7, ymm0                   ; c5 c5 de c0                          
  1575 : vpmaxub      ymm0, ymm0, ymm7                   ; c5 fd de c7                          
  1576 : vpmaxub      ymm8, ymm0, ymm0                   ; c5 7d de c0                          
  1577 : vpmaxub      ymm15, ymm0, ymm0                  ; c5 7d de f8                          
  1578 : vpmaxub      ymm8, ymm7, ymm0                   ; c5 45 de c0                          
  1579 : vpmaxub      ymm8, ymm0, ymm7                   ; c5 7d de c7                          
  1580 : vpmaxub      ymm0, ymm8, ymm0                   ; c5 bd de c0                          
  1581 : vpmaxub      ymm7, ymm8, ymm0                   ; c5 bd de f8                          
  1582 : vpmaxub      ymm0, ymm15, ymm0                  ; c5 85 de c0                          
  1583 : vpmaxub      ymm0, ymm8, ymm7                   ; c5 bd de c7                          
  1584 : vpmaxub      ymm0, ymm0, ymm8                   ; c4 c1 7d de c0                       
  1585 : vpmaxub      ymm7, ymm0, ymm8                   ; c4 c1 7d de f8                       
  1586 : vpmaxub      ymm0, ymm7, ymm8                   ; c4 c1 45 de c0                       
  1587 : vpmaxub      ymm0, ymm0, ymm15                  ; c4 c1 7d de c7                       
  1588 : vpmaxsb      ymm0, ymm0, ymm0                   ; c4 e2 7d 3c c0                       
  1589 : vpmaxsb      ymm7, ymm0, ymm0                   ; c4 e2 7d 3c f8                       
  1590 : vpmaxsb      ymm0, ymm7, ymm0                   ; c4 e2 45 3c c0                       
  1591 : vpmaxsb      ymm0, ymm0, ymm7                   ; c4 e2 7d 3c c7                       
  1592 : vpmaxsb      ymm8, ymm0, ymm0                   ; c4 62 7d 3c c0                       
  1593 : vpmaxsb      ymm15, ymm0, ymm0                  ; c4 62 7d 3c f8                       
  1594 : vpmaxsb      ymm8, ymm7, ymm0                   ; c4 62 45 3c c0                       
  1595 : vpmaxsb      ymm8, ymm0, ymm7                   ; c4 62 7d 3c c7                       
  1596 : vpmaxsb      ymm0, ymm8, ymm0                   ; c4 e2 3d 3c c0                       
  1597 : vpmaxsb      ymm7, ymm8, ymm0                   ; c4 e2 3d 3c f8                       
  1598 : vpmaxsb      ymm0, ymm15, ymm0                  ; c4 e2 05 3c c0                       
  1599 : vpmaxsb      ymm0, ymm8, ymm7                   ; c4 e2 3d 3c c7                       
  1600 : vpmaxsb      ymm0, ymm0, ymm8                   ; c4 c2 7d 3c c0                       
  1601 : vpmaxsb      ymm7, ymm0, ymm8                   ; c4 c2 7d 3c f8                       
  1602 : vpmaxsb      ymm0, ymm7, ymm8                   ; c4 c2 45 3c c0                       
  1603 : vpmaxsb      ymm0, ymm0, ymm15                  ; c4 c2 7d 3c c7                       
  1604 : vpmaxuw      ymm0, ymm0, ymm0                   ; c4 e2 7d 3e c0                       
  1605 : vpmaxuw      ymm7, ymm0, ymm0                   ; c4 e2 7d 3e f8                       
  1606 : vpmaxuw      ymm0, ymm7, ymm0                   ; c4 e2 45 3e c0                       
  1607 : vpmaxuw      ymm0, ymm0, ymm7                   ; c4 e2 7d 3e c7                       
  1608 : vpmaxuw      ymm8, ymm0, ymm0                   ; c4 62 7d 3e c0                       
  1609 : vpmaxuw      ymm15, ymm0, ymm0                  ; c4 62 7d 3e f8                       
  1610 : vpmaxuw      ymm8, ymm7, ymm0                   ; c4 62 45 3e c0                       
  1611 : vpmaxuw      ymm8, ymm0, ymm7                   ; c4 62 7d 3e c7                       
  1612 : vpmaxuw      ymm0, ymm8, ymm0                   ; c4 e2 3d 3e c0                       
  1613 : vpmaxuw      ymm7, ymm8, ymm0                   ; c4 e2 3d 3e f8                       
  1614 : vpmaxuw      ymm0, ymm15, ymm0                  ; c4 e2 05 3e c0                       
  1615 : vpmaxuw      ymm0, ymm8, ymm7                   ; c4 e2 3d 3e c7                       
  1616 : vpmaxuw      ymm0, ymm0, ymm8                   ; c4 c2 7d 3e c0                       
  1617 : vpmaxuw      ymm7, ymm0, ymm8                   ; c4 c2 7d 3e f8                       
  1618 : vpmaxuw      ymm0, ymm7, ymm8                   ; c4 c2 45 3e c0                       
  1619 : vpmaxuw      ymm0, ymm0, ymm15                  ; c4 c2 7d 3e c7                       
  1620 : vpmaxsw      ymm0, ymm0, ymm0                   ; c5 fd ee c0                          
  1621 : vpmaxsw      ymm7, ymm0, ymm0                   ; c5 fd ee f8                          
  1622 : vpmaxsw      ymm0, ymm7, ymm0                   ; c5 c5 ee c0                          
  1623 : vpmaxsw      ymm0, ymm0, ymm7                   ; c5 fd ee c7                          
  1624 : vpmaxsw      ymm8, ymm0, ymm0                   ; c5 7d ee c0                          
  1625 : vpmaxsw      ymm15, ymm0, ymm0                  ; c5 7d ee f8                          
  1626 : vpmaxsw      ymm8, ymm7, ymm0                   ; c5 45 ee c0                          
  1627 : vpmaxsw      ymm8, ymm0, ymm7                   ; c5 7d ee c7                          
  1628 : vpmaxsw      ymm0, ymm8, ymm0                   ; c5 bd ee c0                          
  1629 : vpmaxsw      ymm7, ymm8, ymm0                   ; c5 bd ee f8                          
  1630 : vpmaxsw      ymm0, ymm15, ymm0                  ; c5 85 ee c0                          
  1631 : vpmaxsw      ymm0, ymm8, ymm7                   ; c5 bd ee c7                          
  1632 : vpmaxsw      ymm0, ymm0, ymm8                   ; c4 c1 7d ee c0                       
  1633 : vpmaxsw      ymm7, ymm0, ymm8                   ; c4 c1 7d ee f8                       
  1634 : vpmaxsw      ymm0, ymm7, ymm8                   ; c4 c1 45 ee c0                       
  1635 : vpmaxsw      ymm0, ymm0, ymm15                  ; c4 c1 7d ee c7                       
  1636 : vpmaxud      ymm0, ymm0, ymm0                   ; c4 e2 7d 3f c0                       
  1637 : vpmaxud      ymm7, ymm0, ymm0                   ; c4 e2 7d 3f f8                       
  1638 : vpmaxud      ymm0, ymm7, ymm0                   ; c4 e2 45 3f c0                       
  1639 : vpmaxud      ymm0, ymm0, ymm7                   ; c4 e2 7d 3f c7                       
  1640 : vpmaxud      ymm8, ymm0, ymm0                   ; c4 62 7d 3f c0                       
  1641 : vpmaxud      ymm15, ymm0, ymm0                  ; c4 62 7d 3f f8                       
  1642 : vpmaxud      ymm8, ymm7, ymm0                   ; c4 62 45 3f c0                       
  1643 : vpmaxud      ymm8, ymm0, ymm7                   ; c4 62 7d 3f c7                       
  1644 : vpmaxud      ymm0, ymm8, ymm0                   ; c4 e2 3d 3f c0                       
  1645 : vpmaxud      ymm7, ymm8, ymm0                   ; c4 e2 3d 3f f8                       
  1646 : vpmaxud      ymm0, ymm15, ymm0                  ; c4 e2 05 3f c0                       
  1647 : vpmaxud      ymm0, ymm8, ymm7                   ; c4 e2 3d 3f c7                       
  1648 : vpmaxud      ymm0, ymm0, ymm8                   ; c4 c2 7d 3f c0                       
  1649 : vpmaxud      ymm7, ymm0, ymm8                   ; c4 c2 7d 3f f8                       
  1650 : vpmaxud      ymm0, ymm7, ymm8                   ; c4 c2 45 3f c0                       
  1651 : vpmaxud      ymm0, ymm0, ymm15                  ; c4 c2 7d 3f c7                       
  1652 : vpmaxsd      ymm0, ymm0, ymm0                   ; c4 e2 7d 3d c0                       
  1653 : vpmaxsd      ymm7, ymm0, ymm0                   ; c4 e2 7d 3d f8                       
  1654 : vpmaxsd      ymm0, ymm7, ymm0                   ; c4 e2 45 3d c0                       
  1655 : vpmaxsd      ymm0, ymm0, ymm7                   ; c4 e2 7d 3d c7                       
  1656 : vpmaxsd      ymm8, ymm0, ymm0                   ; c4 62 7d 3d c0                       
  1657 : vpmaxsd      ymm15, ymm0, ymm0                  ; c4 62 7d 3d f8                       
  1658 : vpmaxsd      ymm8, ymm7, ymm0                   ; c4 62 45 3d c0                       
  1659 : vpmaxsd      ymm8, ymm0, ymm7                   ; c4 62 7d 3d c7                       
  1660 : vpmaxsd      ymm0, ymm8, ymm0                   ; c4 e2 3d 3d c0                       
  1661 : vpmaxsd      ymm7, ymm8, ymm0                   ; c4 e2 3d 3d f8                       
  1662 : vpmaxsd      ymm0, ymm15, ymm0                  ; c4 e2 05 3d c0                       
  1663 : vpmaxsd      ymm0, ymm8, ymm7                   ; c4 e2 3d 3d c7                       
  1664 : vpmaxsd      ymm0, ymm0, ymm8                   ; c4 c2 7d 3d c0                       
  1665 : vpmaxsd      ymm7, ymm0, ymm8                   ; c4 c2 7d 3d f8                       
  1666 : vpmaxsd      ymm0, ymm7, ymm8                   ; c4 c2 45 3d c0                       
  1667 : vpmaxsd      ymm0, ymm0, ymm15                  ; c4 c2 7d 3d c7                       
  1668 : vmaxps       ymm0, ymm0, ymm0                   ; c5 fc 5f c0                          
  1669 : vmaxps       ymm7, ymm0, ymm0                   ; c5 fc 5f f8                          
  1670 : vmaxps       ymm0, ymm7, ymm0                   ; c5 c4 5f c0                          
  1671 : vmaxps       ymm0, ymm0, ymm7                   ; c5 fc 5f c7                          
  1672 : vmaxps       ymm8, ymm0, ymm0                   ; c5 7c 5f c0                          
  1673 : vmaxps       ymm15, ymm0, ymm0                  ; c5 7c 5f f8                          
  1674 : vmaxps       ymm8, ymm7, ymm0                   ; c5 44 5f c0                          
  1675 : vmaxps       ymm8, ymm0, ymm7                   ; c5 7c 5f c7                          
  1676 : vmaxps       ymm0, ymm8, ymm0                   ; c5 bc 5f c0                          
  1677 : vmaxps       ymm7, ymm8, ymm0                   ; c5 bc 5f f8                          
  1678 : vmaxps       ymm0, ymm15, ymm0                  ; c5 84 5f c0                          
  1679 : vmaxps       ymm0, ymm8, ymm7                   ; c5 bc 5f c7                          
  1680 : vmaxps       ymm0, ymm0, ymm8                   ; c4 c1 7c 5f c0                       
  1681 : vmaxps       ymm7, ymm0, ymm8                   ; c4 c1 7c 5f f8                       
  1682 : vmaxps       ymm0, ymm7, ymm8                   ; c4 c1 44 5f c0                       
  1683 : vmaxps       ymm0, ymm0, ymm15                  ; c4 c1 7c 5f c7                       
  1684 : vmaxpd       ymm0, ymm0, ymm0                   ; c5 fd 5f c0                          
  1685 : vmaxpd       ymm7, ymm0, ymm0                   ; c5 fd 5f f8                          
  1686 : vmaxpd       ymm0, ymm7, ymm0                   ; c5 c5 5f c0                          
  1687 : vmaxpd       ymm0, ymm0, ymm7                   ; c5 fd 5f c7                          
  1688 : vmaxpd       ymm8, ymm0, ymm0                   ; c5 7d 5f c0                          
  1689 : vmaxpd       ymm15, ymm0, ymm0                  ; c5 7d 5f f8                          
  1690 : vmaxpd       ymm8, ymm7, ymm0                   ; c5 45 5f c0                          
  1691 : vmaxpd       ymm8, ymm0, ymm7                   ; c5 7d 5f c7                          
  1692 : vmaxpd       ymm0, ymm8, ymm0                   ; c5 bd 5f c0                          
  1693 : vmaxpd       ymm7, ymm8, ymm0                   ; c5 bd 5f f8                          
  1694 : vmaxpd       ymm0, ymm15, ymm0                  ; c5 85 5f c0                          
  1695 : vmaxpd       ymm0, ymm8, ymm7                   ; c5 bd 5f c7                          
  1696 : vmaxpd       ymm0, ymm0, ymm8                   ; c4 c1 7d 5f c0                       
  1697 : vmaxpd       ymm7, ymm0, ymm8                   ; c4 c1 7d 5f f8                       
  1698 : vmaxpd       ymm0, ymm7, ymm8                   ; c4 c1 45 5f c0                       
  1699 : vmaxpd       ymm0, ymm0, ymm15                  ; c4 c1 7d 5f c7                       
  1700 : vroundps     ymm0, ymm0, 0x001                  ; c4 e3 7d 08 c0 01                    
  1701 : vroundps     ymm7, ymm0, 0x001                  ; c4 e3 7d 08 f8 01                    
  1702 : vroundps     ymm0, ymm7, 0x001                  ; c4 e3 7d 08 c7 01                    
  1703 : vroundps     ymm8, ymm0, 0x001                  ; c4 63 7d 08 c0 01                    
  1704 : vroundps     ymm15, ymm0, 0x001                 ; c4 63 7d 08 f8 01                    
  1705 : vroundps     ymm8, ymm7, 0x001                  ; c4 63 7d 08 c7 01                    
  1706 : vroundps     ymm0, ymm8, 0x001                  ; c4 c3 7d 08 c0 01                    
  1707 : vroundps     ymm7, ymm8, 0x001                  ; c4 c3 7d 08 f8 01                    
  1708 : vroundps     ymm0, ymm15, 0x001                 ; c4 c3 7d 08 c7 01                    
  1709 : vroundps     ymm8, ymm8, 0x001                  ; c4 43 7d 08 c0 01                    
  1710 : vroundps     ymm15, ymm8, 0x001                 ; c4 43 7d 08 f8 01                    
  1711 : vroundps     ymm8, ymm15, 0x001                 ; c4 43 7d 08 c7 01                    
  1712 : vroundpd     ymm0, ymm0, 0x001                  ; c4 e3 7d 09 c0 01                    
  1713 : vroundpd     ymm7, ymm0, 0x001                  ; c4 e3 7d 09 f8 01                    
  1714 : vroundpd     ymm0, ymm7, 0x001                  ; c4 e3 7d 09 c7 01                    
  1715 : vroundpd     ymm8, ymm0, 0x001                  ; c4 63 7d 09 c0 01                    
  1716 : vroundpd     ymm15, ymm0, 0x001                 ; c4 63 7d 09 f8 01                    
  1717 : vroundpd     ymm8, ymm7, 0x001                  ; c4 63 7d 09 c7 01                    
  1718 : vroundpd     ymm0, ymm8, 0x001                  ; c4 c3 7d 09 c0 01                    
  1719 : vroundpd     ymm7, ymm8, 0x001                  ; c4 c3 7d 09 f8 01                    
  1720 : vroundpd     ymm0, ymm15, 0x001                 ; c4 c3 7d 09 c7 01                    
  1721 : vroundpd     ymm8, ymm8, 0x001                  ; c4 43 7d 09 c0 01                    
  1722 : vroundpd     ymm15, ymm8, 0x001                 ; c4 43 7d 09 f8 01                    
  1723 : vroundpd     ymm8, ymm15, 0x001                 ; c4 43 7d 09 c7 01                    
  1724 : vroundps     ymm0, ymm0, 0x003                  ; c4 e3 7d 08 c0 03                    
  1725 : vroundps     ymm7, ymm0, 0x003                  ; c4 e3 7d 08 f8 03                    
  1726 : vroundps     ymm0, ymm7, 0x003                  ; c4 e3 7d 08 c7 03                    
  1727 : vroundps     ymm8, ymm0, 0x003                  ; c4 63 7d 08 c0 03                    
  1728 : vroundps     ymm15, ymm0, 0x003                 ; c4 63 7d 08 f8 03                    
  1729 : vroundps     ymm8, ymm7, 0x003                  ; c4 63 7d 08 c7 03                    
  1730 : vroundps     ymm0, ymm8, 0x003                  ; c4 c3 7d 08 c0 03                    
  1731 : vroundps     ymm7, ymm8, 0x003                  ; c4 c3 7d 08 f8 03                    
  1732 : vroundps     ymm0, ymm15, 0x003                 ; c4 c3 7d 08 c7 03                    
  1733 : vroundps     ymm8, ymm8, 0x003                  ; c4 43 7d 08 c0 03                    
  1734 : vroundps     ymm15, ymm8, 0x003                 ; c4 43 7d 08 f8 03                    
  1735 : vroundps     ymm8, ymm15, 0x003                 ; c4 43 7d 08 c7 03                    
  1736 : vroundpd     ymm0, ymm0, 0x003                  ; c4 e3 7d 09 c0 03                    
  1737 : vroundpd     ymm7, ymm0, 0x003                  ; c4 e3 7d 09 f8 03                    
  1738 : vroundpd     ymm0, ymm7, 0x003                  ; c4 e3 7d 09 c7 03                    
  1739 : vroundpd     ymm8, ymm0, 0x003                  ; c4 63 7d 09 c0 03                    
  1740 : vroundpd     ymm15, ymm0, 0x003                 ; c4 63 7d 09 f8 03                    
  1741 : vroundpd     ymm8, ymm7, 0x003                  ; c4 63 7d 09 c7 03                    
  1742 : vroundpd     ymm0, ymm8, 0x003                  ; c4 c3 7d 09 c0 03                    
  1743 : vroundpd     ymm7, ymm8, 0x003                  ; c4 c3 7d 09 f8 03                    
  1744 : vroundpd     ymm0, ymm15, 0x003                 ; c4 c3 7d 09 c7 03                    
  1745 : vroundpd     ymm8, ymm8, 0x003                  ; c4 43 7d 09 c0 03                    
  1746 : vroundpd     ymm15, ymm8, 0x003                 ; c4 43 7d 09 f8 03                    
  1747 : vroundpd     ymm8, ymm15, 0x003                 ; c4 43 7d 09 c7 03                    
  1748 : vcvtps2dq    ymm0, ymm0                         ; c5 fd 5b c0                          
  1749 : vcvtps2dq    ymm7, ymm0                         ; c5 fd 5b f8                          
  1750 : vcvtps2dq    ymm0, ymm7                         ; c5 fd 5b c7                          
  1751 : vcvtps2dq    ymm8, ymm0                         ; c5 7d 5b c0                          
  1752 : vcvtps2dq    ymm15, ymm0                        ; c5 7d 5b f8                          
  1753 : vcvtps2dq    ymm8, ymm7                         ; c5 7d 5b c7                          
  1754 : vcvtps2dq    ymm0, ymm8                         ; c4 c1 7d 5b c0                       
  1755 : vcvtps2dq    ymm7, ymm8                         ; c4 c1 7d 5b f8                       
  1756 : vcvtps2dq    ymm0, ymm15                        ; c4 c1 7d 5b c7                       
  1757 : vcvtps2dq    ymm8, ymm8                         ; c4 41 7d 5b c0                       
  1758 : vcvtps2dq    ymm15, ymm8                        ; c4 41 7d 5b f8                       
  1759 : vcvtps2dq    ymm8, ymm15                        ; c4 41 7d 5b c7                       
  1760 : vcvtpd2dq    xmm0, ymm0                         ; c5 ff e6 c0                          
  1761 : vcvtpd2dq    xmm7, ymm0                         ; c5 ff e6 f8                          
  1762 : vcvtpd2dq    xmm0, ymm7                         ; c5 ff e6 c7                          
  1763 : vcvtpd2dq    xmm8, ymm0                         ; c5 7f e6 c0                          
  1764 : vcvtpd2dq    xmm15, ymm0                        ; c5 7f e6 f8                          
  1765 : vcvtpd2dq    xmm8, ymm7                         ; c5 7f e6 c7                          
  1766 : vcvtpd2dq    xmm0, ymm8                         ; c4 c1 7f e6 c0                       
  1767 : vcvtpd2dq    xmm7, ymm8                         ; c4 c1 7f e6 f8                       
  1768 : vcvtpd2dq    xmm0, ymm15                        ; c4 c1 7f e6 c7                       
  1769 : vcvtpd2dq    xmm8, ymm8                         ; c4 41 7f e6 c0                       
  1770 : vcvtpd2dq    xmm15, ymm8                        ; c4 41 7f e6 f8                       
  1771 : vcvtpd2dq    xmm8, ymm15                        ; c4 41 7f e6 c7                       
  1772 : vcvtdq2ps    ymm0, ymm0                         ; c5 fc 5b c0                          
  1773 : vcvtdq2ps    ymm7, ymm0                         ; c5 fc 5b f8                          
  1774 : vcvtdq2ps    ymm0, ymm7                         ; c5 fc 5b c7                          
  1775 : vcvtdq2ps    ymm8, ymm0                         ; c5 7c 5b c0                          
  1776 : vcvtdq2ps    ymm15, ymm0                        ; c5 7c 5b f8                          
  1777 : vcvtdq2ps    ymm8, ymm7                         ; c5 7c 5b c7                          
  1778 : vcvtdq2ps    ymm0, ymm8                         ; c4 c1 7c 5b c0                       
  1779 : vcvtdq2ps    ymm7, ymm8                         ; c4 c1 7c 5b f8                       
  1780 : vcvtdq2ps    ymm0, ymm15                        ; c4 c1 7c 5b c7                       
  1781 : vcvtdq2ps    ymm8, ymm8                         ; c4 41 7c 5b c0                       
  1782 : vcvtdq2ps    ymm15, ymm8                        ; c4 41 7c 5b f8                       
  1783 : vcvtdq2ps    ymm8, ymm15                        ; c4 41 7c 5b c7                       
  1784 : vpmovsxbw    ymm0, xmm0                         ; c4 e2 7d 20 c0                       
  1785 : vpmovsxbw    ymm7, xmm0                         ; c4 e2 7d 20 f8                       
  1786 : vpmovsxbw    ymm0, xmm7                         ; c4 e2 7d 20 c7                       
  1787 : vpmovsxbw    ymm8, xmm0                         ; c4 62 7d 20 c0                       
  1788 : vpmovsxbw    ymm15, xmm0                        ; c4 62 7d 20 f8                       
  1789 : vpmovsxbw    ymm8, xmm7                         ; c4 62 7d 20 c7                       
  1790 : vpmovsxbw    ymm0, xmm8                         ; c4 c2 7d 20 c0                       
  1791 : vpmovsxbw    ymm7, xmm8                         ; c4 c2 7d 20 f8                       
  1792 : vpmovsxbw    ymm0, xmm15                        ; c4 c2 7d 20 c7                       
  1793 : vpmovsxbw    ymm8, xmm8                         ; c4 42 7d 20 c0                       
  1794 : vpmovsxbw    ymm15, xmm8                        ; c4 42 7d 20 f8                       
  1795 : vpmovsxbw    ymm8, xmm15                        ; c4 42 7d 20 c7                       
  1796 : vpmovsxwd    ymm0, xmm0                         ; c4 e2 7d 23 c0                       
  1797 : vpmovsxwd    ymm7, xmm0                         ; c4 e2 7d 23 f8                       
  1798 : vpmovsxwd    ymm0, xmm7                         ; c4 e2 7d 23 c7                       
  1799 : vpmovsxwd    ymm8, xmm0                         ; c4 62 7d 23 c0                       
  1800 : vpmovsxwd    ymm15, xmm0                        ; c4 62 7d 23 f8                       
  1801 : vpmovsxwd    ymm8, xmm7                         ; c4 62 7d 23 c7                       
  1802 : vpmovsxwd    ymm0, xmm8                         ; c4 c2 7d 23 c0                       
  1803 : vpmovsxwd    ymm7, xmm8                         ; c4 c2 7d 23 f8                       
  1804 : vpmovsxwd    ymm0, xmm15                        ; c4 c2 7d 23 c7                       
  1805 : vpmovsxwd    ymm8, xmm8                         ; c4 42 7d 23 c0                       
  1806 : vpmovsxwd    ymm15, xmm8                        ; c4 42 7d 23 f8                       
  1807 : vpmovsxwd    ymm8, xmm15                        ; c4 42 7d 23 c7                       
  1808 : vpmovsxdq    ymm0, xmm0                         ; c4 e2 7d 25 c0                       
  1809 : vpmovsxdq    ymm7, xmm0                         ; c4 e2 7d 25 f8                       
  1810 : vpmovsxdq    ymm0, xmm7                         ; c4 e2 7d 25 c7                       
  1811 : vpmovsxdq    ymm8, xmm0                         ; c4 62 7d 25 c0                       
  1812 : vpmovsxdq    ymm15, xmm0                        ; c4 62 7d 25 f8                       
  1813 : vpmovsxdq    ymm8, xmm7                         ; c4 62 7d 25 c7                       
  1814 : vpmovsxdq    ymm0, xmm8                         ; c4 c2 7d 25 c0                       
  1815 : vpmovsxdq    ymm7, xmm8                         ; c4 c2 7d 25 f8                       
  1816 : vpmovsxdq    ymm0, xmm15                        ; c4 c2 7d 25 c7                       
  1817 : vpmovsxdq    ymm8, xmm8                         ; c4 42 7d 25 c0                       
  1818 : vpmovsxdq    ymm15, xmm8                        ; c4 42 7d 25 f8                       
  1819 : vpmovsxdq    ymm8, xmm15                        ; c4 42 7d 25 c7                       
  1820 : vpmovzxbw    ymm0, xmm0                         ; c4 e2 7d 30 c0                       
  1821 : vpmovzxbw    ymm7, xmm0                         ; c4 e2 7d 30 f8                       
  1822 : vpmovzxbw    ymm0, xmm7                         ; c4 e2 7d 30 c7                       
  1823 : vpmovzxbw    ymm8, xmm0                         ; c4 62 7d 30 c0                       
  1824 : vpmovzxbw    ymm15, xmm0                        ; c4 62 7d 30 f8                       
  1825 : vpmovzxbw    ymm8, xmm7                         ; c4 62 7d 30 c7                       
  1826 : vpmovzxbw    ymm0, xmm8                         ; c4 c2 7d 30 c0                       
  1827 : vpmovzxbw    ymm7, xmm8                         ; c4 c2 7d 30 f8                       
  1828 : vpmovzxbw    ymm0, xmm15                        ; c4 c2 7d 30 c7                       
  1829 : vpmovzxbw    ymm8, xmm8                         ; c4 42 7d 30 c0                       
  1830 : vpmovzxbw    ymm15, xmm8                        ; c4 42 7d 30 f8                       
  1831 : vpmovzxbw    ymm8, xmm15                        ; c4 42 7d 30 c7                       
  1832 : vpmovzxwd    ymm0, xmm0                         ; c4 e2 7d 33 c0                       
  1833 : vpmovzxwd    ymm7, xmm0                         ; c4 e2 7d 33 f8                       
  1834 : vpmovzxwd    ymm0, xmm7                         ; c4 e2 7d 33 c7                       
  1835 : vpmovzxwd    ymm8, xmm0                         ; c4 62 7d 33 c0                       
  1836 : vpmovzxwd    ymm15, xmm0                        ; c4 62 7d 33 f8                       
  1837 : vpmovzxwd    ymm8, xmm7                         ; c4 62 7d 33 c7                       
  1838 : vpmovzxwd    ymm0, xmm8                         ; c4 c2 7d 33 c0                       
  1839 : vpmovzxwd    ymm7, xmm8                         ; c4 c2 7d 33 f8                       
  1840 : vpmovzxwd    ymm0, xmm15                        ; c4 c2 7d 33 c7                       
  1841 : vpmovzxwd    ymm8, xmm8                         ; c4 42 7d 33 c0                       
  1842 : vpmovzxwd    ymm15, xmm8                        ; c4 42 7d 33 f8                       
  1843 : vpmovzxwd    ymm8, xmm15                        ; c4 42 7d 33 c7                       
  1844 : vpmovzxdq    ymm0, xmm0                         ; c4 e2 7d 35 c0                       
  1845 : vpmovzxdq    ymm7, xmm0                         ; c4 e2 7d 35 f8                       
  1846 : vpmovzxdq    ymm0, xmm7                         ; c4 e2 7d 35 c7                       
  1847 : vpmovzxdq    ymm8, xmm0                         ; c4 62 7d 35 c0                       
  1848 : vpmovzxdq    ymm15, xmm0                        ; c4 62 7d 35 f8                       
  1849 : vpmovzxdq    ymm8, xmm7                         ; c4 62 7d 35 c7                       
  1850 : vpmovzxdq    ymm0, xmm8                         ; c4 c2 7d 35 c0                       
  1851 : vpmovzxdq    ymm7, xmm8                         ; c4 c2 7d 35 f8                       
  1852 : vpmovzxdq    ymm0, xmm15                        ; c4 c2 7d 35 c7                       
  1853 : vpmovzxdq    ymm8, xmm8                         ; c4 42 7d 35 c0                       
  1854 : vpmovzxdq    ymm15, xmm8                        ; c4 42 7d 35 f8                       
  1855 : vpmovzxdq    ymm8, xmm15                        ; c4 42 7d 35 c7                       
  1856 : vcvtps2pd    ymm0, xmm0                         ; c5 fc 5a c0                          
  1857 : vcvtps2pd    ymm7, xmm0                         ; c5 fc 5a f8                          
  1858 : vcvtps2pd    ymm0, xmm7                         ; c5 fc 5a c7                          
  1859 : vcvtps2pd    ymm8, xmm0                         ; c5 7c 5a c0                          
  1860 : vcvtps2pd    ymm15, xmm0                        ; c5 7c 5a f8                          
  1861 : vcvtps2pd    ymm8, xmm7                         ; c5 7c 5a c7                          
  1862 : vcvtps2pd    ymm0, xmm8                         ; c4 c1 7c 5a c0                       
  1863 : vcvtps2pd    ymm7, xmm8                         ; c4 c1 7c 5a f8                       
  1864 : vcvtps2pd    ymm0, xmm15                        ; c4 c1 7c 5a c7                       
  1865 : vcvtps2pd    ymm8, xmm8                         ; c4 41 7c 5a c0                       
  1866 : vcvtps2pd    ymm15, xmm8                        ; c4 41 7c 5a f8                       
  1867 : vcvtps2pd    ymm8, xmm15                        ; c4 41 7c 5a c7                       
  1868 : vpand        ymm0, ymm0, ymm0                   ; c5 fd db c0                          
  1869 : vpand        ymm7, ymm0, ymm0                   ; c5 fd db f8                          
  1870 : vpand        ymm0, ymm7, ymm0                   ; c5 c5 db c0                          
  1871 : vpand        ymm0, ymm0, ymm7                   ; c5 fd db c7                          
  1872 : vpand        ymm8, ymm0, ymm0                   ; c5 7d db c0                          
  1873 : vpand        ymm15, ymm0, ymm0                  ; c5 7d db f8                          
  1874 : vpand        ymm8, ymm7, ymm0                   ; c5 45 db c0                          
  1875 : vpand        ymm8, ymm0, ymm7                   ; c5 7d db c7                          
  1876 : vpand        ymm0, ymm8, ymm0                   ; c5 bd db c0                          
  1877 : vpand        ymm7, ymm8, ymm0                   ; c5 bd db f8                          
  1878 : vpand        ymm0, ymm15, ymm0                  ; c5 85 db c0                          
  1879 : vpand        ymm0, ymm8, ymm7                   ; c5 bd db c7                          
  1880 : vpand        ymm0, ymm0, ymm8                   ; c4 c1 7d db c0                       
  1881 : vpand        ymm7, ymm0, ymm8                   ; c4 c1 7d db f8                       
  1882 : vpand        ymm0, ymm7, ymm8                   ; c4 c1 45 db c0                       
  1883 : vpand        ymm0, ymm0, ymm15                  ; c4 c1 7d db c7                       
  1884 : vpor         ymm0, ymm0, ymm0                   ; c5 fd eb c0                          
  1885 : vpor         ymm7, ymm0, ymm0                   ; c5 fd eb f8                          
  1886 : vpor         ymm0, ymm7, ymm0                   ; c5 c5 eb c0                          
  1887 : vpor         ymm0, ymm0, ymm7                   ; c5 fd eb c7                          
  1888 : vpor         ymm8, ymm0, ymm0                   ; c5 7d eb c0                          
  1889 : vpor         ymm15, ymm0, ymm0                  ; c5 7d eb f8                          
  1890 : vpor         ymm8, ymm7, ymm0                   ; c5 45 eb c0                          
  1891 : vpor         ymm8, ymm0, ymm7                   ; c5 7d eb c7                          
  1892 : vpor         ymm0, ymm8, ymm0                   ; c5 bd eb c0                          
  1893 : vpor         ymm7, ymm8, ymm0                   ; c5 bd eb f8                          
  1894 : vpor         ymm0, ymm15, ymm0                  ; c5 85 eb c0                          
  1895 : vpor         ymm0, ymm8, ymm7                   ; c5 bd eb c7                          
  1896 : vpor         ymm0, ymm0, ymm8                   ; c4 c1 7d eb c0                       
  1897 : vpor         ymm7, ymm0, ymm8                   ; c4 c1 7d eb f8                       
  1898 : vpor         ymm0, ymm7, ymm8                   ; c4 c1 45 eb c0                       
  1899 : vpor         ymm0, ymm0, ymm15                  ; c4 c1 7d eb c7                       
  1900 : vpxor        ymm0, ymm0, ymm0                   ; c5 fd ef c0                          
  1901 : vpxor        ymm7, ymm0, ymm0                   ; c5 fd ef f8                          
  1902 : vpxor        ymm0, ymm7, ymm0                   ; c5 c5 ef c0                          
  1903 : vpxor        ymm0, ymm0, ymm7                   ; c5 fd ef c7                          
  1904 : vpxor        ymm8, ymm0, ymm0                   ; c5 7d ef c0                          
  1905 : vpxor        ymm15, ymm0, ymm0                  ; c5 7d ef f8                          
  1906 : vpxor        ymm8, ymm7, ymm0                   ; c5 45 ef c0                          
  1907 : vpxor        ymm8, ymm0, ymm7                   ; c5 7d ef c7                          
  1908 : vpxor        ymm0, ymm8, ymm0                   ; c5 bd ef c0                          
  1909 : vpxor        ymm7, ymm8, ymm0                   ; c5 bd ef f8                          
  1910 : vpxor        ymm0, ymm15, ymm0                  ; c5 85 ef c0                          
  1911 : vpxor        ymm0, ymm8, ymm7                   ; c5 bd ef c7                          
  1912 : vpxor        ymm0, ymm0, ymm8                   ; c4 c1 7d ef c0                       
  1913 : vpxor        ymm7, ymm0, ymm8                   ; c4 c1 7d ef f8                       
  1914 : vpxor        ymm0, ymm7, ymm8                   ; c4 c1 45 ef c0                       
  1915 : vpxor        ymm0, ymm0, ymm15                  ; c4 c1 7d ef c7                       
  1916 : vpsllw       ymm0, ymm0, 0x00f                  ; c5 fd 71 f0 0f                       
  1917 : vpsllw       ymm7, ymm0, 0x00f                  ; c5 c5 71 f0 0f                       
  1918 : vpsllw       ymm0, ymm7, 0x00f                  ; c5 fd 71 f7 0f                       
  1919 : vpsllw       ymm8, ymm0, 0x00f                  ; c5 bd 71 f0 0f                       
  1920 : vpsllw       ymm15, ymm0, 0x00f                 ; c5 85 71 f0 0f                       
  1921 : vpsllw       ymm8, ymm7, 0x00f                  ; c5 bd 71 f7 0f                       
  1922 : vpsllw       ymm0, ymm8, 0x00f                  ; c4 c1 7d 71 f0 0f                    
  1923 : vpsllw       ymm7, ymm8, 0x00f                  ; c4 c1 45 71 f0 0f                    
  1924 : vpsllw       ymm0, ymm15, 0x00f                 ; c4 c1 7d 71 f7 0f                    
  1925 : vpsllw       ymm8, ymm8, 0x00f                  ; c4 c1 3d 71 f0 0f                    
  1926 : vpsllw       ymm15, ymm8, 0x00f                 ; c4 c1 05 71 f0 0f                    
  1927 : vpsllw       ymm8, ymm15, 0x00f                 ; c4 c1 3d 71 f7 0f                    
  1928 : vpslld       ymm0, ymm0, 0x00f                  ; c5 fd 72 f0 0f                       
  1929 : vpslld       ymm7, ymm0, 0x00f                  ; c5 c5 72 f0 0f                       
  1930 : vpslld       ymm0, ymm7, 0x00f                  ; c5 fd 72 f7 0f                       
  1931 : vpslld       ymm8, ymm0, 0x00f                  ; c5 bd 72 f0 0f                       
  1932 : vpslld       ymm15, ymm0, 0x00f                 ; c5 85 72 f0 0f                       
  1933 : vpslld       ymm8, ymm7, 0x00f                  ; c5 bd 72 f7 0f                       
  1934 : vpslld       ymm0, ymm8, 0x00f                  ; c4 c1 7d 72 f0 0f                    
  1935 : vpslld       ymm7, ymm8, 0x00f                  ; c4 c1 45 72 f0 0f                    
  1936 : vpslld       ymm0, ymm15, 0x00f                 ; c4 c1 7d 72 f7 0f                    
  1937 : vpslld       ymm8, ymm8, 0x00f                  ; c4 c1 3d 72 f0 0f                    
  1938 : vpslld       ymm15, ymm8, 0x00f                 ; c4 c1 05 72 f0 0f                    
  1939 : vpslld       ymm8, ymm15, 0x00f                 ; c4 c1 3d 72 f7 0f                    
  1940 : vpsllq       ymm0, ymm0, 0x00f                  ; c5 fd 73 f0 0f                       
  1941 : vpsllq       ymm7, ymm0, 0x00f                  ; c5 c5 73 f0 0f                       
  1942 : vpsllq       ymm0, ymm7, 0x00f                  ; c5 fd 73 f7 0f                       
  1943 : vpsllq       ymm8, ymm0, 0x00f                  ; c5 bd 73 f0 0f                       
  1944 : vpsllq       ymm15, ymm0, 0x00f                 ; c5 85 73 f0 0f                       
  1945 : vpsllq       ymm8, ymm7, 0x00f                  ; c5 bd 73 f7 0f                       
  1946 : vpsllq       ymm0, ymm8, 0x00f                  ; c4 c1 7d 73 f0 0f                    
  1947 : vpsllq       ymm7, ymm8, 0x00f                  ; c4 c1 45 73 f0 0f                    
  1948 : vpsllq       ymm0, ymm15, 0x00f                 ; c4 c1 7d 73 f7 0f                    
  1949 : vpsllq       ymm8, ymm8, 0x00f                  ; c4 c1 3d 73 f0 0f                    
  1950 : vpsllq       ymm15, ymm8, 0x00f                 ; c4 c1 05 73 f0 0f                    
  1951 : vpsllq       ymm8, ymm15, 0x00f                 ; c4 c1 3d 73 f7 0f                    
  1952 : vpsllvd      ymm0, ymm0, ymm0                   ; c4 e2 7d 47 c0                       
  1953 : vpsllvd      ymm7, ymm0, ymm0                   ; c4 e2 7d 47 f8                       
  1954 : vpsllvd      ymm0, ymm7, ymm0                   ; c4 e2 45 47 c0                       
  1955 : vpsllvd      ymm0, ymm0, ymm7                   ; c4 e2 7d 47 c7                       
  1956 : vpsllvd      ymm8, ymm0, ymm0                   ; c4 62 7d 47 c0                       
  1957 : vpsllvd      ymm15, ymm0, ymm0                  ; c4 62 7d 47 f8                       
  1958 : vpsllvd      ymm8, ymm7, ymm0                   ; c4 62 45 47 c0                       
  1959 : vpsllvd      ymm8, ymm0, ymm7                   ; c4 62 7d 47 c7                       
  1960 : vpsllvd      ymm0, ymm8, ymm0                   ; c4 e2 3d 47 c0                       
  1961 : vpsllvd      ymm7, ymm8, ymm0                   ; c4 e2 3d 47 f8                       
  1962 : vpsllvd      ymm0, ymm15, ymm0                  ; c4 e2 05 47 c0                       
  1963 : vpsllvd      ymm0, ymm8, ymm7                   ; c4 e2 3d 47 c7                       
  1964 : vpsllvd      ymm0, ymm0, ymm8                   ; c4 c2 7d 47 c0                       
  1965 : vpsllvd      ymm7, ymm0, ymm8                   ; c4 c2 7d 47 f8                       
  1966 : vpsllvd      ymm0, ymm7, ymm8                   ; c4 c2 45 47 c0                       
  1967 : vpsllvd      ymm0, ymm0, ymm15                  ; c4 c2 7d 47 c7                       
  1968 : vpsllvq      ymm0, ymm0, ymm0                   ; c4 e2 fd 47 c0                       
  1969 : vpsllvq      ymm7, ymm0, ymm0                   ; c4 e2 fd 47 f8                       
  1970 : vpsllvq      ymm0, ymm7, ymm0                   ; c4 e2 c5 47 c0                       
  1971 : vpsllvq      ymm0, ymm0, ymm7                   ; c4 e2 fd 47 c7                       
  1972 : vpsllvq      ymm8, ymm0, ymm0                   ; c4 62 fd 47 c0                       
  1973 : vpsllvq      ymm15, ymm0, ymm0                  ; c4 62 fd 47 f8                       
  1974 : vpsllvq      ymm8, ymm7, ymm0                   ; c4 62 c5 47 c0                       
  1975 : vpsllvq      ymm8, ymm0, ymm7                   ; c4 62 fd 47 c7                       
  1976 : vpsllvq      ymm0, ymm8, ymm0                   ; c4 e2 bd 47 c0                       
  1977 : vpsllvq      ymm7, ymm8, ymm0                   ; c4 e2 bd 47 f8                       
  1978 : vpsllvq      ymm0, ymm15, ymm0                  ; c4 e2 85 47 c0                       
  1979 : vpsllvq      ymm0, ymm8, ymm7                   ; c4 e2 bd 47 c7                       
  1980 : vpsllvq      ymm0, ymm0, ymm8                   ; c4 c2 fd 47 c0                       
  1981 : vpsllvq      ymm7, ymm0, ymm8                   ; c4 c2 fd 47 f8                       
  1982 : vpsllvq      ymm0, ymm7, ymm8                   ; c4 c2 c5 47 c0                       
  1983 : vpsllvq      ymm0, ymm0, ymm15                  ; c4 c2 fd 47 c7                       
  1984 : vpsraw       ymm0, ymm0, 0x00f                  ; c5 fd 71 e0 0f                       
  1985 : vpsraw       ymm7, ymm0, 0x00f                  ; c5 c5 71 e0 0f                       
  1986 : vpsraw       ymm0, ymm7, 0x00f                  ; c5 fd 71 e7 0f                       
  1987 : vpsraw       ymm8, ymm0, 0x00f                  ; c5 bd 71 e0 0f                       
  1988 : vpsraw       ymm15, ymm0, 0x00f                 ; c5 85 71 e0 0f                       
  1989 : vpsraw       ymm8, ymm7, 0x00f                  ; c5 bd 71 e7 0f                       
  1990 : vpsraw       ymm0, ymm8, 0x00f                  ; c4 c1 7d 71 e0 0f                    
  1991 : vpsraw       ymm7, ymm8, 0x00f                  ; c4 c1 45 71 e0 0f                    
  1992 : vpsraw       ymm0, ymm15, 0x00f                 ; c4 c1 7d 71 e7 0f                    
  1993 : vpsraw       ymm8, ymm8, 0x00f                  ; c4 c1 3d 71 e0 0f                    
  1994 : vpsraw       ymm15, ymm8, 0x00f                 ; c4 c1 05 71 e0 0f                    
  1995 : vpsraw       ymm8, ymm15, 0x00f                 ; c4 c1 3d 71 e7 0f                    
  1996 : vpsrad       ymm0, ymm0, 0x00f                  ; c5 fd 72 e0 0f                       
  1997 : vpsrad       ymm7, ymm0, 0x00f                  ; c5 c5 72 e0 0f                       
  1998 : vpsrad       ymm0, ymm7, 0x00f                  ; c5 fd 72 e7 0f                       
  1999 : vpsrad       ymm8, ymm0, 0x00f                  ; c5 bd 72 e0 0f                       
  2000 : vpsrad       ymm15, ymm0, 0x00f                 ; c5 85 72 e0 0f                       
  2001 : vpsrad       ymm8, ymm7, 0x00f                  ; c5 bd 72 e7 0f                       
  2002 : vpsrad       ymm0, ymm8, 0x00f                  ; c4 c1 7d 72 e0 0f                    
  2003 : vpsrad       ymm7, ymm8, 0x00f                  ; c4 c1 45 72 e0 0f                    
  2004 : vpsrad       ymm0, ymm15, 0x00f                 ; c4 c1 7d 72 e7 0f                    
  2005 : vpsrad       ymm8, ymm8, 0x00f                  ; c4 c1 3d 72 e0 0f                    
  2006 : vpsrad       ymm15, ymm8, 0x00f                 ; c4 c1 05 72 e0 0f                    
  2007 : vpsrad       ymm8, ymm15, 0x00f                 ; c4 c1 3d 72 e7 0f                    
  2008 : vpsravd      ymm0, ymm0, ymm0                   ; c4 e2 7d 46 c0                       
  2009 : vpsravd      ymm7, ymm0, ymm0                   ; c4 e2 7d 46 f8                       
  2010 : vpsravd      ymm0, ymm7, ymm0                   ; c4 e2 45 46 c0                       
  2011 : vpsravd      ymm0, ymm0, ymm7                   ; c4 e2 7d 46 c7                       
  2012 : vpsravd      ymm8, ymm0, ymm0                   ; c4 62 7d 46 c0                       
  2013 : vpsravd      ymm15, ymm0, ymm0                  ; c4 62 7d 46 f8                       
  2014 : vpsravd      ymm8, ymm7, ymm0                   ; c4 62 45 46 c0                       
  2015 : vpsravd      ymm8, ymm0, ymm7                   ; c4 62 7d 46 c7                       
  2016 : vpsravd      ymm0, ymm8, ymm0                   ; c4 e2 3d 46 c0                       
  2017 : vpsravd      ymm7, ymm8, ymm0                   ; c4 e2 3d 46 f8                       
  2018 : vpsravd      ymm0, ymm15, ymm0                  ; c4 e2 05 46 c0                       
  2019 : vpsravd      ymm0, ymm8, ymm7                   ; c4 e2 3d 46 c7                       
  2020 : vpsravd      ymm0, ymm0, ymm8                   ; c4 c2 7d 46 c0                       
  2021 : vpsravd      ymm7, ymm0, ymm8                   ; c4 c2 7d 46 f8                       
  2022 : vpsravd      ymm0, ymm7, ymm8                   ; c4 c2 45 46 c0                       
  2023 : vpsravd      ymm0, ymm0, ymm15                  ; c4 c2 7d 46 c7                       
  2024 : vpsrlw       ymm0, ymm0, 0x00f                  ; c5 fd 71 d0 0f                       
  2025 : vpsrlw       ymm7, ymm0, 0x00f                  ; c5 c5 71 d0 0f                       
  2026 : vpsrlw       ymm0, ymm7, 0x00f                  ; c5 fd 71 d7 0f                       
  2027 : vpsrlw       ymm8, ymm0, 0x00f                  ; c5 bd 71 d0 0f                       
  2028 : vpsrlw       ymm15, ymm0, 0x00f                 ; c5 85 71 d0 0f                       
  2029 : vpsrlw       ymm8, ymm7, 0x00f                  ; c5 bd 71 d7 0f                       
  2030 : vpsrlw       ymm0, ymm8, 0x00f                  ; c4 c1 7d 71 d0 0f                    
  2031 : vpsrlw       ymm7, ymm8, 0x00f                  ; c4 c1 45 71 d0 0f                    
  2032 : vpsrlw       ymm0, ymm15, 0x00f                 ; c4 c1 7d 71 d7 0f                    
  2033 : vpsrlw       ymm8, ymm8, 0x00f                  ; c4 c1 3d 71 d0 0f                    
  2034 : vpsrlw       ymm15, ymm8, 0x00f                 ; c4 c1 05 71 d0 0f                    
  2035 : vpsrlw       ymm8, ymm15, 0x00f                 ; c4 c1 3d 71 d7 0f                    
  2036 : vpsrld       ymm0, ymm0, 0x00f                  ; c5 fd 72 d0 0f                       
  2037 : vpsrld       ymm7, ymm0, 0x00f                  ; c5 c5 72 d0 0f                       
  2038 : vpsrld       ymm0, ymm7, 0x00f                  ; c5 fd 72 d7 0f                       
  2039 : vpsrld       ymm8, ymm0, 0x00f                  ; c5 bd 72 d0 0f                       
  2040 : vpsrld       ymm15, ymm0, 0x00f                 ; c5 85 72 d0 0f                       
  2041 : vpsrld       ymm8, ymm7, 0x00f                  ; c5 bd 72 d7 0f                       
  2042 : vpsrld       ymm0, ymm8, 0x00f                  ; c4 c1 7d 72 d0 0f                    
  2043 : vpsrld       ymm7, ymm8, 0x00f                  ; c4 c1 45 72 d0 0f                    
  2044 : vpsrld       ymm0, ymm15, 0x00f                 ; c4 c1 7d 72 d7 0f                    
  2045 : vpsrld       ymm8, ymm8, 0x00f                  ; c4 c1 3d 72 d0 0f                    
  2046 : vpsrld       ymm15, ymm8, 0x00f                 ; c4 c1 05 72 d0 0f                    
  2047 : vpsrld       ymm8, ymm15, 0x00f                 ; c4 c1 3d 72 d7 0f                    
  2048 : vpsrlq       ymm0, ymm0, 0x00f                  ; c5 fd 73 d0 0f                       
  2049 : vpsrlq       ymm7, ymm0, 0x00f                  ; c5 c5 73 d0 0f                       
  2050 : vpsrlq       ymm0, ymm7, 0x00f                  ; c5 fd 73 d7 0f                       
  2051 : vpsrlq       ymm8, ymm0, 0x00f                  ; c5 bd 73 d0 0f                       
  2052 : vpsrlq       ymm15, ymm0, 0x00f                 ; c5 85 73 d0 0f                       
  2053 : vpsrlq       ymm8, ymm7, 0x00f                  ; c5 bd 73 d7 0f                       
  2054 : vpsrlq       ymm0, ymm8, 0x00f                  ; c4 c1 7d 73 d0 0f                    
  2055 : vpsrlq       ymm7, ymm8, 0x00f                  ; c4 c1 45 73 d0 0f                    
  2056 : vpsrlq       ymm0, ymm15, 0x00f                 ; c4 c1 7d 73 d7 0f                    
  2057 : vpsrlq       ymm8, ymm8, 0x00f                  ; c4 c1 3d 73 d0 0f                    
  2058 : vpsrlq       ymm15, ymm8, 0x00f                 ; c4 c1 05 73 d0 0f                    
  2059 : vpsrlq       ymm8, ymm15, 0x00f                 ; c4 c1 3d 73 d7 0f                    
  2060 : vpsrlvd      ymm0, ymm0, ymm0                   ; c4 e2 7d 45 c0                       
  2061 : vpsrlvd      ymm7, ymm0, ymm0                   ; c4 e2 7d 45 f8                       
  2062 : vpsrlvd      ymm0, ymm7, ymm0                   ; c4 e2 45 45 c0                       
  2063 : vpsrlvd      ymm0, ymm0, ymm7                   ; c4 e2 7d 45 c7                       
  2064 : vpsrlvd      ymm8, ymm0, ymm0                   ; c4 62 7d 45 c0                       
  2065 : vpsrlvd      ymm15, ymm0, ymm0                  ; c4 62 7d 45 f8                       
  2066 : vpsrlvd      ymm8, ymm7, ymm0                   ; c4 62 45 45 c0                       
  2067 : vpsrlvd      ymm8, ymm0, ymm7                   ; c4 62 7d 45 c7                       
  2068 : vpsrlvd      ymm0, ymm8, ymm0                   ; c4 e2 3d 45 c0                       
  2069 : vpsrlvd      ymm7, ymm8, ymm0                   ; c4 e2 3d 45 f8                       
  2070 : vpsrlvd      ymm0, ymm15, ymm0                  ; c4 e2 05 45 c0                       
  2071 : vpsrlvd      ymm0, ymm8, ymm7                   ; c4 e2 3d 45 c7                       
  2072 : vpsrlvd      ymm0, ymm0, ymm8                   ; c4 c2 7d 45 c0                       
  2073 : vpsrlvd      ymm7, ymm0, ymm8                   ; c4 c2 7d 45 f8                       
  2074 : vpsrlvd      ymm0, ymm7, ymm8                   ; c4 c2 45 45 c0                       
  2075 : vpsrlvd      ymm0, ymm0, ymm15                  ; c4 c2 7d 45 c7                       
  2076 : vpsrlvq      ymm0, ymm0, ymm0                   ; c4 e2 fd 45 c0                       
  2077 : vpsrlvq      ymm7, ymm0, ymm0                   ; c4 e2 fd 45 f8                       
  2078 : vpsrlvq      ymm0, ymm7, ymm0                   ; c4 e2 c5 45 c0                       
  2079 : vpsrlvq      ymm0, ymm0, ymm7                   ; c4 e2 fd 45 c7                       
  2080 : vpsrlvq      ymm8, ymm0, ymm0                   ; c4 62 fd 45 c0                       
  2081 : vpsrlvq      ymm15, ymm0, ymm0                  ; c4 62 fd 45 f8                       
  2082 : vpsrlvq      ymm8, ymm7, ymm0                   ; c4 62 c5 45 c0                       
  2083 : vpsrlvq      ymm8, ymm0, ymm7                   ; c4 62 fd 45 c7                       
  2084 : vpsrlvq      ymm0, ymm8, ymm0                   ; c4 e2 bd 45 c0                       
  2085 : vpsrlvq      ymm7, ymm8, ymm0                   ; c4 e2 bd 45 f8                       
  2086 : vpsrlvq      ymm0, ymm15, ymm0                  ; c4 e2 85 45 c0                       
  2087 : vpsrlvq      ymm0, ymm8, ymm7                   ; c4 e2 bd 45 c7                       
  2088 : vpsrlvq      ymm0, ymm0, ymm8                   ; c4 c2 fd 45 c0                       
  2089 : vpsrlvq      ymm7, ymm0, ymm8                   ; c4 c2 fd 45 f8                       
  2090 : vpsrlvq      ymm0, ymm7, ymm8                   ; c4 c2 c5 45 c0                       
  2091 : vpsrlvq      ymm0, ymm0, ymm15                  ; c4 c2 fd 45 c7                       
  2092 : vpcmpeqb     ymm0, ymm0, ymm0                   ; c5 fd 74 c0                          
  2093 : vpcmpeqb     ymm7, ymm0, ymm0                   ; c5 fd 74 f8                          
  2094 : vpcmpeqb     ymm0, ymm7, ymm0                   ; c5 c5 74 c0                          
  2095 : vpcmpeqb     ymm0, ymm0, ymm7                   ; c5 fd 74 c7                          
  2096 : vpcmpeqb     ymm8, ymm0, ymm0                   ; c5 7d 74 c0                          
  2097 : vpcmpeqb     ymm15, ymm0, ymm0                  ; c5 7d 74 f8                          
  2098 : vpcmpeqb     ymm8, ymm7, ymm0                   ; c5 45 74 c0                          
  2099 : vpcmpeqb     ymm8, ymm0, ymm7                   ; c5 7d 74 c7                          
  2100 : vpcmpeqb     ymm0, ymm8, ymm0                   ; c5 bd 74 c0                          
  2101 : vpcmpeqb     ymm7, ymm8, ymm0                   ; c5 bd 74 f8                          
  2102 : vpcmpeqb     ymm0, ymm15, ymm0                  ; c5 85 74 c0                          
  2103 : vpcmpeqb     ymm0, ymm8, ymm7                   ; c5 bd 74 c7                          
  2104 : vpcmpeqb     ymm0, ymm0, ymm8                   ; c4 c1 7d 74 c0                       
  2105 : vpcmpeqb     ymm7, ymm0, ymm8                   ; c4 c1 7d 74 f8                       
  2106 : vpcmpeqb     ymm0, ymm7, ymm8                   ; c4 c1 45 74 c0                       
  2107 : vpcmpeqb     ymm0, ymm0, ymm15                  ; c4 c1 7d 74 c7                       
  2108 : vpcmpeqw     ymm0, ymm0, ymm0                   ; c5 fd 75 c0                          
  2109 : vpcmpeqw     ymm7, ymm0, ymm0                   ; c5 fd 75 f8                          
  2110 : vpcmpeqw     ymm0, ymm7, ymm0                   ; c5 c5 75 c0                          
  2111 : vpcmpeqw     ymm0, ymm0, ymm7                   ; c5 fd 75 c7                          
  2112 : vpcmpeqw     ymm8, ymm0, ymm0                   ; c5 7d 75 c0                          
  2113 : vpcmpeqw     ymm15, ymm0, ymm0                  ; c5 7d 75 f8                          
  2114 : vpcmpeqw     ymm8, ymm7, ymm0                   ; c5 45 75 c0                          
  2115 : vpcmpeqw     ymm8, ymm0, ymm7                   ; c5 7d 75 c7                          
  2116 : vpcmpeqw     ymm0, ymm8, ymm0                   ; c5 bd 75 c0                          
  2117 : vpcmpeqw     ymm7, ymm8, ymm0                   ; c5 bd 75 f8                          
  2118 : vpcmpeqw     ymm0, ymm15, ymm0                  ; c5 85 75 c0                          
  2119 : vpcmpeqw     ymm0, ymm8, ymm7                   ; c5 bd 75 c7                          
  2120 : vpcmpeqw     ymm0, ymm0, ymm8                   ; c4 c1 7d 75 c0                       
  2121 : vpcmpeqw     ymm7, ymm0, ymm8                   ; c4 c1 7d 75 f8                       
  2122 : vpcmpeqw     ymm0, ymm7, ymm8                   ; c4 c1 45 75 c0                       
  2123 : vpcmpeqw     ymm0, ymm0, ymm15                  ; c4 c1 7d 75 c7                       
  2124 : vpcmpeqd     ymm0, ymm0, ymm0                   ; c5 fd 76 c0                          
  2125 : vpcmpeqd     ymm7, ymm0, ymm0                   ; c5 fd 76 f8                          
  2126 : vpcmpeqd     ymm0, ymm7, ymm0                   ; c5 c5 76 c0                          
  2127 : vpcmpeqd     ymm0, ymm0, ymm7                   ; c5 fd 76 c7                          
  2128 : vpcmpeqd     ymm8, ymm0, ymm0                   ; c5 7d 76 c0                          
  2129 : vpcmpeqd     ymm15, ymm0, ymm0                  ; c5 7d 76 f8                          
  2130 : vpcmpeqd     ymm8, ymm7, ymm0                   ; c5 45 76 c0                          
  2131 : vpcmpeqd     ymm8, ymm0, ymm7                   ; c5 7d 76 c7                          
  2132 : vpcmpeqd     ymm0, ymm8, ymm0                   ; c5 bd 76 c0                          
  2133 : vpcmpeqd     ymm7, ymm8, ymm0                   ; c5 bd 76 f8                          
  2134 : vpcmpeqd     ymm0, ymm15, ymm0                  ; c5 85 76 c0                          
  2135 : vpcmpeqd     ymm0, ymm8, ymm7                   ; c5 bd 76 c7                          
  2136 : vpcmpeqd     ymm0, ymm0, ymm8                   ; c4 c1 7d 76 c0                       
  2137 : vpcmpeqd     ymm7, ymm0, ymm8                   ; c4 c1 7d 76 f8                       
  2138 : vpcmpeqd     ymm0, ymm7, ymm8                   ; c4 c1 45 76 c0                       
  2139 : vpcmpeqd     ymm0, ymm0, ymm15                  ; c4 c1 7d 76 c7                       
  2140 : vpcmpeqq     ymm0, ymm0, ymm0                   ; c4 e2 7d 29 c0                       
  2141 : vpcmpeqq     ymm7, ymm0, ymm0                   ; c4 e2 7d 29 f8                       
  2142 : vpcmpeqq     ymm0, ymm7, ymm0                   ; c4 e2 45 29 c0                       
  2143 : vpcmpeqq     ymm0, ymm0, ymm7                   ; c4 e2 7d 29 c7                       
  2144 : vpcmpeqq     ymm8, ymm0, ymm0                   ; c4 62 7d 29 c0                       
  2145 : vpcmpeqq     ymm15, ymm0, ymm0                  ; c4 62 7d 29 f8                       
  2146 : vpcmpeqq     ymm8, ymm7, ymm0                   ; c4 62 45 29 c0                       
  2147 : vpcmpeqq     ymm8, ymm0, ymm7                   ; c4 62 7d 29 c7                       
  2148 : vpcmpeqq     ymm0, ymm8, ymm0                   ; c4 e2 3d 29 c0                       
  2149 : vpcmpeqq     ymm7, ymm8, ymm0                   ; c4 e2 3d 29 f8                       
  2150 : vpcmpeqq     ymm0, ymm15, ymm0                  ; c4 e2 05 29 c0                       
  2151 : vpcmpeqq     ymm0, ymm8, ymm7                   ; c4 e2 3d 29 c7                       
  2152 : vpcmpeqq     ymm0, ymm0, ymm8                   ; c4 c2 7d 29 c0                       
  2153 : vpcmpeqq     ymm7, ymm0, ymm8                   ; c4 c2 7d 29 f8                       
  2154 : vpcmpeqq     ymm0, ymm7, ymm8                   ; c4 c2 45 29 c0                       
  2155 : vpcmpeqq     ymm0, ymm0, ymm15                  ; c4 c2 7d 29 c7                       
  2156 : vcmpeqps     ymm0, ymm0, ymm0                   ; c5 fc c2 c0 00                       
  2157 : vcmpeqps     ymm7, ymm0, ymm0                   ; c5 fc c2 f8 00                       
  2158 : vcmpeqps     ymm0, ymm7, ymm0                   ; c5 c4 c2 c0 00                       
  2159 : vcmpeqps     ymm0, ymm0, ymm7                   ; c5 fc c2 c7 00                       
  2160 : vcmpeqps     ymm8, ymm0, ymm0                   ; c5 7c c2 c0 00                       
  2161 : vcmpeqps     ymm15, ymm0, ymm0                  ; c5 7c c2 f8 00                       
  2162 : vcmpeqps     ymm8, ymm7, ymm0                   ; c5 44 c2 c0 00                       
  2163 : vcmpeqps     ymm8, ymm0, ymm7                   ; c5 7c c2 c7 00                       
  2164 : vcmpeqps     ymm0, ymm8, ymm0                   ; c5 bc c2 c0 00                       
  2165 : vcmpeqps     ymm7, ymm8, ymm0                   ; c5 bc c2 f8 00                       
  2166 : vcmpeqps     ymm0, ymm15, ymm0                  ; c5 84 c2 c0 00                       
  2167 : vcmpeqps     ymm0, ymm8, ymm7                   ; c5 bc c2 c7 00                       
  2168 : vcmpeqps     ymm0, ymm0, ymm8                   ; c4 c1 7c c2 c0 00                    
  2169 : vcmpeqps     ymm7, ymm0, ymm8                   ; c4 c1 7c c2 f8 00                    
  2170 : vcmpeqps     ymm0, ymm7, ymm8                   ; c4 c1 44 c2 c0 00                    
  2171 : vcmpeqps     ymm0, ymm0, ymm15                  ; c4 c1 7c c2 c7 00                    
  2172 : vcmpeqpd     ymm0, ymm0, ymm0                   ; c5 fd c2 c0 00                       
  2173 : vcmpeqpd     ymm7, ymm0, ymm0                   ; c5 fd c2 f8 00                       
  2174 : vcmpeqpd     ymm0, ymm7, ymm0                   ; c5 c5 c2 c0 00                       
  2175 : vcmpeqpd     ymm0, ymm0, ymm7                   ; c5 fd c2 c7 00                       
  2176 : vcmpeqpd     ymm8, ymm0, ymm0                   ; c5 7d c2 c0 00                       
  2177 : vcmpeqpd     ymm15, ymm0, ymm0                  ; c5 7d c2 f8 00                       
  2178 : vcmpeqpd     ymm8, ymm7, ymm0                   ; c5 45 c2 c0 00                       
  2179 : vcmpeqpd     ymm8, ymm0, ymm7                   ; c5 7d c2 c7 00                       
  2180 : vcmpeqpd     ymm0, ymm8, ymm0                   ; c5 bd c2 c0 00                       
  2181 : vcmpeqpd     ymm7, ymm8, ymm0                   ; c5 bd c2 f8 00                       
  2182 : vcmpeqpd     ymm0, ymm15, ymm0                  ; c5 85 c2 c0 00                       
  2183 : vcmpeqpd     ymm0, ymm8, ymm7                   ; c5 bd c2 c7 00                       
  2184 : vcmpeqpd     ymm0, ymm0, ymm8                   ; c4 c1 7d c2 c0 00                    
  2185 : vcmpeqpd     ymm7, ymm0, ymm8                   ; c4 c1 7d c2 f8 00                    
  2186 : vcmpeqpd     ymm0, ymm7, ymm8                   ; c4 c1 45 c2 c0 00                    
  2187 : vcmpeqpd     ymm0, ymm0, ymm15                  ; c4 c1 7d c2 c7 00                    
  2188 : vcmpneqps    ymm0, ymm0, ymm0                   ; c5 fc c2 c0 04                       
  2189 : vcmpneqps    ymm7, ymm0, ymm0                   ; c5 fc c2 f8 04                       
  2190 : vcmpneqps    ymm0, ymm7, ymm0                   ; c5 c4 c2 c0 04                       
  2191 : vcmpneqps    ymm0, ymm0, ymm7                   ; c5 fc c2 c7 04                       
  2192 : vcmpneqps    ymm8, ymm0, ymm0                   ; c5 7c c2 c0 04                       
  2193 : vcmpneqps    ymm15, ymm0, ymm0                  ; c5 7c c2 f8 04                       
  2194 : vcmpneqps    ymm8, ymm7, ymm0                   ; c5 44 c2 c0 04                       
  2195 : vcmpneqps    ymm8, ymm0, ymm7                   ; c5 7c c2 c7 04                       
  2196 : vcmpneqps    ymm0, ymm8, ymm0                   ; c5 bc c2 c0 04                       
  2197 : vcmpneqps    ymm7, ymm8, ymm0                   ; c5 bc c2 f8 04                       
  2198 : vcmpneqps    ymm0, ymm15, ymm0                  ; c5 84 c2 c0 04                       
  2199 : vcmpneqps    ymm0, ymm8, ymm7                   ; c5 bc c2 c7 04                       
  2200 : vcmpneqps    ymm0, ymm0, ymm8                   ; c4 c1 7c c2 c0 04                    
  2201 : vcmpneqps    ymm7, ymm0, ymm8                   ; c4 c1 7c c2 f8 04                    
  2202 : vcmpneqps    ymm0, ymm7, ymm8                   ; c4 c1 44 c2 c0 04                    
  2203 : vcmpneqps    ymm0, ymm0, ymm15                  ; c4 c1 7c c2 c7 04                    
  2204 : vcmpneqpd    ymm0, ymm0, ymm0                   ; c5 fd c2 c0 04                       
  2205 : vcmpneqpd    ymm7, ymm0, ymm0                   ; c5 fd c2 f8 04                       
  2206 : vcmpneqpd    ymm0, ymm7, ymm0                   ; c5 c5 c2 c0 04                       
  2207 : vcmpneqpd    ymm0, ymm0, ymm7                   ; c5 fd c2 c7 04                       
  2208 : vcmpneqpd    ymm8, ymm0, ymm0                   ; c5 7d c2 c0 04                       
  2209 : vcmpneqpd    ymm15, ymm0, ymm0                  ; c5 7d c2 f8 04                       
  2210 : vcmpneqpd    ymm8, ymm7, ymm0                   ; c5 45 c2 c0 04                       
  2211 : vcmpneqpd    ymm8, ymm0, ymm7                   ; c5 7d c2 c7 04                       
  2212 : vcmpneqpd    ymm0, ymm8, ymm0                   ; c5 bd c2 c0 04                       
  2213 : vcmpneqpd    ymm7, ymm8, ymm0                   ; c5 bd c2 f8 04                       
  2214 : vcmpneqpd    ymm0, ymm15, ymm0                  ; c5 85 c2 c0 04                       
  2215 : vcmpneqpd    ymm0, ymm8, ymm7                   ; c5 bd c2 c7 04                       
  2216 : vcmpneqpd    ymm0, ymm0, ymm8                   ; c4 c1 7d c2 c0 04                    
  2217 : vcmpneqpd    ymm7, ymm0, ymm8                   ; c4 c1 7d c2 f8 04                    
  2218 : vcmpneqpd    ymm0, ymm7, ymm8                   ; c4 c1 45 c2 c0 04                    
  2219 : vcmpneqpd    ymm0, ymm0, ymm15                  ; c4 c1 7d c2 c7 04                    
  2220 : vcmpltps     ymm0, ymm0, ymm0                   ; c5 fc c2 c0 01                       
  2221 : vcmpltps     ymm7, ymm0, ymm0                   ; c5 fc c2 f8 01                       
  2222 : vcmpltps     ymm0, ymm7, ymm0                   ; c5 c4 c2 c0 01                       
  2223 : vcmpltps     ymm0, ymm0, ymm7                   ; c5 fc c2 c7 01                       
  2224 : vcmpltps     ymm8, ymm0, ymm0                   ; c5 7c c2 c0 01                       
  2225 : vcmpltps     ymm15, ymm0, ymm0                  ; c5 7c c2 f8 01                       
  2226 : vcmpltps     ymm8, ymm7, ymm0                   ; c5 44 c2 c0 01                       
  2227 : vcmpltps     ymm8, ymm0, ymm7                   ; c5 7c c2 c7 01                       
  2228 : vcmpltps     ymm0, ymm8, ymm0                   ; c5 bc c2 c0 01                       
  2229 : vcmpltps     ymm7, ymm8, ymm0                   ; c5 bc c2 f8 01                       
  2230 : vcmpltps     ymm0, ymm15, ymm0                  ; c5 84 c2 c0 01                       
  2231 : vcmpltps     ymm0, ymm8, ymm7                   ; c5 bc c2 c7 01                       
  2232 : vcmpltps     ymm0, ymm0, ymm8                   ; c4 c1 7c c2 c0 01                    
  2233 : vcmpltps     ymm7, ymm0, ymm8                   ; c4 c1 7c c2 f8 01                    
  2234 : vcmpltps     ymm0, ymm7, ymm8                   ; c4 c1 44 c2 c0 01                    
  2235 : vcmpltps     ymm0, ymm0, ymm15                  ; c4 c1 7c c2 c7 01                    
  2236 : vcmpltpd     ymm0, ymm0, ymm0                   ; c5 fd c2 c0 01                       
  2237 : vcmpltpd     ymm7, ymm0, ymm0                   ; c5 fd c2 f8 01                       
  2238 : vcmpltpd     ymm0, ymm7, ymm0                   ; c5 c5 c2 c0 01                       
  2239 : vcmpltpd     ymm0, ymm0, ymm7                   ; c5 fd c2 c7 01                       
  2240 : vcmpltpd     ymm8, ymm0, ymm0                   ; c5 7d c2 c0 01                       
  2241 : vcmpltpd     ymm15, ymm0, ymm0                  ; c5 7d c2 f8 01                       
  2242 : vcmpltpd     ymm8, ymm7, ymm0                   ; c5 45 c2 c0 01                       
  2243 : vcmpltpd     ymm8, ymm0, ymm7                   ; c5 7d c2 c7 01                       
  2244 : vcmpltpd     ymm0, ymm8, ymm0                   ; c5 bd c2 c0 01                       
  2245 : vcmpltpd     ymm7, ymm8, ymm0                   ; c5 bd c2 f8 01                       
  2246 : vcmpltpd     ymm0, ymm15, ymm0                  ; c5 85 c2 c0 01                       
  2247 : vcmpltpd     ymm0, ymm8, ymm7                   ; c5 bd c2 c7 01                       
  2248 : vcmpltpd     ymm0, ymm0, ymm8                   ; c4 c1 7d c2 c0 01                    
  2249 : vcmpltpd     ymm7, ymm0, ymm8                   ; c4 c1 7d c2 f8 01                    
  2250 : vcmpltpd     ymm0, ymm7, ymm8                   ; c4 c1 45 c2 c0 01                    
  2251 : vcmpltpd     ymm0, ymm0, ymm15                  ; c4 c1 7d c2 c7 01                    
  2252 : vcmpleps     ymm0, ymm0, ymm0                   ; c5 fc c2 c0 02                       
  2253 : vcmpleps     ymm7, ymm0, ymm0                   ; c5 fc c2 f8 02                       
  2254 : vcmpleps     ymm0, ymm7, ymm0                   ; c5 c4 c2 c0 02                       
  2255 : vcmpleps     ymm0, ymm0, ymm7                   ; c5 fc c2 c7 02                       
  2256 : vcmpleps     ymm8, ymm0, ymm0                   ; c5 7c c2 c0 02                       
  2257 : vcmpleps     ymm15, ymm0, ymm0                  ; c5 7c c2 f8 02                       
  2258 : vcmpleps     ymm8, ymm7, ymm0                   ; c5 44 c2 c0 02                       
  2259 : vcmpleps     ymm8, ymm0, ymm7                   ; c5 7c c2 c7 02                       
  2260 : vcmpleps     ymm0, ymm8, ymm0                   ; c5 bc c2 c0 02                       
  2261 : vcmpleps     ymm7, ymm8, ymm0                   ; c5 bc c2 f8 02                       
  2262 : vcmpleps     ymm0, ymm15, ymm0                  ; c5 84 c2 c0 02                       
  2263 : vcmpleps     ymm0, ymm8, ymm7                   ; c5 bc c2 c7 02                       
  2264 : vcmpleps     ymm0, ymm0, ymm8                   ; c4 c1 7c c2 c0 02                    
  2265 : vcmpleps     ymm7, ymm0, ymm8                   ; c4 c1 7c c2 f8 02                    
  2266 : vcmpleps     ymm0, ymm7, ymm8                   ; c4 c1 44 c2 c0 02                    
  2267 : vcmpleps     ymm0, ymm0, ymm15                  ; c4 c1 7c c2 c7 02                    
  2268 : vcmplepd     ymm0, ymm0, ymm0                   ; c5 fd c2 c0 02                       
  2269 : vcmplepd     ymm7, ymm0, ymm0                   ; c5 fd c2 f8 02                       
  2270 : vcmplepd     ymm0, ymm7, ymm0                   ; c5 c5 c2 c0 02                       
  2271 : vcmplepd     ymm0, ymm0, ymm7                   ; c5 fd c2 c7 02                       
  2272 : vcmplepd     ymm8, ymm0, ymm0                   ; c5 7d c2 c0 02                       
  2273 : vcmplepd     ymm15, ymm0, ymm0                  ; c5 7d c2 f8 02                       
  2274 : vcmplepd     ymm8, ymm7, ymm0                   ; c5 45 c2 c0 02                       
  2275 : vcmplepd     ymm8, ymm0, ymm7                   ; c5 7d c2 c7 02                       
  2276 : vcmplepd     ymm0, ymm8, ymm0                   ; c5 bd c2 c0 02                       
  2277 : vcmplepd     ymm7, ymm8, ymm0                   ; c5 bd c2 f8 02                       
  2278 : vcmplepd     ymm0, ymm15, ymm0                  ; c5 85 c2 c0 02                       
  2279 : vcmplepd     ymm0, ymm8, ymm7                   ; c5 bd c2 c7 02                       
  2280 : vcmplepd     ymm0, ymm0, ymm8                   ; c4 c1 7d c2 c0 02                    
  2281 : vcmplepd     ymm7, ymm0, ymm8                   ; c4 c1 7d c2 f8 02                    
  2282 : vcmplepd     ymm0, ymm7, ymm8                   ; c4 c1 45 c2 c0 02                    
  2283 : vcmplepd     ymm0, ymm0, ymm15                  ; c4 c1 7d c2 c7 02                    
  2284 : vpcmpgtb     ymm0, ymm0, ymm0                   ; c5 fd 64 c0                          
  2285 : vpcmpgtb     ymm7, ymm0, ymm0                   ; c5 fd 64 f8                          
  2286 : vpcmpgtb     ymm0, ymm7, ymm0                   ; c5 c5 64 c0                          
  2287 : vpcmpgtb     ymm0, ymm0, ymm7                   ; c5 fd 64 c7                          
  2288 : vpcmpgtb     ymm8, ymm0, ymm0                   ; c5 7d 64 c0                          
  2289 : vpcmpgtb     ymm15, ymm0, ymm0                  ; c5 7d 64 f8                          
  2290 : vpcmpgtb     ymm8, ymm7, ymm0                   ; c5 45 64 c0                          
  2291 : vpcmpgtb     ymm8, ymm0, ymm7                   ; c5 7d 64 c7                          
  2292 : vpcmpgtb     ymm0, ymm8, ymm0                   ; c5 bd 64 c0                          
  2293 : vpcmpgtb     ymm7, ymm8, ymm0                   ; c5 bd 64 f8                          
  2294 : vpcmpgtb     ymm0, ymm15, ymm0                  ; c5 85 64 c0                          
  2295 : vpcmpgtb     ymm0, ymm8, ymm7                   ; c5 bd 64 c7                          
  2296 : vpcmpgtb     ymm0, ymm0, ymm8                   ; c4 c1 7d 64 c0                       
  2297 : vpcmpgtb     ymm7, ymm0, ymm8                   ; c4 c1 7d 64 f8                       
  2298 : vpcmpgtb     ymm0, ymm7, ymm8                   ; c4 c1 45 64 c0                       
  2299 : vpcmpgtb     ymm0, ymm0, ymm15                  ; c4 c1 7d 64 c7                       
  2300 : vpcmpgtw     ymm0, ymm0, ymm0                   ; c5 fd 65 c0                          
  2301 : vpcmpgtw     ymm7, ymm0, ymm0                   ; c5 fd 65 f8                          
  2302 : vpcmpgtw     ymm0, ymm7, ymm0                   ; c5 c5 65 c0                          
  2303 : vpcmpgtw     ymm0, ymm0, ymm7                   ; c5 fd 65 c7                          
  2304 : vpcmpgtw     ymm8, ymm0, ymm0                   ; c5 7d 65 c0                          
  2305 : vpcmpgtw     ymm15, ymm0, ymm0                  ; c5 7d 65 f8                          
  2306 : vpcmpgtw     ymm8, ymm7, ymm0                   ; c5 45 65 c0                          
  2307 : vpcmpgtw     ymm8, ymm0, ymm7                   ; c5 7d 65 c7                          
  2308 : vpcmpgtw     ymm0, ymm8, ymm0                   ; c5 bd 65 c0                          
  2309 : vpcmpgtw     ymm7, ymm8, ymm0                   ; c5 bd 65 f8                          
  2310 : vpcmpgtw     ymm0, ymm15, ymm0                  ; c5 85 65 c0                          
  2311 : vpcmpgtw     ymm0, ymm8, ymm7                   ; c5 bd 65 c7                          
  2312 : vpcmpgtw     ymm0, ymm0, ymm8                   ; c4 c1 7d 65 c0                       
  2313 : vpcmpgtw     ymm7, ymm0, ymm8                   ; c4 c1 7d 65 f8                       
  2314 : vpcmpgtw     ymm0, ymm7, ymm8                   ; c4 c1 45 65 c0                       
  2315 : vpcmpgtw     ymm0, ymm0, ymm15                  ; c4 c1 7d 65 c7                       
  2316 : vpcmpgtd     ymm0, ymm0, ymm0                   ; c5 fd 66 c0                          
  2317 : vpcmpgtd     ymm7, ymm0, ymm0                   ; c5 fd 66 f8                          
  2318 : vpcmpgtd     ymm0, ymm7, ymm0                   ; c5 c5 66 c0                          
  2319 : vpcmpgtd     ymm0, ymm0, ymm7                   ; c5 fd 66 c7                          
  2320 : vpcmpgtd     ymm8, ymm0, ymm0                   ; c5 7d 66 c0                          
  2321 : vpcmpgtd     ymm15, ymm0, ymm0                  ; c5 7d 66 f8                          
  2322 : vpcmpgtd     ymm8, ymm7, ymm0                   ; c5 45 66 c0                          
  2323 : vpcmpgtd     ymm8, ymm0, ymm7                   ; c5 7d 66 c7                          
  2324 : vpcmpgtd     ymm0, ymm8, ymm0                   ; c5 bd 66 c0                          
  2325 : vpcmpgtd     ymm7, ymm8, ymm0                   ; c5 bd 66 f8                          
  2326 : vpcmpgtd     ymm0, ymm15, ymm0                  ; c5 85 66 c0                          
  2327 : vpcmpgtd     ymm0, ymm8, ymm7                   ; c5 bd 66 c7                          
  2328 : vpcmpgtd     ymm0, ymm0, ymm8                   ; c4 c1 7d 66 c0                       
  2329 : vpcmpgtd     ymm7, ymm0, ymm8                   ; c4 c1 7d 66 f8                       
  2330 : vpcmpgtd     ymm0, ymm7, ymm8                   ; c4 c1 45 66 c0                       
  2331 : vpcmpgtd     ymm0, ymm0, ymm15                  ; c4 c1 7d 66 c7                       
  2332 : vpcmpgtq     ymm0, ymm0, ymm0                   ; c4 e2 7d 37 c0                       
  2333 : vpcmpgtq     ymm7, ymm0, ymm0                   ; c4 e2 7d 37 f8                       
  2334 : vpcmpgtq     ymm0, ymm7, ymm0                   ; c4 e2 45 37 c0                       
  2335 : vpcmpgtq     ymm0, ymm0, ymm7                   ; c4 e2 7d 37 c7                       
  2336 : vpcmpgtq     ymm8, ymm0, ymm0                   ; c4 62 7d 37 c0                       
  2337 : vpcmpgtq     ymm15, ymm0, ymm0                  ; c4 62 7d 37 f8                       
  2338 : vpcmpgtq     ymm8, ymm7, ymm0                   ; c4 62 45 37 c0                       
  2339 : vpcmpgtq     ymm8, ymm0, ymm7                   ; c4 62 7d 37 c7                       
  2340 : vpcmpgtq     ymm0, ymm8, ymm0                   ; c4 e2 3d 37 c0                       
  2341 : vpcmpgtq     ymm7, ymm8, ymm0                   ; c4 e2 3d 37 f8                       
  2342 : vpcmpgtq     ymm0, ymm15, ymm0                  ; c4 e2 05 37 c0                       
  2343 : vpcmpgtq     ymm0, ymm8, ymm7                   ; c4 e2 3d 37 c7                       
  2344 : vpcmpgtq     ymm0, ymm0, ymm8                   ; c4 c2 7d 37 c0                       
  2345 : vpcmpgtq     ymm7, ymm0, ymm8                   ; c4 c2 7d 37 f8                       
  2346 : vpcmpgtq     ymm0, ymm7, ymm8                   ; c4 c2 45 37 c0                       
  2347 : vpcmpgtq     ymm0, ymm0, ymm15                  ; c4 c2 7d 37 c7                       
  2348 : vpblendvb    ymm0, ymm0, ymm0, ymm0             ; c4 e3 7d 4c c0 00                    
  2349 : vpblendvb    ymm7, ymm0, ymm0, ymm0             ; c4 e3 7d 4c f8 00                    
  2350 : vpblendvb    ymm0, ymm7, ymm0, ymm0             ; c4 e3 45 4c c0 00                    
  2351 : vpblendvb    ymm0, ymm0, ymm7, ymm0             ; c4 e3 7d 4c c7 00                    
  2352 : vpblendvb    ymm0, ymm0, ymm0, ymm7             ; c4 e3 7d 4c c0 70                    
  2353 : vpblendvb    ymm8, ymm0, ymm0, ymm0             ; c4 63 7d 4c c0 00                    
  2354 : vpblendvb    ymm15, ymm0, ymm0, ymm0            ; c4 63 7d 4c f8 00                    
  2355 : vpblendvb    ymm8, ymm7, ymm0, ymm0             ; c4 63 45 4c c0 00                    
  2356 : vpblendvb    ymm8, ymm0, ymm7, ymm0             ; c4 63 7d 4c c7 00                    
  2357 : vpblendvb    ymm8, ymm0, ymm0, ymm7             ; c4 63 7d 4c c0 70                    
  2358 : vpblendvb    ymm0, ymm8, ymm0, ymm0             ; c4 e3 3d 4c c0 00                    
  2359 : vpblendvb    ymm7, ymm8, ymm0, ymm0             ; c4 e3 3d 4c f8 00                    
  2360 : vpblendvb    ymm0, ymm15, ymm0, ymm0            ; c4 e3 05 4c c0 00                    
  2361 : vpblendvb    ymm0, ymm8, ymm7, ymm0             ; c4 e3 3d 4c c7 00                    
  2362 : vpblendvb    ymm0, ymm8, ymm0, ymm7             ; c4 e3 3d 4c c0 70                    
  2363 : vpblendvb    ymm0, ymm0, ymm8, ymm0             ; c4 c3 7d 4c c0 00                    
  2364 : vpblendvb    ymm7, ymm0, ymm8, ymm0             ; c4 c3 7d 4c f8 00                    
  2365 : vpblendvb    ymm0, ymm7, ymm8, ymm0             ; c4 c3 45 4c c0 00                    
  2366 : vpblendvb    ymm0, ymm0, ymm15, ymm0            ; c4 c3 7d 4c c7 00                    
  2367 : vpblendvb    ymm0, ymm0, ymm8, ymm7             ; c4 c3 7d 4c c0 70                    
  2368 : vpblendvb    ymm0, ymm0, ymm0, ymm8             ; c4 e3 7d 4c c0 80                    
  2369 : vpblendvb    ymm7, ymm0, ymm0, ymm8             ; c4 e3 7d 4c f8 80                    
  2370 : vpblendvb    ymm0, ymm7, ymm0, ymm8             ; c4 e3 45 4c c0 80                    
  2371 : vpblendvb    ymm0, ymm0, ymm7, ymm8             ; c4 e3 7d 4c c7 80                    
  2372 : vpblendvb    ymm0, ymm0, ymm0, ymm15            ; c4 e3 7d 4c c0 f0                    
  2373 : vblendvps    ymm0, ymm0, ymm0, ymm0             ; c4 e3 7d 4a c0 00                    
  2374 : vblendvps    ymm7, ymm0, ymm0, ymm0             ; c4 e3 7d 4a f8 00                    
  2375 : vblendvps    ymm0, ymm7, ymm0, ymm0             ; c4 e3 45 4a c0 00                    
  2376 : vblendvps    ymm0, ymm0, ymm7, ymm0             ; c4 e3 7d 4a c7 00                    
  2377 : vblendvps    ymm0, ymm0, ymm0, ymm7             ; c4 e3 7d 4a c0 70                    
  2378 : vblendvps    ymm8, ymm0, ymm0, ymm0             ; c4 63 7d 4a c0 00                    
  2379 : vblendvps    ymm15, ymm0, ymm0, ymm0            ; c4 63 7d 4a f8 00                    
  2380 : vblendvps    ymm8, ymm7, ymm0, ymm0             ; c4 63 45 4a c0 00                    
  2381 : vblendvps    ymm8, ymm0, ymm7, ymm0             ; c4 63 7d 4a c7 00                    
  2382 : vblendvps    ymm8, ymm0, ymm0, ymm7             ; c4 63 7d 4a c0 70                    
  2383 : vblendvps    ymm0, ymm8, ymm0, ymm0             ; c4 e3 3d 4a c0 00                    
  2384 : vblendvps    ymm7, ymm8, ymm0, ymm0             ; c4 e3 3d 4a f8 00                    
  2385 : vblendvps    ymm0, ymm15, ymm0, ymm0            ; c4 e3 05 4a c0 00                    
  2386 : vblendvps    ymm0, ymm8, ymm7, ymm0             ; c4 e3 3d 4a c7 00                    
  2387 : vblendvps    ymm0, ymm8, ymm0, ymm7             ; c4 e3 3d 4a c0 70                    
  2388 : vblendvps    ymm0, ymm0, ymm8, ymm0             ; c4 c3 7d 4a c0 00                    
  2389 : vblendvps    ymm7, ymm0, ymm8, ymm0             ; c4 c3 7d 4a f8 00                    
  2390 : vblendvps    ymm0, ymm7, ymm8, ymm0             ; c4 c3 45 4a c0 00                    
  2391 : vblendvps    ymm0, ymm0, ymm15, ymm0            ; c4 c3 7d 4a c7 00                    
  2392 : vblendvps    ymm0, ymm0, ymm8, ymm7             ; c4 c3 7d 4a c0 70                    
  2393 : vblendvps    ymm0, ymm0, ymm0, ymm8             ; c4 e3 7d 4a c0 80                    
  2394 : vblendvps    ymm7, ymm0, ymm0, ymm8             ; c4 e3 7d 4a f8 80                    
  2395 : vblendvps    ymm0, ymm7, ymm0, ymm8             ; c4 e3 45 4a c0 80                    
  2396 : vblendvps    ymm0, ymm0, ymm7, ymm8             ; c4 e3 7d 4a c7 80                    
  2397 : vblendvps    ymm0, ymm0, ymm0, ymm15            ; c4 e3 7d 4a c0 f0                    
  2398 : vblendvpd    ymm0, ymm0, ymm0, ymm0             ; c4 e3 7d 4b c0 00                    
  2399 : vblendvpd    ymm7, ymm0, ymm0, ymm0             ; c4 e3 7d 4b f8 00                    
  2400 : vblendvpd    ymm0, ymm7, ymm0, ymm0             ; c4 e3 45 4b c0 00                    
  2401 : vblendvpd    ymm0, ymm0, ymm7, ymm0             ; c4 e3 7d 4b c7 00                    
  2402 : vblendvpd    ymm0, ymm0, ymm0, ymm7             ; c4 e3 7d 4b c0 70                    
  2403 : vblendvpd    ymm8, ymm0, ymm0, ymm0             ; c4 63 7d 4b c0 00                    
  2404 : vblendvpd    ymm15, ymm0, ymm0, ymm0            ; c4 63 7d 4b f8 00                    
  2405 : vblendvpd    ymm8, ymm7, ymm0, ymm0             ; c4 63 45 4b c0 00                    
  2406 : vblendvpd    ymm8, ymm0, ymm7, ymm0             ; c4 63 7d 4b c7 00                    
  2407 : vblendvpd    ymm8, ymm0, ymm0, ymm7             ; c4 63 7d 4b c0 70                    
  2408 : vblendvpd    ymm0, ymm8, ymm0, ymm0             ; c4 e3 3d 4b c0 00                    
  2409 : vblendvpd    ymm7, ymm8, ymm0, ymm0             ; c4 e3 3d 4b f8 00                    
  2410 : vblendvpd    ymm0, ymm15, ymm0, ymm0            ; c4 e3 05 4b c0 00                    
  2411 : vblendvpd    ymm0, ymm8, ymm7, ymm0             ; c4 e3 3d 4b c7 00                    
  2412 : vblendvpd    ymm0, ymm8, ymm0, ymm7             ; c4 e3 3d 4b c0 70                    
  2413 : vblendvpd    ymm0, ymm0, ymm8, ymm0             ; c4 c3 7d 4b c0 00                    
  2414 : vblendvpd    ymm7, ymm0, ymm8, ymm0             ; c4 c3 7d 4b f8 00                    
  2415 : vblendvpd    ymm0, ymm7, ymm8, ymm0             ; c4 c3 45 4b c0 00                    
  2416 : vblendvpd    ymm0, ymm0, ymm15, ymm0            ; c4 c3 7d 4b c7 00                    
  2417 : vblendvpd    ymm0, ymm0, ymm8, ymm7             ; c4 c3 7d 4b c0 70                    
  2418 : vblendvpd    ymm0, ymm0, ymm0, ymm8             ; c4 e3 7d 4b c0 80                    
  2419 : vblendvpd    ymm7, ymm0, ymm0, ymm8             ; c4 e3 7d 4b f8 80                    
  2420 : vblendvpd    ymm0, ymm7, ymm0, ymm8             ; c4 e3 45 4b c0 80                    
  2421 : vblendvpd    ymm0, ymm0, ymm7, ymm8             ; c4 e3 7d 4b c7 80                    
  2422 : vblendvpd    ymm0, ymm0, ymm0, ymm15            ; c4 e3 7d 4b c0 f0                    
  2423 : vpbroadcastb ymm0, xmm0                         ; c4 e2 7d 78 c0                       
  2424 : vpbroadcastb ymm7, xmm0                         ; c4 e2 7d 78 f8                       
  2425 : vpbroadcastb ymm0, xmm7                         ; c4 e2 7d 78 c7                       
  2426 : vpbroadcastb ymm8, xmm0                         ; c4 62 7d 78 c0                       
  2427 : vpbroadcastb ymm15, xmm0                        ; c4 62 7d 78 f8                       
  2428 : vpbroadcastb ymm8, xmm7                         ; c4 62 7d 78 c7                       
  2429 : vpbroadcastb ymm0, xmm8                         ; c4 c2 7d 78 c0                       
  2430 : vpbroadcastb ymm7, xmm8                         ; c4 c2 7d 78 f8                       
  2431 : vpbroadcastb ymm0, xmm15                        ; c4 c2 7d 78 c7                       
  2432 : vpbroadcastb ymm8, xmm8                         ; c4 42 7d 78 c0                       
  2433 : vpbroadcastb ymm15, xmm8                        ; c4 42 7d 78 f8                       
  2434 : vpbroadcastb ymm8, xmm15                        ; c4 42 7d 78 c7                       
  2435 : vpbroadcastw ymm0, xmm0                         ; c4 e2 7d 79 c0                       
  2436 : vpbroadcastw ymm7, xmm0                         ; c4 e2 7d 79 f8                       
  2437 : vpbroadcastw ymm0, xmm7                         ; c4 e2 7d 79 c7                       
  2438 : vpbroadcastw ymm8, xmm0                         ; c4 62 7d 79 c0                       
  2439 : vpbroadcastw ymm15, xmm0                        ; c4 62 7d 79 f8                       
  2440 : vpbroadcastw ymm8, xmm7                         ; c4 62 7d 79 c7                       
  2441 : vpbroadcastw ymm0, xmm8                         ; c4 c2 7d 79 c0                       
  2442 : vpbroadcastw ymm7, xmm8                         ; c4 c2 7d 79 f8                       
  2443 : vpbroadcastw ymm0, xmm15                        ; c4 c2 7d 79 c7                       
  2444 : vpbroadcastw ymm8, xmm8                         ; c4 42 7d 79 c0                       
  2445 : vpbroadcastw ymm15, xmm8                        ; c4 42 7d 79 f8                       
  2446 : vpbroadcastw ymm8, xmm15                        ; c4 42 7d 79 c7                       
  2447 : vpbroadcastd ymm0, xmm0                         ; c4 e2 7d 58 c0                       
  2448 : vpbroadcastd ymm7, xmm0                         ; c4 e2 7d 58 f8                       
  2449 : vpbroadcastd ymm0, xmm7                         ; c4 e2 7d 58 c7                       
  2450 : vpbroadcastd ymm8, xmm0                         ; c4 62 7d 58 c0                       
  2451 : vpbroadcastd ymm15, xmm0                        ; c4 62 7d 58 f8                       
  2452 : vpbroadcastd ymm8, xmm7                         ; c4 62 7d 58 c7                       
  2453 : vpbroadcastd ymm0, xmm8                         ; c4 c2 7d 58 c0                       
  2454 : vpbroadcastd ymm7, xmm8                         ; c4 c2 7d 58 f8                       
  2455 : vpbroadcastd ymm0, xmm15                        ; c4 c2 7d 58 c7                       
  2456 : vpbroadcastd ymm8, xmm8                         ; c4 42 7d 58 c0                       
  2457 : vpbroadcastd ymm15, xmm8                        ; c4 42 7d 58 f8                       
  2458 : vpbroadcastd ymm8, xmm15                        ; c4 42 7d 58 c7                       
  2459 : vpbroadcastq ymm0, xmm0                         ; c4 e2 7d 59 c0                       
  2460 : vpbroadcastq ymm7, xmm0                         ; c4 e2 7d 59 f8                       
  2461 : vpbroadcastq ymm0, xmm7                         ; c4 e2 7d 59 c7                       
  2462 : vpbroadcastq ymm8, xmm0                         ; c4 62 7d 59 c0                       
  2463 : vpbroadcastq ymm15, xmm0                        ; c4 62 7d 59 f8                       
  2464 : vpbroadcastq ymm8, xmm7                         ; c4 62 7d 59 c7                       
  2465 : vpbroadcastq ymm0, xmm8                         ; c4 c2 7d 59 c0                       
  2466 : vpbroadcastq ymm7, xmm8                         ; c4 c2 7d 59 f8                       
  2467 : vpbroadcastq ymm0, xmm15                        ; c4 c2 7d 59 c7                       
  2468 : vpbroadcastq ymm8, xmm8                         ; c4 42 7d 59 c0                       
  2469 : vpbroadcastq ymm15, xmm8                        ; c4 42 7d 59 f8                       
  2470 : vpbroadcastq ymm8, xmm15                        ; c4 42 7d 59 c7                       
  2471 : vextracti128 xmm0, ymm0, 0                      ; c4 e3 7d 39 c0 00                    
  2472 : vextracti128 xmm0, ymm0, 0x001                  ; c4 e3 7d 39 c0 01                    
  2473 : vextracti128 xmm7, ymm0, 0x001                  ; c4 e3 7d 39 c7 01                    
  2474 : vextracti128 xmm0, ymm7, 0x001                  ; c4 e3 7d 39 f8 01                    
  2475 : vextracti128 xmm8, ymm0, 0x001                  ; c4 c3 7d 39 c0 01                    
  2476 : vextracti128 xmm15, ymm0, 0x001                 ; c4 c3 7d 39 c7 01                    
  2477 : vextracti128 xmm8, ymm7, 0x001                  ; c4 c3 7d 39 f8 01                    
  2478 : vextracti128 xmm0, ymm8, 0x001                  ; c4 63 7d 39 c0 01                    
  2479 : vextracti128 xmm7, ymm8, 0x001                  ; c4 63 7d 39 c7 01                    
  2480 : vextracti128 xmm0, ymm15, 0x001                 ; c4 63 7d 39 f8 01                    
  2481 : vextracti128 xmm8, ymm8, 0x001                  ; c4 43 7d 39 c0 01                    
  2482 : vextracti128 xmm15, ymm8, 0x001                 ; c4 43 7d 39 c7 01                    
  2483 : vextracti128 xmm8, ymm15, 0x001                 ; c4 43 7d 39 f8 01                    
  2484 : vextractf128 xmm0, ymm0, 0                      ; c4 e3 7d 19 c0 00                    
  2485 : vextractf128 xmm0, ymm0, 0x001                  ; c4 e3 7d 19 c0 01                    
  2486 : vextractf128 xmm7, ymm0, 0x001                  ; c4 e3 7d 19 c7 01                    
  2487 : vextractf128 xmm0, ymm7, 0x001                  ; c4 e3 7d 19 f8 01                    
  2488 : vextractf128 xmm8, ymm0, 0x001                  ; c4 c3 7d 19 c0 01                    
  2489 : vextractf128 xmm15, ymm0, 0x001                 ; c4 c3 7d 19 c7 01                    
  2490 : vextractf128 xmm8, ymm7, 0x001                  ; c4 c3 7d 19 f8 01                    
  2491 : vextractf128 xmm0, ymm8, 0x001                  ; c4 63 7d 19 c0 01                    
  2492 : vextractf128 xmm7, ymm8, 0x001                  ; c4 63 7d 19 c7 01                    
  2493 : vextractf128 xmm0, ymm15, 0x001                 ; c4 63 7d 19 f8 01                    
  2494 : vextractf128 xmm8, ymm8, 0x001                  ; c4 43 7d 19 c0 01                    
  2495 : vextractf128 xmm15, ymm8, 0x001                 ; c4 43 7d 19 c7 01                    
  2496 : vextractf128 xmm8, ymm15, 0x001                 ; c4 43 7d 19 f8 01                    
  2497 : vpextrb      rax, xmm0, 0x001                   ; c4 e3 79 14 c0 01                    
  2498 : vpextrb      rdi, xmm0, 0x001                   ; c4 e3 79 14 c7 01                    
  2499 : vpextrb      rax, xmm7, 0x001                   ; c4 e3 79 14 f8 01                    
  2500 : vpextrb      rax, xmm8, 0x001                   ; c4 63 79 14 c0 01                    
  2501 : vpextrb      rdi, xmm8, 0x001                   ; c4 63 79 14 c7 01                    
  2502 : vpextrb      rax, xmm15, 0x001                  ; c4 63 79 14 f8 01                    
  2503 : vpextrb      r8, xmm0, 0x001                    ; c4 c3 79 14 c0 01                    
  2504 : vpextrb      r15, xmm0, 0x001                   ; c4 c3 79 14 c7 01                    
  2505 : vpextrb      r8, xmm7, 0x001                    ; c4 c3 79 14 f8 01                    
  2506 : vpextrb      r8, xmm8, 0x001                    ; c4 43 79 14 c0 01                    
  2507 : vpextrb      r15, xmm8, 0x001                   ; c4 43 79 14 c7 01                    
  2508 : vpextrb      r8, xmm15, 0x001                   ; c4 43 79 14 f8 01                    
  2509 : vpextrw      rax, xmm0, 0x001                   ; c5 f9 c5 c0 01                       
  2510 : vpextrw      rdi, xmm0, 0x001                   ; c5 f9 c5 f8 01                       
  2511 : vpextrw      rax, xmm7, 0x001                   ; c5 f9 c5 c7 01                       
  2512 : vpextrw      rax, xmm8, 0x001                   ; c4 c1 79 c5 c0 01                    
  2513 : vpextrw      rdi, xmm8, 0x001                   ; c4 c1 79 c5 f8 01                    
  2514 : vpextrw      rax, xmm15, 0x001                  ; c4 c1 79 c5 c7 01                    
  2515 : vpextrw      r8, xmm0, 0x001                    ; c5 79 c5 c0 01                       
  2516 : vpextrw      r15, xmm0, 0x001                   ; c5 79 c5 f8 01                       
  2517 : vpextrw      r8, xmm7, 0x001                    ; c5 79 c5 c7 01                       
  2518 : vpextrw      r8, xmm8, 0x001                    ; c4 41 79 c5 c0 01                    
  2519 : vpextrw      r15, xmm8, 0x001                   ; c4 41 79 c5 f8 01                    
  2520 : vpextrw      r8, xmm15, 0x001                   ; c4 41 79 c5 c7 01                    
  2521 : vpextrd      eax, xmm0, 0x001                   ; c4 e3 79 16 c0 01                    
  2522 : vpextrd      edi, xmm0, 0x001                   ; c4 e3 79 16 c7 01                    
  2523 : vpextrd      eax, xmm7, 0x001                   ; c4 e3 79 16 f8 01                    
  2524 : vpextrd      eax, xmm8, 0x001                   ; c4 63 79 16 c0 01                    
  2525 : vpextrd      edi, xmm8, 0x001                   ; c4 63 79 16 c7 01                    
  2526 : vpextrd      eax, xmm15, 0x001                  ; c4 63 79 16 f8 01                    
  2527 : vpextrd      r8d, xmm0, 0x001                   ; c4 c3 79 16 c0 01                    
  2528 : vpextrd      r15d, xmm0, 0x001                  ; c4 c3 79 16 c7 01                    
  2529 : vpextrd      r8d, xmm7, 0x001                   ; c4 c3 79 16 f8 01                    
  2530 : vpextrd      r8d, xmm8, 0x001                   ; c4 43 79 16 c0 01                    
  2531 : vpextrd      r15d, xmm8, 0x001                  ; c4 43 79 16 c7 01                    
  2532 : vpextrd      r8d, xmm15, 0x001                  ; c4 43 79 16 f8 01                    
  2533 : vpextrq      rax, xmm0, 0x001                   ; c4 e3 f9 16 c0 01                    
  2534 : vpextrq      rdi, xmm0, 0x001                   ; c4 e3 f9 16 c7 01                    
  2535 : vpextrq      rax, xmm7, 0x001                   ; c4 e3 f9 16 f8 01                    
  2536 : vpextrq      rax, xmm8, 0x001                   ; c4 63 f9 16 c0 01                    
  2537 : vpextrq      rdi, xmm8, 0x001                   ; c4 63 f9 16 c7 01                    
  2538 : vpextrq      rax, xmm15, 0x001                  ; c4 63 f9 16 f8 01                    
  2539 : vpextrq      r8, xmm0, 0x001                    ; c4 c3 f9 16 c0 01                    
  2540 : vpextrq      r15, xmm0, 0x001                   ; c4 c3 f9 16 c7 01                    
  2541 : vpextrq      r8, xmm7, 0x001                    ; c4 c3 f9 16 f8 01                    
  2542 : vpextrq      r8, xmm8, 0x001                    ; c4 43 f9 16 c0 01                    
  2543 : vpextrq      r15, xmm8, 0x001                   ; c4 43 f9 16 c7 01                    
  2544 : vpextrq      r8, xmm15, 0x001                   ; c4 43 f9 16 f8 01                    
  2545 : vinserti128  ymm0, ymm0, xmm0, 0                ; c4 e3 7d 38 c0 00                    
  2546 : vinserti128  ymm0, ymm0, xmm0, 0x001            ; c4 e3 7d 38 c0 01                    
  2547 : vinserti128  ymm7, ymm0, xmm0, 0x001            ; c4 e3 7d 38 f8 01                    
  2548 : vinserti128  ymm0, ymm7, xmm0, 0x001            ; c4 e3 45 38 c0 01                    
  2549 : vinserti128  ymm0, ymm0, xmm7, 0x001            ; c4 e3 7d 38 c7 01                    
  2550 : vinserti128  ymm8, ymm0, xmm0, 0x001            ; c4 63 7d 38 c0 01                    
  2551 : vinserti128  ymm15, ymm0, xmm0, 0x001           ; c4 63 7d 38 f8 01                    
  2552 : vinserti128  ymm8, ymm7, xmm0, 0x001            ; c4 63 45 38 c0 01                    
  2553 : vinserti128  ymm8, ymm0, xmm7, 0x001            ; c4 63 7d 38 c7 01                    
  2554 : vinserti128  ymm0, ymm8, xmm0, 0x001            ; c4 e3 3d 38 c0 01                    
  2555 : vinserti128  ymm7, ymm8, xmm0, 0x001            ; c4 e3 3d 38 f8 01                    
  2556 : vinserti128  ymm0, ymm15, xmm0, 0x001           ; c4 e3 05 38 c0 01                    
  2557 : vinserti128  ymm0, ymm8, xmm7, 0x001            ; c4 e3 3d 38 c7 01                    
  2558 : vinserti128  ymm0, ymm0, xmm8, 0x001            ; c4 c3 7d 38 c0 01                    
  2559 : vinserti128  ymm7, ymm0, xmm8, 0x001            ; c4 c3 7d 38 f8 01                    
  2560 : vinserti128  ymm0, ymm7, xmm8, 0x001            ; c4 c3 45 38 c0 01                    
  2561 : vinserti128  ymm0, ymm0, xmm15, 0x001           ; c4 c3 7d 38 c7 01                    
  2562 : vinsertf128  ymm0, ymm0, xmm0, 0                ; c4 e3 7d 18 c0 00                    
  2563 : vinsertf128  ymm0, ymm0, xmm0, 0x001            ; c4 e3 7d 18 c0 01                    
  2564 : vinsertf128  ymm7, ymm0, xmm0, 0x001            ; c4 e3 7d 18 f8 01                    
  2565 : vinsertf128  ymm0, ymm7, xmm0, 0x001            ; c4 e3 45 18 c0 01                    
  2566 : vinsertf128  ymm0, ymm0, xmm7, 0x001            ; c4 e3 7d 18 c7 01                    
  2567 : vinsertf128  ymm8, ymm0, xmm0, 0x001            ; c4 63 7d 18 c0 01                    
  2568 : vinsertf128  ymm15, ymm0, xmm0, 0x001           ; c4 63 7d 18 f8 01                    
  2569 : vinsertf128  ymm8, ymm7, xmm0, 0x001            ; c4 63 45 18 c0 01                    
  2570 : vinsertf128  ymm8, ymm0, xmm7, 0x001            ; c4 63 7d 18 c7 01                    
  2571 : vinsertf128  ymm0, ymm8, xmm0, 0x001            ; c4 e3 3d 18 c0 01                    
  2572 : vinsertf128  ymm7, ymm8, xmm0, 0x001            ; c4 e3 3d 18 f8 01                    
  2573 : vinsertf128  ymm0, ymm15, xmm0, 0x001           ; c4 e3 05 18 c0 01                    
  2574 : vinsertf128  ymm0, ymm8, xmm7, 0x001            ; c4 e3 3d 18 c7 01                    
  2575 : vinsertf128  ymm0, ymm0, xmm8, 0x001            ; c4 c3 7d 18 c0 01                    
  2576 : vinsertf128  ymm7, ymm0, xmm8, 0x001            ; c4 c3 7d 18 f8 01                    
  2577 : vinsertf128  ymm0, ymm7, xmm8, 0x001            ; c4 c3 45 18 c0 01                    
  2578 : vinsertf128  ymm0, ymm0, xmm15, 0x001           ; c4 c3 7d 18 c7 01                    
  2579 : vpinsrb      xmm0, xmm0, eax, 0                 ; c4 e3 79 20 c0 00                    
  2580 : vpinsrb      xmm0, xmm0, eax, 0x001             ; c4 e3 79 20 c0 01                    
  2581 : vpinsrb      xmm7, xmm7, eax, 0x001             ; c4 e3 41 20 f8 01                    
  2582 : vpinsrb      xmm0, xmm0, edi, 0x001             ; c4 e3 79 20 c7 01                    
  2583 : vpinsrb      xmm8, xmm8, eax, 0x001             ; c4 63 39 20 c0 01                    
  2584 : vpinsrb      xmm15, xmm15, eax, 0x001           ; c4 63 01 20 f8 01                    
  2585 : vpinsrb      xmm8, xmm8, edi, 0x001             ; c4 63 39 20 c7 01                    
  2586 : vpinsrb      xmm0, xmm0, r8d, 0x001             ; c4 c3 79 20 c0 01                    
  2587 : vpinsrb      xmm7, xmm7, r8d, 0x001             ; c4 c3 41 20 f8 01                    
  2588 : vpinsrb      xmm0, xmm0, r15d, 0x001            ; c4 c3 79 20 c7 01                    
  2589 : vpinsrb      xmm8, xmm8, r8d, 0x001             ; c4 43 39 20 c0 01                    
  2590 : vpinsrb      xmm15, xmm15, r8d, 0x001           ; c4 43 01 20 f8 01                    
  2591 : vpinsrb      xmm8, xmm8, r15d, 0x001            ; c4 43 39 20 c7 01                    
  2592 : vpinsrw      xmm0, xmm0, eax, 0                 ; c5 f9 c4 c0 00                       
  2593 : vpinsrw      xmm0, xmm0, eax, 0x001             ; c5 f9 c4 c0 01                       
  2594 : vpinsrw      xmm7, xmm7, eax, 0x001             ; c5 c1 c4 f8 01                       
  2595 : vpinsrw      xmm0, xmm0, edi, 0x001             ; c5 f9 c4 c7 01                       
  2596 : vpinsrw      xmm8, xmm8, eax, 0x001             ; c5 39 c4 c0 01                       
  2597 : vpinsrw      xmm15, xmm15, eax, 0x001           ; c5 01 c4 f8 01                       
  2598 : vpinsrw      xmm8, xmm8, edi, 0x001             ; c5 39 c4 c7 01                       
  2599 : vpinsrw      xmm0, xmm0, r8d, 0x001             ; c4 c1 79 c4 c0 01                    
  2600 : vpinsrw      xmm7, xmm7, r8d, 0x001             ; c4 c1 41 c4 f8 01                    
  2601 : vpinsrw      xmm0, xmm0, r15d, 0x001            ; c4 c1 79 c4 c7 01                    
  2602 : vpinsrw      xmm8, xmm8, r8d, 0x001             ; c4 41 39 c4 c0 01                    
  2603 : vpinsrw      xmm15, xmm15, r8d, 0x001           ; c4 41 01 c4 f8 01                    
  2604 : vpinsrw      xmm8, xmm8, r15d, 0x001            ; c4 41 39 c4 c7 01                    
  2605 : vpinsrd      xmm0, xmm0, eax, 0                 ; c4 e3 79 22 c0 00                    
  2606 : vpinsrd      xmm0, xmm0, eax, 0x001             ; c4 e3 79 22 c0 01                    
  2607 : vpinsrd      xmm7, xmm7, eax, 0x001             ; c4 e3 41 22 f8 01                    
  2608 : vpinsrd      xmm0, xmm0, edi, 0x001             ; c4 e3 79 22 c7 01                    
  2609 : vpinsrd      xmm8, xmm8, eax, 0x001             ; c4 63 39 22 c0 01                    
  2610 : vpinsrd      xmm15, xmm15, eax, 0x001           ; c4 63 01 22 f8 01                    
  2611 : vpinsrd      xmm8, xmm8, edi, 0x001             ; c4 63 39 22 c7 01                    
  2612 : vpinsrd      xmm0, xmm0, r8d, 0x001             ; c4 c3 79 22 c0 01                    
  2613 : vpinsrd      xmm7, xmm7, r8d, 0x001             ; c4 c3 41 22 f8 01                    
  2614 : vpinsrd      xmm0, xmm0, r15d, 0x001            ; c4 c3 79 22 c7 01                    
  2615 : vpinsrd      xmm8, xmm8, r8d, 0x001             ; c4 43 39 22 c0 01                    
  2616 : vpinsrd      xmm15, xmm15, r8d, 0x001           ; c4 43 01 22 f8 01                    
  2617 : vpinsrd      xmm8, xmm8, r15d, 0x001            ; c4 43 39 22 c7 01                    
  2618 : vpinsrq      xmm0, xmm0, rax, 0                 ; c4 e3 f9 22 c0 00                    
  2619 : vpinsrq      xmm0, xmm0, rax, 0x001             ; c4 e3 f9 22 c0 01                    
  2620 : vpinsrq      xmm7, xmm7, rax, 0x001             ; c4 e3 c1 22 f8 01                    
  2621 : vpinsrq      xmm0, xmm0, rdi, 0x001             ; c4 e3 f9 22 c7 01                    
  2622 : vpinsrq      xmm8, xmm8, rax, 0x001             ; c4 63 b9 22 c0 01                    
  2623 : vpinsrq      xmm15, xmm15, rax, 0x001           ; c4 63 81 22 f8 01                    
  2624 : vpinsrq      xmm8, xmm8, rdi, 0x001             ; c4 63 b9 22 c7 01                    
  2625 : vpinsrq      xmm0, xmm0, r8, 0x001              ; c4 c3 f9 22 c0 01                    
  2626 : vpinsrq      xmm7, xmm7, r8, 0x001              ; c4 c3 c1 22 f8 01                    
  2627 : vpinsrq      xmm0, xmm0, r15, 0x001             ; c4 c3 f9 22 c7 01                    
  2628 : vpinsrq      xmm8, xmm8, r8, 0x001              ; c4 43 b9 22 c0 01                    
  2629 : vpinsrq      xmm15, xmm15, r8, 0x001            ; c4 43 81 22 f8 01                    
  2630 : vpinsrq      xmm8, xmm8, r15, 0x001             ; c4 43 b9 22 c7 01                    
  2631 : vperm2i128   ymm0, ymm0, ymm0, 0x021            ; c4 e3 7d 46 c0 21                    
  2632 : vperm2i128   ymm0, ymm0, ymm0, 0x021            ; c4 e3 7d 46 c0 21                    
  2633 : vperm2i128   ymm7, ymm0, ymm0, 0x021            ; c4 e3 7d 46 f8 21                    
  2634 : vperm2i128   ymm0, ymm7, ymm0, 0x021            ; c4 e3 45 46 c0 21                    
  2635 : vperm2i128   ymm0, ymm0, ymm7, 0x021            ; c4 e3 7d 46 c7 21                    
  2636 : vperm2i128   ymm8, ymm0, ymm0, 0x021            ; c4 63 7d 46 c0 21                    
  2637 : vperm2i128   ymm15, ymm0, ymm0, 0x021           ; c4 63 7d 46 f8 21                    
  2638 : vperm2i128   ymm8, ymm7, ymm0, 0x021            ; c4 63 45 46 c0 21                    
  2639 : vperm2i128   ymm8, ymm0, ymm7, 0x021            ; c4 63 7d 46 c7 21                    
  2640 : vperm2i128   ymm0, ymm8, ymm0, 0x021            ; c4 e3 3d 46 c0 21                    
  2641 : vperm2i128   ymm7, ymm8, ymm0, 0x021            ; c4 e3 3d 46 f8 21                    
  2642 : vperm2i128   ymm0, ymm15, ymm0, 0x021           ; c4 e3 05 46 c0 21                    
  2643 : vperm2i128   ymm0, ymm8, ymm7, 0x021            ; c4 e3 3d 46 c7 21                    
  2644 : vperm2i128   ymm0, ymm0, ymm8, 0x021            ; c4 c3 7d 46 c0 21                    
  2645 : vperm2i128   ymm7, ymm0, ymm8, 0x021            ; c4 c3 7d 46 f8 21                    
  2646 : vperm2i128   ymm0, ymm7, ymm8, 0x021            ; c4 c3 45 46 c0 21                    
  2647 : vperm2i128   ymm0, ymm0, ymm15, 0x021           ; c4 c3 7d 46 c7 21                    
  2648 : vpalignr     ymm0, ymm0, ymm0, 0x00f            ; c4 e3 7d 0f c0 0f                    
  2649 : vpalignr     ymm0, ymm0, ymm0, 0x00f            ; c4 e3 7d 0f c0 0f                    
  2650 : vpalignr     ymm7, ymm0, ymm0, 0x00f            ; c4 e3 7d 0f f8 0f                    
  2651 : vpalignr     ymm0, ymm7, ymm0, 0x00f            ; c4 e3 45 0f c0 0f                    
  2652 : vpalignr     ymm0, ymm0, ymm7, 0x00f            ; c4 e3 7d 0f c7 0f                    
  2653 : vpalignr     ymm8, ymm0, ymm0, 0x00f            ; c4 63 7d 0f c0 0f                    
  2654 : vpalignr     ymm15, ymm0, ymm0, 0x00f           ; c4 63 7d 0f f8 0f                    
  2655 : vpalignr     ymm8, ymm7, ymm0, 0x00f            ; c4 63 45 0f c0 0f                    
  2656 : vpalignr     ymm8, ymm0, ymm7, 0x00f            ; c4 63 7d 0f c7 0f                    
  2657 : vpalignr     ymm0, ymm8, ymm0, 0x00f            ; c4 e3 3d 0f c0 0f                    
  2658 : vpalignr     ymm7, ymm8, ymm0, 0x00f            ; c4 e3 3d 0f f8 0f                    
  2659 : vpalignr     ymm0, ymm15, ymm0, 0x00f           ; c4 e3 05 0f c0 0f                    
  2660 : vpalignr     ymm0, ymm8, ymm7, 0x00f            ; c4 e3 3d 0f c7 0f                    
  2661 : vpalignr     ymm0, ymm0, ymm8, 0x00f            ; c4 c3 7d 0f c0 0f                    
  2662 : vpalignr     ymm7, ymm0, ymm8, 0x00f            ; c4 c3 7d 0f f8 0f                    
  2663 : vpalignr     ymm0, ymm7, ymm8, 0x00f            ; c4 c3 45 0f c0 0f                    
  2664 : vpalignr     ymm0, ymm0, ymm15, 0x00f           ; c4 c3 7d 0f c7 0f                    
  2665 : vpshufd      xmm0, xmm0, 0x0ee                  ; c5 f9 70 c0 ee                       
  2666 : vpshufd      xmm7, xmm0, 0x0ee                  ; c5 f9 70 f8 ee                       
  2667 : vpshufd      xmm0, xmm7, 0x0ee                  ; c5 f9 70 c7 ee                       
  2668 : vpshufd      xmm8, xmm0, 0x0ee                  ; c5 79 70 c0 ee                       
  2669 : vpshufd      xmm15, xmm0, 0x0ee                 ; c5 79 70 f8 ee                       
  2670 : vpshufd      xmm8, xmm7, 0x0ee                  ; c5 79 70 c7 ee                       
  2671 : vpshufd      xmm0, xmm8, 0x0ee                  ; c4 c1 79 70 c0 ee                    
  2672 : vpshufd      xmm7, xmm8, 0x0ee                  ; c4 c1 79 70 f8 ee                    
  2673 : vpshufd      xmm0, xmm15, 0x0ee                 ; c4 c1 79 70 c7 ee                    
  2674 : vpshufd      xmm8, xmm8, 0x0ee                  ; c4 41 79 70 c0 ee                    
  2675 : vpshufd      xmm15, xmm8, 0x0ee                 ; c4 41 79 70 f8 ee                    
  2676 : vpshufd      xmm8, xmm15, 0x0ee                 ; c4 41 79 70 c7 ee                    
  2677 : vpsadbw      ymm0, ymm0, ymm0                   ; c5 fd f6 c0                          
  2678 : vpsadbw      ymm7, ymm0, ymm0                   ; c5 fd f6 f8                          
  2679 : vpsadbw      ymm0, ymm7, ymm0                   ; c5 c5 f6 c0                          
  2680 : vpsadbw      ymm0, ymm0, ymm7                   ; c5 fd f6 c7                          
  2681 : vpsadbw      ymm8, ymm0, ymm0                   ; c5 7d f6 c0                          
  2682 : vpsadbw      ymm15, ymm0, ymm0                  ; c5 7d f6 f8                          
  2683 : vpsadbw      ymm8, ymm7, ymm0                   ; c5 45 f6 c0                          
  2684 : vpsadbw      ymm8, ymm0, ymm7                   ; c5 7d f6 c7                          
  2685 : vpsadbw      ymm0, ymm8, ymm0                   ; c5 bd f6 c0                          
  2686 : vpsadbw      ymm7, ymm8, ymm0                   ; c5 bd f6 f8                          
  2687 : vpsadbw      ymm0, ymm15, ymm0                  ; c5 85 f6 c0                          
  2688 : vpsadbw      ymm0, ymm8, ymm7                   ; c5 bd f6 c7                          
  2689 : vpsadbw      ymm0, ymm0, ymm8                   ; c4 c1 7d f6 c0                       
  2690 : vpsadbw      ymm7, ymm0, ymm8                   ; c4 c1 7d f6 f8                       
  2691 : vpsadbw      ymm0, ymm7, ymm8                   ; c4 c1 45 f6 c0                       
  2692 : vpsadbw      ymm0, ymm0, ymm15                  ; c4 c1 7d f6 c7                       
  2693 : vphaddd      ymm0, ymm0, ymm0                   ; c4 e2 7d 02 c0                       
  2694 : vphaddd      ymm7, ymm0, ymm0                   ; c4 e2 7d 02 f8                       
  2695 : vphaddd      ymm0, ymm7, ymm0                   ; c4 e2 45 02 c0                       
  2696 : vphaddd      ymm0, ymm0, ymm7                   ; c4 e2 7d 02 c7                       
  2697 : vphaddd      ymm8, ymm0, ymm0                   ; c4 62 7d 02 c0                       
  2698 : vphaddd      ymm15, ymm0, ymm0                  ; c4 62 7d 02 f8                       
  2699 : vphaddd      ymm8, ymm7, ymm0                   ; c4 62 45 02 c0                       
  2700 : vphaddd      ymm8, ymm0, ymm7                   ; c4 62 7d 02 c7                       
  2701 : vphaddd      ymm0, ymm8, ymm0                   ; c4 e2 3d 02 c0                       
  2702 : vphaddd      ymm7, ymm8, ymm0                   ; c4 e2 3d 02 f8                       
  2703 : vphaddd      ymm0, ymm15, ymm0                  ; c4 e2 05 02 c0                       
  2704 : vphaddd      ymm0, ymm8, ymm7                   ; c4 e2 3d 02 c7                       
  2705 : vphaddd      ymm0, ymm0, ymm8                   ; c4 c2 7d 02 c0                       
  2706 : vphaddd      ymm7, ymm0, ymm8                   ; c4 c2 7d 02 f8                       
  2707 : vphaddd      ymm0, ymm7, ymm8                   ; c4 c2 45 02 c0                       
  2708 : vphaddd      ymm0, ymm0, ymm15                  ; c4 c2 7d 02 c7                       
  2709 : vhaddps      ymm0, ymm0, ymm0                   ; c5 ff 7c c0                          
  2710 : vhaddps      ymm7, ymm0, ymm0                   ; c5 ff 7c f8                          
  2711 : vhaddps      ymm0, ymm7, ymm0                   ; c5 c7 7c c0                          
  2712 : vhaddps      ymm0, ymm0, ymm7                   ; c5 ff 7c c7                          
  2713 : vhaddps      ymm8, ymm0, ymm0                   ; c5 7f 7c c0                          
  2714 : vhaddps      ymm15, ymm0, ymm0                  ; c5 7f 7c f8                          
  2715 : vhaddps      ymm8, ymm7, ymm0                   ; c5 47 7c c0                          
  2716 : vhaddps      ymm8, ymm0, ymm7                   ; c5 7f 7c c7                          
  2717 : vhaddps      ymm0, ymm8, ymm0                   ; c5 bf 7c c0                          
  2718 : vhaddps      ymm7, ymm8, ymm0                   ; c5 bf 7c f8                          
  2719 : vhaddps      ymm0, ymm15, ymm0                  ; c5 87 7c c0                          
  2720 : vhaddps      ymm0, ymm8, ymm7                   ; c5 bf 7c c7                          
  2721 : vhaddps      ymm0, ymm0, ymm8                   ; c4 c1 7f 7c c0                       
  2722 : vhaddps      ymm7, ymm0, ymm8                   ; c4 c1 7f 7c f8                       
  2723 : vhaddps      ymm0, ymm7, ymm8                   ; c4 c1 47 7c c0                       
  2724 : vhaddps      ymm0, ymm0, ymm15                  ; c4 c1 7f 7c c7                       
  2725 : vaddss       xmm0, xmm0, xmm0                   ; c5 fa 58 c0                          
  2726 : vaddss       xmm7, xmm0, xmm0                   ; c5 fa 58 f8                          
  2727 : vaddss       xmm0, xmm7, xmm0                   ; c5 c2 58 c0                          
  2728 : vaddss       xmm0, xmm0, xmm7                   ; c5 fa 58 c7                          
  2729 : vaddss       xmm8, xmm0, xmm0                   ; c5 7a 58 c0                          
  2730 : vaddss       xmm15, xmm0, xmm0                  ; c5 7a 58 f8                          
  2731 : vaddss       xmm8, xmm7, xmm0                   ; c5 42 58 c0                          
  2732 : vaddss       xmm8, xmm0, xmm7                   ; c5 7a 58 c7                          
  2733 : vaddss       xmm0, xmm8, xmm0                   ; c5 ba 58 c0                          
  2734 : vaddss       xmm7, xmm8, xmm0                   ; c5 ba 58 f8                          
  2735 : vaddss       xmm0, xmm15, xmm0                  ; c5 82 58 c0                          
  2736 : vaddss       xmm0, xmm8, xmm7                   ; c5 ba 58 c7                          
  2737 : vaddss       xmm0, xmm0, xmm8                   ; c4 c1 7a 58 c0                       
  2738 : vaddss       xmm7, xmm0, xmm8                   ; c4 c1 7a 58 f8                       
  2739 : vaddss       xmm0, xmm7, xmm8                   ; c4 c1 42 58 c0                       
  2740 : vaddss       xmm0, xmm0, xmm15                  ; c4 c1 7a 58 c7                       
  2741 : vhaddpd      ymm0, ymm0, ymm0                   ; c5 fd 7c c0                          
  2742 : vhaddpd      ymm7, ymm0, ymm0                   ; c5 fd 7c f8                          
  2743 : vhaddpd      ymm0, ymm7, ymm0                   ; c5 c5 7c c0                          
  2744 : vhaddpd      ymm0, ymm0, ymm7                   ; c5 fd 7c c7                          
  2745 : vhaddpd      ymm8, ymm0, ymm0                   ; c5 7d 7c c0                          
  2746 : vhaddpd      ymm15, ymm0, ymm0                  ; c5 7d 7c f8                          
  2747 : vhaddpd      ymm8, ymm7, ymm0                   ; c5 45 7c c0                          
  2748 : vhaddpd      ymm8, ymm0, ymm7                   ; c5 7d 7c c7                          
  2749 : vhaddpd      ymm0, ymm8, ymm0                   ; c5 bd 7c c0                          
  2750 : vhaddpd      ymm7, ymm8, ymm0                   ; c5 bd 7c f8                          
  2751 : vhaddpd      ymm0, ymm15, ymm0                  ; c5 85 7c c0                          
  2752 : vhaddpd      ymm0, ymm8, ymm7                   ; c5 bd 7c c7                          
  2753 : vhaddpd      ymm0, ymm0, ymm8                   ; c4 c1 7d 7c c0                       
  2754 : vhaddpd      ymm7, ymm0, ymm8                   ; c4 c1 7d 7c f8                       
  2755 : vhaddpd      ymm0, ymm7, ymm8                   ; c4 c1 45 7c c0                       
  2756 : vhaddpd      ymm0, ymm0, ymm15                  ; c4 c1 7d 7c c7                       
  2757 : vaddsd       xmm0, xmm0, xmm0                   ; c5 fb 58 c0                          
  2758 : vaddsd       xmm7, xmm0, xmm0                   ; c5 fb 58 f8                          
  2759 : vaddsd       xmm0, xmm7, xmm0                   ; c5 c3 58 c0                          
  2760 : vaddsd       xmm0, xmm0, xmm7                   ; c5 fb 58 c7                          
  2761 : vaddsd       xmm8, xmm0, xmm0                   ; c5 7b 58 c0                          
  2762 : vaddsd       xmm15, xmm0, xmm0                  ; c5 7b 58 f8                          
  2763 : vaddsd       xmm8, xmm7, xmm0                   ; c5 43 58 c0                          
  2764 : vaddsd       xmm8, xmm0, xmm7                   ; c5 7b 58 c7                          
  2765 : vaddsd       xmm0, xmm8, xmm0                   ; c5 bb 58 c0                          
  2766 : vaddsd       xmm7, xmm8, xmm0                   ; c5 bb 58 f8                          
  2767 : vaddsd       xmm0, xmm15, xmm0                  ; c5 83 58 c0                          
  2768 : vaddsd       xmm0, xmm8, xmm7                   ; c5 bb 58 c7                          
  2769 : vaddsd       xmm0, xmm0, xmm8                   ; c4 c1 7b 58 c0                       
  2770 : vaddsd       xmm7, xmm0, xmm8                   ; c4 c1 7b 58 f8                       
  2771 : vaddsd       xmm0, xmm7, xmm8                   ; c4 c1 43 58 c0                       
  2772 : vaddsd       xmm0, xmm0, xmm15                  ; c4 c1 7b 58 c7                       
  2773 : call         rax                                ; ff d0                                
  2774 : call         rdi                                ; ff d7                                
  2775 : call         r8                                 ; 41 ff d0                             
  2776 : call         r15                                ; 41 ff d7                             
  2777 : call         qword ptr [rsp + 0x0100]           ; ff 94 24 00 01 00 00                 
