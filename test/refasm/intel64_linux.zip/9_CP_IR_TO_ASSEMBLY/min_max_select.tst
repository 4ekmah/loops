min_max_select(i0, i1, i2, i3)
     0 : sub    rsp, 0x038                     ; 48 81 ec 38 00 00 00                 
     1 : mov    qword ptr [rsp + 0x008], rdx   ; 48 89 94 24 08 00 00 00              
     2 : mov    qword ptr [rsp], rcx           ; 48 89 8c 24 00 00 00 00              
     3 : mov    qword ptr [rsp + 0x028], r13   ; 4c 89 ac 24 28 00 00 00              
     4 : xor    rax, rax                       ; 48 31 c0                             
     5 : mov    qword ptr [rsp + 0x018], 0     ; 48 c7 84 24 18 00 00 00 00 00 00 00  
     6 : mov    qword ptr [rsp + 0x010], 0     ; 48 c7 84 24 10 00 00 00 00 00 00 00  
     7 : movsxd rdx, dword ptr [rdi]           ; 48 63 17                             
     8 : mov    rcx, rdx                       ; 48 89 d1                             
     9 : mov    qword ptr [rsp + 0x020], rsi   ; 48 89 b4 24 20 00 00 00              
    10 : shl    qword ptr [rsp + 0x020], 0x002 ; 48 c1 a4 24 20 00 00 00 02           
    11 :        __loops_label_0:               ;                                      
    12 : cmp    rax, qword ptr [rsp + 0x020]   ; 48 3b 84 24 20 00 00 00              
    13 : jge    __loops_label_2                ; 0f 8d 4b 00 00 00                    
    14 : movsxd rsi, dword ptr [rdi + rax]     ; 48 63 34 07                          
    15 : cmp    rsi, rdx                       ; 48 39 d6                             
    16 : mov    r13, qword ptr [rsp + 0x018]   ; 4c 8b ac 24 18 00 00 00              
    17 : cmovl  r13, rax                       ; 4c 0f 4c e8                          
    18 : mov    qword ptr [rsp + 0x018], r13   ; 4c 89 ac 24 18 00 00 00              
    19 : cmp    rdx, rsi                       ; 48 39 f2                             
    20 : cmovg  rdx, rsi                       ; 48 0f 4f d6                          
    21 : cmp    rsi, rcx                       ; 48 39 ce                             
    22 : mov    r13, qword ptr [rsp + 0x010]   ; 4c 8b ac 24 10 00 00 00              
    23 : cmovg  r13, rax                       ; 4c 0f 4f e8                          
    24 : mov    qword ptr [rsp + 0x010], r13   ; 4c 89 ac 24 10 00 00 00              
    25 : cmp    rcx, rsi                       ; 48 39 f1                             
    26 : cmovl  rcx, rsi                       ; 48 0f 4c ce                          
    27 : add    rax, 0x004                     ; 48 05 04 00 00 00                    
    28 : jmp    __loops_label_0                ; e9 a7 ff ff ff                       
    29 :        __loops_label_2:               ;                                      
    30 : mov    r13, qword ptr [rsp + 0x018]   ; 4c 8b ac 24 18 00 00 00              
    31 : mov    rdi, r13                       ; 4c 89 ef                             
    32 : sar    rdi, 0x002                     ; 48 c1 ff 02                          
    33 : mov    r13, qword ptr [rsp + 0x010]   ; 4c 8b ac 24 10 00 00 00              
    34 : mov    rsi, r13                       ; 4c 89 ee                             
    35 : sar    rsi, 0x002                     ; 48 c1 fe 02                          
    36 : mov    r13, qword ptr [rsp + 0x008]   ; 4c 8b ac 24 08 00 00 00              
    37 : mov    dword ptr [r13], edi           ; 41 89 7d 00                          
    38 : mov    r13, qword ptr [rsp]           ; 4c 8b ac 24 00 00 00 00              
    39 : mov    dword ptr [r13], esi           ; 41 89 75 00                          
    40 : xor    rax, rax                       ; 48 31 c0                             
    41 : mov    r13, qword ptr [rsp + 0x028]   ; 4c 8b ac 24 28 00 00 00              
    42 : add    rsp, 0x038                     ; 48 81 c4 38 00 00 00                 
    43 : ret                                   ; c3                                   
