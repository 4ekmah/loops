min_max_select(i0, i1, i2, i3)
     0 : mov                    i4, 0           
     1 : mov                    i5, 0           
     2 : mov                    i6, 0           
     3 : load.i32               i7, i0          
     4 : mov                    i8, i7          
     5 : shl                    i1, i1, 2       
     6 : annotation:whilecstart 0               
     7 : cmp                    i4, i1          
     8 : jmp_ge                 __loops_label_2 
     9 : annotation:whilecend                   
    10 : load.i32               i9, i0, i4      
    11 : cmp                    i9, i7          
    12 : select_gt              i5, i4, i5      
    13 : cmp                    i9, i7          
    14 : select_gt              i7, i9, i7      
    15 : cmp                    i9, i8          
    16 : select_gt              i6, i4, i6      
    17 : cmp                    i9, i8          
    18 : select_gt              i8, i9, i8      
    19 : add                    i4, i4, 4       
    20 : annotation:endwhile    0, 2            
    21 : sar                    i5, i5, 2       
    22 : sar                    i6, i6, 2       
    23 : store.i32              i2, i5          
    24 : store.i32              i3, i6          
    25 : mov                    iR, 0           
    26 : ret                                    
