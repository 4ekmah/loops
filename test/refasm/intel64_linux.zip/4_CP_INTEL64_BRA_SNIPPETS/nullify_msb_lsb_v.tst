nullify_msb_lsb_v(i0, i1, i2, i3)
     0 : mov                    i4, 0           
     1 : mul                    i3, i3, 4       
     2 : mov                    i5, 1           
     3 : vdef.u32               v11             
     4 : setlane.u32            v11, 0, i5      
     5 : broadcast.u32          v0, v11, 0      
     6 : annotation:whilecstart 0               
     7 : cmp                    i4, i3          
     8 : jmp_ge                 __loops_label_2 
     9 : annotation:whilecend                   
    10 : vld.u32                v1, i0, i4      
    11 : shr.u32                v3, v1, 1       
    12 : or                     v2, v1, v3      
    13 : shr.u32                v4, v2, 2       
    14 : or                     v2, v2, v4      
    15 : shr.u32                v5, v2, 4       
    16 : or                     v2, v2, v5      
    17 : shr.u32                v6, v2, 8       
    18 : or                     v2, v2, v6      
    19 : shr.u32                v7, v2, 16      
    20 : or                     v2, v2, v7      
    21 : add.u32                v2, v2, v0      
    22 : shr.u32                v2, v2, 1       
    23 : xor                    v2, v2, v1      
    24 : vst.u32                i1, i4, v2      
    25 : sub.u32                v10, v1, v0     
    26 : mov                    i6, 255         
    27 : vdef.u8                v12             
    28 : setlane.u8             v12, 0, i6      
    29 : broadcast.u8           v12, v12, 0     
    30 : xor                    v9, v10, v12    
    31 : and                    v8, v1, v9      
    32 : xor                    v8, v8, v1      
    33 : vst.u32                i2, i4, v8      
    34 : add                    i4, i4, 32      
    35 : annotation:endwhile    0, 2            
    36 : ret                                    
