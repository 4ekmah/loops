fixed_power_v_uint32_t_0(i0, i1, i2)
     0 : mov                    i3, 0           
     1 : mul                    i2, i2, 4       
     2 : annotation:whilecstart 0               
     3 : cmp                    i3, i2          
     4 : jmp_ge                 __loops_label_2 
     5 : annotation:whilecend                   
     6 : vld.u32                v0, i0, i3      
     7 : mov                    i4, 1           
     8 : vdef.u32               v2              
     9 : setlane.u32            v2, 0, i4       
    10 : broadcast.u32          v1, v2, 0       
    11 : vst.u32                i1, i3, v1      
    12 : add                    i3, i3, 32      
    13 : annotation:endwhile    0, 2            
    14 : mov                    iR, 0           
    15 : ret                                    
