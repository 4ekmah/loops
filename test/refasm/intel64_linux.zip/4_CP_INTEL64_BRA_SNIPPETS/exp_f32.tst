exp_f32(i0, i1, i2)
     0 : mov                    i4, -1028603739    
     1 : vdef.fp32              v33                
     2 : setlane.fp32           v33, 0, i4         
     3 : broadcast.fp32         v0, v33, 0         
     4 : mov                    i5, 1118879909     
     5 : vdef.fp32              v34                
     6 : setlane.fp32           v34, 0, i5         
     7 : broadcast.fp32         v1, v34, 0         
     8 : mov                    i6, 1056964608     
     9 : vdef.fp32              v35                
    10 : setlane.fp32           v35, 0, i6         
    11 : broadcast.fp32         v2, v35, 0         
    12 : mov                    i7, 1065353216     
    13 : vdef.fp32              v36                
    14 : setlane.fp32           v36, 0, i7         
    15 : broadcast.fp32         v3, v36, 0         
    16 : mov                    i8, 1069066811     
    17 : vdef.fp32              v37                
    18 : setlane.fp32           v37, 0, i8         
    19 : broadcast.fp32         v4, v37, 0         
    20 : mov                    i9, -1087275008    
    21 : vdef.fp32              v38                
    22 : setlane.fp32           v38, 0, i9         
    23 : broadcast.fp32         v5, v38, 0         
    24 : mov                    i10, 962494595     
    25 : vdef.fp32              v39                
    26 : setlane.fp32           v39, 0, i10        
    27 : broadcast.fp32         v6, v39, 0         
    28 : mov                    i11, 961571175     
    29 : vdef.fp32              v40                
    30 : setlane.fp32           v40, 0, i11        
    31 : broadcast.fp32         v7, v40, 0         
    32 : mov                    i12, 985088974     
    33 : vdef.fp32              v41                
    34 : setlane.fp32           v41, 0, i12        
    35 : broadcast.fp32         v8, v41, 0         
    36 : mov                    i13, 1007192328    
    37 : vdef.fp32              v42                
    38 : setlane.fp32           v42, 0, i13        
    39 : broadcast.fp32         v9, v42, 0         
    40 : mov                    i14, 1026206145    
    41 : vdef.fp32              v43                
    42 : setlane.fp32           v43, 0, i14        
    43 : broadcast.fp32         v10, v43, 0        
    44 : mov                    i15, 1042983594    
    45 : vdef.fp32              v44                
    46 : setlane.fp32           v44, 0, i15        
    47 : broadcast.fp32         v11, v44, 0        
    48 : mov                    i16, 1056964608    
    49 : vdef.fp32              v45                
    50 : setlane.fp32           v45, 0, i16        
    51 : broadcast.fp32         v12, v45, 0        
    52 : mov                    i17, 127           
    53 : vdef.i32               v46                
    54 : setlane.i32            v46, 0, i17        
    55 : broadcast.i32          v13, v46, 0        
    56 : mov                    i3, 0              
    57 : annotation:whilecstart 0                  
    58 : cmp                    i2, 0              
    59 : jmp_le                 __loops_label_2    
    60 : annotation:whilecend                      
    61 : vld.fp32               v14, i1, i3        
    62 : min.fp32               v21, v14, v1       
    63 : max.fp32               v20, v21, v0       
    64 : fma.fp32               v24, v2, v20, v4   
    65 : floor.fp32_fp32        v23, v24           
    66 : cast.fp32_i32          v23, v23           
    67 : cast.i32_fp32          v22, v23           
    68 : fma.fp32               v19, v20, v22, v5  
    69 : fma.fp32               v18, v19, v22, v6  
    70 : fma.fp32               v29, v8, v18, v7   
    71 : fma.fp32               v28, v9, v29, v18  
    72 : fma.fp32               v27, v10, v28, v18 
    73 : fma.fp32               v26, v11, v27, v18 
    74 : fma.fp32               v25, v12, v26, v18 
    75 : mul.fp32               v30, v18, v18      
    76 : fma.fp32               v17, v18, v25, v30 
    77 : add.fp32               v16, v17, v3       
    78 : add.i32                v32, v23, v13      
    79 : sal.i32                v31, v32, 23       
    80 : mul.fp32               v15, v16, v31      
    81 : vst.fp32               i0, i3, v15        
    82 : add                    i3, i3, 32         
    83 : sub                    i2, i2, 8          
    84 : annotation:endwhile    0, 2               
    85 : ret                                       
