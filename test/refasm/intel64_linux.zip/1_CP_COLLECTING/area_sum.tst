area_sum(i0, i1)
     0 : mov                    i2, 0                              
     1 : annotation:whilecstart 0                                  
     2 : cmp                    i1, 0                              
     3 : jmp_le                 __loops_label_2                    
     4 : annotation:whilecend                                      
     5 : load.i8                i3, i0                             
     6 : mov                    i4, 922220968                      
     7 : mov                    i5, 922221207                      
     8 : mov                    i6, 922221380                      
     9 : cmp                    i3, 1                              
    10 : select_eq              i7, i5, i6                         
    11 : cmp                    i3, 0                              
    12 : select_eq              i8, i4, i7                         
    13 : mov                    i9, 922220620                      
    14 : mov                    i10, 922220741                     
    15 : mov                    i11, 922220804                     
    16 : cmp                    i3, 1                              
    17 : select_eq              i12, i10, i11                      
    18 : cmp                    i3, 0                              
    19 : select_eq              i13, i9, i12                       
    20 : call_noret             [i8](i0)                           
    21 : call                   [i13](i14, i0)                     
    22 : call                   [0x0000555C36F7F805](i15, i2, i14) 
    23 : mov                    i2, i15                            
    24 : add                    i0, i0, 56                         
    25 : sub                    i1, i1, 1                          
    26 : annotation:endwhile    0, 2                               
    27 : mov                    iR, i2                             
    28 : ret                                                       
