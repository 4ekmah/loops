fixed_power_v_uint32_t_9(i0, i1, i2)
     0 : mov                    i3, 0           
     1 : mul                    i2, i2, 4       
     2 : annotation:whilecstart 0               
     3 : cmp                    i3, i2          
     4 : jmp_ge                 __loops_label_2 
     5 : annotation:whilecend                   
     6 : vld.u32                v0, i0, i3      
     7 : mul.u32                v4, v0, v0      
     8 : mul.u32                v3, v4, v4      
     9 : mul.u32                v2, v3, v3      
    10 : mul.u32                v1, v0, v2      
    11 : vst.u32                i1, i3, v1      
    12 : add                    i3, i3, 32      
    13 : annotation:endwhile    0, 2            
    14 : mov                    iR, 0           
    15 : ret                                    
