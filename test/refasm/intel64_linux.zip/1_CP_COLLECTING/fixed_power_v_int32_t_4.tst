fixed_power_v_int32_t_4(i0, i1, i2)
     0 : mov                    i3, 0           
     1 : mul                    i2, i2, 4       
     2 : annotation:whilecstart 0               
     3 : cmp                    i3, i2          
     4 : jmp_ge                 __loops_label_2 
     5 : annotation:whilecend                   
     6 : vld.i32                v0, i0, i3      
     7 : mul.i32                v2, v0, v0      
     8 : mul.i32                v1, v2, v2      
     9 : vst.i32                i1, i3, v1      
    10 : add                    i3, i3, 32      
    11 : annotation:endwhile    0, 2            
    12 : mov                    iR, 0           
    13 : ret                                    
