fixed_power_v_uint32_t_9(i0, i1, i2)
     0 : sub                    i4, i4, 40      
     1 : mov                    i1, 0           
     2 : mov                    i2, i2          
     3 : mul                    i2, i2, 4       
     4 : mov                    i0, i2          
     5 : annotation:whilecstart 0               
     6 : cmp                    i1, i0          
     7 : jmp_ge                 __loops_label_2 
     8 : annotation:whilecend                   
     9 : vld.u32                v0, i7, i1      
    10 : mul.u32                v1, v0, v0      
    11 : mul.u32                v1, v1, v1      
    12 : mul.u32                v1, v1, v1      
    13 : mul.u32                v0, v0, v1      
    14 : vst.u32                i6, i1, v0      
    15 : add                    i1, i1, 32      
    16 : annotation:endwhile    0, 2            
    17 : mov                    i0, 0           
    18 : ret                                    
    19 : add                    i4, i4, 40      
