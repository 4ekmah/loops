nullify_msb_lsb_v(i0, i1, i2, i3)
     0 : sub                    i4, i4, 40      
     1 : spill                  3, i13          
     2 : mov                    s2, 0           
     3 : mov                    i1, i1          
     4 : mul                    i1, i1, 4       
     5 : mov                    i0, 1           
     6 : vdef.u32               v1              
     7 : setlane.u32            v1, 0, i0       
     8 : broadcast.u32          v0, v1, 0       
     9 : spill                  1, i1           
    10 : annotation:whilecstart 0               
    11 : unspill                i13, 1          
    12 : cmp                    s2, i13         
    13 : jmp_ge                 __loops_label_2 
    14 : annotation:whilecend                   
    15 : unspill                i13, 2          
    16 : vld.u32                v1, i7, i13     
    17 : shr.u32                v2, v1, 1       
    18 : or                     v2, v1, v2      
    19 : shr.u32                v3, v2, 2       
    20 : or                     v2, v2, v3      
    21 : shr.u32                v3, v2, 4       
    22 : or                     v2, v2, v3      
    23 : shr.u32                v3, v2, 8       
    24 : or                     v2, v2, v3      
    25 : shr.u32                v3, v2, 16      
    26 : or                     v2, v2, v3      
    27 : add.u32                v2, v2, v0      
    28 : shr.u32                v2, v2, 1       
    29 : xor                    v2, v2, v1      
    30 : unspill                i13, 2          
    31 : vst.u32                i6, i13, v2     
    32 : sub.u32                v2, v1, v0      
    33 : mov                    i0, 255         
    34 : vdef.u8                v3              
    35 : setlane.u8             v3, 0, i0       
    36 : broadcast.u8           v3, v3, 0       
    37 : xor                    v2, v2, v3      
    38 : and                    v2, v1, v2      
    39 : xor                    v1, v2, v1      
    40 : unspill                i13, 2          
    41 : vst.u32                i2, i13, v1     
    42 : add                    s2, s2, 32      
    43 : annotation:endwhile    0, 2            
    44 : ret                                    
    45 : unspill                i13, 3          
    46 : add                    i4, i4, 40      
