fixed_power_v_float_0(i0, i1, i2)
     0 : sub                    i4, i4, 40      
     1 : mov                    i1, 0           
     2 : mov                    i2, i2          
     3 : mul                    i2, i2, 4       
     4 : spill                  4, i2           
     5 : annotation:whilecstart 0               
     6 : cmp                    i1, s4          
     7 : jmp_ge                 __loops_label_2 
     8 : annotation:whilecend                   
     9 : vld.fp32               v0, i7, i1      
    10 : mov                    i0, 1065353216  
    11 : vdef.fp32              v0              
    12 : setlane.fp32           v0, 0, i0       
    13 : broadcast.fp32         v0, v0, 0       
    14 : vst.fp32               i6, i1, v0      
    15 : add                    i1, i1, 32      
    16 : annotation:endwhile    0, 2            
    17 : mov                    i0, 0           
    18 : ret                                    
    19 : add                    i4, i4, 40      
