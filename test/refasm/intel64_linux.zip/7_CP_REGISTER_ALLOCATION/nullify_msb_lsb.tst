nullify_msb_lsb(i0, i1, i2)
     0 : mov       i1, i7     
     1 : shr       i1, i1, 1  
     2 : mov       i1, i1     
     3 : or        i1, i1, i7 
     4 : mov       i0, i1     
     5 : shr       i0, i0, 2  
     6 : mov       i0, i0     
     7 : or        i0, i0, i1 
     8 : mov       i1, i0     
     9 : shr       i1, i1, 4  
    10 : mov       i1, i1     
    11 : or        i1, i1, i0 
    12 : mov       i0, i1     
    13 : shr       i0, i0, 8  
    14 : mov       i0, i0     
    15 : or        i0, i0, i1 
    16 : mov       i1, i0     
    17 : shr       i1, i1, 16 
    18 : mov       i1, i1     
    19 : or        i1, i1, i0 
    20 : mov       i0, i1     
    21 : shr       i0, i0, 32 
    22 : mov       i0, i0     
    23 : or        i0, i0, i1 
    24 : mov       i0, i0     
    25 : add       i0, i0, 1  
    26 : mov       i0, i0     
    27 : shr       i0, i0, 1  
    28 : mov       i0, i0     
    29 : xor       i0, i0, i7 
    30 : store.u64 i2, i0     
    31 : sub       i2, i7, 1  
    32 : mov       i2, i2     
    33 : not       i2, i2     
    34 : mov       i2, i2     
    35 : and       i2, i2, i7 
    36 : mov       i7, i7     
    37 : xor       i7, i7, i2 
    38 : store.u64 i6, i7     
    39 : ret                  
