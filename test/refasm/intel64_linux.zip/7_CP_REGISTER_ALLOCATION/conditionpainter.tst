conditionpainter(i0)
     0 : sub                    i4, i4, 56      
     1 : spill                  5, i13          
     2 : mov                    i13, -5         
     3 : spill                  2, i13          
     4 : annotation:whilecstart 0               
     5 : cmp                    s2, 5           
     6 : jmp_gt                 __loops_label_2 
     7 : annotation:whilecend                   
     8 : mov                    i6, s2          
     9 : add                    i6, i6, 5       
    10 : mov                    i6, i6          
    11 : mul                    i6, i6, 11      
    12 : mov                    s1, i6          
    13 : unspill                i13, 1          
    14 : mul                    i13, i13, 8     
    15 : spill                  1, i13          
    16 : mov                    i13, -5         
    17 : spill                  0, i13          
    18 : annotation:whilecstart 3               
    19 : cmp                    s0, 5           
    20 : jmp_gt                 __loops_label_5 
    21 : annotation:whilecend                   
    22 : mov                    i0, s0          
    23 : add                    i0, i0, 3       
    24 : mov                    i1, 0           
    25 : cmp                    s2, i0          
    26 : iverson_ge             i1              
    27 : mov                    i0, 0           
    28 : cmp                    s2, 4           
    29 : iverson_le             i0              
    30 : mov                    i0, i0          
    31 : and                    i0, i0, i1      
    32 : mov                    i1, 0           
    33 : cmp                    s0, -2          
    34 : iverson_ge             i1              
    35 : mov                    i1, i1          
    36 : and                    i1, i1, i0      
    37 : mov                    i0, 0           
    38 : cmp                    s0, 0           
    39 : iverson_le             i0              
    40 : mov                    i0, i0          
    41 : and                    i0, i0, i1      
    42 : unspill                i13, 0          
    43 : sub                    i1, i13, 1      
    44 : mov                    i2, 0           
    45 : cmp                    s2, i1          
    46 : iverson_le             i2              
    47 : mov                    i1, 0           
    48 : cmp                    s0, 0           
    49 : iverson_ge             i1              
    50 : mov                    i1, i1          
    51 : and                    i1, i1, i2      
    52 : mov                    i2, 0           
    53 : cmp                    s2, 0           
    54 : iverson_le             i2              
    55 : mov                    i2, i2          
    56 : and                    i2, i2, i1      
    57 : mov                    i1, s0          
    58 : mul                    i1, i1, s0      
    59 : mov                    i6, s2          
    60 : mul                    i6, i6, s2      
    61 : mov                    i6, i6          
    62 : add                    i6, i6, i1      
    63 : mov                    i1, 0           
    64 : cmp                    i6, 9           
    65 : iverson_le             i1              
    66 : mov                    i1, i1          
    67 : and                    i1, i1, i2      
    68 : mov                    s3, i1          
    69 : or                     s3, s3, i0      
    70 : mov                    i6, 2           
    71 : mov                    s4, 0           
    72 : mov                    i0, 0           
    73 : cmp                    s0, 2           
    74 : iverson_ge             i0              
    75 : mov                    i1, 0           
    76 : cmp                    s0, 4           
    77 : iverson_le             i1              
    78 : mov                    i1, i1          
    79 : and                    i1, i1, i0      
    80 : mov                    i0, 0           
    81 : cmp                    s2, 1           
    82 : iverson_ge             i0              
    83 : mov                    i2, 0           
    84 : cmp                    s2, 3           
    85 : iverson_le             i2              
    86 : mov                    i2, i2          
    87 : and                    i2, i2, i0      
    88 : mov                    i2, i2          
    89 : or                     i2, i2, i1      
    90 : mov                    i1, s0          
    91 : mul                    i1, i1, s0      
    92 : mov                    i0, s2          
    93 : mul                    i0, i0, s2      
    94 : mov                    i0, i0          
    95 : add                    i0, i0, i1      
    96 : mov                    i1, 0           
    97 : cmp                    i0, 16          
    98 : iverson_le             i1              
    99 : mov                    i1, i1          
   100 : and                    i1, i1, i2      
   101 : cmp                    i1, 0           
   102 : unspill                i13, 4          
   103 : select_ne              i6, i6, i13     
   104 : mov                    i6, i6          
   105 : add                    i6, i6, s3      
   106 : annotation:ifcstart                    
   107 : mov                    i2, s2          
   108 : mul                    i2, i2, 2       
   109 : cmp                    i2, s0          
   110 : jmp_gt                 __loops_label_8 
   111 : mov                    i2, s0          
   112 : add                    i2, i2, 3       
   113 : mov                    i2, i2          
   114 : neg                    i2, i2          
   115 : mov                    i1, s0          
   116 : add                    i1, i1, 3       
   117 : mov                    i1, i1          
   118 : mul                    i1, i1, i2      
   119 : cmp                    s2, i1          
   120 : jmp_le                 __loops_label_9 
   121 : __loops_label_8:                       
   122 : mov                    i2, s0          
   123 : mul                    i2, i2, 2       
   124 : cmp                    s2, i2          
   125 : jmp_gt                 __loops_label_7 
   126 : mov                    i2, s0          
   127 : add                    i2, i2, 3       
   128 : mov                    i2, i2          
   129 : neg                    i2, i2          
   130 : mov                    i1, s0          
   131 : add                    i1, i1, 3       
   132 : mov                    i1, i1          
   133 : mul                    i1, i1, i2      
   134 : cmp                    s2, i1          
   135 : jmp_gt                 __loops_label_7 
   136 : __loops_label_9:                       
   137 : cmp                    s0, 0           
   138 : jmp_gt                 __loops_label_7 
   139 : annotation:ifcend                      
   140 : add                    i6, i6, 3       
   141 : annotation:endif       7               
   142 : mov                    i2, s0          
   143 : add                    i2, i2, 5       
   144 : mov                    i2, i2          
   145 : shl                    i2, i2, 3       
   146 : mov                    i2, i2          
   147 : add                    i2, i2, s1      
   148 : store.i64              i7, i2, i6      
   149 : add                    s0, s0, 1       
   150 : annotation:endwhile    3, 5            
   151 : add                    s2, s2, 1       
   152 : annotation:endwhile    0, 2            
   153 : ret                                    
   154 : unspill                i13, 5          
   155 : add                    i4, i4, 56      
