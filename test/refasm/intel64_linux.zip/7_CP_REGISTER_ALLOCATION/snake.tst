snake(i0, i1, i2)
     0 : sub                    i4, i4, 744     
     1 : spill                  90, i13         
     2 : spill                  91, i14         
     3 : spill                  92, i5          
     4 : mov                    i5, i4          
     5 : add                    i5, i5, 736     
     6 : mov                    i1, i6          
     7 : add                    i1, i1, i2      
     8 : sub                    s84, i1, 1      
     9 : mov                    i1, 0           
    10 : mov                    s83, 1          
    11 : mov                    i13, s83        
    12 : spill                  80, i13         
    13 : neg                    s80, s80        
    14 : mov                    s85, 0          
    15 : annotation:whilecstart 0               
    16 : unspill                i13, 84         
    17 : cmp                    s85, i13        
    18 : jmp_ge                 __loops_label_2 
    19 : annotation:whilecend                   
    20 : mov                    s81, 0          
    21 : mov                    s82, 0          
    22 : annotation:ifcstart                    
    23 : mov                    i0, s85         
    24 : and                    i0, i0, 1       
    25 : cmp                    i0, 0           
    26 : jmp_eq                 __loops_label_4 
    27 : annotation:ifcend                      
    28 : sub                    i0, i2, 1       
    29 : cmp                    i0, s85         
    30 : unspill                i13, 85         
    31 : select_gt              i14, i0, i13    
    32 : spill                  81, i14         
    33 : unspill                i13, 85         
    34 : sub                    s86, i13, i0    
    35 : mov                    s87, 0          
    36 : cmp                    s85, i0         
    37 : unspill                i13, 87         
    38 : select_gt              i14, s86, i13   
    39 : spill                  82, i14         
    40 : annotation:else        4, 5            
    41 : sub                    s88, i6, 1      
    42 : unspill                i13, 85         
    43 : sub                    i0, i13, s88    
    44 : mov                    s89, 0          
    45 : unspill                i13, 88         
    46 : cmp                    s85, i13        
    47 : unspill                i13, 89         
    48 : select_gt              i14, i0, i13    
    49 : spill                  81, i14         
    50 : unspill                i13, 85         
    51 : cmp                    s88, i13        
    52 : unspill                i13, 85         
    53 : select_gt              i14, s88, i13   
    54 : spill                  82, i14         
    55 : annotation:endif       5               
    56 : annotation:whilecstart 6               
    57 : cmp                    s81, 0          
    58 : jmp_gt                 __loops_label_8 
    59 : cmp                    s81, i2         
    60 : jmp_ge                 __loops_label_8 
    61 : cmp                    s82, 0          
    62 : jmp_gt                 __loops_label_8 
    63 : cmp                    s82, i6         
    64 : jmp_ge                 __loops_label_8 
    65 : annotation:whilecend                   
    66 : mov                    i0, -100345469  
    67 : unspill                i13, 81         
    68 : unspill                i14, 82         
    69 : call_noret             [i0](i13, i14)  
    70 : mov                    i0, s82         
    71 : mul                    i0, i0, i2      
    72 : mov                    i0, i0          
    73 : add                    i0, i0, s81     
    74 : store.u8               i7, i0, i1      
    75 : add                    i1, i1, 1       
    76 : unspill                i13, 83         
    77 : add                    s81, s81, i13   
    78 : unspill                i13, 80         
    79 : add                    s82, s82, i13   
    80 : annotation:endwhile    6, 8            
    81 : neg                    s83, s83        
    82 : neg                    s80, s80        
    83 : add                    s85, s85, 1     
    84 : annotation:endwhile    0, 2            
    85 : ret                                    
    86 : unspill                i5, 92          
    87 : unspill                i13, 90         
    88 : unspill                i14, 91         
    89 : add                    i4, i4, 744     
