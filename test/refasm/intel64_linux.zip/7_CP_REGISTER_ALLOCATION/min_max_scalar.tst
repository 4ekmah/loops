min_max_scalar(i0, i1, i2, i3)
     0 : sub                    i4, i4, 88      
     1 : spill                  9, i13          
     2 : mov                    s6, 0           
     3 : mov                    s1, 0           
     4 : mov                    s2, 0           
     5 : load.i32               i13, i7         
     6 : spill                  3, i13          
     7 : mov                    i13, s3         
     8 : spill                  4, i13          
     9 : mov                    i6, i6          
    10 : mul                    i6, i6, 4       
    11 : spill                  5, i6           
    12 : annotation:whilecstart 0               
    13 : unspill                i13, 5          
    14 : cmp                    s6, i13         
    15 : jmp_ge                 __loops_label_2 
    16 : annotation:whilecend                   
    17 : unspill                i13, 6          
    18 : load.i32               i0, i7, i13     
    19 : annotation:ifcstart                    
    20 : cmp                    i0, s3          
    21 : jmp_ge                 __loops_label_4 
    22 : annotation:ifcend                      
    23 : mov                    s3, i0          
    24 : mov                    i13, s6         
    25 : spill                  1, i13          
    26 : annotation:endif       4               
    27 : annotation:ifcstart                    
    28 : cmp                    i0, s4          
    29 : jmp_le                 __loops_label_6 
    30 : annotation:ifcend                      
    31 : mov                    s4, i0          
    32 : mov                    i13, s6         
    33 : spill                  2, i13          
    34 : annotation:endif       6               
    35 : add                    s6, s6, 4       
    36 : annotation:endwhile    0, 2            
    37 : mov                    s7, 4           
    38 : mov                    i7, s1          
    39 : spill                  8, i2           
    40 : mov                    i0, i7          
    41 : div                    i0, i0, s7      
    42 : unspill                i2, 8           
    43 : mov                    i7, i0          
    44 : mov                    i6, s2          
    45 : spill                  8, i2           
    46 : mov                    i0, i6          
    47 : div                    i0, i0, s7      
    48 : unspill                i2, 8           
    49 : mov                    i6, i0          
    50 : store.i32              i2, i7          
    51 : store.i32              i1, i6          
    52 : mov                    i0, 0           
    53 : ret                                    
    54 : unspill                i13, 9          
    55 : add                    i4, i4, 88      
