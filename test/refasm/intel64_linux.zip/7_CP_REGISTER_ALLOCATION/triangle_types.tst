triangle_types(i0, i1, i2)
     0 : sub                 i4, i4, 40       
     1 : spill               4, i6            
     2 : annotation:ifcstart                  
     3 : cmp                 i7, 0            
     4 : jmp_le              __loops_label_0  
     5 : cmp                 s4, 0            
     6 : jmp_le              __loops_label_0  
     7 : cmp                 i2, 0            
     8 : jmp_gt              __loops_label_1  
     9 : __loops_label_0:                     
    10 : annotation:ifcend                    
    11 : mov                 i0, 0            
    12 : ret                                  
    13 : annotation:else     1, 2             
    14 : annotation:ifcstart                  
    15 : mov                 i1, s4           
    16 : add                 i1, i1, i2       
    17 : cmp                 i7, i1           
    18 : jmp_gt              __loops_label_3  
    19 : mov                 i1, i7           
    20 : add                 i1, i1, i2       
    21 : cmp                 s4, i1           
    22 : jmp_gt              __loops_label_3  
    23 : mov                 i1, i7           
    24 : add                 i1, i1, s4       
    25 : cmp                 i2, i1           
    26 : jmp_le              __loops_label_4  
    27 : __loops_label_3:                     
    28 : annotation:ifcend                    
    29 : mov                 i0, 0            
    30 : ret                                  
    31 : annotation:else     4, 5             
    32 : annotation:ifcstart                  
    33 : cmp                 i7, s4           
    34 : jmp_ne              __loops_label_7  
    35 : cmp                 i7, i2           
    36 : jmp_ne              __loops_label_7  
    37 : annotation:ifcend                    
    38 : mov                 i0, 2            
    39 : ret                                  
    40 : annotation:else     7, 8             
    41 : annotation:ifcstart                  
    42 : cmp                 i7, s4           
    43 : jmp_eq              __loops_label_9  
    44 : cmp                 i7, i2           
    45 : jmp_eq              __loops_label_9  
    46 : cmp                 s4, i2           
    47 : jmp_ne              __loops_label_10 
    48 : __loops_label_9:                     
    49 : annotation:ifcend                    
    50 : mov                 i0, 3            
    51 : ret                                  
    52 : annotation:else     10, 11           
    53 : annotation:ifcstart                  
    54 : mov                 i1, i7           
    55 : mul                 i1, i1, i7       
    56 : mov                 i0, s4           
    57 : mul                 i0, i0, s4       
    58 : mov                 i6, i2           
    59 : mul                 i6, i6, i2       
    60 : mov                 i6, i6           
    61 : add                 i6, i6, i0       
    62 : cmp                 i1, i6           
    63 : jmp_eq              __loops_label_12 
    64 : mov                 i6, s4           
    65 : mul                 i6, i6, s4       
    66 : mov                 i1, i7           
    67 : mul                 i1, i1, i7       
    68 : mov                 i0, i2           
    69 : mul                 i0, i0, i2       
    70 : mov                 i0, i0           
    71 : add                 i0, i0, i1       
    72 : cmp                 i6, i0           
    73 : jmp_eq              __loops_label_12 
    74 : mov                 i6, i2           
    75 : mul                 i6, i6, i2       
    76 : mov                 i1, i7           
    77 : mul                 i1, i1, i7       
    78 : mov                 i0, s4           
    79 : mul                 i0, i0, s4       
    80 : mov                 i0, i0           
    81 : add                 i0, i0, i1       
    82 : cmp                 i6, i0           
    83 : jmp_ne              __loops_label_13 
    84 : __loops_label_12:                    
    85 : annotation:ifcend                    
    86 : mov                 i0, 1            
    87 : ret                                  
    88 : annotation:else     13, 14           
    89 : annotation:ifcstart                  
    90 : mov                 i6, i7           
    91 : mul                 i6, i6, i7       
    92 : mov                 i1, s4           
    93 : mul                 i1, i1, s4       
    94 : mov                 i0, i2           
    95 : mul                 i0, i0, i2       
    96 : mov                 i0, i0           
    97 : add                 i0, i0, i1       
    98 : cmp                 i6, i0           
    99 : jmp_gt              __loops_label_15 
   100 : mov                 i6, s4           
   101 : mul                 i6, i6, s4       
   102 : mov                 i1, i7           
   103 : mul                 i1, i1, i7       
   104 : mov                 i0, i2           
   105 : mul                 i0, i0, i2       
   106 : mov                 i0, i0           
   107 : add                 i0, i0, i1       
   108 : cmp                 i6, i0           
   109 : jmp_gt              __loops_label_15 
   110 : mov                 i6, i2           
   111 : mul                 i6, i6, i2       
   112 : mov                 i2, i7           
   113 : mul                 i2, i2, i7       
   114 : mov                 i7, s4           
   115 : mul                 i7, i7, s4       
   116 : mov                 i7, i7           
   117 : add                 i7, i7, i2       
   118 : cmp                 i6, i7           
   119 : jmp_le              __loops_label_16 
   120 : __loops_label_15:                    
   121 : annotation:ifcend                    
   122 : mov                 i0, 5            
   123 : ret                                  
   124 : annotation:else     16, 17           
   125 : mov                 i0, 4            
   126 : ret                                  
   127 : annotation:endif    2                
   128 : annotation:endif    5                
   129 : annotation:endif    8                
   130 : annotation:endif    11               
   131 : annotation:endif    14               
   132 : annotation:endif    17               
   133 : add                 i4, i4, 40       
