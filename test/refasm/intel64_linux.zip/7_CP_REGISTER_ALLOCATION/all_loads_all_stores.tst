all_loads_all_stores(i0, i1, i2, i3, i4)
     0 : sub                    i4, i4, 104      
     1 : spill                  11, i13          
     2 : mov                    s4, 0            
     3 : mov                    s0, 0            
     4 : mov                    s1, 0            
     5 : mov                    i0, 2            
     6 : mov                    s5, 1            
     7 : cmp                    i6, 1            
     8 : unspill                i13, 5           
     9 : select_gt              i0, i0, i13      
    10 : mov                    s6, 4            
    11 : cmp                    i6, 3            
    12 : select_gt              i0, s6, i0       
    13 : mov                    s7, 8            
    14 : cmp                    i6, 5            
    15 : select_gt              i13, s7, i0      
    16 : spill                  2, i13           
    17 : mov                    i0, 2            
    18 : mov                    s8, 1            
    19 : cmp                    i1, 1            
    20 : unspill                i13, 8           
    21 : select_gt              i0, i0, i13      
    22 : mov                    s9, 4            
    23 : cmp                    i1, 3            
    24 : select_gt              i0, s9, i0       
    25 : mov                    s10, 8           
    26 : cmp                    i1, 5            
    27 : select_gt              i13, s10, i0     
    28 : spill                  3, i13           
    29 : annotation:whilecstart 0                
    30 : cmp                    s4, i8           
    31 : jmp_ge                 __loops_label_2  
    32 : annotation:whilecend                    
    33 : def                    i0               
    34 : annotation:ifcstart                     
    35 : cmp                    i6, 0            
    36 : jmp_ne                 __loops_label_4  
    37 : annotation:ifcend                       
    38 : unspill                i13, 0           
    39 : load.u8                i0, i7, i13      
    40 : annotation:else        4, 5             
    41 : annotation:ifcstart                     
    42 : cmp                    i6, 1            
    43 : jmp_ne                 __loops_label_7  
    44 : annotation:ifcend                       
    45 : unspill                i13, 0           
    46 : load.i8                i0, i7, i13      
    47 : annotation:else        7, 8             
    48 : annotation:ifcstart                     
    49 : cmp                    i6, 2            
    50 : jmp_ne                 __loops_label_10 
    51 : annotation:ifcend                       
    52 : unspill                i13, 0           
    53 : load.u16               i0, i7, i13      
    54 : annotation:else        10, 11           
    55 : annotation:ifcstart                     
    56 : cmp                    i6, 3            
    57 : jmp_ne                 __loops_label_13 
    58 : annotation:ifcend                       
    59 : unspill                i13, 0           
    60 : load.i16               i0, i7, i13      
    61 : annotation:else        13, 14           
    62 : annotation:ifcstart                     
    63 : cmp                    i6, 4            
    64 : jmp_ne                 __loops_label_16 
    65 : annotation:ifcend                       
    66 : unspill                i13, 0           
    67 : load.u32               i0, i7, i13      
    68 : annotation:else        16, 17           
    69 : annotation:ifcstart                     
    70 : cmp                    i6, 5            
    71 : jmp_ne                 __loops_label_19 
    72 : annotation:ifcend                       
    73 : unspill                i13, 0           
    74 : load.i32               i0, i7, i13      
    75 : annotation:else        19, 20           
    76 : annotation:ifcstart                     
    77 : cmp                    i6, 6            
    78 : jmp_ne                 __loops_label_22 
    79 : annotation:ifcend                       
    80 : unspill                i13, 0           
    81 : load.u64               i0, i7, i13      
    82 : annotation:else        22, 23           
    83 : unspill                i13, 0           
    84 : load.i64               i0, i7, i13      
    85 : annotation:endif       5                
    86 : annotation:endif       8                
    87 : annotation:endif       11               
    88 : annotation:endif       14               
    89 : annotation:endif       17               
    90 : annotation:endif       20               
    91 : annotation:endif       23               
    92 : annotation:ifcstart                     
    93 : cmp                    i1, 0            
    94 : jmp_ne                 __loops_label_25 
    95 : annotation:ifcend                       
    96 : unspill                i13, 1           
    97 : store.u8               i2, i13, i0      
    98 : annotation:else        25, 26           
    99 : annotation:ifcstart                     
   100 : cmp                    i1, 1            
   101 : jmp_ne                 __loops_label_28 
   102 : annotation:ifcend                       
   103 : unspill                i13, 1           
   104 : store.i8               i2, i13, i0      
   105 : annotation:else        28, 29           
   106 : annotation:ifcstart                     
   107 : cmp                    i1, 2            
   108 : jmp_ne                 __loops_label_31 
   109 : annotation:ifcend                       
   110 : unspill                i13, 1           
   111 : store.u16              i2, i13, i0      
   112 : annotation:else        31, 32           
   113 : annotation:ifcstart                     
   114 : cmp                    i1, 3            
   115 : jmp_ne                 __loops_label_34 
   116 : annotation:ifcend                       
   117 : unspill                i13, 1           
   118 : store.i16              i2, i13, i0      
   119 : annotation:else        34, 35           
   120 : annotation:ifcstart                     
   121 : cmp                    i1, 4            
   122 : jmp_ne                 __loops_label_37 
   123 : annotation:ifcend                       
   124 : unspill                i13, 1           
   125 : store.u32              i2, i13, i0      
   126 : annotation:else        37, 38           
   127 : annotation:ifcstart                     
   128 : cmp                    i1, 5            
   129 : jmp_ne                 __loops_label_40 
   130 : annotation:ifcend                       
   131 : unspill                i13, 1           
   132 : store.i32              i2, i13, i0      
   133 : annotation:else        40, 41           
   134 : annotation:ifcstart                     
   135 : cmp                    i1, 6            
   136 : jmp_ne                 __loops_label_43 
   137 : annotation:ifcend                       
   138 : unspill                i13, 1           
   139 : store.u64              i2, i13, i0      
   140 : annotation:else        43, 44           
   141 : unspill                i13, 1           
   142 : store.i64              i2, i13, i0      
   143 : annotation:endif       26               
   144 : annotation:endif       29               
   145 : annotation:endif       32               
   146 : annotation:endif       35               
   147 : annotation:endif       38               
   148 : annotation:endif       41               
   149 : annotation:endif       44               
   150 : unspill                i13, 2           
   151 : add                    s0, s0, i13      
   152 : unspill                i13, 3           
   153 : add                    s1, s1, i13      
   154 : add                    s4, s4, 1        
   155 : annotation:endwhile    0, 2             
   156 : unspill                i13, 11          
   157 : add                    i4, i4, 104      
