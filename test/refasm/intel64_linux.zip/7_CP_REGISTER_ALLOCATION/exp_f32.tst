exp_f32(i0, i1, i2)
     0 : sub                    i4, i4, 168       
     1 : mov                    i1, -1028603739   
     2 : vdef.fp32              v1                
     3 : setlane.fp32           v1, 0, i1         
     4 : broadcast.fp32         v0, v1, 0         
     5 : mov                    i1, 1118879909    
     6 : vdef.fp32              v2                
     7 : setlane.fp32           v2, 0, i1         
     8 : broadcast.fp32         v1, v2, 0         
     9 : mov                    i1, 1056964608    
    10 : vdef.fp32              v3                
    11 : setlane.fp32           v3, 0, i1         
    12 : broadcast.fp32         v2, v3, 0         
    13 : mov                    i1, 1065353216    
    14 : vdef.fp32              v4                
    15 : setlane.fp32           v4, 0, i1         
    16 : broadcast.fp32         v3, v4, 0         
    17 : mov                    i1, 1069066811    
    18 : vdef.fp32              v5                
    19 : setlane.fp32           v5, 0, i1         
    20 : broadcast.fp32         v4, v5, 0         
    21 : mov                    i1, -1087275008   
    22 : vdef.fp32              v6                
    23 : setlane.fp32           v6, 0, i1         
    24 : broadcast.fp32         v5, v6, 0         
    25 : mov                    i1, 962494595     
    26 : vdef.fp32              v7                
    27 : setlane.fp32           v7, 0, i1         
    28 : broadcast.fp32         v6, v7, 0         
    29 : mov                    i1, 961571175     
    30 : vdef.fp32              v8                
    31 : setlane.fp32           v8, 0, i1         
    32 : broadcast.fp32         v7, v8, 0         
    33 : mov                    i1, 985088974     
    34 : vdef.fp32              v9                
    35 : setlane.fp32           v9, 0, i1         
    36 : broadcast.fp32         v8, v9, 0         
    37 : mov                    i1, 1007192328    
    38 : vdef.fp32              v9                
    39 : setlane.fp32           v9, 0, i1         
    40 : broadcast.fp32         v13, v9, 0        
    41 : spill                  16, v13           
    42 : mov                    i1, 1026206145    
    43 : vdef.fp32              v9                
    44 : setlane.fp32           v9, 0, i1         
    45 : broadcast.fp32         v13, v9, 0        
    46 : spill                  12, v13           
    47 : mov                    i1, 1042983594    
    48 : vdef.fp32              v9                
    49 : setlane.fp32           v9, 0, i1         
    50 : broadcast.fp32         v13, v9, 0        
    51 : spill                  8, v13            
    52 : mov                    i1, 1056964608    
    53 : vdef.fp32              v9                
    54 : setlane.fp32           v9, 0, i1         
    55 : broadcast.fp32         v13, v9, 0        
    56 : spill                  4, v13            
    57 : mov                    i1, 127           
    58 : vdef.i32               v9                
    59 : setlane.i32            v9, 0, i1         
    60 : broadcast.i32          v13, v9, 0        
    61 : spill                  0, v13            
    62 : mov                    i1, 0             
    63 : annotation:whilecstart 0                 
    64 : cmp                    i2, 0             
    65 : jmp_le                 __loops_label_2   
    66 : annotation:whilecend                     
    67 : vld.fp32               v12, i6, i1       
    68 : min.fp32               v12, v12, v1      
    69 : max.fp32               v12, v12, v0      
    70 : mov                    v11, v2           
    71 : fma.fp32               v11, v11, v12, v4 
    72 : floor.fp32_fp32        v11, v11          
    73 : cast.fp32_i32          v11, v11          
    74 : cast.i32_fp32          v10, v11          
    75 : mov                    v12, v12          
    76 : fma.fp32               v12, v12, v10, v5 
    77 : mov                    v12, v12          
    78 : fma.fp32               v12, v12, v10, v6 
    79 : mov                    v10, v8           
    80 : fma.fp32               v10, v10, v12, v7 
    81 : unspill                v13, 16           
    82 : mov                    v9, v13           
    83 : fma.fp32               v9, v9, v10, v12  
    84 : unspill                v13, 12           
    85 : mov                    v10, v13          
    86 : fma.fp32               v10, v10, v9, v12 
    87 : unspill                v13, 8            
    88 : mov                    v9, v13           
    89 : fma.fp32               v9, v9, v10, v12  
    90 : unspill                v13, 4            
    91 : mov                    v10, v13          
    92 : fma.fp32               v10, v10, v9, v12 
    93 : mul.fp32               v9, v12, v12      
    94 : mov                    v12, v12          
    95 : fma.fp32               v12, v12, v10, v9 
    96 : add.fp32               v9, v12, v3       
    97 : unspill                v13, 0            
    98 : add.i32                v10, v11, v13     
    99 : sal.i32                v10, v10, 23      
   100 : mul.fp32               v9, v9, v10       
   101 : vst.fp32               i7, i1, v9        
   102 : add                    i1, i1, 32        
   103 : sub                    i2, i2, 8         
   104 : annotation:endwhile    0, 2              
   105 : ret                                      
   106 : add                    i4, i4, 168       
