bresenham(i0, i1, i2, i3, i4, i5, i6)
     0 : sub                    i4, i4, 120      
     1 : spill                  13, i13          
     2 : spill                  14, i14          
     3 : spill                  12, i9           
     4 : sub                    i0, i8, i2       
     5 : mov                    i9, i0           
     6 : neg                    i9, i9           
     7 : select_s               i13, i0, i9      
     8 : spill                  4, i13           
     9 : sub                    i0, i8, i2       
    10 : mov                    i9, i0           
    11 : mov                    i0, i0           
    12 : sar                    i0, i0, 63       
    13 : mov                    i9, i9           
    14 : neg                    i9, i9           
    15 : mov                    s5, i0           
    16 : x86_adc                s5, s5, i0       
    17 : unspill                i13, 12          
    18 : sub                    i0, i13, i1      
    19 : mov                    i9, i0           
    20 : neg                    i9, i9           
    21 : select_s               i9, i0, i9       
    22 : mov                    s6, i9           
    23 : neg                    s6, s6           
    24 : unspill                i13, 12          
    25 : sub                    i0, i13, i1      
    26 : mov                    i9, i0           
    27 : mov                    i0, i0           
    28 : sar                    i0, i0, 63       
    29 : mov                    i9, i9           
    30 : neg                    i9, i9           
    31 : mov                    i9, i0           
    32 : x86_adc                i9, i9, i0       
    33 : mov                    i13, s4          
    34 : spill                  8, i13           
    35 : unspill                i13, 6           
    36 : add                    s8, s8, i13      
    37 : spill                  7, i9            
    38 : annotation:whilecstart 0                
    39 : cmp                    i7, 0            
    40 : jmp_eq                 __loops_label_2  
    41 : annotation:whilecend                    
    42 : mov                    s9, i1           
    43 : unspill                i13, 9           
    44 : mul                    i13, i13, i6     
    45 : spill                  9, i13           
    46 : mov                    i13, s9          
    47 : spill                  10, i13          
    48 : add                    s10, s10, i2     
    49 : unspill                i14, 16          
    50 : unspill                i13, 10          
    51 : store.u8               i7, i13, i14     
    52 : annotation:ifcstart                     
    53 : cmp                    i2, i8           
    54 : jmp_ne                 __loops_label_4  
    55 : cmp                    i1, s12          
    56 : jmp_ne                 __loops_label_4  
    57 : annotation:ifcend                       
    58 : annotation:break       2                
    59 : annotation:endif       4                
    60 : mov                    i13, s8          
    61 : spill                  11, i13          
    62 : shl                    s11, s11, 1      
    63 : annotation:ifcstart                     
    64 : unspill                i13, 6           
    65 : cmp                    s11, i13         
    66 : jmp_gt                 __loops_label_6  
    67 : annotation:ifcend                       
    68 : annotation:ifcstart                     
    69 : cmp                    i2, i8           
    70 : jmp_ne                 __loops_label_8  
    71 : annotation:ifcend                       
    72 : annotation:break       2                
    73 : annotation:endif       8                
    74 : unspill                i13, 6           
    75 : add                    s8, s8, i13      
    76 : add                    i2, i2, s5       
    77 : annotation:endif       6                
    78 : annotation:ifcstart                     
    79 : unspill                i13, 4           
    80 : cmp                    s11, i13         
    81 : jmp_gt                 __loops_label_10 
    82 : annotation:ifcend                       
    83 : annotation:ifcstart                     
    84 : cmp                    i1, s12          
    85 : jmp_ne                 __loops_label_12 
    86 : annotation:ifcend                       
    87 : annotation:break       2                
    88 : annotation:endif       12               
    89 : unspill                i13, 4           
    90 : add                    s8, s8, i13      
    91 : add                    i1, i1, s7       
    92 : annotation:endif       10               
    93 : annotation:endwhile    0, 2             
    94 : ret                                     
    95 : unspill                i13, 13          
    96 : unspill                i14, 14          
    97 : add                    i4, i4, 120      
