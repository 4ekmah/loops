sort_double(i0, i1)
     0 : sub                    i4, i4, 696      
     1 : spill                  85, i13          
     2 : spill                  86, i5           
     3 : mov                    i5, i4           
     4 : add                    i5, i5, 688      
     5 : mov                    s82, i6          
     6 : shl                    s82, s82, 3      
     7 : unspill                i13, 82          
     8 : sub                    s83, i13, 8      
     9 : mov                    s84, 0           
    10 : annotation:whilecstart 0                
    11 : unspill                i13, 83          
    12 : cmp                    s84, i13         
    13 : jmp_ge                 __loops_label_2  
    14 : annotation:whilecend                    
    15 : mov                    i13, s84         
    16 : spill                  81, i13          
    17 : mov                    i13, s81         
    18 : spill                  80, i13          
    19 : add                    s80, s80, 8      
    20 : annotation:whilecstart 3                
    21 : unspill                i13, 82          
    22 : cmp                    s80, i13         
    23 : jmp_ge                 __loops_label_5  
    24 : annotation:whilecend                    
    25 : annotation:ifcstart                     
    26 : unspill                i13, 80          
    27 : load.fp64              i0, i7, i13      
    28 : unspill                i13, 81          
    29 : load.fp64              i1, i7, i13      
    30 : mov                    i2, -100336614   
    31 : call                   [i2](i2, i0, i1) 
    32 : cmp                    i2, 0            
    33 : jmp_eq                 __loops_label_7  
    34 : annotation:ifcend                       
    35 : mov                    i13, s80         
    36 : spill                  81, i13          
    37 : annotation:endif       7                
    38 : add                    s80, s80, 8      
    39 : annotation:endwhile    3, 5             
    40 : annotation:ifcstart                     
    41 : unspill                i13, 84          
    42 : cmp                    s81, i13         
    43 : jmp_eq                 __loops_label_9  
    44 : annotation:ifcend                       
    45 : unspill                i13, 84          
    46 : load.fp64              i2, i7, i13      
    47 : unspill                i13, 81          
    48 : load.fp64              i1, i7, i13      
    49 : unspill                i13, 81          
    50 : store.fp64             i7, i13, i2      
    51 : unspill                i13, 84          
    52 : store.fp64             i7, i13, i1      
    53 : annotation:endif       9                
    54 : add                    s84, s84, 8      
    55 : annotation:endwhile    0, 2             
    56 : ret                                     
    57 : unspill                i5, 86           
    58 : unspill                i13, 85          
    59 : add                    i4, i4, 696      
