area_sum(i0, i1)
     0 : sub                    i4, i4, 680       
     1 : spill                  83, i13           
     2 : spill                  84, i5            
     3 : mov                    i5, i4            
     4 : add                    i5, i5, 672       
     5 : mov                    s80, 0            
     6 : annotation:whilecstart 0                 
     7 : cmp                    i6, 0             
     8 : jmp_le                 __loops_label_2   
     9 : annotation:whilecend                     
    10 : load.i8                i13, i7           
    11 : spill                  81, i13           
    12 : mov                    i0, -54746182     
    13 : mov                    i2, -54745943     
    14 : mov                    i1, -54745770     
    15 : cmp                    s81, 1            
    16 : select_eq              i1, i2, i1        
    17 : cmp                    s81, 0            
    18 : select_eq              i13, i0, i1       
    19 : spill                  82, i13           
    20 : mov                    i2, -54746530     
    21 : mov                    i0, -54746409     
    22 : mov                    i1, -54746346     
    23 : cmp                    s81, 1            
    24 : select_eq              i1, i0, i1        
    25 : cmp                    s81, 0            
    26 : select_eq              i1, i2, i1        
    27 : unspill                i13, 82           
    28 : call_noret             [i13](i7)         
    29 : call                   [i1](i2, i7)      
    30 : mov                    i1, -54746601     
    31 : unspill                i13, 80           
    32 : call                   [i1](i2, i13, i2) 
    33 : mov                    s80, i2           
    34 : add                    i7, i7, 56        
    35 : sub                    i6, i6, 1         
    36 : annotation:endwhile    0, 2              
    37 : mov                    i0, s80           
    38 : ret                                      
    39 : unspill                i5, 84            
    40 : unspill                i13, 83           
    41 : add                    i4, i4, 680       
