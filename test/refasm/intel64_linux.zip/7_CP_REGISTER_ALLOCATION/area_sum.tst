area_sum(i0, i1)
     0 : sub                    i4, i4, 680       
     1 : spill                  83, i13           
     2 : spill                  84, i5            
     3 : mov                    i5, i4            
     4 : add                    i5, i5, 672       
     5 : mov                    s80, 0            
     6 : annotation:whilecstart 0                 
     7 : cmp                    i6, 0             
     8 : jmp_le                 __loops_label_2   
     9 : annotation:whilecend                     
    10 : load.i8                i13, i7           
    11 : spill                  81, i13           
    12 : mov                    i0, -1655098454   
    13 : mov                    i2, -1655098215   
    14 : mov                    i1, -1655098042   
    15 : cmp                    s81, 1            
    16 : select_eq              i1, i2, i1        
    17 : cmp                    s81, 0            
    18 : select_eq              i13, i0, i1       
    19 : spill                  82, i13           
    20 : mov                    i2, -1655098802   
    21 : mov                    i0, -1655098681   
    22 : mov                    i1, -1655098618   
    23 : cmp                    s81, 1            
    24 : select_eq              i1, i0, i1        
    25 : cmp                    s81, 0            
    26 : select_eq              i1, i2, i1        
    27 : unspill                i13, 82           
    28 : call_noret             [i13](i7)         
    29 : spill                  82, i13           
    30 : call                   [i1](i2, i7)      
    31 : mov                    i1, -1655098873   
    32 : unspill                i13, 80           
    33 : call                   [i1](i2, i13, i2) 
    34 : mov                    s80, i2           
    35 : add                    i7, i7, 56        
    36 : sub                    i6, i6, 1         
    37 : annotation:endwhile    0, 2              
    38 : mov                    i0, s80           
    39 : ret                                      
    40 : unspill                i5, 84            
    41 : unspill                i13, 83           
    42 : add                    i4, i4, 680       
