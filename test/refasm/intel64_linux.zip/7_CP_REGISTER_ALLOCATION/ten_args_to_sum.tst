ten_args_to_sum(i0, i1, i2, i3, i4, i5, i6, i7, i8, i9)
     0 : sub     i4, i4, 40 
     1 : unspill i0, 6      
     2 : mov     i7, i7     
     3 : mul     i7, i7, 1  
     4 : mov     i6, i6     
     5 : mul     i6, i6, 2  
     6 : mov     i6, i6     
     7 : add     i6, i6, i7 
     8 : mov     i2, i2     
     9 : mul     i2, i2, 3  
    10 : mov     i2, i2     
    11 : add     i2, i2, i6 
    12 : mov     i1, i1     
    13 : mul     i1, i1, 4  
    14 : mov     i1, i1     
    15 : add     i1, i1, i2 
    16 : mov     i8, i8     
    17 : mul     i8, i8, 5  
    18 : mov     i8, i8     
    19 : add     i8, i8, i1 
    20 : mov     i9, i9     
    21 : mul     i9, i9, 6  
    22 : mov     i9, i9     
    23 : add     i9, i9, i8 
    24 : mov     i0, i0     
    25 : mul     i0, i0, 7  
    26 : mov     i0, i0     
    27 : add     i0, i0, i9 
    28 : mov     i7, s7     
    29 : mul     i7, i7, 8  
    30 : mov     i7, i7     
    31 : add     i7, i7, i0 
    32 : mov     i6, s8     
    33 : mul     i6, i6, 3  
    34 : mov     i6, i6     
    35 : add     i6, i6, i7 
    36 : mov     i7, s9     
    37 : mul     i7, i7, 2  
    38 : mov     i7, i7     
    39 : add     i7, i7, i6 
    40 : mov     i0, i7     
    41 : ret                
    42 : add     i4, i4, 40 
