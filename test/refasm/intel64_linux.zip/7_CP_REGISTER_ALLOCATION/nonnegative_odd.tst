nonnegative_odd(i0, i1)
     0 : sub                    i4, i4, 72      
     1 : spill                  8, i13          
     2 : mov                    i2, 0           
     3 : mov                    i13, -4         
     4 : spill                  5, i13          
     5 : mov                    s4, i6          
     6 : unspill                i13, 4          
     7 : mul                    i13, i13, 4     
     8 : spill                  4, i13          
     9 : annotation:whilecstart 0               
    10 : cmp                    i2, s4          
    11 : jmp_ge                 __loops_label_2 
    12 : annotation:whilecend                   
    13 : load.i32               i1, i7, i2      
    14 : annotation:ifcstart                    
    15 : cmp                    i1, 0           
    16 : jmp_ge                 __loops_label_4 
    17 : annotation:ifcend                      
    18 : add                    i2, i2, 4       
    19 : annotation:continue    0               
    20 : annotation:endif       4               
    21 : mov                    i0, 2           
    22 : spill                  7, i2           
    23 : spill                  6, i0           
    24 : mov                    i0, i1          
    25 : mod                    i2, i0, s6      
    26 : mov                    i1, i2          
    27 : unspill                i2, 7           
    28 : annotation:ifcstart                    
    29 : cmp                    i1, 0           
    30 : jmp_eq                 __loops_label_6 
    31 : annotation:ifcend                      
    32 : mov                    s5, i2          
    33 : annotation:break       2               
    34 : annotation:endif       6               
    35 : add                    i2, i2, 4       
    36 : annotation:endwhile    0, 2            
    37 : mov                    i1, 4           
    38 : mov                    i7, s5          
    39 : mov                    i0, i7          
    40 : div                    i0, i0, i1      
    41 : mov                    i7, i0          
    42 : mov                    i0, i7          
    43 : ret                                    
    44 : unspill                i13, 8          
    45 : add                    i4, i4, 72      
