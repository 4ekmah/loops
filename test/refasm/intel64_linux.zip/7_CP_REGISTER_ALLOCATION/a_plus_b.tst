a_plus_b(i0, i1)
     0 : mov i6, i6     
     1 : add i6, i6, i7 
     2 : mov i0, i6     
     3 : ret            
