helloworld_call()
     0 : sub        i4, i4, 648     
     1 : spill      80, i5          
     2 : mov        i5, i4          
     3 : add        i5, i5, 640     
     4 : mov        i7, -1794464022 
     5 : spill      0, i0           
     6 : spill      1, i1           
     7 : spill      2, i2           
     8 : spill      3, i6           
     9 : spill      4, i7           
    10 : spill      5, i8           
    11 : spill      6, i9           
    12 : spill      7, i10          
    13 : spill      8, i11          
    14 : spill      12, v0          
    15 : spill      16, v1          
    16 : spill      20, v2          
    17 : spill      24, v3          
    18 : spill      28, v4          
    19 : spill      32, v5          
    20 : spill      36, v6          
    21 : spill      40, v7          
    22 : spill      44, v8          
    23 : spill      48, v9          
    24 : spill      52, v10         
    25 : spill      56, v11         
    26 : spill      60, v12         
    27 : spill      64, v13         
    28 : spill      68, v14         
    29 : spill      72, v15         
    30 : call_noret [i7]()          
    31 : unspill    i0, 0           
    32 : unspill    i1, 1           
    33 : unspill    i2, 2           
    34 : unspill    i6, 3           
    35 : unspill    i7, 4           
    36 : unspill    i8, 5           
    37 : unspill    i9, 6           
    38 : unspill    i10, 7          
    39 : unspill    i11, 8          
    40 : unspill    v0, 12          
    41 : unspill    v1, 16          
    42 : unspill    v2, 20          
    43 : unspill    v3, 24          
    44 : unspill    v4, 28          
    45 : unspill    v5, 32          
    46 : unspill    v6, 36          
    47 : unspill    v7, 40          
    48 : unspill    v8, 44          
    49 : unspill    v9, 48          
    50 : unspill    v10, 52         
    51 : unspill    v11, 56         
    52 : unspill    v12, 60         
    53 : unspill    v13, 64         
    54 : unspill    v14, 68         
    55 : unspill    v15, 72         
    56 : unspill    i5, 80          
    57 : add        i4, i4, 648     
    58 : ret                        
