exp_f32(i0, i1, i2)
     0 : sub              i4, i4, 200       
     1 : mov              i1, -1028603739   
     2 : vdef.fp32        v0                
     3 : setlane.fp32     v0, 0, i1         
     4 : broadcast.fp32   v0, v0, 0         
     5 : mov              i1, 1118879909    
     6 : vdef.fp32        v1                
     7 : setlane.fp32     v1, 0, i1         
     8 : broadcast.fp32   v1, v1, 0         
     9 : mov              i1, 1056964608    
    10 : vdef.fp32        v2                
    11 : setlane.fp32     v2, 0, i1         
    12 : broadcast.fp32   v2, v2, 0         
    13 : mov              i1, 1065353216    
    14 : vdef.fp32        v3                
    15 : setlane.fp32     v3, 0, i1         
    16 : broadcast.fp32   v3, v3, 0         
    17 : mov              i1, 1069066811    
    18 : vdef.fp32        v4                
    19 : setlane.fp32     v4, 0, i1         
    20 : broadcast.fp32   v4, v4, 0         
    21 : mov              i1, -1087275008   
    22 : vdef.fp32        v5                
    23 : setlane.fp32     v5, 0, i1         
    24 : broadcast.fp32   v5, v5, 0         
    25 : mov              i1, 962494595     
    26 : vdef.fp32        v6                
    27 : setlane.fp32     v6, 0, i1         
    28 : broadcast.fp32   v6, v6, 0         
    29 : mov              i1, 961571175     
    30 : vdef.fp32        v7                
    31 : setlane.fp32     v7, 0, i1         
    32 : broadcast.fp32   v7, v7, 0         
    33 : mov              i1, 985088974     
    34 : vdef.fp32        v8                
    35 : setlane.fp32     v8, 0, i1         
    36 : broadcast.fp32   v8, v8, 0         
    37 : mov              i1, 1007192328    
    38 : vdef.fp32        v9                
    39 : setlane.fp32     v9, 0, i1         
    40 : broadcast.fp32   v13, v9, 0        
    41 : spill            20, v13           
    42 : mov              i1, 1026206145    
    43 : vdef.fp32        v10               
    44 : setlane.fp32     v10, 0, i1        
    45 : broadcast.fp32   v13, v10, 0       
    46 : spill            16, v13           
    47 : mov              i1, 1042983594    
    48 : vdef.fp32        v11               
    49 : setlane.fp32     v11, 0, i1        
    50 : broadcast.fp32   v13, v11, 0       
    51 : spill            12, v13           
    52 : mov              i1, 1056964608    
    53 : vdef.fp32        v12               
    54 : setlane.fp32     v12, 0, i1        
    55 : broadcast.fp32   v13, v12, 0       
    56 : spill            4, v13            
    57 : mov              i1, 127           
    58 : vdef.i32         v12               
    59 : setlane.i32      v12, 0, i1        
    60 : broadcast.i32    v13, v12, 0       
    61 : spill            8, v13            
    62 : mov              i1, 0             
    63 : __loops_label_0:                   
    64 : cmp              i2, 0             
    65 : jmp_le           __loops_label_2   
    66 : vld.fp32         v12, i6, i1       
    67 : min.fp32         v12, v12, v1      
    68 : max.fp32         v12, v12, v0      
    69 : mov              v11, v2           
    70 : fma.fp32         v11, v11, v12, v4 
    71 : floor.fp32_fp32  v11, v11          
    72 : cast.fp32_i32    v11, v11          
    73 : cast.i32_fp32    v10, v11          
    74 : fma.fp32         v12, v12, v10, v5 
    75 : fma.fp32         v12, v12, v10, v6 
    76 : mov              v10, v8           
    77 : fma.fp32         v10, v10, v12, v7 
    78 : unspill          v13, 20           
    79 : spill            0, v0             
    80 : mov              v0, v10           
    81 : mov              v10, v13          
    82 : fma.fp32         v10, v10, v0, v12 
    83 : unspill          v0, 0             
    84 : unspill          v13, 16           
    85 : spill            0, v0             
    86 : mov              v0, v10           
    87 : mov              v10, v13          
    88 : fma.fp32         v10, v10, v0, v12 
    89 : unspill          v0, 0             
    90 : unspill          v13, 12           
    91 : spill            0, v0             
    92 : mov              v0, v10           
    93 : mov              v10, v13          
    94 : fma.fp32         v10, v10, v0, v12 
    95 : unspill          v0, 0             
    96 : unspill          v13, 4            
    97 : spill            0, v0             
    98 : mov              v0, v10           
    99 : mov              v10, v13          
   100 : fma.fp32         v10, v10, v0, v12 
   101 : unspill          v0, 0             
   102 : mul.fp32         v9, v12, v12      
   103 : fma.fp32         v12, v12, v10, v9 
   104 : add.fp32         v9, v12, v3       
   105 : unspill          v13, 8            
   106 : add.i32          v10, v11, v13     
   107 : sal.i32          v10, v10, 23      
   108 : mul.fp32         v9, v9, v10       
   109 : vst.fp32         i7, i1, v9        
   110 : add              i1, i1, 32        
   111 : sub              i2, i2, 8         
   112 : jmp              0                 
   113 : __loops_label_2:                   
   114 : add              i4, i4, 200       
   115 : ret                                
