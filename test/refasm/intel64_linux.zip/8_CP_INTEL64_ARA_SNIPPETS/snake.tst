snake(i0, i1, i2)
     0 : sub              i4, i4, 728     
     1 : spill            87, i7          
     2 : spill            86, i6          
     3 : spill            85, i2          
     4 : spill            88, i13         
     5 : spill            89, i14         
     6 : spill            90, i5          
     7 : mov              i5, i4          
     8 : add              i5, i5, 720     
     9 : unspill          i13, 86         
    10 : mov              i1, i13         
    11 : add              i1, i1, s85     
    12 : mov              s84, i1         
    13 : sub              s84, s84, 1     
    14 : mov              s83, 0          
    15 : mov              s80, 1          
    16 : mov              i13, s80        
    17 : neg              i13, i13        
    18 : spill            81, i13         
    19 : mov              s82, 0          
    20 : __loops_label_0:                 
    21 : unspill          i13, 84         
    22 : cmp              s82, i13        
    23 : jmp_ge           __loops_label_2 
    24 : mov              i0, 0           
    25 : mov              i1, 0           
    26 : unspill          i13, 82         
    27 : mov              i2, i13         
    28 : and              i2, i2, 1       
    29 : cmp              i2, 0           
    30 : jmp_eq           __loops_label_4 
    31 : unspill          i13, 85         
    32 : mov              i2, i13         
    33 : sub              i2, i2, 1       
    34 : unspill          i13, 82         
    35 : mov              i0, i13         
    36 : cmp              i0, i2          
    37 : select_gt        i0, i2, i0      
    38 : unspill          i13, 82         
    39 : mov              i6, i13         
    40 : sub              i6, i6, i2      
    41 : mov              i7, 0           
    42 : cmp              s82, i2         
    43 : mov              i1, i7          
    44 : select_gt        i1, i6, i1      
    45 : jmp              5               
    46 : __loops_label_4:                 
    47 : unspill          i13, 86         
    48 : mov              i7, i13         
    49 : sub              i7, i7, 1       
    50 : unspill          i13, 82         
    51 : mov              i6, i13         
    52 : sub              i6, i6, i7      
    53 : mov              i2, 0           
    54 : cmp              s82, i7         
    55 : mov              i0, i2          
    56 : select_gt        i0, i6, i0      
    57 : unspill          i13, 82         
    58 : mov              i1, i13         
    59 : cmp              i1, i7          
    60 : select_gt        i1, i7, i1      
    61 : __loops_label_5:                 
    62 : __loops_label_6:                 
    63 : cmp              i0, 0           
    64 : jmp_gt           __loops_label_8 
    65 : cmp              i0, s85         
    66 : jmp_ge           __loops_label_8 
    67 : cmp              i1, 0           
    68 : jmp_gt           __loops_label_8 
    69 : cmp              i1, s86         
    70 : jmp_ge           __loops_label_8 
    71 : mov              i7, -1313611903 
    72 : spill            0, i0           
    73 : spill            1, i1           
    74 : spill            2, i2           
    75 : spill            3, i6           
    76 : spill            4, i7           
    77 : spill            5, i8           
    78 : spill            6, i9           
    79 : spill            7, i10          
    80 : spill            8, i11          
    81 : spill            12, v0          
    82 : spill            16, v1          
    83 : spill            20, v2          
    84 : spill            24, v3          
    85 : spill            28, v4          
    86 : spill            32, v5          
    87 : spill            36, v6          
    88 : spill            40, v7          
    89 : spill            44, v8          
    90 : spill            48, v9          
    91 : spill            52, v10         
    92 : spill            56, v11         
    93 : spill            60, v12         
    94 : spill            64, v13         
    95 : spill            68, v14         
    96 : spill            72, v15         
    97 : mov              i7, i0          
    98 : mov              i6, i1          
    99 : unspill          i10, 4          
   100 : call_noret       [i10]()         
   101 : unspill          i0, 0           
   102 : unspill          i1, 1           
   103 : unspill          i2, 2           
   104 : unspill          i6, 3           
   105 : unspill          i7, 4           
   106 : unspill          i8, 5           
   107 : unspill          i9, 6           
   108 : unspill          i10, 7          
   109 : unspill          i11, 8          
   110 : unspill          v0, 12          
   111 : unspill          v1, 16          
   112 : unspill          v2, 20          
   113 : unspill          v3, 24          
   114 : unspill          v4, 28          
   115 : unspill          v5, 32          
   116 : unspill          v6, 36          
   117 : unspill          v7, 40          
   118 : unspill          v8, 44          
   119 : unspill          v9, 48          
   120 : unspill          v10, 52         
   121 : unspill          v11, 56         
   122 : unspill          v12, 60         
   123 : unspill          v13, 64         
   124 : unspill          v14, 68         
   125 : unspill          v15, 72         
   126 : mov              i7, i1          
   127 : mul              i7, i7, s85     
   128 : add              i7, i7, i0      
   129 : unspill          i13, 87         
   130 : unspill          i14, 83         
   131 : store.u8         i13, i7, i14    
   132 : add              s83, s83, 1     
   133 : add              i0, i0, s80     
   134 : add              i1, i1, s81     
   135 : jmp              6               
   136 : __loops_label_8:                 
   137 : neg              s80, s80        
   138 : neg              s81, s81        
   139 : add              s82, s82, 1     
   140 : jmp              0               
   141 : __loops_label_2:                 
   142 : unspill          i5, 90          
   143 : unspill          i13, 88         
   144 : unspill          i14, 89         
   145 : add              i4, i4, 728     
   146 : ret                              
