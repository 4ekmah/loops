ten_args_to_sum(i0, i1, i2, i3, i4, i5, i6, i7, i8, i9)
     0 : sub     i4, i4, 8  
     1 : spill   0, i13     
     2 : unspill i0, 2      
     3 : mul     i7, i7, 1  
     4 : mul     i6, i6, 2  
     5 : add     i7, i7, i6 
     6 : mul     i2, i2, 3  
     7 : add     i7, i7, i2 
     8 : mul     i1, i1, 4  
     9 : add     i7, i7, i1 
    10 : mul     i8, i8, 5  
    11 : add     i7, i7, i8 
    12 : mul     i9, i9, 6  
    13 : add     i7, i7, i9 
    14 : mul     i0, i0, 7  
    15 : add     i7, i7, i0 
    16 : unspill i13, 3     
    17 : mov     i6, i13    
    18 : mul     i6, i6, 8  
    19 : add     i7, i7, i6 
    20 : unspill i13, 4     
    21 : mov     i6, i13    
    22 : mul     i6, i6, 3  
    23 : add     i7, i7, i6 
    24 : unspill i13, 5     
    25 : mov     i6, i13    
    26 : mul     i6, i6, 2  
    27 : add     i7, i7, i6 
    28 : mov     i0, i7     
    29 : unspill i13, 0     
    30 : add     i4, i4, 8  
    31 : ret                
