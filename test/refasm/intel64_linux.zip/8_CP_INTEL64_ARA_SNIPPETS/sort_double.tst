sort_double(i0, i1)
     0 : sub              i4, i4, 696     
     1 : spill            83, i7          
     2 : spill            84, i13         
     3 : spill            85, i14         
     4 : spill            86, i5          
     5 : mov              i5, i4          
     6 : add              i5, i5, 688     
     7 : mov              s82, i6         
     8 : shl              s82, s82, 3     
     9 : unspill          i13, 82         
    10 : mov              s81, i13        
    11 : sub              s81, s81, 8     
    12 : mov              s80, 0          
    13 : __loops_label_0:                 
    14 : unspill          i13, 81         
    15 : cmp              s80, i13        
    16 : jmp_ge           __loops_label_2 
    17 : mov              i0, s80         
    18 : mov              i1, i0          
    19 : add              i1, i1, 8       
    20 : __loops_label_3:                 
    21 : cmp              i1, s82         
    22 : jmp_ge           __loops_label_5 
    23 : unspill          i13, 83         
    24 : load.fp64        i2, i13, i1     
    25 : unspill          i13, 83         
    26 : load.fp64        i6, i13, i0     
    27 : mov              i7, 922214936   
    28 : spill            0, i0           
    29 : spill            1, i1           
    30 : spill            2, i2           
    31 : spill            3, i6           
    32 : spill            4, i7           
    33 : spill            5, i8           
    34 : spill            6, i9           
    35 : spill            7, i10          
    36 : spill            8, i11          
    37 : spill            12, v0          
    38 : spill            16, v1          
    39 : spill            20, v2          
    40 : spill            24, v3          
    41 : spill            28, v4          
    42 : spill            32, v5          
    43 : spill            36, v6          
    44 : spill            40, v7          
    45 : spill            44, v8          
    46 : spill            48, v9          
    47 : spill            52, v10         
    48 : spill            56, v11         
    49 : spill            60, v12         
    50 : spill            64, v13         
    51 : spill            68, v14         
    52 : spill            72, v15         
    53 : mov              i7, i2          
    54 : unspill          i10, 4          
    55 : call_noret       [i10]()         
    56 : mov              i7, i0          
    57 : unspill          i0, 0           
    58 : unspill          i1, 1           
    59 : unspill          i2, 2           
    60 : unspill          i6, 3           
    61 : unspill          i8, 5           
    62 : unspill          i9, 6           
    63 : unspill          i10, 7          
    64 : unspill          i11, 8          
    65 : unspill          v0, 12          
    66 : unspill          v1, 16          
    67 : unspill          v2, 20          
    68 : unspill          v3, 24          
    69 : unspill          v4, 28          
    70 : unspill          v5, 32          
    71 : unspill          v6, 36          
    72 : unspill          v7, 40          
    73 : unspill          v8, 44          
    74 : unspill          v9, 48          
    75 : unspill          v10, 52         
    76 : unspill          v11, 56         
    77 : unspill          v12, 60         
    78 : unspill          v13, 64         
    79 : unspill          v14, 68         
    80 : unspill          v15, 72         
    81 : cmp              i7, 0           
    82 : jmp_eq           __loops_label_7 
    83 : mov              i0, i1          
    84 : __loops_label_7:                 
    85 : add              i1, i1, 8       
    86 : jmp              3               
    87 : __loops_label_5:                 
    88 : cmp              i0, s80         
    89 : jmp_eq           __loops_label_9 
    90 : unspill          i13, 83         
    91 : unspill          i14, 80         
    92 : load.fp64        i7, i13, i14    
    93 : unspill          i13, 83         
    94 : load.fp64        i6, i13, i0     
    95 : unspill          i13, 83         
    96 : store.fp64       i13, i0, i7     
    97 : unspill          i13, 83         
    98 : unspill          i14, 80         
    99 : store.fp64       i13, i14, i6    
   100 : __loops_label_9:                 
   101 : add              s80, s80, 8     
   102 : jmp              0               
   103 : __loops_label_2:                 
   104 : unspill          i5, 86          
   105 : unspill          i13, 84         
   106 : unspill          i14, 85         
   107 : add              i4, i4, 696     
   108 : ret                              
