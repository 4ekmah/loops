helloworld_call()
     0 : mov        i0, -54763268 
     1 : call_noret [i0]()        
     2 : ret                      
