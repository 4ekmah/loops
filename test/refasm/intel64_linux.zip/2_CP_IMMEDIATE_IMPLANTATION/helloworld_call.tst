helloworld_call()
     0 : mov        i0, -1655115540 
     1 : call_noret [i0]()          
     2 : ret                        
