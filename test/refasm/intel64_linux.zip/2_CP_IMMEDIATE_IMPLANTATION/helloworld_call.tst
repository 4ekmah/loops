helloworld_call()
     0 : mov        i0, 922203882 
     1 : call_noret [i0]()        
     2 : ret                      
