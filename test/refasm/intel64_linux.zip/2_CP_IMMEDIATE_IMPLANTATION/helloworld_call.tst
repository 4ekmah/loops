helloworld_call()
     0 : mov        i0, -100347668 
     1 : call_noret [i0]()         
     2 : ret                       
