exp_f32(i0, i1, i2)
     0 : mov                    i4, -1028603739    
     1 : vdef.fp32              v34                
     2 : setlane.fp32           v35, 0, i4         
     3 : broadcast.fp32         v0, v35, 0         
     4 : mov                    i5, 1118879909     
     5 : vdef.fp32              v36                
     6 : setlane.fp32           v37, 0, i5         
     7 : broadcast.fp32         v1, v37, 0         
     8 : mov                    i6, 1056964608     
     9 : vdef.fp32              v38                
    10 : setlane.fp32           v39, 0, i6         
    11 : broadcast.fp32         v2, v39, 0         
    12 : mov                    i7, 1065353216     
    13 : vdef.fp32              v40                
    14 : setlane.fp32           v41, 0, i7         
    15 : broadcast.fp32         v3, v41, 0         
    16 : mov                    i8, 1069066811     
    17 : vdef.fp32              v42                
    18 : setlane.fp32           v43, 0, i8         
    19 : broadcast.fp32         v4, v43, 0         
    20 : mov                    i9, -1087275008    
    21 : vdef.fp32              v44                
    22 : setlane.fp32           v45, 0, i9         
    23 : broadcast.fp32         v5, v45, 0         
    24 : mov                    i10, 962494595     
    25 : vdef.fp32              v46                
    26 : setlane.fp32           v47, 0, i10        
    27 : broadcast.fp32         v6, v47, 0         
    28 : mov                    i11, 961571175     
    29 : vdef.fp32              v48                
    30 : setlane.fp32           v49, 0, i11        
    31 : broadcast.fp32         v7, v49, 0         
    32 : mov                    i12, 985088974     
    33 : vdef.fp32              v50                
    34 : setlane.fp32           v51, 0, i12        
    35 : broadcast.fp32         v8, v51, 0         
    36 : mov                    i13, 1007192328    
    37 : vdef.fp32              v52                
    38 : setlane.fp32           v53, 0, i13        
    39 : broadcast.fp32         v9, v53, 0         
    40 : mov                    i14, 1026206145    
    41 : vdef.fp32              v54                
    42 : setlane.fp32           v55, 0, i14        
    43 : broadcast.fp32         v10, v55, 0        
    44 : mov                    i15, 1042983594    
    45 : vdef.fp32              v56                
    46 : setlane.fp32           v57, 0, i15        
    47 : broadcast.fp32         v11, v57, 0        
    48 : mov                    i16, 1056964608    
    49 : vdef.fp32              v58                
    50 : setlane.fp32           v59, 0, i16        
    51 : broadcast.fp32         v12, v59, 0        
    52 : mov                    i17, 127           
    53 : vdef.i32               v60                
    54 : setlane.i32            v61, 0, i17        
    55 : broadcast.i32          v13, v61, 0        
    56 : mov                    i3, 0              
    57 : annotation:whilecstart 0                  
    58 : cmp                    i2, 0              
    59 : jmp_le                 __loops_label_2    
    60 : annotation:whilecend                      
    61 : vld.fp32               v14, i1, i3        
    62 : min.fp32               v21, v14, v1       
    63 : max.fp32               v20, v21, v0       
    64 : fma.fp32               v25, v2, v20, v4   
    65 : floor.fp32_fp32        v23, v25           
    66 : cast.fp32_i32          v24, v23           
    67 : cast.i32_fp32          v22, v24           
    68 : fma.fp32               v19, v20, v22, v5  
    69 : fma.fp32               v18, v19, v22, v6  
    70 : fma.fp32               v30, v8, v18, v7   
    71 : fma.fp32               v29, v9, v30, v18  
    72 : fma.fp32               v28, v10, v29, v18 
    73 : fma.fp32               v27, v11, v28, v18 
    74 : fma.fp32               v26, v12, v27, v18 
    75 : mul.fp32               v31, v18, v18      
    76 : fma.fp32               v17, v18, v26, v31 
    77 : add.fp32               v16, v17, v3       
    78 : add.i32                v33, v24, v13      
    79 : sal.i32                v32, v33, 23       
    80 : mul.fp32               v15, v16, v32      
    81 : vst.fp32               i0, i3, v15        
    82 : add                    i3, i3, 32         
    83 : sub                    i2, i2, 8          
    84 : annotation:endwhile    0, 2               
    85 : ret                                       
