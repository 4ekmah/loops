fixed_power_v_float_0(i0, i1, i2)
     0 : mov                    i4, 0           
     1 : mul                    i3, i2, 4       
     2 : annotation:whilecstart 0               
     3 : cmp                    i4, i3          
     4 : jmp_ge                 __loops_label_2 
     5 : annotation:whilecend                   
     6 : vld.fp32               v0, i0, i4      
     7 : mov                    i5, 1065353216  
     8 : vdef.fp32              v2              
     9 : setlane.fp32           v3, 0, i5       
    10 : broadcast.fp32         v1, v3, 0       
    11 : vst.fp32               i1, i4, v1      
    12 : add                    i4, i4, 32      
    13 : annotation:endwhile    0, 2            
    14 : mov                    iR, 0           
    15 : ret                                    
