sort_double(i0, i1)
     0 : shl                    i2, i1, 3         
     1 : sub                    i3, i2, 8         
     2 : mov                    i4, 0             
     3 : annotation:whilecstart 0                 
     4 : cmp                    i4, i3            
     5 : jmp_ge                 __loops_label_2   
     6 : annotation:whilecend                     
     7 : mov                    i5, i4            
     8 : add                    i6, i5, 8         
     9 : annotation:whilecstart 3                 
    10 : cmp                    i6, i2            
    11 : jmp_ge                 __loops_label_5   
    12 : annotation:whilecend                     
    13 : annotation:ifcstart                      
    14 : load.fp64              i8, i0, i6        
    15 : load.fp64              i9, i0, i5        
    16 : mov                    i12, -1794452968  
    17 : call                   [i12](i7, i8, i9) 
    18 : cmp                    i7, 0             
    19 : jmp_eq                 __loops_label_7   
    20 : annotation:ifcend                        
    21 : mov                    i5, i6            
    22 : annotation:endif       7                 
    23 : add                    i6, i6, 8         
    24 : annotation:endwhile    3, 5              
    25 : annotation:ifcstart                      
    26 : cmp                    i5, i4            
    27 : jmp_eq                 __loops_label_9   
    28 : annotation:ifcend                        
    29 : load.fp64              i10, i0, i4       
    30 : load.fp64              i11, i0, i5       
    31 : store.fp64             i0, i5, i10       
    32 : store.fp64             i0, i4, i11       
    33 : annotation:endif       9                 
    34 : add                    i4, i4, 8         
    35 : annotation:endwhile    0, 2              
    36 : ret                                      
