bresenham(i0, i1, i2, i3, i4, i5, i6)
     0 : sub                    i9, i4, i2       
     1 : neg                    i7, i9           
     2 : select_s               i8, i9, i7       
     3 : sub                    i12, i4, i2      
     4 : mov                    i24, i12         
     5 : sar                    i10, i12, 63     
     6 : neg                    i25, i24         
     7 : x86_adc                i11, i10, i10    
     8 : sub                    i16, i5, i3      
     9 : neg                    i14, i16         
    10 : select_s               i15, i16, i14    
    11 : neg                    i13, i15         
    12 : sub                    i19, i5, i3      
    13 : mov                    i26, i19         
    14 : sar                    i17, i19, 63     
    15 : neg                    i27, i26         
    16 : x86_adc                i18, i17, i17    
    17 : add                    i20, i8, i13     
    18 : annotation:whilecstart 0                
    19 : cmp                    i0, 0            
    20 : jmp_eq                 __loops_label_2  
    21 : annotation:whilecend                    
    22 : mul                    i22, i3, i1      
    23 : add                    i21, i22, i2     
    24 : store.u8               i0, i21, i6      
    25 : annotation:ifcstart                     
    26 : cmp                    i2, i4           
    27 : jmp_ne                 __loops_label_4  
    28 : cmp                    i3, i5           
    29 : jmp_ne                 __loops_label_4  
    30 : annotation:ifcend                       
    31 : annotation:break       2                
    32 : annotation:endif       4                
    33 : shl                    i23, i20, 1      
    34 : annotation:ifcstart                     
    35 : cmp                    i23, i13         
    36 : jmp_gt                 __loops_label_6  
    37 : annotation:ifcend                       
    38 : annotation:ifcstart                     
    39 : cmp                    i2, i4           
    40 : jmp_ne                 __loops_label_8  
    41 : annotation:ifcend                       
    42 : annotation:break       2                
    43 : annotation:endif       8                
    44 : add                    i20, i20, i13    
    45 : add                    i2, i2, i11      
    46 : annotation:endif       6                
    47 : annotation:ifcstart                     
    48 : cmp                    i23, i8          
    49 : jmp_gt                 __loops_label_10 
    50 : annotation:ifcend                       
    51 : annotation:ifcstart                     
    52 : cmp                    i3, i5           
    53 : jmp_ne                 __loops_label_12 
    54 : annotation:ifcend                       
    55 : annotation:break       2                
    56 : annotation:endif       12               
    57 : add                    i20, i20, i8     
    58 : add                    i3, i3, i18      
    59 : annotation:endif       10               
    60 : annotation:endwhile    0, 2             
    61 : ret                                     
