min_max_select(i0, i1, i2, i3)
     0 : mov                    i5, 0           
     1 : mov                    i6, 0           
     2 : mov                    i7, 0           
     3 : load.i32               i8, i0          
     4 : mov                    i9, i8          
     5 : shl                    i4, i1, 2       
     6 : annotation:whilecstart 0               
     7 : cmp                    i5, i4          
     8 : jmp_ge                 __loops_label_2 
     9 : annotation:whilecend                   
    10 : load.i32               i10, i0, i5     
    11 : cmp                    i10, i8         
    12 : select_gt              i6, i5, i6      
    13 : cmp                    i10, i8         
    14 : select_gt              i8, i10, i8     
    15 : cmp                    i10, i9         
    16 : select_gt              i7, i5, i7      
    17 : cmp                    i10, i9         
    18 : select_gt              i9, i10, i9     
    19 : add                    i5, i5, 4       
    20 : annotation:endwhile    0, 2            
    21 : sar                    i6, i6, 2       
    22 : sar                    i7, i7, 2       
    23 : store.i32              i2, i6          
    24 : store.i32              i3, i7          
    25 : mov                    iR, 0           
    26 : ret                                    
