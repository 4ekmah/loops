bresenham(i0, i1, i2, i3, i4, i5, i6)
     0 : sub                    i4, i4, 88       
     1 : spill                  9, i13           
     2 : spill                  10, i14          
     3 : sub                    i0, i8, i2       
     4 : abs                    i13, i0          
     5 : spill                  4, i13           
     6 : sub                    i0, i8, i2       
     7 : sign                   i13, i0          
     8 : spill                  5, i13           
     9 : sub                    i0, i9, i1       
    10 : abs                    i0, i0           
    11 : neg                    s6, i0           
    12 : sub                    i0, i9, i1       
    13 : sign                   i13, i0          
    14 : spill                  8, i13           
    15 : unspill                i13, 4           
    16 : unspill                i14, 6           
    17 : add                    s7, i13, i14     
    18 : annotation:whilecstart 0                
    19 : cmp                    i7, 0            
    20 : jmp_eq                 __loops_label_2  
    21 : annotation:whilecend                    
    22 : mul                    i0, i1, i6       
    23 : add                    i0, i0, i2       
    24 : unspill                i13, 12          
    25 : store.u8               i7, i0, i13      
    26 : annotation:ifcstart                     
    27 : cmp                    i2, i8           
    28 : jmp_ne                 __loops_label_4  
    29 : cmp                    i1, i9           
    30 : jmp_ne                 __loops_label_4  
    31 : annotation:ifcend                       
    32 : annotation:break       2                
    33 : annotation:endif       4                
    34 : unspill                i13, 7           
    35 : shl                    i0, i13, 1       
    36 : annotation:ifcstart                     
    37 : cmp                    i0, s6           
    38 : jmp_gt                 __loops_label_6  
    39 : annotation:ifcend                       
    40 : annotation:ifcstart                     
    41 : cmp                    i2, i8           
    42 : jmp_ne                 __loops_label_8  
    43 : annotation:ifcend                       
    44 : annotation:break       2                
    45 : annotation:endif       8                
    46 : unspill                i13, 6           
    47 : add                    s7, s7, i13      
    48 : add                    i2, i2, s5       
    49 : annotation:endif       6                
    50 : annotation:ifcstart                     
    51 : cmp                    i0, s4           
    52 : jmp_gt                 __loops_label_10 
    53 : annotation:ifcend                       
    54 : annotation:ifcstart                     
    55 : cmp                    i1, i9           
    56 : jmp_ne                 __loops_label_12 
    57 : annotation:ifcend                       
    58 : annotation:break       2                
    59 : annotation:endif       12               
    60 : unspill                i13, 4           
    61 : add                    s7, s7, i13      
    62 : add                    i1, i1, s8       
    63 : annotation:endif       10               
    64 : annotation:endwhile    0, 2             
    65 : ret                                     
    66 : unspill                i13, 9           
    67 : unspill                i14, 10          
    68 : add                    i4, i4, 88       
