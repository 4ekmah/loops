nullify_msb_lsb_v(i0, i1, i2, i3)
     0 : sub                    i4, i4, 24      
     1 : spill                  1, i13          
     2 : mov                    i0, 0           
     3 : mul                    i13, i1, 4      
     4 : spill                  0, i13          
     5 : mov                    i1, 1           
     6 : vdef.u32               v0              
     7 : setlane.u32            v0, 0, i1       
     8 : broadcast.u32          v0, v0, 0       
     9 : annotation:whilecstart 0               
    10 : cmp                    i0, s0          
    11 : jmp_ge                 __loops_label_2 
    12 : annotation:whilecend                   
    13 : vld.u32                v1, i7, i0      
    14 : shr.u32                v2, v1, 1       
    15 : or                     v2, v1, v2      
    16 : shr.u32                v3, v2, 2       
    17 : or                     v2, v2, v3      
    18 : shr.u32                v3, v2, 4       
    19 : or                     v2, v2, v3      
    20 : shr.u32                v3, v2, 8       
    21 : or                     v2, v2, v3      
    22 : shr.u32                v3, v2, 16      
    23 : or                     v2, v2, v3      
    24 : add.u32                v2, v2, v0      
    25 : shr.u32                v2, v2, 1       
    26 : xor                    v2, v2, v1      
    27 : vst.u32                i6, i0, v2      
    28 : sub.u32                v2, v1, v0      
    29 : mov                    i1, 255         
    30 : vdef.u8                v3              
    31 : setlane.u8             v3, 0, i1       
    32 : broadcast.u8           v3, v3, 0       
    33 : xor                    v2, v2, v3      
    34 : and                    v2, v1, v2      
    35 : xor                    v1, v2, v1      
    36 : vst.u32                i2, i0, v1      
    37 : add                    i0, i0, 32      
    38 : annotation:endwhile    0, 2            
    39 : ret                                    
    40 : unspill                i13, 1          
    41 : add                    i4, i4, 24      
