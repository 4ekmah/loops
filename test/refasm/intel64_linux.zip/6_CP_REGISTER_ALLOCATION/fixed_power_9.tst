fixed_power_9(i0)
     0 : mul i6, i7, i7 
     1 : mul i6, i6, i6 
     2 : mul i6, i6, i6 
     3 : mul i7, i7, i6 
     4 : mov i0, i7     
     5 : ret            
