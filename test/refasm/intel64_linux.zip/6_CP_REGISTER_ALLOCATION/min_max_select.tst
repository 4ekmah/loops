min_max_select(i0, i1, i2, i3)
     0 : sub                    i4, i4, 56      
     1 : spill                  1, i2           
     2 : spill                  0, i1           
     3 : spill                  5, i13          
     4 : mov                    i0, 0           
     5 : mov                    s3, 0           
     6 : mov                    s2, 0           
     7 : load.i32               i2, i7          
     8 : mov                    i1, i2          
     9 : shl                    s4, i6, 2       
    10 : annotation:whilecstart 0               
    11 : cmp                    i0, s4          
    12 : jmp_ge                 __loops_label_2 
    13 : annotation:whilecend                   
    14 : load.i32               i6, i7, i0      
    15 : cmp                    i6, i2          
    16 : unspill                i13, 3          
    17 : select_gt              i13, i0, i13    
    18 : spill                  3, i13          
    19 : min                    i2, i6, i2      
    20 : cmp                    i6, i1          
    21 : unspill                i13, 2          
    22 : select_gt              i13, i0, i13    
    23 : spill                  2, i13          
    24 : max                    i1, i6, i1      
    25 : add                    i0, i0, 4       
    26 : annotation:endwhile    0, 2            
    27 : unspill                i13, 3          
    28 : sar                    i7, i13, 2      
    29 : unspill                i13, 2          
    30 : sar                    i6, i13, 2      
    31 : unspill                i13, 1          
    32 : store.i32              i13, i7         
    33 : unspill                i13, 0          
    34 : store.i32              i13, i6         
    35 : mov                    i0, 0           
    36 : ret                                    
    37 : unspill                i13, 5          
    38 : add                    i4, i4, 56      
