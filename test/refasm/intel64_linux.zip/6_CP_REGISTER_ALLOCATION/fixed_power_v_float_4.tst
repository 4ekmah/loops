fixed_power_v_float_4(i0, i1, i2)
     0 : mov                    i1, 0           
     1 : mul                    i2, i2, 4       
     2 : annotation:whilecstart 0               
     3 : cmp                    i1, i2          
     4 : jmp_ge                 __loops_label_2 
     5 : annotation:whilecend                   
     6 : vld.fp32               v0, i7, i1      
     7 : mul.fp32               v0, v0, v0      
     8 : mul.fp32               v0, v0, v0      
     9 : vst.fp32               i6, i1, v0      
    10 : add                    i1, i1, 32      
    11 : annotation:endwhile    0, 2            
    12 : mov                    i0, 0           
    13 : ret                                    
