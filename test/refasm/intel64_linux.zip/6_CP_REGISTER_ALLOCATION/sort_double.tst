sort_double(i0, i1)
     0 : sub                    i4, i4, 696      
     1 : spill                  84, i13          
     2 : spill                  85, i14          
     3 : spill                  86, i5           
     4 : mov                    i5, i4           
     5 : add                    i5, i5, 688      
     6 : spill                  83, i7           
     7 : shl                    s82, i6, 3       
     8 : unspill                i13, 82          
     9 : sub                    s81, i13, 8      
    10 : mov                    s80, 0           
    11 : annotation:whilecstart 0                
    12 : unspill                i13, 81          
    13 : cmp                    s80, i13         
    14 : jmp_ge                 __loops_label_2  
    15 : annotation:whilecend                    
    16 : mov                    i0, s80          
    17 : add                    i1, i0, 8        
    18 : annotation:whilecstart 3                
    19 : cmp                    i1, s82          
    20 : jmp_ge                 __loops_label_5  
    21 : annotation:whilecend                    
    22 : annotation:ifcstart                     
    23 : unspill                i13, 83          
    24 : load.fp64              i2, i13, i1      
    25 : unspill                i13, 83          
    26 : load.fp64              i6, i13, i0      
    27 : mov                    i7, 141456296    
    28 : call                   [i7](i7, i2, i6) 
    29 : cmp                    i7, 0            
    30 : jmp_eq                 __loops_label_7  
    31 : annotation:ifcend                       
    32 : mov                    i0, i1           
    33 : annotation:endif       7                
    34 : add                    i1, i1, 8        
    35 : annotation:endwhile    3, 5             
    36 : annotation:ifcstart                     
    37 : cmp                    i0, s80          
    38 : jmp_eq                 __loops_label_9  
    39 : annotation:ifcend                       
    40 : unspill                i13, 83          
    41 : unspill                i14, 80          
    42 : load.fp64              i7, i13, i14     
    43 : unspill                i13, 83          
    44 : load.fp64              i6, i13, i0      
    45 : unspill                i13, 83          
    46 : store.fp64             i13, i0, i7      
    47 : unspill                i13, 83          
    48 : unspill                i14, 80          
    49 : store.fp64             i13, i14, i6     
    50 : annotation:endif       9                
    51 : add                    s80, s80, 8      
    52 : annotation:endwhile    0, 2             
    53 : ret                                     
    54 : unspill                i5, 86           
    55 : unspill                i13, 84          
    56 : unspill                i14, 85          
    57 : add                    i4, i4, 696      
