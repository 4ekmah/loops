all_loads_all_stores(i0, i1, i2, i3, i4)
     0 : sub                    i4, i4, 56       
     1 : spill                  3, i8            
     2 : spill                  5, i13           
     3 : mov                    s2, 0            
     4 : mov                    s0, 0            
     5 : mov                    s1, 0            
     6 : mov                    i0, 2            
     7 : mov                    i8, 1            
     8 : cmp                    i6, 1            
     9 : select_gt              i8, i0, i8       
    10 : mov                    i0, 4            
    11 : cmp                    i6, 3            
    12 : select_gt              i8, i0, i8       
    13 : mov                    i0, 8            
    14 : cmp                    i6, 5            
    15 : select_gt              i13, i0, i8      
    16 : spill                  4, i13           
    17 : mov                    i0, 2            
    18 : mov                    i8, 1            
    19 : cmp                    i1, 1            
    20 : select_gt              i8, i0, i8       
    21 : mov                    i0, 4            
    22 : cmp                    i1, 3            
    23 : select_gt              i8, i0, i8       
    24 : mov                    i0, 8            
    25 : cmp                    i1, 5            
    26 : select_gt              i8, i0, i8       
    27 : annotation:whilecstart 0                
    28 : unspill                i13, 3           
    29 : cmp                    s2, i13          
    30 : jmp_ge                 __loops_label_2  
    31 : annotation:whilecend                    
    32 : def                    i0               
    33 : annotation:ifcstart                     
    34 : cmp                    i6, 0            
    35 : jmp_ne                 __loops_label_4  
    36 : annotation:ifcend                       
    37 : unspill                i13, 0           
    38 : load.u8                i0, i7, i13      
    39 : annotation:else        4, 5             
    40 : annotation:ifcstart                     
    41 : cmp                    i6, 1            
    42 : jmp_ne                 __loops_label_7  
    43 : annotation:ifcend                       
    44 : unspill                i13, 0           
    45 : load.i8                i0, i7, i13      
    46 : annotation:else        7, 8             
    47 : annotation:ifcstart                     
    48 : cmp                    i6, 2            
    49 : jmp_ne                 __loops_label_10 
    50 : annotation:ifcend                       
    51 : unspill                i13, 0           
    52 : load.u16               i0, i7, i13      
    53 : annotation:else        10, 11           
    54 : annotation:ifcstart                     
    55 : cmp                    i6, 3            
    56 : jmp_ne                 __loops_label_13 
    57 : annotation:ifcend                       
    58 : unspill                i13, 0           
    59 : load.i16               i0, i7, i13      
    60 : annotation:else        13, 14           
    61 : annotation:ifcstart                     
    62 : cmp                    i6, 4            
    63 : jmp_ne                 __loops_label_16 
    64 : annotation:ifcend                       
    65 : unspill                i13, 0           
    66 : load.u32               i0, i7, i13      
    67 : annotation:else        16, 17           
    68 : annotation:ifcstart                     
    69 : cmp                    i6, 5            
    70 : jmp_ne                 __loops_label_19 
    71 : annotation:ifcend                       
    72 : unspill                i13, 0           
    73 : load.i32               i0, i7, i13      
    74 : annotation:else        19, 20           
    75 : annotation:ifcstart                     
    76 : cmp                    i6, 6            
    77 : jmp_ne                 __loops_label_22 
    78 : annotation:ifcend                       
    79 : unspill                i13, 0           
    80 : load.u64               i0, i7, i13      
    81 : annotation:else        22, 23           
    82 : unspill                i13, 0           
    83 : load.i64               i0, i7, i13      
    84 : annotation:endif       5                
    85 : annotation:endif       8                
    86 : annotation:endif       11               
    87 : annotation:endif       14               
    88 : annotation:endif       17               
    89 : annotation:endif       20               
    90 : annotation:endif       23               
    91 : annotation:ifcstart                     
    92 : cmp                    i1, 0            
    93 : jmp_ne                 __loops_label_25 
    94 : annotation:ifcend                       
    95 : unspill                i13, 1           
    96 : store.u8               i2, i13, i0      
    97 : annotation:else        25, 26           
    98 : annotation:ifcstart                     
    99 : cmp                    i1, 1            
   100 : jmp_ne                 __loops_label_28 
   101 : annotation:ifcend                       
   102 : unspill                i13, 1           
   103 : store.i8               i2, i13, i0      
   104 : annotation:else        28, 29           
   105 : annotation:ifcstart                     
   106 : cmp                    i1, 2            
   107 : jmp_ne                 __loops_label_31 
   108 : annotation:ifcend                       
   109 : unspill                i13, 1           
   110 : store.u16              i2, i13, i0      
   111 : annotation:else        31, 32           
   112 : annotation:ifcstart                     
   113 : cmp                    i1, 3            
   114 : jmp_ne                 __loops_label_34 
   115 : annotation:ifcend                       
   116 : unspill                i13, 1           
   117 : store.i16              i2, i13, i0      
   118 : annotation:else        34, 35           
   119 : annotation:ifcstart                     
   120 : cmp                    i1, 4            
   121 : jmp_ne                 __loops_label_37 
   122 : annotation:ifcend                       
   123 : unspill                i13, 1           
   124 : store.u32              i2, i13, i0      
   125 : annotation:else        37, 38           
   126 : annotation:ifcstart                     
   127 : cmp                    i1, 5            
   128 : jmp_ne                 __loops_label_40 
   129 : annotation:ifcend                       
   130 : unspill                i13, 1           
   131 : store.i32              i2, i13, i0      
   132 : annotation:else        40, 41           
   133 : annotation:ifcstart                     
   134 : cmp                    i1, 6            
   135 : jmp_ne                 __loops_label_43 
   136 : annotation:ifcend                       
   137 : unspill                i13, 1           
   138 : store.u64              i2, i13, i0      
   139 : annotation:else        43, 44           
   140 : unspill                i13, 1           
   141 : store.i64              i2, i13, i0      
   142 : annotation:endif       26               
   143 : annotation:endif       29               
   144 : annotation:endif       32               
   145 : annotation:endif       35               
   146 : annotation:endif       38               
   147 : annotation:endif       41               
   148 : annotation:endif       44               
   149 : unspill                i13, 4           
   150 : add                    s0, s0, i13      
   151 : add                    s1, s1, i8       
   152 : add                    s2, s2, 1        
   153 : annotation:endwhile    0, 2             
   154 : unspill                i13, 5           
   155 : add                    i4, i4, 56       
