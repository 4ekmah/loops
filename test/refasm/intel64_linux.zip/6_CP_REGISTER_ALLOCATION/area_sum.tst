area_sum(i0, i1)
     0 : sub                    i4, i4, 680       
     1 : spill                  82, i7            
     2 : spill                  81, i6            
     3 : spill                  83, i13           
     4 : spill                  84, i5            
     5 : mov                    i5, i4            
     6 : add                    i5, i5, 672       
     7 : mov                    s80, 0            
     8 : annotation:whilecstart 0                 
     9 : cmp                    s81, 0            
    10 : jmp_le                 __loops_label_2   
    11 : annotation:whilecend                     
    12 : unspill                i13, 82           
    13 : load.i8                i1, i13           
    14 : mov                    i0, -1794446936   
    15 : mov                    i2, -1794446697   
    16 : mov                    i6, -1794446524   
    17 : cmp                    i1, 1             
    18 : select_eq              i6, i2, i6        
    19 : cmp                    i1, 0             
    20 : select_eq              i6, i0, i6        
    21 : mov                    i2, -1794447284   
    22 : mov                    i0, -1794447163   
    23 : mov                    i7, -1794447100   
    24 : cmp                    i1, 1             
    25 : select_eq              i7, i0, i7        
    26 : cmp                    i1, 0             
    27 : select_eq              i7, i2, i7        
    28 : unspill                i13, 82           
    29 : call_noret             [i6](i13)         
    30 : unspill                i13, 82           
    31 : call                   [i7](i7, i13)     
    32 : mov                    i6, -1794447355   
    33 : unspill                i13, 80           
    34 : call                   [i6](i7, i13, i7) 
    35 : mov                    s80, i7           
    36 : add                    s82, s82, 56      
    37 : sub                    s81, s81, 1       
    38 : annotation:endwhile    0, 2              
    39 : mov                    i0, s80           
    40 : ret                                      
    41 : unspill                i5, 84            
    42 : unspill                i13, 83           
    43 : add                    i4, i4, 680       
