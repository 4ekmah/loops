nonnegative_odd(i0, i1)
     0 : sub                    i4, i4, 56      
     1 : spill                  5, i13          
     2 : mov                    i2, 0           
     3 : mov                    i13, -4         
     4 : spill                  4, i13          
     5 : mul                    i6, i6, 4       
     6 : annotation:whilecstart 0               
     7 : cmp                    i2, i6          
     8 : jmp_ge                 __loops_label_2 
     9 : annotation:whilecend                   
    10 : load.i32               i0, i7, i2      
    11 : annotation:ifcstart                    
    12 : cmp                    i0, 0           
    13 : jmp_ge                 __loops_label_4 
    14 : annotation:ifcend                      
    15 : add                    i2, i2, 4       
    16 : annotation:break       0               
    17 : annotation:endif       4               
    18 : mov                    i1, 2           
    19 : mod                    i1, i0, i1      
    20 : annotation:ifcstart                    
    21 : cmp                    i1, 0           
    22 : jmp_eq                 __loops_label_6 
    23 : annotation:ifcend                      
    24 : mov                    s4, i2          
    25 : annotation:break       2               
    26 : annotation:endif       6               
    27 : add                    i2, i2, 4       
    28 : annotation:endwhile    0, 2            
    29 : mov                    i7, 4           
    30 : unspill                i13, 4          
    31 : div                    i7, i13, i7     
    32 : mov                    i0, i7          
    33 : ret                                    
    34 : unspill                i13, 5          
    35 : add                    i4, i4, 56      
