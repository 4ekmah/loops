triangle_types(i0, i1, i2)
     0 : sub                 i4, i4, 24       
     1 : spill               0, i6            
     2 : spill               1, i13           
     3 : annotation:ifcstart                  
     4 : cmp                 i7, 0            
     5 : jmp_le              __loops_label_0  
     6 : cmp                 s0, 0            
     7 : jmp_le              __loops_label_0  
     8 : cmp                 i2, 0            
     9 : jmp_gt              __loops_label_1  
    10 : __loops_label_0:                     
    11 : annotation:ifcend                    
    12 : mov                 i0, 0            
    13 : ret                                  
    14 : annotation:else     1, 2             
    15 : annotation:ifcstart                  
    16 : unspill             i13, 0           
    17 : add                 i1, i13, i2      
    18 : cmp                 i7, i1           
    19 : jmp_gt              __loops_label_3  
    20 : add                 i1, i7, i2       
    21 : cmp                 s0, i1           
    22 : jmp_gt              __loops_label_3  
    23 : add                 i1, i7, s0       
    24 : cmp                 i2, i1           
    25 : jmp_le              __loops_label_4  
    26 : __loops_label_3:                     
    27 : annotation:ifcend                    
    28 : mov                 i0, 0            
    29 : ret                                  
    30 : annotation:else     4, 5             
    31 : annotation:ifcstart                  
    32 : cmp                 i7, s0           
    33 : jmp_ne              __loops_label_7  
    34 : cmp                 i7, i2           
    35 : jmp_ne              __loops_label_7  
    36 : annotation:ifcend                    
    37 : mov                 i0, 2            
    38 : ret                                  
    39 : annotation:else     7, 8             
    40 : annotation:ifcstart                  
    41 : cmp                 i7, s0           
    42 : jmp_eq              __loops_label_9  
    43 : cmp                 i7, i2           
    44 : jmp_eq              __loops_label_9  
    45 : cmp                 s0, i2           
    46 : jmp_ne              __loops_label_10 
    47 : __loops_label_9:                     
    48 : annotation:ifcend                    
    49 : mov                 i0, 3            
    50 : ret                                  
    51 : annotation:else     10, 11           
    52 : annotation:ifcstart                  
    53 : mul                 i1, i7, i7       
    54 : unspill             i13, 0           
    55 : mul                 i0, i13, s0      
    56 : mul                 i6, i2, i2       
    57 : add                 i0, i0, i6       
    58 : cmp                 i1, i0           
    59 : jmp_eq              __loops_label_12 
    60 : unspill             i13, 0           
    61 : mul                 i6, i13, s0      
    62 : mul                 i1, i7, i7       
    63 : mul                 i0, i2, i2       
    64 : add                 i1, i1, i0       
    65 : cmp                 i6, i1           
    66 : jmp_eq              __loops_label_12 
    67 : mul                 i6, i2, i2       
    68 : mul                 i1, i7, i7       
    69 : unspill             i13, 0           
    70 : mul                 i0, i13, s0      
    71 : add                 i1, i1, i0       
    72 : cmp                 i6, i1           
    73 : jmp_ne              __loops_label_13 
    74 : __loops_label_12:                    
    75 : annotation:ifcend                    
    76 : mov                 i0, 1            
    77 : ret                                  
    78 : annotation:else     13, 14           
    79 : annotation:ifcstart                  
    80 : mul                 i6, i7, i7       
    81 : unspill             i13, 0           
    82 : mul                 i1, i13, s0      
    83 : mul                 i0, i2, i2       
    84 : add                 i1, i1, i0       
    85 : cmp                 i6, i1           
    86 : jmp_gt              __loops_label_15 
    87 : unspill             i13, 0           
    88 : mul                 i6, i13, s0      
    89 : mul                 i1, i7, i7       
    90 : mul                 i0, i2, i2       
    91 : add                 i1, i1, i0       
    92 : cmp                 i6, i1           
    93 : jmp_gt              __loops_label_15 
    94 : mul                 i2, i2, i2       
    95 : mul                 i7, i7, i7       
    96 : unspill             i13, 0           
    97 : mul                 i6, i13, s0      
    98 : add                 i7, i7, i6       
    99 : cmp                 i2, i7           
   100 : jmp_le              __loops_label_16 
   101 : __loops_label_15:                    
   102 : annotation:ifcend                    
   103 : mov                 i0, 5            
   104 : ret                                  
   105 : annotation:else     16, 17           
   106 : mov                 i0, 4            
   107 : ret                                  
   108 : annotation:endif    2                
   109 : annotation:endif    5                
   110 : annotation:endif    8                
   111 : annotation:endif    11               
   112 : annotation:endif    14               
   113 : annotation:endif    17               
   114 : unspill             i13, 1           
   115 : add                 i4, i4, 24       
