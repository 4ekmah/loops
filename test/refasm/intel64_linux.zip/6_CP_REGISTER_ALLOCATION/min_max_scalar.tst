min_max_scalar(i0, i1, i2, i3)
     0 : sub                    i4, i4, 88      
     1 : spill                  9, i13          
     2 : spill                  5, i2           
     3 : spill                  4, i1           
     4 : mov                    i0, 0           
     5 : mov                    s7, 0           
     6 : mov                    s6, 0           
     7 : load.i32               i2, i7          
     8 : mov                    i1, i2          
     9 : mul                    i13, i6, 4      
    10 : spill                  8, i13          
    11 : annotation:whilecstart 0               
    12 : cmp                    i0, s8          
    13 : jmp_ge                 __loops_label_2 
    14 : annotation:whilecend                   
    15 : load.i32               i6, i7, i0      
    16 : annotation:ifcstart                    
    17 : cmp                    i6, i2          
    18 : jmp_ge                 __loops_label_4 
    19 : annotation:ifcend                      
    20 : mov                    i2, i6          
    21 : mov                    s7, i0          
    22 : annotation:endif       4               
    23 : annotation:ifcstart                    
    24 : cmp                    i6, i1          
    25 : jmp_le                 __loops_label_6 
    26 : annotation:ifcend                      
    27 : mov                    i1, i6          
    28 : mov                    s6, i0          
    29 : annotation:endif       6               
    30 : add                    i0, i0, 4       
    31 : annotation:endwhile    0, 2            
    32 : mov                    i7, 4           
    33 : unspill                i13, 7          
    34 : div                    i6, i13, i7     
    35 : unspill                i13, 6          
    36 : div                    i7, i13, i7     
    37 : unspill                i13, 5          
    38 : store.i32              i13, i6         
    39 : unspill                i13, 4          
    40 : store.i32              i13, i7         
    41 : mov                    i0, 0           
    42 : ret                                    
    43 : unspill                i13, 9          
    44 : add                    i4, i4, 88      
