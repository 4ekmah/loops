conditionpainter(i0)
     0 : sub                    i4, i4, 56      
     1 : spill                  1, i7           
     2 : spill                  5, i13          
     3 : mov                    i13, -5         
     4 : spill                  0, i13          
     5 : annotation:whilecstart 0               
     6 : cmp                    s0, 5           
     7 : jmp_gt                 __loops_label_2 
     8 : annotation:whilecend                   
     9 : unspill                i13, 0          
    10 : add                    i2, i13, 5      
    11 : mul                    i2, i2, 11      
    12 : mul                    i13, i2, 8      
    13 : spill                  3, i13          
    14 : mov                    i13, -5         
    15 : spill                  2, i13          
    16 : annotation:whilecstart 3               
    17 : cmp                    s2, 5           
    18 : jmp_gt                 __loops_label_5 
    19 : annotation:whilecend                   
    20 : unspill                i13, 2          
    21 : add                    i0, i13, 3      
    22 : mov                    i6, 0           
    23 : cmp                    s0, i0          
    24 : iverson_ge             i6              
    25 : mov                    i0, 0           
    26 : cmp                    s0, 4           
    27 : iverson_le             i0              
    28 : and                    i6, i6, i0      
    29 : mov                    i0, 0           
    30 : cmp                    s2, -2          
    31 : iverson_ge             i0              
    32 : and                    i6, i6, i0      
    33 : mov                    i0, 0           
    34 : cmp                    s2, 0           
    35 : iverson_le             i0              
    36 : and                    i6, i6, i0      
    37 : unspill                i13, 2          
    38 : sub                    i0, i13, 1      
    39 : mov                    i7, 0           
    40 : cmp                    s0, i0          
    41 : iverson_le             i7              
    42 : mov                    i0, 0           
    43 : cmp                    s2, 0           
    44 : iverson_ge             i0              
    45 : and                    i7, i7, i0      
    46 : mov                    i0, 0           
    47 : cmp                    s0, 0           
    48 : iverson_le             i0              
    49 : and                    i7, i7, i0      
    50 : unspill                i13, 2          
    51 : mul                    i0, i13, s2     
    52 : unspill                i13, 0          
    53 : mul                    i1, i13, s0     
    54 : add                    i0, i0, i1      
    55 : mov                    i1, 0           
    56 : cmp                    i0, 9           
    57 : iverson_le             i1              
    58 : and                    i7, i7, i1      
    59 : or                     s4, i6, i7      
    60 : mov                    i7, 2           
    61 : mov                    i1, 0           
    62 : mov                    i0, 0           
    63 : cmp                    s2, 2           
    64 : iverson_ge             i0              
    65 : mov                    i2, 0           
    66 : cmp                    s2, 4           
    67 : iverson_le             i2              
    68 : and                    i0, i0, i2      
    69 : mov                    i2, 0           
    70 : cmp                    s0, 1           
    71 : iverson_ge             i2              
    72 : mov                    i6, 0           
    73 : cmp                    s0, 3           
    74 : iverson_le             i6              
    75 : and                    i2, i2, i6      
    76 : or                     i0, i0, i2      
    77 : unspill                i13, 2          
    78 : mul                    i6, i13, s2     
    79 : unspill                i13, 0          
    80 : mul                    i2, i13, s0     
    81 : add                    i6, i6, i2      
    82 : mov                    i2, 0           
    83 : cmp                    i6, 16          
    84 : iverson_le             i2              
    85 : and                    i0, i0, i2      
    86 : cmp                    i0, 0           
    87 : select_ne              i1, i7, i1      
    88 : unspill                i13, 4          
    89 : add                    i1, i13, i1     
    90 : annotation:ifcstart                    
    91 : unspill                i13, 0          
    92 : mul                    i7, i13, 2      
    93 : cmp                    i7, s2          
    94 : jmp_gt                 __loops_label_8 
    95 : unspill                i13, 2          
    96 : add                    i7, i13, 3      
    97 : neg                    i7, i7          
    98 : unspill                i13, 2          
    99 : add                    i6, i13, 3      
   100 : mul                    i7, i7, i6      
   101 : cmp                    s0, i7          
   102 : jmp_le                 __loops_label_9 
   103 : __loops_label_8:                       
   104 : unspill                i13, 2          
   105 : mul                    i7, i13, 2      
   106 : cmp                    s0, i7          
   107 : jmp_gt                 __loops_label_7 
   108 : unspill                i13, 2          
   109 : add                    i7, i13, 3      
   110 : neg                    i7, i7          
   111 : unspill                i13, 2          
   112 : add                    i6, i13, 3      
   113 : mul                    i7, i7, i6      
   114 : cmp                    s0, i7          
   115 : jmp_gt                 __loops_label_7 
   116 : __loops_label_9:                       
   117 : cmp                    s2, 0           
   118 : jmp_gt                 __loops_label_7 
   119 : annotation:ifcend                      
   120 : add                    i1, i1, 3       
   121 : annotation:endif       7               
   122 : unspill                i13, 2          
   123 : add                    i7, i13, 5      
   124 : shl                    i7, i7, 3       
   125 : unspill                i13, 3          
   126 : add                    i7, i13, i7     
   127 : unspill                i13, 1          
   128 : store.i64              i13, i7, i1     
   129 : add                    s2, s2, 1       
   130 : annotation:endwhile    3, 5            
   131 : add                    s0, s0, 1       
   132 : annotation:endwhile    0, 2            
   133 : ret                                    
   134 : unspill                i13, 5          
   135 : add                    i4, i4, 56      
