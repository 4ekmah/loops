fixed_power_v_double_0(i0, i1, i2)
     0 : mov                    i1, 0           
     1 : mul                    i2, i2, 8       
     2 : annotation:whilecstart 0               
     3 : cmp                    i1, i2          
     4 : jmp_ge                 __loops_label_2 
     5 : annotation:whilecend                   
     6 : vld.fp64               v0, i7, i1      
     7 : mov                    i0, 0           
     8 : vdef.fp64              v0              
     9 : setlane.fp64           v0, 0, i0       
    10 : broadcast.fp64         v0, v0, 0       
    11 : vst.fp64               i6, i1, v0      
    12 : add                    i1, i1, 32      
    13 : annotation:endwhile    0, 2            
    14 : mov                    i0, 0           
    15 : ret                                    
