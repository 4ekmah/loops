helloworld_call()
     0 : sub        i4, i4, 648   
     1 : spill      80, i5        
     2 : mov        i5, i4        
     3 : add        i5, i5, 640   
     4 : mov        i7, 922203882 
     5 : call_noret [i7]()        
     6 : ret                      
     7 : unspill    i5, 80        
     8 : add        i4, i4, 648   
