nullify_msb_lsb(i0, i1, i2)
     0 : shr       i1, i7, 1  
     1 : or        i1, i7, i1 
     2 : shr       i0, i1, 2  
     3 : or        i1, i1, i0 
     4 : shr       i0, i1, 4  
     5 : or        i1, i1, i0 
     6 : shr       i0, i1, 8  
     7 : or        i1, i1, i0 
     8 : shr       i0, i1, 16 
     9 : or        i1, i1, i0 
    10 : shr       i0, i1, 32 
    11 : or        i1, i1, i0 
    12 : add       i1, i1, 1  
    13 : shr       i1, i1, 1  
    14 : xor       i1, i1, i7 
    15 : store.u64 i2, i1     
    16 : sub       i2, i7, 1  
    17 : not       i2, i2     
    18 : and       i2, i7, i2 
    19 : xor       i2, i2, i7 
    20 : store.u64 i6, i2     
    21 : ret                  
