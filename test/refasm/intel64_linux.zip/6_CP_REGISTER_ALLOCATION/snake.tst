snake(i0, i1, i2)
     0 : sub                    i4, i4, 728     
     1 : spill                  87, i7          
     2 : spill                  86, i6          
     3 : spill                  85, i2          
     4 : spill                  88, i13         
     5 : spill                  89, i14         
     6 : spill                  90, i5          
     7 : mov                    i5, i4          
     8 : add                    i5, i5, 720     
     9 : unspill                i13, 86         
    10 : add                    i1, i13, s85    
    11 : sub                    s84, i1, 1      
    12 : mov                    s83, 0          
    13 : mov                    s80, 1          
    14 : neg                    i13, s80        
    15 : spill                  81, i13         
    16 : mov                    s82, 0          
    17 : annotation:whilecstart 0               
    18 : unspill                i13, 84         
    19 : cmp                    s82, i13        
    20 : jmp_ge                 __loops_label_2 
    21 : annotation:whilecend                   
    22 : mov                    i0, 0           
    23 : mov                    i1, 0           
    24 : annotation:ifcstart                    
    25 : unspill                i13, 82         
    26 : and                    i2, i13, 1      
    27 : cmp                    i2, 0           
    28 : jmp_eq                 __loops_label_4 
    29 : annotation:ifcend                      
    30 : unspill                i13, 85         
    31 : sub                    i2, i13, 1      
    32 : unspill                i13, 82         
    33 : min                    i0, i2, i13     
    34 : unspill                i13, 82         
    35 : sub                    i6, i13, i2     
    36 : mov                    i7, 0           
    37 : cmp                    s82, i2         
    38 : select_gt              i1, i6, i7      
    39 : annotation:else        4, 5            
    40 : unspill                i13, 86         
    41 : sub                    i7, i13, 1      
    42 : unspill                i13, 82         
    43 : sub                    i6, i13, i7     
    44 : mov                    i2, 0           
    45 : cmp                    s82, i7         
    46 : select_gt              i0, i6, i2      
    47 : unspill                i13, 82         
    48 : min                    i1, i7, i13     
    49 : annotation:endif       5               
    50 : annotation:whilecstart 6               
    51 : cmp                    i0, 0           
    52 : jmp_gt                 __loops_label_8 
    53 : cmp                    i0, s85         
    54 : jmp_ge                 __loops_label_8 
    55 : cmp                    i1, 0           
    56 : jmp_gt                 __loops_label_8 
    57 : cmp                    i1, s86         
    58 : jmp_ge                 __loops_label_8 
    59 : annotation:whilecend                   
    60 : mov                    i7, -1313611903 
    61 : call_noret             [i7](i0, i1)    
    62 : mul                    i7, i1, s85     
    63 : add                    i7, i7, i0      
    64 : unspill                i13, 87         
    65 : unspill                i14, 83         
    66 : store.u8               i13, i7, i14    
    67 : add                    s83, s83, 1     
    68 : add                    i0, i0, s80     
    69 : add                    i1, i1, s81     
    70 : annotation:endwhile    6, 8            
    71 : neg                    s80, s80        
    72 : neg                    s81, s81        
    73 : add                    s82, s82, 1     
    74 : annotation:endwhile    0, 2            
    75 : ret                                    
    76 : unspill                i5, 90          
    77 : unspill                i13, 88         
    78 : unspill                i14, 89         
    79 : add                    i4, i4, 728     
