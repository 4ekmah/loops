bresenham(i0, i1, i2, i3, i4, i5, i6)
     0 : sub               i4, i4, 88       
     1 : spill             9, i13           
     2 : spill             10, i14          
     3 : sub               i0, i8, i2       
     4 : abs               i13, i0          
     5 : spill             4, i13           
     6 : sub               i0, i8, i2       
     7 : sign              i13, i0          
     8 : spill             5, i13           
     9 : sub               i0, i9, i1       
    10 : abs               i0, i0           
    11 : neg               s6, i0           
    12 : sub               i0, i9, i1       
    13 : sign              i13, i0          
    14 : spill             8, i13           
    15 : unspill           i13, 4           
    16 : unspill           i14, 6           
    17 : add               s7, i13, i14     
    18 : __loops_label_0:                   
    19 : cmp               i7, 0            
    20 : jmp_eq            __loops_label_2  
    21 : mul               i0, i1, i6       
    22 : add               i0, i0, i2       
    23 : unspill           i13, 12          
    24 : store.u8          i7, i0, i13      
    25 : cmp               i2, i8           
    26 : jmp_ne            __loops_label_4  
    27 : cmp               i1, i9           
    28 : jmp_ne            __loops_label_4  
    29 : jmp               2                
    30 : __loops_label_4:                   
    31 : unspill           i13, 7           
    32 : shl               i0, i13, 1       
    33 : cmp               i0, s6           
    34 : jmp_gt            __loops_label_6  
    35 : cmp               i2, i8           
    36 : jmp_ne            __loops_label_8  
    37 : jmp               2                
    38 : __loops_label_8:                   
    39 : unspill           i13, 6           
    40 : add               s7, s7, i13      
    41 : add               i2, i2, s5       
    42 : __loops_label_6:                   
    43 : cmp               i0, s4           
    44 : jmp_gt            __loops_label_10 
    45 : cmp               i1, i9           
    46 : jmp_ne            __loops_label_12 
    47 : jmp               2                
    48 : __loops_label_12:                  
    49 : unspill           i13, 4           
    50 : add               s7, s7, i13      
    51 : add               i1, i1, s8       
    52 : __loops_label_10:                  
    53 : jmp               0                
    54 : __loops_label_2:                   
    55 : unspill           i13, 9           
    56 : unspill           i14, 10          
    57 : add               i4, i4, 88       
    58 : ret                                
