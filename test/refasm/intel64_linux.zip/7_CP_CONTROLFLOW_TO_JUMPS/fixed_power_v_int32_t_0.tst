fixed_power_v_int32_t_0(i0, i1, i2)
     0 : mov              i1, 0           
     1 : mul              i2, i2, 4       
     2 : __loops_label_0:                 
     3 : cmp              i1, i2          
     4 : jmp_ge           __loops_label_2 
     5 : vld.i32          v0, i7, i1      
     6 : mov              i0, 1           
     7 : vdef.i32         v0              
     8 : setlane.i32      v0, 0, i0       
     9 : broadcast.i32    v0, v0, 0       
    10 : vst.i32          i6, i1, v0      
    11 : add              i1, i1, 32      
    12 : jmp              0               
    13 : __loops_label_2:                 
    14 : mov              i0, 0           
    15 : ret                              
