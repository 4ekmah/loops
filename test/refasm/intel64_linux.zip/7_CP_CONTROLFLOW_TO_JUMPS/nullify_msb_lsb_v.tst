nullify_msb_lsb_v(i0, i1, i2, i3)
     0 : sub              i4, i4, 24      
     1 : spill            1, i13          
     2 : mov              i0, 0           
     3 : mul              i13, i1, 4      
     4 : spill            0, i13          
     5 : mov              i1, 1           
     6 : vdef.u32         v0              
     7 : setlane.u32      v0, 0, i1       
     8 : broadcast.u32    v0, v0, 0       
     9 : __loops_label_0:                 
    10 : cmp              i0, s0          
    11 : jmp_ge           __loops_label_2 
    12 : vld.u32          v1, i7, i0      
    13 : shr.u32          v2, v1, 1       
    14 : or               v2, v1, v2      
    15 : shr.u32          v3, v2, 2       
    16 : or               v2, v2, v3      
    17 : shr.u32          v3, v2, 4       
    18 : or               v2, v2, v3      
    19 : shr.u32          v3, v2, 8       
    20 : or               v2, v2, v3      
    21 : shr.u32          v3, v2, 16      
    22 : or               v2, v2, v3      
    23 : add.u32          v2, v2, v0      
    24 : shr.u32          v2, v2, 1       
    25 : xor              v2, v2, v1      
    26 : vst.u32          i6, i0, v2      
    27 : sub.u32          v2, v1, v0      
    28 : mov              i1, 255         
    29 : vdef.u8          v3              
    30 : setlane.u8       v3, 0, i1       
    31 : broadcast.u8     v3, v3, 0       
    32 : xor              v2, v2, v3      
    33 : and              v2, v1, v2      
    34 : xor              v1, v2, v1      
    35 : vst.u32          i2, i0, v1      
    36 : add              i0, i0, 32      
    37 : jmp              0               
    38 : __loops_label_2:                 
    39 : unspill          i13, 1          
    40 : add              i4, i4, 24      
    41 : ret                              
