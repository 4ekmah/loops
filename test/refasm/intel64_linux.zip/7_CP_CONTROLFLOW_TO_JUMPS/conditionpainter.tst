conditionpainter(i0)
     0 : sub              i4, i4, 56      
     1 : spill            1, i7           
     2 : spill            5, i13          
     3 : mov              i13, -5         
     4 : spill            0, i13          
     5 : __loops_label_0:                 
     6 : cmp              s0, 5           
     7 : jmp_gt           __loops_label_2 
     8 : unspill          i13, 0          
     9 : add              i2, i13, 5      
    10 : mul              i2, i2, 11      
    11 : mul              i13, i2, 8      
    12 : spill            3, i13          
    13 : mov              i13, -5         
    14 : spill            2, i13          
    15 : __loops_label_3:                 
    16 : cmp              s2, 5           
    17 : jmp_gt           __loops_label_5 
    18 : unspill          i13, 2          
    19 : add              i0, i13, 3      
    20 : mov              i6, 0           
    21 : cmp              s0, i0          
    22 : iverson_ge       i6              
    23 : mov              i0, 0           
    24 : cmp              s0, 4           
    25 : iverson_le       i0              
    26 : and              i6, i6, i0      
    27 : mov              i0, 0           
    28 : cmp              s2, -2          
    29 : iverson_ge       i0              
    30 : and              i6, i6, i0      
    31 : mov              i0, 0           
    32 : cmp              s2, 0           
    33 : iverson_le       i0              
    34 : and              i6, i6, i0      
    35 : unspill          i13, 2          
    36 : sub              i0, i13, 1      
    37 : mov              i7, 0           
    38 : cmp              s0, i0          
    39 : iverson_le       i7              
    40 : mov              i0, 0           
    41 : cmp              s2, 0           
    42 : iverson_ge       i0              
    43 : and              i7, i7, i0      
    44 : mov              i0, 0           
    45 : cmp              s0, 0           
    46 : iverson_le       i0              
    47 : and              i7, i7, i0      
    48 : unspill          i13, 2          
    49 : mul              i0, i13, s2     
    50 : unspill          i13, 0          
    51 : mul              i1, i13, s0     
    52 : add              i0, i0, i1      
    53 : mov              i1, 0           
    54 : cmp              i0, 9           
    55 : iverson_le       i1              
    56 : and              i7, i7, i1      
    57 : or               s4, i6, i7      
    58 : mov              i7, 2           
    59 : mov              i1, 0           
    60 : mov              i0, 0           
    61 : cmp              s2, 2           
    62 : iverson_ge       i0              
    63 : mov              i2, 0           
    64 : cmp              s2, 4           
    65 : iverson_le       i2              
    66 : and              i0, i0, i2      
    67 : mov              i2, 0           
    68 : cmp              s0, 1           
    69 : iverson_ge       i2              
    70 : mov              i6, 0           
    71 : cmp              s0, 3           
    72 : iverson_le       i6              
    73 : and              i2, i2, i6      
    74 : or               i0, i0, i2      
    75 : unspill          i13, 2          
    76 : mul              i6, i13, s2     
    77 : unspill          i13, 0          
    78 : mul              i2, i13, s0     
    79 : add              i6, i6, i2      
    80 : mov              i2, 0           
    81 : cmp              i6, 16          
    82 : iverson_le       i2              
    83 : and              i0, i0, i2      
    84 : cmp              i0, 0           
    85 : select_ne        i1, i7, i1      
    86 : unspill          i13, 4          
    87 : add              i1, i13, i1     
    88 : unspill          i13, 0          
    89 : mul              i7, i13, 2      
    90 : cmp              i7, s2          
    91 : jmp_gt           __loops_label_8 
    92 : unspill          i13, 2          
    93 : add              i7, i13, 3      
    94 : neg              i7, i7          
    95 : unspill          i13, 2          
    96 : add              i6, i13, 3      
    97 : mul              i7, i7, i6      
    98 : cmp              s0, i7          
    99 : jmp_le           __loops_label_9 
   100 : __loops_label_8:                 
   101 : unspill          i13, 2          
   102 : mul              i7, i13, 2      
   103 : cmp              s0, i7          
   104 : jmp_gt           __loops_label_7 
   105 : unspill          i13, 2          
   106 : add              i7, i13, 3      
   107 : neg              i7, i7          
   108 : unspill          i13, 2          
   109 : add              i6, i13, 3      
   110 : mul              i7, i7, i6      
   111 : cmp              s0, i7          
   112 : jmp_gt           __loops_label_7 
   113 : __loops_label_9:                 
   114 : cmp              s2, 0           
   115 : jmp_gt           __loops_label_7 
   116 : add              i1, i1, 3       
   117 : __loops_label_7:                 
   118 : unspill          i13, 2          
   119 : add              i7, i13, 5      
   120 : shl              i7, i7, 3       
   121 : unspill          i13, 3          
   122 : add              i7, i13, i7     
   123 : unspill          i13, 1          
   124 : store.i64        i13, i7, i1     
   125 : add              s2, s2, 1       
   126 : jmp              3               
   127 : __loops_label_5:                 
   128 : add              s0, s0, 1       
   129 : jmp              0               
   130 : __loops_label_2:                 
   131 : unspill          i13, 5          
   132 : add              i4, i4, 56      
   133 : ret                              
