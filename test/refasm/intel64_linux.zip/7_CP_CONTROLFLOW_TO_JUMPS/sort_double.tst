sort_double(i0, i1)
     0 : sub              i4, i4, 696      
     1 : spill            83, i7           
     2 : spill            84, i13          
     3 : spill            85, i14          
     4 : spill            86, i5           
     5 : mov              i5, i4           
     6 : add              i5, i5, 688      
     7 : shl              s82, i6, 3       
     8 : unspill          i13, 82          
     9 : sub              s81, i13, 8      
    10 : mov              s80, 0           
    11 : __loops_label_0:                  
    12 : unspill          i13, 81          
    13 : cmp              s80, i13         
    14 : jmp_ge           __loops_label_2  
    15 : mov              i0, s80          
    16 : add              i1, i0, 8        
    17 : __loops_label_3:                  
    18 : cmp              i1, s82          
    19 : jmp_ge           __loops_label_5  
    20 : unspill          i13, 83          
    21 : load.fp64        i2, i13, i1      
    22 : unspill          i13, 83          
    23 : load.fp64        i6, i13, i0      
    24 : mov              i7, -1794452968  
    25 : call             [i7](i7, i2, i6) 
    26 : cmp              i7, 0            
    27 : jmp_eq           __loops_label_7  
    28 : mov              i0, i1           
    29 : __loops_label_7:                  
    30 : add              i1, i1, 8        
    31 : jmp              3                
    32 : __loops_label_5:                  
    33 : cmp              i0, s80          
    34 : jmp_eq           __loops_label_9  
    35 : unspill          i13, 83          
    36 : unspill          i14, 80          
    37 : load.fp64        i7, i13, i14     
    38 : unspill          i13, 83          
    39 : load.fp64        i6, i13, i0      
    40 : unspill          i13, 83          
    41 : store.fp64       i13, i0, i7      
    42 : unspill          i13, 83          
    43 : unspill          i14, 80          
    44 : store.fp64       i13, i14, i6     
    45 : __loops_label_9:                  
    46 : add              s80, s80, 8      
    47 : jmp              0                
    48 : __loops_label_2:                  
    49 : unspill          i5, 86           
    50 : unspill          i13, 84          
    51 : unspill          i14, 85          
    52 : add              i4, i4, 696      
    53 : ret                               
