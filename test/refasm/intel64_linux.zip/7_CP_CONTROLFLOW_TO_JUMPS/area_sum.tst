area_sum(i0, i1)
     0 : sub              i4, i4, 680       
     1 : spill            83, i13           
     2 : spill            84, i5            
     3 : mov              i5, i4            
     4 : add              i5, i5, 672       
     5 : spill            82, i7            
     6 : spill            81, i6            
     7 : mov              s80, 0            
     8 : __loops_label_0:                   
     9 : cmp              s81, 0            
    10 : jmp_le           __loops_label_2   
    11 : unspill          i13, 82           
    12 : load.i8          i1, i13           
    13 : mov              i0, 141462328     
    14 : mov              i2, 141462567     
    15 : mov              i6, 141462740     
    16 : cmp              i1, 1             
    17 : select_eq        i6, i2, i6        
    18 : cmp              i1, 0             
    19 : select_eq        i6, i0, i6        
    20 : mov              i2, 141461980     
    21 : mov              i0, 141462101     
    22 : mov              i7, 141462164     
    23 : cmp              i1, 1             
    24 : select_eq        i7, i0, i7        
    25 : cmp              i1, 0             
    26 : select_eq        i7, i2, i7        
    27 : unspill          i13, 82           
    28 : call_noret       [i6](i13)         
    29 : unspill          i13, 82           
    30 : call             [i7](i7, i13)     
    31 : mov              i6, 141461909     
    32 : unspill          i13, 80           
    33 : call             [i6](i7, i13, i7) 
    34 : mov              s80, i7           
    35 : add              s82, s82, 56      
    36 : sub              s81, s81, 1       
    37 : jmp              0                 
    38 : __loops_label_2:                   
    39 : mov              i0, s80           
    40 : unspill          i5, 84            
    41 : unspill          i13, 83           
    42 : add              i4, i4, 680       
    43 : ret                                
