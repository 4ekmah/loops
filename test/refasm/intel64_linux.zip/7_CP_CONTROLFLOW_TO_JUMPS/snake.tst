snake(i0, i1, i2)
     0 : sub              i4, i4, 728     
     1 : spill            87, i7          
     2 : spill            86, i6          
     3 : spill            85, i2          
     4 : spill            88, i13         
     5 : spill            89, i14         
     6 : spill            90, i5          
     7 : mov              i5, i4          
     8 : add              i5, i5, 720     
     9 : unspill          i13, 86         
    10 : add              i1, i13, s85    
    11 : sub              s84, i1, 1      
    12 : mov              s83, 0          
    13 : mov              s80, 1          
    14 : neg              i13, s80        
    15 : spill            81, i13         
    16 : mov              s82, 0          
    17 : __loops_label_0:                 
    18 : unspill          i13, 84         
    19 : cmp              s82, i13        
    20 : jmp_ge           __loops_label_2 
    21 : mov              i0, 0           
    22 : mov              i1, 0           
    23 : unspill          i13, 82         
    24 : and              i2, i13, 1      
    25 : cmp              i2, 0           
    26 : jmp_eq           __loops_label_4 
    27 : unspill          i13, 85         
    28 : sub              i2, i13, 1      
    29 : unspill          i13, 82         
    30 : min              i0, i2, i13     
    31 : unspill          i13, 82         
    32 : sub              i6, i13, i2     
    33 : mov              i7, 0           
    34 : cmp              s82, i2         
    35 : select_gt        i1, i6, i7      
    36 : jmp              5               
    37 : __loops_label_4:                 
    38 : unspill          i13, 86         
    39 : sub              i7, i13, 1      
    40 : unspill          i13, 82         
    41 : sub              i6, i13, i7     
    42 : mov              i2, 0           
    43 : cmp              s82, i7         
    44 : select_gt        i0, i6, i2      
    45 : unspill          i13, 82         
    46 : min              i1, i7, i13     
    47 : __loops_label_5:                 
    48 : __loops_label_6:                 
    49 : cmp              i0, 0           
    50 : jmp_gt           __loops_label_8 
    51 : cmp              i0, s85         
    52 : jmp_ge           __loops_label_8 
    53 : cmp              i1, 0           
    54 : jmp_gt           __loops_label_8 
    55 : cmp              i1, s86         
    56 : jmp_ge           __loops_label_8 
    57 : mov              i7, -1794461823 
    58 : call_noret       [i7](i0, i1)    
    59 : mul              i7, i1, s85     
    60 : add              i7, i7, i0      
    61 : unspill          i13, 87         
    62 : unspill          i14, 83         
    63 : store.u8         i13, i7, i14    
    64 : add              s83, s83, 1     
    65 : add              i0, i0, s80     
    66 : add              i1, i1, s81     
    67 : jmp              6               
    68 : __loops_label_8:                 
    69 : neg              s80, s80        
    70 : neg              s81, s81        
    71 : add              s82, s82, 1     
    72 : jmp              0               
    73 : __loops_label_2:                 
    74 : unspill          i5, 90          
    75 : unspill          i13, 88         
    76 : unspill          i14, 89         
    77 : add              i4, i4, 728     
    78 : ret                              
