min_max_select(i0, i1, i2, i3)
     0 : sub              i4, i4, 56      
     1 : spill            5, i13          
     2 : spill            1, i2           
     3 : spill            0, i1           
     4 : mov              i0, 0           
     5 : mov              s3, 0           
     6 : mov              s2, 0           
     7 : load.i32         i2, i7          
     8 : mov              i1, i2          
     9 : shl              s4, i6, 2       
    10 : __loops_label_0:                 
    11 : cmp              i0, s4          
    12 : jmp_ge           __loops_label_2 
    13 : load.i32         i6, i7, i0      
    14 : cmp              i6, i2          
    15 : unspill          i13, 3          
    16 : select_gt        i13, i0, i13    
    17 : spill            3, i13          
    18 : min              i2, i6, i2      
    19 : cmp              i6, i1          
    20 : unspill          i13, 2          
    21 : select_gt        i13, i0, i13    
    22 : spill            2, i13          
    23 : max              i1, i6, i1      
    24 : add              i0, i0, 4       
    25 : jmp              0               
    26 : __loops_label_2:                 
    27 : unspill          i13, 3          
    28 : sar              i7, i13, 2      
    29 : unspill          i13, 2          
    30 : sar              i6, i13, 2      
    31 : unspill          i13, 1          
    32 : store.i32        i13, i7         
    33 : unspill          i13, 0          
    34 : store.i32        i13, i6         
    35 : mov              i0, 0           
    36 : unspill          i13, 5          
    37 : add              i4, i4, 56      
    38 : ret                              
