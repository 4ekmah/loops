min_max_scalar(i0, i1, i2, i3)
     0 : sub              i4, i4, 88      
     1 : spill            5, i2           
     2 : spill            4, i1           
     3 : spill            9, i13          
     4 : mov              i0, 0           
     5 : mov              s7, 0           
     6 : mov              s6, 0           
     7 : load.i32         i2, i7          
     8 : mov              i1, i2          
     9 : mul              i13, i6, 4      
    10 : spill            8, i13          
    11 : __loops_label_0:                 
    12 : cmp              i0, s8          
    13 : jmp_ge           __loops_label_2 
    14 : load.i32         i6, i7, i0      
    15 : cmp              i6, i2          
    16 : jmp_ge           __loops_label_4 
    17 : mov              i2, i6          
    18 : mov              s7, i0          
    19 : __loops_label_4:                 
    20 : cmp              i6, i1          
    21 : jmp_le           __loops_label_6 
    22 : mov              i1, i6          
    23 : mov              s6, i0          
    24 : __loops_label_6:                 
    25 : add              i0, i0, 4       
    26 : jmp              0               
    27 : __loops_label_2:                 
    28 : mov              i7, 4           
    29 : unspill          i13, 7          
    30 : div              i6, i13, i7     
    31 : unspill          i13, 6          
    32 : div              i7, i13, i7     
    33 : unspill          i13, 5          
    34 : store.i32        i13, i6         
    35 : unspill          i13, 4          
    36 : store.i32        i13, i7         
    37 : mov              i0, 0           
    38 : unspill          i13, 9          
    39 : add              i4, i4, 88      
    40 : ret                              
