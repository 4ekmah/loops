fixed_power_v_float_9(i0, i1, i2)
     0 : mov              i1, 0           
     1 : mul              i2, i2, 4       
     2 : __loops_label_0:                 
     3 : cmp              i1, i2          
     4 : jmp_ge           __loops_label_2 
     5 : vld.fp32         v0, i7, i1      
     6 : mul.fp32         v1, v0, v0      
     7 : mul.fp32         v1, v1, v1      
     8 : mul.fp32         v1, v1, v1      
     9 : mul.fp32         v0, v0, v1      
    10 : vst.fp32         i6, i1, v0      
    11 : add              i1, i1, 32      
    12 : jmp              0               
    13 : __loops_label_2:                 
    14 : mov              i0, 0           
    15 : ret                              
