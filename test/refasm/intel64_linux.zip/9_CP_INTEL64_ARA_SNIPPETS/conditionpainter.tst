conditionpainter(i0)
     0 : sub              i4, i4, 56      
     1 : spill            5, i13          
     2 : mov              i13, -5         
     3 : spill            2, i13          
     4 : __loops_label_0:                 
     5 : cmp              s2, 5           
     6 : jmp_gt           __loops_label_2 
     7 : mov              i6, s2          
     8 : add              i6, i6, 5       
     9 : mul              i6, i6, 11      
    10 : mov              s1, i6          
    11 : unspill          i13, 1          
    12 : mul              i13, i13, 8     
    13 : spill            1, i13          
    14 : mov              i13, -5         
    15 : spill            0, i13          
    16 : __loops_label_3:                 
    17 : cmp              s0, 5           
    18 : jmp_gt           __loops_label_5 
    19 : mov              i0, s0          
    20 : add              i0, i0, 3       
    21 : mov              i1, 0           
    22 : cmp              s2, i0          
    23 : iverson_ge       i1              
    24 : mov              i0, 0           
    25 : cmp              s2, 4           
    26 : iverson_le       i0              
    27 : and              i0, i0, i1      
    28 : mov              i1, 0           
    29 : cmp              s0, -2          
    30 : iverson_ge       i1              
    31 : and              i1, i1, i0      
    32 : mov              i0, 0           
    33 : cmp              s0, 0           
    34 : iverson_le       i0              
    35 : and              i0, i0, i1      
    36 : unspill          i13, 0          
    37 : mov              i1, i13         
    38 : sub              i1, i1, 1       
    39 : mov              i2, 0           
    40 : cmp              s2, i1          
    41 : iverson_le       i2              
    42 : mov              i1, 0           
    43 : cmp              s0, 0           
    44 : iverson_ge       i1              
    45 : and              i1, i1, i2      
    46 : mov              i2, 0           
    47 : cmp              s2, 0           
    48 : iverson_le       i2              
    49 : and              i2, i2, i1      
    50 : mov              i1, s0          
    51 : mul              i1, i1, s0      
    52 : mov              i6, s2          
    53 : mul              i6, i6, s2      
    54 : add              i6, i6, i1      
    55 : mov              i1, 0           
    56 : cmp              i6, 9           
    57 : iverson_le       i1              
    58 : and              i1, i1, i2      
    59 : mov              s3, i1          
    60 : or               s3, s3, i0      
    61 : mov              i6, 2           
    62 : mov              s4, 0           
    63 : mov              i0, 0           
    64 : cmp              s0, 2           
    65 : iverson_ge       i0              
    66 : mov              i1, 0           
    67 : cmp              s0, 4           
    68 : iverson_le       i1              
    69 : and              i1, i1, i0      
    70 : mov              i0, 0           
    71 : cmp              s2, 1           
    72 : iverson_ge       i0              
    73 : mov              i2, 0           
    74 : cmp              s2, 3           
    75 : iverson_le       i2              
    76 : and              i2, i2, i0      
    77 : or               i2, i2, i1      
    78 : mov              i1, s0          
    79 : mul              i1, i1, s0      
    80 : mov              i0, s2          
    81 : mul              i0, i0, s2      
    82 : add              i0, i0, i1      
    83 : mov              i1, 0           
    84 : cmp              i0, 16          
    85 : iverson_le       i1              
    86 : and              i1, i1, i2      
    87 : cmp              i1, 0           
    88 : unspill          i13, 4          
    89 : select_eq        i6, i13, i6     
    90 : add              i6, i6, s3      
    91 : mov              i2, s2          
    92 : mul              i2, i2, 2       
    93 : cmp              i2, s0          
    94 : jmp_gt           __loops_label_8 
    95 : mov              i2, s0          
    96 : add              i2, i2, 3       
    97 : neg              i2, i2          
    98 : mov              i1, s0          
    99 : add              i1, i1, 3       
   100 : mul              i1, i1, i2      
   101 : cmp              s2, i1          
   102 : jmp_le           __loops_label_9 
   103 : __loops_label_8:                 
   104 : mov              i2, s0          
   105 : mul              i2, i2, 2       
   106 : cmp              s2, i2          
   107 : jmp_gt           __loops_label_7 
   108 : mov              i2, s0          
   109 : add              i2, i2, 3       
   110 : neg              i2, i2          
   111 : mov              i1, s0          
   112 : add              i1, i1, 3       
   113 : mul              i1, i1, i2      
   114 : cmp              s2, i1          
   115 : jmp_gt           __loops_label_7 
   116 : __loops_label_9:                 
   117 : cmp              s0, 0           
   118 : jmp_gt           __loops_label_7 
   119 : add              i6, i6, 3       
   120 : __loops_label_7:                 
   121 : mov              i2, s0          
   122 : add              i2, i2, 5       
   123 : shl              i2, i2, 3       
   124 : add              i2, i2, s1      
   125 : store.i64        i7, i2, i6      
   126 : add              s0, s0, 1       
   127 : jmp              3               
   128 : __loops_label_5:                 
   129 : add              s2, s2, 1       
   130 : jmp              0               
   131 : __loops_label_2:                 
   132 : unspill          i13, 5          
   133 : add              i4, i4, 56      
   134 : ret                              
