snake(i0, i1, i2)
     0 : sub              i4, i4, 744     
     1 : spill            90, i13         
     2 : spill            91, i14         
     3 : spill            92, i5          
     4 : mov              i5, i4          
     5 : add              i5, i5, 736     
     6 : mov              i1, i6          
     7 : add              i1, i1, i2      
     8 : mov              s84, i1         
     9 : sub              s84, s84, 1     
    10 : mov              i1, 0           
    11 : mov              s83, 1          
    12 : mov              i13, s83        
    13 : spill            80, i13         
    14 : neg              s80, s80        
    15 : mov              s85, 0          
    16 : __loops_label_0:                 
    17 : unspill          i13, 84         
    18 : cmp              s85, i13        
    19 : jmp_ge           __loops_label_2 
    20 : mov              s81, 0          
    21 : mov              s82, 0          
    22 : mov              i0, s85         
    23 : and              i0, i0, 1       
    24 : cmp              i0, 0           
    25 : jmp_eq           __loops_label_4 
    26 : mov              i0, i2          
    27 : sub              i0, i0, 1       
    28 : cmp              i0, s85         
    29 : unspill          i13, 85         
    30 : mov              i14, i13        
    31 : select_gt        i14, i0, i14    
    32 : spill            81, i14         
    33 : unspill          i13, 85         
    34 : mov              s86, i13        
    35 : sub              s86, s86, i0    
    36 : mov              s87, 0          
    37 : cmp              s85, i0         
    38 : unspill          i13, 87         
    39 : mov              i14, i13        
    40 : select_gt        i14, s86, i14   
    41 : spill            82, i14         
    42 : jmp              5               
    43 : __loops_label_4:                 
    44 : mov              s88, i6         
    45 : sub              s88, s88, 1     
    46 : unspill          i13, 85         
    47 : mov              i0, i13         
    48 : sub              i0, i0, s88     
    49 : mov              s89, 0          
    50 : unspill          i13, 88         
    51 : cmp              s85, i13        
    52 : unspill          i13, 89         
    53 : mov              i14, i13        
    54 : select_gt        i14, i0, i14    
    55 : spill            81, i14         
    56 : unspill          i13, 85         
    57 : cmp              s88, i13        
    58 : unspill          i13, 85         
    59 : mov              i14, i13        
    60 : select_gt        i14, s88, i14   
    61 : spill            82, i14         
    62 : __loops_label_5:                 
    63 : __loops_label_6:                 
    64 : cmp              s81, 0          
    65 : jmp_gt           __loops_label_8 
    66 : cmp              s81, i2         
    67 : jmp_ge           __loops_label_8 
    68 : cmp              s82, 0          
    69 : jmp_gt           __loops_label_8 
    70 : cmp              s82, i6         
    71 : jmp_ge           __loops_label_8 
    72 : mov              i0, -100345469  
    73 : unspill          i13, 81         
    74 : unspill          i14, 82         
    75 : spill            0, i0           
    76 : spill            1, i1           
    77 : spill            2, i2           
    78 : spill            3, i6           
    79 : spill            4, i7           
    80 : spill            5, i8           
    81 : spill            6, i9           
    82 : spill            7, i10          
    83 : spill            8, i11          
    84 : spill            12, v0          
    85 : spill            16, v1          
    86 : spill            20, v2          
    87 : spill            24, v3          
    88 : spill            28, v4          
    89 : spill            32, v5          
    90 : spill            36, v6          
    91 : spill            40, v7          
    92 : spill            44, v8          
    93 : spill            48, v9          
    94 : spill            52, v10         
    95 : spill            56, v11         
    96 : spill            60, v12         
    97 : spill            64, v13         
    98 : spill            68, v14         
    99 : spill            72, v15         
   100 : mov              i7, i13         
   101 : mov              i6, i14         
   102 : call_noret       [i0]()          
   103 : unspill          i0, 0           
   104 : unspill          i1, 1           
   105 : unspill          i2, 2           
   106 : unspill          i6, 3           
   107 : unspill          i7, 4           
   108 : unspill          i8, 5           
   109 : unspill          i9, 6           
   110 : unspill          i10, 7          
   111 : unspill          i11, 8          
   112 : unspill          v0, 12          
   113 : unspill          v1, 16          
   114 : unspill          v2, 20          
   115 : unspill          v3, 24          
   116 : unspill          v4, 28          
   117 : unspill          v5, 32          
   118 : unspill          v6, 36          
   119 : unspill          v7, 40          
   120 : unspill          v8, 44          
   121 : unspill          v9, 48          
   122 : unspill          v10, 52         
   123 : unspill          v11, 56         
   124 : unspill          v12, 60         
   125 : unspill          v13, 64         
   126 : unspill          v14, 68         
   127 : unspill          v15, 72         
   128 : mov              i0, s82         
   129 : mul              i0, i0, i2      
   130 : add              i0, i0, s81     
   131 : store.u8         i7, i0, i1      
   132 : add              i1, i1, 1       
   133 : unspill          i13, 83         
   134 : add              s81, s81, i13   
   135 : unspill          i13, 80         
   136 : add              s82, s82, i13   
   137 : jmp              6               
   138 : __loops_label_8:                 
   139 : neg              s83, s83        
   140 : neg              s80, s80        
   141 : add              s85, s85, 1     
   142 : jmp              0               
   143 : __loops_label_2:                 
   144 : unspill          i5, 92          
   145 : unspill          i13, 90         
   146 : unspill          i14, 91         
   147 : add              i4, i4, 744     
   148 : ret                              
