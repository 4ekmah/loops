fixed_power_v_uint32_t_4(i0, i1, i2)
     0 : sub              i4, i4, 40      
     1 : mov              i1, 0           
     2 : mul              i2, i2, 4       
     3 : mov              i0, i2          
     4 : __loops_label_0:                 
     5 : cmp              i1, i0          
     6 : jmp_ge           __loops_label_2 
     7 : vld.u32          v0, i7, i1      
     8 : mul.u32          v0, v0, v0      
     9 : mul.u32          v0, v0, v0      
    10 : vst.u32          i6, i1, v0      
    11 : add              i1, i1, 32      
    12 : jmp              0               
    13 : __loops_label_2:                 
    14 : mov              i0, 0           
    15 : add              i4, i4, 40      
    16 : ret                              
