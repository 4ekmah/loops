sort_double(i0, i1)
     0 : sub              i4, i4, 696     
     1 : spill            85, i13         
     2 : spill            86, i5          
     3 : mov              i5, i4          
     4 : add              i5, i5, 688     
     5 : mov              s82, i6         
     6 : shl              s82, s82, 3     
     7 : unspill          i13, 82         
     8 : mov              s83, i13        
     9 : sub              s83, s83, 8     
    10 : mov              s84, 0          
    11 : __loops_label_0:                 
    12 : unspill          i13, 83         
    13 : cmp              s84, i13        
    14 : jmp_ge           __loops_label_2 
    15 : mov              i13, s84        
    16 : spill            81, i13         
    17 : mov              i13, s81        
    18 : spill            80, i13         
    19 : add              s80, s80, 8     
    20 : __loops_label_3:                 
    21 : unspill          i13, 82         
    22 : cmp              s80, i13        
    23 : jmp_ge           __loops_label_5 
    24 : unspill          i13, 80         
    25 : load.fp64        i0, i7, i13     
    26 : unspill          i13, 81         
    27 : load.fp64        i1, i7, i13     
    28 : mov              i2, -1655104486 
    29 : spill            0, i0           
    30 : spill            1, i1           
    31 : spill            2, i2           
    32 : spill            3, i6           
    33 : spill            4, i7           
    34 : spill            5, i8           
    35 : spill            6, i9           
    36 : spill            7, i10          
    37 : spill            8, i11          
    38 : spill            12, v0          
    39 : spill            16, v1          
    40 : spill            20, v2          
    41 : spill            24, v3          
    42 : spill            28, v4          
    43 : spill            32, v5          
    44 : spill            36, v6          
    45 : spill            40, v7          
    46 : spill            44, v8          
    47 : spill            48, v9          
    48 : spill            52, v10         
    49 : spill            56, v11         
    50 : spill            60, v12         
    51 : spill            64, v13         
    52 : spill            68, v14         
    53 : spill            72, v15         
    54 : mov              i7, i0          
    55 : mov              i6, i1          
    56 : call_noret       [i2]()          
    57 : mov              i2, i0          
    58 : unspill          i0, 0           
    59 : unspill          i1, 1           
    60 : unspill          i6, 3           
    61 : unspill          i7, 4           
    62 : unspill          i8, 5           
    63 : unspill          i9, 6           
    64 : unspill          i10, 7          
    65 : unspill          i11, 8          
    66 : unspill          v0, 12          
    67 : unspill          v1, 16          
    68 : unspill          v2, 20          
    69 : unspill          v3, 24          
    70 : unspill          v4, 28          
    71 : unspill          v5, 32          
    72 : unspill          v6, 36          
    73 : unspill          v7, 40          
    74 : unspill          v8, 44          
    75 : unspill          v9, 48          
    76 : unspill          v10, 52         
    77 : unspill          v11, 56         
    78 : unspill          v12, 60         
    79 : unspill          v13, 64         
    80 : unspill          v14, 68         
    81 : unspill          v15, 72         
    82 : cmp              i2, 0           
    83 : jmp_eq           __loops_label_7 
    84 : mov              i13, s80        
    85 : spill            81, i13         
    86 : __loops_label_7:                 
    87 : add              s80, s80, 8     
    88 : jmp              3               
    89 : __loops_label_5:                 
    90 : unspill          i13, 84         
    91 : cmp              s81, i13        
    92 : jmp_eq           __loops_label_9 
    93 : unspill          i13, 84         
    94 : load.fp64        i2, i7, i13     
    95 : unspill          i13, 81         
    96 : load.fp64        i1, i7, i13     
    97 : unspill          i13, 81         
    98 : store.fp64       i7, i13, i2     
    99 : unspill          i13, 84         
   100 : store.fp64       i7, i13, i1     
   101 : __loops_label_9:                 
   102 : add              s84, s84, 8     
   103 : jmp              0               
   104 : __loops_label_2:                 
   105 : unspill          i5, 86          
   106 : unspill          i13, 85         
   107 : add              i4, i4, 696     
   108 : ret                              
