bresenham(i0, i1, i2, i3, i4, i5, i6)
     0 : sub               i4, i4, 104      
     1 : spill             10, i13          
     2 : spill             11, i14          
     3 : spill             9, i9            
     4 : mov               i0, i8           
     5 : sub               i0, i0, i2       
     6 : mov               i9, i0           
     7 : neg               i9, i9           
     8 : mov               i13, i9          
     9 : select_s          i13, i0, i13     
    10 : spill             1, i13           
    11 : mov               i0, i8           
    12 : sub               i0, i0, i2       
    13 : mov               i9, i0           
    14 : sar               i0, i0, 63       
    15 : neg               i9, i9           
    16 : mov               s2, i0           
    17 : x86_adc           s2, s2, i0       
    18 : unspill           i13, 9           
    19 : mov               i0, i13          
    20 : sub               i0, i0, i1       
    21 : mov               i9, i0           
    22 : neg               i9, i9           
    23 : select_s          i9, i0, i9       
    24 : mov               s3, i9           
    25 : neg               s3, s3           
    26 : unspill           i13, 9           
    27 : mov               i0, i13          
    28 : sub               i0, i0, i1       
    29 : mov               i9, i0           
    30 : sar               i0, i0, 63       
    31 : neg               i9, i9           
    32 : mov               i9, i0           
    33 : x86_adc           i9, i9, i0       
    34 : mov               i13, s1          
    35 : spill             5, i13           
    36 : unspill           i13, 3           
    37 : add               s5, s5, i13      
    38 : spill             4, i9            
    39 : __loops_label_0:                   
    40 : cmp               i7, 0            
    41 : jmp_eq            __loops_label_2  
    42 : mov               s6, i1           
    43 : unspill           i13, 6           
    44 : mul               i13, i13, i6     
    45 : spill             6, i13           
    46 : mov               i13, s6          
    47 : spill             7, i13           
    48 : add               s7, s7, i2       
    49 : unspill           i14, 14          
    50 : unspill           i13, 7           
    51 : store.u8          i7, i13, i14     
    52 : cmp               i2, i8           
    53 : jmp_ne            __loops_label_4  
    54 : cmp               i1, s9           
    55 : jmp_ne            __loops_label_4  
    56 : jmp               2                
    57 : __loops_label_4:                   
    58 : mov               i13, s5          
    59 : spill             8, i13           
    60 : shl               s8, s8, 1        
    61 : unspill           i13, 3           
    62 : cmp               s8, i13          
    63 : jmp_gt            __loops_label_6  
    64 : cmp               i2, i8           
    65 : jmp_ne            __loops_label_8  
    66 : jmp               2                
    67 : __loops_label_8:                   
    68 : unspill           i13, 3           
    69 : add               s5, s5, i13      
    70 : add               i2, i2, s2       
    71 : __loops_label_6:                   
    72 : unspill           i13, 1           
    73 : cmp               s8, i13          
    74 : jmp_gt            __loops_label_10 
    75 : cmp               i1, s9           
    76 : jmp_ne            __loops_label_12 
    77 : jmp               2                
    78 : __loops_label_12:                  
    79 : unspill           i13, 1           
    80 : add               s5, s5, i13      
    81 : add               i1, i1, s4       
    82 : __loops_label_10:                  
    83 : jmp               0                
    84 : __loops_label_2:                   
    85 : unspill           i13, 10          
    86 : unspill           i14, 11          
    87 : add               i4, i4, 104      
    88 : ret                                
