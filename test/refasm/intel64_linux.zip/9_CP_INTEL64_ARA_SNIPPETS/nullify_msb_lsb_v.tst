nullify_msb_lsb_v(i0, i1, i2, i3)
     0 : sub              i4, i4, 40      
     1 : spill            3, i13          
     2 : mov              s2, 0           
     3 : mul              i1, i1, 4       
     4 : mov              i0, 1           
     5 : vdef.u32         v1              
     6 : setlane.u32      v1, 0, i0       
     7 : broadcast.u32    v0, v1, 0       
     8 : spill            1, i1           
     9 : __loops_label_0:                 
    10 : unspill          i13, 1          
    11 : cmp              s2, i13         
    12 : jmp_ge           __loops_label_2 
    13 : unspill          i13, 2          
    14 : vld.u32          v1, i7, i13     
    15 : shr.u32          v2, v1, 1       
    16 : or               v2, v1, v2      
    17 : shr.u32          v3, v2, 2       
    18 : or               v2, v2, v3      
    19 : shr.u32          v3, v2, 4       
    20 : or               v2, v2, v3      
    21 : shr.u32          v3, v2, 8       
    22 : or               v2, v2, v3      
    23 : shr.u32          v3, v2, 16      
    24 : or               v2, v2, v3      
    25 : add.u32          v2, v2, v0      
    26 : shr.u32          v2, v2, 1       
    27 : xor              v2, v2, v1      
    28 : unspill          i13, 2          
    29 : vst.u32          i6, i13, v2     
    30 : sub.u32          v2, v1, v0      
    31 : mov              i0, 255         
    32 : vdef.u8          v3              
    33 : setlane.u8       v3, 0, i0       
    34 : broadcast.u8     v3, v3, 0       
    35 : xor              v2, v2, v3      
    36 : and              v2, v1, v2      
    37 : xor              v1, v2, v1      
    38 : unspill          i13, 2          
    39 : vst.u32          i2, i13, v1     
    40 : add              s2, s2, 32      
    41 : jmp              0               
    42 : __loops_label_2:                 
    43 : unspill          i13, 3          
    44 : add              i4, i4, 40      
    45 : ret                              
