fixed_power_9(i0)
     0 : mov i6, i7     
     1 : mul i6, i6, i7 
     2 : mov i2, i6     
     3 : mul i2, i2, i6 
     4 : mov i6, i2     
     5 : mul i6, i6, i2 
     6 : mul i6, i6, i7 
     7 : mov i0, i6     
     8 : ret            
