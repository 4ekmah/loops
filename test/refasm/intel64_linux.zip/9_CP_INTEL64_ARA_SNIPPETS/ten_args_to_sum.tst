ten_args_to_sum(i0, i1, i2, i3, i4, i5, i6, i7, i8, i9)
     0 : sub     i4, i4, 8  
     1 : unspill i0, 2      
     2 : mul     i7, i7, 1  
     3 : mul     i6, i6, 2  
     4 : add     i6, i6, i7 
     5 : mul     i2, i2, 3  
     6 : add     i2, i2, i6 
     7 : mul     i1, i1, 4  
     8 : add     i1, i1, i2 
     9 : mul     i8, i8, 5  
    10 : add     i8, i8, i1 
    11 : mul     i9, i9, 6  
    12 : add     i9, i9, i8 
    13 : mul     i0, i0, 7  
    14 : add     i0, i0, i9 
    15 : mov     i7, s3     
    16 : mul     i7, i7, 8  
    17 : add     i7, i7, i0 
    18 : mov     i6, s4     
    19 : mul     i6, i6, 3  
    20 : add     i6, i6, i7 
    21 : mov     i7, s5     
    22 : mul     i7, i7, 2  
    23 : add     i7, i7, i6 
    24 : mov     i0, i7     
    25 : add     i4, i4, 8  
    26 : ret                
