a_plus_b(i0, i1)
     0 : add i6, i6, i7 
     1 : mov i0, i6     
     2 : ret            
