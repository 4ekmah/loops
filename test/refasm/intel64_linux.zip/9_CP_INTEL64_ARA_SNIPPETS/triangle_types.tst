triangle_types(i0, i1, i2)
     0 : sub               i4, i4, 40       
     1 : spill             4, i6            
     2 : cmp               i7, 0            
     3 : jmp_le            __loops_label_0  
     4 : cmp               s4, 0            
     5 : jmp_le            __loops_label_0  
     6 : cmp               i2, 0            
     7 : jmp_gt            __loops_label_1  
     8 : __loops_label_0:                   
     9 : mov               i0, 0            
    10 : jmp               18               
    11 : __loops_label_1:                   
    12 : mov               i1, s4           
    13 : add               i1, i1, i2       
    14 : cmp               i7, i1           
    15 : jmp_gt            __loops_label_3  
    16 : mov               i1, i7           
    17 : add               i1, i1, i2       
    18 : cmp               s4, i1           
    19 : jmp_gt            __loops_label_3  
    20 : mov               i1, i7           
    21 : add               i1, i1, s4       
    22 : cmp               i2, i1           
    23 : jmp_le            __loops_label_4  
    24 : __loops_label_3:                   
    25 : mov               i0, 0            
    26 : jmp               18               
    27 : __loops_label_4:                   
    28 : cmp               i7, s4           
    29 : jmp_ne            __loops_label_7  
    30 : cmp               i7, i2           
    31 : jmp_ne            __loops_label_7  
    32 : mov               i0, 2            
    33 : jmp               18               
    34 : __loops_label_7:                   
    35 : cmp               i7, s4           
    36 : jmp_eq            __loops_label_9  
    37 : cmp               i7, i2           
    38 : jmp_eq            __loops_label_9  
    39 : cmp               s4, i2           
    40 : jmp_ne            __loops_label_10 
    41 : __loops_label_9:                   
    42 : mov               i0, 3            
    43 : jmp               18               
    44 : __loops_label_10:                  
    45 : mov               i1, i7           
    46 : mul               i1, i1, i7       
    47 : mov               i0, s4           
    48 : mul               i0, i0, s4       
    49 : mov               i6, i2           
    50 : mul               i6, i6, i2       
    51 : add               i6, i6, i0       
    52 : cmp               i1, i6           
    53 : jmp_eq            __loops_label_12 
    54 : mov               i6, s4           
    55 : mul               i6, i6, s4       
    56 : mov               i1, i7           
    57 : mul               i1, i1, i7       
    58 : mov               i0, i2           
    59 : mul               i0, i0, i2       
    60 : add               i0, i0, i1       
    61 : cmp               i6, i0           
    62 : jmp_eq            __loops_label_12 
    63 : mov               i6, i2           
    64 : mul               i6, i6, i2       
    65 : mov               i1, i7           
    66 : mul               i1, i1, i7       
    67 : mov               i0, s4           
    68 : mul               i0, i0, s4       
    69 : add               i0, i0, i1       
    70 : cmp               i6, i0           
    71 : jmp_ne            __loops_label_13 
    72 : __loops_label_12:                  
    73 : mov               i0, 1            
    74 : jmp               18               
    75 : __loops_label_13:                  
    76 : mov               i6, i7           
    77 : mul               i6, i6, i7       
    78 : mov               i1, s4           
    79 : mul               i1, i1, s4       
    80 : mov               i0, i2           
    81 : mul               i0, i0, i2       
    82 : add               i0, i0, i1       
    83 : cmp               i6, i0           
    84 : jmp_gt            __loops_label_15 
    85 : mov               i6, s4           
    86 : mul               i6, i6, s4       
    87 : mov               i1, i7           
    88 : mul               i1, i1, i7       
    89 : mov               i0, i2           
    90 : mul               i0, i0, i2       
    91 : add               i0, i0, i1       
    92 : cmp               i6, i0           
    93 : jmp_gt            __loops_label_15 
    94 : mov               i6, i2           
    95 : mul               i6, i6, i2       
    96 : mov               i2, i7           
    97 : mul               i2, i2, i7       
    98 : mov               i7, s4           
    99 : mul               i7, i7, s4       
   100 : add               i7, i7, i2       
   101 : cmp               i6, i7           
   102 : jmp_le            __loops_label_16 
   103 : __loops_label_15:                  
   104 : mov               i0, 5            
   105 : jmp               18               
   106 : __loops_label_16:                  
   107 : mov               i0, 4            
   108 : jmp               18               
   109 : __loops_label_2:                   
   110 : __loops_label_5:                   
   111 : __loops_label_8:                   
   112 : __loops_label_11:                  
   113 : __loops_label_14:                  
   114 : __loops_label_17:                  
   115 : __loops_label_18:                  
   116 : add               i4, i4, 40       
   117 : ret                                
