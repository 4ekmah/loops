min_max_select(i0, i1, i2, i3)
     0 : sub              i4, i4, 72      
     1 : spill            7, i13          
     2 : mov              s6, 0           
     3 : mov              s1, 0           
     4 : mov              s2, 0           
     5 : load.i32         i13, i7         
     6 : spill            3, i13          
     7 : mov              i13, s3         
     8 : spill            4, i13          
     9 : shl              i6, i6, 2       
    10 : spill            5, i6           
    11 : __loops_label_0:                 
    12 : unspill          i13, 5          
    13 : cmp              s6, i13         
    14 : jmp_ge           __loops_label_2 
    15 : unspill          i13, 6          
    16 : load.i32         i0, i7, i13     
    17 : cmp              i0, s3          
    18 : unspill          i13, 1          
    19 : select_gt        i13, s6, i13    
    20 : spill            1, i13          
    21 : cmp              i0, s3          
    22 : unspill          i13, 3          
    23 : select_gt        i13, i0, i13    
    24 : spill            3, i13          
    25 : cmp              i0, s4          
    26 : unspill          i13, 2          
    27 : select_gt        i13, s6, i13    
    28 : spill            2, i13          
    29 : cmp              i0, s4          
    30 : unspill          i13, 4          
    31 : select_gt        i13, i0, i13    
    32 : spill            4, i13          
    33 : add              s6, s6, 4       
    34 : jmp              0               
    35 : __loops_label_2:                 
    36 : sar              s1, s1, 2       
    37 : sar              s2, s2, 2       
    38 : unspill          i13, 1          
    39 : store.i32        i2, i13         
    40 : unspill          i13, 2          
    41 : store.i32        i1, i13         
    42 : mov              i0, 0           
    43 : unspill          i13, 7          
    44 : add              i4, i4, 72      
    45 : ret                              
