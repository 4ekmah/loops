min_max_scalar(i0, i1, i2, i3)
     0 : sub              i4, i4, 104     
     1 : spill            12, i13         
     2 : mov              s9, 0           
     3 : mov              s4, 0           
     4 : mov              s5, 0           
     5 : load.i32         i13, i7         
     6 : spill            6, i13          
     7 : mov              i13, s6         
     8 : spill            7, i13          
     9 : mul              i6, i6, 4       
    10 : spill            8, i6           
    11 : __loops_label_0:                 
    12 : unspill          i13, 8          
    13 : cmp              s9, i13         
    14 : jmp_ge           __loops_label_2 
    15 : unspill          i13, 9          
    16 : load.i32         i0, i7, i13     
    17 : cmp              i0, s6          
    18 : jmp_ge           __loops_label_4 
    19 : mov              s6, i0          
    20 : mov              i13, s9         
    21 : spill            4, i13          
    22 : __loops_label_4:                 
    23 : cmp              i0, s7          
    24 : jmp_le           __loops_label_6 
    25 : mov              s7, i0          
    26 : mov              i13, s9         
    27 : spill            5, i13          
    28 : __loops_label_6:                 
    29 : add              s9, s9, 4       
    30 : jmp              0               
    31 : __loops_label_2:                 
    32 : mov              s10, 4          
    33 : mov              i7, s4          
    34 : spill            11, i2          
    35 : mov              i0, i7          
    36 : x86_cqo                          
    37 : div              i0, i0, s10     
    38 : unspill          i2, 11          
    39 : mov              i7, i0          
    40 : mov              i6, s5          
    41 : spill            11, i2          
    42 : mov              i0, i6          
    43 : x86_cqo                          
    44 : div              i0, i0, s10     
    45 : unspill          i2, 11          
    46 : mov              i6, i0          
    47 : store.i32        i2, i7          
    48 : store.i32        i1, i6          
    49 : mov              i0, 0           
    50 : unspill          i13, 12         
    51 : add              i4, i4, 104     
    52 : ret                              
