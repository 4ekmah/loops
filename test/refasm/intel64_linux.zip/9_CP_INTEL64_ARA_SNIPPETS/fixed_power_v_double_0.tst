fixed_power_v_double_0(i0, i1, i2)
     0 : sub              i4, i4, 40      
     1 : mov              i1, 0           
     2 : mul              i2, i2, 8       
     3 : spill            4, i2           
     4 : __loops_label_0:                 
     5 : cmp              i1, s4          
     6 : jmp_ge           __loops_label_2 
     7 : vld.fp64         v0, i7, i1      
     8 : mov              i0, 0           
     9 : vdef.fp64        v0              
    10 : setlane.fp64     v0, 0, i0       
    11 : broadcast.fp64   v0, v0, 0       
    12 : vst.fp64         i6, i1, v0      
    13 : add              i1, i1, 32      
    14 : jmp              0               
    15 : __loops_label_2:                 
    16 : mov              i0, 0           
    17 : add              i4, i4, 40      
    18 : ret                              
