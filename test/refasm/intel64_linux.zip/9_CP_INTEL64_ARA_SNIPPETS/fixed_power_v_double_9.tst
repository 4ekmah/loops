fixed_power_v_double_9(i0, i1, i2)
     0 : sub              i4, i4, 8       
     1 : mov              i1, 0           
     2 : mul              i2, i2, 8       
     3 : mov              i0, i2          
     4 : __loops_label_0:                 
     5 : cmp              i1, i0          
     6 : jmp_ge           __loops_label_2 
     7 : vld.fp64         v0, i7, i1      
     8 : mul.fp64         v1, v0, v0      
     9 : mul.fp64         v1, v1, v1      
    10 : mul.fp64         v1, v1, v1      
    11 : mul.fp64         v0, v0, v1      
    12 : vst.fp64         i6, i1, v0      
    13 : add              i1, i1, 32      
    14 : jmp              0               
    15 : __loops_label_2:                 
    16 : mov              i0, 0           
    17 : add              i4, i4, 8       
    18 : ret                              
