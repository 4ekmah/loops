all_loads_all_stores(i0, i1, i2, i3, i4)
     0 : sub               i4, i4, 104      
     1 : spill             11, i13          
     2 : mov               s4, 0            
     3 : mov               s0, 0            
     4 : mov               s1, 0            
     5 : mov               i0, 2            
     6 : mov               s5, 1            
     7 : cmp               i6, 1            
     8 : unspill           i13, 5           
     9 : select_le         i0, i13, i0      
    10 : mov               s6, 4            
    11 : cmp               i6, 3            
    12 : select_gt         i0, s6, i0       
    13 : mov               s7, 8            
    14 : cmp               i6, 5            
    15 : mov               i13, i0          
    16 : select_gt         i13, s7, i13     
    17 : spill             2, i13           
    18 : mov               i0, 2            
    19 : mov               s8, 1            
    20 : cmp               i1, 1            
    21 : unspill           i13, 8           
    22 : select_le         i0, i13, i0      
    23 : mov               s9, 4            
    24 : cmp               i1, 3            
    25 : select_gt         i0, s9, i0       
    26 : mov               s10, 8           
    27 : cmp               i1, 5            
    28 : mov               i13, i0          
    29 : select_gt         i13, s10, i13    
    30 : spill             3, i13           
    31 : __loops_label_0:                   
    32 : cmp               s4, i8           
    33 : jmp_ge            __loops_label_2  
    34 : def               i0               
    35 : cmp               i6, 0            
    36 : jmp_ne            __loops_label_4  
    37 : unspill           i13, 0           
    38 : load.u8           i0, i7, i13      
    39 : jmp               5                
    40 : __loops_label_4:                   
    41 : cmp               i6, 1            
    42 : jmp_ne            __loops_label_7  
    43 : unspill           i13, 0           
    44 : load.i8           i0, i7, i13      
    45 : jmp               8                
    46 : __loops_label_7:                   
    47 : cmp               i6, 2            
    48 : jmp_ne            __loops_label_10 
    49 : unspill           i13, 0           
    50 : load.u16          i0, i7, i13      
    51 : jmp               11               
    52 : __loops_label_10:                  
    53 : cmp               i6, 3            
    54 : jmp_ne            __loops_label_13 
    55 : unspill           i13, 0           
    56 : load.i16          i0, i7, i13      
    57 : jmp               14               
    58 : __loops_label_13:                  
    59 : cmp               i6, 4            
    60 : jmp_ne            __loops_label_16 
    61 : unspill           i13, 0           
    62 : load.u32          i0, i7, i13      
    63 : jmp               17               
    64 : __loops_label_16:                  
    65 : cmp               i6, 5            
    66 : jmp_ne            __loops_label_19 
    67 : unspill           i13, 0           
    68 : load.i32          i0, i7, i13      
    69 : jmp               20               
    70 : __loops_label_19:                  
    71 : cmp               i6, 6            
    72 : jmp_ne            __loops_label_22 
    73 : unspill           i13, 0           
    74 : load.u64          i0, i7, i13      
    75 : jmp               23               
    76 : __loops_label_22:                  
    77 : unspill           i13, 0           
    78 : load.i64          i0, i7, i13      
    79 : __loops_label_5:                   
    80 : __loops_label_8:                   
    81 : __loops_label_11:                  
    82 : __loops_label_14:                  
    83 : __loops_label_17:                  
    84 : __loops_label_20:                  
    85 : __loops_label_23:                  
    86 : cmp               i1, 0            
    87 : jmp_ne            __loops_label_25 
    88 : unspill           i13, 1           
    89 : store.u8          i2, i13, i0      
    90 : jmp               26               
    91 : __loops_label_25:                  
    92 : cmp               i1, 1            
    93 : jmp_ne            __loops_label_28 
    94 : unspill           i13, 1           
    95 : store.i8          i2, i13, i0      
    96 : jmp               29               
    97 : __loops_label_28:                  
    98 : cmp               i1, 2            
    99 : jmp_ne            __loops_label_31 
   100 : unspill           i13, 1           
   101 : store.u16         i2, i13, i0      
   102 : jmp               32               
   103 : __loops_label_31:                  
   104 : cmp               i1, 3            
   105 : jmp_ne            __loops_label_34 
   106 : unspill           i13, 1           
   107 : store.i16         i2, i13, i0      
   108 : jmp               35               
   109 : __loops_label_34:                  
   110 : cmp               i1, 4            
   111 : jmp_ne            __loops_label_37 
   112 : unspill           i13, 1           
   113 : store.u32         i2, i13, i0      
   114 : jmp               38               
   115 : __loops_label_37:                  
   116 : cmp               i1, 5            
   117 : jmp_ne            __loops_label_40 
   118 : unspill           i13, 1           
   119 : store.i32         i2, i13, i0      
   120 : jmp               41               
   121 : __loops_label_40:                  
   122 : cmp               i1, 6            
   123 : jmp_ne            __loops_label_43 
   124 : unspill           i13, 1           
   125 : store.u64         i2, i13, i0      
   126 : jmp               44               
   127 : __loops_label_43:                  
   128 : unspill           i13, 1           
   129 : store.i64         i2, i13, i0      
   130 : __loops_label_26:                  
   131 : __loops_label_29:                  
   132 : __loops_label_32:                  
   133 : __loops_label_35:                  
   134 : __loops_label_38:                  
   135 : __loops_label_41:                  
   136 : __loops_label_44:                  
   137 : unspill           i13, 2           
   138 : add               s0, s0, i13      
   139 : unspill           i13, 3           
   140 : add               s1, s1, i13      
   141 : add               s4, s4, 1        
   142 : jmp               0                
   143 : __loops_label_2:                   
   144 : unspill           i13, 11          
   145 : add               i4, i4, 104      
   146 : ret                                
