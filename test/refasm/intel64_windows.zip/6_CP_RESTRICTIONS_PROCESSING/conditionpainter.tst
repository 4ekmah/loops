conditionpainter(i0)
     0 : mov                    i1, -5          
     1 : annotation:whilecstart 0               
     2 : cmp                    i1, 5           
     3 : jmp_gt                 __loops_label_2 
     4 : annotation:whilecend                   
     5 : mov                    i4, i1          
     6 : add                    i4, i4, 5       
     7 : mov                    i3, i4          
     8 : mul                    i3, i3, 11      
     9 : mov                    i2, i3          
    10 : mul                    i2, i2, 8       
    11 : mov                    i5, -5          
    12 : annotation:whilecstart 3               
    13 : cmp                    i5, 5           
    14 : jmp_gt                 __loops_label_5 
    15 : annotation:whilecend                   
    16 : mov                    i11, i5         
    17 : add                    i11, i11, 3     
    18 : mov                    i12, 0          
    19 : cmp                    i1, i11         
    20 : iverson_ge             i12             
    21 : mov                    i13, 0          
    22 : cmp                    i1, 4           
    23 : iverson_le             i13             
    24 : mov                    i10, i13        
    25 : and                    i10, i10, i12   
    26 : mov                    i14, 0          
    27 : cmp                    i5, -2          
    28 : iverson_ge             i14             
    29 : mov                    i9, i14         
    30 : and                    i9, i9, i10     
    31 : mov                    i15, 0          
    32 : cmp                    i5, 0           
    33 : iverson_le             i15             
    34 : mov                    i8, i15         
    35 : and                    i8, i8, i9      
    36 : sub                    i19, i5, 1      
    37 : mov                    i20, 0          
    38 : cmp                    i1, i19         
    39 : iverson_le             i20             
    40 : mov                    i21, 0          
    41 : cmp                    i5, 0           
    42 : iverson_ge             i21             
    43 : mov                    i18, i21        
    44 : and                    i18, i18, i20   
    45 : mov                    i22, 0          
    46 : cmp                    i1, 0           
    47 : iverson_le             i22             
    48 : mov                    i17, i22        
    49 : and                    i17, i17, i18   
    50 : mov                    i24, i5         
    51 : mul                    i24, i24, i5    
    52 : mov                    i25, i1         
    53 : mul                    i25, i25, i1    
    54 : mov                    i23, i25        
    55 : add                    i23, i23, i24   
    56 : mov                    i26, 0          
    57 : cmp                    i23, 9          
    58 : iverson_le             i26             
    59 : mov                    i16, i26        
    60 : and                    i16, i16, i17   
    61 : mov                    i6, i16         
    62 : or                     i6, i6, i8      
    63 : mov                    i27, 2          
    64 : mov                    i28, 0          
    65 : mov                    i32, 0          
    66 : cmp                    i5, 2           
    67 : iverson_ge             i32             
    68 : mov                    i33, 0          
    69 : cmp                    i5, 4           
    70 : iverson_le             i33             
    71 : mov                    i31, i33        
    72 : and                    i31, i31, i32   
    73 : mov                    i35, 0          
    74 : cmp                    i1, 1           
    75 : iverson_ge             i35             
    76 : mov                    i36, 0          
    77 : cmp                    i1, 3           
    78 : iverson_le             i36             
    79 : mov                    i34, i36        
    80 : and                    i34, i34, i35   
    81 : mov                    i30, i34        
    82 : or                     i30, i30, i31   
    83 : mov                    i38, i5         
    84 : mul                    i38, i38, i5    
    85 : mov                    i39, i1         
    86 : mul                    i39, i39, i1    
    87 : mov                    i37, i39        
    88 : add                    i37, i37, i38   
    89 : mov                    i40, 0          
    90 : cmp                    i37, 16         
    91 : iverson_le             i40             
    92 : mov                    i29, i40        
    93 : and                    i29, i29, i30   
    94 : cmp                    i29, 0          
    95 : select_ne              i41, i27, i28   
    96 : mov                    i7, i41         
    97 : add                    i7, i7, i6      
    98 : annotation:ifcstart                    
    99 : mov                    i42, i1         
   100 : mul                    i42, i42, 2     
   101 : cmp                    i42, i5         
   102 : jmp_gt                 __loops_label_8 
   103 : mov                    i45, i5         
   104 : add                    i45, i45, 3     
   105 : mov                    i44, i45        
   106 : neg                    i44, i44        
   107 : mov                    i46, i5         
   108 : add                    i46, i46, 3     
   109 : mov                    i43, i46        
   110 : mul                    i43, i43, i44   
   111 : cmp                    i1, i43         
   112 : jmp_le                 __loops_label_9 
   113 : __loops_label_8:                       
   114 : mov                    i47, i5         
   115 : mul                    i47, i47, 2     
   116 : cmp                    i1, i47         
   117 : jmp_gt                 __loops_label_7 
   118 : mov                    i50, i5         
   119 : add                    i50, i50, 3     
   120 : mov                    i49, i50        
   121 : neg                    i49, i49        
   122 : mov                    i51, i5         
   123 : add                    i51, i51, 3     
   124 : mov                    i48, i51        
   125 : mul                    i48, i48, i49   
   126 : cmp                    i1, i48         
   127 : jmp_gt                 __loops_label_7 
   128 : __loops_label_9:                       
   129 : cmp                    i5, 0           
   130 : jmp_gt                 __loops_label_7 
   131 : annotation:ifcend                      
   132 : add                    i7, i7, 3       
   133 : annotation:endif       7               
   134 : mov                    i54, i5         
   135 : add                    i54, i54, 5     
   136 : mov                    i53, i54        
   137 : shl                    i53, i53, 3     
   138 : mov                    i52, i53        
   139 : add                    i52, i52, i2    
   140 : store.i64              i0, i52, i7     
   141 : add                    i5, i5, 1       
   142 : annotation:endwhile    3, 5            
   143 : add                    i1, i1, 1       
   144 : annotation:endwhile    0, 2            
   145 : ret                                    
