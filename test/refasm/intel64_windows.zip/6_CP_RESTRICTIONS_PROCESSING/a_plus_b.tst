a_plus_b(i0, i1)
     0 : mov i2, i1     
     1 : add i2, i2, i0 
     2 : mov iR, i2     
     3 : ret            
