min_max_scalar(i0, i1, i2, i3)
     0 : mov                    i5, 0           
     1 : mov                    i6, 0           
     2 : mov                    i8, 0           
     3 : load.i32               i10, i0         
     4 : mov                    i11, i10        
     5 : mov                    i4, i1          
     6 : mul                    i4, i4, 4       
     7 : annotation:whilecstart 0               
     8 : cmp                    i5, i4          
     9 : jmp_ge                 __loops_label_2 
    10 : annotation:whilecend                   
    11 : load.i32               i12, i0, i5     
    12 : annotation:ifcstart                    
    13 : cmp                    i12, i10        
    14 : jmp_ge                 __loops_label_4 
    15 : annotation:ifcend                      
    16 : mov                    i10, i12        
    17 : mov                    i6, i5          
    18 : annotation:endif       4               
    19 : annotation:ifcstart                    
    20 : cmp                    i12, i11        
    21 : jmp_le                 __loops_label_6 
    22 : annotation:ifcend                      
    23 : mov                    i11, i12        
    24 : mov                    i8, i5          
    25 : annotation:endif       6               
    26 : add                    i5, i5, 4       
    27 : annotation:endwhile    0, 2            
    28 : mov                    i13, 4          
    29 : mov                    i7, i6          
    30 : div                    i7, i7, i13     
    31 : mov                    i9, i8          
    32 : div                    i9, i9, i13     
    33 : store.i32              i2, i7          
    34 : store.i32              i3, i9          
    35 : mov                    iR, 0           
    36 : ret                                    
