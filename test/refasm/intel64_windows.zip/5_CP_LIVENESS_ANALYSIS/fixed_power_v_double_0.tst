fixed_power_v_double_0(i0, i1, i2)
     0 : mov                    i4, 0           
     1 : mul                    i3, i2, 8       
     2 : annotation:whilecstart 0               
     3 : cmp                    i4, i3          
     4 : jmp_ge                 __loops_label_2 
     5 : annotation:whilecend                   
     6 : vld.fp64               v0, i0, i4      
     7 : mov                    i5, 0           
     8 : vdef.fp64              v2              
     9 : setlane.fp64           v3, 0, i5       
    10 : broadcast.fp64         v1, v3, 0       
    11 : vst.fp64               i1, i4, v1      
    12 : add                    i4, i4, 32      
    13 : annotation:endwhile    0, 2            
    14 : mov                    iR, 0           
    15 : ret                                    
