a_plus_b(i0, i1)
     0 : add i2, i0, i1 
     1 : mov iR, i2     
     2 : ret            
