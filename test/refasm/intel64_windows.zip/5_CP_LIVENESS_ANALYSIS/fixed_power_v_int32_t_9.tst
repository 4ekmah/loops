fixed_power_v_int32_t_9(i0, i1, i2)
     0 : mov                    i4, 0           
     1 : mul                    i3, i2, 4       
     2 : annotation:whilecstart 0               
     3 : cmp                    i4, i3          
     4 : jmp_ge                 __loops_label_2 
     5 : annotation:whilecend                   
     6 : vld.i32                v0, i0, i4      
     7 : mul.i32                v4, v0, v0      
     8 : mul.i32                v3, v4, v4      
     9 : mul.i32                v2, v3, v3      
    10 : mul.i32                v1, v0, v2      
    11 : vst.i32                i1, i4, v1      
    12 : add                    i4, i4, 32      
    13 : annotation:endwhile    0, 2            
    14 : mov                    iR, 0           
    15 : ret                                    
