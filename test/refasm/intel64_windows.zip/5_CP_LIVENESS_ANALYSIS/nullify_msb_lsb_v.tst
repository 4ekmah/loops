nullify_msb_lsb_v(i0, i1, i2, i3)
     0 : mov                    i5, 0           
     1 : mul                    i4, i3, 4       
     2 : mov                    i6, 1           
     3 : vdef.u32               v19             
     4 : setlane.u32            v20, 0, i6      
     5 : broadcast.u32          v0, v20, 0      
     6 : annotation:whilecstart 0               
     7 : cmp                    i5, i4          
     8 : jmp_ge                 __loops_label_2 
     9 : annotation:whilecend                   
    10 : vld.u32                v1, i0, i5      
    11 : shr.u32                v10, v1, 1      
    12 : or                     v2, v1, v10     
    13 : shr.u32                v11, v2, 2      
    14 : or                     v3, v2, v11     
    15 : shr.u32                v12, v3, 4      
    16 : or                     v4, v3, v12     
    17 : shr.u32                v13, v4, 8      
    18 : or                     v5, v4, v13     
    19 : shr.u32                v14, v5, 16     
    20 : or                     v6, v5, v14     
    21 : add.u32                v7, v6, v0      
    22 : shr.u32                v8, v7, 1       
    23 : xor                    v9, v8, v1      
    24 : vst.u32                i1, i5, v9      
    25 : sub.u32                v18, v1, v0     
    26 : mov                    i7, 255         
    27 : vdef.u8                v21             
    28 : setlane.u8             v22, 0, i7      
    29 : broadcast.u8           v23, v22, 0     
    30 : xor                    v17, v18, v23   
    31 : and                    v15, v1, v17    
    32 : xor                    v16, v15, v1    
    33 : vst.u32                i2, i5, v16     
    34 : add                    i5, i5, 32      
    35 : annotation:endwhile    0, 2            
    36 : ret                                    
