ten_args_to_sum(i0, i1, i2, i3, i4, i5, i6, i7, i8, i9)
     0 : mul i10, i0, 1    
     1 : mul i20, i1, 2    
     2 : add i11, i10, i20 
     3 : mul i21, i2, 3    
     4 : add i12, i11, i21 
     5 : mul i22, i3, 4    
     6 : add i13, i12, i22 
     7 : mul i23, i4, 5    
     8 : add i14, i13, i23 
     9 : mul i24, i5, 6    
    10 : add i15, i14, i24 
    11 : mul i25, i6, 7    
    12 : add i16, i15, i25 
    13 : mul i26, i7, 8    
    14 : add i17, i16, i26 
    15 : mul i27, i8, 3    
    16 : add i18, i17, i27 
    17 : mul i28, i9, 2    
    18 : add i19, i18, i28 
    19 : mov iR, i19       
    20 : ret               
