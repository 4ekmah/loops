conditionpainter(i0)
     0 : mov                    i1, -5          
     1 : annotation:whilecstart 0               
     2 : cmp                    i1, 5           
     3 : jmp_gt                 __loops_label_2 
     4 : annotation:whilecend                   
     5 : add                    i4, i1, 5       
     6 : mul                    i3, i4, 11      
     7 : mul                    i2, i3, 8       
     8 : mov                    i5, -5          
     9 : annotation:whilecstart 3               
    10 : cmp                    i5, 5           
    11 : jmp_gt                 __loops_label_5 
    12 : annotation:whilecend                   
    13 : add                    i11, i5, 3      
    14 : mov                    i12, 0          
    15 : cmp                    i1, i11         
    16 : iverson_ge             i12             
    17 : mov                    i13, 0          
    18 : cmp                    i1, 4           
    19 : iverson_le             i13             
    20 : and                    i10, i12, i13   
    21 : mov                    i14, 0          
    22 : cmp                    i5, -2          
    23 : iverson_ge             i14             
    24 : and                    i9, i10, i14    
    25 : mov                    i15, 0          
    26 : cmp                    i5, 0           
    27 : iverson_le             i15             
    28 : and                    i8, i9, i15     
    29 : sub                    i19, i5, 1      
    30 : mov                    i20, 0          
    31 : cmp                    i1, i19         
    32 : iverson_le             i20             
    33 : mov                    i21, 0          
    34 : cmp                    i5, 0           
    35 : iverson_ge             i21             
    36 : and                    i18, i20, i21   
    37 : mov                    i22, 0          
    38 : cmp                    i1, 0           
    39 : iverson_le             i22             
    40 : and                    i17, i18, i22   
    41 : mul                    i24, i5, i5     
    42 : mul                    i25, i1, i1     
    43 : add                    i23, i24, i25   
    44 : mov                    i26, 0          
    45 : cmp                    i23, 9          
    46 : iverson_le             i26             
    47 : and                    i16, i17, i26   
    48 : or                     i6, i8, i16     
    49 : mov                    i27, 2          
    50 : mov                    i28, 0          
    51 : mov                    i32, 0          
    52 : cmp                    i5, 2           
    53 : iverson_ge             i32             
    54 : mov                    i33, 0          
    55 : cmp                    i5, 4           
    56 : iverson_le             i33             
    57 : and                    i31, i32, i33   
    58 : mov                    i35, 0          
    59 : cmp                    i1, 1           
    60 : iverson_ge             i35             
    61 : mov                    i36, 0          
    62 : cmp                    i1, 3           
    63 : iverson_le             i36             
    64 : and                    i34, i35, i36   
    65 : or                     i30, i31, i34   
    66 : mul                    i38, i5, i5     
    67 : mul                    i39, i1, i1     
    68 : add                    i37, i38, i39   
    69 : mov                    i40, 0          
    70 : cmp                    i37, 16         
    71 : iverson_le             i40             
    72 : and                    i29, i30, i40   
    73 : cmp                    i29, 0          
    74 : select_ne              i41, i27, i28   
    75 : add                    i7, i6, i41     
    76 : annotation:ifcstart                    
    77 : mul                    i42, i1, 2      
    78 : cmp                    i42, i5         
    79 : jmp_gt                 __loops_label_8 
    80 : add                    i45, i5, 3      
    81 : neg                    i44, i45        
    82 : add                    i46, i5, 3      
    83 : mul                    i43, i44, i46   
    84 : cmp                    i1, i43         
    85 : jmp_le                 __loops_label_9 
    86 : __loops_label_8:                       
    87 : mul                    i47, i5, 2      
    88 : cmp                    i1, i47         
    89 : jmp_gt                 __loops_label_7 
    90 : add                    i50, i5, 3      
    91 : neg                    i49, i50        
    92 : add                    i51, i5, 3      
    93 : mul                    i48, i49, i51   
    94 : cmp                    i1, i48         
    95 : jmp_gt                 __loops_label_7 
    96 : __loops_label_9:                       
    97 : cmp                    i5, 0           
    98 : jmp_gt                 __loops_label_7 
    99 : annotation:ifcend                      
   100 : add                    i7, i7, 3       
   101 : annotation:endif       7               
   102 : add                    i54, i5, 5      
   103 : shl                    i53, i54, 3     
   104 : add                    i52, i2, i53    
   105 : store.i64              i0, i52, i7     
   106 : add                    i5, i5, 1       
   107 : annotation:endwhile    3, 5            
   108 : add                    i1, i1, 1       
   109 : annotation:endwhile    0, 2            
   110 : ret                                    
