nonnegative_odd(i0, i1)
     0 : mov                    i3, 0           
     1 : mov                    i4, -4          
     2 : mul                    i2, i1, 4       
     3 : annotation:whilecstart 0               
     4 : cmp                    i3, i2          
     5 : jmp_ge                 __loops_label_2 
     6 : annotation:whilecend                   
     7 : load.i32               i6, i0, i3      
     8 : annotation:ifcstart                    
     9 : cmp                    i6, 0           
    10 : jmp_ge                 __loops_label_4 
    11 : annotation:ifcend                      
    12 : add                    i3, i3, 4       
    13 : annotation:break       0               
    14 : annotation:endif       4               
    15 : mov                    i8, 2           
    16 : mod                    i7, i6, i8      
    17 : annotation:ifcstart                    
    18 : cmp                    i7, 0           
    19 : jmp_eq                 __loops_label_6 
    20 : annotation:ifcend                      
    21 : mov                    i4, i3          
    22 : annotation:break       2               
    23 : annotation:endif       6               
    24 : add                    i3, i3, 4       
    25 : annotation:endwhile    0, 2            
    26 : mov                    i9, 4           
    27 : div                    i5, i4, i9      
    28 : mov                    iR, i5          
    29 : ret                                    
