fixed_power_v_int32_t_4(i0, i1, i2)
     0 : mov                    i4, 0           
     1 : mul                    i3, i2, 4       
     2 : annotation:whilecstart 0               
     3 : cmp                    i4, i3          
     4 : jmp_ge                 __loops_label_2 
     5 : annotation:whilecend                   
     6 : vld.i32                v0, i0, i4      
     7 : mul.i32                v2, v0, v0      
     8 : mul.i32                v1, v2, v2      
     9 : vst.i32                i1, i4, v1      
    10 : add                    i4, i4, 32      
    11 : annotation:endwhile    0, 2            
    12 : mov                    iR, 0           
    13 : ret                                    
