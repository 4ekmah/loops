min_max_scalar(i0, i1, i2, i3)
     0 : mov                    i5, 0           
     1 : mov                    i6, 0           
     2 : mov                    i8, 0           
     3 : load.i32               i10, i0         
     4 : mov                    i11, i10        
     5 : mul                    i4, i1, 4       
     6 : annotation:whilecstart 0               
     7 : cmp                    i5, i4          
     8 : jmp_ge                 __loops_label_2 
     9 : annotation:whilecend                   
    10 : load.i32               i12, i0, i5     
    11 : annotation:ifcstart                    
    12 : cmp                    i12, i10        
    13 : jmp_ge                 __loops_label_4 
    14 : annotation:ifcend                      
    15 : mov                    i10, i12        
    16 : mov                    i6, i5          
    17 : annotation:endif       4               
    18 : annotation:ifcstart                    
    19 : cmp                    i12, i11        
    20 : jmp_le                 __loops_label_6 
    21 : annotation:ifcend                      
    22 : mov                    i11, i12        
    23 : mov                    i8, i5          
    24 : annotation:endif       6               
    25 : add                    i5, i5, 4       
    26 : annotation:endwhile    0, 2            
    27 : mov                    i13, 4          
    28 : div                    i7, i6, i13     
    29 : div                    i9, i8, i13     
    30 : store.i32              i2, i7          
    31 : store.i32              i3, i9          
    32 : mov                    iR, 0           
    33 : ret                                    
