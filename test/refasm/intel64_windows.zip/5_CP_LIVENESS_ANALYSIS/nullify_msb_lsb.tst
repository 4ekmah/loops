nullify_msb_lsb(i0, i1, i2)
     0 : shr       i12, i0, 1   
     1 : or        i3, i0, i12  
     2 : shr       i13, i3, 2   
     3 : or        i4, i3, i13  
     4 : shr       i14, i4, 4   
     5 : or        i5, i4, i14  
     6 : shr       i15, i5, 8   
     7 : or        i6, i5, i15  
     8 : shr       i16, i6, 16  
     9 : or        i7, i6, i16  
    10 : shr       i17, i7, 32  
    11 : or        i8, i7, i17  
    12 : add       i9, i8, 1    
    13 : shr       i10, i9, 1   
    14 : xor       i11, i10, i0 
    15 : store.u64 i2, i11      
    16 : sub       i21, i0, 1   
    17 : not       i20, i21     
    18 : and       i18, i0, i20 
    19 : xor       i19, i18, i0 
    20 : store.u64 i1, i19      
    21 : ret                    
