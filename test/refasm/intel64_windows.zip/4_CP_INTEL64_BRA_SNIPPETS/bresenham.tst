bresenham(i0, i1, i2, i3, i4, i5, i6)
     0 : sub                    i8, i4, i2       
     1 : neg                    i7, i8           
     2 : select_s               i7, i8, i7       
     3 : sub                    i10, i4, i2      
     4 : mov                    i20, i10         
     5 : sar                    i9, i10, 63      
     6 : neg                    i20, i20         
     7 : x86_adc                i9, i9, i9       
     8 : sub                    i13, i5, i3      
     9 : neg                    i12, i13         
    10 : select_s               i12, i13, i12    
    11 : neg                    i11, i12         
    12 : sub                    i15, i5, i3      
    13 : mov                    i21, i15         
    14 : sar                    i14, i15, 63     
    15 : neg                    i21, i21         
    16 : x86_adc                i14, i14, i14    
    17 : add                    i16, i7, i11     
    18 : annotation:whilecstart 0                
    19 : cmp                    i0, 0            
    20 : jmp_eq                 __loops_label_2  
    21 : annotation:whilecend                    
    22 : mul                    i18, i3, i1      
    23 : add                    i17, i18, i2     
    24 : store.u8               i0, i17, i6      
    25 : annotation:ifcstart                     
    26 : cmp                    i2, i4           
    27 : jmp_ne                 __loops_label_4  
    28 : cmp                    i3, i5           
    29 : jmp_ne                 __loops_label_4  
    30 : annotation:ifcend                       
    31 : annotation:break       2                
    32 : annotation:endif       4                
    33 : shl                    i19, i16, 1      
    34 : annotation:ifcstart                     
    35 : cmp                    i19, i11         
    36 : jmp_gt                 __loops_label_6  
    37 : annotation:ifcend                       
    38 : annotation:ifcstart                     
    39 : cmp                    i2, i4           
    40 : jmp_ne                 __loops_label_8  
    41 : annotation:ifcend                       
    42 : annotation:break       2                
    43 : annotation:endif       8                
    44 : add                    i16, i16, i11    
    45 : add                    i2, i2, i9       
    46 : annotation:endif       6                
    47 : annotation:ifcstart                     
    48 : cmp                    i19, i7          
    49 : jmp_gt                 __loops_label_10 
    50 : annotation:ifcend                       
    51 : annotation:ifcstart                     
    52 : cmp                    i3, i5           
    53 : jmp_ne                 __loops_label_12 
    54 : annotation:ifcend                       
    55 : annotation:break       2                
    56 : annotation:endif       12               
    57 : add                    i16, i16, i7     
    58 : add                    i3, i3, i14      
    59 : annotation:endif       10               
    60 : annotation:endwhile    0, 2             
    61 : ret                                     
