conditionpainter(i0)
     0 : mov                    i1, -5          
     1 : annotation:whilecstart 0               
     2 : cmp                    i1, 5           
     3 : jmp_gt                 __loops_label_2 
     4 : annotation:whilecend                   
     5 : add                    i4, i1, 5       
     6 : mul                    i3, i4, 11      
     7 : mul                    i2, i3, 8       
     8 : mov                    i5, -5          
     9 : annotation:whilecstart 3               
    10 : cmp                    i5, 5           
    11 : jmp_gt                 __loops_label_5 
    12 : annotation:whilecend                   
    13 : add                    i10, i5, 3      
    14 : mov                    i11, 0          
    15 : cmp                    i1, i10         
    16 : iverson_ge             i11             
    17 : mov                    i12, 0          
    18 : cmp                    i1, 4           
    19 : iverson_le             i12             
    20 : and                    i9, i11, i12    
    21 : mov                    i13, 0          
    22 : cmp                    i5, -2          
    23 : iverson_ge             i13             
    24 : and                    i8, i9, i13     
    25 : mov                    i14, 0          
    26 : cmp                    i5, 0           
    27 : iverson_le             i14             
    28 : and                    i7, i8, i14     
    29 : sub                    i18, i5, 1      
    30 : mov                    i19, 0          
    31 : cmp                    i1, i18         
    32 : iverson_le             i19             
    33 : mov                    i20, 0          
    34 : cmp                    i5, 0           
    35 : iverson_ge             i20             
    36 : and                    i17, i19, i20   
    37 : mov                    i21, 0          
    38 : cmp                    i1, 0           
    39 : iverson_le             i21             
    40 : and                    i16, i17, i21   
    41 : mul                    i23, i5, i5     
    42 : mul                    i24, i1, i1     
    43 : add                    i22, i23, i24   
    44 : mov                    i25, 0          
    45 : cmp                    i22, 9          
    46 : iverson_le             i25             
    47 : and                    i15, i16, i25   
    48 : or                     i6, i7, i15     
    49 : mov                    i26, 2          
    50 : mov                    i27, 0          
    51 : mov                    i31, 0          
    52 : cmp                    i5, 2           
    53 : iverson_ge             i31             
    54 : mov                    i32, 0          
    55 : cmp                    i5, 4           
    56 : iverson_le             i32             
    57 : and                    i30, i31, i32   
    58 : mov                    i34, 0          
    59 : cmp                    i1, 1           
    60 : iverson_ge             i34             
    61 : mov                    i35, 0          
    62 : cmp                    i1, 3           
    63 : iverson_le             i35             
    64 : and                    i33, i34, i35   
    65 : or                     i29, i30, i33   
    66 : mul                    i37, i5, i5     
    67 : mul                    i38, i1, i1     
    68 : add                    i36, i37, i38   
    69 : mov                    i39, 0          
    70 : cmp                    i36, 16         
    71 : iverson_le             i39             
    72 : and                    i28, i29, i39   
    73 : cmp                    i28, 0          
    74 : select_ne              i40, i26, i27   
    75 : add                    i6, i6, i40     
    76 : annotation:ifcstart                    
    77 : mul                    i41, i1, 2      
    78 : cmp                    i41, i5         
    79 : jmp_gt                 __loops_label_8 
    80 : add                    i44, i5, 3      
    81 : neg                    i43, i44        
    82 : add                    i45, i5, 3      
    83 : mul                    i42, i43, i45   
    84 : cmp                    i1, i42         
    85 : jmp_le                 __loops_label_9 
    86 : __loops_label_8:                       
    87 : mul                    i46, i5, 2      
    88 : cmp                    i1, i46         
    89 : jmp_gt                 __loops_label_7 
    90 : add                    i49, i5, 3      
    91 : neg                    i48, i49        
    92 : add                    i50, i5, 3      
    93 : mul                    i47, i48, i50   
    94 : cmp                    i1, i47         
    95 : jmp_gt                 __loops_label_7 
    96 : __loops_label_9:                       
    97 : cmp                    i5, 0           
    98 : jmp_gt                 __loops_label_7 
    99 : annotation:ifcend                      
   100 : add                    i6, i6, 3       
   101 : annotation:endif       7               
   102 : add                    i53, i5, 5      
   103 : shl                    i52, i53, 3     
   104 : add                    i51, i2, i52    
   105 : store.i64              i0, i51, i6     
   106 : add                    i5, i5, 1       
   107 : annotation:endwhile    3, 5            
   108 : add                    i1, i1, 1       
   109 : annotation:endwhile    0, 2            
   110 : ret                                    
