all_loads_all_stores(i0, i1, i2, i3, i4)
     0 : sub               i4, i4, 56       
     1 : spill             3, i9            
     2 : spill             5, i13           
     3 : mov               s0, 0            
     4 : mov               s1, 0            
     5 : mov               s2, 0            
     6 : mov               i0, 2            
     7 : mov               i9, 1            
     8 : cmp               i2, 1            
     9 : select_gt         i9, i0, i9       
    10 : mov               i0, 4            
    11 : cmp               i2, 3            
    12 : select_gt         i9, i0, i9       
    13 : mov               i0, 8            
    14 : cmp               i2, 5            
    15 : select_gt         i13, i0, i9      
    16 : spill             4, i13           
    17 : mov               i0, 2            
    18 : mov               i9, 1            
    19 : cmp               s3, 1            
    20 : select_gt         i9, i0, i9       
    21 : mov               i0, 4            
    22 : cmp               s3, 3            
    23 : select_gt         i9, i0, i9       
    24 : mov               i0, 8            
    25 : cmp               s3, 5            
    26 : select_gt         i9, i0, i9       
    27 : __loops_label_0:                   
    28 : unspill           i13, 12          
    29 : cmp               s0, i13          
    30 : jmp_ge            __loops_label_2  
    31 : def               i0               
    32 : cmp               i2, 0            
    33 : jmp_ne            __loops_label_4  
    34 : unspill           i13, 1           
    35 : load.u8           i0, i1, i13      
    36 : jmp               5                
    37 : __loops_label_4:                   
    38 : cmp               i2, 1            
    39 : jmp_ne            __loops_label_7  
    40 : unspill           i13, 1           
    41 : load.i8           i0, i1, i13      
    42 : jmp               8                
    43 : __loops_label_7:                   
    44 : cmp               i2, 2            
    45 : jmp_ne            __loops_label_10 
    46 : unspill           i13, 1           
    47 : load.u16          i0, i1, i13      
    48 : jmp               11               
    49 : __loops_label_10:                  
    50 : cmp               i2, 3            
    51 : jmp_ne            __loops_label_13 
    52 : unspill           i13, 1           
    53 : load.i16          i0, i1, i13      
    54 : jmp               14               
    55 : __loops_label_13:                  
    56 : cmp               i2, 4            
    57 : jmp_ne            __loops_label_16 
    58 : unspill           i13, 1           
    59 : load.u32          i0, i1, i13      
    60 : jmp               17               
    61 : __loops_label_16:                  
    62 : cmp               i2, 5            
    63 : jmp_ne            __loops_label_19 
    64 : unspill           i13, 1           
    65 : load.i32          i0, i1, i13      
    66 : jmp               20               
    67 : __loops_label_19:                  
    68 : cmp               i2, 6            
    69 : jmp_ne            __loops_label_22 
    70 : unspill           i13, 1           
    71 : load.u64          i0, i1, i13      
    72 : jmp               23               
    73 : __loops_label_22:                  
    74 : unspill           i13, 1           
    75 : load.i64          i0, i1, i13      
    76 : __loops_label_5:                   
    77 : __loops_label_8:                   
    78 : __loops_label_11:                  
    79 : __loops_label_14:                  
    80 : __loops_label_17:                  
    81 : __loops_label_20:                  
    82 : __loops_label_23:                  
    83 : cmp               s3, 0            
    84 : jmp_ne            __loops_label_25 
    85 : unspill           i13, 2           
    86 : store.u8          i8, i13, i0      
    87 : jmp               26               
    88 : __loops_label_25:                  
    89 : cmp               s3, 1            
    90 : jmp_ne            __loops_label_28 
    91 : unspill           i13, 2           
    92 : store.i8          i8, i13, i0      
    93 : jmp               29               
    94 : __loops_label_28:                  
    95 : cmp               s3, 2            
    96 : jmp_ne            __loops_label_31 
    97 : unspill           i13, 2           
    98 : store.u16         i8, i13, i0      
    99 : jmp               32               
   100 : __loops_label_31:                  
   101 : cmp               s3, 3            
   102 : jmp_ne            __loops_label_34 
   103 : unspill           i13, 2           
   104 : store.i16         i8, i13, i0      
   105 : jmp               35               
   106 : __loops_label_34:                  
   107 : cmp               s3, 4            
   108 : jmp_ne            __loops_label_37 
   109 : unspill           i13, 2           
   110 : store.u32         i8, i13, i0      
   111 : jmp               38               
   112 : __loops_label_37:                  
   113 : cmp               s3, 5            
   114 : jmp_ne            __loops_label_40 
   115 : unspill           i13, 2           
   116 : store.i32         i8, i13, i0      
   117 : jmp               41               
   118 : __loops_label_40:                  
   119 : cmp               s3, 6            
   120 : jmp_ne            __loops_label_43 
   121 : unspill           i13, 2           
   122 : store.u64         i8, i13, i0      
   123 : jmp               44               
   124 : __loops_label_43:                  
   125 : unspill           i13, 2           
   126 : store.i64         i8, i13, i0      
   127 : __loops_label_26:                  
   128 : __loops_label_29:                  
   129 : __loops_label_32:                  
   130 : __loops_label_35:                  
   131 : __loops_label_38:                  
   132 : __loops_label_41:                  
   133 : __loops_label_44:                  
   134 : unspill           i13, 4           
   135 : add               s1, s1, i13      
   136 : add               s2, s2, i9       
   137 : add               s0, s0, 1        
   138 : jmp               0                
   139 : __loops_label_2:                   
   140 : unspill           i13, 5           
   141 : add               i4, i4, 56       
   142 : ret                                
