triangle_types(i0, i1, i2)
     0 : sub               i4, i4, 24       
     1 : spill             1, i13           
     2 : spill             0, i2            
     3 : cmp               i1, 0            
     4 : jmp_le            __loops_label_0  
     5 : cmp               s0, 0            
     6 : jmp_le            __loops_label_0  
     7 : cmp               i8, 0            
     8 : jmp_gt            __loops_label_1  
     9 : __loops_label_0:                   
    10 : mov               i0, 0            
    11 : jmp               18               
    12 : __loops_label_1:                   
    13 : unspill           i13, 0           
    14 : add               i9, i13, i8      
    15 : cmp               i1, i9           
    16 : jmp_gt            __loops_label_3  
    17 : add               i9, i1, i8       
    18 : cmp               s0, i9           
    19 : jmp_gt            __loops_label_3  
    20 : add               i9, i1, s0       
    21 : cmp               i8, i9           
    22 : jmp_le            __loops_label_4  
    23 : __loops_label_3:                   
    24 : mov               i0, 0            
    25 : jmp               18               
    26 : __loops_label_4:                   
    27 : cmp               i1, s0           
    28 : jmp_ne            __loops_label_7  
    29 : cmp               i1, i8           
    30 : jmp_ne            __loops_label_7  
    31 : mov               i0, 2            
    32 : jmp               18               
    33 : __loops_label_7:                   
    34 : cmp               i1, s0           
    35 : jmp_eq            __loops_label_9  
    36 : cmp               i1, i8           
    37 : jmp_eq            __loops_label_9  
    38 : cmp               s0, i8           
    39 : jmp_ne            __loops_label_10 
    40 : __loops_label_9:                   
    41 : mov               i0, 3            
    42 : jmp               18               
    43 : __loops_label_10:                  
    44 : mul               i9, i1, i1       
    45 : unspill           i13, 0           
    46 : mul               i0, i13, s0      
    47 : mul               i2, i8, i8       
    48 : add               i0, i0, i2       
    49 : cmp               i9, i0           
    50 : jmp_eq            __loops_label_12 
    51 : unspill           i13, 0           
    52 : mul               i2, i13, s0      
    53 : mul               i9, i1, i1       
    54 : mul               i0, i8, i8       
    55 : add               i9, i9, i0       
    56 : cmp               i2, i9           
    57 : jmp_eq            __loops_label_12 
    58 : mul               i2, i8, i8       
    59 : mul               i9, i1, i1       
    60 : unspill           i13, 0           
    61 : mul               i0, i13, s0      
    62 : add               i9, i9, i0       
    63 : cmp               i2, i9           
    64 : jmp_ne            __loops_label_13 
    65 : __loops_label_12:                  
    66 : mov               i0, 1            
    67 : jmp               18               
    68 : __loops_label_13:                  
    69 : mul               i2, i1, i1       
    70 : unspill           i13, 0           
    71 : mul               i9, i13, s0      
    72 : mul               i0, i8, i8       
    73 : add               i9, i9, i0       
    74 : cmp               i2, i9           
    75 : jmp_gt            __loops_label_15 
    76 : unspill           i13, 0           
    77 : mul               i2, i13, s0      
    78 : mul               i9, i1, i1       
    79 : mul               i0, i8, i8       
    80 : add               i9, i9, i0       
    81 : cmp               i2, i9           
    82 : jmp_gt            __loops_label_15 
    83 : mul               i8, i8, i8       
    84 : mul               i1, i1, i1       
    85 : unspill           i13, 0           
    86 : mul               i2, i13, s0      
    87 : add               i1, i1, i2       
    88 : cmp               i8, i1           
    89 : jmp_le            __loops_label_16 
    90 : __loops_label_15:                  
    91 : mov               i0, 5            
    92 : jmp               18               
    93 : __loops_label_16:                  
    94 : mov               i0, 4            
    95 : jmp               18               
    96 : __loops_label_2:                   
    97 : __loops_label_5:                   
    98 : __loops_label_8:                   
    99 : __loops_label_11:                  
   100 : __loops_label_14:                  
   101 : __loops_label_17:                  
   102 : __loops_label_18:                  
   103 : unspill           i13, 1           
   104 : add               i4, i4, 24       
   105 : ret                                
