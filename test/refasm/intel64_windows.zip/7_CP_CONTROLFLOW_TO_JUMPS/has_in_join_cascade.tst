has_in_join_cascade(i0, i1, i2)
     0 : sub               i4, i4, 120      
     1 : spill             13, i13          
     2 : spill             14, i14          
     3 : spill             6, i1            
     4 : spill             5, i2            
     5 : spill             4, i8            
     6 : mov               s0, 0            
     7 : unspill           i13, 6           
     8 : load.i64          i14, i13, 16     
     9 : spill             3, i14           
    10 : unspill           i13, 6           
    11 : load.i64          i14, i13, 0      
    12 : spill             2, i14           
    13 : unspill           i13, 6           
    14 : load.i64          i14, i13, 8      
    15 : spill             1, i14           
    16 : __loops_label_0:                   
    17 : cmp               s3, 0            
    18 : jmp_le            __loops_label_2  
    19 : unspill           i13, 2           
    20 : load.i32          i14, i13         
    21 : spill             11, i14          
    22 : add               s2, s2, 4        
    23 : unspill           i13, 1           
    24 : load.i32          i14, i13         
    25 : spill             10, i14          
    26 : add               s1, s1, 4        
    27 : sub               s3, s3, 1        
    28 : unspill           i13, 6           
    29 : load.i64          i14, i13, 40     
    30 : spill             9, i14           
    31 : unspill           i13, 6           
    32 : load.i64          i14, i13, 24     
    33 : spill             8, i14           
    34 : unspill           i13, 6           
    35 : load.i64          i14, i13, 32     
    36 : spill             7, i14           
    37 : __loops_label_3:                   
    38 : cmp               s9, 0            
    39 : jmp_le            __loops_label_5  
    40 : unspill           i13, 8           
    41 : load.i32          i1, i13          
    42 : add               s8, s8, 4        
    43 : unspill           i13, 7           
    44 : load.i32          i2, i13          
    45 : add               s7, s7, 4        
    46 : sub               s9, s9, 1        
    47 : cmp               i2, s11          
    48 : jmp_le            __loops_label_7  
    49 : jmp               3                
    50 : __loops_label_7:                   
    51 : cmp               i2, s11          
    52 : jmp_ne            __loops_label_10 
    53 : unspill           i13, 6           
    54 : load.i64          i2, i13, 64      
    55 : unspill           i13, 6           
    56 : load.i64          i8, i13, 48      
    57 : unspill           i13, 6           
    58 : load.i64          i14, i13, 56     
    59 : spill             12, i14          
    60 : __loops_label_11:                  
    61 : cmp               i2, 0            
    62 : jmp_le            __loops_label_13 
    63 : load.i32          i9, i8           
    64 : add               i8, i8, 4        
    65 : unspill           i13, 12          
    66 : load.i32          i0, i13          
    67 : add               s12, s12, 4      
    68 : sub               i2, i2, 1        
    69 : cmp               i9, s10          
    70 : jmp_le            __loops_label_15 
    71 : jmp               11               
    72 : __loops_label_15:                  
    73 : cmp               i9, s10          
    74 : jmp_ne            __loops_label_18 
    75 : cmp               i1, s5           
    76 : jmp_ne            __loops_label_18 
    77 : cmp               i0, s4           
    78 : jmp_ne            __loops_label_18 
    79 : mov               s0, 1            
    80 : jmp               2                
    81 : __loops_label_16:                  
    82 : __loops_label_18:                  
    83 : jmp               11               
    84 : __loops_label_13:                  
    85 : __loops_label_8:                   
    86 : __loops_label_10:                  
    87 : jmp               3                
    88 : __loops_label_5:                   
    89 : jmp               0                
    90 : __loops_label_2:                   
    91 : mov               i0, s0           
    92 : unspill           i13, 13          
    93 : unspill           i14, 14          
    94 : add               i4, i4, 120      
    95 : ret                                
