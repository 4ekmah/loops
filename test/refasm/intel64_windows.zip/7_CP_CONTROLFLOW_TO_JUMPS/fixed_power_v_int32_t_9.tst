fixed_power_v_int32_t_9(i0, i1, i2)
     0 : mov              i9, 0           
     1 : mul              i8, i8, 4       
     2 : __loops_label_0:                 
     3 : cmp              i9, i8          
     4 : jmp_ge           __loops_label_2 
     5 : vld.i32          v0, i1, i9      
     6 : mul.i32          v1, v0, v0      
     7 : mul.i32          v1, v1, v1      
     8 : mul.i32          v1, v1, v1      
     9 : mul.i32          v0, v0, v1      
    10 : vst.i32          i2, i9, v0      
    11 : add              i9, i9, 32      
    12 : jmp              0               
    13 : __loops_label_2:                 
    14 : mov              i0, 0           
    15 : ret                              
