conditionpainter(i0)
     0 : sub              i4, i4, 56      
     1 : spill            1, i1           
     2 : spill            5, i13          
     3 : mov              i13, -5         
     4 : spill            0, i13          
     5 : __loops_label_0:                 
     6 : cmp              s0, 5           
     7 : jmp_gt           __loops_label_2 
     8 : unspill          i13, 0          
     9 : add              i8, i13, 5      
    10 : mul              i8, i8, 11      
    11 : mul              i13, i8, 8      
    12 : spill            3, i13          
    13 : mov              i13, -5         
    14 : spill            2, i13          
    15 : __loops_label_3:                 
    16 : cmp              s2, 5           
    17 : jmp_gt           __loops_label_5 
    18 : unspill          i13, 2          
    19 : add              i0, i13, 3      
    20 : mov              i2, 0           
    21 : cmp              s0, i0          
    22 : iverson_ge       i2              
    23 : mov              i0, 0           
    24 : cmp              s0, 4           
    25 : iverson_le       i0              
    26 : and              i2, i2, i0      
    27 : mov              i0, 0           
    28 : cmp              s2, -2          
    29 : iverson_ge       i0              
    30 : and              i2, i2, i0      
    31 : mov              i0, 0           
    32 : cmp              s2, 0           
    33 : iverson_le       i0              
    34 : and              i2, i2, i0      
    35 : unspill          i13, 2          
    36 : sub              i0, i13, 1      
    37 : mov              i1, 0           
    38 : cmp              s0, i0          
    39 : iverson_le       i1              
    40 : mov              i0, 0           
    41 : cmp              s2, 0           
    42 : iverson_ge       i0              
    43 : and              i1, i1, i0      
    44 : mov              i0, 0           
    45 : cmp              s0, 0           
    46 : iverson_le       i0              
    47 : and              i1, i1, i0      
    48 : unspill          i13, 2          
    49 : mul              i0, i13, s2     
    50 : unspill          i13, 0          
    51 : mul              i9, i13, s0     
    52 : add              i0, i0, i9      
    53 : mov              i9, 0           
    54 : cmp              i0, 9           
    55 : iverson_le       i9              
    56 : and              i1, i1, i9      
    57 : or               s4, i2, i1      
    58 : mov              i1, 2           
    59 : mov              i9, 0           
    60 : mov              i0, 0           
    61 : cmp              s2, 2           
    62 : iverson_ge       i0              
    63 : mov              i8, 0           
    64 : cmp              s2, 4           
    65 : iverson_le       i8              
    66 : and              i0, i0, i8      
    67 : mov              i8, 0           
    68 : cmp              s0, 1           
    69 : iverson_ge       i8              
    70 : mov              i2, 0           
    71 : cmp              s0, 3           
    72 : iverson_le       i2              
    73 : and              i8, i8, i2      
    74 : or               i0, i0, i8      
    75 : unspill          i13, 2          
    76 : mul              i2, i13, s2     
    77 : unspill          i13, 0          
    78 : mul              i8, i13, s0     
    79 : add              i2, i2, i8      
    80 : mov              i8, 0           
    81 : cmp              i2, 16          
    82 : iverson_le       i8              
    83 : and              i0, i0, i8      
    84 : cmp              i0, 0           
    85 : select_ne        i9, i1, i9      
    86 : unspill          i13, 4          
    87 : add              i9, i13, i9     
    88 : unspill          i13, 0          
    89 : mul              i1, i13, 2      
    90 : cmp              i1, s2          
    91 : jmp_gt           __loops_label_8 
    92 : unspill          i13, 2          
    93 : add              i1, i13, 3      
    94 : neg              i1, i1          
    95 : unspill          i13, 2          
    96 : add              i2, i13, 3      
    97 : mul              i1, i1, i2      
    98 : cmp              s0, i1          
    99 : jmp_le           __loops_label_9 
   100 : __loops_label_8:                 
   101 : unspill          i13, 2          
   102 : mul              i1, i13, 2      
   103 : cmp              s0, i1          
   104 : jmp_gt           __loops_label_7 
   105 : unspill          i13, 2          
   106 : add              i1, i13, 3      
   107 : neg              i1, i1          
   108 : unspill          i13, 2          
   109 : add              i2, i13, 3      
   110 : mul              i1, i1, i2      
   111 : cmp              s0, i1          
   112 : jmp_gt           __loops_label_7 
   113 : __loops_label_9:                 
   114 : cmp              s2, 0           
   115 : jmp_gt           __loops_label_7 
   116 : add              i9, i9, 3       
   117 : __loops_label_7:                 
   118 : unspill          i13, 2          
   119 : add              i1, i13, 5      
   120 : shl              i1, i1, 3       
   121 : unspill          i13, 3          
   122 : add              i1, i13, i1     
   123 : unspill          i13, 1          
   124 : store.i64        i13, i1, i9     
   125 : add              s2, s2, 1       
   126 : jmp              3               
   127 : __loops_label_5:                 
   128 : add              s0, s0, 1       
   129 : jmp              0               
   130 : __loops_label_2:                 
   131 : unspill          i13, 5          
   132 : add              i4, i4, 56      
   133 : ret                              
