snake(i0, i1, i2)
     0 : sub              i4, i4, 664     
     1 : spill            79, i1          
     2 : spill            78, i2          
     3 : spill            77, i8          
     4 : spill            80, i13         
     5 : spill            81, i14         
     6 : spill            82, i5          
     7 : mov              i5, i4          
     8 : add              i5, i5, 656     
     9 : unspill          i13, 78         
    10 : add              i9, i13, s77    
    11 : sub              s76, i9, 1      
    12 : mov              s75, 0          
    13 : mov              s72, 1          
    14 : neg              i13, s72        
    15 : spill            73, i13         
    16 : mov              s74, 0          
    17 : __loops_label_0:                 
    18 : unspill          i13, 76         
    19 : cmp              s74, i13        
    20 : jmp_ge           __loops_label_2 
    21 : mov              i0, 0           
    22 : mov              i9, 0           
    23 : unspill          i13, 74         
    24 : and              i8, i13, 1      
    25 : cmp              i8, 0           
    26 : jmp_eq           __loops_label_4 
    27 : unspill          i13, 77         
    28 : sub              i8, i13, 1      
    29 : unspill          i13, 74         
    30 : min              i0, i8, i13     
    31 : unspill          i13, 74         
    32 : sub              i2, i13, i8     
    33 : mov              i1, 0           
    34 : cmp              s74, i8         
    35 : select_gt        i9, i2, i1      
    36 : jmp              5               
    37 : __loops_label_4:                 
    38 : unspill          i13, 78         
    39 : sub              i1, i13, 1      
    40 : unspill          i13, 74         
    41 : sub              i2, i13, i1     
    42 : mov              i8, 0           
    43 : cmp              s74, i1         
    44 : select_gt        i0, i2, i8      
    45 : unspill          i13, 74         
    46 : min              i9, i1, i13     
    47 : __loops_label_5:                 
    48 : __loops_label_6:                 
    49 : cmp              i0, 0           
    50 : jmp_gt           __loops_label_8 
    51 : cmp              i0, s77         
    52 : jmp_ge           __loops_label_8 
    53 : cmp              i9, 0           
    54 : jmp_gt           __loops_label_8 
    55 : cmp              i9, s78         
    56 : jmp_ge           __loops_label_8 
    57 : mov              i1, -1637082256 
    58 : call_noret       [i1](i0, i9)    
    59 : mul              i1, i9, s77     
    60 : add              i1, i1, i0      
    61 : unspill          i13, 79         
    62 : unspill          i14, 75         
    63 : store.u8         i13, i1, i14    
    64 : add              s75, s75, 1     
    65 : add              i0, i0, s72     
    66 : add              i9, i9, s73     
    67 : jmp              6               
    68 : __loops_label_8:                 
    69 : neg              s72, s72        
    70 : neg              s73, s73        
    71 : add              s74, s74, 1     
    72 : jmp              0               
    73 : __loops_label_2:                 
    74 : unspill          i5, 82          
    75 : unspill          i13, 80         
    76 : unspill          i14, 81         
    77 : add              i4, i4, 664     
    78 : ret                              
