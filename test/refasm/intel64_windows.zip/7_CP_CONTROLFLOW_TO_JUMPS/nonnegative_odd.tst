nonnegative_odd(i0, i1)
     0 : sub              i4, i4, 56      
     1 : spill            5, i13          
     2 : mov              i8, 0           
     3 : mov              i13, -4         
     4 : spill            4, i13          
     5 : mul              i2, i2, 4       
     6 : __loops_label_0:                 
     7 : cmp              i8, i2          
     8 : jmp_ge           __loops_label_2 
     9 : load.i32         i0, i1, i8      
    10 : cmp              i0, 0           
    11 : jmp_ge           __loops_label_4 
    12 : add              i8, i8, 4       
    13 : jmp              0               
    14 : __loops_label_4:                 
    15 : mov              i9, 2           
    16 : mod              i9, i0, i9      
    17 : cmp              i9, 0           
    18 : jmp_eq           __loops_label_6 
    19 : mov              s4, i8          
    20 : jmp              2               
    21 : __loops_label_6:                 
    22 : add              i8, i8, 4       
    23 : jmp              0               
    24 : __loops_label_2:                 
    25 : mov              i1, 4           
    26 : unspill          i13, 4          
    27 : div              i1, i13, i1     
    28 : mov              i0, i1          
    29 : unspill          i13, 5          
    30 : add              i4, i4, 56      
    31 : ret                              
