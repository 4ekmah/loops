area_sum(i0, i1)
     0 : sub              i4, i4, 616       
     1 : spill            74, i1            
     2 : spill            73, i2            
     3 : spill            75, i13           
     4 : spill            76, i5            
     5 : mov              i5, i4            
     6 : add              i5, i5, 608       
     7 : mov              s72, 0            
     8 : __loops_label_0:                   
     9 : cmp              s73, 0            
    10 : jmp_le           __loops_label_2   
    11 : unspill          i13, 74           
    12 : load.i8          i9, i13           
    13 : mov              i0, -1637068304   
    14 : mov              i8, -1637068000   
    15 : mov              i2, -1637067776   
    16 : cmp              i9, 1             
    17 : select_eq        i2, i8, i2        
    18 : cmp              i9, 0             
    19 : select_eq        i2, i0, i2        
    20 : mov              i8, -1637068624   
    21 : mov              i0, -1637068512   
    22 : mov              i1, -1637068448   
    23 : cmp              i9, 1             
    24 : select_eq        i1, i0, i1        
    25 : cmp              i9, 0             
    26 : select_eq        i1, i8, i1        
    27 : unspill          i13, 74           
    28 : call_noret       [i2](i13)         
    29 : unspill          i13, 74           
    30 : call             [i1](i1, i13)     
    31 : mov              i2, -1637068704   
    32 : unspill          i13, 72           
    33 : call             [i2](i1, i13, i1) 
    34 : mov              s72, i1           
    35 : add              s74, s74, 56      
    36 : sub              s73, s73, 1       
    37 : jmp              0                 
    38 : __loops_label_2:                   
    39 : mov              i0, s72           
    40 : unspill          i5, 76            
    41 : unspill          i13, 75           
    42 : add              i4, i4, 616       
    43 : ret                                
