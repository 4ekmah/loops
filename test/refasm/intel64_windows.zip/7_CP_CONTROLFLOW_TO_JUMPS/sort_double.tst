sort_double(i0, i1)
     0 : sub              i4, i4, 632      
     1 : spill            75, i1           
     2 : spill            76, i13          
     3 : spill            77, i14          
     4 : spill            78, i5           
     5 : mov              i5, i4           
     6 : add              i5, i5, 624      
     7 : shl              s74, i2, 3       
     8 : unspill          i13, 74          
     9 : sub              s73, i13, 8      
    10 : mov              s72, 0           
    11 : __loops_label_0:                  
    12 : unspill          i13, 73          
    13 : cmp              s72, i13         
    14 : jmp_ge           __loops_label_2  
    15 : mov              i0, s72          
    16 : add              i9, i0, 8        
    17 : __loops_label_3:                  
    18 : cmp              i9, s74          
    19 : jmp_ge           __loops_label_5  
    20 : unspill          i13, 75          
    21 : load.fp64        i8, i13, i9      
    22 : unspill          i13, 75          
    23 : load.fp64        i2, i13, i0      
    24 : mov              i1, -1637073984  
    25 : call             [i1](i1, i8, i2) 
    26 : cmp              i1, 0            
    27 : jmp_eq           __loops_label_7  
    28 : mov              i0, i9           
    29 : __loops_label_7:                  
    30 : add              i9, i9, 8        
    31 : jmp              3                
    32 : __loops_label_5:                  
    33 : cmp              i0, s72          
    34 : jmp_eq           __loops_label_9  
    35 : unspill          i13, 75          
    36 : unspill          i14, 72          
    37 : load.fp64        i1, i13, i14     
    38 : unspill          i13, 75          
    39 : load.fp64        i2, i13, i0      
    40 : unspill          i13, 75          
    41 : store.fp64       i13, i0, i1      
    42 : unspill          i13, 75          
    43 : unspill          i14, 72          
    44 : store.fp64       i13, i14, i2     
    45 : __loops_label_9:                  
    46 : add              s72, s72, 8      
    47 : jmp              0                
    48 : __loops_label_2:                  
    49 : unspill          i5, 78           
    50 : unspill          i13, 76          
    51 : unspill          i14, 77          
    52 : add              i4, i4, 632      
    53 : ret                               
