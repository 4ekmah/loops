helloworld_call()
     0 : sub        i4, i4, 584   
     1 : spill      72, i5        
     2 : mov        i5, i4        
     3 : add        i5, i5, 576   
     4 : mov        i1, 778246128 
     5 : call_noret [i1]()        
     6 : unspill    i5, 72        
     7 : add        i4, i4, 584   
     8 : ret                      
