fixed_power_v_double_0(i0, i1, i2)
     0 : mov              i9, 0           
     1 : mul              i8, i8, 8       
     2 : __loops_label_0:                 
     3 : cmp              i9, i8          
     4 : jmp_ge           __loops_label_2 
     5 : vld.fp64         v0, i1, i9      
     6 : mov              i0, 0           
     7 : vdef.fp64        v0              
     8 : setlane.fp64     v0, 0, i0       
     9 : broadcast.fp64   v0, v0, 0       
    10 : vst.fp64         i2, i9, v0      
    11 : add              i9, i9, 32      
    12 : jmp              0               
    13 : __loops_label_2:                 
    14 : mov              i0, 0           
    15 : ret                              
