ten_args_to_sum(i0, i1, i2, i3, i4, i5, i6, i7, i8, i9)
     0 : sub     i4, i4, 8  
     1 : spill   0, i13     
     2 : unspill i0, 6      
     3 : mul     i1, i1, 1  
     4 : mul     i2, i2, 2  
     5 : add     i1, i1, i2 
     6 : mul     i8, i8, 3  
     7 : add     i1, i1, i8 
     8 : mul     i9, i9, 4  
     9 : add     i1, i1, i9 
    10 : mul     i0, i0, 5  
    11 : add     i1, i1, i0 
    12 : unspill i13, 7     
    13 : mul     i2, i13, 6 
    14 : add     i1, i1, i2 
    15 : unspill i13, 8     
    16 : mul     i2, i13, 7 
    17 : add     i1, i1, i2 
    18 : unspill i13, 9     
    19 : mul     i2, i13, 8 
    20 : add     i1, i1, i2 
    21 : unspill i13, 10    
    22 : mul     i2, i13, 3 
    23 : add     i1, i1, i2 
    24 : unspill i13, 11    
    25 : mul     i2, i13, 2 
    26 : add     i1, i1, i2 
    27 : mov     i0, i1     
    28 : unspill i13, 0     
    29 : add     i4, i4, 8  
    30 : ret                
