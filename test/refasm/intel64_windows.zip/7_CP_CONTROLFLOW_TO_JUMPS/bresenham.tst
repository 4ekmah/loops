bresenham(i0, i1, i2, i3, i4, i5, i6)
     0 : sub               i4, i4, 88       
     1 : spill             9, i13           
     2 : spill             10, i14          
     3 : unspill           i13, 16          
     4 : sub               i0, i13, i8      
     5 : abs               i13, i0          
     6 : spill             4, i13           
     7 : unspill           i13, 16          
     8 : sub               i0, i13, i8      
     9 : sign              i13, i0          
    10 : spill             5, i13           
    11 : unspill           i13, 17          
    12 : sub               i0, i13, i9      
    13 : abs               i0, i0           
    14 : neg               s6, i0           
    15 : unspill           i13, 17          
    16 : sub               i0, i13, i9      
    17 : sign              i13, i0          
    18 : spill             8, i13           
    19 : unspill           i13, 4           
    20 : unspill           i14, 6           
    21 : add               s7, i13, i14     
    22 : __loops_label_0:                   
    23 : cmp               i1, 0            
    24 : jmp_eq            __loops_label_2  
    25 : mul               i0, i9, i2       
    26 : add               i0, i0, i8       
    27 : unspill           i13, 18          
    28 : store.u8          i1, i0, i13      
    29 : cmp               i8, s16          
    30 : jmp_ne            __loops_label_4  
    31 : cmp               i9, s17          
    32 : jmp_ne            __loops_label_4  
    33 : jmp               2                
    34 : __loops_label_4:                   
    35 : unspill           i13, 7           
    36 : shl               i0, i13, 1       
    37 : cmp               i0, s6           
    38 : jmp_gt            __loops_label_6  
    39 : cmp               i8, s16          
    40 : jmp_ne            __loops_label_8  
    41 : jmp               2                
    42 : __loops_label_8:                   
    43 : unspill           i13, 6           
    44 : add               s7, s7, i13      
    45 : add               i8, i8, s5       
    46 : __loops_label_6:                   
    47 : cmp               i0, s4           
    48 : jmp_gt            __loops_label_10 
    49 : cmp               i9, s17          
    50 : jmp_ne            __loops_label_12 
    51 : jmp               2                
    52 : __loops_label_12:                  
    53 : unspill           i13, 4           
    54 : add               s7, s7, i13      
    55 : add               i9, i9, s8       
    56 : __loops_label_10:                  
    57 : jmp               0                
    58 : __loops_label_2:                   
    59 : unspill           i13, 9           
    60 : unspill           i14, 10          
    61 : add               i4, i4, 88       
    62 : ret                                
