min_max_select(i0, i1, i2, i3)
     0 : sub              i4, i4, 56      
     1 : spill            1, i8           
     2 : spill            0, i9           
     3 : spill            5, i13          
     4 : mov              i0, 0           
     5 : mov              s3, 0           
     6 : mov              s2, 0           
     7 : load.i32         i8, i1          
     8 : mov              i9, i8          
     9 : shl              s4, i2, 2       
    10 : __loops_label_0:                 
    11 : cmp              i0, s4          
    12 : jmp_ge           __loops_label_2 
    13 : load.i32         i2, i1, i0      
    14 : cmp              i2, i8          
    15 : unspill          i13, 3          
    16 : select_gt        i13, i0, i13    
    17 : spill            3, i13          
    18 : min              i8, i2, i8      
    19 : cmp              i2, i9          
    20 : unspill          i13, 2          
    21 : select_gt        i13, i0, i13    
    22 : spill            2, i13          
    23 : max              i9, i2, i9      
    24 : add              i0, i0, 4       
    25 : jmp              0               
    26 : __loops_label_2:                 
    27 : unspill          i13, 3          
    28 : sar              i1, i13, 2      
    29 : unspill          i13, 2          
    30 : sar              i2, i13, 2      
    31 : unspill          i13, 1          
    32 : store.i32        i13, i1         
    33 : unspill          i13, 0          
    34 : store.i32        i13, i2         
    35 : mov              i0, 0           
    36 : unspill          i13, 5          
    37 : add              i4, i4, 56      
    38 : ret                              
