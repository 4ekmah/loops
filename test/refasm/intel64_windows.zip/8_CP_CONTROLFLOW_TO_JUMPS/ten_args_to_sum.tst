ten_args_to_sum(i0, i1, i2, i3, i4, i5, i6, i7, i8, i9)
     0 : sub     i4, i4, 40 
     1 : unspill i0, 10     
     2 : mov     i1, i1     
     3 : mul     i1, i1, 1  
     4 : mov     i2, i2     
     5 : mul     i2, i2, 2  
     6 : mov     i2, i2     
     7 : add     i2, i2, i1 
     8 : mov     i8, i8     
     9 : mul     i8, i8, 3  
    10 : mov     i8, i8     
    11 : add     i8, i8, i2 
    12 : mov     i9, i9     
    13 : mul     i9, i9, 4  
    14 : mov     i9, i9     
    15 : add     i9, i9, i8 
    16 : mov     i0, i0     
    17 : mul     i0, i0, 5  
    18 : mov     i0, i0     
    19 : add     i0, i0, i9 
    20 : mov     i1, s11    
    21 : mul     i1, i1, 6  
    22 : mov     i1, i1     
    23 : add     i1, i1, i0 
    24 : mov     i2, s12    
    25 : mul     i2, i2, 7  
    26 : mov     i2, i2     
    27 : add     i2, i2, i1 
    28 : mov     i1, s13    
    29 : mul     i1, i1, 8  
    30 : mov     i1, i1     
    31 : add     i1, i1, i2 
    32 : mov     i2, s14    
    33 : mul     i2, i2, 3  
    34 : mov     i2, i2     
    35 : add     i2, i2, i1 
    36 : mov     i1, s15    
    37 : mul     i1, i1, 2  
    38 : mov     i1, i1     
    39 : add     i1, i1, i2 
    40 : mov     i0, i1     
    41 : add     i4, i4, 40 
    42 : ret                
