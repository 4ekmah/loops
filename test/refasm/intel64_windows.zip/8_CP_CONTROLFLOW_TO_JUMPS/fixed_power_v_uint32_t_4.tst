fixed_power_v_uint32_t_4(i0, i1, i2)
     0 : sub              i4, i4, 40      
     1 : mov              i9, 0           
     2 : mov              i8, i8          
     3 : mul              i8, i8, 4       
     4 : mov              i0, i8          
     5 : __loops_label_0:                 
     6 : cmp              i9, i0          
     7 : jmp_ge           __loops_label_2 
     8 : vld.u32          v0, i1, i9      
     9 : mul.u32          v0, v0, v0      
    10 : mul.u32          v0, v0, v0      
    11 : vst.u32          i2, i9, v0      
    12 : add              i9, i9, 32      
    13 : jmp              0               
    14 : __loops_label_2:                 
    15 : mov              i0, 0           
    16 : add              i4, i4, 40      
    17 : ret                              
