fixed_power_v_int32_t_9(i0, i1, i2)
     0 : sub              i4, i4, 40      
     1 : mov              i9, 0           
     2 : mov              i8, i8          
     3 : mul              i8, i8, 4       
     4 : mov              i0, i8          
     5 : __loops_label_0:                 
     6 : cmp              i9, i0          
     7 : jmp_ge           __loops_label_2 
     8 : vld.i32          v0, i1, i9      
     9 : mul.i32          v1, v0, v0      
    10 : mul.i32          v1, v1, v1      
    11 : mul.i32          v1, v1, v1      
    12 : mul.i32          v0, v0, v1      
    13 : vst.i32          i2, i9, v0      
    14 : add              i9, i9, 32      
    15 : jmp              0               
    16 : __loops_label_2:                 
    17 : mov              i0, 0           
    18 : add              i4, i4, 40      
    19 : ret                              
