has_in_join_cascade(i0, i1, i2)
     0 : sub               i4, i4, 120      
     1 : spill             13, i13          
     2 : spill             14, i14          
     3 : mov               s5, 0            
     4 : load.i64          i13, i1, 16      
     5 : spill             6, i13           
     6 : load.i64          i13, i1, 0       
     7 : spill             7, i13           
     8 : load.i64          i13, i1, 8       
     9 : spill             8, i13           
    10 : __loops_label_0:                   
    11 : cmp               s6, 0            
    12 : jmp_le            __loops_label_2  
    13 : unspill           i13, 7           
    14 : load.i32          i14, i13         
    15 : spill             9, i14           
    16 : add               s7, s7, 4        
    17 : unspill           i13, 8           
    18 : load.i32          i14, i13         
    19 : spill             4, i14           
    20 : add               s8, s8, 4        
    21 : sub               s6, s6, 1        
    22 : load.i64          i13, i1, 40      
    23 : spill             10, i13          
    24 : load.i64          i13, i1, 24      
    25 : spill             11, i13          
    26 : load.i64          i13, i1, 32      
    27 : spill             12, i13          
    28 : __loops_label_3:                   
    29 : cmp               s10, 0           
    30 : jmp_le            __loops_label_5  
    31 : unspill           i13, 11          
    32 : load.i32          i14, i13         
    33 : spill             0, i14           
    34 : add               s11, s11, 4      
    35 : unspill           i13, 12          
    36 : load.i32          i9, i13          
    37 : add               s12, s12, 4      
    38 : sub               s10, s10, 1      
    39 : cmp               i9, s9           
    40 : jmp_le            __loops_label_7  
    41 : jmp               0                
    42 : __loops_label_7:                   
    43 : cmp               i9, s9           
    44 : jmp_ne            __loops_label_10 
    45 : load.i64          i13, i1, 64      
    46 : spill             1, i13           
    47 : load.i64          i13, i1, 48      
    48 : spill             2, i13           
    49 : load.i64          i13, i1, 56      
    50 : spill             3, i13           
    51 : __loops_label_11:                  
    52 : cmp               s1, 0            
    53 : jmp_le            __loops_label_13 
    54 : unspill           i13, 2           
    55 : load.i32          i0, i13          
    56 : add               s2, s2, 4        
    57 : unspill           i13, 3           
    58 : load.i32          i9, i13          
    59 : add               s3, s3, 4        
    60 : sub               s1, s1, 1        
    61 : cmp               i0, s4           
    62 : jmp_le            __loops_label_15 
    63 : jmp               0                
    64 : __loops_label_15:                  
    65 : cmp               i0, s4           
    66 : jmp_ne            __loops_label_18 
    67 : cmp               s0, i2           
    68 : jmp_ne            __loops_label_18 
    69 : cmp               i9, i8           
    70 : jmp_ne            __loops_label_18 
    71 : mov               s5, 1            
    72 : jmp               2                
    73 : __loops_label_16:                  
    74 : __loops_label_18:                  
    75 : jmp               11               
    76 : __loops_label_13:                  
    77 : __loops_label_8:                   
    78 : __loops_label_10:                  
    79 : jmp               3                
    80 : __loops_label_5:                   
    81 : jmp               0                
    82 : __loops_label_2:                   
    83 : mov               i0, s5           
    84 : unspill           i13, 13          
    85 : unspill           i14, 14          
    86 : add               i4, i4, 120      
    87 : ret                                
