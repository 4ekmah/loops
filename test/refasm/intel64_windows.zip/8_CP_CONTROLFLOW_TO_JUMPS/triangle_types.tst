triangle_types(i0, i1, i2)
     0 : sub               i4, i4, 24       
     1 : spill             1, i2            
     2 : cmp               i1, 0            
     3 : jmp_le            __loops_label_0  
     4 : cmp               s1, 0            
     5 : jmp_le            __loops_label_0  
     6 : cmp               i8, 0            
     7 : jmp_gt            __loops_label_1  
     8 : __loops_label_0:                   
     9 : mov               i0, 0            
    10 : jmp               18               
    11 : __loops_label_1:                   
    12 : mov               i9, s1           
    13 : add               i9, i9, i8       
    14 : cmp               i1, i9           
    15 : jmp_gt            __loops_label_3  
    16 : mov               i9, i1           
    17 : add               i9, i9, i8       
    18 : cmp               s1, i9           
    19 : jmp_gt            __loops_label_3  
    20 : mov               i9, i1           
    21 : add               i9, i9, s1       
    22 : cmp               i8, i9           
    23 : jmp_le            __loops_label_4  
    24 : __loops_label_3:                   
    25 : mov               i0, 0            
    26 : jmp               18               
    27 : __loops_label_4:                   
    28 : cmp               i1, s1           
    29 : jmp_ne            __loops_label_7  
    30 : cmp               i1, i8           
    31 : jmp_ne            __loops_label_7  
    32 : mov               i0, 2            
    33 : jmp               18               
    34 : __loops_label_7:                   
    35 : cmp               i1, s1           
    36 : jmp_eq            __loops_label_9  
    37 : cmp               i1, i8           
    38 : jmp_eq            __loops_label_9  
    39 : cmp               s1, i8           
    40 : jmp_ne            __loops_label_10 
    41 : __loops_label_9:                   
    42 : mov               i0, 3            
    43 : jmp               18               
    44 : __loops_label_10:                  
    45 : mov               i9, i1           
    46 : mul               i9, i9, i1       
    47 : mov               i0, s1           
    48 : mul               i0, i0, s1       
    49 : mov               i2, i8           
    50 : mul               i2, i2, i8       
    51 : mov               i2, i2           
    52 : add               i2, i2, i0       
    53 : cmp               i9, i2           
    54 : jmp_eq            __loops_label_12 
    55 : mov               i2, s1           
    56 : mul               i2, i2, s1       
    57 : mov               i9, i1           
    58 : mul               i9, i9, i1       
    59 : mov               i0, i8           
    60 : mul               i0, i0, i8       
    61 : mov               i0, i0           
    62 : add               i0, i0, i9       
    63 : cmp               i2, i0           
    64 : jmp_eq            __loops_label_12 
    65 : mov               i2, i8           
    66 : mul               i2, i2, i8       
    67 : mov               i9, i1           
    68 : mul               i9, i9, i1       
    69 : mov               i0, s1           
    70 : mul               i0, i0, s1       
    71 : mov               i0, i0           
    72 : add               i0, i0, i9       
    73 : cmp               i2, i0           
    74 : jmp_ne            __loops_label_13 
    75 : __loops_label_12:                  
    76 : mov               i0, 1            
    77 : jmp               18               
    78 : __loops_label_13:                  
    79 : mov               i2, i1           
    80 : mul               i2, i2, i1       
    81 : mov               i9, s1           
    82 : mul               i9, i9, s1       
    83 : mov               i0, i8           
    84 : mul               i0, i0, i8       
    85 : mov               i0, i0           
    86 : add               i0, i0, i9       
    87 : cmp               i2, i0           
    88 : jmp_gt            __loops_label_15 
    89 : mov               i2, s1           
    90 : mul               i2, i2, s1       
    91 : mov               i9, i1           
    92 : mul               i9, i9, i1       
    93 : mov               i0, i8           
    94 : mul               i0, i0, i8       
    95 : mov               i0, i0           
    96 : add               i0, i0, i9       
    97 : cmp               i2, i0           
    98 : jmp_gt            __loops_label_15 
    99 : mov               i2, i8           
   100 : mul               i2, i2, i8       
   101 : mov               i8, i1           
   102 : mul               i8, i8, i1       
   103 : mov               i1, s1           
   104 : mul               i1, i1, s1       
   105 : mov               i1, i1           
   106 : add               i1, i1, i8       
   107 : cmp               i2, i1           
   108 : jmp_le            __loops_label_16 
   109 : __loops_label_15:                  
   110 : mov               i0, 5            
   111 : jmp               18               
   112 : __loops_label_16:                  
   113 : mov               i0, 4            
   114 : jmp               18               
   115 : __loops_label_2:                   
   116 : __loops_label_5:                   
   117 : __loops_label_8:                   
   118 : __loops_label_11:                  
   119 : __loops_label_14:                  
   120 : __loops_label_17:                  
   121 : __loops_label_18:                  
   122 : add               i4, i4, 24       
   123 : ret                                
