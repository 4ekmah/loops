snake(i0, i1, i2)
     0 : sub              i4, i4, 680     
     1 : spill            82, i13         
     2 : spill            83, i14         
     3 : spill            84, i5          
     4 : mov              i5, i4          
     5 : add              i5, i5, 672     
     6 : mov              i9, i2          
     7 : add              i9, i9, i8      
     8 : sub              s76, i9, 1      
     9 : mov              i9, 0           
    10 : mov              s75, 1          
    11 : mov              i13, s75        
    12 : spill            72, i13         
    13 : neg              s72, s72        
    14 : mov              s77, 0          
    15 : __loops_label_0:                 
    16 : unspill          i13, 76         
    17 : cmp              s77, i13        
    18 : jmp_ge           __loops_label_2 
    19 : mov              s73, 0          
    20 : mov              s74, 0          
    21 : mov              i0, s77         
    22 : and              i0, i0, 1       
    23 : cmp              i0, 0           
    24 : jmp_eq           __loops_label_4 
    25 : sub              i0, i8, 1       
    26 : cmp              i0, s77         
    27 : unspill          i13, 77         
    28 : select_gt        i14, i0, i13    
    29 : spill            73, i14         
    30 : unspill          i13, 77         
    31 : sub              s78, i13, i0    
    32 : mov              s79, 0          
    33 : cmp              s77, i0         
    34 : unspill          i13, 79         
    35 : select_gt        i14, s78, i13   
    36 : spill            74, i14         
    37 : jmp              5               
    38 : __loops_label_4:                 
    39 : sub              s80, i2, 1      
    40 : unspill          i13, 77         
    41 : sub              i0, i13, s80    
    42 : mov              s81, 0          
    43 : unspill          i13, 80         
    44 : cmp              s77, i13        
    45 : unspill          i13, 81         
    46 : select_gt        i14, i0, i13    
    47 : spill            73, i14         
    48 : unspill          i13, 77         
    49 : cmp              s80, i13        
    50 : unspill          i13, 77         
    51 : select_gt        i14, s80, i13   
    52 : spill            74, i14         
    53 : __loops_label_5:                 
    54 : __loops_label_6:                 
    55 : cmp              s73, 0          
    56 : jmp_gt           __loops_label_8 
    57 : cmp              s73, i8         
    58 : jmp_ge           __loops_label_8 
    59 : cmp              s74, 0          
    60 : jmp_gt           __loops_label_8 
    61 : cmp              s74, i2         
    62 : jmp_ge           __loops_label_8 
    63 : mov              i0, -887494032  
    64 : unspill          i13, 73         
    65 : unspill          i14, 74         
    66 : call_noret       [i0](i13, i14)  
    67 : mov              i0, s74         
    68 : mul              i0, i0, i8      
    69 : mov              i0, i0          
    70 : add              i0, i0, s73     
    71 : store.u8         i1, i0, i9      
    72 : add              i9, i9, 1       
    73 : unspill          i13, 75         
    74 : add              s73, s73, i13   
    75 : unspill          i13, 72         
    76 : add              s74, s74, i13   
    77 : jmp              6               
    78 : __loops_label_8:                 
    79 : neg              s75, s75        
    80 : neg              s72, s72        
    81 : add              s77, s77, 1     
    82 : jmp              0               
    83 : __loops_label_2:                 
    84 : unspill          i5, 84          
    85 : unspill          i13, 82         
    86 : unspill          i14, 83         
    87 : add              i4, i4, 680     
    88 : ret                              
