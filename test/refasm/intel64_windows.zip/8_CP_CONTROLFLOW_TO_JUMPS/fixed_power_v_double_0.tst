fixed_power_v_double_0(i0, i1, i2)
     0 : sub              i4, i4, 24      
     1 : mov              i9, 0           
     2 : mov              i8, i8          
     3 : mul              i8, i8, 8       
     4 : spill            1, i8           
     5 : __loops_label_0:                 
     6 : cmp              i9, s1          
     7 : jmp_ge           __loops_label_2 
     8 : vld.fp64         v0, i1, i9      
     9 : mov              i0, 0           
    10 : vdef.fp64        v0              
    11 : setlane.fp64     v0, 0, i0       
    12 : broadcast.fp64   v0, v0, 0       
    13 : vst.fp64         i2, i9, v0      
    14 : add              i9, i9, 32      
    15 : jmp              0               
    16 : __loops_label_2:                 
    17 : mov              i0, 0           
    18 : add              i4, i4, 24      
    19 : ret                              
