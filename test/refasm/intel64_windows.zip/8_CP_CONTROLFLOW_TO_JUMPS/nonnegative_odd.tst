nonnegative_odd(i0, i1)
     0 : sub              i4, i4, 72      
     1 : spill            7, i13          
     2 : mov              i9, 0           
     3 : mov              i13, -4         
     4 : spill            5, i13          
     5 : mov              s4, i2          
     6 : unspill          i13, 4          
     7 : mul              i13, i13, 4     
     8 : spill            4, i13          
     9 : __loops_label_0:                 
    10 : cmp              i9, s4          
    11 : jmp_ge           __loops_label_2 
    12 : load.i32         i8, i1, i9      
    13 : cmp              i8, 0           
    14 : jmp_ge           __loops_label_4 
    15 : add              i9, i9, 4       
    16 : jmp              0               
    17 : __loops_label_4:                 
    18 : mov              i0, 2           
    19 : spill            6, i0           
    20 : mov              i0, i8          
    21 : mod              i2, i0, s6      
    22 : mov              i8, i2          
    23 : cmp              i8, 0           
    24 : jmp_eq           __loops_label_6 
    25 : mov              s5, i9          
    26 : jmp              2               
    27 : __loops_label_6:                 
    28 : add              i9, i9, 4       
    29 : jmp              0               
    30 : __loops_label_2:                 
    31 : mov              i9, 4           
    32 : mov              i1, s5          
    33 : mov              i0, i1          
    34 : div              i0, i0, i9      
    35 : mov              i1, i0          
    36 : mov              i0, i1          
    37 : unspill          i13, 7          
    38 : add              i4, i4, 72      
    39 : ret                              
