min_max_select(i0, i1, i2, i3)
     0 : sub              i4, i4, 88      
     1 : spill            10, i13         
     2 : mov              s9, 0           
     3 : mov              s4, 0           
     4 : mov              s5, 0           
     5 : load.i32         i13, i1         
     6 : spill            6, i13          
     7 : mov              i13, s6         
     8 : spill            7, i13          
     9 : mov              i2, i2          
    10 : shl              i2, i2, 2       
    11 : spill            8, i2           
    12 : __loops_label_0:                 
    13 : unspill          i13, 8          
    14 : cmp              s9, i13         
    15 : jmp_ge           __loops_label_2 
    16 : unspill          i13, 9          
    17 : load.i32         i0, i1, i13     
    18 : cmp              i0, s6          
    19 : unspill          i13, 4          
    20 : select_gt        i13, s9, i13    
    21 : spill            4, i13          
    22 : cmp              i0, s6          
    23 : unspill          i13, 6          
    24 : select_gt        i13, i0, i13    
    25 : spill            6, i13          
    26 : cmp              i0, s7          
    27 : unspill          i13, 5          
    28 : select_gt        i13, s9, i13    
    29 : spill            5, i13          
    30 : cmp              i0, s7          
    31 : unspill          i13, 7          
    32 : select_gt        i13, i0, i13    
    33 : spill            7, i13          
    34 : add              s9, s9, 4       
    35 : jmp              0               
    36 : __loops_label_2:                 
    37 : sar              s4, s4, 2       
    38 : sar              s5, s5, 2       
    39 : unspill          i13, 4          
    40 : store.i32        i8, i13         
    41 : unspill          i13, 5          
    42 : store.i32        i9, i13         
    43 : mov              i0, 0           
    44 : unspill          i13, 10         
    45 : add              i4, i4, 88      
    46 : ret                              
