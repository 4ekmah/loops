bresenham(i0, i1, i2, i3, i4, i5, i6)
     0 : sub               i4, i4, 104      
     1 : spill             10, i13          
     2 : spill             11, i14          
     3 : spill             9, i9            
     4 : unspill           i13, 18          
     5 : sub               i0, i13, i8      
     6 : mov               i9, i0           
     7 : neg               i9, i9           
     8 : select_s          i13, i0, i9      
     9 : spill             1, i13           
    10 : unspill           i13, 18          
    11 : sub               i0, i13, i8      
    12 : mov               i9, i0           
    13 : mov               i0, i0           
    14 : sar               i0, i0, 63       
    15 : mov               i9, i9           
    16 : neg               i9, i9           
    17 : mov               s2, i0           
    18 : x86_adc           s2, s2, i0       
    19 : unspill           i13, 19          
    20 : sub               i0, i13, s9      
    21 : mov               i9, i0           
    22 : neg               i9, i9           
    23 : select_s          i9, i0, i9       
    24 : mov               s3, i9           
    25 : neg               s3, s3           
    26 : unspill           i13, 19          
    27 : sub               i0, i13, s9      
    28 : mov               i9, i0           
    29 : mov               i0, i0           
    30 : sar               i0, i0, 63       
    31 : mov               i9, i9           
    32 : neg               i9, i9           
    33 : mov               i9, i0           
    34 : x86_adc           i9, i9, i0       
    35 : mov               i13, s1          
    36 : spill             5, i13           
    37 : unspill           i13, 3           
    38 : add               s5, s5, i13      
    39 : spill             4, i9            
    40 : __loops_label_0:                   
    41 : cmp               i1, 0            
    42 : jmp_eq            __loops_label_2  
    43 : mov               i13, s9          
    44 : spill             6, i13           
    45 : unspill           i13, 6           
    46 : mul               i13, i13, i2     
    47 : spill             6, i13           
    48 : mov               i13, s6          
    49 : spill             7, i13           
    50 : add               s7, s7, i8       
    51 : unspill           i14, 20          
    52 : unspill           i13, 7           
    53 : store.u8          i1, i13, i14     
    54 : cmp               i8, s18          
    55 : jmp_ne            __loops_label_4  
    56 : unspill           i13, 19          
    57 : cmp               s9, i13          
    58 : jmp_ne            __loops_label_4  
    59 : jmp               2                
    60 : __loops_label_4:                   
    61 : mov               i13, s5          
    62 : spill             8, i13           
    63 : shl               s8, s8, 1        
    64 : unspill           i13, 3           
    65 : cmp               s8, i13          
    66 : jmp_gt            __loops_label_6  
    67 : cmp               i8, s18          
    68 : jmp_ne            __loops_label_8  
    69 : jmp               2                
    70 : __loops_label_8:                   
    71 : unspill           i13, 3           
    72 : add               s5, s5, i13      
    73 : add               i8, i8, s2       
    74 : __loops_label_6:                   
    75 : unspill           i13, 1           
    76 : cmp               s8, i13          
    77 : jmp_gt            __loops_label_10 
    78 : unspill           i13, 19          
    79 : cmp               s9, i13          
    80 : jmp_ne            __loops_label_12 
    81 : jmp               2                
    82 : __loops_label_12:                  
    83 : unspill           i13, 1           
    84 : add               s5, s5, i13      
    85 : unspill           i13, 4           
    86 : add               s9, s9, i13      
    87 : __loops_label_10:                  
    88 : jmp               0                
    89 : __loops_label_2:                   
    90 : unspill           i13, 10          
    91 : unspill           i14, 11          
    92 : add               i4, i4, 104      
    93 : ret                                
