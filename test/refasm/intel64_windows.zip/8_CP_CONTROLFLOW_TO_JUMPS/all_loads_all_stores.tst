all_loads_all_stores(i0, i1, i2, i3, i4)
     0 : sub               i4, i4, 88       
     1 : spill             8, i13           
     2 : spill             9, i14           
     3 : spill             7, i9            
     4 : mov               s1, 0            
     5 : mov               s2, 0            
     6 : mov               s3, 0            
     7 : mov               i0, 2            
     8 : mov               i9, 1            
     9 : cmp               i2, 1            
    10 : select_gt         i9, i0, i9       
    11 : mov               i0, 4            
    12 : cmp               i2, 3            
    13 : select_gt         i9, i0, i9       
    14 : mov               i0, 8            
    15 : cmp               i2, 5            
    16 : select_gt         i13, i0, i9      
    17 : spill             4, i13           
    18 : mov               i0, 2            
    19 : mov               i9, 1            
    20 : cmp               s7, 1            
    21 : select_gt         i9, i0, i9       
    22 : mov               i0, 4            
    23 : cmp               s7, 3            
    24 : select_gt         i9, i0, i9       
    25 : mov               i0, 8            
    26 : cmp               s7, 5            
    27 : select_gt         i9, i0, i9       
    28 : spill             5, i9            
    29 : __loops_label_0:                   
    30 : unspill           i13, 16          
    31 : cmp               s1, i13          
    32 : jmp_ge            __loops_label_2  
    33 : def               i13              
    34 : spill             6, i13           
    35 : cmp               i2, 0            
    36 : jmp_ne            __loops_label_4  
    37 : unspill           i13, 2           
    38 : load.u8           i14, i1, i13     
    39 : spill             6, i14           
    40 : jmp               5                
    41 : __loops_label_4:                   
    42 : cmp               i2, 1            
    43 : jmp_ne            __loops_label_7  
    44 : unspill           i13, 2           
    45 : load.i8           i14, i1, i13     
    46 : spill             6, i14           
    47 : jmp               8                
    48 : __loops_label_7:                   
    49 : cmp               i2, 2            
    50 : jmp_ne            __loops_label_10 
    51 : unspill           i13, 2           
    52 : load.u16          i14, i1, i13     
    53 : spill             6, i14           
    54 : jmp               11               
    55 : __loops_label_10:                  
    56 : cmp               i2, 3            
    57 : jmp_ne            __loops_label_13 
    58 : unspill           i13, 2           
    59 : load.i16          i14, i1, i13     
    60 : spill             6, i14           
    61 : jmp               14               
    62 : __loops_label_13:                  
    63 : cmp               i2, 4            
    64 : jmp_ne            __loops_label_16 
    65 : unspill           i13, 2           
    66 : load.u32          i14, i1, i13     
    67 : spill             6, i14           
    68 : jmp               17               
    69 : __loops_label_16:                  
    70 : cmp               i2, 5            
    71 : jmp_ne            __loops_label_19 
    72 : unspill           i13, 2           
    73 : load.i32          i14, i1, i13     
    74 : spill             6, i14           
    75 : jmp               20               
    76 : __loops_label_19:                  
    77 : cmp               i2, 6            
    78 : jmp_ne            __loops_label_22 
    79 : unspill           i13, 2           
    80 : load.u64          i14, i1, i13     
    81 : spill             6, i14           
    82 : jmp               23               
    83 : __loops_label_22:                  
    84 : unspill           i13, 2           
    85 : load.i64          i14, i1, i13     
    86 : spill             6, i14           
    87 : __loops_label_5:                   
    88 : __loops_label_8:                   
    89 : __loops_label_11:                  
    90 : __loops_label_14:                  
    91 : __loops_label_17:                  
    92 : __loops_label_20:                  
    93 : __loops_label_23:                  
    94 : cmp               s7, 0            
    95 : jmp_ne            __loops_label_25 
    96 : unspill           i13, 3           
    97 : unspill           i14, 6           
    98 : store.u8          i8, i13, i14     
    99 : jmp               26               
   100 : __loops_label_25:                  
   101 : cmp               s7, 1            
   102 : jmp_ne            __loops_label_28 
   103 : unspill           i13, 3           
   104 : unspill           i14, 6           
   105 : store.i8          i8, i13, i14     
   106 : jmp               29               
   107 : __loops_label_28:                  
   108 : cmp               s7, 2            
   109 : jmp_ne            __loops_label_31 
   110 : unspill           i13, 3           
   111 : unspill           i14, 6           
   112 : store.u16         i8, i13, i14     
   113 : jmp               32               
   114 : __loops_label_31:                  
   115 : cmp               s7, 3            
   116 : jmp_ne            __loops_label_34 
   117 : unspill           i13, 3           
   118 : unspill           i14, 6           
   119 : store.i16         i8, i13, i14     
   120 : jmp               35               
   121 : __loops_label_34:                  
   122 : cmp               s7, 4            
   123 : jmp_ne            __loops_label_37 
   124 : unspill           i13, 3           
   125 : unspill           i14, 6           
   126 : store.u32         i8, i13, i14     
   127 : jmp               38               
   128 : __loops_label_37:                  
   129 : cmp               s7, 5            
   130 : jmp_ne            __loops_label_40 
   131 : unspill           i13, 3           
   132 : unspill           i14, 6           
   133 : store.i32         i8, i13, i14     
   134 : jmp               41               
   135 : __loops_label_40:                  
   136 : cmp               s7, 6            
   137 : jmp_ne            __loops_label_43 
   138 : unspill           i13, 3           
   139 : unspill           i14, 6           
   140 : store.u64         i8, i13, i14     
   141 : jmp               44               
   142 : __loops_label_43:                  
   143 : unspill           i13, 3           
   144 : unspill           i14, 6           
   145 : store.i64         i8, i13, i14     
   146 : __loops_label_26:                  
   147 : __loops_label_29:                  
   148 : __loops_label_32:                  
   149 : __loops_label_35:                  
   150 : __loops_label_38:                  
   151 : __loops_label_41:                  
   152 : __loops_label_44:                  
   153 : unspill           i13, 4           
   154 : add               s2, s2, i13      
   155 : unspill           i13, 5           
   156 : add               s3, s3, i13      
   157 : add               s1, s1, 1        
   158 : jmp               0                
   159 : __loops_label_2:                   
   160 : unspill           i13, 8           
   161 : unspill           i14, 9           
   162 : add               i4, i4, 88       
   163 : ret                                
