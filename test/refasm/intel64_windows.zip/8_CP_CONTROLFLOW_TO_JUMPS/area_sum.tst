area_sum(i0, i1)
     0 : sub              i4, i4, 616       
     1 : spill            75, i13           
     2 : spill            76, i5            
     3 : mov              i5, i4            
     4 : add              i5, i5, 608       
     5 : mov              s72, 0            
     6 : __loops_label_0:                   
     7 : cmp              i2, 0             
     8 : jmp_le           __loops_label_2   
     9 : load.i8          i13, i1           
    10 : spill            73, i13           
    11 : mov              i0, -887480080    
    12 : mov              i8, -887479776    
    13 : mov              i9, -887479552    
    14 : cmp              s73, 1            
    15 : select_eq        i9, i8, i9        
    16 : cmp              s73, 0            
    17 : select_eq        i13, i0, i9       
    18 : spill            74, i13           
    19 : mov              i8, -887480400    
    20 : mov              i0, -887480288    
    21 : mov              i9, -887480224    
    22 : cmp              s73, 1            
    23 : select_eq        i9, i0, i9        
    24 : cmp              s73, 0            
    25 : select_eq        i9, i8, i9        
    26 : unspill          i13, 74           
    27 : call_noret       [i13](i1)         
    28 : spill            74, i13           
    29 : call             [i9](i8, i1)      
    30 : mov              i9, -887480480    
    31 : unspill          i13, 72           
    32 : call             [i9](i8, i13, i8) 
    33 : mov              s72, i8           
    34 : add              i1, i1, 56        
    35 : sub              i2, i2, 1         
    36 : jmp              0                 
    37 : __loops_label_2:                   
    38 : mov              i0, s72           
    39 : unspill          i5, 76            
    40 : unspill          i13, 75           
    41 : add              i4, i4, 616       
    42 : ret                                
