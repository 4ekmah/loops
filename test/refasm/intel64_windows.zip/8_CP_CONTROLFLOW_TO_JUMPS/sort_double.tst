sort_double(i0, i1)
     0 : sub              i4, i4, 632      
     1 : spill            77, i13          
     2 : spill            78, i5           
     3 : mov              i5, i4           
     4 : add              i5, i5, 624      
     5 : mov              s74, i2          
     6 : shl              s74, s74, 3      
     7 : unspill          i13, 74          
     8 : sub              s75, i13, 8      
     9 : mov              s76, 0           
    10 : __loops_label_0:                  
    11 : unspill          i13, 75          
    12 : cmp              s76, i13         
    13 : jmp_ge           __loops_label_2  
    14 : mov              i13, s76         
    15 : spill            73, i13          
    16 : mov              i13, s73         
    17 : spill            72, i13          
    18 : add              s72, s72, 8      
    19 : __loops_label_3:                  
    20 : unspill          i13, 74          
    21 : cmp              s72, i13         
    22 : jmp_ge           __loops_label_5  
    23 : unspill          i13, 72          
    24 : load.fp64        i0, i1, i13      
    25 : unspill          i13, 73          
    26 : load.fp64        i9, i1, i13      
    27 : mov              i8, -887485760   
    28 : call             [i8](i8, i0, i9) 
    29 : cmp              i8, 0            
    30 : jmp_eq           __loops_label_7  
    31 : mov              i13, s72         
    32 : spill            73, i13          
    33 : __loops_label_7:                  
    34 : add              s72, s72, 8      
    35 : jmp              3                
    36 : __loops_label_5:                  
    37 : unspill          i13, 76          
    38 : cmp              s73, i13         
    39 : jmp_eq           __loops_label_9  
    40 : unspill          i13, 76          
    41 : load.fp64        i8, i1, i13      
    42 : unspill          i13, 73          
    43 : load.fp64        i9, i1, i13      
    44 : unspill          i13, 73          
    45 : store.fp64       i1, i13, i8      
    46 : unspill          i13, 76          
    47 : store.fp64       i1, i13, i9      
    48 : __loops_label_9:                  
    49 : add              s76, s76, 8      
    50 : jmp              0                
    51 : __loops_label_2:                  
    52 : unspill          i5, 78           
    53 : unspill          i13, 77          
    54 : add              i4, i4, 632      
    55 : ret                               
