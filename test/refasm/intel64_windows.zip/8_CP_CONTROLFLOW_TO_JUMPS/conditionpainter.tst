conditionpainter(i0)
     0 : sub              i4, i4, 56      
     1 : spill            5, i13          
     2 : mov              i13, -5         
     3 : spill            2, i13          
     4 : __loops_label_0:                 
     5 : cmp              s2, 5           
     6 : jmp_gt           __loops_label_2 
     7 : mov              i2, s2          
     8 : add              i2, i2, 5       
     9 : mov              i2, i2          
    10 : mul              i2, i2, 11      
    11 : mov              s1, i2          
    12 : unspill          i13, 1          
    13 : mul              i13, i13, 8     
    14 : spill            1, i13          
    15 : mov              i13, -5         
    16 : spill            0, i13          
    17 : __loops_label_3:                 
    18 : cmp              s0, 5           
    19 : jmp_gt           __loops_label_5 
    20 : mov              i0, s0          
    21 : add              i0, i0, 3       
    22 : mov              i9, 0           
    23 : cmp              s2, i0          
    24 : iverson_ge       i9              
    25 : mov              i0, 0           
    26 : cmp              s2, 4           
    27 : iverson_le       i0              
    28 : mov              i0, i0          
    29 : and              i0, i0, i9      
    30 : mov              i9, 0           
    31 : cmp              s0, -2          
    32 : iverson_ge       i9              
    33 : mov              i9, i9          
    34 : and              i9, i9, i0      
    35 : mov              i0, 0           
    36 : cmp              s0, 0           
    37 : iverson_le       i0              
    38 : mov              i0, i0          
    39 : and              i0, i0, i9      
    40 : unspill          i13, 0          
    41 : sub              i9, i13, 1      
    42 : mov              i8, 0           
    43 : cmp              s2, i9          
    44 : iverson_le       i8              
    45 : mov              i9, 0           
    46 : cmp              s0, 0           
    47 : iverson_ge       i9              
    48 : mov              i9, i9          
    49 : and              i9, i9, i8      
    50 : mov              i8, 0           
    51 : cmp              s2, 0           
    52 : iverson_le       i8              
    53 : mov              i8, i8          
    54 : and              i8, i8, i9      
    55 : mov              i9, s0          
    56 : mul              i9, i9, s0      
    57 : mov              i2, s2          
    58 : mul              i2, i2, s2      
    59 : mov              i2, i2          
    60 : add              i2, i2, i9      
    61 : mov              i9, 0           
    62 : cmp              i2, 9           
    63 : iverson_le       i9              
    64 : mov              i9, i9          
    65 : and              i9, i9, i8      
    66 : mov              s3, i9          
    67 : or               s3, s3, i0      
    68 : mov              i2, 2           
    69 : mov              s4, 0           
    70 : mov              i0, 0           
    71 : cmp              s0, 2           
    72 : iverson_ge       i0              
    73 : mov              i9, 0           
    74 : cmp              s0, 4           
    75 : iverson_le       i9              
    76 : mov              i9, i9          
    77 : and              i9, i9, i0      
    78 : mov              i0, 0           
    79 : cmp              s2, 1           
    80 : iverson_ge       i0              
    81 : mov              i8, 0           
    82 : cmp              s2, 3           
    83 : iverson_le       i8              
    84 : mov              i8, i8          
    85 : and              i8, i8, i0      
    86 : mov              i8, i8          
    87 : or               i8, i8, i9      
    88 : mov              i9, s0          
    89 : mul              i9, i9, s0      
    90 : mov              i0, s2          
    91 : mul              i0, i0, s2      
    92 : mov              i0, i0          
    93 : add              i0, i0, i9      
    94 : mov              i9, 0           
    95 : cmp              i0, 16          
    96 : iverson_le       i9              
    97 : mov              i9, i9          
    98 : and              i9, i9, i8      
    99 : cmp              i9, 0           
   100 : unspill          i13, 4          
   101 : select_ne        i2, i2, i13     
   102 : mov              i2, i2          
   103 : add              i2, i2, s3      
   104 : mov              i8, s2          
   105 : mul              i8, i8, 2       
   106 : cmp              i8, s0          
   107 : jmp_gt           __loops_label_8 
   108 : mov              i8, s0          
   109 : add              i8, i8, 3       
   110 : mov              i8, i8          
   111 : neg              i8, i8          
   112 : mov              i9, s0          
   113 : add              i9, i9, 3       
   114 : mov              i9, i9          
   115 : mul              i9, i9, i8      
   116 : cmp              s2, i9          
   117 : jmp_le           __loops_label_9 
   118 : __loops_label_8:                 
   119 : mov              i8, s0          
   120 : mul              i8, i8, 2       
   121 : cmp              s2, i8          
   122 : jmp_gt           __loops_label_7 
   123 : mov              i8, s0          
   124 : add              i8, i8, 3       
   125 : mov              i8, i8          
   126 : neg              i8, i8          
   127 : mov              i9, s0          
   128 : add              i9, i9, 3       
   129 : mov              i9, i9          
   130 : mul              i9, i9, i8      
   131 : cmp              s2, i9          
   132 : jmp_gt           __loops_label_7 
   133 : __loops_label_9:                 
   134 : cmp              s0, 0           
   135 : jmp_gt           __loops_label_7 
   136 : add              i2, i2, 3       
   137 : __loops_label_7:                 
   138 : mov              i8, s0          
   139 : add              i8, i8, 5       
   140 : mov              i8, i8          
   141 : shl              i8, i8, 3       
   142 : mov              i8, i8          
   143 : add              i8, i8, s1      
   144 : store.i64        i1, i8, i2      
   145 : add              s0, s0, 1       
   146 : jmp              3               
   147 : __loops_label_5:                 
   148 : add              s2, s2, 1       
   149 : jmp              0               
   150 : __loops_label_2:                 
   151 : unspill          i13, 5          
   152 : add              i4, i4, 56      
   153 : ret                              
