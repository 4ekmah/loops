min_max_scalar(i0, i1, i2, i3)
     0 : sub              i4, i4, 72      
     1 : spill            8, i13          
     2 : mov              s6, 0           
     3 : mov              s1, 0           
     4 : mov              s2, 0           
     5 : load.i32         i13, i1         
     6 : spill            3, i13          
     7 : mov              i13, s3         
     8 : spill            4, i13          
     9 : mov              i2, i2          
    10 : mul              i2, i2, 4       
    11 : spill            5, i2           
    12 : __loops_label_0:                 
    13 : unspill          i13, 5          
    14 : cmp              s6, i13         
    15 : jmp_ge           __loops_label_2 
    16 : unspill          i13, 6          
    17 : load.i32         i0, i1, i13     
    18 : cmp              i0, s3          
    19 : jmp_ge           __loops_label_4 
    20 : mov              s3, i0          
    21 : mov              i13, s6         
    22 : spill            1, i13          
    23 : __loops_label_4:                 
    24 : cmp              i0, s4          
    25 : jmp_le           __loops_label_6 
    26 : mov              s4, i0          
    27 : mov              i13, s6         
    28 : spill            2, i13          
    29 : __loops_label_6:                 
    30 : add              s6, s6, 4       
    31 : jmp              0               
    32 : __loops_label_2:                 
    33 : mov              s7, 4           
    34 : mov              i1, s1          
    35 : mov              i0, i1          
    36 : div              i0, i0, s7      
    37 : mov              i1, i0          
    38 : mov              i0, s2          
    39 : div              i0, i0, s7      
    40 : store.i32        i8, i1          
    41 : store.i32        i9, i0          
    42 : mov              i0, 0           
    43 : unspill          i13, 8          
    44 : add              i4, i4, 72      
    45 : ret                              
