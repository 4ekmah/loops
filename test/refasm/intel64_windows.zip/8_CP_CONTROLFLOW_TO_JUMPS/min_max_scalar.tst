min_max_scalar(i0, i1, i2, i3)
     0 : sub              i4, i4, 104     
     1 : spill            11, i13         
     2 : mov              s9, 0           
     3 : mov              s4, 0           
     4 : mov              s5, 0           
     5 : load.i32         i13, i1         
     6 : spill            6, i13          
     7 : mov              i13, s6         
     8 : spill            7, i13          
     9 : mov              i2, i2          
    10 : mul              i2, i2, 4       
    11 : spill            8, i2           
    12 : __loops_label_0:                 
    13 : unspill          i13, 8          
    14 : cmp              s9, i13         
    15 : jmp_ge           __loops_label_2 
    16 : unspill          i13, 9          
    17 : load.i32         i0, i1, i13     
    18 : cmp              i0, s6          
    19 : jmp_ge           __loops_label_4 
    20 : mov              s6, i0          
    21 : mov              i13, s9         
    22 : spill            4, i13          
    23 : __loops_label_4:                 
    24 : cmp              i0, s7          
    25 : jmp_le           __loops_label_6 
    26 : mov              s7, i0          
    27 : mov              i13, s9         
    28 : spill            5, i13          
    29 : __loops_label_6:                 
    30 : add              s9, s9, 4       
    31 : jmp              0               
    32 : __loops_label_2:                 
    33 : mov              s10, 4          
    34 : mov              i1, s4          
    35 : mov              i0, i1          
    36 : div              i0, i0, s10     
    37 : mov              i1, i0          
    38 : mov              i0, s5          
    39 : div              i0, i0, s10     
    40 : store.i32        i8, i1          
    41 : store.i32        i9, i0          
    42 : mov              i0, 0           
    43 : unspill          i13, 11         
    44 : add              i4, i4, 104     
    45 : ret                              
