exp_f32(i0, i1, i2)
     0 : sub              i4, i4, 456       
     1 : spill            24, v6            
     2 : spill            28, v7            
     3 : spill            32, v8            
     4 : spill            36, v9            
     5 : spill            40, v10           
     6 : spill            44, v11           
     7 : spill            48, v12           
     8 : spill            52, v13           
     9 : mov              i9, -1028603739   
    10 : vdef.fp32        v1                
    11 : setlane.fp32     v1, 0, i9         
    12 : broadcast.fp32   v0, v1, 0         
    13 : mov              i9, 1118879909    
    14 : vdef.fp32        v2                
    15 : setlane.fp32     v2, 0, i9         
    16 : broadcast.fp32   v1, v2, 0         
    17 : mov              i9, 1056964608    
    18 : vdef.fp32        v3                
    19 : setlane.fp32     v3, 0, i9         
    20 : broadcast.fp32   v2, v3, 0         
    21 : mov              i9, 1065353216    
    22 : vdef.fp32        v5                
    23 : setlane.fp32     v5, 0, i9         
    24 : broadcast.fp32   v3, v5, 0         
    25 : mov              i9, 1069066811    
    26 : vdef.fp32        v6                
    27 : setlane.fp32     v6, 0, i9         
    28 : broadcast.fp32   v5, v6, 0         
    29 : mov              i9, -1087275008   
    30 : vdef.fp32        v7                
    31 : setlane.fp32     v7, 0, i9         
    32 : broadcast.fp32   v6, v7, 0         
    33 : mov              i9, 962494595     
    34 : vdef.fp32        v8                
    35 : setlane.fp32     v8, 0, i9         
    36 : broadcast.fp32   v7, v8, 0         
    37 : mov              i9, 961571175     
    38 : vdef.fp32        v9                
    39 : setlane.fp32     v9, 0, i9         
    40 : broadcast.fp32   v8, v9, 0         
    41 : mov              i9, 985088974     
    42 : vdef.fp32        v9                
    43 : setlane.fp32     v9, 0, i9         
    44 : broadcast.fp32   v13, v9, 0        
    45 : spill            20, v13           
    46 : mov              i9, 1007192328    
    47 : vdef.fp32        v9                
    48 : setlane.fp32     v9, 0, i9         
    49 : broadcast.fp32   v13, v9, 0        
    50 : spill            16, v13           
    51 : mov              i9, 1026206145    
    52 : vdef.fp32        v9                
    53 : setlane.fp32     v9, 0, i9         
    54 : broadcast.fp32   v13, v9, 0        
    55 : spill            12, v13           
    56 : mov              i9, 1042983594    
    57 : vdef.fp32        v9                
    58 : setlane.fp32     v9, 0, i9         
    59 : broadcast.fp32   v13, v9, 0        
    60 : spill            8, v13            
    61 : mov              i9, 1056964608    
    62 : vdef.fp32        v9                
    63 : setlane.fp32     v9, 0, i9         
    64 : broadcast.fp32   v13, v9, 0        
    65 : spill            0, v13            
    66 : mov              i9, 127           
    67 : vdef.i32         v9                
    68 : setlane.i32      v9, 0, i9         
    69 : broadcast.i32    v13, v9, 0        
    70 : spill            4, v13            
    71 : mov              i9, 0             
    72 : __loops_label_0:                   
    73 : cmp              i8, 0             
    74 : jmp_le           __loops_label_2   
    75 : vld.fp32         v12, i2, i9       
    76 : min.fp32         v12, v12, v1      
    77 : max.fp32         v12, v12, v0      
    78 : mov              v11, v2           
    79 : fma.fp32         v11, v11, v12, v5 
    80 : floor.fp32_fp32  v11, v11          
    81 : cast.fp32_i32    v11, v11          
    82 : cast.i32_fp32    v10, v11          
    83 : mov              v12, v12          
    84 : fma.fp32         v12, v12, v10, v6 
    85 : mov              v12, v12          
    86 : fma.fp32         v12, v12, v10, v7 
    87 : unspill          v13, 20           
    88 : mov              v10, v13          
    89 : fma.fp32         v10, v10, v12, v8 
    90 : unspill          v13, 16           
    91 : mov              v9, v13           
    92 : fma.fp32         v9, v9, v10, v12  
    93 : unspill          v13, 12           
    94 : mov              v10, v13          
    95 : fma.fp32         v10, v10, v9, v12 
    96 : unspill          v13, 8            
    97 : mov              v9, v13           
    98 : fma.fp32         v9, v9, v10, v12  
    99 : unspill          v13, 0            
   100 : mov              v10, v13          
   101 : fma.fp32         v10, v10, v9, v12 
   102 : mul.fp32         v9, v12, v12      
   103 : mov              v12, v12          
   104 : fma.fp32         v12, v12, v10, v9 
   105 : add.fp32         v9, v12, v3       
   106 : unspill          v13, 4            
   107 : add.i32          v10, v11, v13     
   108 : sal.i32          v10, v10, 23      
   109 : mul.fp32         v9, v9, v10       
   110 : vst.fp32         i1, i9, v9        
   111 : add              i9, i9, 32        
   112 : sub              i8, i8, 8         
   113 : jmp              0                 
   114 : __loops_label_2:                   
   115 : unspill          v6, 24            
   116 : unspill          v7, 28            
   117 : unspill          v8, 32            
   118 : unspill          v9, 36            
   119 : unspill          v10, 40           
   120 : unspill          v11, 44           
   121 : unspill          v12, 48           
   122 : unspill          v13, 52           
   123 : add              i4, i4, 456       
   124 : ret                                
