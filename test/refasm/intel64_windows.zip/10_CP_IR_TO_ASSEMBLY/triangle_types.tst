triangle_types(i0, i1, i2)
     0 : sub  rsp, 018h                   ; 48 81 ec 18 00 00 00                 
     1 : mov  qword ptr [rsp + 008h], rdx ; 48 89 94 24 08 00 00 00              
     2 : cmp  rcx, 0h                     ; 48 83 f9 00                          
     3 : jle  __loops_label_0             ; 0f 8e 1c 00 00 00                    
     4 : cmp  qword ptr [rsp + 008h], 0h  ; 48 81 bc 24 08 00 00 00 00 00 00 00  
     5 : jle  __loops_label_0             ; 0f 8e 0a 00 00 00                    
     6 : cmp  r8, 0h                      ; 49 83 f8 00                          
     7 : jg   __loops_label_1             ; 0f 8f 08 00 00 00                    
     8 :      __loops_label_0:            ;                                      
     9 : xor  rax, rax                    ; 48 31 c0                             
    10 : jmp  __loops_label_18            ; e9 be 01 00 00                       
    11 :      __loops_label_1:            ;                                      
    12 : mov  r9, qword ptr [rsp + 008h]  ; 4c 8b 8c 24 08 00 00 00              
    13 : add  r9, r8                      ; 4d 01 c1                             
    14 : cmp  rcx, r9                     ; 4c 39 c9                             
    15 : jg   __loops_label_3             ; 0f 8f 28 00 00 00                    
    16 : mov  r9, rcx                     ; 49 89 c9                             
    17 : add  r9, r8                      ; 4d 01 c1                             
    18 : cmp  qword ptr [rsp + 008h], r9  ; 4c 39 8c 24 08 00 00 00              
    19 : jg   __loops_label_3             ; 0f 8f 14 00 00 00                    
    20 : mov  r9, rcx                     ; 49 89 c9                             
    21 : add  r9, qword ptr [rsp + 008h]  ; 4c 03 8c 24 08 00 00 00              
    22 : cmp  r8, r9                      ; 4d 39 c8                             
    23 : jle  __loops_label_4             ; 0f 8e 08 00 00 00                    
    24 :      __loops_label_3:            ;                                      
    25 : xor  rax, rax                    ; 48 31 c0                             
    26 : jmp  __loops_label_18            ; e9 7a 01 00 00                       
    27 :      __loops_label_4:            ;                                      
    28 : cmp  rcx, qword ptr [rsp + 008h] ; 48 3b 8c 24 08 00 00 00              
    29 : jne  __loops_label_7             ; 0f 85 15 00 00 00                    
    30 : cmp  rcx, r8                     ; 4c 39 c1                             
    31 : jne  __loops_label_7             ; 0f 85 0c 00 00 00                    
    32 : mov  rax, 002h                   ; 48 c7 c0 02 00 00 00                 
    33 : jmp  __loops_label_18            ; e9 57 01 00 00                       
    34 :      __loops_label_7:            ;                                      
    35 : cmp  rcx, qword ptr [rsp + 008h] ; 48 3b 8c 24 08 00 00 00              
    36 : je   __loops_label_9             ; 0f 84 17 00 00 00                    
    37 : cmp  rcx, r8                     ; 4c 39 c1                             
    38 : je   __loops_label_9             ; 0f 84 0e 00 00 00                    
    39 : cmp  qword ptr [rsp + 008h], r8  ; 4c 39 84 24 08 00 00 00              
    40 : jne  __loops_label_10            ; 0f 85 0c 00 00 00                    
    41 :      __loops_label_9:            ;                                      
    42 : mov  rax, 003h                   ; 48 c7 c0 03 00 00 00                 
    43 : jmp  __loops_label_18            ; e9 26 01 00 00                       
    44 :      __loops_label_10:           ;                                      
    45 : mov  r9, rcx                     ; 49 89 c9                             
    46 : imul r9, rcx                     ; 4c 0f af c9                          
    47 : mov  rax, qword ptr [rsp + 008h] ; 48 8b 84 24 08 00 00 00              
    48 : imul rax, qword ptr [rsp + 008h] ; 48 0f af 84 24 08 00 00 00           
    49 : mov  rdx, r8                     ; 4c 89 c2                             
    50 : imul rdx, r8                     ; 49 0f af d0                          
    51 : add  rdx, rax                    ; 48 01 c2                             
    52 : cmp  r9, rdx                     ; 49 39 d1                             
    53 : je   __loops_label_12            ; 0f 84 56 00 00 00                    
    54 : mov  rdx, qword ptr [rsp + 008h] ; 48 8b 94 24 08 00 00 00              
    55 : imul rdx, qword ptr [rsp + 008h] ; 48 0f af 94 24 08 00 00 00           
    56 : mov  r9, rcx                     ; 49 89 c9                             
    57 : imul r9, rcx                     ; 4c 0f af c9                          
    58 : mov  rax, r8                     ; 4c 89 c0                             
    59 : imul rax, r8                     ; 49 0f af c0                          
    60 : add  rax, r9                     ; 4c 01 c8                             
    61 : cmp  rdx, rax                    ; 48 39 c2                             
    62 : je   __loops_label_12            ; 0f 84 2b 00 00 00                    
    63 : mov  rdx, r8                     ; 4c 89 c2                             
    64 : imul rdx, r8                     ; 49 0f af d0                          
    65 : mov  r9, rcx                     ; 49 89 c9                             
    66 : imul r9, rcx                     ; 4c 0f af c9                          
    67 : mov  rax, qword ptr [rsp + 008h] ; 48 8b 84 24 08 00 00 00              
    68 : imul rax, qword ptr [rsp + 008h] ; 48 0f af 84 24 08 00 00 00           
    69 : add  rax, r9                     ; 4c 01 c8                             
    70 : cmp  rdx, rax                    ; 48 39 c2                             
    71 : jne  __loops_label_13            ; 0f 85 0c 00 00 00                    
    72 :      __loops_label_12:           ;                                      
    73 : mov  rax, 001h                   ; 48 c7 c0 01 00 00 00                 
    74 : jmp  __loops_label_18            ; e9 99 00 00 00                       
    75 :      __loops_label_13:           ;                                      
    76 : mov  rdx, rcx                    ; 48 89 ca                             
    77 : imul rdx, rcx                    ; 48 0f af d1                          
    78 : mov  r9, qword ptr [rsp + 008h]  ; 4c 8b 8c 24 08 00 00 00              
    79 : imul r9, qword ptr [rsp + 008h]  ; 4c 0f af 8c 24 08 00 00 00           
    80 : mov  rax, r8                     ; 4c 89 c0                             
    81 : imul rax, r8                     ; 49 0f af c0                          
    82 : add  rax, r9                     ; 4c 01 c8                             
    83 : cmp  rdx, rax                    ; 48 39 c2                             
    84 : jg   __loops_label_15            ; 0f 8f 56 00 00 00                    
    85 : mov  rdx, qword ptr [rsp + 008h] ; 48 8b 94 24 08 00 00 00              
    86 : imul rdx, qword ptr [rsp + 008h] ; 48 0f af 94 24 08 00 00 00           
    87 : mov  r9, rcx                     ; 49 89 c9                             
    88 : imul r9, rcx                     ; 4c 0f af c9                          
    89 : mov  rax, r8                     ; 4c 89 c0                             
    90 : imul rax, r8                     ; 49 0f af c0                          
    91 : add  rax, r9                     ; 4c 01 c8                             
    92 : cmp  rdx, rax                    ; 48 39 c2                             
    93 : jg   __loops_label_15            ; 0f 8f 2b 00 00 00                    
    94 : mov  rdx, r8                     ; 4c 89 c2                             
    95 : imul rdx, r8                     ; 49 0f af d0                          
    96 : mov  r8, rcx                     ; 49 89 c8                             
    97 : imul r8, rcx                     ; 4c 0f af c1                          
    98 : mov  rcx, qword ptr [rsp + 008h] ; 48 8b 8c 24 08 00 00 00              
    99 : imul rcx, qword ptr [rsp + 008h] ; 48 0f af 8c 24 08 00 00 00           
   100 : add  rcx, r8                     ; 4c 01 c1                             
   101 : cmp  rdx, rcx                    ; 48 39 ca                             
   102 : jle  __loops_label_16            ; 0f 8e 0c 00 00 00                    
   103 :      __loops_label_15:           ;                                      
   104 : mov  rax, 005h                   ; 48 c7 c0 05 00 00 00                 
   105 : jmp  __loops_label_18            ; e9 0c 00 00 00                       
   106 :      __loops_label_16:           ;                                      
   107 : mov  rax, 004h                   ; 48 c7 c0 04 00 00 00                 
   108 : jmp  __loops_label_18            ; e9 00 00 00 00                       
   109 :      __loops_label_2:            ;                                      
   110 :      __loops_label_5:            ;                                      
   111 :      __loops_label_8:            ;                                      
   112 :      __loops_label_11:           ;                                      
   113 :      __loops_label_14:           ;                                      
   114 :      __loops_label_17:           ;                                      
   115 :      __loops_label_18:           ;                                      
   116 : add  rsp, 018h                   ; 48 81 c4 18 00 00 00                 
   117 : ret                              ; c3                                   
