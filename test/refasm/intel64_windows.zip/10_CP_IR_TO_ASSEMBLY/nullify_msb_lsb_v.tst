nullify_msb_lsb_v(i0, i1, i2, i3)
     0 : sub          rsp, 028h                     ; 48 81 ec 28 00 00 00                 
     1 : mov          qword ptr [rsp + 018h], r13   ; 4c 89 ac 24 18 00 00 00              
     2 : mov          qword ptr [rsp + 010h], 0h    ; 48 c7 84 24 10 00 00 00 00 00 00 00  
     3 : imul         r9, 004h                      ; 4d 6b c9 04                          
     4 : mov          rax, 001h                     ; 48 c7 c0 01 00 00 00                 
     5 : vpinsrd      xmm1, xmm1, eax, 0h           ; c4 e3 71 22 c8 00                    
     6 : vpbroadcastd ymm0, xmm1                    ; c4 e2 7d 58 c1                       
     7 : mov          qword ptr [rsp + 008h], r9    ; 4c 89 8c 24 08 00 00 00              
     8 :              __loops_label_0:              ;                                      
     9 : mov          r13, qword ptr [rsp + 008h]   ; 4c 8b ac 24 08 00 00 00              
    10 : cmp          qword ptr [rsp + 010h], r13   ; 4c 39 ac 24 10 00 00 00              
    11 : jge          __loops_label_2               ; 0f 8d 97 00 00 00                    
    12 : mov          r13, qword ptr [rsp + 010h]   ; 4c 8b ac 24 10 00 00 00              
    13 : vmovdqu      ymm1, ymmword ptr [rcx + r13] ; c4 a1 7e 6f 0c 29                    
    14 : vpsrld       ymm2, ymm1, 001h              ; c5 ed 72 d1 01                       
    15 : vpor         ymm2, ymm1, ymm2              ; c5 f5 eb d2                          
    16 : vpsrld       ymm3, ymm2, 002h              ; c5 e5 72 d2 02                       
    17 : vpor         ymm2, ymm2, ymm3              ; c5 ed eb d3                          
    18 : vpsrld       ymm3, ymm2, 004h              ; c5 e5 72 d2 04                       
    19 : vpor         ymm2, ymm2, ymm3              ; c5 ed eb d3                          
    20 : vpsrld       ymm3, ymm2, 008h              ; c5 e5 72 d2 08                       
    21 : vpor         ymm2, ymm2, ymm3              ; c5 ed eb d3                          
    22 : vpsrld       ymm3, ymm2, 010h              ; c5 e5 72 d2 10                       
    23 : vpor         ymm2, ymm2, ymm3              ; c5 ed eb d3                          
    24 : vpaddd       ymm2, ymm2, ymm0              ; c5 ed fe d0                          
    25 : vpsrld       ymm2, ymm2, 001h              ; c5 ed 72 d2 01                       
    26 : vpxor        ymm2, ymm2, ymm1              ; c5 ed ef d1                          
    27 : mov          r13, qword ptr [rsp + 010h]   ; 4c 8b ac 24 10 00 00 00              
    28 : vmovdqu      ymmword ptr [rdx + r13], ymm2 ; c4 a1 7e 7f 14 2a                    
    29 : vpsubd       ymm2, ymm1, ymm0              ; c5 f5 fa d0                          
    30 : mov          rax, 0ffh                     ; 48 c7 c0 ff 00 00 00                 
    31 : vpinsrb      xmm3, xmm3, eax, 0h           ; c4 e3 61 20 d8 00                    
    32 : vpbroadcastb ymm3, xmm3                    ; c4 e2 7d 78 db                       
    33 : vpxor        ymm2, ymm2, ymm3              ; c5 ed ef d3                          
    34 : vpand        ymm2, ymm1, ymm2              ; c5 f5 db d2                          
    35 : vpxor        ymm1, ymm2, ymm1              ; c5 ed ef c9                          
    36 : mov          r13, qword ptr [rsp + 010h]   ; 4c 8b ac 24 10 00 00 00              
    37 : vmovdqu      ymmword ptr [r8 + r13], ymm1  ; c4 81 7e 7f 0c 28                    
    38 : add          qword ptr [rsp + 010h], 020h  ; 48 81 84 24 10 00 00 00 20 00 00 00  
    39 : jmp          __loops_label_0               ; e9 53 ff ff ff                       
    40 :              __loops_label_2:              ;                                      
    41 : mov          r13, qword ptr [rsp + 018h]   ; 4c 8b ac 24 18 00 00 00              
    42 : add          rsp, 028h                     ; 48 81 c4 28 00 00 00                 
    43 : ret                                        ; c3                                   
