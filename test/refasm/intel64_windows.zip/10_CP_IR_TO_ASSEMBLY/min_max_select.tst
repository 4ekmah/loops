min_max_select(i0, i1, i2, i3)
     0 : sub    rsp, 058h                    ; 48 81 ec 58 00 00 00                 
     1 : mov    qword ptr [rsp + 050h], r13  ; 4c 89 ac 24 50 00 00 00              
     2 : mov    qword ptr [rsp + 048h], 0h   ; 48 c7 84 24 48 00 00 00 00 00 00 00  
     3 : mov    qword ptr [rsp + 020h], 0h   ; 48 c7 84 24 20 00 00 00 00 00 00 00  
     4 : mov    qword ptr [rsp + 028h], 0h   ; 48 c7 84 24 28 00 00 00 00 00 00 00  
     5 : movsxd r13, dword ptr [rcx]         ; 4c 63 29                             
     6 : mov    qword ptr [rsp + 030h], r13  ; 4c 89 ac 24 30 00 00 00              
     7 : mov    r13, qword ptr [rsp + 030h]  ; 4c 8b ac 24 30 00 00 00              
     8 : mov    qword ptr [rsp + 038h], r13  ; 4c 89 ac 24 38 00 00 00              
     9 : shl    rdx, 002h                    ; 48 c1 e2 02                          
    10 : mov    qword ptr [rsp + 040h], rdx  ; 48 89 94 24 40 00 00 00              
    11 :        __loops_label_0:             ;                                      
    12 : mov    r13, qword ptr [rsp + 040h]  ; 4c 8b ac 24 40 00 00 00              
    13 : cmp    qword ptr [rsp + 048h], r13  ; 4c 39 ac 24 48 00 00 00              
    14 : jge    __loops_label_2              ; 0f 8d 97 00 00 00                    
    15 : mov    r13, qword ptr [rsp + 048h]  ; 4c 8b ac 24 48 00 00 00              
    16 : movsxd rax, dword ptr [rcx + r13]   ; 4a 63 04 29                          
    17 : cmp    rax, qword ptr [rsp + 030h]  ; 48 3b 84 24 30 00 00 00              
    18 : mov    r13, qword ptr [rsp + 020h]  ; 4c 8b ac 24 20 00 00 00              
    19 : cmovl  r13, qword ptr [rsp + 048h]  ; 4c 0f 4c ac 24 48 00 00 00           
    20 : mov    qword ptr [rsp + 020h], r13  ; 4c 89 ac 24 20 00 00 00              
    21 : cmp    rax, qword ptr [rsp + 030h]  ; 48 3b 84 24 30 00 00 00              
    22 : mov    r13, qword ptr [rsp + 030h]  ; 4c 8b ac 24 30 00 00 00              
    23 : cmovl  r13, rax                     ; 4c 0f 4c e8                          
    24 : mov    qword ptr [rsp + 030h], r13  ; 4c 89 ac 24 30 00 00 00              
    25 : cmp    rax, qword ptr [rsp + 038h]  ; 48 3b 84 24 38 00 00 00              
    26 : mov    r13, qword ptr [rsp + 028h]  ; 4c 8b ac 24 28 00 00 00              
    27 : cmovg  r13, qword ptr [rsp + 048h]  ; 4c 0f 4f ac 24 48 00 00 00           
    28 : mov    qword ptr [rsp + 028h], r13  ; 4c 89 ac 24 28 00 00 00              
    29 : cmp    rax, qword ptr [rsp + 038h]  ; 48 3b 84 24 38 00 00 00              
    30 : mov    r13, qword ptr [rsp + 038h]  ; 4c 8b ac 24 38 00 00 00              
    31 : cmovg  r13, rax                     ; 4c 0f 4f e8                          
    32 : mov    qword ptr [rsp + 038h], r13  ; 4c 89 ac 24 38 00 00 00              
    33 : add    qword ptr [rsp + 048h], 004h ; 48 81 84 24 48 00 00 00 04 00 00 00  
    34 : jmp    __loops_label_0              ; e9 53 ff ff ff                       
    35 :        __loops_label_2:             ;                                      
    36 : sar    qword ptr [rsp + 020h], 002h ; 48 c1 bc 24 20 00 00 00 02           
    37 : sar    qword ptr [rsp + 028h], 002h ; 48 c1 bc 24 28 00 00 00 02           
    38 : mov    r13, qword ptr [rsp + 020h]  ; 4c 8b ac 24 20 00 00 00              
    39 : mov    dword ptr [r8], r13d         ; 45 89 28                             
    40 : mov    r13, qword ptr [rsp + 028h]  ; 4c 8b ac 24 28 00 00 00              
    41 : mov    dword ptr [r9], r13d         ; 45 89 29                             
    42 : xor    rax, rax                     ; 48 31 c0                             
    43 : mov    r13, qword ptr [rsp + 050h]  ; 4c 8b ac 24 50 00 00 00              
    44 : add    rsp, 058h                    ; 48 81 c4 58 00 00 00                 
    45 : ret                                 ; c3                                   
