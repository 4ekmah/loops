all_loads_all_stores(i0, i1, i2, i3, i4)
     0 : sub    rsp, 068h                    ; 48 81 ec 68 00 00 00                 
     1 : mov    qword ptr [rsp + 058h], r13  ; 4c 89 ac 24 58 00 00 00              
     2 : mov    qword ptr [rsp + 060h], r14  ; 4c 89 b4 24 60 00 00 00              
     3 : mov    qword ptr [rsp + 050h], r9   ; 4c 89 8c 24 50 00 00 00              
     4 : mov    qword ptr [rsp + 020h], 0h   ; 48 c7 84 24 20 00 00 00 00 00 00 00  
     5 : mov    qword ptr [rsp + 028h], 0h   ; 48 c7 84 24 28 00 00 00 00 00 00 00  
     6 : mov    qword ptr [rsp + 030h], 0h   ; 48 c7 84 24 30 00 00 00 00 00 00 00  
     7 : mov    rax, 002h                    ; 48 c7 c0 02 00 00 00                 
     8 : mov    r9, 001h                     ; 49 c7 c1 01 00 00 00                 
     9 : cmp    rdx, 001h                    ; 48 83 fa 01                          
    10 : cmovg  r9, rax                      ; 4c 0f 4f c8                          
    11 : mov    rax, 004h                    ; 48 c7 c0 04 00 00 00                 
    12 : cmp    rdx, 003h                    ; 48 83 fa 03                          
    13 : cmovg  r9, rax                      ; 4c 0f 4f c8                          
    14 : mov    rax, 008h                    ; 48 c7 c0 08 00 00 00                 
    15 : cmp    rdx, 005h                    ; 48 83 fa 05                          
    16 : mov    r13, r9                      ; 4d 89 cd                             
    17 : cmovg  r13, rax                     ; 4c 0f 4f e8                          
    18 : mov    qword ptr [rsp + 038h], r13  ; 4c 89 ac 24 38 00 00 00              
    19 : mov    rax, 002h                    ; 48 c7 c0 02 00 00 00                 
    20 : mov    r9, 001h                     ; 49 c7 c1 01 00 00 00                 
    21 : cmp    qword ptr [rsp + 050h], 001h ; 48 81 bc 24 50 00 00 00 01 00 00 00  
    22 : cmovg  r9, rax                      ; 4c 0f 4f c8                          
    23 : mov    rax, 004h                    ; 48 c7 c0 04 00 00 00                 
    24 : cmp    qword ptr [rsp + 050h], 003h ; 48 81 bc 24 50 00 00 00 03 00 00 00  
    25 : cmovg  r9, rax                      ; 4c 0f 4f c8                          
    26 : mov    rax, 008h                    ; 48 c7 c0 08 00 00 00                 
    27 : cmp    qword ptr [rsp + 050h], 005h ; 48 81 bc 24 50 00 00 00 05 00 00 00  
    28 : cmovg  r9, rax                      ; 4c 0f 4f c8                          
    29 : mov    qword ptr [rsp + 040h], r9   ; 4c 89 8c 24 40 00 00 00              
    30 :        __loops_label_0:             ;                                      
    31 : mov    r13, qword ptr [rsp + 090h]  ; 4c 8b ac 24 90 00 00 00              
    32 : cmp    qword ptr [rsp + 020h], r13  ; 4c 39 ac 24 20 00 00 00              
    33 : jge    __loops_label_2              ; 0f 8d 89 02 00 00                    
    34 : mov    qword ptr [rsp + 048h], r13  ; 4c 89 ac 24 48 00 00 00              
    35 : cmp    rdx, 0h                      ; 48 83 fa 00                          
    36 : jne    __loops_label_4              ; 0f 85 1a 00 00 00                    
    37 : mov    r13, qword ptr [rsp + 028h]  ; 4c 8b ac 24 28 00 00 00              
    38 : movzx  r14, byte ptr [rcx + r13]    ; 4e 0f b6 34 29                       
    39 : mov    qword ptr [rsp + 048h], r14  ; 4c 89 b4 24 48 00 00 00              
    40 : jmp    __loops_label_23             ; e9 e9 00 00 00                       
    41 :        __loops_label_4:             ;                                      
    42 : cmp    rdx, 001h                    ; 48 83 fa 01                          
    43 : jne    __loops_label_7              ; 0f 85 1a 00 00 00                    
    44 : mov    r13, qword ptr [rsp + 028h]  ; 4c 8b ac 24 28 00 00 00              
    45 : movsx  r14, byte ptr [rcx + r13]    ; 4e 0f be 34 29                       
    46 : mov    qword ptr [rsp + 048h], r14  ; 4c 89 b4 24 48 00 00 00              
    47 : jmp    __loops_label_23             ; e9 c5 00 00 00                       
    48 :        __loops_label_7:             ;                                      
    49 : cmp    rdx, 002h                    ; 48 83 fa 02                          
    50 : jne    __loops_label_10             ; 0f 85 1a 00 00 00                    
    51 : mov    r13, qword ptr [rsp + 028h]  ; 4c 8b ac 24 28 00 00 00              
    52 : movzx  r14, word ptr [rcx + r13]    ; 4e 0f b7 34 29                       
    53 : mov    qword ptr [rsp + 048h], r14  ; 4c 89 b4 24 48 00 00 00              
    54 : jmp    __loops_label_23             ; e9 a1 00 00 00                       
    55 :        __loops_label_10:            ;                                      
    56 : cmp    rdx, 003h                    ; 48 83 fa 03                          
    57 : jne    __loops_label_13             ; 0f 85 1a 00 00 00                    
    58 : mov    r13, qword ptr [rsp + 028h]  ; 4c 8b ac 24 28 00 00 00              
    59 : movsx  r14, word ptr [rcx + r13]    ; 4e 0f bf 34 29                       
    60 : mov    qword ptr [rsp + 048h], r14  ; 4c 89 b4 24 48 00 00 00              
    61 : jmp    __loops_label_23             ; e9 7d 00 00 00                       
    62 :        __loops_label_13:            ;                                      
    63 : cmp    rdx, 004h                    ; 48 83 fa 04                          
    64 : jne    __loops_label_16             ; 0f 85 19 00 00 00                    
    65 : mov    r13, qword ptr [rsp + 028h]  ; 4c 8b ac 24 28 00 00 00              
    66 : mov    r14d, dword ptr [rcx + r13]  ; 46 8b 34 29                          
    67 : mov    qword ptr [rsp + 048h], r14  ; 4c 89 b4 24 48 00 00 00              
    68 : jmp    __loops_label_23             ; e9 5a 00 00 00                       
    69 :        __loops_label_16:            ;                                      
    70 : cmp    rdx, 005h                    ; 48 83 fa 05                          
    71 : jne    __loops_label_19             ; 0f 85 19 00 00 00                    
    72 : mov    r13, qword ptr [rsp + 028h]  ; 4c 8b ac 24 28 00 00 00              
    73 : movsxd r14, dword ptr [rcx + r13]   ; 4e 63 34 29                          
    74 : mov    qword ptr [rsp + 048h], r14  ; 4c 89 b4 24 48 00 00 00              
    75 : jmp    __loops_label_23             ; e9 37 00 00 00                       
    76 :        __loops_label_19:            ;                                      
    77 : cmp    rdx, 006h                    ; 48 83 fa 06                          
    78 : jne    __loops_label_22             ; 0f 85 19 00 00 00                    
    79 : mov    r13, qword ptr [rsp + 028h]  ; 4c 8b ac 24 28 00 00 00              
    80 : mov    r14, qword ptr [rcx + r13]   ; 4e 8b 34 29                          
    81 : mov    qword ptr [rsp + 048h], r14  ; 4c 89 b4 24 48 00 00 00              
    82 : jmp    __loops_label_23             ; e9 14 00 00 00                       
    83 :        __loops_label_22:            ;                                      
    84 : mov    r13, qword ptr [rsp + 028h]  ; 4c 8b ac 24 28 00 00 00              
    85 : mov    r14, qword ptr [rcx + r13]   ; 4e 8b 34 29                          
    86 : mov    qword ptr [rsp + 048h], r14  ; 4c 89 b4 24 48 00 00 00              
    87 :        __loops_label_5:             ;                                      
    88 :        __loops_label_8:             ;                                      
    89 :        __loops_label_11:            ;                                      
    90 :        __loops_label_14:            ;                                      
    91 :        __loops_label_17:            ;                                      
    92 :        __loops_label_20:            ;                                      
    93 :        __loops_label_23:            ;                                      
    94 : cmp    qword ptr [rsp + 050h], 0h   ; 48 81 bc 24 50 00 00 00 00 00 00 00  
    95 : jne    __loops_label_25             ; 0f 85 19 00 00 00                    
    96 : mov    r13, qword ptr [rsp + 030h]  ; 4c 8b ac 24 30 00 00 00              
    97 : mov    r14, qword ptr [rsp + 048h]  ; 4c 8b b4 24 48 00 00 00              
    98 : mov    byte ptr [r8 + r13], r14b    ; 47 88 34 28                          
    99 : jmp    __loops_label_44             ; e9 18 01 00 00                       
   100 :        __loops_label_25:            ;                                      
   101 : cmp    qword ptr [rsp + 050h], 001h ; 48 81 bc 24 50 00 00 00 01 00 00 00  
   102 : jne    __loops_label_28             ; 0f 85 19 00 00 00                    
   103 : mov    r13, qword ptr [rsp + 030h]  ; 4c 8b ac 24 30 00 00 00              
   104 : mov    r14, qword ptr [rsp + 048h]  ; 4c 8b b4 24 48 00 00 00              
   105 : mov    byte ptr [r8 + r13], r14b    ; 47 88 34 28                          
   106 : jmp    __loops_label_44             ; e9 ed 00 00 00                       
   107 :        __loops_label_28:            ;                                      
   108 : cmp    qword ptr [rsp + 050h], 002h ; 48 81 bc 24 50 00 00 00 02 00 00 00  
   109 : jne    __loops_label_31             ; 0f 85 1a 00 00 00                    
   110 : mov    r13, qword ptr [rsp + 030h]  ; 4c 8b ac 24 30 00 00 00              
   111 : mov    r14, qword ptr [rsp + 048h]  ; 4c 8b b4 24 48 00 00 00              
   112 : mov    word ptr [r8 + r13], r14w    ; 66 47 89 34 28                       
   113 : jmp    __loops_label_44             ; e9 c1 00 00 00                       
   114 :        __loops_label_31:            ;                                      
   115 : cmp    qword ptr [rsp + 050h], 003h ; 48 81 bc 24 50 00 00 00 03 00 00 00  
   116 : jne    __loops_label_34             ; 0f 85 1a 00 00 00                    
   117 : mov    r13, qword ptr [rsp + 030h]  ; 4c 8b ac 24 30 00 00 00              
   118 : mov    r14, qword ptr [rsp + 048h]  ; 4c 8b b4 24 48 00 00 00              
   119 : mov    word ptr [r8 + r13], r14w    ; 66 47 89 34 28                       
   120 : jmp    __loops_label_44             ; e9 95 00 00 00                       
   121 :        __loops_label_34:            ;                                      
   122 : cmp    qword ptr [rsp + 050h], 004h ; 48 81 bc 24 50 00 00 00 04 00 00 00  
   123 : jne    __loops_label_37             ; 0f 85 19 00 00 00                    
   124 : mov    r13, qword ptr [rsp + 030h]  ; 4c 8b ac 24 30 00 00 00              
   125 : mov    r14, qword ptr [rsp + 048h]  ; 4c 8b b4 24 48 00 00 00              
   126 : mov    dword ptr [r8 + r13], r14d   ; 47 89 34 28                          
   127 : jmp    __loops_label_44             ; e9 6a 00 00 00                       
   128 :        __loops_label_37:            ;                                      
   129 : cmp    qword ptr [rsp + 050h], 005h ; 48 81 bc 24 50 00 00 00 05 00 00 00  
   130 : jne    __loops_label_40             ; 0f 85 19 00 00 00                    
   131 : mov    r13, qword ptr [rsp + 030h]  ; 4c 8b ac 24 30 00 00 00              
   132 : mov    r14, qword ptr [rsp + 048h]  ; 4c 8b b4 24 48 00 00 00              
   133 : mov    dword ptr [r8 + r13], r14d   ; 47 89 34 28                          
   134 : jmp    __loops_label_44             ; e9 3f 00 00 00                       
   135 :        __loops_label_40:            ;                                      
   136 : cmp    qword ptr [rsp + 050h], 006h ; 48 81 bc 24 50 00 00 00 06 00 00 00  
   137 : jne    __loops_label_43             ; 0f 85 19 00 00 00                    
   138 : mov    r13, qword ptr [rsp + 030h]  ; 4c 8b ac 24 30 00 00 00              
   139 : mov    r14, qword ptr [rsp + 048h]  ; 4c 8b b4 24 48 00 00 00              
   140 : mov    qword ptr [r8 + r13], r14    ; 4f 89 34 28                          
   141 : jmp    __loops_label_44             ; e9 14 00 00 00                       
   142 :        __loops_label_43:            ;                                      
   143 : mov    r13, qword ptr [rsp + 030h]  ; 4c 8b ac 24 30 00 00 00              
   144 : mov    r14, qword ptr [rsp + 048h]  ; 4c 8b b4 24 48 00 00 00              
   145 : mov    qword ptr [r8 + r13], r14    ; 4f 89 34 28                          
   146 :        __loops_label_26:            ;                                      
   147 :        __loops_label_29:            ;                                      
   148 :        __loops_label_32:            ;                                      
   149 :        __loops_label_35:            ;                                      
   150 :        __loops_label_38:            ;                                      
   151 :        __loops_label_41:            ;                                      
   152 :        __loops_label_44:            ;                                      
   153 : mov    r13, qword ptr [rsp + 038h]  ; 4c 8b ac 24 38 00 00 00              
   154 : add    qword ptr [rsp + 028h], r13  ; 4c 01 ac 24 28 00 00 00              
   155 : mov    r13, qword ptr [rsp + 040h]  ; 4c 8b ac 24 40 00 00 00              
   156 : add    qword ptr [rsp + 030h], r13  ; 4c 01 ac 24 30 00 00 00              
   157 : add    qword ptr [rsp + 020h], 001h ; 48 81 84 24 20 00 00 00 01 00 00 00  
   158 : jmp    __loops_label_0              ; e9 61 fd ff ff                       
   159 :        __loops_label_2:             ;                                      
   160 : mov    r13, qword ptr [rsp + 058h]  ; 4c 8b ac 24 58 00 00 00              
   161 : mov    r14, qword ptr [rsp + 060h]  ; 4c 8b b4 24 60 00 00 00              
   162 : add    rsp, 068h                    ; 48 81 c4 68 00 00 00                 
   163 : ret                                 ; c3                                   
