nonnegative_odd(i0, i1)
     0 : sub    rsp, 028h                   ; 48 81 ec 28 00 00 00     
     1 : mov    qword ptr [rsp + 020h], r13 ; 4c 89 ac 24 20 00 00 00  
     2 : xor    r9, r9                      ; 4d 31 c9                 
     3 : mov    r13, 0fffffffffffffffch     ; 49 c7 c5 fc ff ff ff     
     4 : mov    qword ptr [rsp + 010h], r13 ; 4c 89 ac 24 10 00 00 00  
     5 : mov    qword ptr [rsp + 008h], rdx ; 48 89 94 24 08 00 00 00  
     6 : mov    r13, qword ptr [rsp + 008h] ; 4c 8b ac 24 08 00 00 00  
     7 : imul   r13, 004h                   ; 4d 6b ed 04              
     8 : mov    qword ptr [rsp + 008h], r13 ; 4c 89 ac 24 08 00 00 00  
     9 :        __loops_label_0:            ;                          
    10 : cmp    r9, qword ptr [rsp + 008h]  ; 4c 3b 8c 24 08 00 00 00  
    11 : jge    __loops_label_2             ; 0f 8d 5c 00 00 00        
    12 : movsxd r8, dword ptr [rcx + r9]    ; 4e 63 04 09              
    13 : cmp    r8, 0h                      ; 49 83 f8 00              
    14 : jge    __loops_label_4             ; 0f 8d 0c 00 00 00        
    15 : add    r9, 004h                    ; 49 81 c1 04 00 00 00     
    16 : jmp    __loops_label_0             ; e9 d8 ff ff ff           
    17 :        __loops_label_4:            ;                          
    18 : mov    rax, 002h                   ; 48 c7 c0 02 00 00 00     
    19 : mov    qword ptr [rsp + 018h], rax ; 48 89 84 24 18 00 00 00  
    20 : mov    rax, r8                     ; 4c 89 c0                 
    21 : cqo                                ; 48 99                    
    22 : idiv   qword ptr [rsp + 018h]      ; 48 f7 bc 24 18 00 00 00  
    23 : mov    r8, rdx                     ; 49 89 d0                 
    24 : cmp    r8, 0h                      ; 49 83 f8 00              
    25 : je     __loops_label_6             ; 0f 84 0d 00 00 00        
    26 : mov    qword ptr [rsp + 010h], r9  ; 4c 89 8c 24 10 00 00 00  
    27 : jmp    __loops_label_2             ; e9 0c 00 00 00           
    28 :        __loops_label_6:            ;                          
    29 : add    r9, 004h                    ; 49 81 c1 04 00 00 00     
    30 : jmp    __loops_label_0             ; e9 96 ff ff ff           
    31 :        __loops_label_2:            ;                          
    32 : mov    r9, 004h                    ; 49 c7 c1 04 00 00 00     
    33 : mov    rcx, qword ptr [rsp + 010h] ; 48 8b 8c 24 10 00 00 00  
    34 : mov    rax, rcx                    ; 48 89 c8                 
    35 : cqo                                ; 48 99                    
    36 : idiv   r9                          ; 49 f7 f9                 
    37 : mov    rcx, rax                    ; 48 89 c1                 
    38 : mov    rax, rcx                    ; 48 89 c8                 
    39 : mov    r13, qword ptr [rsp + 020h] ; 4c 8b ac 24 20 00 00 00  
    40 : add    rsp, 028h                   ; 48 81 c4 28 00 00 00     
    41 : ret                                ; c3                       
