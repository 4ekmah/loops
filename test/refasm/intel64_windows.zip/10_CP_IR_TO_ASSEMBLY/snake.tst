snake(i0, i1, i2)
     0 : sub     rsp, 02a8h                       ; 48 81 ec a8 02 00 00                 
     1 : mov     qword ptr [rsp + 0290h], r13     ; 4c 89 ac 24 90 02 00 00              
     2 : mov     qword ptr [rsp + 0298h], r14     ; 4c 89 b4 24 98 02 00 00              
     3 : mov     qword ptr [rsp + 02a0h], rbp     ; 48 89 ac 24 a0 02 00 00              
     4 : mov     rbp, rsp                         ; 48 89 e5                             
     5 : add     rbp, 02a0h                       ; 48 81 c5 a0 02 00 00                 
     6 : mov     r9, rdx                          ; 49 89 d1                             
     7 : add     r9, r8                           ; 4d 01 c1                             
     8 : mov     qword ptr [rsp + 0260h], r9      ; 4c 89 8c 24 60 02 00 00              
     9 : sub     qword ptr [rsp + 0260h], 001h    ; 48 81 ac 24 60 02 00 00 01 00 00 00  
    10 : xor     r9, r9                           ; 4d 31 c9                             
    11 : mov     qword ptr [rsp + 0258h], 001h    ; 48 c7 84 24 58 02 00 00 01 00 00 00  
    12 : mov     r13, qword ptr [rsp + 0258h]     ; 4c 8b ac 24 58 02 00 00              
    13 : mov     qword ptr [rsp + 0240h], r13     ; 4c 89 ac 24 40 02 00 00              
    14 : neg     qword ptr [rsp + 0240h]          ; 48 f7 9c 24 40 02 00 00              
    15 : mov     qword ptr [rsp + 0268h], 0h      ; 48 c7 84 24 68 02 00 00 00 00 00 00  
    16 :         __loops_label_0:                 ;                                      
    17 : mov     r13, qword ptr [rsp + 0260h]     ; 4c 8b ac 24 60 02 00 00              
    18 : cmp     qword ptr [rsp + 0268h], r13     ; 4c 39 ac 24 68 02 00 00              
    19 : jge     __loops_label_2                  ; 0f 8d 7e 03 00 00                    
    20 : mov     qword ptr [rsp + 0248h], 0h      ; 48 c7 84 24 48 02 00 00 00 00 00 00  
    21 : mov     qword ptr [rsp + 0250h], 0h      ; 48 c7 84 24 50 02 00 00 00 00 00 00  
    22 : mov     rax, qword ptr [rsp + 0268h]     ; 48 8b 84 24 68 02 00 00              
    23 : and     rax, 001h                        ; 48 25 01 00 00 00                    
    24 : cmp     rax, 0h                          ; 48 83 f8 00                          
    25 : je      __loops_label_4                  ; 0f 84 75 00 00 00                    
    26 : mov     rax, r8                          ; 4c 89 c0                             
    27 : sub     rax, 001h                        ; 48 2d 01 00 00 00                    
    28 : cmp     rax, qword ptr [rsp + 0268h]     ; 48 3b 84 24 68 02 00 00              
    29 : mov     r13, qword ptr [rsp + 0268h]     ; 4c 8b ac 24 68 02 00 00              
    30 : mov     r14, r13                         ; 4d 89 ee                             
    31 : cmovl   r14, rax                         ; 4c 0f 4c f0                          
    32 : mov     qword ptr [rsp + 0248h], r14     ; 4c 89 b4 24 48 02 00 00              
    33 : mov     r13, qword ptr [rsp + 0268h]     ; 4c 8b ac 24 68 02 00 00              
    34 : mov     qword ptr [rsp + 0270h], r13     ; 4c 89 ac 24 70 02 00 00              
    35 : sub     qword ptr [rsp + 0270h], rax     ; 48 29 84 24 70 02 00 00              
    36 : mov     qword ptr [rsp + 0278h], 0h      ; 48 c7 84 24 78 02 00 00 00 00 00 00  
    37 : cmp     qword ptr [rsp + 0268h], rax     ; 48 39 84 24 68 02 00 00              
    38 : mov     r13, qword ptr [rsp + 0278h]     ; 4c 8b ac 24 78 02 00 00              
    39 : mov     r14, r13                         ; 4d 89 ee                             
    40 : cmovg   r14, qword ptr [rsp + 0270h]     ; 4c 0f 4f b4 24 70 02 00 00           
    41 : mov     qword ptr [rsp + 0250h], r14     ; 4c 89 b4 24 50 02 00 00              
    42 : jmp     __loops_label_6                  ; e9 86 00 00 00                       
    43 :         __loops_label_4:                 ;                                      
    44 : mov     qword ptr [rsp + 0280h], rdx     ; 48 89 94 24 80 02 00 00              
    45 : sub     qword ptr [rsp + 0280h], 001h    ; 48 81 ac 24 80 02 00 00 01 00 00 00  
    46 : mov     r13, qword ptr [rsp + 0268h]     ; 4c 8b ac 24 68 02 00 00              
    47 : mov     rax, r13                         ; 4c 89 e8                             
    48 : sub     rax, qword ptr [rsp + 0280h]     ; 48 2b 84 24 80 02 00 00              
    49 : mov     qword ptr [rsp + 0288h], 0h      ; 48 c7 84 24 88 02 00 00 00 00 00 00  
    50 : mov     r13, qword ptr [rsp + 0280h]     ; 4c 8b ac 24 80 02 00 00              
    51 : cmp     qword ptr [rsp + 0268h], r13     ; 4c 39 ac 24 68 02 00 00              
    52 : mov     r13, qword ptr [rsp + 0288h]     ; 4c 8b ac 24 88 02 00 00              
    53 : mov     r14, r13                         ; 4d 89 ee                             
    54 : cmovg   r14, rax                         ; 4c 0f 4f f0                          
    55 : mov     qword ptr [rsp + 0248h], r14     ; 4c 89 b4 24 48 02 00 00              
    56 : mov     r13, qword ptr [rsp + 0268h]     ; 4c 8b ac 24 68 02 00 00              
    57 : cmp     qword ptr [rsp + 0280h], r13     ; 4c 39 ac 24 80 02 00 00              
    58 : mov     r13, qword ptr [rsp + 0268h]     ; 4c 8b ac 24 68 02 00 00              
    59 : mov     r14, r13                         ; 4d 89 ee                             
    60 : cmovl   r14, qword ptr [rsp + 0280h]     ; 4c 0f 4c b4 24 80 02 00 00           
    61 : mov     qword ptr [rsp + 0250h], r14     ; 4c 89 b4 24 50 02 00 00              
    62 :         __loops_label_5:                 ;                                      
    63 :         __loops_label_6:                 ;                                      
    64 : cmp     qword ptr [rsp + 0248h], 0h      ; 48 81 bc 24 48 02 00 00 00 00 00 00  
    65 : jl      __loops_label_8                  ; 0f 8c 20 02 00 00                    
    66 : cmp     qword ptr [rsp + 0248h], r8      ; 4c 39 84 24 48 02 00 00              
    67 : jge     __loops_label_8                  ; 0f 8d 12 02 00 00                    
    68 : cmp     qword ptr [rsp + 0250h], 0h      ; 48 81 bc 24 50 02 00 00 00 00 00 00  
    69 : jl      __loops_label_8                  ; 0f 8c 00 02 00 00                    
    70 : cmp     qword ptr [rsp + 0250h], rdx     ; 48 39 94 24 50 02 00 00              
    71 : jge     __loops_label_8                  ; 0f 8d f2 01 00 00                    
    72 : mov     rax, 07ff7cb19ea70h              ; 48 b8 70 ea 19 cb f7 7f 00 00        
    73 : mov     r13, qword ptr [rsp + 0248h]     ; 4c 8b ac 24 48 02 00 00              
    74 : mov     r14, qword ptr [rsp + 0250h]     ; 4c 8b b4 24 50 02 00 00              
    75 : mov     qword ptr [rsp], rax             ; 48 89 84 24 00 00 00 00              
    76 : mov     qword ptr [rsp + 008h], rcx      ; 48 89 8c 24 08 00 00 00              
    77 : mov     qword ptr [rsp + 010h], rdx      ; 48 89 94 24 10 00 00 00              
    78 : mov     qword ptr [rsp + 018h], r8       ; 4c 89 84 24 18 00 00 00              
    79 : mov     qword ptr [rsp + 020h], r9       ; 4c 89 8c 24 20 00 00 00              
    80 : mov     qword ptr [rsp + 028h], r10      ; 4c 89 94 24 28 00 00 00              
    81 : mov     qword ptr [rsp + 030h], r11      ; 4c 89 9c 24 30 00 00 00              
    82 : vmovdqu ymmword ptr [rsp + 040h], ymm0   ; c5 fe 7f 84 24 40 00 00 00           
    83 : vmovdqu ymmword ptr [rsp + 060h], ymm1   ; c5 fe 7f 8c 24 60 00 00 00           
    84 : vmovdqu ymmword ptr [rsp + 080h], ymm2   ; c5 fe 7f 94 24 80 00 00 00           
    85 : vmovdqu ymmword ptr [rsp + 0a0h], ymm3   ; c5 fe 7f 9c 24 a0 00 00 00           
    86 : vmovdqu ymmword ptr [rsp + 0c0h], ymm5   ; c5 fe 7f ac 24 c0 00 00 00           
    87 : vmovdqu ymmword ptr [rsp + 0e0h], ymm6   ; c5 fe 7f b4 24 e0 00 00 00           
    88 : vmovdqu ymmword ptr [rsp + 0100h], ymm7  ; c5 fe 7f bc 24 00 01 00 00           
    89 : vmovdqu ymmword ptr [rsp + 0120h], ymm8  ; c5 7e 7f 84 24 20 01 00 00           
    90 : vmovdqu ymmword ptr [rsp + 0140h], ymm9  ; c5 7e 7f 8c 24 40 01 00 00           
    91 : vmovdqu ymmword ptr [rsp + 0160h], ymm10 ; c5 7e 7f 94 24 60 01 00 00           
    92 : vmovdqu ymmword ptr [rsp + 0180h], ymm11 ; c5 7e 7f 9c 24 80 01 00 00           
    93 : vmovdqu ymmword ptr [rsp + 01a0h], ymm12 ; c5 7e 7f a4 24 a0 01 00 00           
    94 : vmovdqu ymmword ptr [rsp + 01c0h], ymm13 ; c5 7e 7f ac 24 c0 01 00 00           
    95 : vmovdqu ymmword ptr [rsp + 01e0h], ymm14 ; c5 7e 7f b4 24 e0 01 00 00           
    96 : vmovdqu ymmword ptr [rsp + 0200h], ymm15 ; c5 7e 7f bc 24 00 02 00 00           
    97 : mov     rcx, r13                         ; 4c 89 e9                             
    98 : mov     rdx, r14                         ; 4c 89 f2                             
    99 : sub     rsp, 020h                        ; 48 81 ec 20 00 00 00                 
   100 : call    rax                              ; ff d0                                
   101 : add     rsp, 020h                        ; 48 81 c4 20 00 00 00                 
   102 : mov     rax, qword ptr [rsp]             ; 48 8b 84 24 00 00 00 00              
   103 : mov     rcx, qword ptr [rsp + 008h]      ; 48 8b 8c 24 08 00 00 00              
   104 : mov     rdx, qword ptr [rsp + 010h]      ; 48 8b 94 24 10 00 00 00              
   105 : mov     r8, qword ptr [rsp + 018h]       ; 4c 8b 84 24 18 00 00 00              
   106 : mov     r9, qword ptr [rsp + 020h]       ; 4c 8b 8c 24 20 00 00 00              
   107 : mov     r10, qword ptr [rsp + 028h]      ; 4c 8b 94 24 28 00 00 00              
   108 : mov     r11, qword ptr [rsp + 030h]      ; 4c 8b 9c 24 30 00 00 00              
   109 : vmovdqu ymm0, ymmword ptr [rsp + 040h]   ; c5 fe 6f 84 24 40 00 00 00           
   110 : vmovdqu ymm1, ymmword ptr [rsp + 060h]   ; c5 fe 6f 8c 24 60 00 00 00           
   111 : vmovdqu ymm2, ymmword ptr [rsp + 080h]   ; c5 fe 6f 94 24 80 00 00 00           
   112 : vmovdqu ymm3, ymmword ptr [rsp + 0a0h]   ; c5 fe 6f 9c 24 a0 00 00 00           
   113 : vmovdqu ymm5, ymmword ptr [rsp + 0c0h]   ; c5 fe 6f ac 24 c0 00 00 00           
   114 : vmovdqu ymm6, ymmword ptr [rsp + 0e0h]   ; c5 fe 6f b4 24 e0 00 00 00           
   115 : vmovdqu ymm7, ymmword ptr [rsp + 0100h]  ; c5 fe 6f bc 24 00 01 00 00           
   116 : vmovdqu ymm8, ymmword ptr [rsp + 0120h]  ; c5 7e 6f 84 24 20 01 00 00           
   117 : vmovdqu ymm9, ymmword ptr [rsp + 0140h]  ; c5 7e 6f 8c 24 40 01 00 00           
   118 : vmovdqu ymm10, ymmword ptr [rsp + 0160h] ; c5 7e 6f 94 24 60 01 00 00           
   119 : vmovdqu ymm11, ymmword ptr [rsp + 0180h] ; c5 7e 6f 9c 24 80 01 00 00           
   120 : vmovdqu ymm12, ymmword ptr [rsp + 01a0h] ; c5 7e 6f a4 24 a0 01 00 00           
   121 : vmovdqu ymm13, ymmword ptr [rsp + 01c0h] ; c5 7e 6f ac 24 c0 01 00 00           
   122 : vmovdqu ymm14, ymmword ptr [rsp + 01e0h] ; c5 7e 6f b4 24 e0 01 00 00           
   123 : vmovdqu ymm15, ymmword ptr [rsp + 0200h] ; c5 7e 6f bc 24 00 02 00 00           
   124 : mov     rax, qword ptr [rsp + 0250h]     ; 48 8b 84 24 50 02 00 00              
   125 : imul    rax, r8                          ; 49 0f af c0                          
   126 : add     rax, qword ptr [rsp + 0248h]     ; 48 03 84 24 48 02 00 00              
   127 : mov     byte ptr [rcx + rax], r9b        ; 44 88 0c 01                          
   128 : add     r9, 001h                         ; 49 81 c1 01 00 00 00                 
   129 : mov     r13, qword ptr [rsp + 0258h]     ; 4c 8b ac 24 58 02 00 00              
   130 : add     qword ptr [rsp + 0248h], r13     ; 4c 01 ac 24 48 02 00 00              
   131 : mov     r13, qword ptr [rsp + 0240h]     ; 4c 8b ac 24 40 02 00 00              
   132 : add     qword ptr [rsp + 0250h], r13     ; 4c 01 ac 24 50 02 00 00              
   133 : jmp     __loops_label_6                  ; e9 ce fd ff ff                       
   134 :         __loops_label_8:                 ;                                      
   135 : neg     qword ptr [rsp + 0258h]          ; 48 f7 9c 24 58 02 00 00              
   136 : neg     qword ptr [rsp + 0240h]          ; 48 f7 9c 24 40 02 00 00              
   137 : add     qword ptr [rsp + 0268h], 001h    ; 48 81 84 24 68 02 00 00 01 00 00 00  
   138 : jmp     __loops_label_0                  ; e9 6c fc ff ff                       
   139 :         __loops_label_2:                 ;                                      
   140 : mov     rbp, qword ptr [rsp + 02a0h]     ; 48 8b ac 24 a0 02 00 00              
   141 : mov     r13, qword ptr [rsp + 0290h]     ; 4c 8b ac 24 90 02 00 00              
   142 : mov     r14, qword ptr [rsp + 0298h]     ; 4c 8b b4 24 98 02 00 00              
   143 : add     rsp, 02a8h                       ; 48 81 c4 a8 02 00 00                 
   144 : ret                                      ; c3                                   
