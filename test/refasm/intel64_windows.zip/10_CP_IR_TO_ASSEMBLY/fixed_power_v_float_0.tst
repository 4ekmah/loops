fixed_power_v_float_0(i0, i1, i2)
     0 : sub          rsp, 018h                    ; 48 81 ec 18 00 00 00     
     1 : xor          r9, r9                       ; 4d 31 c9                 
     2 : imul         r8, 004h                     ; 4d 6b c0 04              
     3 : mov          qword ptr [rsp + 008h], r8   ; 4c 89 84 24 08 00 00 00  
     4 :              __loops_label_0:             ;                          
     5 : cmp          r9, qword ptr [rsp + 008h]   ; 4c 3b 8c 24 08 00 00 00  
     6 : jge          __loops_label_2              ; 0f 8d 2a 00 00 00        
     7 : vmovups      ymm0, ymmword ptr [rcx + r9] ; c4 a1 7c 10 04 09        
     8 : mov          rax, 03f800000h              ; 48 c7 c0 00 00 80 3f     
     9 : vpinsrd      xmm0, xmm0, eax, 0h          ; c4 e3 79 22 c0 00        
    10 : vpbroadcastd ymm0, xmm0                   ; c4 e2 7d 58 c0           
    11 : vmovups      ymmword ptr [rdx + r9], ymm0 ; c4 a1 7c 11 04 0a        
    12 : add          r9, 020h                     ; 49 81 c1 20 00 00 00     
    13 : jmp          __loops_label_0              ; e9 c8 ff ff ff           
    14 :              __loops_label_2:             ;                          
    15 : xor          rax, rax                     ; 48 31 c0                 
    16 : add          rsp, 018h                    ; 48 81 c4 18 00 00 00     
    17 : ret                                       ; c3                       
