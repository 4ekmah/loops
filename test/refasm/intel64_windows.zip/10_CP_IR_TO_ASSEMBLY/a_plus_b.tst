a_plus_b(i0, i1)
     0 : add rdx, rcx ; 48 01 ca  
     1 : mov rax, rdx ; 48 89 d0  
     2 : ret          ; c3        
