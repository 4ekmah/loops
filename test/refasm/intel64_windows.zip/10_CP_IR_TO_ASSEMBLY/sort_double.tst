sort_double(i0, i1)
     0 : sub     rsp, 0278h                       ; 48 81 ec 78 02 00 00                 
     1 : mov     qword ptr [rsp + 0268h], r13     ; 4c 89 ac 24 68 02 00 00              
     2 : mov     qword ptr [rsp + 0270h], rbp     ; 48 89 ac 24 70 02 00 00              
     3 : mov     rbp, rsp                         ; 48 89 e5                             
     4 : add     rbp, 0270h                       ; 48 81 c5 70 02 00 00                 
     5 : mov     qword ptr [rsp + 0250h], rdx     ; 48 89 94 24 50 02 00 00              
     6 : shl     qword ptr [rsp + 0250h], 003h    ; 48 c1 a4 24 50 02 00 00 03           
     7 : mov     r13, qword ptr [rsp + 0250h]     ; 4c 8b ac 24 50 02 00 00              
     8 : mov     qword ptr [rsp + 0258h], r13     ; 4c 89 ac 24 58 02 00 00              
     9 : sub     qword ptr [rsp + 0258h], 008h    ; 48 81 ac 24 58 02 00 00 08 00 00 00  
    10 : mov     qword ptr [rsp + 0260h], 0h      ; 48 c7 84 24 60 02 00 00 00 00 00 00  
    11 :         __loops_label_0:                 ;                                      
    12 : mov     r13, qword ptr [rsp + 0258h]     ; 4c 8b ac 24 58 02 00 00              
    13 : cmp     qword ptr [rsp + 0260h], r13     ; 4c 39 ac 24 60 02 00 00              
    14 : jge     __loops_label_2                  ; 0f 8d 76 02 00 00                    
    15 : mov     r13, qword ptr [rsp + 0260h]     ; 4c 8b ac 24 60 02 00 00              
    16 : mov     qword ptr [rsp + 0248h], r13     ; 4c 89 ac 24 48 02 00 00              
    17 : mov     r13, qword ptr [rsp + 0248h]     ; 4c 8b ac 24 48 02 00 00              
    18 : mov     qword ptr [rsp + 0240h], r13     ; 4c 89 ac 24 40 02 00 00              
    19 : add     qword ptr [rsp + 0240h], 008h    ; 48 81 84 24 40 02 00 00 08 00 00 00  
    20 :         __loops_label_3:                 ;                                      
    21 : mov     r13, qword ptr [rsp + 0250h]     ; 4c 8b ac 24 50 02 00 00              
    22 : cmp     qword ptr [rsp + 0240h], r13     ; 4c 39 ac 24 40 02 00 00              
    23 : jge     __loops_label_5                  ; 0f 8d dd 01 00 00                    
    24 : mov     r13, qword ptr [rsp + 0240h]     ; 4c 8b ac 24 40 02 00 00              
    25 : mov     rax, qword ptr [rcx + r13]       ; 4a 8b 04 29                          
    26 : mov     r13, qword ptr [rsp + 0248h]     ; 4c 8b ac 24 48 02 00 00              
    27 : mov     r9, qword ptr [rcx + r13]        ; 4e 8b 0c 29                          
    28 : mov     r8, 07ff7cb1a0ac0h               ; 49 b8 c0 0a 1a cb f7 7f 00 00        
    29 : mov     qword ptr [rsp], rax             ; 48 89 84 24 00 00 00 00              
    30 : mov     qword ptr [rsp + 008h], rcx      ; 48 89 8c 24 08 00 00 00              
    31 : mov     qword ptr [rsp + 010h], rdx      ; 48 89 94 24 10 00 00 00              
    32 : mov     qword ptr [rsp + 018h], r8       ; 4c 89 84 24 18 00 00 00              
    33 : mov     qword ptr [rsp + 020h], r9       ; 4c 89 8c 24 20 00 00 00              
    34 : mov     qword ptr [rsp + 028h], r10      ; 4c 89 94 24 28 00 00 00              
    35 : mov     qword ptr [rsp + 030h], r11      ; 4c 89 9c 24 30 00 00 00              
    36 : vmovdqu ymmword ptr [rsp + 040h], ymm0   ; c5 fe 7f 84 24 40 00 00 00           
    37 : vmovdqu ymmword ptr [rsp + 060h], ymm1   ; c5 fe 7f 8c 24 60 00 00 00           
    38 : vmovdqu ymmword ptr [rsp + 080h], ymm2   ; c5 fe 7f 94 24 80 00 00 00           
    39 : vmovdqu ymmword ptr [rsp + 0a0h], ymm3   ; c5 fe 7f 9c 24 a0 00 00 00           
    40 : vmovdqu ymmword ptr [rsp + 0c0h], ymm5   ; c5 fe 7f ac 24 c0 00 00 00           
    41 : vmovdqu ymmword ptr [rsp + 0e0h], ymm6   ; c5 fe 7f b4 24 e0 00 00 00           
    42 : vmovdqu ymmword ptr [rsp + 0100h], ymm7  ; c5 fe 7f bc 24 00 01 00 00           
    43 : vmovdqu ymmword ptr [rsp + 0120h], ymm8  ; c5 7e 7f 84 24 20 01 00 00           
    44 : vmovdqu ymmword ptr [rsp + 0140h], ymm9  ; c5 7e 7f 8c 24 40 01 00 00           
    45 : vmovdqu ymmword ptr [rsp + 0160h], ymm10 ; c5 7e 7f 94 24 60 01 00 00           
    46 : vmovdqu ymmword ptr [rsp + 0180h], ymm11 ; c5 7e 7f 9c 24 80 01 00 00           
    47 : vmovdqu ymmword ptr [rsp + 01a0h], ymm12 ; c5 7e 7f a4 24 a0 01 00 00           
    48 : vmovdqu ymmword ptr [rsp + 01c0h], ymm13 ; c5 7e 7f ac 24 c0 01 00 00           
    49 : vmovdqu ymmword ptr [rsp + 01e0h], ymm14 ; c5 7e 7f b4 24 e0 01 00 00           
    50 : vmovdqu ymmword ptr [rsp + 0200h], ymm15 ; c5 7e 7f bc 24 00 02 00 00           
    51 : mov     rcx, rax                         ; 48 89 c1                             
    52 : mov     rdx, r9                          ; 4c 89 ca                             
    53 : sub     rsp, 020h                        ; 48 81 ec 20 00 00 00                 
    54 : call    r8                               ; 41 ff d0                             
    55 : add     rsp, 020h                        ; 48 81 c4 20 00 00 00                 
    56 : mov     r8, rax                          ; 49 89 c0                             
    57 : mov     rax, qword ptr [rsp]             ; 48 8b 84 24 00 00 00 00              
    58 : mov     rcx, qword ptr [rsp + 008h]      ; 48 8b 8c 24 08 00 00 00              
    59 : mov     rdx, qword ptr [rsp + 010h]      ; 48 8b 94 24 10 00 00 00              
    60 : mov     r9, qword ptr [rsp + 020h]       ; 4c 8b 8c 24 20 00 00 00              
    61 : mov     r10, qword ptr [rsp + 028h]      ; 4c 8b 94 24 28 00 00 00              
    62 : mov     r11, qword ptr [rsp + 030h]      ; 4c 8b 9c 24 30 00 00 00              
    63 : vmovdqu ymm0, ymmword ptr [rsp + 040h]   ; c5 fe 6f 84 24 40 00 00 00           
    64 : vmovdqu ymm1, ymmword ptr [rsp + 060h]   ; c5 fe 6f 8c 24 60 00 00 00           
    65 : vmovdqu ymm2, ymmword ptr [rsp + 080h]   ; c5 fe 6f 94 24 80 00 00 00           
    66 : vmovdqu ymm3, ymmword ptr [rsp + 0a0h]   ; c5 fe 6f 9c 24 a0 00 00 00           
    67 : vmovdqu ymm5, ymmword ptr [rsp + 0c0h]   ; c5 fe 6f ac 24 c0 00 00 00           
    68 : vmovdqu ymm6, ymmword ptr [rsp + 0e0h]   ; c5 fe 6f b4 24 e0 00 00 00           
    69 : vmovdqu ymm7, ymmword ptr [rsp + 0100h]  ; c5 fe 6f bc 24 00 01 00 00           
    70 : vmovdqu ymm8, ymmword ptr [rsp + 0120h]  ; c5 7e 6f 84 24 20 01 00 00           
    71 : vmovdqu ymm9, ymmword ptr [rsp + 0140h]  ; c5 7e 6f 8c 24 40 01 00 00           
    72 : vmovdqu ymm10, ymmword ptr [rsp + 0160h] ; c5 7e 6f 94 24 60 01 00 00           
    73 : vmovdqu ymm11, ymmword ptr [rsp + 0180h] ; c5 7e 6f 9c 24 80 01 00 00           
    74 : vmovdqu ymm12, ymmword ptr [rsp + 01a0h] ; c5 7e 6f a4 24 a0 01 00 00           
    75 : vmovdqu ymm13, ymmword ptr [rsp + 01c0h] ; c5 7e 6f ac 24 c0 01 00 00           
    76 : vmovdqu ymm14, ymmword ptr [rsp + 01e0h] ; c5 7e 6f b4 24 e0 01 00 00           
    77 : vmovdqu ymm15, ymmword ptr [rsp + 0200h] ; c5 7e 6f bc 24 00 02 00 00           
    78 : cmp     r8, 0h                           ; 49 83 f8 00                          
    79 : je      __loops_label_7                  ; 0f 84 10 00 00 00                    
    80 : mov     r13, qword ptr [rsp + 0240h]     ; 4c 8b ac 24 40 02 00 00              
    81 : mov     qword ptr [rsp + 0248h], r13     ; 4c 89 ac 24 48 02 00 00              
    82 :         __loops_label_7:                 ;                                      
    83 : add     qword ptr [rsp + 0240h], 008h    ; 48 81 84 24 40 02 00 00 08 00 00 00  
    84 : jmp     __loops_label_3                  ; e9 0d fe ff ff                       
    85 :         __loops_label_5:                 ;                                      
    86 : mov     r13, qword ptr [rsp + 0260h]     ; 4c 8b ac 24 60 02 00 00              
    87 : cmp     qword ptr [rsp + 0248h], r13     ; 4c 39 ac 24 48 02 00 00              
    88 : je      __loops_label_9                  ; 0f 84 30 00 00 00                    
    89 : mov     r13, qword ptr [rsp + 0260h]     ; 4c 8b ac 24 60 02 00 00              
    90 : mov     r8, qword ptr [rcx + r13]        ; 4e 8b 04 29                          
    91 : mov     r13, qword ptr [rsp + 0248h]     ; 4c 8b ac 24 48 02 00 00              
    92 : mov     r9, qword ptr [rcx + r13]        ; 4e 8b 0c 29                          
    93 : mov     r13, qword ptr [rsp + 0248h]     ; 4c 8b ac 24 48 02 00 00              
    94 : mov     qword ptr [rcx + r13], r8        ; 4e 89 04 29                          
    95 : mov     r13, qword ptr [rsp + 0260h]     ; 4c 8b ac 24 60 02 00 00              
    96 : mov     qword ptr [rcx + r13], r9        ; 4e 89 0c 29                          
    97 :         __loops_label_9:                 ;                                      
    98 : add     qword ptr [rsp + 0260h], 008h    ; 48 81 84 24 60 02 00 00 08 00 00 00  
    99 : jmp     __loops_label_0                  ; e9 74 fd ff ff                       
   100 :         __loops_label_2:                 ;                                      
   101 : mov     rbp, qword ptr [rsp + 0270h]     ; 48 8b ac 24 70 02 00 00              
   102 : mov     r13, qword ptr [rsp + 0268h]     ; 4c 8b ac 24 68 02 00 00              
   103 : add     rsp, 0278h                       ; 48 81 c4 78 02 00 00                 
   104 : ret                                      ; c3                                   
