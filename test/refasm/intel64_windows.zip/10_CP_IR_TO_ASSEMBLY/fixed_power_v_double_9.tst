fixed_power_v_double_9(i0, i1, i2)
     0 : sub     rsp, 008h                    ; 48 81 ec 08 00 00 00  
     1 : xor     r9, r9                       ; 4d 31 c9              
     2 : imul    r8, 008h                     ; 4d 6b c0 08           
     3 : mov     rax, r8                      ; 4c 89 c0              
     4 :         __loops_label_0:             ;                       
     5 : cmp     r9, rax                      ; 49 39 c1              
     6 : jge     __loops_label_2              ; 0f 8d 28 00 00 00     
     7 : vmovupd ymm0, ymmword ptr [rcx + r9] ; c4 a1 7d 10 04 09     
     8 : vmulpd  ymm1, ymm0, ymm0             ; c5 fd 59 c8           
     9 : vmulpd  ymm1, ymm1, ymm1             ; c5 f5 59 c9           
    10 : vmulpd  ymm1, ymm1, ymm1             ; c5 f5 59 c9           
    11 : vmulpd  ymm0, ymm0, ymm1             ; c5 fd 59 c1           
    12 : vmovupd ymmword ptr [rdx + r9], ymm0 ; c4 a1 7d 11 04 0a     
    13 : add     r9, 020h                     ; 49 81 c1 20 00 00 00  
    14 : jmp     __loops_label_0              ; e9 cf ff ff ff        
    15 :         __loops_label_2:             ;                       
    16 : xor     rax, rax                     ; 48 31 c0              
    17 : add     rsp, 008h                    ; 48 81 c4 08 00 00 00  
    18 : ret                                  ; c3                    
