ten_args_to_sum(i0, i1, i2, i3, i4, i5, i6, i7, i8, i9)
     0 : sub  rsp, 028h                   ; 48 81 ec 28 00 00 00     
     1 : mov  rax, qword ptr [rsp + 050h] ; 48 8b 84 24 50 00 00 00  
     2 : imul rcx, 001h                   ; 48 6b c9 01              
     3 : imul rdx, 002h                   ; 48 6b d2 02              
     4 : add  rdx, rcx                    ; 48 01 ca                 
     5 : imul r8, 003h                    ; 4d 6b c0 03              
     6 : add  r8, rdx                     ; 49 01 d0                 
     7 : imul r9, 004h                    ; 4d 6b c9 04              
     8 : add  r9, r8                      ; 4d 01 c1                 
     9 : imul rax, 005h                   ; 48 6b c0 05              
    10 : add  rax, r9                     ; 4c 01 c8                 
    11 : mov  rcx, qword ptr [rsp + 058h] ; 48 8b 8c 24 58 00 00 00  
    12 : imul rcx, 006h                   ; 48 6b c9 06              
    13 : add  rcx, rax                    ; 48 01 c1                 
    14 : mov  rdx, qword ptr [rsp + 060h] ; 48 8b 94 24 60 00 00 00  
    15 : imul rdx, 007h                   ; 48 6b d2 07              
    16 : add  rdx, rcx                    ; 48 01 ca                 
    17 : mov  rcx, qword ptr [rsp + 068h] ; 48 8b 8c 24 68 00 00 00  
    18 : imul rcx, 008h                   ; 48 6b c9 08              
    19 : add  rcx, rdx                    ; 48 01 d1                 
    20 : mov  rdx, qword ptr [rsp + 070h] ; 48 8b 94 24 70 00 00 00  
    21 : imul rdx, 003h                   ; 48 6b d2 03              
    22 : add  rdx, rcx                    ; 48 01 ca                 
    23 : mov  rcx, qword ptr [rsp + 078h] ; 48 8b 8c 24 78 00 00 00  
    24 : imul rcx, 002h                   ; 48 6b c9 02              
    25 : add  rcx, rdx                    ; 48 01 d1                 
    26 : mov  rax, rcx                    ; 48 89 c8                 
    27 : add  rsp, 028h                   ; 48 81 c4 28 00 00 00     
    28 : ret                              ; c3                       
