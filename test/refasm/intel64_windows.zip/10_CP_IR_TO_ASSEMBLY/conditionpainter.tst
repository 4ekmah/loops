conditionpainter(i0)
     0 : sub   rsp, 038h                           ; 48 81 ec 38 00 00 00                 
     1 : mov   qword ptr [rsp + 028h], r13         ; 4c 89 ac 24 28 00 00 00              
     2 : mov   r13, 0fffffffffffffffbh             ; 49 c7 c5 fb ff ff ff                 
     3 : mov   qword ptr [rsp + 010h], r13         ; 4c 89 ac 24 10 00 00 00              
     4 :       __loops_label_0:                    ;                                      
     5 : cmp   qword ptr [rsp + 010h], 005h        ; 48 81 bc 24 10 00 00 00 05 00 00 00  
     6 : jg    __loops_label_2                     ; 0f 8f e2 02 00 00                    
     7 : mov   rdx, qword ptr [rsp + 010h]         ; 48 8b 94 24 10 00 00 00              
     8 : add   rdx, 005h                           ; 48 81 c2 05 00 00 00                 
     9 : imul  rdx, 00bh                           ; 48 6b d2 0b                          
    10 : mov   qword ptr [rsp + 008h], rdx         ; 48 89 94 24 08 00 00 00              
    11 : mov   r13, qword ptr [rsp + 008h]         ; 4c 8b ac 24 08 00 00 00              
    12 : imul  r13, 008h                           ; 4d 6b ed 08                          
    13 : mov   qword ptr [rsp + 008h], r13         ; 4c 89 ac 24 08 00 00 00              
    14 : mov   r13, 0fffffffffffffffbh             ; 49 c7 c5 fb ff ff ff                 
    15 : mov   qword ptr [rsp], r13                ; 4c 89 ac 24 00 00 00 00              
    16 :       __loops_label_3:                    ;                                      
    17 : cmp   qword ptr [rsp], 005h               ; 48 81 bc 24 00 00 00 00 05 00 00 00  
    18 : jg    __loops_label_5                     ; 0f 8f 81 02 00 00                    
    19 : mov   rax, qword ptr [rsp]                ; 48 8b 84 24 00 00 00 00              
    20 : add   rax, 003h                           ; 48 05 03 00 00 00                    
    21 : xor   r9, r9                              ; 4d 31 c9                             
    22 : cmp   qword ptr [rsp + 010h], rax         ; 48 39 84 24 10 00 00 00              
    23 : setge r9b                                 ; 41 0f 9d c1                          
    24 : xor   rax, rax                            ; 48 31 c0                             
    25 : cmp   qword ptr [rsp + 010h], 004h        ; 48 81 bc 24 10 00 00 00 04 00 00 00  
    26 : setle al                                  ; 0f 9e c0                             
    27 : and   rax, r9                             ; 4c 21 c8                             
    28 : xor   r9, r9                              ; 4d 31 c9                             
    29 : cmp   qword ptr [rsp], 0fffffffffffffffeh ; 48 81 bc 24 00 00 00 00 fe ff ff ff  
    30 : setge r9b                                 ; 41 0f 9d c1                          
    31 : and   r9, rax                             ; 49 21 c1                             
    32 : xor   rax, rax                            ; 48 31 c0                             
    33 : cmp   qword ptr [rsp], 0h                 ; 48 81 bc 24 00 00 00 00 00 00 00 00  
    34 : setle al                                  ; 0f 9e c0                             
    35 : and   rax, r9                             ; 4c 21 c8                             
    36 : mov   r13, qword ptr [rsp]                ; 4c 8b ac 24 00 00 00 00              
    37 : mov   r9, r13                             ; 4d 89 e9                             
    38 : sub   r9, 001h                            ; 49 81 e9 01 00 00 00                 
    39 : xor   r8, r8                              ; 4d 31 c0                             
    40 : cmp   qword ptr [rsp + 010h], r9          ; 4c 39 8c 24 10 00 00 00              
    41 : setle r8b                                 ; 41 0f 9e c0                          
    42 : xor   r9, r9                              ; 4d 31 c9                             
    43 : cmp   qword ptr [rsp], 0h                 ; 48 81 bc 24 00 00 00 00 00 00 00 00  
    44 : setge r9b                                 ; 41 0f 9d c1                          
    45 : and   r9, r8                              ; 4d 21 c1                             
    46 : xor   r8, r8                              ; 4d 31 c0                             
    47 : cmp   qword ptr [rsp + 010h], 0h          ; 48 81 bc 24 10 00 00 00 00 00 00 00  
    48 : setle r8b                                 ; 41 0f 9e c0                          
    49 : and   r8, r9                              ; 4d 21 c8                             
    50 : mov   r9, qword ptr [rsp]                 ; 4c 8b 8c 24 00 00 00 00              
    51 : imul  r9, qword ptr [rsp]                 ; 4c 0f af 8c 24 00 00 00 00           
    52 : mov   rdx, qword ptr [rsp + 010h]         ; 48 8b 94 24 10 00 00 00              
    53 : imul  rdx, qword ptr [rsp + 010h]         ; 48 0f af 94 24 10 00 00 00           
    54 : add   rdx, r9                             ; 4c 01 ca                             
    55 : xor   r9, r9                              ; 4d 31 c9                             
    56 : cmp   rdx, 009h                           ; 48 83 fa 09                          
    57 : setle r9b                                 ; 41 0f 9e c1                          
    58 : and   r9, r8                              ; 4d 21 c1                             
    59 : mov   qword ptr [rsp + 018h], r9          ; 4c 89 8c 24 18 00 00 00              
    60 : or    qword ptr [rsp + 018h], rax         ; 48 09 84 24 18 00 00 00              
    61 : mov   rdx, 002h                           ; 48 c7 c2 02 00 00 00                 
    62 : mov   qword ptr [rsp + 020h], 0h          ; 48 c7 84 24 20 00 00 00 00 00 00 00  
    63 : xor   rax, rax                            ; 48 31 c0                             
    64 : cmp   qword ptr [rsp], 002h               ; 48 81 bc 24 00 00 00 00 02 00 00 00  
    65 : setge al                                  ; 0f 9d c0                             
    66 : xor   r9, r9                              ; 4d 31 c9                             
    67 : cmp   qword ptr [rsp], 004h               ; 48 81 bc 24 00 00 00 00 04 00 00 00  
    68 : setle r9b                                 ; 41 0f 9e c1                          
    69 : and   r9, rax                             ; 49 21 c1                             
    70 : xor   rax, rax                            ; 48 31 c0                             
    71 : cmp   qword ptr [rsp + 010h], 001h        ; 48 81 bc 24 10 00 00 00 01 00 00 00  
    72 : setge al                                  ; 0f 9d c0                             
    73 : xor   r8, r8                              ; 4d 31 c0                             
    74 : cmp   qword ptr [rsp + 010h], 003h        ; 48 81 bc 24 10 00 00 00 03 00 00 00  
    75 : setle r8b                                 ; 41 0f 9e c0                          
    76 : and   r8, rax                             ; 49 21 c0                             
    77 : or    r8, r9                              ; 4d 09 c8                             
    78 : mov   r9, qword ptr [rsp]                 ; 4c 8b 8c 24 00 00 00 00              
    79 : imul  r9, qword ptr [rsp]                 ; 4c 0f af 8c 24 00 00 00 00           
    80 : mov   rax, qword ptr [rsp + 010h]         ; 48 8b 84 24 10 00 00 00              
    81 : imul  rax, qword ptr [rsp + 010h]         ; 48 0f af 84 24 10 00 00 00           
    82 : add   rax, r9                             ; 4c 01 c8                             
    83 : xor   r9, r9                              ; 4d 31 c9                             
    84 : cmp   rax, 010h                           ; 48 83 f8 10                          
    85 : setle r9b                                 ; 41 0f 9e c1                          
    86 : and   r9, r8                              ; 4d 21 c1                             
    87 : cmp   r9, 0h                              ; 49 83 f9 00                          
    88 : mov   r13, qword ptr [rsp + 020h]         ; 4c 8b ac 24 20 00 00 00              
    89 : cmove rdx, r13                            ; 49 0f 44 d5                          
    90 : add   rdx, qword ptr [rsp + 018h]         ; 48 03 94 24 18 00 00 00              
    91 : mov   r8, qword ptr [rsp + 010h]          ; 4c 8b 84 24 10 00 00 00              
    92 : imul  r8, 002h                            ; 4d 6b c0 02                          
    93 : cmp   r8, qword ptr [rsp]                 ; 4c 3b 84 24 00 00 00 00              
    94 : jl    __loops_label_8                     ; 0f 8c 33 00 00 00                    
    95 : mov   r8, qword ptr [rsp]                 ; 4c 8b 84 24 00 00 00 00              
    96 : add   r8, 003h                            ; 49 81 c0 03 00 00 00                 
    97 : neg   r8                                  ; 49 f7 d8                             
    98 : mov   r9, qword ptr [rsp]                 ; 4c 8b 8c 24 00 00 00 00              
    99 : add   r9, 003h                            ; 49 81 c1 03 00 00 00                 
   100 : imul  r9, r8                              ; 4d 0f af c8                          
   101 : cmp   qword ptr [rsp + 010h], r9          ; 4c 39 8c 24 10 00 00 00              
   102 : jle   __loops_label_9                     ; 0f 8e 4d 00 00 00                    
   103 :       __loops_label_8:                    ;                                      
   104 : mov   r8, qword ptr [rsp]                 ; 4c 8b 84 24 00 00 00 00              
   105 : imul  r8, 002h                            ; 4d 6b c0 02                          
   106 : cmp   qword ptr [rsp + 010h], r8          ; 4c 39 84 24 10 00 00 00              
   107 : jg    __loops_label_7                     ; 0f 8f 4c 00 00 00                    
   108 : mov   r8, qword ptr [rsp]                 ; 4c 8b 84 24 00 00 00 00              
   109 : add   r8, 003h                            ; 49 81 c0 03 00 00 00                 
   110 : neg   r8                                  ; 49 f7 d8                             
   111 : mov   r9, qword ptr [rsp]                 ; 4c 8b 8c 24 00 00 00 00              
   112 : add   r9, 003h                            ; 49 81 c1 03 00 00 00                 
   113 : imul  r9, r8                              ; 4d 0f af c8                          
   114 : cmp   qword ptr [rsp + 010h], r9          ; 4c 39 8c 24 10 00 00 00              
   115 : jl    __loops_label_7                     ; 0f 8c 19 00 00 00                    
   116 :       __loops_label_9:                    ;                                      
   117 : cmp   qword ptr [rsp], 0h                 ; 48 81 bc 24 00 00 00 00 00 00 00 00  
   118 : jg    __loops_label_7                     ; 0f 8f 07 00 00 00                    
   119 : add   rdx, 003h                           ; 48 81 c2 03 00 00 00                 
   120 :       __loops_label_7:                    ;                                      
   121 : mov   r8, qword ptr [rsp]                 ; 4c 8b 84 24 00 00 00 00              
   122 : add   r8, 005h                            ; 49 81 c0 05 00 00 00                 
   123 : shl   r8, 003h                            ; 49 c1 e0 03                          
   124 : add   r8, qword ptr [rsp + 008h]          ; 4c 03 84 24 08 00 00 00              
   125 : mov   qword ptr [rcx + r8], rdx           ; 4a 89 14 01                          
   126 : add   qword ptr [rsp], 001h               ; 48 81 84 24 00 00 00 00 01 00 00 00  
   127 : jmp   __loops_label_3                     ; e9 6d fd ff ff                       
   128 :       __loops_label_5:                    ;                                      
   129 : add   qword ptr [rsp + 010h], 001h        ; 48 81 84 24 10 00 00 00 01 00 00 00  
   130 : jmp   __loops_label_0                     ; e9 0c fd ff ff                       
   131 :       __loops_label_2:                    ;                                      
   132 : mov   r13, qword ptr [rsp + 028h]         ; 4c 8b ac 24 28 00 00 00              
   133 : add   rsp, 038h                           ; 48 81 c4 38 00 00 00                 
   134 : ret                                       ; c3                                   
