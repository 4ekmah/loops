area_sum(i0, i1)
     0 : sub     rsp, 0268h                       ; 48 81 ec 68 02 00 00                 
     1 : mov     qword ptr [rsp + 0258h], r13     ; 4c 89 ac 24 58 02 00 00              
     2 : mov     qword ptr [rsp + 0260h], rbp     ; 48 89 ac 24 60 02 00 00              
     3 : mov     rbp, rsp                         ; 48 89 e5                             
     4 : add     rbp, 0260h                       ; 48 81 c5 60 02 00 00                 
     5 : mov     qword ptr [rsp + 0240h], 0h      ; 48 c7 84 24 40 02 00 00 00 00 00 00  
     6 :         __loops_label_0:                 ;                                      
     7 : cmp     rdx, 0h                          ; 48 83 fa 00                          
     8 : jle     __loops_label_2                  ; 0f 8e 79 05 00 00                    
     9 : movsx   r13, byte ptr [rcx]              ; 4c 0f be 29                          
    10 : mov     qword ptr [rsp + 0248h], r13     ; 4c 89 ac 24 48 02 00 00              
    11 : mov     rax, 07ff6eee62210h              ; 48 b8 10 22 e6 ee f6 7f 00 00        
    12 : mov     r8, 07ff6eee62340h               ; 49 b8 40 23 e6 ee f6 7f 00 00        
    13 : mov     r9, 07ff6eee62420h               ; 49 b9 20 24 e6 ee f6 7f 00 00        
    14 : cmp     qword ptr [rsp + 0248h], 001h    ; 48 81 bc 24 48 02 00 00 01 00 00 00  
    15 : cmove   r9, r8                           ; 4d 0f 44 c8                          
    16 : cmp     qword ptr [rsp + 0248h], 0h      ; 48 81 bc 24 48 02 00 00 00 00 00 00  
    17 : mov     r13, r9                          ; 4d 89 cd                             
    18 : cmove   r13, rax                         ; 4c 0f 44 e8                          
    19 : mov     qword ptr [rsp + 0250h], r13     ; 4c 89 ac 24 50 02 00 00              
    20 : mov     r8, 07ff6eee620d0h               ; 49 b8 d0 20 e6 ee f6 7f 00 00        
    21 : mov     rax, 07ff6eee62140h              ; 48 b8 40 21 e6 ee f6 7f 00 00        
    22 : mov     r9, 07ff6eee62180h               ; 49 b9 80 21 e6 ee f6 7f 00 00        
    23 : cmp     qword ptr [rsp + 0248h], 001h    ; 48 81 bc 24 48 02 00 00 01 00 00 00  
    24 : cmove   r9, rax                          ; 4c 0f 44 c8                          
    25 : cmp     qword ptr [rsp + 0248h], 0h      ; 48 81 bc 24 48 02 00 00 00 00 00 00  
    26 : cmove   r9, r8                           ; 4d 0f 44 c8                          
    27 : mov     r13, qword ptr [rsp + 0250h]     ; 4c 8b ac 24 50 02 00 00              
    28 : mov     qword ptr [rsp], rax             ; 48 89 84 24 00 00 00 00              
    29 : mov     qword ptr [rsp + 008h], rcx      ; 48 89 8c 24 08 00 00 00              
    30 : mov     qword ptr [rsp + 010h], rdx      ; 48 89 94 24 10 00 00 00              
    31 : mov     qword ptr [rsp + 018h], r8       ; 4c 89 84 24 18 00 00 00              
    32 : mov     qword ptr [rsp + 020h], r9       ; 4c 89 8c 24 20 00 00 00              
    33 : mov     qword ptr [rsp + 028h], r10      ; 4c 89 94 24 28 00 00 00              
    34 : mov     qword ptr [rsp + 030h], r11      ; 4c 89 9c 24 30 00 00 00              
    35 : vmovdqu ymmword ptr [rsp + 040h], ymm0   ; c5 fe 7f 84 24 40 00 00 00           
    36 : vmovdqu ymmword ptr [rsp + 060h], ymm1   ; c5 fe 7f 8c 24 60 00 00 00           
    37 : vmovdqu ymmword ptr [rsp + 080h], ymm2   ; c5 fe 7f 94 24 80 00 00 00           
    38 : vmovdqu ymmword ptr [rsp + 0a0h], ymm3   ; c5 fe 7f 9c 24 a0 00 00 00           
    39 : vmovdqu ymmword ptr [rsp + 0c0h], ymm5   ; c5 fe 7f ac 24 c0 00 00 00           
    40 : vmovdqu ymmword ptr [rsp + 0e0h], ymm6   ; c5 fe 7f b4 24 e0 00 00 00           
    41 : vmovdqu ymmword ptr [rsp + 0100h], ymm7  ; c5 fe 7f bc 24 00 01 00 00           
    42 : vmovdqu ymmword ptr [rsp + 0120h], ymm8  ; c5 7e 7f 84 24 20 01 00 00           
    43 : vmovdqu ymmword ptr [rsp + 0140h], ymm9  ; c5 7e 7f 8c 24 40 01 00 00           
    44 : vmovdqu ymmword ptr [rsp + 0160h], ymm10 ; c5 7e 7f 94 24 60 01 00 00           
    45 : vmovdqu ymmword ptr [rsp + 0180h], ymm11 ; c5 7e 7f 9c 24 80 01 00 00           
    46 : vmovdqu ymmword ptr [rsp + 01a0h], ymm12 ; c5 7e 7f a4 24 a0 01 00 00           
    47 : vmovdqu ymmword ptr [rsp + 01c0h], ymm13 ; c5 7e 7f ac 24 c0 01 00 00           
    48 : vmovdqu ymmword ptr [rsp + 01e0h], ymm14 ; c5 7e 7f b4 24 e0 01 00 00           
    49 : vmovdqu ymmword ptr [rsp + 0200h], ymm15 ; c5 7e 7f bc 24 00 02 00 00           
    50 : sub     rsp, 020h                        ; 48 81 ec 20 00 00 00                 
    51 : call    r13                              ; 41 ff d5                             
    52 : add     rsp, 020h                        ; 48 81 c4 20 00 00 00                 
    53 : mov     rax, qword ptr [rsp]             ; 48 8b 84 24 00 00 00 00              
    54 : mov     rcx, qword ptr [rsp + 008h]      ; 48 8b 8c 24 08 00 00 00              
    55 : mov     rdx, qword ptr [rsp + 010h]      ; 48 8b 94 24 10 00 00 00              
    56 : mov     r8, qword ptr [rsp + 018h]       ; 4c 8b 84 24 18 00 00 00              
    57 : mov     r9, qword ptr [rsp + 020h]       ; 4c 8b 8c 24 20 00 00 00              
    58 : mov     r10, qword ptr [rsp + 028h]      ; 4c 8b 94 24 28 00 00 00              
    59 : mov     r11, qword ptr [rsp + 030h]      ; 4c 8b 9c 24 30 00 00 00              
    60 : vmovdqu ymm0, ymmword ptr [rsp + 040h]   ; c5 fe 6f 84 24 40 00 00 00           
    61 : vmovdqu ymm1, ymmword ptr [rsp + 060h]   ; c5 fe 6f 8c 24 60 00 00 00           
    62 : vmovdqu ymm2, ymmword ptr [rsp + 080h]   ; c5 fe 6f 94 24 80 00 00 00           
    63 : vmovdqu ymm3, ymmword ptr [rsp + 0a0h]   ; c5 fe 6f 9c 24 a0 00 00 00           
    64 : vmovdqu ymm5, ymmword ptr [rsp + 0c0h]   ; c5 fe 6f ac 24 c0 00 00 00           
    65 : vmovdqu ymm6, ymmword ptr [rsp + 0e0h]   ; c5 fe 6f b4 24 e0 00 00 00           
    66 : vmovdqu ymm7, ymmword ptr [rsp + 0100h]  ; c5 fe 6f bc 24 00 01 00 00           
    67 : vmovdqu ymm8, ymmword ptr [rsp + 0120h]  ; c5 7e 6f 84 24 20 01 00 00           
    68 : vmovdqu ymm9, ymmword ptr [rsp + 0140h]  ; c5 7e 6f 8c 24 40 01 00 00           
    69 : vmovdqu ymm10, ymmword ptr [rsp + 0160h] ; c5 7e 6f 94 24 60 01 00 00           
    70 : vmovdqu ymm11, ymmword ptr [rsp + 0180h] ; c5 7e 6f 9c 24 80 01 00 00           
    71 : vmovdqu ymm12, ymmword ptr [rsp + 01a0h] ; c5 7e 6f a4 24 a0 01 00 00           
    72 : vmovdqu ymm13, ymmword ptr [rsp + 01c0h] ; c5 7e 6f ac 24 c0 01 00 00           
    73 : vmovdqu ymm14, ymmword ptr [rsp + 01e0h] ; c5 7e 6f b4 24 e0 01 00 00           
    74 : vmovdqu ymm15, ymmword ptr [rsp + 0200h] ; c5 7e 6f bc 24 00 02 00 00           
    75 : mov     qword ptr [rsp + 0250h], r13     ; 4c 89 ac 24 50 02 00 00              
    76 : mov     qword ptr [rsp], rax             ; 48 89 84 24 00 00 00 00              
    77 : mov     qword ptr [rsp + 008h], rcx      ; 48 89 8c 24 08 00 00 00              
    78 : mov     qword ptr [rsp + 010h], rdx      ; 48 89 94 24 10 00 00 00              
    79 : mov     qword ptr [rsp + 018h], r8       ; 4c 89 84 24 18 00 00 00              
    80 : mov     qword ptr [rsp + 020h], r9       ; 4c 89 8c 24 20 00 00 00              
    81 : mov     qword ptr [rsp + 028h], r10      ; 4c 89 94 24 28 00 00 00              
    82 : mov     qword ptr [rsp + 030h], r11      ; 4c 89 9c 24 30 00 00 00              
    83 : vmovdqu ymmword ptr [rsp + 040h], ymm0   ; c5 fe 7f 84 24 40 00 00 00           
    84 : vmovdqu ymmword ptr [rsp + 060h], ymm1   ; c5 fe 7f 8c 24 60 00 00 00           
    85 : vmovdqu ymmword ptr [rsp + 080h], ymm2   ; c5 fe 7f 94 24 80 00 00 00           
    86 : vmovdqu ymmword ptr [rsp + 0a0h], ymm3   ; c5 fe 7f 9c 24 a0 00 00 00           
    87 : vmovdqu ymmword ptr [rsp + 0c0h], ymm5   ; c5 fe 7f ac 24 c0 00 00 00           
    88 : vmovdqu ymmword ptr [rsp + 0e0h], ymm6   ; c5 fe 7f b4 24 e0 00 00 00           
    89 : vmovdqu ymmword ptr [rsp + 0100h], ymm7  ; c5 fe 7f bc 24 00 01 00 00           
    90 : vmovdqu ymmword ptr [rsp + 0120h], ymm8  ; c5 7e 7f 84 24 20 01 00 00           
    91 : vmovdqu ymmword ptr [rsp + 0140h], ymm9  ; c5 7e 7f 8c 24 40 01 00 00           
    92 : vmovdqu ymmword ptr [rsp + 0160h], ymm10 ; c5 7e 7f 94 24 60 01 00 00           
    93 : vmovdqu ymmword ptr [rsp + 0180h], ymm11 ; c5 7e 7f 9c 24 80 01 00 00           
    94 : vmovdqu ymmword ptr [rsp + 01a0h], ymm12 ; c5 7e 7f a4 24 a0 01 00 00           
    95 : vmovdqu ymmword ptr [rsp + 01c0h], ymm13 ; c5 7e 7f ac 24 c0 01 00 00           
    96 : vmovdqu ymmword ptr [rsp + 01e0h], ymm14 ; c5 7e 7f b4 24 e0 01 00 00           
    97 : vmovdqu ymmword ptr [rsp + 0200h], ymm15 ; c5 7e 7f bc 24 00 02 00 00           
    98 : sub     rsp, 020h                        ; 48 81 ec 20 00 00 00                 
    99 : call    r9                               ; 41 ff d1                             
   100 : add     rsp, 020h                        ; 48 81 c4 20 00 00 00                 
   101 : mov     r8, rax                          ; 49 89 c0                             
   102 : mov     rax, qword ptr [rsp]             ; 48 8b 84 24 00 00 00 00              
   103 : mov     rcx, qword ptr [rsp + 008h]      ; 48 8b 8c 24 08 00 00 00              
   104 : mov     rdx, qword ptr [rsp + 010h]      ; 48 8b 94 24 10 00 00 00              
   105 : mov     r9, qword ptr [rsp + 020h]       ; 4c 8b 8c 24 20 00 00 00              
   106 : mov     r10, qword ptr [rsp + 028h]      ; 4c 8b 94 24 28 00 00 00              
   107 : mov     r11, qword ptr [rsp + 030h]      ; 4c 8b 9c 24 30 00 00 00              
   108 : vmovdqu ymm0, ymmword ptr [rsp + 040h]   ; c5 fe 6f 84 24 40 00 00 00           
   109 : vmovdqu ymm1, ymmword ptr [rsp + 060h]   ; c5 fe 6f 8c 24 60 00 00 00           
   110 : vmovdqu ymm2, ymmword ptr [rsp + 080h]   ; c5 fe 6f 94 24 80 00 00 00           
   111 : vmovdqu ymm3, ymmword ptr [rsp + 0a0h]   ; c5 fe 6f 9c 24 a0 00 00 00           
   112 : vmovdqu ymm5, ymmword ptr [rsp + 0c0h]   ; c5 fe 6f ac 24 c0 00 00 00           
   113 : vmovdqu ymm6, ymmword ptr [rsp + 0e0h]   ; c5 fe 6f b4 24 e0 00 00 00           
   114 : vmovdqu ymm7, ymmword ptr [rsp + 0100h]  ; c5 fe 6f bc 24 00 01 00 00           
   115 : vmovdqu ymm8, ymmword ptr [rsp + 0120h]  ; c5 7e 6f 84 24 20 01 00 00           
   116 : vmovdqu ymm9, ymmword ptr [rsp + 0140h]  ; c5 7e 6f 8c 24 40 01 00 00           
   117 : vmovdqu ymm10, ymmword ptr [rsp + 0160h] ; c5 7e 6f 94 24 60 01 00 00           
   118 : vmovdqu ymm11, ymmword ptr [rsp + 0180h] ; c5 7e 6f 9c 24 80 01 00 00           
   119 : vmovdqu ymm12, ymmword ptr [rsp + 01a0h] ; c5 7e 6f a4 24 a0 01 00 00           
   120 : vmovdqu ymm13, ymmword ptr [rsp + 01c0h] ; c5 7e 6f ac 24 c0 01 00 00           
   121 : vmovdqu ymm14, ymmword ptr [rsp + 01e0h] ; c5 7e 6f b4 24 e0 01 00 00           
   122 : vmovdqu ymm15, ymmword ptr [rsp + 0200h] ; c5 7e 6f bc 24 00 02 00 00           
   123 : mov     r9, 07ff6eee62080h               ; 49 b9 80 20 e6 ee f6 7f 00 00        
   124 : mov     r13, qword ptr [rsp + 0240h]     ; 4c 8b ac 24 40 02 00 00              
   125 : mov     qword ptr [rsp], rax             ; 48 89 84 24 00 00 00 00              
   126 : mov     qword ptr [rsp + 008h], rcx      ; 48 89 8c 24 08 00 00 00              
   127 : mov     qword ptr [rsp + 010h], rdx      ; 48 89 94 24 10 00 00 00              
   128 : mov     qword ptr [rsp + 018h], r8       ; 4c 89 84 24 18 00 00 00              
   129 : mov     qword ptr [rsp + 020h], r9       ; 4c 89 8c 24 20 00 00 00              
   130 : mov     qword ptr [rsp + 028h], r10      ; 4c 89 94 24 28 00 00 00              
   131 : mov     qword ptr [rsp + 030h], r11      ; 4c 89 9c 24 30 00 00 00              
   132 : vmovdqu ymmword ptr [rsp + 040h], ymm0   ; c5 fe 7f 84 24 40 00 00 00           
   133 : vmovdqu ymmword ptr [rsp + 060h], ymm1   ; c5 fe 7f 8c 24 60 00 00 00           
   134 : vmovdqu ymmword ptr [rsp + 080h], ymm2   ; c5 fe 7f 94 24 80 00 00 00           
   135 : vmovdqu ymmword ptr [rsp + 0a0h], ymm3   ; c5 fe 7f 9c 24 a0 00 00 00           
   136 : vmovdqu ymmword ptr [rsp + 0c0h], ymm5   ; c5 fe 7f ac 24 c0 00 00 00           
   137 : vmovdqu ymmword ptr [rsp + 0e0h], ymm6   ; c5 fe 7f b4 24 e0 00 00 00           
   138 : vmovdqu ymmword ptr [rsp + 0100h], ymm7  ; c5 fe 7f bc 24 00 01 00 00           
   139 : vmovdqu ymmword ptr [rsp + 0120h], ymm8  ; c5 7e 7f 84 24 20 01 00 00           
   140 : vmovdqu ymmword ptr [rsp + 0140h], ymm9  ; c5 7e 7f 8c 24 40 01 00 00           
   141 : vmovdqu ymmword ptr [rsp + 0160h], ymm10 ; c5 7e 7f 94 24 60 01 00 00           
   142 : vmovdqu ymmword ptr [rsp + 0180h], ymm11 ; c5 7e 7f 9c 24 80 01 00 00           
   143 : vmovdqu ymmword ptr [rsp + 01a0h], ymm12 ; c5 7e 7f a4 24 a0 01 00 00           
   144 : vmovdqu ymmword ptr [rsp + 01c0h], ymm13 ; c5 7e 7f ac 24 c0 01 00 00           
   145 : vmovdqu ymmword ptr [rsp + 01e0h], ymm14 ; c5 7e 7f b4 24 e0 01 00 00           
   146 : vmovdqu ymmword ptr [rsp + 0200h], ymm15 ; c5 7e 7f bc 24 00 02 00 00           
   147 : mov     rcx, r13                         ; 4c 89 e9                             
   148 : mov     rdx, r8                          ; 4c 89 c2                             
   149 : sub     rsp, 020h                        ; 48 81 ec 20 00 00 00                 
   150 : call    r9                               ; 41 ff d1                             
   151 : add     rsp, 020h                        ; 48 81 c4 20 00 00 00                 
   152 : mov     r8, rax                          ; 49 89 c0                             
   153 : mov     rax, qword ptr [rsp]             ; 48 8b 84 24 00 00 00 00              
   154 : mov     rcx, qword ptr [rsp + 008h]      ; 48 8b 8c 24 08 00 00 00              
   155 : mov     rdx, qword ptr [rsp + 010h]      ; 48 8b 94 24 10 00 00 00              
   156 : mov     r9, qword ptr [rsp + 020h]       ; 4c 8b 8c 24 20 00 00 00              
   157 : mov     r10, qword ptr [rsp + 028h]      ; 4c 8b 94 24 28 00 00 00              
   158 : mov     r11, qword ptr [rsp + 030h]      ; 4c 8b 9c 24 30 00 00 00              
   159 : vmovdqu ymm0, ymmword ptr [rsp + 040h]   ; c5 fe 6f 84 24 40 00 00 00           
   160 : vmovdqu ymm1, ymmword ptr [rsp + 060h]   ; c5 fe 6f 8c 24 60 00 00 00           
   161 : vmovdqu ymm2, ymmword ptr [rsp + 080h]   ; c5 fe 6f 94 24 80 00 00 00           
   162 : vmovdqu ymm3, ymmword ptr [rsp + 0a0h]   ; c5 fe 6f 9c 24 a0 00 00 00           
   163 : vmovdqu ymm5, ymmword ptr [rsp + 0c0h]   ; c5 fe 6f ac 24 c0 00 00 00           
   164 : vmovdqu ymm6, ymmword ptr [rsp + 0e0h]   ; c5 fe 6f b4 24 e0 00 00 00           
   165 : vmovdqu ymm7, ymmword ptr [rsp + 0100h]  ; c5 fe 6f bc 24 00 01 00 00           
   166 : vmovdqu ymm8, ymmword ptr [rsp + 0120h]  ; c5 7e 6f 84 24 20 01 00 00           
   167 : vmovdqu ymm9, ymmword ptr [rsp + 0140h]  ; c5 7e 6f 8c 24 40 01 00 00           
   168 : vmovdqu ymm10, ymmword ptr [rsp + 0160h] ; c5 7e 6f 94 24 60 01 00 00           
   169 : vmovdqu ymm11, ymmword ptr [rsp + 0180h] ; c5 7e 6f 9c 24 80 01 00 00           
   170 : vmovdqu ymm12, ymmword ptr [rsp + 01a0h] ; c5 7e 6f a4 24 a0 01 00 00           
   171 : vmovdqu ymm13, ymmword ptr [rsp + 01c0h] ; c5 7e 6f ac 24 c0 01 00 00           
   172 : vmovdqu ymm14, ymmword ptr [rsp + 01e0h] ; c5 7e 6f b4 24 e0 01 00 00           
   173 : vmovdqu ymm15, ymmword ptr [rsp + 0200h] ; c5 7e 6f bc 24 00 02 00 00           
   174 : mov     qword ptr [rsp + 0240h], r8      ; 4c 89 84 24 40 02 00 00              
   175 : add     rcx, 038h                        ; 48 81 c1 38 00 00 00                 
   176 : sub     rdx, 001h                        ; 48 81 ea 01 00 00 00                 
   177 : jmp     __loops_label_0                  ; e9 7d fa ff ff                       
   178 :         __loops_label_2:                 ;                                      
   179 : mov     rax, qword ptr [rsp + 0240h]     ; 48 8b 84 24 40 02 00 00              
   180 : mov     rbp, qword ptr [rsp + 0260h]     ; 48 8b ac 24 60 02 00 00              
   181 : mov     r13, qword ptr [rsp + 0258h]     ; 4c 8b ac 24 58 02 00 00              
   182 : add     rsp, 0268h                       ; 48 81 c4 68 02 00 00                 
   183 : ret                                      ; c3                                   
