sibling_loops(i0, i1, i2)
     0 : sub    rsp, 018h                   ; 48 81 ec 18 00 00 00                 
     1 : mov    qword ptr [rsp + 008h], r13 ; 4c 89 ac 24 08 00 00 00              
     2 : xor    r9, r9                      ; 4d 31 c9                             
     3 : mov    qword ptr [rsp], 0h         ; 48 c7 84 24 00 00 00 00 00 00 00 00  
     4 :        __loops_label_0:            ;                                      
     5 : cmp    r9, rdx                     ; 49 39 d1                             
     6 : jge    __loops_label_2             ; 0f 8d 18 00 00 00                    
     7 : movsxd rax, dword ptr [rcx + r9]   ; 4a 63 04 09                          
     8 : add    qword ptr [rsp], rax        ; 48 01 84 24 00 00 00 00              
     9 : add    r9, 004h                    ; 49 81 c1 04 00 00 00                 
    10 : jmp    __loops_label_0             ; e9 df ff ff ff                       
    11 :        __loops_label_2:            ;                                      
    12 : xor    rax, rax                    ; 48 31 c0                             
    13 :        __loops_label_3:            ;                                      
    14 : cmp    r9, 0h                      ; 49 83 f9 00                          
    15 : jle    __loops_label_5             ; 0f 8e 12 00 00 00                    
    16 : add    rax, 001h                   ; 48 05 01 00 00 00                    
    17 : sub    r9, 004h                    ; 49 81 e9 04 00 00 00                 
    18 : jmp    __loops_label_3             ; e9 e4 ff ff ff                       
    19 :        __loops_label_5:            ;                                      
    20 : mov    r13, qword ptr [rsp]        ; 4c 8b ac 24 00 00 00 00              
    21 : mov    dword ptr [r8], r13d        ; 45 89 28                             
    22 : mov    dword ptr [r8 + 004h], eax  ; 41 89 80 04 00 00 00                 
    23 : xor    rax, rax                    ; 48 31 c0                             
    24 : mov    r13, qword ptr [rsp + 008h] ; 4c 8b ac 24 08 00 00 00              
    25 : add    rsp, 018h                   ; 48 81 c4 18 00 00 00                 
    26 : ret                                ; c3                                   
