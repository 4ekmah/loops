fixed_power_v_uint32_t_9(i0, i1, i2)
     0 : sub     rsp, 008h                    ; 48 81 ec 08 00 00 00  
     1 : xor     r9, r9                       ; 4d 31 c9              
     2 : imul    r8, 004h                     ; 4d 6b c0 04           
     3 : mov     rax, r8                      ; 4c 89 c0              
     4 :         __loops_label_0:             ;                       
     5 : cmp     r9, rax                      ; 49 39 c1              
     6 : jge     __loops_label_2              ; 0f 8d 2c 00 00 00     
     7 : vmovdqu ymm0, ymmword ptr [rcx + r9] ; c4 a1 7e 6f 04 09     
     8 : vpmulld ymm1, ymm0, ymm0             ; c4 e2 7d 40 c8        
     9 : vpmulld ymm1, ymm1, ymm1             ; c4 e2 75 40 c9        
    10 : vpmulld ymm1, ymm1, ymm1             ; c4 e2 75 40 c9        
    11 : vpmulld ymm0, ymm0, ymm1             ; c4 e2 7d 40 c1        
    12 : vmovdqu ymmword ptr [rdx + r9], ymm0 ; c4 a1 7e 7f 04 0a     
    13 : add     r9, 020h                     ; 49 81 c1 20 00 00 00  
    14 : jmp     __loops_label_0              ; e9 cb ff ff ff        
    15 :         __loops_label_2:             ;                       
    16 : xor     rax, rax                     ; 48 31 c0              
    17 : add     rsp, 008h                    ; 48 81 c4 08 00 00 00  
    18 : ret                                  ; c3                    
