bresenham(i0, i1, i2, i3, i4, i5, i6)
     0 : sub   rsp, 078h                    ; 48 81 ec 78 00 00 00        
     1 : mov   qword ptr [rsp + 068h], r13  ; 4c 89 ac 24 68 00 00 00     
     2 : mov   qword ptr [rsp + 070h], r14  ; 4c 89 b4 24 70 00 00 00     
     3 : mov   qword ptr [rsp + 060h], r9   ; 4c 89 8c 24 60 00 00 00     
     4 : mov   r13, qword ptr [rsp + 0a0h]  ; 4c 8b ac 24 a0 00 00 00     
     5 : mov   rax, r13                     ; 4c 89 e8                    
     6 : sub   rax, r8                      ; 4c 29 c0                    
     7 : mov   r9, rax                      ; 49 89 c1                    
     8 : neg   r9                           ; 49 f7 d9                    
     9 : mov   r13, r9                      ; 4d 89 cd                    
    10 : cmovs r13, rax                     ; 4c 0f 48 e8                 
    11 : mov   qword ptr [rsp + 020h], r13  ; 4c 89 ac 24 20 00 00 00     
    12 : mov   r13, qword ptr [rsp + 0a0h]  ; 4c 8b ac 24 a0 00 00 00     
    13 : mov   rax, r13                     ; 4c 89 e8                    
    14 : sub   rax, r8                      ; 4c 29 c0                    
    15 : mov   r9, rax                      ; 49 89 c1                    
    16 : sar   rax, 03fh                    ; 48 c1 f8 3f                 
    17 : neg   r9                           ; 49 f7 d9                    
    18 : mov   qword ptr [rsp + 028h], rax  ; 48 89 84 24 28 00 00 00     
    19 : adc   qword ptr [rsp + 028h], rax  ; 48 11 84 24 28 00 00 00     
    20 : mov   r13, qword ptr [rsp + 0a8h]  ; 4c 8b ac 24 a8 00 00 00     
    21 : mov   rax, r13                     ; 4c 89 e8                    
    22 : sub   rax, qword ptr [rsp + 060h]  ; 48 2b 84 24 60 00 00 00     
    23 : mov   r9, rax                      ; 49 89 c1                    
    24 : neg   r9                           ; 49 f7 d9                    
    25 : cmovs r9, rax                      ; 4c 0f 48 c8                 
    26 : mov   qword ptr [rsp + 030h], r9   ; 4c 89 8c 24 30 00 00 00     
    27 : neg   qword ptr [rsp + 030h]       ; 48 f7 9c 24 30 00 00 00     
    28 : mov   r13, qword ptr [rsp + 0a8h]  ; 4c 8b ac 24 a8 00 00 00     
    29 : mov   rax, r13                     ; 4c 89 e8                    
    30 : sub   rax, qword ptr [rsp + 060h]  ; 48 2b 84 24 60 00 00 00     
    31 : mov   r9, rax                      ; 49 89 c1                    
    32 : sar   rax, 03fh                    ; 48 c1 f8 3f                 
    33 : neg   r9                           ; 49 f7 d9                    
    34 : mov   r9, rax                      ; 49 89 c1                    
    35 : adc   r9, rax                      ; 49 11 c1                    
    36 : mov   r13, qword ptr [rsp + 020h]  ; 4c 8b ac 24 20 00 00 00     
    37 : mov   qword ptr [rsp + 040h], r13  ; 4c 89 ac 24 40 00 00 00     
    38 : mov   r13, qword ptr [rsp + 030h]  ; 4c 8b ac 24 30 00 00 00     
    39 : add   qword ptr [rsp + 040h], r13  ; 4c 01 ac 24 40 00 00 00     
    40 : mov   qword ptr [rsp + 038h], r9   ; 4c 89 8c 24 38 00 00 00     
    41 :       __loops_label_0:             ;                             
    42 : cmp   rcx, 0h                      ; 48 83 f9 00                 
    43 : je    __loops_label_2              ; 0f 84 29 01 00 00           
    44 : mov   r13, qword ptr [rsp + 060h]  ; 4c 8b ac 24 60 00 00 00     
    45 : mov   qword ptr [rsp + 048h], r13  ; 4c 89 ac 24 48 00 00 00     
    46 : mov   r13, qword ptr [rsp + 048h]  ; 4c 8b ac 24 48 00 00 00     
    47 : imul  r13, rdx                     ; 4c 0f af ea                 
    48 : mov   qword ptr [rsp + 048h], r13  ; 4c 89 ac 24 48 00 00 00     
    49 : mov   r13, qword ptr [rsp + 048h]  ; 4c 8b ac 24 48 00 00 00     
    50 : mov   qword ptr [rsp + 050h], r13  ; 4c 89 ac 24 50 00 00 00     
    51 : add   qword ptr [rsp + 050h], r8   ; 4c 01 84 24 50 00 00 00     
    52 : mov   r14, qword ptr [rsp + 0b0h]  ; 4c 8b b4 24 b0 00 00 00     
    53 : mov   r13, qword ptr [rsp + 050h]  ; 4c 8b ac 24 50 00 00 00     
    54 : mov   byte ptr [rcx + r13], r14b   ; 46 88 34 29                 
    55 : cmp   r8, qword ptr [rsp + 0a0h]   ; 4c 3b 84 24 a0 00 00 00     
    56 : jne   __loops_label_4              ; 0f 85 1b 00 00 00           
    57 : mov   r13, qword ptr [rsp + 0a8h]  ; 4c 8b ac 24 a8 00 00 00     
    58 : cmp   qword ptr [rsp + 060h], r13  ; 4c 39 ac 24 60 00 00 00     
    59 : jne   __loops_label_4              ; 0f 85 05 00 00 00           
    60 : jmp   __loops_label_2              ; e9 b0 00 00 00              
    61 :       __loops_label_4:             ;                             
    62 : mov   r13, qword ptr [rsp + 040h]  ; 4c 8b ac 24 40 00 00 00     
    63 : mov   qword ptr [rsp + 058h], r13  ; 4c 89 ac 24 58 00 00 00     
    64 : shl   qword ptr [rsp + 058h], 001h ; 48 c1 a4 24 58 00 00 00 01  
    65 : mov   r13, qword ptr [rsp + 030h]  ; 4c 8b ac 24 30 00 00 00     
    66 : cmp   qword ptr [rsp + 058h], r13  ; 4c 39 ac 24 58 00 00 00     
    67 : jl    __loops_label_6              ; 0f 8c 2b 00 00 00           
    68 : cmp   r8, qword ptr [rsp + 0a0h]   ; 4c 3b 84 24 a0 00 00 00     
    69 : jne   __loops_label_8              ; 0f 85 05 00 00 00           
    70 : jmp   __loops_label_2              ; e9 6e 00 00 00              
    71 :       __loops_label_8:             ;                             
    72 : mov   r13, qword ptr [rsp + 030h]  ; 4c 8b ac 24 30 00 00 00     
    73 : add   qword ptr [rsp + 040h], r13  ; 4c 01 ac 24 40 00 00 00     
    74 : add   r8, qword ptr [rsp + 028h]   ; 4c 03 84 24 28 00 00 00     
    75 :       __loops_label_6:             ;                             
    76 : mov   r13, qword ptr [rsp + 020h]  ; 4c 8b ac 24 20 00 00 00     
    77 : cmp   qword ptr [rsp + 058h], r13  ; 4c 39 ac 24 58 00 00 00     
    78 : jg    __loops_label_10             ; 0f 8f 3b 00 00 00           
    79 : mov   r13, qword ptr [rsp + 0a8h]  ; 4c 8b ac 24 a8 00 00 00     
    80 : cmp   qword ptr [rsp + 060h], r13  ; 4c 39 ac 24 60 00 00 00     
    81 : jne   __loops_label_12             ; 0f 85 05 00 00 00           
    82 : jmp   __loops_label_2              ; e9 25 00 00 00              
    83 :       __loops_label_12:            ;                             
    84 : mov   r13, qword ptr [rsp + 020h]  ; 4c 8b ac 24 20 00 00 00     
    85 : add   qword ptr [rsp + 040h], r13  ; 4c 01 ac 24 40 00 00 00     
    86 : mov   r13, qword ptr [rsp + 038h]  ; 4c 8b ac 24 38 00 00 00     
    87 : add   qword ptr [rsp + 060h], r13  ; 4c 01 ac 24 60 00 00 00     
    88 :       __loops_label_10:            ;                             
    89 : jmp   __loops_label_0              ; e9 cd fe ff ff              
    90 :       __loops_label_2:             ;                             
    91 : mov   r13, qword ptr [rsp + 068h]  ; 4c 8b ac 24 68 00 00 00     
    92 : mov   r14, qword ptr [rsp + 070h]  ; 4c 8b b4 24 70 00 00 00     
    93 : add   rsp, 078h                    ; 48 81 c4 78 00 00 00        
    94 : ret                                ; c3                          
