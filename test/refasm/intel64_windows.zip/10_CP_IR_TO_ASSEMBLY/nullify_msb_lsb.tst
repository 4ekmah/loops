nullify_msb_lsb(i0, i1, i2)
     0 : mov r9, rcx              ; 49 89 c9              
     1 : shr r9, 001h             ; 49 c1 e9 01           
     2 : or  r9, rcx              ; 49 09 c9              
     3 : mov rax, r9              ; 4c 89 c8              
     4 : shr rax, 002h            ; 48 c1 e8 02           
     5 : or  rax, r9              ; 4c 09 c8              
     6 : mov r9, rax              ; 49 89 c1              
     7 : shr r9, 004h             ; 49 c1 e9 04           
     8 : or  r9, rax              ; 49 09 c1              
     9 : mov rax, r9              ; 4c 89 c8              
    10 : shr rax, 008h            ; 48 c1 e8 08           
    11 : or  rax, r9              ; 4c 09 c8              
    12 : mov r9, rax              ; 49 89 c1              
    13 : shr r9, 010h             ; 49 c1 e9 10           
    14 : or  r9, rax              ; 49 09 c1              
    15 : mov rax, r9              ; 4c 89 c8              
    16 : shr rax, 020h            ; 48 c1 e8 20           
    17 : or  rax, r9              ; 4c 09 c8              
    18 : add rax, 001h            ; 48 05 01 00 00 00     
    19 : shr rax, 001h            ; 48 c1 e8 01           
    20 : xor rax, rcx             ; 48 31 c8              
    21 : mov qword ptr [r8], rax  ; 49 89 00              
    22 : mov r8, rcx              ; 49 89 c8              
    23 : sub r8, 001h             ; 49 81 e8 01 00 00 00  
    24 : not r8                   ; 49 f7 d0              
    25 : and r8, rcx              ; 49 21 c8              
    26 : xor rcx, r8              ; 4c 31 c1              
    27 : mov qword ptr [rdx], rcx ; 48 89 0a              
    28 : ret                      ; c3                    
