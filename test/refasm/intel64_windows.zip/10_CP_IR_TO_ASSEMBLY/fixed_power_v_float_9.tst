fixed_power_v_float_9(i0, i1, i2)
     0 : sub     rsp, 028h                    ; 48 81 ec 28 00 00 00  
     1 : xor     r9, r9                       ; 4d 31 c9              
     2 : imul    r8, 004h                     ; 4d 6b c0 04           
     3 : mov     rax, r8                      ; 4c 89 c0              
     4 :         __loops_label_0:             ;                       
     5 : cmp     r9, rax                      ; 49 39 c1              
     6 : jge     __loops_label_2              ; 0f 8d 28 00 00 00     
     7 : vmovups ymm0, ymmword ptr [rcx + r9] ; c4 a1 7c 10 04 09     
     8 : vmulps  ymm1, ymm0, ymm0             ; c5 fc 59 c8           
     9 : vmulps  ymm1, ymm1, ymm1             ; c5 f4 59 c9           
    10 : vmulps  ymm1, ymm1, ymm1             ; c5 f4 59 c9           
    11 : vmulps  ymm0, ymm0, ymm1             ; c5 fc 59 c1           
    12 : vmovups ymmword ptr [rdx + r9], ymm0 ; c4 a1 7c 11 04 0a     
    13 : add     r9, 020h                     ; 49 81 c1 20 00 00 00  
    14 : jmp     __loops_label_0              ; e9 cf ff ff ff        
    15 :         __loops_label_2:             ;                       
    16 : xor     rax, rax                     ; 48 31 c0              
    17 : add     rsp, 028h                    ; 48 81 c4 28 00 00 00  
    18 : ret                                  ; c3                    
