fixed_power_9(i0)
     0 : mov  rdx, rcx ; 48 89 ca     
     1 : imul rdx, rcx ; 48 0f af d1  
     2 : mov  r8, rdx  ; 49 89 d0     
     3 : imul r8, rdx  ; 4c 0f af c2  
     4 : mov  rdx, r8  ; 4c 89 c2     
     5 : imul rdx, r8  ; 49 0f af d0  
     6 : imul rdx, rcx ; 48 0f af d1  
     7 : mov  rax, rdx ; 48 89 d0     
     8 : ret           ; c3           
