min_max_scalar(i0, i1, i2, i3)
     0 : sub    rsp, 048h                    ; 48 81 ec 48 00 00 00                 
     1 : mov    qword ptr [rsp + 040h], r13  ; 4c 89 ac 24 40 00 00 00              
     2 : mov    qword ptr [rsp + 030h], 0h   ; 48 c7 84 24 30 00 00 00 00 00 00 00  
     3 : mov    qword ptr [rsp + 008h], 0h   ; 48 c7 84 24 08 00 00 00 00 00 00 00  
     4 : mov    qword ptr [rsp + 010h], 0h   ; 48 c7 84 24 10 00 00 00 00 00 00 00  
     5 : movsxd r13, dword ptr [rcx]         ; 4c 63 29                             
     6 : mov    qword ptr [rsp + 018h], r13  ; 4c 89 ac 24 18 00 00 00              
     7 : mov    r13, qword ptr [rsp + 018h]  ; 4c 8b ac 24 18 00 00 00              
     8 : mov    qword ptr [rsp + 020h], r13  ; 4c 89 ac 24 20 00 00 00              
     9 : imul   rdx, 004h                    ; 48 6b d2 04                          
    10 : mov    qword ptr [rsp + 028h], rdx  ; 48 89 94 24 28 00 00 00              
    11 :        __loops_label_0:             ;                                      
    12 : mov    r13, qword ptr [rsp + 028h]  ; 4c 8b ac 24 28 00 00 00              
    13 : cmp    qword ptr [rsp + 030h], r13  ; 4c 39 ac 24 30 00 00 00              
    14 : jge    __loops_label_2              ; 0f 8d 69 00 00 00                    
    15 : mov    r13, qword ptr [rsp + 030h]  ; 4c 8b ac 24 30 00 00 00              
    16 : movsxd rax, dword ptr [rcx + r13]   ; 4a 63 04 29                          
    17 : cmp    rax, qword ptr [rsp + 018h]  ; 48 3b 84 24 18 00 00 00              
    18 : jge    __loops_label_4              ; 0f 8d 18 00 00 00                    
    19 : mov    qword ptr [rsp + 018h], rax  ; 48 89 84 24 18 00 00 00              
    20 : mov    r13, qword ptr [rsp + 030h]  ; 4c 8b ac 24 30 00 00 00              
    21 : mov    qword ptr [rsp + 008h], r13  ; 4c 89 ac 24 08 00 00 00              
    22 :        __loops_label_4:             ;                                      
    23 : cmp    rax, qword ptr [rsp + 020h]  ; 48 3b 84 24 20 00 00 00              
    24 : jle    __loops_label_6              ; 0f 8e 18 00 00 00                    
    25 : mov    qword ptr [rsp + 020h], rax  ; 48 89 84 24 20 00 00 00              
    26 : mov    r13, qword ptr [rsp + 030h]  ; 4c 8b ac 24 30 00 00 00              
    27 : mov    qword ptr [rsp + 010h], r13  ; 4c 89 ac 24 10 00 00 00              
    28 :        __loops_label_6:             ;                                      
    29 : add    qword ptr [rsp + 030h], 004h ; 48 81 84 24 30 00 00 00 04 00 00 00  
    30 : jmp    __loops_label_0              ; e9 81 ff ff ff                       
    31 :        __loops_label_2:             ;                                      
    32 : mov    qword ptr [rsp + 038h], 004h ; 48 c7 84 24 38 00 00 00 04 00 00 00  
    33 : mov    rcx, qword ptr [rsp + 008h]  ; 48 8b 8c 24 08 00 00 00              
    34 : mov    rax, rcx                     ; 48 89 c8                             
    35 : cqo                                 ; 48 99                                
    36 : idiv   qword ptr [rsp + 038h]       ; 48 f7 bc 24 38 00 00 00              
    37 : mov    rcx, rax                     ; 48 89 c1                             
    38 : mov    rax, qword ptr [rsp + 010h]  ; 48 8b 84 24 10 00 00 00              
    39 : cqo                                 ; 48 99                                
    40 : idiv   qword ptr [rsp + 038h]       ; 48 f7 bc 24 38 00 00 00              
    41 : mov    dword ptr [r8], ecx          ; 41 89 08                             
    42 : mov    dword ptr [r9], eax          ; 41 89 01                             
    43 : xor    rax, rax                     ; 48 31 c0                             
    44 : mov    r13, qword ptr [rsp + 040h]  ; 4c 8b ac 24 40 00 00 00              
    45 : add    rsp, 048h                    ; 48 81 c4 48 00 00 00                 
    46 : ret                                 ; c3                                   
