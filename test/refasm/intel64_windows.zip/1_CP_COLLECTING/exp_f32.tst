exp_f32(i0, i1, i2)
     0 : mov                    v0, -1028603739    
     1 : mov                    v1, 1118879909     
     2 : mov                    v2, 1056964608     
     3 : mov                    v3, 1065353216     
     4 : mov                    v4, 1069066811     
     5 : mov                    v5, -1087275008    
     6 : mov                    v6, 962494595      
     7 : mov                    v7, 961571175      
     8 : mov                    v8, 985088974      
     9 : mov                    v9, 1007192328     
    10 : mov                    v10, 1026206145    
    11 : mov                    v11, 1042983594    
    12 : mov                    v12, 1056964608    
    13 : mov                    v13, 127           
    14 : mov                    i3, 0              
    15 : annotation:whilecstart 0                  
    16 : cmp                    i2, 0              
    17 : jmp_le                 __loops_label_2    
    18 : annotation:whilecend                      
    19 : vld.fp32               v14, i1, i3        
    20 : min.fp32               v21, v14, v1       
    21 : max.fp32               v20, v21, v0       
    22 : fma.fp32               v24, v2, v20, v4   
    23 : floor.fp32_i32         v23, v24           
    24 : cast.i32_fp32          v22, v23           
    25 : fma.fp32               v19, v20, v22, v5  
    26 : fma.fp32               v18, v19, v22, v6  
    27 : fma.fp32               v29, v8, v18, v7   
    28 : fma.fp32               v28, v9, v29, v18  
    29 : fma.fp32               v27, v10, v28, v18 
    30 : fma.fp32               v26, v11, v27, v18 
    31 : fma.fp32               v25, v12, v26, v18 
    32 : mul.fp32               v30, v18, v18      
    33 : fma.fp32               v17, v18, v25, v30 
    34 : add.fp32               v16, v17, v3       
    35 : add.i32                v32, v23, v13      
    36 : sal.i32                v31, v32, 23       
    37 : mul.fp32               v15, v16, v31      
    38 : vst.fp32               i0, i3, v15        
    39 : add                    i3, i3, 32         
    40 : sub                    i2, i2, 8          
    41 : annotation:endwhile    0, 2               
    42 : ret                                       
