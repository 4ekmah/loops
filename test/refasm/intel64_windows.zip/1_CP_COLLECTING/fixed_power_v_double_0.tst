fixed_power_v_double_0(i0, i1, i2)
     0 : mov                    i3, 0           
     1 : mul                    i2, i2, 8       
     2 : annotation:whilecstart 0               
     3 : cmp                    i3, i2          
     4 : jmp_ge                 __loops_label_2 
     5 : annotation:whilecend                   
     6 : vld.fp64               v0, i0, i3      
     7 : mov                    v1, 0           
     8 : vst.fp64               i1, i3, v1      
     9 : add                    i3, i3, 32      
    10 : annotation:endwhile    0, 2            
    11 : mov                    iR, 0           
    12 : ret                                    
