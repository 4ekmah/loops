nullify_msb_lsb_v(i0, i1, i2, i3)
     0 : mov                    i4, 0           
     1 : mul                    i3, i3, 4       
     2 : mov                    v0, 1           
     3 : annotation:whilecstart 0               
     4 : cmp                    i4, i3          
     5 : jmp_ge                 __loops_label_2 
     6 : annotation:whilecend                   
     7 : vld.u32                v1, i0, i4      
     8 : shr.u32                v3, v1, 1       
     9 : or                     v2, v1, v3      
    10 : shr.u32                v4, v2, 2       
    11 : or                     v2, v2, v4      
    12 : shr.u32                v5, v2, 4       
    13 : or                     v2, v2, v5      
    14 : shr.u32                v6, v2, 8       
    15 : or                     v2, v2, v6      
    16 : shr.u32                v7, v2, 16      
    17 : or                     v2, v2, v7      
    18 : add.u32                v2, v2, v0      
    19 : shr.u32                v2, v2, 1       
    20 : xor                    v2, v2, v1      
    21 : vst.u32                i1, i4, v2      
    22 : sub.u32                v10, v1, v0     
    23 : not                    v9, v10         
    24 : and                    v8, v1, v9      
    25 : xor                    v8, v8, v1      
    26 : vst.u32                i2, i4, v8      
    27 : add                    i4, i4, 32      
    28 : annotation:endwhile    0, 2            
    29 : ret                                    
