min_max_scalar(i0, i1, i2, i3)
     0 : mov                    i4, 0           
     1 : mov                    i5, 0           
     2 : mov                    i6, 0           
     3 : load.i32               i7, i0          
     4 : mov                    i8, i7          
     5 : mul                    i1, i1, 4       
     6 : annotation:whilecstart 0               
     7 : cmp                    i4, i1          
     8 : jmp_ge                 __loops_label_2 
     9 : annotation:whilecend                   
    10 : load.i32               i9, i0, i4      
    11 : annotation:ifcstart                    
    12 : cmp                    i9, i7          
    13 : jmp_ge                 __loops_label_4 
    14 : annotation:ifcend                      
    15 : mov                    i7, i9          
    16 : mov                    i5, i4          
    17 : annotation:endif       4               
    18 : annotation:ifcstart                    
    19 : cmp                    i9, i8          
    20 : jmp_le                 __loops_label_6 
    21 : annotation:ifcend                      
    22 : mov                    i8, i9          
    23 : mov                    i6, i4          
    24 : annotation:endif       6               
    25 : add                    i4, i4, 4       
    26 : annotation:endwhile    0, 2            
    27 : mov                    i10, 4          
    28 : div                    i5, i5, i10     
    29 : div                    i6, i6, i10     
    30 : store.i32              i2, i5          
    31 : store.i32              i3, i6          
    32 : mov                    iR, 0           
    33 : ret                                    
