fixed_power_9(i0)
     0 : mul i4, i0, i0 
     1 : mul i3, i4, i4 
     2 : mul i2, i3, i3 
     3 : mul i1, i0, i2 
     4 : mov iR, i1     
     5 : ret            
