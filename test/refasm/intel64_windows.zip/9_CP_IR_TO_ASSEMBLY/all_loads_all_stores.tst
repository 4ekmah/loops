all_loads_all_stores(i0, i1, i2, i3, i4)
     0 : sub    rsp, 038h                    ; 48 81 ec 38 00 00 00                 
     1 : mov    qword ptr [rsp + 018h], r9   ; 4c 89 8c 24 18 00 00 00              
     2 : mov    qword ptr [rsp + 028h], r13  ; 4c 89 ac 24 28 00 00 00              
     3 : mov    qword ptr [rsp], 0h          ; 48 c7 84 24 00 00 00 00 00 00 00 00  
     4 : mov    qword ptr [rsp + 008h], 0h   ; 48 c7 84 24 08 00 00 00 00 00 00 00  
     5 : mov    qword ptr [rsp + 010h], 0h   ; 48 c7 84 24 10 00 00 00 00 00 00 00  
     6 : mov    rax, 002h                    ; 48 c7 c0 02 00 00 00                 
     7 : mov    r9, 001h                     ; 49 c7 c1 01 00 00 00                 
     8 : cmp    rdx, 001h                    ; 48 83 fa 01                          
     9 : cmovg  r9, rax                      ; 4c 0f 4f c8                          
    10 : mov    rax, 004h                    ; 48 c7 c0 04 00 00 00                 
    11 : cmp    rdx, 003h                    ; 48 83 fa 03                          
    12 : cmovg  r9, rax                      ; 4c 0f 4f c8                          
    13 : mov    rax, 008h                    ; 48 c7 c0 08 00 00 00                 
    14 : cmp    rdx, 005h                    ; 48 83 fa 05                          
    15 : mov    r13, r9                      ; 4d 89 cd                             
    16 : cmovg  r13, rax                     ; 4c 0f 4f e8                          
    17 : mov    qword ptr [rsp + 020h], r13  ; 4c 89 ac 24 20 00 00 00              
    18 : mov    rax, 002h                    ; 48 c7 c0 02 00 00 00                 
    19 : mov    r9, 001h                     ; 49 c7 c1 01 00 00 00                 
    20 : cmp    qword ptr [rsp + 018h], 001h ; 48 81 bc 24 18 00 00 00 01 00 00 00  
    21 : cmovg  r9, rax                      ; 4c 0f 4f c8                          
    22 : mov    rax, 004h                    ; 48 c7 c0 04 00 00 00                 
    23 : cmp    qword ptr [rsp + 018h], 003h ; 48 81 bc 24 18 00 00 00 03 00 00 00  
    24 : cmovg  r9, rax                      ; 4c 0f 4f c8                          
    25 : mov    rax, 008h                    ; 48 c7 c0 08 00 00 00                 
    26 : cmp    qword ptr [rsp + 018h], 005h ; 48 81 bc 24 18 00 00 00 05 00 00 00  
    27 : cmovg  r9, rax                      ; 4c 0f 4f c8                          
    28 :        __loops_label_0:             ;                                      
    29 : mov    r13, qword ptr [rsp + 060h]  ; 4c 8b ac 24 60 00 00 00              
    30 : cmp    qword ptr [rsp], r13         ; 4c 39 ac 24 00 00 00 00              
    31 : jge    __loops_label_2              ; 0f 8d f9 01 00 00                    
    32 : cmp    rdx, 0h                      ; 48 83 fa 00                          
    33 : jne    __loops_label_4              ; 0f 85 12 00 00 00                    
    34 : mov    r13, qword ptr [rsp + 008h]  ; 4c 8b ac 24 08 00 00 00              
    35 : movzx  rax, byte ptr [rcx + r13]    ; 4a 0f b6 04 29                       
    36 : jmp    __loops_label_23             ; e9 b1 00 00 00                       
    37 :        __loops_label_4:             ;                                      
    38 : cmp    rdx, 001h                    ; 48 83 fa 01                          
    39 : jne    __loops_label_7              ; 0f 85 12 00 00 00                    
    40 : mov    r13, qword ptr [rsp + 008h]  ; 4c 8b ac 24 08 00 00 00              
    41 : movsx  rax, byte ptr [rcx + r13]    ; 4a 0f be 04 29                       
    42 : jmp    __loops_label_23             ; e9 95 00 00 00                       
    43 :        __loops_label_7:             ;                                      
    44 : cmp    rdx, 002h                    ; 48 83 fa 02                          
    45 : jne    __loops_label_10             ; 0f 85 12 00 00 00                    
    46 : mov    r13, qword ptr [rsp + 008h]  ; 4c 8b ac 24 08 00 00 00              
    47 : movzx  rax, word ptr [rcx + r13]    ; 4a 0f b7 04 29                       
    48 : jmp    __loops_label_23             ; e9 79 00 00 00                       
    49 :        __loops_label_10:            ;                                      
    50 : cmp    rdx, 003h                    ; 48 83 fa 03                          
    51 : jne    __loops_label_13             ; 0f 85 12 00 00 00                    
    52 : mov    r13, qword ptr [rsp + 008h]  ; 4c 8b ac 24 08 00 00 00              
    53 : movsx  rax, word ptr [rcx + r13]    ; 4a 0f bf 04 29                       
    54 : jmp    __loops_label_23             ; e9 5d 00 00 00                       
    55 :        __loops_label_13:            ;                                      
    56 : cmp    rdx, 004h                    ; 48 83 fa 04                          
    57 : jne    __loops_label_16             ; 0f 85 11 00 00 00                    
    58 : mov    r13, qword ptr [rsp + 008h]  ; 4c 8b ac 24 08 00 00 00              
    59 : mov    eax, dword ptr [rcx + r13]   ; 42 8b 04 29                          
    60 : jmp    __loops_label_23             ; e9 42 00 00 00                       
    61 :        __loops_label_16:            ;                                      
    62 : cmp    rdx, 005h                    ; 48 83 fa 05                          
    63 : jne    __loops_label_19             ; 0f 85 11 00 00 00                    
    64 : mov    r13, qword ptr [rsp + 008h]  ; 4c 8b ac 24 08 00 00 00              
    65 : movsxd rax, dword ptr [rcx + r13]   ; 4a 63 04 29                          
    66 : jmp    __loops_label_23             ; e9 27 00 00 00                       
    67 :        __loops_label_19:            ;                                      
    68 : cmp    rdx, 006h                    ; 48 83 fa 06                          
    69 : jne    __loops_label_22             ; 0f 85 11 00 00 00                    
    70 : mov    r13, qword ptr [rsp + 008h]  ; 4c 8b ac 24 08 00 00 00              
    71 : mov    rax, qword ptr [rcx + r13]   ; 4a 8b 04 29                          
    72 : jmp    __loops_label_23             ; e9 0c 00 00 00                       
    73 :        __loops_label_22:            ;                                      
    74 : mov    r13, qword ptr [rsp + 008h]  ; 4c 8b ac 24 08 00 00 00              
    75 : mov    rax, qword ptr [rcx + r13]   ; 4a 8b 04 29                          
    76 :        __loops_label_5:             ;                                      
    77 :        __loops_label_8:             ;                                      
    78 :        __loops_label_11:            ;                                      
    79 :        __loops_label_14:            ;                                      
    80 :        __loops_label_17:            ;                                      
    81 :        __loops_label_20:            ;                                      
    82 :        __loops_label_23:            ;                                      
    83 : cmp    qword ptr [rsp + 018h], 0h   ; 48 81 bc 24 18 00 00 00 00 00 00 00  
    84 : jne    __loops_label_25             ; 0f 85 11 00 00 00                    
    85 : mov    r13, qword ptr [rsp + 010h]  ; 4c 8b ac 24 10 00 00 00              
    86 : mov    byte ptr [r8 + r13], al      ; 43 88 04 28                          
    87 : jmp    __loops_label_44             ; e9 e0 00 00 00                       
    88 :        __loops_label_25:            ;                                      
    89 : cmp    qword ptr [rsp + 018h], 001h ; 48 81 bc 24 18 00 00 00 01 00 00 00  
    90 : jne    __loops_label_28             ; 0f 85 11 00 00 00                    
    91 : mov    r13, qword ptr [rsp + 010h]  ; 4c 8b ac 24 10 00 00 00              
    92 : mov    byte ptr [r8 + r13], al      ; 43 88 04 28                          
    93 : jmp    __loops_label_44             ; e9 bd 00 00 00                       
    94 :        __loops_label_28:            ;                                      
    95 : cmp    qword ptr [rsp + 018h], 002h ; 48 81 bc 24 18 00 00 00 02 00 00 00  
    96 : jne    __loops_label_31             ; 0f 85 12 00 00 00                    
    97 : mov    r13, qword ptr [rsp + 010h]  ; 4c 8b ac 24 10 00 00 00              
    98 : mov    word ptr [r8 + r13], ax      ; 66 43 89 04 28                       
    99 : jmp    __loops_label_44             ; e9 99 00 00 00                       
   100 :        __loops_label_31:            ;                                      
   101 : cmp    qword ptr [rsp + 018h], 003h ; 48 81 bc 24 18 00 00 00 03 00 00 00  
   102 : jne    __loops_label_34             ; 0f 85 12 00 00 00                    
   103 : mov    r13, qword ptr [rsp + 010h]  ; 4c 8b ac 24 10 00 00 00              
   104 : mov    word ptr [r8 + r13], ax      ; 66 43 89 04 28                       
   105 : jmp    __loops_label_44             ; e9 75 00 00 00                       
   106 :        __loops_label_34:            ;                                      
   107 : cmp    qword ptr [rsp + 018h], 004h ; 48 81 bc 24 18 00 00 00 04 00 00 00  
   108 : jne    __loops_label_37             ; 0f 85 11 00 00 00                    
   109 : mov    r13, qword ptr [rsp + 010h]  ; 4c 8b ac 24 10 00 00 00              
   110 : mov    dword ptr [r8 + r13], eax    ; 43 89 04 28                          
   111 : jmp    __loops_label_44             ; e9 52 00 00 00                       
   112 :        __loops_label_37:            ;                                      
   113 : cmp    qword ptr [rsp + 018h], 005h ; 48 81 bc 24 18 00 00 00 05 00 00 00  
   114 : jne    __loops_label_40             ; 0f 85 11 00 00 00                    
   115 : mov    r13, qword ptr [rsp + 010h]  ; 4c 8b ac 24 10 00 00 00              
   116 : mov    dword ptr [r8 + r13], eax    ; 43 89 04 28                          
   117 : jmp    __loops_label_44             ; e9 2f 00 00 00                       
   118 :        __loops_label_40:            ;                                      
   119 : cmp    qword ptr [rsp + 018h], 006h ; 48 81 bc 24 18 00 00 00 06 00 00 00  
   120 : jne    __loops_label_43             ; 0f 85 11 00 00 00                    
   121 : mov    r13, qword ptr [rsp + 010h]  ; 4c 8b ac 24 10 00 00 00              
   122 : mov    qword ptr [r8 + r13], rax    ; 4b 89 04 28                          
   123 : jmp    __loops_label_44             ; e9 0c 00 00 00                       
   124 :        __loops_label_43:            ;                                      
   125 : mov    r13, qword ptr [rsp + 010h]  ; 4c 8b ac 24 10 00 00 00              
   126 : mov    qword ptr [r8 + r13], rax    ; 4b 89 04 28                          
   127 :        __loops_label_26:            ;                                      
   128 :        __loops_label_29:            ;                                      
   129 :        __loops_label_32:            ;                                      
   130 :        __loops_label_35:            ;                                      
   131 :        __loops_label_38:            ;                                      
   132 :        __loops_label_41:            ;                                      
   133 :        __loops_label_44:            ;                                      
   134 : mov    r13, qword ptr [rsp + 020h]  ; 4c 8b ac 24 20 00 00 00              
   135 : add    qword ptr [rsp + 008h], r13  ; 4c 01 ac 24 08 00 00 00              
   136 : add    qword ptr [rsp + 010h], r9   ; 4c 01 8c 24 10 00 00 00              
   137 : add    qword ptr [rsp], 001h        ; 48 81 84 24 00 00 00 00 01 00 00 00  
   138 : jmp    __loops_label_0              ; e9 f1 fd ff ff                       
   139 :        __loops_label_2:             ;                                      
   140 : mov    r13, qword ptr [rsp + 028h]  ; 4c 8b ac 24 28 00 00 00              
   141 : add    rsp, 038h                    ; 48 81 c4 38 00 00 00                 
   142 : ret                                 ; c3                                   
