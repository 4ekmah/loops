triangle_types(i0, i1, i2)
     0 : sub  rsp, 018h                   ; 48 81 ec 18 00 00 00                 
     1 : mov  qword ptr [rsp], rdx        ; 48 89 94 24 00 00 00 00              
     2 : mov  qword ptr [rsp + 008h], r13 ; 4c 89 ac 24 08 00 00 00              
     3 : cmp  rcx, 0h                     ; 48 83 f9 00                          
     4 : jle  __loops_label_0             ; 0f 8e 1c 00 00 00                    
     5 : cmp  qword ptr [rsp], 0h         ; 48 81 bc 24 00 00 00 00 00 00 00 00  
     6 : jle  __loops_label_0             ; 0f 8e 0a 00 00 00                    
     7 : cmp  r8, 0h                      ; 49 83 f8 00                          
     8 : jg   __loops_label_1             ; 0f 8f 08 00 00 00                    
     9 :      __loops_label_0:            ;                                      
    10 : xor  rax, rax                    ; 48 31 c0                             
    11 : jmp  __loops_label_18            ; e9 cd 01 00 00                       
    12 :      __loops_label_1:            ;                                      
    13 : mov  r13, qword ptr [rsp]        ; 4c 8b ac 24 00 00 00 00              
    14 : mov  r9, r13                     ; 4d 89 e9                             
    15 : add  r9, r8                      ; 4d 01 c1                             
    16 : cmp  rcx, r9                     ; 4c 39 c9                             
    17 : jg   __loops_label_3             ; 0f 8f 28 00 00 00                    
    18 : mov  r9, rcx                     ; 49 89 c9                             
    19 : add  r9, r8                      ; 4d 01 c1                             
    20 : cmp  qword ptr [rsp], r9         ; 4c 39 8c 24 00 00 00 00              
    21 : jg   __loops_label_3             ; 0f 8f 14 00 00 00                    
    22 : mov  r9, rcx                     ; 49 89 c9                             
    23 : add  r9, qword ptr [rsp]         ; 4c 03 8c 24 00 00 00 00              
    24 : cmp  r8, r9                      ; 4d 39 c8                             
    25 : jle  __loops_label_4             ; 0f 8e 08 00 00 00                    
    26 :      __loops_label_3:            ;                                      
    27 : xor  rax, rax                    ; 48 31 c0                             
    28 : jmp  __loops_label_18            ; e9 86 01 00 00                       
    29 :      __loops_label_4:            ;                                      
    30 : cmp  rcx, qword ptr [rsp]        ; 48 3b 8c 24 00 00 00 00              
    31 : jne  __loops_label_7             ; 0f 85 15 00 00 00                    
    32 : cmp  rcx, r8                     ; 4c 39 c1                             
    33 : jne  __loops_label_7             ; 0f 85 0c 00 00 00                    
    34 : mov  rax, 002h                   ; 48 c7 c0 02 00 00 00                 
    35 : jmp  __loops_label_18            ; e9 63 01 00 00                       
    36 :      __loops_label_7:            ;                                      
    37 : cmp  rcx, qword ptr [rsp]        ; 48 3b 8c 24 00 00 00 00              
    38 : je   __loops_label_9             ; 0f 84 17 00 00 00                    
    39 : cmp  rcx, r8                     ; 4c 39 c1                             
    40 : je   __loops_label_9             ; 0f 84 0e 00 00 00                    
    41 : cmp  qword ptr [rsp], r8         ; 4c 39 84 24 00 00 00 00              
    42 : jne  __loops_label_10            ; 0f 85 0c 00 00 00                    
    43 :      __loops_label_9:            ;                                      
    44 : mov  rax, 003h                   ; 48 c7 c0 03 00 00 00                 
    45 : jmp  __loops_label_18            ; e9 32 01 00 00                       
    46 :      __loops_label_10:           ;                                      
    47 : mov  r9, rcx                     ; 49 89 c9                             
    48 : imul r9, rcx                     ; 4c 0f af c9                          
    49 : mov  r13, qword ptr [rsp]        ; 4c 8b ac 24 00 00 00 00              
    50 : mov  rax, r13                    ; 4c 89 e8                             
    51 : imul rax, qword ptr [rsp]        ; 48 0f af 84 24 00 00 00 00           
    52 : mov  rdx, r8                     ; 4c 89 c2                             
    53 : imul rdx, r8                     ; 49 0f af d0                          
    54 : add  rax, rdx                    ; 48 01 d0                             
    55 : cmp  r9, rax                     ; 49 39 c1                             
    56 : je   __loops_label_12            ; 0f 84 5c 00 00 00                    
    57 : mov  r13, qword ptr [rsp]        ; 4c 8b ac 24 00 00 00 00              
    58 : mov  rdx, r13                    ; 4c 89 ea                             
    59 : imul rdx, qword ptr [rsp]        ; 48 0f af 94 24 00 00 00 00           
    60 : mov  r9, rcx                     ; 49 89 c9                             
    61 : imul r9, rcx                     ; 4c 0f af c9                          
    62 : mov  rax, r8                     ; 4c 89 c0                             
    63 : imul rax, r8                     ; 49 0f af c0                          
    64 : add  r9, rax                     ; 49 01 c1                             
    65 : cmp  rdx, r9                     ; 4c 39 ca                             
    66 : je   __loops_label_12            ; 0f 84 2e 00 00 00                    
    67 : mov  rdx, r8                     ; 4c 89 c2                             
    68 : imul rdx, r8                     ; 49 0f af d0                          
    69 : mov  r9, rcx                     ; 49 89 c9                             
    70 : imul r9, rcx                     ; 4c 0f af c9                          
    71 : mov  r13, qword ptr [rsp]        ; 4c 8b ac 24 00 00 00 00              
    72 : mov  rax, r13                    ; 4c 89 e8                             
    73 : imul rax, qword ptr [rsp]        ; 48 0f af 84 24 00 00 00 00           
    74 : add  r9, rax                     ; 49 01 c1                             
    75 : cmp  rdx, r9                     ; 4c 39 ca                             
    76 : jne  __loops_label_13            ; 0f 85 0c 00 00 00                    
    77 :      __loops_label_12:           ;                                      
    78 : mov  rax, 001h                   ; 48 c7 c0 01 00 00 00                 
    79 : jmp  __loops_label_18            ; e9 9c 00 00 00                       
    80 :      __loops_label_13:           ;                                      
    81 : mov  rdx, rcx                    ; 48 89 ca                             
    82 : imul rdx, rcx                    ; 48 0f af d1                          
    83 : mov  r13, qword ptr [rsp]        ; 4c 8b ac 24 00 00 00 00              
    84 : mov  r9, r13                     ; 4d 89 e9                             
    85 : imul r9, qword ptr [rsp]         ; 4c 0f af 8c 24 00 00 00 00           
    86 : mov  rax, r8                     ; 4c 89 c0                             
    87 : imul rax, r8                     ; 49 0f af c0                          
    88 : add  r9, rax                     ; 49 01 c1                             
    89 : cmp  rdx, r9                     ; 4c 39 ca                             
    90 : jg   __loops_label_15            ; 0f 8f 56 00 00 00                    
    91 : mov  r13, qword ptr [rsp]        ; 4c 8b ac 24 00 00 00 00              
    92 : mov  rdx, r13                    ; 4c 89 ea                             
    93 : imul rdx, qword ptr [rsp]        ; 48 0f af 94 24 00 00 00 00           
    94 : mov  r9, rcx                     ; 49 89 c9                             
    95 : imul r9, rcx                     ; 4c 0f af c9                          
    96 : mov  rax, r8                     ; 4c 89 c0                             
    97 : imul rax, r8                     ; 49 0f af c0                          
    98 : add  r9, rax                     ; 49 01 c1                             
    99 : cmp  rdx, r9                     ; 4c 39 ca                             
   100 : jg   __loops_label_15            ; 0f 8f 28 00 00 00                    
   101 : imul r8, r8                      ; 4d 0f af c0                          
   102 : imul rcx, rcx                    ; 48 0f af c9                          
   103 : mov  r13, qword ptr [rsp]        ; 4c 8b ac 24 00 00 00 00              
   104 : mov  rdx, r13                    ; 4c 89 ea                             
   105 : imul rdx, qword ptr [rsp]        ; 48 0f af 94 24 00 00 00 00           
   106 : add  rcx, rdx                    ; 48 01 d1                             
   107 : cmp  r8, rcx                     ; 49 39 c8                             
   108 : jle  __loops_label_16            ; 0f 8e 0c 00 00 00                    
   109 :      __loops_label_15:           ;                                      
   110 : mov  rax, 005h                   ; 48 c7 c0 05 00 00 00                 
   111 : jmp  __loops_label_18            ; e9 0c 00 00 00                       
   112 :      __loops_label_16:           ;                                      
   113 : mov  rax, 004h                   ; 48 c7 c0 04 00 00 00                 
   114 : jmp  __loops_label_18            ; e9 00 00 00 00                       
   115 :      __loops_label_2:            ;                                      
   116 :      __loops_label_5:            ;                                      
   117 :      __loops_label_8:            ;                                      
   118 :      __loops_label_11:           ;                                      
   119 :      __loops_label_14:           ;                                      
   120 :      __loops_label_17:           ;                                      
   121 :      __loops_label_18:           ;                                      
   122 : mov  r13, qword ptr [rsp + 008h] ; 4c 8b ac 24 08 00 00 00              
   123 : add  rsp, 018h                   ; 48 81 c4 18 00 00 00                 
   124 : ret                              ; c3                                   
