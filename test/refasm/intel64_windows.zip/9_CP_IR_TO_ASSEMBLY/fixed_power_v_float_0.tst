fixed_power_v_float_0(i0, i1, i2)
     0 : xor          r9, r9                       ; 4d 31 c9              
     1 : imul         r8, 004h                     ; 4d 6b c0 04           
     2 :              __loops_label_0:             ;                       
     3 : cmp          r9, r8                       ; 4d 39 c1              
     4 : jge          __loops_label_2              ; 0f 8d 2a 00 00 00     
     5 : vmovups      ymm0, ymmword ptr [rcx + r9] ; c4 a1 7c 10 04 09     
     6 : mov          rax, 03f800000h              ; 48 c7 c0 00 00 80 3f  
     7 : vpinsrd      xmm0, xmm0, eax, 0h          ; c4 e3 79 22 c0 00     
     8 : vpbroadcastd ymm0, xmm0                   ; c4 e2 7d 58 c0        
     9 : vmovups      ymmword ptr [rdx + r9], ymm0 ; c4 a1 7c 11 04 0a     
    10 : add          r9, 020h                     ; 49 81 c1 20 00 00 00  
    11 : jmp          __loops_label_0              ; e9 cd ff ff ff        
    12 :              __loops_label_2:             ;                       
    13 : xor          rax, rax                     ; 48 31 c0              
    14 : ret                                       ; c3                    
