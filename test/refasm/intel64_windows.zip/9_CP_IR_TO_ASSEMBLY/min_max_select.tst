min_max_select(i0, i1, i2, i3)
     0 : sub    rsp, 038h                    ; 48 81 ec 38 00 00 00                 
     1 : mov    qword ptr [rsp + 028h], r13  ; 4c 89 ac 24 28 00 00 00              
     2 : mov    qword ptr [rsp + 008h], r8   ; 4c 89 84 24 08 00 00 00              
     3 : mov    qword ptr [rsp], r9          ; 4c 89 8c 24 00 00 00 00              
     4 : xor    rax, rax                     ; 48 31 c0                             
     5 : mov    qword ptr [rsp + 018h], 0h   ; 48 c7 84 24 18 00 00 00 00 00 00 00  
     6 : mov    qword ptr [rsp + 010h], 0h   ; 48 c7 84 24 10 00 00 00 00 00 00 00  
     7 : movsxd r8, dword ptr [rcx]          ; 4c 63 01                             
     8 : mov    r9, r8                       ; 4d 89 c1                             
     9 : mov    qword ptr [rsp + 020h], rdx  ; 48 89 94 24 20 00 00 00              
    10 : shl    qword ptr [rsp + 020h], 002h ; 48 c1 a4 24 20 00 00 00 02           
    11 :        __loops_label_0:             ;                                      
    12 : cmp    rax, qword ptr [rsp + 020h]  ; 48 3b 84 24 20 00 00 00              
    13 : jge    __loops_label_2              ; 0f 8d 4b 00 00 00                    
    14 : movsxd rdx, dword ptr [rcx + rax]   ; 48 63 14 01                          
    15 : cmp    rdx, r8                      ; 4c 39 c2                             
    16 : mov    r13, qword ptr [rsp + 018h]  ; 4c 8b ac 24 18 00 00 00              
    17 : cmovl  r13, rax                     ; 4c 0f 4c e8                          
    18 : mov    qword ptr [rsp + 018h], r13  ; 4c 89 ac 24 18 00 00 00              
    19 : cmp    r8, rdx                      ; 49 39 d0                             
    20 : cmovg  r8, rdx                      ; 4c 0f 4f c2                          
    21 : cmp    rdx, r9                      ; 4c 39 ca                             
    22 : mov    r13, qword ptr [rsp + 010h]  ; 4c 8b ac 24 10 00 00 00              
    23 : cmovg  r13, rax                     ; 4c 0f 4f e8                          
    24 : mov    qword ptr [rsp + 010h], r13  ; 4c 89 ac 24 10 00 00 00              
    25 : cmp    r9, rdx                      ; 49 39 d1                             
    26 : cmovl  r9, rdx                      ; 4c 0f 4c ca                          
    27 : add    rax, 004h                    ; 48 05 04 00 00 00                    
    28 : jmp    __loops_label_0              ; e9 a7 ff ff ff                       
    29 :        __loops_label_2:             ;                                      
    30 : mov    r13, qword ptr [rsp + 018h]  ; 4c 8b ac 24 18 00 00 00              
    31 : mov    rcx, r13                     ; 4c 89 e9                             
    32 : sar    rcx, 002h                    ; 48 c1 f9 02                          
    33 : mov    r13, qword ptr [rsp + 010h]  ; 4c 8b ac 24 10 00 00 00              
    34 : mov    rdx, r13                     ; 4c 89 ea                             
    35 : sar    rdx, 002h                    ; 48 c1 fa 02                          
    36 : mov    r13, qword ptr [rsp + 008h]  ; 4c 8b ac 24 08 00 00 00              
    37 : mov    dword ptr [r13], ecx         ; 41 89 4d 00                          
    38 : mov    r13, qword ptr [rsp]         ; 4c 8b ac 24 00 00 00 00              
    39 : mov    dword ptr [r13], edx         ; 41 89 55 00                          
    40 : xor    rax, rax                     ; 48 31 c0                             
    41 : mov    r13, qword ptr [rsp + 028h]  ; 4c 8b ac 24 28 00 00 00              
    42 : add    rsp, 038h                    ; 48 81 c4 38 00 00 00                 
    43 : ret                                 ; c3                                   
