bresenham(i0, i1, i2, i3, i4, i5, i6)
     0 : sub   rsp, 058h                   ; 48 81 ec 58 00 00 00        
     1 : mov   qword ptr [rsp + 048h], r13 ; 4c 89 ac 24 48 00 00 00     
     2 : mov   qword ptr [rsp + 050h], r14 ; 4c 89 b4 24 50 00 00 00     
     3 : mov   r13, qword ptr [rsp + 080h] ; 4c 8b ac 24 80 00 00 00     
     4 : mov   rax, r13                    ; 4c 89 e8                    
     5 : sub   rax, r8                     ; 4c 29 c0                    
     6 : mov   r13, rax                    ; 49 89 c5                    
     7 : neg   r13                         ; 49 f7 dd                    
     8 : cmovs r13, rax                    ; 4c 0f 48 e8                 
     9 : mov   qword ptr [rsp + 020h], r13 ; 4c 89 ac 24 20 00 00 00     
    10 : mov   r13, qword ptr [rsp + 080h] ; 4c 8b ac 24 80 00 00 00     
    11 : mov   rax, r13                    ; 4c 89 e8                    
    12 : sub   rax, r8                     ; 4c 29 c0                    
    13 : mov   qword ptr [rsp], rcx        ; 48 89 8c 24 00 00 00 00     
    14 : mov   r13, rax                    ; 49 89 c5                    
    15 : mov   rcx, r13                    ; 4c 89 e9                    
    16 : sar   r13, 03fh                   ; 49 c1 fd 3f                 
    17 : neg   rcx                         ; 48 f7 d9                    
    18 : adc   r13, r13                    ; 4d 11 ed                    
    19 : mov   rcx, qword ptr [rsp]        ; 48 8b 8c 24 00 00 00 00     
    20 : mov   qword ptr [rsp + 028h], r13 ; 4c 89 ac 24 28 00 00 00     
    21 : mov   r13, qword ptr [rsp + 088h] ; 4c 8b ac 24 88 00 00 00     
    22 : mov   rax, r13                    ; 4c 89 e8                    
    23 : sub   rax, r9                     ; 4c 29 c8                    
    24 : mov   qword ptr [rsp], rax        ; 48 89 84 24 00 00 00 00     
    25 : neg   rax                         ; 48 f7 d8                    
    26 : cmovs rax, qword ptr [rsp]        ; 48 0f 48 84 24 00 00 00 00  
    27 : mov   qword ptr [rsp + 030h], rax ; 48 89 84 24 30 00 00 00     
    28 : neg   qword ptr [rsp + 030h]      ; 48 f7 9c 24 30 00 00 00     
    29 : mov   r13, qword ptr [rsp + 088h] ; 4c 8b ac 24 88 00 00 00     
    30 : mov   rax, r13                    ; 4c 89 e8                    
    31 : sub   rax, r9                     ; 4c 29 c8                    
    32 : mov   qword ptr [rsp], rcx        ; 48 89 8c 24 00 00 00 00     
    33 : mov   r13, rax                    ; 49 89 c5                    
    34 : mov   rcx, r13                    ; 4c 89 e9                    
    35 : sar   r13, 03fh                   ; 49 c1 fd 3f                 
    36 : neg   rcx                         ; 48 f7 d9                    
    37 : adc   r13, r13                    ; 4d 11 ed                    
    38 : mov   rcx, qword ptr [rsp]        ; 48 8b 8c 24 00 00 00 00     
    39 : mov   qword ptr [rsp + 040h], r13 ; 4c 89 ac 24 40 00 00 00     
    40 : mov   r13, qword ptr [rsp + 020h] ; 4c 8b ac 24 20 00 00 00     
    41 : mov   r14, qword ptr [rsp + 030h] ; 4c 8b b4 24 30 00 00 00     
    42 : mov   qword ptr [rsp + 038h], r13 ; 4c 89 ac 24 38 00 00 00     
    43 : add   qword ptr [rsp + 038h], r14 ; 4c 01 b4 24 38 00 00 00     
    44 :       __loops_label_0:            ;                             
    45 : cmp   rcx, 0h                     ; 48 83 f9 00                 
    46 : je    __loops_label_2             ; 0f 84 bd 00 00 00           
    47 : mov   rax, r9                     ; 4c 89 c8                    
    48 : imul  rax, rdx                    ; 48 0f af c2                 
    49 : add   rax, r8                     ; 4c 01 c0                    
    50 : mov   r13, qword ptr [rsp + 090h] ; 4c 8b ac 24 90 00 00 00     
    51 : mov   byte ptr [rcx + rax], r13b  ; 44 88 2c 01                 
    52 : cmp   r8, qword ptr [rsp + 080h]  ; 4c 3b 84 24 80 00 00 00     
    53 : jne   __loops_label_4             ; 0f 85 13 00 00 00           
    54 : cmp   r9, qword ptr [rsp + 088h]  ; 4c 3b 8c 24 88 00 00 00     
    55 : jne   __loops_label_4             ; 0f 85 05 00 00 00           
    56 : jmp   __loops_label_2             ; e9 86 00 00 00              
    57 :       __loops_label_4:            ;                             
    58 : mov   r13, qword ptr [rsp + 038h] ; 4c 8b ac 24 38 00 00 00     
    59 : mov   rax, r13                    ; 4c 89 e8                    
    60 : shl   rax, 001h                   ; 48 c1 e0 01                 
    61 : cmp   rax, qword ptr [rsp + 030h] ; 48 3b 84 24 30 00 00 00     
    62 : jl    __loops_label_6             ; 0f 8c 2b 00 00 00           
    63 : cmp   r8, qword ptr [rsp + 080h]  ; 4c 3b 84 24 80 00 00 00     
    64 : jne   __loops_label_8             ; 0f 85 05 00 00 00           
    65 : jmp   __loops_label_2             ; e9 56 00 00 00              
    66 :       __loops_label_8:            ;                             
    67 : mov   r13, qword ptr [rsp + 030h] ; 4c 8b ac 24 30 00 00 00     
    68 : add   qword ptr [rsp + 038h], r13 ; 4c 01 ac 24 38 00 00 00     
    69 : add   r8, qword ptr [rsp + 028h]  ; 4c 03 84 24 28 00 00 00     
    70 :       __loops_label_6:            ;                             
    71 : cmp   rax, qword ptr [rsp + 020h] ; 48 3b 84 24 20 00 00 00     
    72 : jg    __loops_label_10            ; 0f 8f 2b 00 00 00           
    73 : cmp   r9, qword ptr [rsp + 088h]  ; 4c 3b 8c 24 88 00 00 00     
    74 : jne   __loops_label_12            ; 0f 85 05 00 00 00           
    75 : jmp   __loops_label_2             ; e9 1d 00 00 00              
    76 :       __loops_label_12:           ;                             
    77 : mov   r13, qword ptr [rsp + 020h] ; 4c 8b ac 24 20 00 00 00     
    78 : add   qword ptr [rsp + 038h], r13 ; 4c 01 ac 24 38 00 00 00     
    79 : add   r9, qword ptr [rsp + 040h]  ; 4c 03 8c 24 40 00 00 00     
    80 :       __loops_label_10:           ;                             
    81 : jmp   __loops_label_0             ; e9 39 ff ff ff              
    82 :       __loops_label_2:            ;                             
    83 : mov   r13, qword ptr [rsp + 048h] ; 4c 8b ac 24 48 00 00 00     
    84 : mov   r14, qword ptr [rsp + 050h] ; 4c 8b b4 24 50 00 00 00     
    85 : add   rsp, 058h                   ; 48 81 c4 58 00 00 00        
    86 : ret                               ; c3                          
