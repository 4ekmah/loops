area_sum(i0, i1)
     0 : sub     rsp, 0268h                       ; 48 81 ec 68 02 00 00                 
     1 : mov     qword ptr [rsp + 0250h], rcx     ; 48 89 8c 24 50 02 00 00              
     2 : mov     qword ptr [rsp + 0248h], rdx     ; 48 89 94 24 48 02 00 00              
     3 : mov     qword ptr [rsp + 0258h], r13     ; 4c 89 ac 24 58 02 00 00              
     4 : mov     qword ptr [rsp + 0260h], rbp     ; 48 89 ac 24 60 02 00 00              
     5 : mov     rbp, rsp                         ; 48 89 e5                             
     6 : add     rbp, 0260h                       ; 48 81 c5 60 02 00 00                 
     7 : mov     qword ptr [rsp + 0240h], 0h      ; 48 c7 84 24 40 02 00 00 00 00 00 00  
     8 :         __loops_label_0:                 ;                                      
     9 : cmp     qword ptr [rsp + 0248h], 0h      ; 48 81 bc 24 48 02 00 00 00 00 00 00  
    10 : jle     __loops_label_2                  ; 0f 8e 73 05 00 00                    
    11 : mov     r13, qword ptr [rsp + 0250h]     ; 4c 8b ac 24 50 02 00 00              
    12 : movsx   r9, byte ptr [r13]               ; 4d 0f be 4d 00                       
    13 : mov     rax, 07ff79e6c51f0h              ; 48 b8 f0 51 6c 9e f7 7f 00 00        
    14 : mov     r8, 07ff79e6c5320h               ; 49 b8 20 53 6c 9e f7 7f 00 00        
    15 : mov     rdx, 07ff79e6c5400h              ; 48 ba 00 54 6c 9e f7 7f 00 00        
    16 : cmp     r9, 001h                         ; 49 83 f9 01                          
    17 : cmove   rdx, r8                          ; 49 0f 44 d0                          
    18 : cmp     r9, 0h                           ; 49 83 f9 00                          
    19 : cmove   rdx, rax                         ; 48 0f 44 d0                          
    20 : mov     r8, 07ff79e6c50b0h               ; 49 b8 b0 50 6c 9e f7 7f 00 00        
    21 : mov     rax, 07ff79e6c5120h              ; 48 b8 20 51 6c 9e f7 7f 00 00        
    22 : mov     rcx, 07ff79e6c5160h              ; 48 b9 60 51 6c 9e f7 7f 00 00        
    23 : cmp     r9, 001h                         ; 49 83 f9 01                          
    24 : cmove   rcx, rax                         ; 48 0f 44 c8                          
    25 : cmp     r9, 0h                           ; 49 83 f9 00                          
    26 : cmove   rcx, r8                          ; 49 0f 44 c8                          
    27 : mov     r13, qword ptr [rsp + 0250h]     ; 4c 8b ac 24 50 02 00 00              
    28 : mov     qword ptr [rsp], rax             ; 48 89 84 24 00 00 00 00              
    29 : mov     qword ptr [rsp + 008h], rcx      ; 48 89 8c 24 08 00 00 00              
    30 : mov     qword ptr [rsp + 010h], rdx      ; 48 89 94 24 10 00 00 00              
    31 : mov     qword ptr [rsp + 018h], r8       ; 4c 89 84 24 18 00 00 00              
    32 : mov     qword ptr [rsp + 020h], r9       ; 4c 89 8c 24 20 00 00 00              
    33 : mov     qword ptr [rsp + 028h], r10      ; 4c 89 94 24 28 00 00 00              
    34 : mov     qword ptr [rsp + 030h], r11      ; 4c 89 9c 24 30 00 00 00              
    35 : vmovdqu ymmword ptr [rsp + 040h], ymm0   ; c5 fe 7f 84 24 40 00 00 00           
    36 : vmovdqu ymmword ptr [rsp + 060h], ymm1   ; c5 fe 7f 8c 24 60 00 00 00           
    37 : vmovdqu ymmword ptr [rsp + 080h], ymm2   ; c5 fe 7f 94 24 80 00 00 00           
    38 : vmovdqu ymmword ptr [rsp + 0a0h], ymm3   ; c5 fe 7f 9c 24 a0 00 00 00           
    39 : vmovdqu ymmword ptr [rsp + 0c0h], ymm5   ; c5 fe 7f ac 24 c0 00 00 00           
    40 : vmovdqu ymmword ptr [rsp + 0e0h], ymm6   ; c5 fe 7f b4 24 e0 00 00 00           
    41 : vmovdqu ymmword ptr [rsp + 0100h], ymm7  ; c5 fe 7f bc 24 00 01 00 00           
    42 : vmovdqu ymmword ptr [rsp + 0120h], ymm8  ; c5 7e 7f 84 24 20 01 00 00           
    43 : vmovdqu ymmword ptr [rsp + 0140h], ymm9  ; c5 7e 7f 8c 24 40 01 00 00           
    44 : vmovdqu ymmword ptr [rsp + 0160h], ymm10 ; c5 7e 7f 94 24 60 01 00 00           
    45 : vmovdqu ymmword ptr [rsp + 0180h], ymm11 ; c5 7e 7f 9c 24 80 01 00 00           
    46 : vmovdqu ymmword ptr [rsp + 01a0h], ymm12 ; c5 7e 7f a4 24 a0 01 00 00           
    47 : vmovdqu ymmword ptr [rsp + 01c0h], ymm13 ; c5 7e 7f ac 24 c0 01 00 00           
    48 : vmovdqu ymmword ptr [rsp + 01e0h], ymm14 ; c5 7e 7f b4 24 e0 01 00 00           
    49 : vmovdqu ymmword ptr [rsp + 0200h], ymm15 ; c5 7e 7f bc 24 00 02 00 00           
    50 : mov     rcx, r13                         ; 4c 89 e9                             
    51 : sub     rsp, 020h                        ; 48 81 ec 20 00 00 00                 
    52 : call    rdx                              ; ff d2                                
    53 : add     rsp, 020h                        ; 48 81 c4 20 00 00 00                 
    54 : mov     rax, qword ptr [rsp]             ; 48 8b 84 24 00 00 00 00              
    55 : mov     rcx, qword ptr [rsp + 008h]      ; 48 8b 8c 24 08 00 00 00              
    56 : mov     rdx, qword ptr [rsp + 010h]      ; 48 8b 94 24 10 00 00 00              
    57 : mov     r8, qword ptr [rsp + 018h]       ; 4c 8b 84 24 18 00 00 00              
    58 : mov     r9, qword ptr [rsp + 020h]       ; 4c 8b 8c 24 20 00 00 00              
    59 : mov     r10, qword ptr [rsp + 028h]      ; 4c 8b 94 24 28 00 00 00              
    60 : mov     r11, qword ptr [rsp + 030h]      ; 4c 8b 9c 24 30 00 00 00              
    61 : vmovdqu ymm0, ymmword ptr [rsp + 040h]   ; c5 fe 6f 84 24 40 00 00 00           
    62 : vmovdqu ymm1, ymmword ptr [rsp + 060h]   ; c5 fe 6f 8c 24 60 00 00 00           
    63 : vmovdqu ymm2, ymmword ptr [rsp + 080h]   ; c5 fe 6f 94 24 80 00 00 00           
    64 : vmovdqu ymm3, ymmword ptr [rsp + 0a0h]   ; c5 fe 6f 9c 24 a0 00 00 00           
    65 : vmovdqu ymm5, ymmword ptr [rsp + 0c0h]   ; c5 fe 6f ac 24 c0 00 00 00           
    66 : vmovdqu ymm6, ymmword ptr [rsp + 0e0h]   ; c5 fe 6f b4 24 e0 00 00 00           
    67 : vmovdqu ymm7, ymmword ptr [rsp + 0100h]  ; c5 fe 6f bc 24 00 01 00 00           
    68 : vmovdqu ymm8, ymmword ptr [rsp + 0120h]  ; c5 7e 6f 84 24 20 01 00 00           
    69 : vmovdqu ymm9, ymmword ptr [rsp + 0140h]  ; c5 7e 6f 8c 24 40 01 00 00           
    70 : vmovdqu ymm10, ymmword ptr [rsp + 0160h] ; c5 7e 6f 94 24 60 01 00 00           
    71 : vmovdqu ymm11, ymmword ptr [rsp + 0180h] ; c5 7e 6f 9c 24 80 01 00 00           
    72 : vmovdqu ymm12, ymmword ptr [rsp + 01a0h] ; c5 7e 6f a4 24 a0 01 00 00           
    73 : vmovdqu ymm13, ymmword ptr [rsp + 01c0h] ; c5 7e 6f ac 24 c0 01 00 00           
    74 : vmovdqu ymm14, ymmword ptr [rsp + 01e0h] ; c5 7e 6f b4 24 e0 01 00 00           
    75 : vmovdqu ymm15, ymmword ptr [rsp + 0200h] ; c5 7e 6f bc 24 00 02 00 00           
    76 : mov     r13, qword ptr [rsp + 0250h]     ; 4c 8b ac 24 50 02 00 00              
    77 : mov     qword ptr [rsp], rax             ; 48 89 84 24 00 00 00 00              
    78 : mov     qword ptr [rsp + 008h], rcx      ; 48 89 8c 24 08 00 00 00              
    79 : mov     qword ptr [rsp + 010h], rdx      ; 48 89 94 24 10 00 00 00              
    80 : mov     qword ptr [rsp + 018h], r8       ; 4c 89 84 24 18 00 00 00              
    81 : mov     qword ptr [rsp + 020h], r9       ; 4c 89 8c 24 20 00 00 00              
    82 : mov     qword ptr [rsp + 028h], r10      ; 4c 89 94 24 28 00 00 00              
    83 : mov     qword ptr [rsp + 030h], r11      ; 4c 89 9c 24 30 00 00 00              
    84 : vmovdqu ymmword ptr [rsp + 040h], ymm0   ; c5 fe 7f 84 24 40 00 00 00           
    85 : vmovdqu ymmword ptr [rsp + 060h], ymm1   ; c5 fe 7f 8c 24 60 00 00 00           
    86 : vmovdqu ymmword ptr [rsp + 080h], ymm2   ; c5 fe 7f 94 24 80 00 00 00           
    87 : vmovdqu ymmword ptr [rsp + 0a0h], ymm3   ; c5 fe 7f 9c 24 a0 00 00 00           
    88 : vmovdqu ymmword ptr [rsp + 0c0h], ymm5   ; c5 fe 7f ac 24 c0 00 00 00           
    89 : vmovdqu ymmword ptr [rsp + 0e0h], ymm6   ; c5 fe 7f b4 24 e0 00 00 00           
    90 : vmovdqu ymmword ptr [rsp + 0100h], ymm7  ; c5 fe 7f bc 24 00 01 00 00           
    91 : vmovdqu ymmword ptr [rsp + 0120h], ymm8  ; c5 7e 7f 84 24 20 01 00 00           
    92 : vmovdqu ymmword ptr [rsp + 0140h], ymm9  ; c5 7e 7f 8c 24 40 01 00 00           
    93 : vmovdqu ymmword ptr [rsp + 0160h], ymm10 ; c5 7e 7f 94 24 60 01 00 00           
    94 : vmovdqu ymmword ptr [rsp + 0180h], ymm11 ; c5 7e 7f 9c 24 80 01 00 00           
    95 : vmovdqu ymmword ptr [rsp + 01a0h], ymm12 ; c5 7e 7f a4 24 a0 01 00 00           
    96 : vmovdqu ymmword ptr [rsp + 01c0h], ymm13 ; c5 7e 7f ac 24 c0 01 00 00           
    97 : vmovdqu ymmword ptr [rsp + 01e0h], ymm14 ; c5 7e 7f b4 24 e0 01 00 00           
    98 : vmovdqu ymmword ptr [rsp + 0200h], ymm15 ; c5 7e 7f bc 24 00 02 00 00           
    99 : mov     rcx, r13                         ; 4c 89 e9                             
   100 : mov     r10, qword ptr [rsp + 008h]      ; 4c 8b 94 24 08 00 00 00              
   101 : sub     rsp, 020h                        ; 48 81 ec 20 00 00 00                 
   102 : call    r10                              ; 41 ff d2                             
   103 : add     rsp, 020h                        ; 48 81 c4 20 00 00 00                 
   104 : mov     rcx, rax                         ; 48 89 c1                             
   105 : mov     rax, qword ptr [rsp]             ; 48 8b 84 24 00 00 00 00              
   106 : mov     rdx, qword ptr [rsp + 010h]      ; 48 8b 94 24 10 00 00 00              
   107 : mov     r8, qword ptr [rsp + 018h]       ; 4c 8b 84 24 18 00 00 00              
   108 : mov     r9, qword ptr [rsp + 020h]       ; 4c 8b 8c 24 20 00 00 00              
   109 : mov     r10, qword ptr [rsp + 028h]      ; 4c 8b 94 24 28 00 00 00              
   110 : mov     r11, qword ptr [rsp + 030h]      ; 4c 8b 9c 24 30 00 00 00              
   111 : vmovdqu ymm0, ymmword ptr [rsp + 040h]   ; c5 fe 6f 84 24 40 00 00 00           
   112 : vmovdqu ymm1, ymmword ptr [rsp + 060h]   ; c5 fe 6f 8c 24 60 00 00 00           
   113 : vmovdqu ymm2, ymmword ptr [rsp + 080h]   ; c5 fe 6f 94 24 80 00 00 00           
   114 : vmovdqu ymm3, ymmword ptr [rsp + 0a0h]   ; c5 fe 6f 9c 24 a0 00 00 00           
   115 : vmovdqu ymm5, ymmword ptr [rsp + 0c0h]   ; c5 fe 6f ac 24 c0 00 00 00           
   116 : vmovdqu ymm6, ymmword ptr [rsp + 0e0h]   ; c5 fe 6f b4 24 e0 00 00 00           
   117 : vmovdqu ymm7, ymmword ptr [rsp + 0100h]  ; c5 fe 6f bc 24 00 01 00 00           
   118 : vmovdqu ymm8, ymmword ptr [rsp + 0120h]  ; c5 7e 6f 84 24 20 01 00 00           
   119 : vmovdqu ymm9, ymmword ptr [rsp + 0140h]  ; c5 7e 6f 8c 24 40 01 00 00           
   120 : vmovdqu ymm10, ymmword ptr [rsp + 0160h] ; c5 7e 6f 94 24 60 01 00 00           
   121 : vmovdqu ymm11, ymmword ptr [rsp + 0180h] ; c5 7e 6f 9c 24 80 01 00 00           
   122 : vmovdqu ymm12, ymmword ptr [rsp + 01a0h] ; c5 7e 6f a4 24 a0 01 00 00           
   123 : vmovdqu ymm13, ymmword ptr [rsp + 01c0h] ; c5 7e 6f ac 24 c0 01 00 00           
   124 : vmovdqu ymm14, ymmword ptr [rsp + 01e0h] ; c5 7e 6f b4 24 e0 01 00 00           
   125 : vmovdqu ymm15, ymmword ptr [rsp + 0200h] ; c5 7e 6f bc 24 00 02 00 00           
   126 : mov     rdx, 07ff79e6c5060h              ; 48 ba 60 50 6c 9e f7 7f 00 00        
   127 : mov     r13, qword ptr [rsp + 0240h]     ; 4c 8b ac 24 40 02 00 00              
   128 : mov     qword ptr [rsp], rax             ; 48 89 84 24 00 00 00 00              
   129 : mov     qword ptr [rsp + 008h], rcx      ; 48 89 8c 24 08 00 00 00              
   130 : mov     qword ptr [rsp + 010h], rdx      ; 48 89 94 24 10 00 00 00              
   131 : mov     qword ptr [rsp + 018h], r8       ; 4c 89 84 24 18 00 00 00              
   132 : mov     qword ptr [rsp + 020h], r9       ; 4c 89 8c 24 20 00 00 00              
   133 : mov     qword ptr [rsp + 028h], r10      ; 4c 89 94 24 28 00 00 00              
   134 : mov     qword ptr [rsp + 030h], r11      ; 4c 89 9c 24 30 00 00 00              
   135 : vmovdqu ymmword ptr [rsp + 040h], ymm0   ; c5 fe 7f 84 24 40 00 00 00           
   136 : vmovdqu ymmword ptr [rsp + 060h], ymm1   ; c5 fe 7f 8c 24 60 00 00 00           
   137 : vmovdqu ymmword ptr [rsp + 080h], ymm2   ; c5 fe 7f 94 24 80 00 00 00           
   138 : vmovdqu ymmword ptr [rsp + 0a0h], ymm3   ; c5 fe 7f 9c 24 a0 00 00 00           
   139 : vmovdqu ymmword ptr [rsp + 0c0h], ymm5   ; c5 fe 7f ac 24 c0 00 00 00           
   140 : vmovdqu ymmword ptr [rsp + 0e0h], ymm6   ; c5 fe 7f b4 24 e0 00 00 00           
   141 : vmovdqu ymmword ptr [rsp + 0100h], ymm7  ; c5 fe 7f bc 24 00 01 00 00           
   142 : vmovdqu ymmword ptr [rsp + 0120h], ymm8  ; c5 7e 7f 84 24 20 01 00 00           
   143 : vmovdqu ymmword ptr [rsp + 0140h], ymm9  ; c5 7e 7f 8c 24 40 01 00 00           
   144 : vmovdqu ymmword ptr [rsp + 0160h], ymm10 ; c5 7e 7f 94 24 60 01 00 00           
   145 : vmovdqu ymmword ptr [rsp + 0180h], ymm11 ; c5 7e 7f 9c 24 80 01 00 00           
   146 : vmovdqu ymmword ptr [rsp + 01a0h], ymm12 ; c5 7e 7f a4 24 a0 01 00 00           
   147 : vmovdqu ymmword ptr [rsp + 01c0h], ymm13 ; c5 7e 7f ac 24 c0 01 00 00           
   148 : vmovdqu ymmword ptr [rsp + 01e0h], ymm14 ; c5 7e 7f b4 24 e0 01 00 00           
   149 : vmovdqu ymmword ptr [rsp + 0200h], ymm15 ; c5 7e 7f bc 24 00 02 00 00           
   150 : mov     rcx, r13                         ; 4c 89 e9                             
   151 : mov     rdx, qword ptr [rsp + 008h]      ; 48 8b 94 24 08 00 00 00              
   152 : mov     r10, qword ptr [rsp + 010h]      ; 4c 8b 94 24 10 00 00 00              
   153 : sub     rsp, 020h                        ; 48 81 ec 20 00 00 00                 
   154 : call    r10                              ; 41 ff d2                             
   155 : add     rsp, 020h                        ; 48 81 c4 20 00 00 00                 
   156 : mov     rcx, rax                         ; 48 89 c1                             
   157 : mov     rax, qword ptr [rsp]             ; 48 8b 84 24 00 00 00 00              
   158 : mov     rdx, qword ptr [rsp + 010h]      ; 48 8b 94 24 10 00 00 00              
   159 : mov     r8, qword ptr [rsp + 018h]       ; 4c 8b 84 24 18 00 00 00              
   160 : mov     r9, qword ptr [rsp + 020h]       ; 4c 8b 8c 24 20 00 00 00              
   161 : mov     r10, qword ptr [rsp + 028h]      ; 4c 8b 94 24 28 00 00 00              
   162 : mov     r11, qword ptr [rsp + 030h]      ; 4c 8b 9c 24 30 00 00 00              
   163 : vmovdqu ymm0, ymmword ptr [rsp + 040h]   ; c5 fe 6f 84 24 40 00 00 00           
   164 : vmovdqu ymm1, ymmword ptr [rsp + 060h]   ; c5 fe 6f 8c 24 60 00 00 00           
   165 : vmovdqu ymm2, ymmword ptr [rsp + 080h]   ; c5 fe 6f 94 24 80 00 00 00           
   166 : vmovdqu ymm3, ymmword ptr [rsp + 0a0h]   ; c5 fe 6f 9c 24 a0 00 00 00           
   167 : vmovdqu ymm5, ymmword ptr [rsp + 0c0h]   ; c5 fe 6f ac 24 c0 00 00 00           
   168 : vmovdqu ymm6, ymmword ptr [rsp + 0e0h]   ; c5 fe 6f b4 24 e0 00 00 00           
   169 : vmovdqu ymm7, ymmword ptr [rsp + 0100h]  ; c5 fe 6f bc 24 00 01 00 00           
   170 : vmovdqu ymm8, ymmword ptr [rsp + 0120h]  ; c5 7e 6f 84 24 20 01 00 00           
   171 : vmovdqu ymm9, ymmword ptr [rsp + 0140h]  ; c5 7e 6f 8c 24 40 01 00 00           
   172 : vmovdqu ymm10, ymmword ptr [rsp + 0160h] ; c5 7e 6f 94 24 60 01 00 00           
   173 : vmovdqu ymm11, ymmword ptr [rsp + 0180h] ; c5 7e 6f 9c 24 80 01 00 00           
   174 : vmovdqu ymm12, ymmword ptr [rsp + 01a0h] ; c5 7e 6f a4 24 a0 01 00 00           
   175 : vmovdqu ymm13, ymmword ptr [rsp + 01c0h] ; c5 7e 6f ac 24 c0 01 00 00           
   176 : vmovdqu ymm14, ymmword ptr [rsp + 01e0h] ; c5 7e 6f b4 24 e0 01 00 00           
   177 : vmovdqu ymm15, ymmword ptr [rsp + 0200h] ; c5 7e 6f bc 24 00 02 00 00           
   178 : mov     qword ptr [rsp + 0240h], rcx     ; 48 89 8c 24 40 02 00 00              
   179 : add     qword ptr [rsp + 0250h], 038h    ; 48 81 84 24 50 02 00 00 38 00 00 00  
   180 : sub     qword ptr [rsp + 0248h], 001h    ; 48 81 ac 24 48 02 00 00 01 00 00 00  
   181 : jmp     __loops_label_0                  ; e9 7b fa ff ff                       
   182 :         __loops_label_2:                 ;                                      
   183 : mov     rax, qword ptr [rsp + 0240h]     ; 48 8b 84 24 40 02 00 00              
   184 : mov     rbp, qword ptr [rsp + 0260h]     ; 48 8b ac 24 60 02 00 00              
   185 : mov     r13, qword ptr [rsp + 0258h]     ; 4c 8b ac 24 58 02 00 00              
   186 : add     rsp, 0268h                       ; 48 81 c4 68 02 00 00                 
   187 : ret                                      ; c3                                   
