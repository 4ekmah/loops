fixed_power_v_double_0(i0, i1, i2)
     0 : xor          r9, r9                       ; 4d 31 c9                       
     1 : imul         r8, 008h                     ; 4d 6b c0 08                    
     2 :              __loops_label_0:             ;                                
     3 : cmp          r9, r8                       ; 4d 39 c1                       
     4 : jge          __loops_label_2              ; 0f 8d 2d 00 00 00              
     5 : vmovupd      ymm0, ymmword ptr [rcx + r9] ; c4 a1 7d 10 04 09              
     6 : mov          rax, 03ff0000000000000h      ; 48 b8 00 00 00 00 00 00 f0 3f  
     7 : vpinsrq      xmm0, xmm0, rax, 0h          ; c4 e3 f9 22 c0 00              
     8 : vpbroadcastq ymm0, xmm0                   ; c4 e2 7d 59 c0                 
     9 : vmovupd      ymmword ptr [rdx + r9], ymm0 ; c4 a1 7d 11 04 0a              
    10 : add          r9, 020h                     ; 49 81 c1 20 00 00 00           
    11 : jmp          __loops_label_0              ; e9 ca ff ff ff                 
    12 :              __loops_label_2:             ;                                
    13 : xor          rax, rax                     ; 48 31 c0                       
    14 : ret                                       ; c3                             
