has_in_join_cascade(i0, i1, i2)
     0 : sub    rsp, 078h                    ; 48 81 ec 78 00 00 00                 
     1 : mov    qword ptr [rsp + 030h], rcx  ; 48 89 8c 24 30 00 00 00              
     2 : mov    qword ptr [rsp + 028h], rdx  ; 48 89 94 24 28 00 00 00              
     3 : mov    qword ptr [rsp + 020h], r8   ; 4c 89 84 24 20 00 00 00              
     4 : mov    qword ptr [rsp + 068h], r13  ; 4c 89 ac 24 68 00 00 00              
     5 : mov    qword ptr [rsp + 070h], r14  ; 4c 89 b4 24 70 00 00 00              
     6 : mov    qword ptr [rsp], 0h          ; 48 c7 84 24 00 00 00 00 00 00 00 00  
     7 : mov    r13, qword ptr [rsp + 030h]  ; 4c 8b ac 24 30 00 00 00              
     8 : mov    r14, qword ptr [r13 + 010h]  ; 4d 8b b5 10 00 00 00                 
     9 : mov    qword ptr [rsp + 018h], r14  ; 4c 89 b4 24 18 00 00 00              
    10 : mov    r13, qword ptr [rsp + 030h]  ; 4c 8b ac 24 30 00 00 00              
    11 : mov    r14, qword ptr [r13 + 0h]    ; 4d 8b b5 00 00 00 00                 
    12 : mov    qword ptr [rsp + 010h], r14  ; 4c 89 b4 24 10 00 00 00              
    13 : mov    r13, qword ptr [rsp + 030h]  ; 4c 8b ac 24 30 00 00 00              
    14 : mov    r14, qword ptr [r13 + 008h]  ; 4d 8b b5 08 00 00 00                 
    15 : mov    qword ptr [rsp + 008h], r14  ; 4c 89 b4 24 08 00 00 00              
    16 :        __loops_label_0:             ;                                      
    17 : cmp    qword ptr [rsp + 018h], 0h   ; 48 81 bc 24 18 00 00 00 00 00 00 00  
    18 : jle    __loops_label_2              ; 0f 8e c5 01 00 00                    
    19 : mov    r13, qword ptr [rsp + 010h]  ; 4c 8b ac 24 10 00 00 00              
    20 : movsxd r14, dword ptr [r13]         ; 4d 63 75 00                          
    21 : mov    qword ptr [rsp + 058h], r14  ; 4c 89 b4 24 58 00 00 00              
    22 : add    qword ptr [rsp + 010h], 004h ; 48 81 84 24 10 00 00 00 04 00 00 00  
    23 : mov    r13, qword ptr [rsp + 008h]  ; 4c 8b ac 24 08 00 00 00              
    24 : movsxd r14, dword ptr [r13]         ; 4d 63 75 00                          
    25 : mov    qword ptr [rsp + 050h], r14  ; 4c 89 b4 24 50 00 00 00              
    26 : add    qword ptr [rsp + 008h], 004h ; 48 81 84 24 08 00 00 00 04 00 00 00  
    27 : sub    qword ptr [rsp + 018h], 001h ; 48 81 ac 24 18 00 00 00 01 00 00 00  
    28 : mov    r13, qword ptr [rsp + 030h]  ; 4c 8b ac 24 30 00 00 00              
    29 : mov    r14, qword ptr [r13 + 028h]  ; 4d 8b b5 28 00 00 00                 
    30 : mov    qword ptr [rsp + 048h], r14  ; 4c 89 b4 24 48 00 00 00              
    31 : mov    r13, qword ptr [rsp + 030h]  ; 4c 8b ac 24 30 00 00 00              
    32 : mov    r14, qword ptr [r13 + 018h]  ; 4d 8b b5 18 00 00 00                 
    33 : mov    qword ptr [rsp + 040h], r14  ; 4c 89 b4 24 40 00 00 00              
    34 : mov    r13, qword ptr [rsp + 030h]  ; 4c 8b ac 24 30 00 00 00              
    35 : mov    r14, qword ptr [r13 + 020h]  ; 4d 8b b5 20 00 00 00                 
    36 : mov    qword ptr [rsp + 038h], r14  ; 4c 89 b4 24 38 00 00 00              
    37 :        __loops_label_3:             ;                                      
    38 : cmp    qword ptr [rsp + 048h], 0h   ; 48 81 bc 24 48 00 00 00 00 00 00 00  
    39 : jle    __loops_label_5              ; 0f 8e 1d 01 00 00                    
    40 : mov    r13, qword ptr [rsp + 040h]  ; 4c 8b ac 24 40 00 00 00              
    41 : movsxd rcx, dword ptr [r13]         ; 49 63 4d 00                          
    42 : add    qword ptr [rsp + 040h], 004h ; 48 81 84 24 40 00 00 00 04 00 00 00  
    43 : mov    r13, qword ptr [rsp + 038h]  ; 4c 8b ac 24 38 00 00 00              
    44 : movsxd rdx, dword ptr [r13]         ; 49 63 55 00                          
    45 : add    qword ptr [rsp + 038h], 004h ; 48 81 84 24 38 00 00 00 04 00 00 00  
    46 : sub    qword ptr [rsp + 048h], 001h ; 48 81 ac 24 48 00 00 00 01 00 00 00  
    47 : cmp    rdx, qword ptr [rsp + 058h]  ; 48 3b 94 24 58 00 00 00              
    48 : jle    __loops_label_7              ; 0f 8e 05 00 00 00                    
    49 : jmp    __loops_label_3              ; e9 9f ff ff ff                       
    50 :        __loops_label_7:             ;                                      
    51 : cmp    rdx, qword ptr [rsp + 058h]  ; 48 3b 94 24 58 00 00 00              
    52 : jne    __loops_label_10             ; 0f 85 bb 00 00 00                    
    53 : mov    r13, qword ptr [rsp + 030h]  ; 4c 8b ac 24 30 00 00 00              
    54 : mov    rdx, qword ptr [r13 + 040h]  ; 49 8b 95 40 00 00 00                 
    55 : mov    r13, qword ptr [rsp + 030h]  ; 4c 8b ac 24 30 00 00 00              
    56 : mov    r8, qword ptr [r13 + 030h]   ; 4d 8b 85 30 00 00 00                 
    57 : mov    r13, qword ptr [rsp + 030h]  ; 4c 8b ac 24 30 00 00 00              
    58 : mov    r14, qword ptr [r13 + 038h]  ; 4d 8b b5 38 00 00 00                 
    59 : mov    qword ptr [rsp + 060h], r14  ; 4c 89 b4 24 60 00 00 00              
    60 :        __loops_label_11:            ;                                      
    61 : cmp    rdx, 0h                      ; 48 83 fa 00                          
    62 : jle    __loops_label_10             ; 0f 8e 7c 00 00 00                    
    63 : movsxd r9, dword ptr [r8]           ; 4d 63 08                             
    64 : add    r8, 004h                     ; 49 81 c0 04 00 00 00                 
    65 : mov    r13, qword ptr [rsp + 060h]  ; 4c 8b ac 24 60 00 00 00              
    66 : movsxd rax, dword ptr [r13]         ; 49 63 45 00                          
    67 : add    qword ptr [rsp + 060h], 004h ; 48 81 84 24 60 00 00 00 04 00 00 00  
    68 : sub    rdx, 001h                    ; 48 81 ea 01 00 00 00                 
    69 : cmp    r9, qword ptr [rsp + 050h]   ; 4c 3b 8c 24 50 00 00 00              
    70 : jle    __loops_label_15             ; 0f 8e 05 00 00 00                    
    71 : jmp    __loops_label_11             ; e9 ba ff ff ff                       
    72 :        __loops_label_15:            ;                                      
    73 : cmp    r9, qword ptr [rsp + 050h]   ; 4c 3b 8c 24 50 00 00 00              
    74 : jne    __loops_label_18             ; 0f 85 2d 00 00 00                    
    75 : cmp    rcx, qword ptr [rsp + 028h]  ; 48 3b 8c 24 28 00 00 00              
    76 : jne    __loops_label_18             ; 0f 85 1f 00 00 00                    
    77 : cmp    rax, qword ptr [rsp + 020h]  ; 48 3b 84 24 20 00 00 00              
    78 : jne    __loops_label_18             ; 0f 85 11 00 00 00                    
    79 : mov    qword ptr [rsp], 001h        ; 48 c7 84 24 00 00 00 00 01 00 00 00  
    80 : jmp    __loops_label_2              ; e9 0f 00 00 00                       
    81 :        __loops_label_16:            ;                                      
    82 :        __loops_label_18:            ;                                      
    83 : jmp    __loops_label_11             ; e9 7a ff ff ff                       
    84 :        __loops_label_13:            ;                                      
    85 :        __loops_label_8:             ;                                      
    86 :        __loops_label_10:            ;                                      
    87 : jmp    __loops_label_3              ; e9 d1 fe ff ff                       
    88 :        __loops_label_5:             ;                                      
    89 : jmp    __loops_label_0              ; e9 29 fe ff ff                       
    90 :        __loops_label_2:             ;                                      
    91 : mov    rax, qword ptr [rsp]         ; 48 8b 84 24 00 00 00 00              
    92 : mov    r13, qword ptr [rsp + 068h]  ; 4c 8b ac 24 68 00 00 00              
    93 : mov    r14, qword ptr [rsp + 070h]  ; 4c 8b b4 24 70 00 00 00              
    94 : add    rsp, 078h                    ; 48 81 c4 78 00 00 00                 
    95 : ret                                 ; c3                                   
