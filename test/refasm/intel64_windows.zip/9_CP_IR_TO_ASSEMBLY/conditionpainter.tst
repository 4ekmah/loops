conditionpainter(i0)
     0 : sub    rsp, 038h                                  ; 48 81 ec 38 00 00 00                 
     1 : mov    qword ptr [rsp + 008h], rcx                ; 48 89 8c 24 08 00 00 00              
     2 : mov    qword ptr [rsp + 028h], r13                ; 4c 89 ac 24 28 00 00 00              
     3 : mov    r13, 0fffffffffffffffbh                    ; 49 c7 c5 fb ff ff ff                 
     4 : mov    qword ptr [rsp], r13                       ; 4c 89 ac 24 00 00 00 00              
     5 :        __loops_label_0:                           ;                                      
     6 : cmp    qword ptr [rsp], 005h                      ; 48 81 bc 24 00 00 00 00 05 00 00 00  
     7 : jg     __loops_label_2                            ; 0f 8f f4 02 00 00                    
     8 : mov    r13, qword ptr [rsp]                       ; 4c 8b ac 24 00 00 00 00              
     9 : mov    r8, r13                                    ; 4d 89 e8                             
    10 : add    r8, 005h                                   ; 49 81 c0 05 00 00 00                 
    11 : imul   r8, 00bh                                   ; 4d 6b c0 0b                          
    12 : mov    r13, r8                                    ; 4d 89 c5                             
    13 : imul   r13, 008h                                  ; 4d 6b ed 08                          
    14 : mov    qword ptr [rsp + 018h], r13                ; 4c 89 ac 24 18 00 00 00              
    15 : mov    r13, 0fffffffffffffffbh                    ; 49 c7 c5 fb ff ff ff                 
    16 : mov    qword ptr [rsp + 010h], r13                ; 4c 89 ac 24 10 00 00 00              
    17 :        __loops_label_3:                           ;                                      
    18 : cmp    qword ptr [rsp + 010h], 005h               ; 48 81 bc 24 10 00 00 00 05 00 00 00  
    19 : jg     __loops_label_5                            ; 0f 8f 9d 02 00 00                    
    20 : mov    r13, qword ptr [rsp + 010h]                ; 4c 8b ac 24 10 00 00 00              
    21 : mov    rax, r13                                   ; 4c 89 e8                             
    22 : add    rax, 003h                                  ; 48 05 03 00 00 00                    
    23 : xor    rdx, rdx                                   ; 48 31 d2                             
    24 : cmp    qword ptr [rsp], rax                       ; 48 39 84 24 00 00 00 00              
    25 : setge  dl                                         ; 0f 9d c2                             
    26 : xor    rax, rax                                   ; 48 31 c0                             
    27 : cmp    qword ptr [rsp], 004h                      ; 48 81 bc 24 00 00 00 00 04 00 00 00  
    28 : setle  al                                         ; 0f 9e c0                             
    29 : and    rdx, rax                                   ; 48 21 c2                             
    30 : xor    rax, rax                                   ; 48 31 c0                             
    31 : cmp    qword ptr [rsp + 010h], 0fffffffffffffffeh ; 48 81 bc 24 10 00 00 00 fe ff ff ff  
    32 : setge  al                                         ; 0f 9d c0                             
    33 : and    rdx, rax                                   ; 48 21 c2                             
    34 : xor    rax, rax                                   ; 48 31 c0                             
    35 : cmp    qword ptr [rsp + 010h], 0h                 ; 48 81 bc 24 10 00 00 00 00 00 00 00  
    36 : setle  al                                         ; 0f 9e c0                             
    37 : and    rdx, rax                                   ; 48 21 c2                             
    38 : mov    r13, qword ptr [rsp + 010h]                ; 4c 8b ac 24 10 00 00 00              
    39 : mov    rax, r13                                   ; 4c 89 e8                             
    40 : sub    rax, 001h                                  ; 48 2d 01 00 00 00                    
    41 : xor    rcx, rcx                                   ; 48 31 c9                             
    42 : cmp    qword ptr [rsp], rax                       ; 48 39 84 24 00 00 00 00              
    43 : setle  cl                                         ; 0f 9e c1                             
    44 : xor    rax, rax                                   ; 48 31 c0                             
    45 : cmp    qword ptr [rsp + 010h], 0h                 ; 48 81 bc 24 10 00 00 00 00 00 00 00  
    46 : setge  al                                         ; 0f 9d c0                             
    47 : and    rcx, rax                                   ; 48 21 c1                             
    48 : xor    rax, rax                                   ; 48 31 c0                             
    49 : cmp    qword ptr [rsp], 0h                        ; 48 81 bc 24 00 00 00 00 00 00 00 00  
    50 : setle  al                                         ; 0f 9e c0                             
    51 : and    rcx, rax                                   ; 48 21 c1                             
    52 : mov    r13, qword ptr [rsp + 010h]                ; 4c 8b ac 24 10 00 00 00              
    53 : mov    rax, r13                                   ; 4c 89 e8                             
    54 : imul   rax, qword ptr [rsp + 010h]                ; 48 0f af 84 24 10 00 00 00           
    55 : mov    r13, qword ptr [rsp]                       ; 4c 8b ac 24 00 00 00 00              
    56 : mov    r9, r13                                    ; 4d 89 e9                             
    57 : imul   r9, qword ptr [rsp]                        ; 4c 0f af 8c 24 00 00 00 00           
    58 : add    rax, r9                                    ; 4c 01 c8                             
    59 : xor    r9, r9                                     ; 4d 31 c9                             
    60 : cmp    rax, 009h                                  ; 48 83 f8 09                          
    61 : setle  r9b                                        ; 41 0f 9e c1                          
    62 : and    rcx, r9                                    ; 4c 21 c9                             
    63 : mov    qword ptr [rsp + 020h], rdx                ; 48 89 94 24 20 00 00 00              
    64 : or     qword ptr [rsp + 020h], rcx                ; 48 09 8c 24 20 00 00 00              
    65 : mov    rcx, 002h                                  ; 48 c7 c1 02 00 00 00                 
    66 : xor    r9, r9                                     ; 4d 31 c9                             
    67 : xor    rax, rax                                   ; 48 31 c0                             
    68 : cmp    qword ptr [rsp + 010h], 002h               ; 48 81 bc 24 10 00 00 00 02 00 00 00  
    69 : setge  al                                         ; 0f 9d c0                             
    70 : xor    r8, r8                                     ; 4d 31 c0                             
    71 : cmp    qword ptr [rsp + 010h], 004h               ; 48 81 bc 24 10 00 00 00 04 00 00 00  
    72 : setle  r8b                                        ; 41 0f 9e c0                          
    73 : and    rax, r8                                    ; 4c 21 c0                             
    74 : xor    r8, r8                                     ; 4d 31 c0                             
    75 : cmp    qword ptr [rsp], 001h                      ; 48 81 bc 24 00 00 00 00 01 00 00 00  
    76 : setge  r8b                                        ; 41 0f 9d c0                          
    77 : xor    rdx, rdx                                   ; 48 31 d2                             
    78 : cmp    qword ptr [rsp], 003h                      ; 48 81 bc 24 00 00 00 00 03 00 00 00  
    79 : setle  dl                                         ; 0f 9e c2                             
    80 : and    r8, rdx                                    ; 49 21 d0                             
    81 : or     rax, r8                                    ; 4c 09 c0                             
    82 : mov    r13, qword ptr [rsp + 010h]                ; 4c 8b ac 24 10 00 00 00              
    83 : mov    rdx, r13                                   ; 4c 89 ea                             
    84 : imul   rdx, qword ptr [rsp + 010h]                ; 48 0f af 94 24 10 00 00 00           
    85 : mov    r13, qword ptr [rsp]                       ; 4c 8b ac 24 00 00 00 00              
    86 : mov    r8, r13                                    ; 4d 89 e8                             
    87 : imul   r8, qword ptr [rsp]                        ; 4c 0f af 84 24 00 00 00 00           
    88 : add    rdx, r8                                    ; 4c 01 c2                             
    89 : xor    r8, r8                                     ; 4d 31 c0                             
    90 : cmp    rdx, 010h                                  ; 48 83 fa 10                          
    91 : setle  r8b                                        ; 41 0f 9e c0                          
    92 : and    rax, r8                                    ; 4c 21 c0                             
    93 : cmp    rax, 0h                                    ; 48 83 f8 00                          
    94 : cmovne r9, rcx                                    ; 4c 0f 45 c9                          
    95 : mov    r13, qword ptr [rsp + 020h]                ; 4c 8b ac 24 20 00 00 00              
    96 : add    r9, r13                                    ; 4d 01 e9                             
    97 : mov    r13, qword ptr [rsp]                       ; 4c 8b ac 24 00 00 00 00              
    98 : mov    rcx, r13                                   ; 4c 89 e9                             
    99 : imul   rcx, 002h                                  ; 48 6b c9 02                          
   100 : cmp    rcx, qword ptr [rsp + 010h]                ; 48 3b 8c 24 10 00 00 00              
   101 : jl     __loops_label_8                            ; 0f 8c 39 00 00 00                    
   102 : mov    r13, qword ptr [rsp + 010h]                ; 4c 8b ac 24 10 00 00 00              
   103 : mov    rcx, r13                                   ; 4c 89 e9                             
   104 : add    rcx, 003h                                  ; 48 81 c1 03 00 00 00                 
   105 : neg    rcx                                        ; 48 f7 d9                             
   106 : mov    r13, qword ptr [rsp + 010h]                ; 4c 8b ac 24 10 00 00 00              
   107 : mov    rdx, r13                                   ; 4c 89 ea                             
   108 : add    rdx, 003h                                  ; 48 81 c2 03 00 00 00                 
   109 : imul   rcx, rdx                                   ; 48 0f af ca                          
   110 : cmp    qword ptr [rsp], rcx                       ; 48 39 8c 24 00 00 00 00              
   111 : jle    __loops_label_9                            ; 0f 8e 56 00 00 00                    
   112 :        __loops_label_8:                           ;                                      
   113 : mov    r13, qword ptr [rsp + 010h]                ; 4c 8b ac 24 10 00 00 00              
   114 : mov    rcx, r13                                   ; 4c 89 e9                             
   115 : imul   rcx, 002h                                  ; 48 6b c9 02                          
   116 : cmp    qword ptr [rsp], rcx                       ; 48 39 8c 24 00 00 00 00              
   117 : jg     __loops_label_7                            ; 0f 8f 52 00 00 00                    
   118 : mov    r13, qword ptr [rsp + 010h]                ; 4c 8b ac 24 10 00 00 00              
   119 : mov    rcx, r13                                   ; 4c 89 e9                             
   120 : add    rcx, 003h                                  ; 48 81 c1 03 00 00 00                 
   121 : neg    rcx                                        ; 48 f7 d9                             
   122 : mov    r13, qword ptr [rsp + 010h]                ; 4c 8b ac 24 10 00 00 00              
   123 : mov    rdx, r13                                   ; 4c 89 ea                             
   124 : add    rdx, 003h                                  ; 48 81 c2 03 00 00 00                 
   125 : imul   rcx, rdx                                   ; 48 0f af ca                          
   126 : cmp    qword ptr [rsp], rcx                       ; 48 39 8c 24 00 00 00 00              
   127 : jl     __loops_label_7                            ; 0f 8c 19 00 00 00                    
   128 :        __loops_label_9:                           ;                                      
   129 : cmp    qword ptr [rsp + 010h], 0h                 ; 48 81 bc 24 10 00 00 00 00 00 00 00  
   130 : jg     __loops_label_7                            ; 0f 8f 07 00 00 00                    
   131 : add    r9, 003h                                   ; 49 81 c1 03 00 00 00                 
   132 :        __loops_label_7:                           ;                                      
   133 : mov    r13, qword ptr [rsp + 010h]                ; 4c 8b ac 24 10 00 00 00              
   134 : mov    rcx, r13                                   ; 4c 89 e9                             
   135 : add    rcx, 005h                                  ; 48 81 c1 05 00 00 00                 
   136 : shl    rcx, 003h                                  ; 48 c1 e1 03                          
   137 : mov    r13, qword ptr [rsp + 018h]                ; 4c 8b ac 24 18 00 00 00              
   138 : add    rcx, r13                                   ; 4c 01 e9                             
   139 : mov    r13, qword ptr [rsp + 008h]                ; 4c 8b ac 24 08 00 00 00              
   140 : mov    qword ptr [r13 + rcx], r9                  ; 4d 89 4c 0d 00                       
   141 : add    qword ptr [rsp + 010h], 001h               ; 48 81 84 24 10 00 00 00 01 00 00 00  
   142 : jmp    __loops_label_3                            ; e9 51 fd ff ff                       
   143 :        __loops_label_5:                           ;                                      
   144 : add    qword ptr [rsp], 001h                      ; 48 81 84 24 00 00 00 00 01 00 00 00  
   145 : jmp    __loops_label_0                            ; e9 fa fc ff ff                       
   146 :        __loops_label_2:                           ;                                      
   147 : mov    r13, qword ptr [rsp + 028h]                ; 4c 8b ac 24 28 00 00 00              
   148 : add    rsp, 038h                                  ; 48 81 c4 38 00 00 00                 
   149 : ret                                               ; c3                                   
