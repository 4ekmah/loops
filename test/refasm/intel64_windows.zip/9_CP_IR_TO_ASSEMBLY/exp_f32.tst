exp_f32(i0, i1, i2)
     0 : sub          rsp, 01e8h                       ; 48 81 ec e8 01 00 00           
     1 : vmovdqu      ymmword ptr [rsp + 0e0h], ymm6   ; c5 fe 7f b4 24 e0 00 00 00     
     2 : vmovdqu      ymmword ptr [rsp + 0100h], ymm7  ; c5 fe 7f bc 24 00 01 00 00     
     3 : vmovdqu      ymmword ptr [rsp + 0120h], ymm8  ; c5 7e 7f 84 24 20 01 00 00     
     4 : vmovdqu      ymmword ptr [rsp + 0140h], ymm9  ; c5 7e 7f 8c 24 40 01 00 00     
     5 : vmovdqu      ymmword ptr [rsp + 0160h], ymm10 ; c5 7e 7f 94 24 60 01 00 00     
     6 : vmovdqu      ymmword ptr [rsp + 0180h], ymm11 ; c5 7e 7f 9c 24 80 01 00 00     
     7 : vmovdqu      ymmword ptr [rsp + 01a0h], ymm12 ; c5 7e 7f a4 24 a0 01 00 00     
     8 : vmovdqu      ymmword ptr [rsp + 01c0h], ymm13 ; c5 7e 7f ac 24 c0 01 00 00     
     9 : mov          r9, 0c2b0c0a5h                   ; 49 b9 a5 c0 b0 c2 00 00 00 00  
    10 : vpinsrd      xmm0, xmm0, r9d, 0h              ; c4 c3 79 22 c1 00              
    11 : vpbroadcastd ymm0, xmm0                       ; c4 e2 7d 58 c0                 
    12 : mov          r9, 042b0c0a5h                   ; 49 c7 c1 a5 c0 b0 42           
    13 : vpinsrd      xmm1, xmm1, r9d, 0h              ; c4 c3 71 22 c9 00              
    14 : vpbroadcastd ymm1, xmm1                       ; c4 e2 7d 58 c9                 
    15 : mov          r9, 03f000000h                   ; 49 c7 c1 00 00 00 3f           
    16 : vpinsrd      xmm2, xmm2, r9d, 0h              ; c4 c3 69 22 d1 00              
    17 : vpbroadcastd ymm2, xmm2                       ; c4 e2 7d 58 d2                 
    18 : mov          r9, 03f800000h                   ; 49 c7 c1 00 00 80 3f           
    19 : vpinsrd      xmm3, xmm3, r9d, 0h              ; c4 c3 61 22 d9 00              
    20 : vpbroadcastd ymm3, xmm3                       ; c4 e2 7d 58 db                 
    21 : mov          r9, 03fb8aa3bh                   ; 49 c7 c1 3b aa b8 3f           
    22 : vpinsrd      xmm5, xmm5, r9d, 0h              ; c4 c3 51 22 e9 00              
    23 : vpbroadcastd ymm5, xmm5                       ; c4 e2 7d 58 ed                 
    24 : mov          r9, 0bf318000h                   ; 49 b9 00 80 31 bf 00 00 00 00  
    25 : vpinsrd      xmm6, xmm6, r9d, 0h              ; c4 c3 49 22 f1 00              
    26 : vpbroadcastd ymm6, xmm6                       ; c4 e2 7d 58 f6                 
    27 : mov          r9, 0395e8083h                   ; 49 c7 c1 83 80 5e 39           
    28 : vpinsrd      xmm7, xmm7, r9d, 0h              ; c4 c3 41 22 f9 00              
    29 : vpbroadcastd ymm7, xmm7                       ; c4 e2 7d 58 ff                 
    30 : mov          r9, 039506967h                   ; 49 c7 c1 67 69 50 39           
    31 : vpinsrd      xmm8, xmm8, r9d, 0h              ; c4 43 39 22 c1 00              
    32 : vpbroadcastd ymm8, xmm8                       ; c4 42 7d 58 c0                 
    33 : mov          r9, 03ab743ceh                   ; 49 c7 c1 ce 43 b7 3a           
    34 : vpinsrd      xmm9, xmm9, r9d, 0h              ; c4 43 31 22 c9 00              
    35 : vpbroadcastd ymm13, xmm9                      ; c4 42 7d 58 e9                 
    36 : vmovups      ymmword ptr [rsp + 0c0h], ymm13  ; c5 7c 11 ac 24 c0 00 00 00     
    37 : mov          r9, 03c088908h                   ; 49 c7 c1 08 89 08 3c           
    38 : vpinsrd      xmm10, xmm10, r9d, 0h            ; c4 43 29 22 d1 00              
    39 : vpbroadcastd ymm13, xmm10                     ; c4 42 7d 58 ea                 
    40 : vmovups      ymmword ptr [rsp + 0a0h], ymm13  ; c5 7c 11 ac 24 a0 00 00 00     
    41 : mov          r9, 03d2aa9c1h                   ; 49 c7 c1 c1 a9 2a 3d           
    42 : vpinsrd      xmm11, xmm11, r9d, 0h            ; c4 43 21 22 d9 00              
    43 : vpbroadcastd ymm13, xmm11                     ; c4 42 7d 58 eb                 
    44 : vmovups      ymmword ptr [rsp + 080h], ymm13  ; c5 7c 11 ac 24 80 00 00 00     
    45 : mov          r9, 03e2aaaaah                   ; 49 c7 c1 aa aa 2a 3e           
    46 : vpinsrd      xmm12, xmm12, r9d, 0h            ; c4 43 19 22 e1 00              
    47 : vpbroadcastd ymm13, xmm12                     ; c4 42 7d 58 ec                 
    48 : vmovups      ymmword ptr [rsp + 020h], ymm13  ; c5 7c 11 ac 24 20 00 00 00     
    49 : mov          r9, 03f000000h                   ; 49 c7 c1 00 00 00 3f           
    50 : vpinsrd      xmm12, xmm12, r9d, 0h            ; c4 43 19 22 e1 00              
    51 : vpbroadcastd ymm13, xmm12                     ; c4 42 7d 58 ec                 
    52 : vmovups      ymmword ptr [rsp + 040h], ymm13  ; c5 7c 11 ac 24 40 00 00 00     
    53 : mov          r9, 07fh                         ; 49 c7 c1 7f 00 00 00           
    54 : vpinsrd      xmm12, xmm12, r9d, 0h            ; c4 43 19 22 e1 00              
    55 : vpbroadcastd ymm13, xmm12                     ; c4 42 7d 58 ec                 
    56 : vmovdqu      ymmword ptr [rsp + 060h], ymm13  ; c5 7e 7f ac 24 60 00 00 00     
    57 : xor          r9, r9                           ; 4d 31 c9                       
    58 :              __loops_label_0:                 ;                                
    59 : cmp          r8, 0h                           ; 49 83 f8 00                    
    60 : jle          __loops_label_2                  ; 0f 8e 2c 01 00 00              
    61 : vmovups      ymm12, ymmword ptr [rdx + r9]    ; c4 21 7c 10 24 0a              
    62 : vminps       ymm12, ymm12, ymm1               ; c5 1c 5d e1                    
    63 : vmaxps       ymm12, ymm12, ymm0               ; c5 1c 5f e0                    
    64 : vmovups      ymm11, ymm2                      ; c5 7c 10 da                    
    65 : vfmadd231ps  ymm11, ymm12, ymm5               ; c4 62 1d b8 dd                 
    66 : vroundps     ymm11, ymm11, 001h               ; c4 43 7d 08 db 01              
    67 : vcvtps2dq    ymm11, ymm11                     ; c4 41 7d 5b db                 
    68 : vcvtdq2ps    ymm10, ymm11                     ; c4 41 7c 5b d3                 
    69 : vfmadd231ps  ymm12, ymm10, ymm6               ; c4 62 2d b8 e6                 
    70 : vfmadd231ps  ymm12, ymm10, ymm7               ; c4 62 2d b8 e7                 
    71 : vmovups      ymm13, ymmword ptr [rsp + 0c0h]  ; c5 7c 10 ac 24 c0 00 00 00     
    72 : vmovups      ymm10, ymm13                     ; c4 41 7c 10 d5                 
    73 : vfmadd231ps  ymm10, ymm12, ymm8               ; c4 42 1d b8 d0                 
    74 : vmovups      ymm13, ymmword ptr [rsp + 0a0h]  ; c5 7c 10 ac 24 a0 00 00 00     
    75 : vmovups      ymmword ptr [rsp + 0h], ymm0     ; c5 fc 11 84 24 00 00 00 00     
    76 : vmovups      ymm0, ymm10                      ; c4 c1 7c 10 c2                 
    77 : vmovups      ymm10, ymm13                     ; c4 41 7c 10 d5                 
    78 : vfmadd231ps  ymm10, ymm0, ymm12               ; c4 42 7d b8 d4                 
    79 : vmovups      ymm0, ymmword ptr [rsp + 0h]     ; c5 fc 10 84 24 00 00 00 00     
    80 : vmovups      ymm13, ymmword ptr [rsp + 080h]  ; c5 7c 10 ac 24 80 00 00 00     
    81 : vmovups      ymmword ptr [rsp + 0h], ymm0     ; c5 fc 11 84 24 00 00 00 00     
    82 : vmovups      ymm0, ymm10                      ; c4 c1 7c 10 c2                 
    83 : vmovups      ymm10, ymm13                     ; c4 41 7c 10 d5                 
    84 : vfmadd231ps  ymm10, ymm0, ymm12               ; c4 42 7d b8 d4                 
    85 : vmovups      ymm0, ymmword ptr [rsp + 0h]     ; c5 fc 10 84 24 00 00 00 00     
    86 : vmovups      ymm13, ymmword ptr [rsp + 020h]  ; c5 7c 10 ac 24 20 00 00 00     
    87 : vmovups      ymmword ptr [rsp + 0h], ymm0     ; c5 fc 11 84 24 00 00 00 00     
    88 : vmovups      ymm0, ymm10                      ; c4 c1 7c 10 c2                 
    89 : vmovups      ymm10, ymm13                     ; c4 41 7c 10 d5                 
    90 : vfmadd231ps  ymm10, ymm0, ymm12               ; c4 42 7d b8 d4                 
    91 : vmovups      ymm0, ymmword ptr [rsp + 0h]     ; c5 fc 10 84 24 00 00 00 00     
    92 : vmovups      ymm13, ymmword ptr [rsp + 040h]  ; c5 7c 10 ac 24 40 00 00 00     
    93 : vmovups      ymmword ptr [rsp + 0h], ymm0     ; c5 fc 11 84 24 00 00 00 00     
    94 : vmovups      ymm0, ymm10                      ; c4 c1 7c 10 c2                 
    95 : vmovups      ymm10, ymm13                     ; c4 41 7c 10 d5                 
    96 : vfmadd231ps  ymm10, ymm0, ymm12               ; c4 42 7d b8 d4                 
    97 : vmovups      ymm0, ymmword ptr [rsp + 0h]     ; c5 fc 10 84 24 00 00 00 00     
    98 : vmulps       ymm9, ymm12, ymm12               ; c4 41 1c 59 cc                 
    99 : vfmadd231ps  ymm12, ymm10, ymm9               ; c4 42 2d b8 e1                 
   100 : vaddps       ymm9, ymm12, ymm3                ; c5 1c 58 cb                    
   101 : vmovdqu      ymm13, ymmword ptr [rsp + 060h]  ; c5 7e 6f ac 24 60 00 00 00     
   102 : vpaddd       ymm10, ymm11, ymm13              ; c4 41 25 fe d5                 
   103 : vpslld       ymm10, ymm10, 017h               ; c4 c1 2d 72 f2 17              
   104 : vmulps       ymm9, ymm9, ymm10                ; c4 41 34 59 ca                 
   105 : vmovups      ymmword ptr [rcx + r9], ymm9     ; c4 21 7c 11 0c 09              
   106 : add          r9, 020h                         ; 49 81 c1 20 00 00 00           
   107 : sub          r8, 008h                         ; 49 81 e8 08 00 00 00           
   108 : jmp          __loops_label_0                  ; e9 ca fe ff ff                 
   109 :              __loops_label_2:                 ;                                
   110 : vmovdqu      ymm6, ymmword ptr [rsp + 0e0h]   ; c5 fe 6f b4 24 e0 00 00 00     
   111 : vmovdqu      ymm7, ymmword ptr [rsp + 0100h]  ; c5 fe 6f bc 24 00 01 00 00     
   112 : vmovdqu      ymm8, ymmword ptr [rsp + 0120h]  ; c5 7e 6f 84 24 20 01 00 00     
   113 : vmovdqu      ymm9, ymmword ptr [rsp + 0140h]  ; c5 7e 6f 8c 24 40 01 00 00     
   114 : vmovdqu      ymm10, ymmword ptr [rsp + 0160h] ; c5 7e 6f 94 24 60 01 00 00     
   115 : vmovdqu      ymm11, ymmword ptr [rsp + 0180h] ; c5 7e 6f 9c 24 80 01 00 00     
   116 : vmovdqu      ymm12, ymmword ptr [rsp + 01a0h] ; c5 7e 6f a4 24 a0 01 00 00     
   117 : vmovdqu      ymm13, ymmword ptr [rsp + 01c0h] ; c5 7e 6f ac 24 c0 01 00 00     
   118 : add          rsp, 01e8h                       ; 48 81 c4 e8 01 00 00           
   119 : ret                                           ; c3                             
