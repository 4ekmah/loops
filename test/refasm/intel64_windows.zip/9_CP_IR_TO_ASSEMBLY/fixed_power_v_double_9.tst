fixed_power_v_double_9(i0, i1, i2)
     0 : xor     r9, r9                       ; 4d 31 c9              
     1 : imul    r8, 008h                     ; 4d 6b c0 08           
     2 :         __loops_label_0:             ;                       
     3 : cmp     r9, r8                       ; 4d 39 c1              
     4 : jge     __loops_label_2              ; 0f 8d 28 00 00 00     
     5 : vmovupd ymm0, ymmword ptr [rcx + r9] ; c4 a1 7d 10 04 09     
     6 : vmulpd  ymm1, ymm0, ymm0             ; c5 fd 59 c8           
     7 : vmulpd  ymm1, ymm1, ymm1             ; c5 f5 59 c9           
     8 : vmulpd  ymm1, ymm1, ymm1             ; c5 f5 59 c9           
     9 : vmulpd  ymm0, ymm0, ymm1             ; c5 fd 59 c1           
    10 : vmovupd ymmword ptr [rdx + r9], ymm0 ; c4 a1 7d 11 04 0a     
    11 : add     r9, 020h                     ; 49 81 c1 20 00 00 00  
    12 : jmp     __loops_label_0              ; e9 cf ff ff ff        
    13 :         __loops_label_2:             ;                       
    14 : xor     rax, rax                     ; 48 31 c0              
    15 : ret                                  ; c3                    
