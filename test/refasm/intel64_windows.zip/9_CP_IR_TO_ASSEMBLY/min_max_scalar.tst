min_max_scalar(i0, i1, i2, i3)
     0 : sub    rsp, 058h                   ; 48 81 ec 58 00 00 00                 
     1 : mov    qword ptr [rsp + 048h], r13 ; 4c 89 ac 24 48 00 00 00              
     2 : mov    qword ptr [rsp + 028h], r8  ; 4c 89 84 24 28 00 00 00              
     3 : mov    qword ptr [rsp + 020h], r9  ; 4c 89 8c 24 20 00 00 00              
     4 : xor    rax, rax                    ; 48 31 c0                             
     5 : mov    qword ptr [rsp + 038h], 0h  ; 48 c7 84 24 38 00 00 00 00 00 00 00  
     6 : mov    qword ptr [rsp + 030h], 0h  ; 48 c7 84 24 30 00 00 00 00 00 00 00  
     7 : movsxd r8, dword ptr [rcx]         ; 4c 63 01                             
     8 : mov    r9, r8                      ; 4d 89 c1                             
     9 : mov    r13, rdx                    ; 49 89 d5                             
    10 : imul   r13, 004h                   ; 4d 6b ed 04                          
    11 : mov    qword ptr [rsp + 040h], r13 ; 4c 89 ac 24 40 00 00 00              
    12 :        __loops_label_0:            ;                                      
    13 : cmp    rax, qword ptr [rsp + 040h] ; 48 3b 84 24 40 00 00 00              
    14 : jge    __loops_label_2             ; 0f 8d 37 00 00 00                    
    15 : movsxd rdx, dword ptr [rcx + rax]  ; 48 63 14 01                          
    16 : cmp    rdx, r8                     ; 4c 39 c2                             
    17 : jge    __loops_label_4             ; 0f 8d 0b 00 00 00                    
    18 : mov    r8, rdx                     ; 49 89 d0                             
    19 : mov    qword ptr [rsp + 038h], rax ; 48 89 84 24 38 00 00 00              
    20 :        __loops_label_4:            ;                                      
    21 : cmp    rdx, r9                     ; 4c 39 ca                             
    22 : jle    __loops_label_6             ; 0f 8e 0b 00 00 00                    
    23 : mov    r9, rdx                     ; 49 89 d1                             
    24 : mov    qword ptr [rsp + 030h], rax ; 48 89 84 24 30 00 00 00              
    25 :        __loops_label_6:            ;                                      
    26 : add    rax, 004h                   ; 48 05 04 00 00 00                    
    27 : jmp    __loops_label_0             ; e9 bb ff ff ff                       
    28 :        __loops_label_2:            ;                                      
    29 : mov    rcx, 004h                   ; 48 c7 c1 04 00 00 00                 
    30 : mov    r13, qword ptr [rsp + 038h] ; 4c 8b ac 24 38 00 00 00              
    31 : mov    qword ptr [rsp], rax        ; 48 89 84 24 00 00 00 00              
    32 : mov    rax, r13                    ; 4c 89 e8                             
    33 : cqo                                ; 48 99                                
    34 : idiv   rcx                         ; 48 f7 f9                             
    35 : mov    rdx, rax                    ; 48 89 c2                             
    36 : mov    rax, qword ptr [rsp]        ; 48 8b 84 24 00 00 00 00              
    37 : mov    r13, qword ptr [rsp + 030h] ; 4c 8b ac 24 30 00 00 00              
    38 : mov    qword ptr [rsp], rax        ; 48 89 84 24 00 00 00 00              
    39 : mov    qword ptr [rsp + 008h], rdx ; 48 89 94 24 08 00 00 00              
    40 : mov    rax, r13                    ; 4c 89 e8                             
    41 : cqo                                ; 48 99                                
    42 : idiv   rcx                         ; 48 f7 f9                             
    43 : mov    rcx, rax                    ; 48 89 c1                             
    44 : mov    rax, qword ptr [rsp]        ; 48 8b 84 24 00 00 00 00              
    45 : mov    rdx, qword ptr [rsp + 008h] ; 48 8b 94 24 08 00 00 00              
    46 : mov    r13, qword ptr [rsp + 028h] ; 4c 8b ac 24 28 00 00 00              
    47 : mov    dword ptr [r13], edx        ; 41 89 55 00                          
    48 : mov    r13, qword ptr [rsp + 020h] ; 4c 8b ac 24 20 00 00 00              
    49 : mov    dword ptr [r13], ecx        ; 41 89 4d 00                          
    50 : xor    rax, rax                    ; 48 31 c0                             
    51 : mov    r13, qword ptr [rsp + 048h] ; 4c 8b ac 24 48 00 00 00              
    52 : add    rsp, 058h                   ; 48 81 c4 58 00 00 00                 
    53 : ret                                ; c3                                   
