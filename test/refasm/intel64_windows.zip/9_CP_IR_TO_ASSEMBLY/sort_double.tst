sort_double(i0, i1)
     0 : sub     rsp, 0278h                       ; 48 81 ec 78 02 00 00                 
     1 : mov     qword ptr [rsp + 0258h], rcx     ; 48 89 8c 24 58 02 00 00              
     2 : mov     qword ptr [rsp + 0260h], r13     ; 4c 89 ac 24 60 02 00 00              
     3 : mov     qword ptr [rsp + 0268h], r14     ; 4c 89 b4 24 68 02 00 00              
     4 : mov     qword ptr [rsp + 0270h], rbp     ; 48 89 ac 24 70 02 00 00              
     5 : mov     rbp, rsp                         ; 48 89 e5                             
     6 : add     rbp, 0270h                       ; 48 81 c5 70 02 00 00                 
     7 : mov     qword ptr [rsp + 0250h], rdx     ; 48 89 94 24 50 02 00 00              
     8 : shl     qword ptr [rsp + 0250h], 003h    ; 48 c1 a4 24 50 02 00 00 03           
     9 : mov     r13, qword ptr [rsp + 0250h]     ; 4c 8b ac 24 50 02 00 00              
    10 : mov     qword ptr [rsp + 0248h], r13     ; 4c 89 ac 24 48 02 00 00              
    11 : sub     qword ptr [rsp + 0248h], 008h    ; 48 81 ac 24 48 02 00 00 08 00 00 00  
    12 : mov     qword ptr [rsp + 0240h], 0h      ; 48 c7 84 24 40 02 00 00 00 00 00 00  
    13 :         __loops_label_0:                 ;                                      
    14 : mov     r13, qword ptr [rsp + 0248h]     ; 4c 8b ac 24 48 02 00 00              
    15 : cmp     qword ptr [rsp + 0240h], r13     ; 4c 39 ac 24 40 02 00 00              
    16 : jge     __loops_label_2                  ; 0f 8d 55 02 00 00                    
    17 : mov     rax, qword ptr [rsp + 0240h]     ; 48 8b 84 24 40 02 00 00              
    18 : mov     r9, rax                          ; 49 89 c1                             
    19 : add     r9, 008h                         ; 49 81 c1 08 00 00 00                 
    20 :         __loops_label_3:                 ;                                      
    21 : cmp     r9, qword ptr [rsp + 0250h]      ; 4c 3b 8c 24 50 02 00 00              
    22 : jge     __loops_label_5                  ; 0f 8d d2 01 00 00                    
    23 : mov     r13, qword ptr [rsp + 0258h]     ; 4c 8b ac 24 58 02 00 00              
    24 : mov     r8, qword ptr [r13 + r9]         ; 4f 8b 44 0d 00                       
    25 : mov     r13, qword ptr [rsp + 0258h]     ; 4c 8b ac 24 58 02 00 00              
    26 : mov     rdx, qword ptr [r13 + rax]       ; 49 8b 54 05 00                       
    27 : mov     rcx, 07ff79e6c3bc0h              ; 48 b9 c0 3b 6c 9e f7 7f 00 00        
    28 : mov     qword ptr [rsp], rax             ; 48 89 84 24 00 00 00 00              
    29 : mov     qword ptr [rsp + 008h], rcx      ; 48 89 8c 24 08 00 00 00              
    30 : mov     qword ptr [rsp + 010h], rdx      ; 48 89 94 24 10 00 00 00              
    31 : mov     qword ptr [rsp + 018h], r8       ; 4c 89 84 24 18 00 00 00              
    32 : mov     qword ptr [rsp + 020h], r9       ; 4c 89 8c 24 20 00 00 00              
    33 : mov     qword ptr [rsp + 028h], r10      ; 4c 89 94 24 28 00 00 00              
    34 : mov     qword ptr [rsp + 030h], r11      ; 4c 89 9c 24 30 00 00 00              
    35 : vmovdqu ymmword ptr [rsp + 040h], ymm0   ; c5 fe 7f 84 24 40 00 00 00           
    36 : vmovdqu ymmword ptr [rsp + 060h], ymm1   ; c5 fe 7f 8c 24 60 00 00 00           
    37 : vmovdqu ymmword ptr [rsp + 080h], ymm2   ; c5 fe 7f 94 24 80 00 00 00           
    38 : vmovdqu ymmword ptr [rsp + 0a0h], ymm3   ; c5 fe 7f 9c 24 a0 00 00 00           
    39 : vmovdqu ymmword ptr [rsp + 0c0h], ymm5   ; c5 fe 7f ac 24 c0 00 00 00           
    40 : vmovdqu ymmword ptr [rsp + 0e0h], ymm6   ; c5 fe 7f b4 24 e0 00 00 00           
    41 : vmovdqu ymmword ptr [rsp + 0100h], ymm7  ; c5 fe 7f bc 24 00 01 00 00           
    42 : vmovdqu ymmword ptr [rsp + 0120h], ymm8  ; c5 7e 7f 84 24 20 01 00 00           
    43 : vmovdqu ymmword ptr [rsp + 0140h], ymm9  ; c5 7e 7f 8c 24 40 01 00 00           
    44 : vmovdqu ymmword ptr [rsp + 0160h], ymm10 ; c5 7e 7f 94 24 60 01 00 00           
    45 : vmovdqu ymmword ptr [rsp + 0180h], ymm11 ; c5 7e 7f 9c 24 80 01 00 00           
    46 : vmovdqu ymmword ptr [rsp + 01a0h], ymm12 ; c5 7e 7f a4 24 a0 01 00 00           
    47 : vmovdqu ymmword ptr [rsp + 01c0h], ymm13 ; c5 7e 7f ac 24 c0 01 00 00           
    48 : vmovdqu ymmword ptr [rsp + 01e0h], ymm14 ; c5 7e 7f b4 24 e0 01 00 00           
    49 : vmovdqu ymmword ptr [rsp + 0200h], ymm15 ; c5 7e 7f bc 24 00 02 00 00           
    50 : mov     rcx, r8                          ; 4c 89 c1                             
    51 : mov     r10, qword ptr [rsp + 008h]      ; 4c 8b 94 24 08 00 00 00              
    52 : sub     rsp, 020h                        ; 48 81 ec 20 00 00 00                 
    53 : call    r10                              ; 41 ff d2                             
    54 : add     rsp, 020h                        ; 48 81 c4 20 00 00 00                 
    55 : mov     rcx, rax                         ; 48 89 c1                             
    56 : mov     rax, qword ptr [rsp]             ; 48 8b 84 24 00 00 00 00              
    57 : mov     rdx, qword ptr [rsp + 010h]      ; 48 8b 94 24 10 00 00 00              
    58 : mov     r8, qword ptr [rsp + 018h]       ; 4c 8b 84 24 18 00 00 00              
    59 : mov     r9, qword ptr [rsp + 020h]       ; 4c 8b 8c 24 20 00 00 00              
    60 : mov     r10, qword ptr [rsp + 028h]      ; 4c 8b 94 24 28 00 00 00              
    61 : mov     r11, qword ptr [rsp + 030h]      ; 4c 8b 9c 24 30 00 00 00              
    62 : vmovdqu ymm0, ymmword ptr [rsp + 040h]   ; c5 fe 6f 84 24 40 00 00 00           
    63 : vmovdqu ymm1, ymmword ptr [rsp + 060h]   ; c5 fe 6f 8c 24 60 00 00 00           
    64 : vmovdqu ymm2, ymmword ptr [rsp + 080h]   ; c5 fe 6f 94 24 80 00 00 00           
    65 : vmovdqu ymm3, ymmword ptr [rsp + 0a0h]   ; c5 fe 6f 9c 24 a0 00 00 00           
    66 : vmovdqu ymm5, ymmword ptr [rsp + 0c0h]   ; c5 fe 6f ac 24 c0 00 00 00           
    67 : vmovdqu ymm6, ymmword ptr [rsp + 0e0h]   ; c5 fe 6f b4 24 e0 00 00 00           
    68 : vmovdqu ymm7, ymmword ptr [rsp + 0100h]  ; c5 fe 6f bc 24 00 01 00 00           
    69 : vmovdqu ymm8, ymmword ptr [rsp + 0120h]  ; c5 7e 6f 84 24 20 01 00 00           
    70 : vmovdqu ymm9, ymmword ptr [rsp + 0140h]  ; c5 7e 6f 8c 24 40 01 00 00           
    71 : vmovdqu ymm10, ymmword ptr [rsp + 0160h] ; c5 7e 6f 94 24 60 01 00 00           
    72 : vmovdqu ymm11, ymmword ptr [rsp + 0180h] ; c5 7e 6f 9c 24 80 01 00 00           
    73 : vmovdqu ymm12, ymmword ptr [rsp + 01a0h] ; c5 7e 6f a4 24 a0 01 00 00           
    74 : vmovdqu ymm13, ymmword ptr [rsp + 01c0h] ; c5 7e 6f ac 24 c0 01 00 00           
    75 : vmovdqu ymm14, ymmword ptr [rsp + 01e0h] ; c5 7e 6f b4 24 e0 01 00 00           
    76 : vmovdqu ymm15, ymmword ptr [rsp + 0200h] ; c5 7e 6f bc 24 00 02 00 00           
    77 : cmp     rcx, 0h                          ; 48 83 f9 00                          
    78 : je      __loops_label_7                  ; 0f 84 03 00 00 00                    
    79 : mov     rax, r9                          ; 4c 89 c8                             
    80 :         __loops_label_7:                 ;                                      
    81 : add     r9, 008h                         ; 49 81 c1 08 00 00 00                 
    82 : jmp     __loops_label_3                  ; e9 20 fe ff ff                       
    83 :         __loops_label_5:                 ;                                      
    84 : cmp     rax, qword ptr [rsp + 0240h]     ; 48 3b 84 24 40 02 00 00              
    85 : je      __loops_label_9                  ; 0f 84 44 00 00 00                    
    86 : mov     r13, qword ptr [rsp + 0258h]     ; 4c 8b ac 24 58 02 00 00              
    87 : mov     r14, qword ptr [rsp + 0240h]     ; 4c 8b b4 24 40 02 00 00              
    88 : mov     rcx, qword ptr [r13 + r14]       ; 4b 8b 4c 35 00                       
    89 : mov     r13, qword ptr [rsp + 0258h]     ; 4c 8b ac 24 58 02 00 00              
    90 : mov     rdx, qword ptr [r13 + rax]       ; 49 8b 54 05 00                       
    91 : mov     r13, qword ptr [rsp + 0258h]     ; 4c 8b ac 24 58 02 00 00              
    92 : mov     qword ptr [r13 + rax], rcx       ; 49 89 4c 05 00                       
    93 : mov     r13, qword ptr [rsp + 0258h]     ; 4c 8b ac 24 58 02 00 00              
    94 : mov     r14, qword ptr [rsp + 0240h]     ; 4c 8b b4 24 40 02 00 00              
    95 : mov     qword ptr [r13 + r14], rdx       ; 4b 89 54 35 00                       
    96 :         __loops_label_9:                 ;                                      
    97 : add     qword ptr [rsp + 0240h], 008h    ; 48 81 84 24 40 02 00 00 08 00 00 00  
    98 : jmp     __loops_label_0                  ; e9 95 fd ff ff                       
    99 :         __loops_label_2:                 ;                                      
   100 : mov     rbp, qword ptr [rsp + 0270h]     ; 48 8b ac 24 70 02 00 00              
   101 : mov     r13, qword ptr [rsp + 0260h]     ; 4c 8b ac 24 60 02 00 00              
   102 : mov     r14, qword ptr [rsp + 0268h]     ; 4c 8b b4 24 68 02 00 00              
   103 : add     rsp, 0278h                       ; 48 81 c4 78 02 00 00                 
   104 : ret                                      ; c3                                   
