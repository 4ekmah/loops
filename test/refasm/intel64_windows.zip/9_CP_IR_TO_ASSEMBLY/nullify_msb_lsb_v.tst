nullify_msb_lsb_v(i0, i1, i2, i3)
     0 : sub          rsp, 018h                     ; 48 81 ec 18 00 00 00     
     1 : mov          qword ptr [rsp + 008h], r13   ; 4c 89 ac 24 08 00 00 00  
     2 : xor          rax, rax                      ; 48 31 c0                 
     3 : mov          r13, r9                       ; 4d 89 cd                 
     4 : imul         r13, 004h                     ; 4d 6b ed 04              
     5 : mov          qword ptr [rsp], r13          ; 4c 89 ac 24 00 00 00 00  
     6 : mov          r9, 001h                      ; 49 c7 c1 01 00 00 00     
     7 : vpinsrd      xmm0, xmm0, r9d, 0h           ; c4 c3 79 22 c1 00        
     8 : vpbroadcastd ymm0, xmm0                    ; c4 e2 7d 58 c0           
     9 :              __loops_label_0:              ;                          
    10 : cmp          rax, qword ptr [rsp]          ; 48 3b 84 24 00 00 00 00  
    11 : jge          __loops_label_2               ; 0f 8d 77 00 00 00        
    12 : vmovdqu      ymm1, ymmword ptr [rcx + rax] ; c5 fe 6f 0c 01           
    13 : vpsrld       ymm2, ymm1, 001h              ; c5 ed 72 d1 01           
    14 : vpor         ymm2, ymm1, ymm2              ; c5 f5 eb d2              
    15 : vpsrld       ymm3, ymm2, 002h              ; c5 e5 72 d2 02           
    16 : vpor         ymm2, ymm2, ymm3              ; c5 ed eb d3              
    17 : vpsrld       ymm3, ymm2, 004h              ; c5 e5 72 d2 04           
    18 : vpor         ymm2, ymm2, ymm3              ; c5 ed eb d3              
    19 : vpsrld       ymm3, ymm2, 008h              ; c5 e5 72 d2 08           
    20 : vpor         ymm2, ymm2, ymm3              ; c5 ed eb d3              
    21 : vpsrld       ymm3, ymm2, 010h              ; c5 e5 72 d2 10           
    22 : vpor         ymm2, ymm2, ymm3              ; c5 ed eb d3              
    23 : vpaddd       ymm2, ymm2, ymm0              ; c5 ed fe d0              
    24 : vpsrld       ymm2, ymm2, 001h              ; c5 ed 72 d2 01           
    25 : vpxor        ymm2, ymm2, ymm1              ; c5 ed ef d1              
    26 : vmovdqu      ymmword ptr [rdx + rax], ymm2 ; c5 fe 7f 14 02           
    27 : vpsubd       ymm2, ymm1, ymm0              ; c5 f5 fa d0              
    28 : mov          r9, 0ffh                      ; 49 c7 c1 ff 00 00 00     
    29 : vpinsrb      xmm3, xmm3, r9d, 0h           ; c4 c3 61 20 d9 00        
    30 : vpbroadcastb ymm3, xmm3                    ; c4 e2 7d 78 db           
    31 : vpxor        ymm2, ymm2, ymm3              ; c5 ed ef d3              
    32 : vpand        ymm2, ymm1, ymm2              ; c5 f5 db d2              
    33 : vpxor        ymm1, ymm2, ymm1              ; c5 ed ef c9              
    34 : vmovdqu      ymmword ptr [r8 + rax], ymm1  ; c4 c1 7e 7f 0c 00        
    35 : add          rax, 020h                     ; 48 05 20 00 00 00        
    36 : jmp          __loops_label_0               ; e9 7b ff ff ff           
    37 :              __loops_label_2:              ;                          
    38 : mov          r13, qword ptr [rsp + 008h]   ; 4c 8b ac 24 08 00 00 00  
    39 : add          rsp, 018h                     ; 48 81 c4 18 00 00 00     
    40 : ret                                        ; c3                       
