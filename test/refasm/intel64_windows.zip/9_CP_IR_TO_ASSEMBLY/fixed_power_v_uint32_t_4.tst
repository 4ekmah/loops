fixed_power_v_uint32_t_4(i0, i1, i2)
     0 : xor     r9, r9                       ; 4d 31 c9              
     1 : imul    r8, 004h                     ; 4d 6b c0 04           
     2 :         __loops_label_0:             ;                       
     3 : cmp     r9, r8                       ; 4d 39 c1              
     4 : jge     __loops_label_2              ; 0f 8d 22 00 00 00     
     5 : vmovdqu ymm0, ymmword ptr [rcx + r9] ; c4 a1 7e 6f 04 09     
     6 : vpmulld ymm0, ymm0, ymm0             ; c4 e2 7d 40 c0        
     7 : vpmulld ymm0, ymm0, ymm0             ; c4 e2 7d 40 c0        
     8 : vmovdqu ymmword ptr [rdx + r9], ymm0 ; c4 a1 7e 7f 04 0a     
     9 : add     r9, 020h                     ; 49 81 c1 20 00 00 00  
    10 : jmp     __loops_label_0              ; e9 d5 ff ff ff        
    11 :         __loops_label_2:             ;                       
    12 : xor     rax, rax                     ; 48 31 c0              
    13 : ret                                  ; c3                    
