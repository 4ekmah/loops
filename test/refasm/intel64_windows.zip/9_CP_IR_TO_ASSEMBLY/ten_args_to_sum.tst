ten_args_to_sum(i0, i1, i2, i3, i4, i5, i6, i7, i8, i9)
     0 : sub  rsp, 008h                   ; 48 81 ec 08 00 00 00     
     1 : mov  qword ptr [rsp], r13        ; 4c 89 ac 24 00 00 00 00  
     2 : mov  rax, qword ptr [rsp + 030h] ; 48 8b 84 24 30 00 00 00  
     3 : imul rcx, 001h                   ; 48 6b c9 01              
     4 : imul rdx, 002h                   ; 48 6b d2 02              
     5 : add  rcx, rdx                    ; 48 01 d1                 
     6 : imul r8, 003h                    ; 4d 6b c0 03              
     7 : add  rcx, r8                     ; 4c 01 c1                 
     8 : imul r9, 004h                    ; 4d 6b c9 04              
     9 : add  rcx, r9                     ; 4c 01 c9                 
    10 : imul rax, 005h                   ; 48 6b c0 05              
    11 : add  rcx, rax                    ; 48 01 c1                 
    12 : mov  r13, qword ptr [rsp + 038h] ; 4c 8b ac 24 38 00 00 00  
    13 : mov  rdx, r13                    ; 4c 89 ea                 
    14 : imul rdx, 006h                   ; 48 6b d2 06              
    15 : add  rcx, rdx                    ; 48 01 d1                 
    16 : mov  r13, qword ptr [rsp + 040h] ; 4c 8b ac 24 40 00 00 00  
    17 : mov  rdx, r13                    ; 4c 89 ea                 
    18 : imul rdx, 007h                   ; 48 6b d2 07              
    19 : add  rcx, rdx                    ; 48 01 d1                 
    20 : mov  r13, qword ptr [rsp + 048h] ; 4c 8b ac 24 48 00 00 00  
    21 : mov  rdx, r13                    ; 4c 89 ea                 
    22 : imul rdx, 008h                   ; 48 6b d2 08              
    23 : add  rcx, rdx                    ; 48 01 d1                 
    24 : mov  r13, qword ptr [rsp + 050h] ; 4c 8b ac 24 50 00 00 00  
    25 : mov  rdx, r13                    ; 4c 89 ea                 
    26 : imul rdx, 003h                   ; 48 6b d2 03              
    27 : add  rcx, rdx                    ; 48 01 d1                 
    28 : mov  r13, qword ptr [rsp + 058h] ; 4c 8b ac 24 58 00 00 00  
    29 : mov  rdx, r13                    ; 4c 89 ea                 
    30 : imul rdx, 002h                   ; 48 6b d2 02              
    31 : add  rcx, rdx                    ; 48 01 d1                 
    32 : mov  rax, rcx                    ; 48 89 c8                 
    33 : mov  r13, qword ptr [rsp]        ; 4c 8b ac 24 00 00 00 00  
    34 : add  rsp, 008h                   ; 48 81 c4 08 00 00 00     
    35 : ret                              ; c3                       
