snake(i0, i1, i2)
     0 : sub     rsp, 0298h                       ; 48 81 ec 98 02 00 00                 
     1 : mov     qword ptr [rsp + 0278h], rcx     ; 48 89 8c 24 78 02 00 00              
     2 : mov     qword ptr [rsp + 0270h], rdx     ; 48 89 94 24 70 02 00 00              
     3 : mov     qword ptr [rsp + 0268h], r8      ; 4c 89 84 24 68 02 00 00              
     4 : mov     qword ptr [rsp + 0280h], r13     ; 4c 89 ac 24 80 02 00 00              
     5 : mov     qword ptr [rsp + 0288h], r14     ; 4c 89 b4 24 88 02 00 00              
     6 : mov     qword ptr [rsp + 0290h], rbp     ; 48 89 ac 24 90 02 00 00              
     7 : mov     rbp, rsp                         ; 48 89 e5                             
     8 : add     rbp, 0290h                       ; 48 81 c5 90 02 00 00                 
     9 : mov     r13, qword ptr [rsp + 0270h]     ; 4c 8b ac 24 70 02 00 00              
    10 : mov     r9, r13                          ; 4d 89 e9                             
    11 : add     r9, qword ptr [rsp + 0268h]      ; 4c 03 8c 24 68 02 00 00              
    12 : mov     qword ptr [rsp + 0260h], r9      ; 4c 89 8c 24 60 02 00 00              
    13 : sub     qword ptr [rsp + 0260h], 001h    ; 48 81 ac 24 60 02 00 00 01 00 00 00  
    14 : mov     qword ptr [rsp + 0258h], 0h      ; 48 c7 84 24 58 02 00 00 00 00 00 00  
    15 : mov     qword ptr [rsp + 0240h], 001h    ; 48 c7 84 24 40 02 00 00 01 00 00 00  
    16 : mov     r13, qword ptr [rsp + 0240h]     ; 4c 8b ac 24 40 02 00 00              
    17 : neg     r13                              ; 49 f7 dd                             
    18 : mov     qword ptr [rsp + 0248h], r13     ; 4c 89 ac 24 48 02 00 00              
    19 : mov     qword ptr [rsp + 0250h], 0h      ; 48 c7 84 24 50 02 00 00 00 00 00 00  
    20 :         __loops_label_0:                 ;                                      
    21 : mov     r13, qword ptr [rsp + 0260h]     ; 4c 8b ac 24 60 02 00 00              
    22 : cmp     qword ptr [rsp + 0250h], r13     ; 4c 39 ac 24 50 02 00 00              
    23 : jge     __loops_label_2                  ; 0f 8d ec 02 00 00                    
    24 : xor     rax, rax                         ; 48 31 c0                             
    25 : xor     r9, r9                           ; 4d 31 c9                             
    26 : mov     r13, qword ptr [rsp + 0250h]     ; 4c 8b ac 24 50 02 00 00              
    27 : mov     r8, r13                          ; 4d 89 e8                             
    28 : and     r8, 001h                         ; 49 81 e0 01 00 00 00                 
    29 : cmp     r8, 0h                           ; 49 83 f8 00                          
    30 : je      __loops_label_4                  ; 0f 84 49 00 00 00                    
    31 : mov     r13, qword ptr [rsp + 0268h]     ; 4c 8b ac 24 68 02 00 00              
    32 : mov     r8, r13                          ; 4d 89 e8                             
    33 : sub     r8, 001h                         ; 49 81 e8 01 00 00 00                 
    34 : mov     r13, qword ptr [rsp + 0250h]     ; 4c 8b ac 24 50 02 00 00              
    35 : mov     rax, r13                         ; 4c 89 e8                             
    36 : cmp     rax, r8                          ; 4c 39 c0                             
    37 : cmovg   rax, r8                          ; 49 0f 4f c0                          
    38 : mov     r13, qword ptr [rsp + 0250h]     ; 4c 8b ac 24 50 02 00 00              
    39 : mov     rdx, r13                         ; 4c 89 ea                             
    40 : sub     rdx, r8                          ; 4c 29 c2                             
    41 : xor     rcx, rcx                         ; 48 31 c9                             
    42 : cmp     qword ptr [rsp + 0250h], r8      ; 4c 39 84 24 50 02 00 00              
    43 : mov     r9, rcx                          ; 49 89 c9                             
    44 : cmovg   r9, rdx                          ; 4c 0f 4f ca                          
    45 : jmp     __loops_label_6                  ; e9 44 00 00 00                       
    46 :         __loops_label_4:                 ;                                      
    47 : mov     r13, qword ptr [rsp + 0270h]     ; 4c 8b ac 24 70 02 00 00              
    48 : mov     rcx, r13                         ; 4c 89 e9                             
    49 : sub     rcx, 001h                        ; 48 81 e9 01 00 00 00                 
    50 : mov     r13, qword ptr [rsp + 0250h]     ; 4c 8b ac 24 50 02 00 00              
    51 : mov     rdx, r13                         ; 4c 89 ea                             
    52 : sub     rdx, rcx                         ; 48 29 ca                             
    53 : xor     r8, r8                           ; 4d 31 c0                             
    54 : cmp     qword ptr [rsp + 0250h], rcx     ; 48 39 8c 24 50 02 00 00              
    55 : mov     rax, r8                          ; 4c 89 c0                             
    56 : cmovg   rax, rdx                         ; 48 0f 4f c2                          
    57 : mov     r13, qword ptr [rsp + 0250h]     ; 4c 8b ac 24 50 02 00 00              
    58 : mov     r9, r13                          ; 4d 89 e9                             
    59 : cmp     r9, rcx                          ; 49 39 c9                             
    60 : cmovg   r9, rcx                          ; 4c 0f 4f c9                          
    61 :         __loops_label_5:                 ;                                      
    62 :         __loops_label_6:                 ;                                      
    63 : cmp     rax, 0h                          ; 48 83 f8 00                          
    64 : jl      __loops_label_8                  ; 0f 8c 12 02 00 00                    
    65 : cmp     rax, qword ptr [rsp + 0268h]     ; 48 3b 84 24 68 02 00 00              
    66 : jge     __loops_label_8                  ; 0f 8d 04 02 00 00                    
    67 : cmp     r9, 0h                           ; 49 83 f9 00                          
    68 : jl      __loops_label_8                  ; 0f 8c fa 01 00 00                    
    69 : cmp     r9, qword ptr [rsp + 0270h]      ; 4c 3b 8c 24 70 02 00 00              
    70 : jge     __loops_label_8                  ; 0f 8d ec 01 00 00                    
    71 : mov     rcx, 07ff62e631ff0h              ; 48 b9 f0 1f 63 2e f6 7f 00 00        
    72 : mov     qword ptr [rsp], rax             ; 48 89 84 24 00 00 00 00              
    73 : mov     qword ptr [rsp + 008h], rcx      ; 48 89 8c 24 08 00 00 00              
    74 : mov     qword ptr [rsp + 010h], rdx      ; 48 89 94 24 10 00 00 00              
    75 : mov     qword ptr [rsp + 018h], r8       ; 4c 89 84 24 18 00 00 00              
    76 : mov     qword ptr [rsp + 020h], r9       ; 4c 89 8c 24 20 00 00 00              
    77 : mov     qword ptr [rsp + 028h], r10      ; 4c 89 94 24 28 00 00 00              
    78 : mov     qword ptr [rsp + 030h], r11      ; 4c 89 9c 24 30 00 00 00              
    79 : vmovdqu ymmword ptr [rsp + 040h], ymm0   ; c5 fe 7f 84 24 40 00 00 00           
    80 : vmovdqu ymmword ptr [rsp + 060h], ymm1   ; c5 fe 7f 8c 24 60 00 00 00           
    81 : vmovdqu ymmword ptr [rsp + 080h], ymm2   ; c5 fe 7f 94 24 80 00 00 00           
    82 : vmovdqu ymmword ptr [rsp + 0a0h], ymm3   ; c5 fe 7f 9c 24 a0 00 00 00           
    83 : vmovdqu ymmword ptr [rsp + 0c0h], ymm5   ; c5 fe 7f ac 24 c0 00 00 00           
    84 : vmovdqu ymmword ptr [rsp + 0e0h], ymm6   ; c5 fe 7f b4 24 e0 00 00 00           
    85 : vmovdqu ymmword ptr [rsp + 0100h], ymm7  ; c5 fe 7f bc 24 00 01 00 00           
    86 : vmovdqu ymmword ptr [rsp + 0120h], ymm8  ; c5 7e 7f 84 24 20 01 00 00           
    87 : vmovdqu ymmword ptr [rsp + 0140h], ymm9  ; c5 7e 7f 8c 24 40 01 00 00           
    88 : vmovdqu ymmword ptr [rsp + 0160h], ymm10 ; c5 7e 7f 94 24 60 01 00 00           
    89 : vmovdqu ymmword ptr [rsp + 0180h], ymm11 ; c5 7e 7f 9c 24 80 01 00 00           
    90 : vmovdqu ymmword ptr [rsp + 01a0h], ymm12 ; c5 7e 7f a4 24 a0 01 00 00           
    91 : vmovdqu ymmword ptr [rsp + 01c0h], ymm13 ; c5 7e 7f ac 24 c0 01 00 00           
    92 : vmovdqu ymmword ptr [rsp + 01e0h], ymm14 ; c5 7e 7f b4 24 e0 01 00 00           
    93 : vmovdqu ymmword ptr [rsp + 0200h], ymm15 ; c5 7e 7f bc 24 00 02 00 00           
    94 : mov     rcx, rax                         ; 48 89 c1                             
    95 : mov     rdx, r9                          ; 4c 89 ca                             
    96 : mov     r10, qword ptr [rsp + 008h]      ; 4c 8b 94 24 08 00 00 00              
    97 : sub     rsp, 020h                        ; 48 81 ec 20 00 00 00                 
    98 : call    r10                              ; 41 ff d2                             
    99 : add     rsp, 020h                        ; 48 81 c4 20 00 00 00                 
   100 : mov     rax, qword ptr [rsp]             ; 48 8b 84 24 00 00 00 00              
   101 : mov     rcx, qword ptr [rsp + 008h]      ; 48 8b 8c 24 08 00 00 00              
   102 : mov     rdx, qword ptr [rsp + 010h]      ; 48 8b 94 24 10 00 00 00              
   103 : mov     r8, qword ptr [rsp + 018h]       ; 4c 8b 84 24 18 00 00 00              
   104 : mov     r9, qword ptr [rsp + 020h]       ; 4c 8b 8c 24 20 00 00 00              
   105 : mov     r10, qword ptr [rsp + 028h]      ; 4c 8b 94 24 28 00 00 00              
   106 : mov     r11, qword ptr [rsp + 030h]      ; 4c 8b 9c 24 30 00 00 00              
   107 : vmovdqu ymm0, ymmword ptr [rsp + 040h]   ; c5 fe 6f 84 24 40 00 00 00           
   108 : vmovdqu ymm1, ymmword ptr [rsp + 060h]   ; c5 fe 6f 8c 24 60 00 00 00           
   109 : vmovdqu ymm2, ymmword ptr [rsp + 080h]   ; c5 fe 6f 94 24 80 00 00 00           
   110 : vmovdqu ymm3, ymmword ptr [rsp + 0a0h]   ; c5 fe 6f 9c 24 a0 00 00 00           
   111 : vmovdqu ymm5, ymmword ptr [rsp + 0c0h]   ; c5 fe 6f ac 24 c0 00 00 00           
   112 : vmovdqu ymm6, ymmword ptr [rsp + 0e0h]   ; c5 fe 6f b4 24 e0 00 00 00           
   113 : vmovdqu ymm7, ymmword ptr [rsp + 0100h]  ; c5 fe 6f bc 24 00 01 00 00           
   114 : vmovdqu ymm8, ymmword ptr [rsp + 0120h]  ; c5 7e 6f 84 24 20 01 00 00           
   115 : vmovdqu ymm9, ymmword ptr [rsp + 0140h]  ; c5 7e 6f 8c 24 40 01 00 00           
   116 : vmovdqu ymm10, ymmword ptr [rsp + 0160h] ; c5 7e 6f 94 24 60 01 00 00           
   117 : vmovdqu ymm11, ymmword ptr [rsp + 0180h] ; c5 7e 6f 9c 24 80 01 00 00           
   118 : vmovdqu ymm12, ymmword ptr [rsp + 01a0h] ; c5 7e 6f a4 24 a0 01 00 00           
   119 : vmovdqu ymm13, ymmword ptr [rsp + 01c0h] ; c5 7e 6f ac 24 c0 01 00 00           
   120 : vmovdqu ymm14, ymmword ptr [rsp + 01e0h] ; c5 7e 6f b4 24 e0 01 00 00           
   121 : vmovdqu ymm15, ymmword ptr [rsp + 0200h] ; c5 7e 6f bc 24 00 02 00 00           
   122 : mov     rcx, r9                          ; 4c 89 c9                             
   123 : imul    rcx, qword ptr [rsp + 0268h]     ; 48 0f af 8c 24 68 02 00 00           
   124 : add     rcx, rax                         ; 48 01 c1                             
   125 : mov     r13, qword ptr [rsp + 0278h]     ; 4c 8b ac 24 78 02 00 00              
   126 : mov     r14, qword ptr [rsp + 0258h]     ; 4c 8b b4 24 58 02 00 00              
   127 : mov     byte ptr [r13 + rcx], r14b       ; 45 88 74 0d 00                       
   128 : add     qword ptr [rsp + 0258h], 001h    ; 48 81 84 24 58 02 00 00 01 00 00 00  
   129 : add     rax, qword ptr [rsp + 0240h]     ; 48 03 84 24 40 02 00 00              
   130 : add     r9, qword ptr [rsp + 0248h]      ; 4c 03 8c 24 48 02 00 00              
   131 : jmp     __loops_label_6                  ; e9 e4 fd ff ff                       
   132 :         __loops_label_8:                 ;                                      
   133 : neg     qword ptr [rsp + 0240h]          ; 48 f7 9c 24 40 02 00 00              
   134 : neg     qword ptr [rsp + 0248h]          ; 48 f7 9c 24 48 02 00 00              
   135 : add     qword ptr [rsp + 0250h], 001h    ; 48 81 84 24 50 02 00 00 01 00 00 00  
   136 : jmp     __loops_label_0                  ; e9 fe fc ff ff                       
   137 :         __loops_label_2:                 ;                                      
   138 : mov     rbp, qword ptr [rsp + 0290h]     ; 48 8b ac 24 90 02 00 00              
   139 : mov     r13, qword ptr [rsp + 0280h]     ; 4c 8b ac 24 80 02 00 00              
   140 : mov     r14, qword ptr [rsp + 0288h]     ; 4c 8b b4 24 88 02 00 00              
   141 : add     rsp, 0298h                       ; 48 81 c4 98 02 00 00                 
   142 : ret                                      ; c3                                   
