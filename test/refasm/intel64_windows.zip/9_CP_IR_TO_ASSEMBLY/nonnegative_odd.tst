nonnegative_odd(i0, i1)
     0 : sub    rsp, 038h                   ; 48 81 ec 38 00 00 00     
     1 : mov    qword ptr [rsp + 028h], r13 ; 4c 89 ac 24 28 00 00 00  
     2 : xor    r8, r8                      ; 4d 31 c0                 
     3 : mov    r13, 0fffffffffffffffch     ; 49 c7 c5 fc ff ff ff     
     4 : mov    qword ptr [rsp + 020h], r13 ; 4c 89 ac 24 20 00 00 00  
     5 : imul   rdx, 004h                   ; 48 6b d2 04              
     6 :        __loops_label_0:            ;                          
     7 : cmp    r8, rdx                     ; 49 39 d0                 
     8 : jge    __loops_label_2             ; 0f 8d 6c 00 00 00        
     9 : movsxd rax, dword ptr [rcx + r8]   ; 4a 63 04 01              
    10 : cmp    rax, 0h                     ; 48 83 f8 00              
    11 : jge    __loops_label_4             ; 0f 8d 0c 00 00 00        
    12 : add    r8, 004h                    ; 49 81 c0 04 00 00 00     
    13 : jmp    __loops_label_0             ; e9 dd ff ff ff           
    14 :        __loops_label_4:            ;                          
    15 : mov    r9, 002h                    ; 49 c7 c1 02 00 00 00     
    16 : mov    qword ptr [rsp], rax        ; 48 89 84 24 00 00 00 00  
    17 : mov    qword ptr [rsp + 008h], rdx ; 48 89 94 24 08 00 00 00  
    18 : cqo                                ; 48 99                    
    19 : idiv   r9                          ; 49 f7 f9                 
    20 : mov    r9, rdx                     ; 49 89 d1                 
    21 : mov    rax, qword ptr [rsp]        ; 48 8b 84 24 00 00 00 00  
    22 : mov    rdx, qword ptr [rsp + 008h] ; 48 8b 94 24 08 00 00 00  
    23 : cmp    r9, 0h                      ; 49 83 f9 00              
    24 : je     __loops_label_6             ; 0f 84 0d 00 00 00        
    25 : mov    qword ptr [rsp + 020h], r8  ; 4c 89 84 24 20 00 00 00  
    26 : jmp    __loops_label_2             ; e9 0c 00 00 00           
    27 :        __loops_label_6:            ;                          
    28 : add    r8, 004h                    ; 49 81 c0 04 00 00 00     
    29 : jmp    __loops_label_0             ; e9 8b ff ff ff           
    30 :        __loops_label_2:            ;                          
    31 : mov    rcx, 004h                   ; 48 c7 c1 04 00 00 00     
    32 : mov    r13, qword ptr [rsp + 020h] ; 4c 8b ac 24 20 00 00 00  
    33 : mov    qword ptr [rsp], rax        ; 48 89 84 24 00 00 00 00  
    34 : mov    qword ptr [rsp + 008h], rdx ; 48 89 94 24 08 00 00 00  
    35 : mov    rax, r13                    ; 4c 89 e8                 
    36 : cqo                                ; 48 99                    
    37 : idiv   rcx                         ; 48 f7 f9                 
    38 : mov    rcx, rax                    ; 48 89 c1                 
    39 : mov    rax, qword ptr [rsp]        ; 48 8b 84 24 00 00 00 00  
    40 : mov    rdx, qword ptr [rsp + 008h] ; 48 8b 94 24 08 00 00 00  
    41 : mov    rax, rcx                    ; 48 89 c8                 
    42 : mov    r13, qword ptr [rsp + 028h] ; 4c 8b ac 24 28 00 00 00  
    43 : add    rsp, 038h                   ; 48 81 c4 38 00 00 00     
    44 : ret                                ; c3                       
