helloworld_call()
     0 : sub     rsp, 0248h                       ; 48 81 ec 48 02 00 00           
     1 : mov     qword ptr [rsp + 0240h], rbp     ; 48 89 ac 24 40 02 00 00        
     2 : mov     rbp, rsp                         ; 48 89 e5                       
     3 : add     rbp, 0240h                       ; 48 81 c5 40 02 00 00           
     4 : mov     rcx, 07ff62e6317f0h              ; 48 b9 f0 17 63 2e f6 7f 00 00  
     5 : mov     qword ptr [rsp], rax             ; 48 89 84 24 00 00 00 00        
     6 : mov     qword ptr [rsp + 008h], rcx      ; 48 89 8c 24 08 00 00 00        
     7 : mov     qword ptr [rsp + 010h], rdx      ; 48 89 94 24 10 00 00 00        
     8 : mov     qword ptr [rsp + 018h], r8       ; 4c 89 84 24 18 00 00 00        
     9 : mov     qword ptr [rsp + 020h], r9       ; 4c 89 8c 24 20 00 00 00        
    10 : mov     qword ptr [rsp + 028h], r10      ; 4c 89 94 24 28 00 00 00        
    11 : mov     qword ptr [rsp + 030h], r11      ; 4c 89 9c 24 30 00 00 00        
    12 : vmovdqu ymmword ptr [rsp + 040h], ymm0   ; c5 fe 7f 84 24 40 00 00 00     
    13 : vmovdqu ymmword ptr [rsp + 060h], ymm1   ; c5 fe 7f 8c 24 60 00 00 00     
    14 : vmovdqu ymmword ptr [rsp + 080h], ymm2   ; c5 fe 7f 94 24 80 00 00 00     
    15 : vmovdqu ymmword ptr [rsp + 0a0h], ymm3   ; c5 fe 7f 9c 24 a0 00 00 00     
    16 : vmovdqu ymmword ptr [rsp + 0c0h], ymm5   ; c5 fe 7f ac 24 c0 00 00 00     
    17 : vmovdqu ymmword ptr [rsp + 0e0h], ymm6   ; c5 fe 7f b4 24 e0 00 00 00     
    18 : vmovdqu ymmword ptr [rsp + 0100h], ymm7  ; c5 fe 7f bc 24 00 01 00 00     
    19 : vmovdqu ymmword ptr [rsp + 0120h], ymm8  ; c5 7e 7f 84 24 20 01 00 00     
    20 : vmovdqu ymmword ptr [rsp + 0140h], ymm9  ; c5 7e 7f 8c 24 40 01 00 00     
    21 : vmovdqu ymmword ptr [rsp + 0160h], ymm10 ; c5 7e 7f 94 24 60 01 00 00     
    22 : vmovdqu ymmword ptr [rsp + 0180h], ymm11 ; c5 7e 7f 9c 24 80 01 00 00     
    23 : vmovdqu ymmword ptr [rsp + 01a0h], ymm12 ; c5 7e 7f a4 24 a0 01 00 00     
    24 : vmovdqu ymmword ptr [rsp + 01c0h], ymm13 ; c5 7e 7f ac 24 c0 01 00 00     
    25 : vmovdqu ymmword ptr [rsp + 01e0h], ymm14 ; c5 7e 7f b4 24 e0 01 00 00     
    26 : vmovdqu ymmword ptr [rsp + 0200h], ymm15 ; c5 7e 7f bc 24 00 02 00 00     
    27 : sub     rsp, 020h                        ; 48 81 ec 20 00 00 00           
    28 : call    rcx                              ; ff d1                          
    29 : add     rsp, 020h                        ; 48 81 c4 20 00 00 00           
    30 : mov     rax, qword ptr [rsp]             ; 48 8b 84 24 00 00 00 00        
    31 : mov     rcx, qword ptr [rsp + 008h]      ; 48 8b 8c 24 08 00 00 00        
    32 : mov     rdx, qword ptr [rsp + 010h]      ; 48 8b 94 24 10 00 00 00        
    33 : mov     r8, qword ptr [rsp + 018h]       ; 4c 8b 84 24 18 00 00 00        
    34 : mov     r9, qword ptr [rsp + 020h]       ; 4c 8b 8c 24 20 00 00 00        
    35 : mov     r10, qword ptr [rsp + 028h]      ; 4c 8b 94 24 28 00 00 00        
    36 : mov     r11, qword ptr [rsp + 030h]      ; 4c 8b 9c 24 30 00 00 00        
    37 : vmovdqu ymm0, ymmword ptr [rsp + 040h]   ; c5 fe 6f 84 24 40 00 00 00     
    38 : vmovdqu ymm1, ymmword ptr [rsp + 060h]   ; c5 fe 6f 8c 24 60 00 00 00     
    39 : vmovdqu ymm2, ymmword ptr [rsp + 080h]   ; c5 fe 6f 94 24 80 00 00 00     
    40 : vmovdqu ymm3, ymmword ptr [rsp + 0a0h]   ; c5 fe 6f 9c 24 a0 00 00 00     
    41 : vmovdqu ymm5, ymmword ptr [rsp + 0c0h]   ; c5 fe 6f ac 24 c0 00 00 00     
    42 : vmovdqu ymm6, ymmword ptr [rsp + 0e0h]   ; c5 fe 6f b4 24 e0 00 00 00     
    43 : vmovdqu ymm7, ymmword ptr [rsp + 0100h]  ; c5 fe 6f bc 24 00 01 00 00     
    44 : vmovdqu ymm8, ymmword ptr [rsp + 0120h]  ; c5 7e 6f 84 24 20 01 00 00     
    45 : vmovdqu ymm9, ymmword ptr [rsp + 0140h]  ; c5 7e 6f 8c 24 40 01 00 00     
    46 : vmovdqu ymm10, ymmword ptr [rsp + 0160h] ; c5 7e 6f 94 24 60 01 00 00     
    47 : vmovdqu ymm11, ymmword ptr [rsp + 0180h] ; c5 7e 6f 9c 24 80 01 00 00     
    48 : vmovdqu ymm12, ymmword ptr [rsp + 01a0h] ; c5 7e 6f a4 24 a0 01 00 00     
    49 : vmovdqu ymm13, ymmword ptr [rsp + 01c0h] ; c5 7e 6f ac 24 c0 01 00 00     
    50 : vmovdqu ymm14, ymmword ptr [rsp + 01e0h] ; c5 7e 6f b4 24 e0 01 00 00     
    51 : vmovdqu ymm15, ymmword ptr [rsp + 0200h] ; c5 7e 6f bc 24 00 02 00 00     
    52 : mov     rbp, qword ptr [rsp + 0240h]     ; 48 8b ac 24 40 02 00 00        
    53 : add     rsp, 0248h                       ; 48 81 c4 48 02 00 00           
    54 : ret                                      ; c3                             
