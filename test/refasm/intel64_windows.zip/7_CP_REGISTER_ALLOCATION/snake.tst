snake(i0, i1, i2)
     0 : sub                    i4, i4, 680     
     1 : spill                  82, i13         
     2 : spill                  83, i14         
     3 : spill                  84, i5          
     4 : mov                    i5, i4          
     5 : add                    i5, i5, 672     
     6 : mov                    i9, i2          
     7 : add                    i9, i9, i8      
     8 : sub                    s76, i9, 1      
     9 : mov                    i9, 0           
    10 : mov                    s75, 1          
    11 : mov                    i13, s75        
    12 : spill                  72, i13         
    13 : neg                    s72, s72        
    14 : mov                    s77, 0          
    15 : annotation:whilecstart 0               
    16 : unspill                i13, 76         
    17 : cmp                    s77, i13        
    18 : jmp_ge                 __loops_label_2 
    19 : annotation:whilecend                   
    20 : mov                    s73, 0          
    21 : mov                    s74, 0          
    22 : annotation:ifcstart                    
    23 : mov                    i0, s77         
    24 : and                    i0, i0, 1       
    25 : cmp                    i0, 0           
    26 : jmp_eq                 __loops_label_4 
    27 : annotation:ifcend                      
    28 : sub                    i0, i8, 1       
    29 : cmp                    i0, s77         
    30 : unspill                i13, 77         
    31 : select_gt              i14, i0, i13    
    32 : spill                  73, i14         
    33 : unspill                i13, 77         
    34 : sub                    s78, i13, i0    
    35 : mov                    s79, 0          
    36 : cmp                    s77, i0         
    37 : unspill                i13, 79         
    38 : select_gt              i14, s78, i13   
    39 : spill                  74, i14         
    40 : annotation:else        4, 5            
    41 : sub                    s80, i2, 1      
    42 : unspill                i13, 77         
    43 : sub                    i0, i13, s80    
    44 : mov                    s81, 0          
    45 : unspill                i13, 80         
    46 : cmp                    s77, i13        
    47 : unspill                i13, 81         
    48 : select_gt              i14, i0, i13    
    49 : spill                  73, i14         
    50 : unspill                i13, 77         
    51 : cmp                    s80, i13        
    52 : unspill                i13, 77         
    53 : select_gt              i14, s80, i13   
    54 : spill                  74, i14         
    55 : annotation:endif       5               
    56 : annotation:whilecstart 6               
    57 : cmp                    s73, 0          
    58 : jmp_gt                 __loops_label_8 
    59 : cmp                    s73, i8         
    60 : jmp_ge                 __loops_label_8 
    61 : cmp                    s74, 0          
    62 : jmp_gt                 __loops_label_8 
    63 : cmp                    s74, i2         
    64 : jmp_ge                 __loops_label_8 
    65 : annotation:whilecend                   
    66 : mov                    i0, -887494032  
    67 : unspill                i13, 73         
    68 : unspill                i14, 74         
    69 : call_noret             [i0](i13, i14)  
    70 : mov                    i0, s74         
    71 : mul                    i0, i0, i8      
    72 : mov                    i0, i0          
    73 : add                    i0, i0, s73     
    74 : store.u8               i1, i0, i9      
    75 : add                    i9, i9, 1       
    76 : unspill                i13, 75         
    77 : add                    s73, s73, i13   
    78 : unspill                i13, 72         
    79 : add                    s74, s74, i13   
    80 : annotation:endwhile    6, 8            
    81 : neg                    s75, s75        
    82 : neg                    s72, s72        
    83 : add                    s77, s77, 1     
    84 : annotation:endwhile    0, 2            
    85 : ret                                    
    86 : unspill                i5, 84          
    87 : unspill                i13, 82         
    88 : unspill                i14, 83         
    89 : add                    i4, i4, 680     
