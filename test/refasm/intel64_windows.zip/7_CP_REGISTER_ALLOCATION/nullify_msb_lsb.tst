nullify_msb_lsb(i0, i1, i2)
     0 : mov       i9, i1     
     1 : shr       i9, i9, 1  
     2 : mov       i9, i9     
     3 : or        i9, i9, i1 
     4 : mov       i0, i9     
     5 : shr       i0, i0, 2  
     6 : mov       i0, i0     
     7 : or        i0, i0, i9 
     8 : mov       i9, i0     
     9 : shr       i9, i9, 4  
    10 : mov       i9, i9     
    11 : or        i9, i9, i0 
    12 : mov       i0, i9     
    13 : shr       i0, i0, 8  
    14 : mov       i0, i0     
    15 : or        i0, i0, i9 
    16 : mov       i9, i0     
    17 : shr       i9, i9, 16 
    18 : mov       i9, i9     
    19 : or        i9, i9, i0 
    20 : mov       i0, i9     
    21 : shr       i0, i0, 32 
    22 : mov       i0, i0     
    23 : or        i0, i0, i9 
    24 : mov       i0, i0     
    25 : add       i0, i0, 1  
    26 : mov       i0, i0     
    27 : shr       i0, i0, 1  
    28 : mov       i0, i0     
    29 : xor       i0, i0, i1 
    30 : store.u64 i8, i0     
    31 : sub       i8, i1, 1  
    32 : mov       i8, i8     
    33 : not       i8, i8     
    34 : mov       i8, i8     
    35 : and       i8, i8, i1 
    36 : mov       i1, i1     
    37 : xor       i1, i1, i8 
    38 : store.u64 i2, i1     
    39 : ret                  
