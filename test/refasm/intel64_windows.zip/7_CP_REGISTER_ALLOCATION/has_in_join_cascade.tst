has_in_join_cascade(i0, i1, i2)
     0 : sub                    i4, i4, 120      
     1 : spill                  13, i13          
     2 : spill                  14, i14          
     3 : mov                    s5, 0            
     4 : load.i64               i13, i1, 16      
     5 : spill                  6, i13           
     6 : load.i64               i13, i1, 0       
     7 : spill                  7, i13           
     8 : load.i64               i13, i1, 8       
     9 : spill                  8, i13           
    10 : annotation:whilecstart 0                
    11 : cmp                    s6, 0            
    12 : jmp_le                 __loops_label_2  
    13 : annotation:whilecend                    
    14 : unspill                i13, 7           
    15 : load.i32               i14, i13         
    16 : spill                  9, i14           
    17 : add                    s7, s7, 4        
    18 : unspill                i13, 8           
    19 : load.i32               i14, i13         
    20 : spill                  4, i14           
    21 : add                    s8, s8, 4        
    22 : sub                    s6, s6, 1        
    23 : load.i64               i13, i1, 40      
    24 : spill                  10, i13          
    25 : load.i64               i13, i1, 24      
    26 : spill                  11, i13          
    27 : load.i64               i13, i1, 32      
    28 : spill                  12, i13          
    29 : annotation:whilecstart 3                
    30 : cmp                    s10, 0           
    31 : jmp_le                 __loops_label_5  
    32 : annotation:whilecend                    
    33 : unspill                i13, 11          
    34 : load.i32               i14, i13         
    35 : spill                  0, i14           
    36 : add                    s11, s11, 4      
    37 : unspill                i13, 12          
    38 : load.i32               i9, i13          
    39 : add                    s12, s12, 4      
    40 : sub                    s10, s10, 1      
    41 : annotation:ifcstart                     
    42 : cmp                    i9, s9           
    43 : jmp_le                 __loops_label_7  
    44 : annotation:ifcend                       
    45 : annotation:continue    0                
    46 : annotation:else        7, 8             
    47 : annotation:ifcstart                     
    48 : cmp                    i9, s9           
    49 : jmp_ne                 __loops_label_10 
    50 : annotation:ifcend                       
    51 : load.i64               i13, i1, 64      
    52 : spill                  1, i13           
    53 : load.i64               i13, i1, 48      
    54 : spill                  2, i13           
    55 : load.i64               i13, i1, 56      
    56 : spill                  3, i13           
    57 : annotation:whilecstart 11               
    58 : cmp                    s1, 0            
    59 : jmp_le                 __loops_label_13 
    60 : annotation:whilecend                    
    61 : unspill                i13, 2           
    62 : load.i32               i0, i13          
    63 : add                    s2, s2, 4        
    64 : unspill                i13, 3           
    65 : load.i32               i9, i13          
    66 : add                    s3, s3, 4        
    67 : sub                    s1, s1, 1        
    68 : annotation:ifcstart                     
    69 : cmp                    i0, s4           
    70 : jmp_le                 __loops_label_15 
    71 : annotation:ifcend                       
    72 : annotation:continue    0                
    73 : annotation:else        15, 16           
    74 : annotation:ifcstart                     
    75 : cmp                    i0, s4           
    76 : jmp_ne                 __loops_label_18 
    77 : cmp                    s0, i2           
    78 : jmp_ne                 __loops_label_18 
    79 : cmp                    i9, i8           
    80 : jmp_ne                 __loops_label_18 
    81 : annotation:ifcend                       
    82 : mov                    s5, 1            
    83 : annotation:break       2                
    84 : annotation:endif       16               
    85 : annotation:endif       18               
    86 : annotation:endwhile    11, 13           
    87 : annotation:endif       8                
    88 : annotation:endif       10               
    89 : annotation:endwhile    3, 5             
    90 : annotation:endwhile    0, 2             
    91 : mov                    i0, s5           
    92 : ret                                     
    93 : unspill                i13, 13          
    94 : unspill                i14, 14          
    95 : add                    i4, i4, 120      
