bresenham(i0, i1, i2, i3, i4, i5, i6)
     0 : sub                    i4, i4, 104      
     1 : spill                  10, i13          
     2 : spill                  11, i14          
     3 : spill                  9, i9            
     4 : unspill                i13, 18          
     5 : sub                    i0, i13, i8      
     6 : mov                    i9, i0           
     7 : neg                    i9, i9           
     8 : select_s               i13, i0, i9      
     9 : spill                  1, i13           
    10 : unspill                i13, 18          
    11 : sub                    i0, i13, i8      
    12 : mov                    i9, i0           
    13 : mov                    i0, i0           
    14 : sar                    i0, i0, 63       
    15 : mov                    i9, i9           
    16 : neg                    i9, i9           
    17 : mov                    s2, i0           
    18 : x86_adc                s2, s2, i0       
    19 : unspill                i13, 19          
    20 : sub                    i0, i13, s9      
    21 : mov                    i9, i0           
    22 : neg                    i9, i9           
    23 : select_s               i9, i0, i9       
    24 : mov                    s3, i9           
    25 : neg                    s3, s3           
    26 : unspill                i13, 19          
    27 : sub                    i0, i13, s9      
    28 : mov                    i9, i0           
    29 : mov                    i0, i0           
    30 : sar                    i0, i0, 63       
    31 : mov                    i9, i9           
    32 : neg                    i9, i9           
    33 : mov                    i9, i0           
    34 : x86_adc                i9, i9, i0       
    35 : mov                    i13, s1          
    36 : spill                  5, i13           
    37 : unspill                i13, 3           
    38 : add                    s5, s5, i13      
    39 : spill                  4, i9            
    40 : annotation:whilecstart 0                
    41 : cmp                    i1, 0            
    42 : jmp_eq                 __loops_label_2  
    43 : annotation:whilecend                    
    44 : mov                    i13, s9          
    45 : spill                  6, i13           
    46 : unspill                i13, 6           
    47 : mul                    i13, i13, i2     
    48 : spill                  6, i13           
    49 : mov                    i13, s6          
    50 : spill                  7, i13           
    51 : add                    s7, s7, i8       
    52 : unspill                i14, 20          
    53 : unspill                i13, 7           
    54 : store.u8               i1, i13, i14     
    55 : annotation:ifcstart                     
    56 : cmp                    i8, s18          
    57 : jmp_ne                 __loops_label_4  
    58 : unspill                i13, 19          
    59 : cmp                    s9, i13          
    60 : jmp_ne                 __loops_label_4  
    61 : annotation:ifcend                       
    62 : annotation:break       2                
    63 : annotation:endif       4                
    64 : mov                    i13, s5          
    65 : spill                  8, i13           
    66 : shl                    s8, s8, 1        
    67 : annotation:ifcstart                     
    68 : unspill                i13, 3           
    69 : cmp                    s8, i13          
    70 : jmp_gt                 __loops_label_6  
    71 : annotation:ifcend                       
    72 : annotation:ifcstart                     
    73 : cmp                    i8, s18          
    74 : jmp_ne                 __loops_label_8  
    75 : annotation:ifcend                       
    76 : annotation:break       2                
    77 : annotation:endif       8                
    78 : unspill                i13, 3           
    79 : add                    s5, s5, i13      
    80 : add                    i8, i8, s2       
    81 : annotation:endif       6                
    82 : annotation:ifcstart                     
    83 : unspill                i13, 1           
    84 : cmp                    s8, i13          
    85 : jmp_gt                 __loops_label_10 
    86 : annotation:ifcend                       
    87 : annotation:ifcstart                     
    88 : unspill                i13, 19          
    89 : cmp                    s9, i13          
    90 : jmp_ne                 __loops_label_12 
    91 : annotation:ifcend                       
    92 : annotation:break       2                
    93 : annotation:endif       12               
    94 : unspill                i13, 1           
    95 : add                    s5, s5, i13      
    96 : unspill                i13, 4           
    97 : add                    s9, s9, i13      
    98 : annotation:endif       10               
    99 : annotation:endwhile    0, 2             
   100 : ret                                     
   101 : unspill                i13, 10          
   102 : unspill                i14, 11          
   103 : add                    i4, i4, 104      
