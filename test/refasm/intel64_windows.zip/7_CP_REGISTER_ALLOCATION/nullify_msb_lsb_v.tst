nullify_msb_lsb_v(i0, i1, i2, i3)
     0 : sub                    i4, i4, 56      
     1 : spill                  6, i13          
     2 : mov                    s5, 0           
     3 : mov                    i9, i9          
     4 : mul                    i9, i9, 4       
     5 : mov                    i0, 1           
     6 : vdef.u32               v1              
     7 : setlane.u32            v1, 0, i0       
     8 : broadcast.u32          v0, v1, 0       
     9 : spill                  4, i9           
    10 : annotation:whilecstart 0               
    11 : unspill                i13, 4          
    12 : cmp                    s5, i13         
    13 : jmp_ge                 __loops_label_2 
    14 : annotation:whilecend                   
    15 : unspill                i13, 5          
    16 : vld.u32                v1, i1, i13     
    17 : shr.u32                v2, v1, 1       
    18 : or                     v2, v1, v2      
    19 : shr.u32                v3, v2, 2       
    20 : or                     v2, v2, v3      
    21 : shr.u32                v3, v2, 4       
    22 : or                     v2, v2, v3      
    23 : shr.u32                v3, v2, 8       
    24 : or                     v2, v2, v3      
    25 : shr.u32                v3, v2, 16      
    26 : or                     v2, v2, v3      
    27 : add.u32                v2, v2, v0      
    28 : shr.u32                v2, v2, 1       
    29 : xor                    v2, v2, v1      
    30 : unspill                i13, 5          
    31 : vst.u32                i2, i13, v2     
    32 : sub.u32                v2, v1, v0      
    33 : mov                    i0, 255         
    34 : vdef.u8                v3              
    35 : setlane.u8             v3, 0, i0       
    36 : broadcast.u8           v3, v3, 0       
    37 : xor                    v2, v2, v3      
    38 : and                    v2, v1, v2      
    39 : xor                    v1, v2, v1      
    40 : unspill                i13, 5          
    41 : vst.u32                i8, i13, v1     
    42 : add                    s5, s5, 32      
    43 : annotation:endwhile    0, 2            
    44 : ret                                    
    45 : unspill                i13, 6          
    46 : add                    i4, i4, 56      
