nonnegative_odd(i0, i1)
     0 : sub                    i4, i4, 72      
     1 : spill                  7, i13          
     2 : mov                    i9, 0           
     3 : mov                    i13, -4         
     4 : spill                  5, i13          
     5 : mov                    s4, i2          
     6 : unspill                i13, 4          
     7 : mul                    i13, i13, 4     
     8 : spill                  4, i13          
     9 : annotation:whilecstart 0               
    10 : cmp                    i9, s4          
    11 : jmp_ge                 __loops_label_2 
    12 : annotation:whilecend                   
    13 : load.i32               i8, i1, i9      
    14 : annotation:ifcstart                    
    15 : cmp                    i8, 0           
    16 : jmp_ge                 __loops_label_4 
    17 : annotation:ifcend                      
    18 : add                    i9, i9, 4       
    19 : annotation:continue    0               
    20 : annotation:endif       4               
    21 : mov                    i0, 2           
    22 : spill                  6, i0           
    23 : mov                    i0, i8          
    24 : mod                    i2, i0, s6      
    25 : mov                    i8, i2          
    26 : annotation:ifcstart                    
    27 : cmp                    i8, 0           
    28 : jmp_eq                 __loops_label_6 
    29 : annotation:ifcend                      
    30 : mov                    s5, i9          
    31 : annotation:break       2               
    32 : annotation:endif       6               
    33 : add                    i9, i9, 4       
    34 : annotation:endwhile    0, 2            
    35 : mov                    i9, 4           
    36 : mov                    i1, s5          
    37 : mov                    i0, i1          
    38 : div                    i0, i0, i9      
    39 : mov                    i1, i0          
    40 : mov                    i0, i1          
    41 : ret                                    
    42 : unspill                i13, 7          
    43 : add                    i4, i4, 72      
