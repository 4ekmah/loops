exp_f32(i0, i1, i2)
     0 : sub                    i4, i4, 456       
     1 : spill                  24, v6            
     2 : spill                  28, v7            
     3 : spill                  32, v8            
     4 : spill                  36, v9            
     5 : spill                  40, v10           
     6 : spill                  44, v11           
     7 : spill                  48, v12           
     8 : spill                  52, v13           
     9 : mov                    i9, -1028603739   
    10 : vdef.fp32              v1                
    11 : setlane.fp32           v1, 0, i9         
    12 : broadcast.fp32         v0, v1, 0         
    13 : mov                    i9, 1118879909    
    14 : vdef.fp32              v2                
    15 : setlane.fp32           v2, 0, i9         
    16 : broadcast.fp32         v1, v2, 0         
    17 : mov                    i9, 1056964608    
    18 : vdef.fp32              v3                
    19 : setlane.fp32           v3, 0, i9         
    20 : broadcast.fp32         v2, v3, 0         
    21 : mov                    i9, 1065353216    
    22 : vdef.fp32              v5                
    23 : setlane.fp32           v5, 0, i9         
    24 : broadcast.fp32         v3, v5, 0         
    25 : mov                    i9, 1069066811    
    26 : vdef.fp32              v6                
    27 : setlane.fp32           v6, 0, i9         
    28 : broadcast.fp32         v5, v6, 0         
    29 : mov                    i9, -1087275008   
    30 : vdef.fp32              v7                
    31 : setlane.fp32           v7, 0, i9         
    32 : broadcast.fp32         v6, v7, 0         
    33 : mov                    i9, 962494595     
    34 : vdef.fp32              v8                
    35 : setlane.fp32           v8, 0, i9         
    36 : broadcast.fp32         v7, v8, 0         
    37 : mov                    i9, 961571175     
    38 : vdef.fp32              v9                
    39 : setlane.fp32           v9, 0, i9         
    40 : broadcast.fp32         v8, v9, 0         
    41 : mov                    i9, 985088974     
    42 : vdef.fp32              v9                
    43 : setlane.fp32           v9, 0, i9         
    44 : broadcast.fp32         v13, v9, 0        
    45 : spill                  20, v13           
    46 : mov                    i9, 1007192328    
    47 : vdef.fp32              v9                
    48 : setlane.fp32           v9, 0, i9         
    49 : broadcast.fp32         v13, v9, 0        
    50 : spill                  16, v13           
    51 : mov                    i9, 1026206145    
    52 : vdef.fp32              v9                
    53 : setlane.fp32           v9, 0, i9         
    54 : broadcast.fp32         v13, v9, 0        
    55 : spill                  12, v13           
    56 : mov                    i9, 1042983594    
    57 : vdef.fp32              v9                
    58 : setlane.fp32           v9, 0, i9         
    59 : broadcast.fp32         v13, v9, 0        
    60 : spill                  8, v13            
    61 : mov                    i9, 1056964608    
    62 : vdef.fp32              v9                
    63 : setlane.fp32           v9, 0, i9         
    64 : broadcast.fp32         v13, v9, 0        
    65 : spill                  0, v13            
    66 : mov                    i9, 127           
    67 : vdef.i32               v9                
    68 : setlane.i32            v9, 0, i9         
    69 : broadcast.i32          v13, v9, 0        
    70 : spill                  4, v13            
    71 : mov                    i9, 0             
    72 : annotation:whilecstart 0                 
    73 : cmp                    i8, 0             
    74 : jmp_le                 __loops_label_2   
    75 : annotation:whilecend                     
    76 : vld.fp32               v12, i2, i9       
    77 : min.fp32               v12, v12, v1      
    78 : max.fp32               v12, v12, v0      
    79 : mov                    v11, v2           
    80 : fma.fp32               v11, v11, v12, v5 
    81 : floor.fp32_fp32        v11, v11          
    82 : cast.fp32_i32          v11, v11          
    83 : cast.i32_fp32          v10, v11          
    84 : mov                    v12, v12          
    85 : fma.fp32               v12, v12, v10, v6 
    86 : mov                    v12, v12          
    87 : fma.fp32               v12, v12, v10, v7 
    88 : unspill                v13, 20           
    89 : mov                    v10, v13          
    90 : fma.fp32               v10, v10, v12, v8 
    91 : unspill                v13, 16           
    92 : mov                    v9, v13           
    93 : fma.fp32               v9, v9, v10, v12  
    94 : unspill                v13, 12           
    95 : mov                    v10, v13          
    96 : fma.fp32               v10, v10, v9, v12 
    97 : unspill                v13, 8            
    98 : mov                    v9, v13           
    99 : fma.fp32               v9, v9, v10, v12  
   100 : unspill                v13, 0            
   101 : mov                    v10, v13          
   102 : fma.fp32               v10, v10, v9, v12 
   103 : mul.fp32               v9, v12, v12      
   104 : mov                    v12, v12          
   105 : fma.fp32               v12, v12, v10, v9 
   106 : add.fp32               v9, v12, v3       
   107 : unspill                v13, 4            
   108 : add.i32                v10, v11, v13     
   109 : sal.i32                v10, v10, 23      
   110 : mul.fp32               v9, v9, v10       
   111 : vst.fp32               i1, i9, v9        
   112 : add                    i9, i9, 32        
   113 : sub                    i8, i8, 8         
   114 : annotation:endwhile    0, 2              
   115 : ret                                      
   116 : unspill                v6, 24            
   117 : unspill                v7, 28            
   118 : unspill                v8, 32            
   119 : unspill                v9, 36            
   120 : unspill                v10, 40           
   121 : unspill                v11, 44           
   122 : unspill                v12, 48           
   123 : unspill                v13, 52           
   124 : add                    i4, i4, 456       
