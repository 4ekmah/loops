min_max_scalar(i0, i1, i2, i3)
     0 : sub                    i4, i4, 104     
     1 : spill                  11, i13         
     2 : mov                    s9, 0           
     3 : mov                    s4, 0           
     4 : mov                    s5, 0           
     5 : load.i32               i13, i1         
     6 : spill                  6, i13          
     7 : mov                    i13, s6         
     8 : spill                  7, i13          
     9 : mov                    i2, i2          
    10 : mul                    i2, i2, 4       
    11 : spill                  8, i2           
    12 : annotation:whilecstart 0               
    13 : unspill                i13, 8          
    14 : cmp                    s9, i13         
    15 : jmp_ge                 __loops_label_2 
    16 : annotation:whilecend                   
    17 : unspill                i13, 9          
    18 : load.i32               i0, i1, i13     
    19 : annotation:ifcstart                    
    20 : cmp                    i0, s6          
    21 : jmp_ge                 __loops_label_4 
    22 : annotation:ifcend                      
    23 : mov                    s6, i0          
    24 : mov                    i13, s9         
    25 : spill                  4, i13          
    26 : annotation:endif       4               
    27 : annotation:ifcstart                    
    28 : cmp                    i0, s7          
    29 : jmp_le                 __loops_label_6 
    30 : annotation:ifcend                      
    31 : mov                    s7, i0          
    32 : mov                    i13, s9         
    33 : spill                  5, i13          
    34 : annotation:endif       6               
    35 : add                    s9, s9, 4       
    36 : annotation:endwhile    0, 2            
    37 : mov                    s10, 4          
    38 : mov                    i1, s4          
    39 : mov                    i0, i1          
    40 : div                    i0, i0, s10     
    41 : mov                    i1, i0          
    42 : mov                    i0, s5          
    43 : div                    i0, i0, s10     
    44 : store.i32              i8, i1          
    45 : store.i32              i9, i0          
    46 : mov                    i0, 0           
    47 : ret                                    
    48 : unspill                i13, 11         
    49 : add                    i4, i4, 104     
