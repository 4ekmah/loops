triangle_types(i0, i1, i2)
     0 : sub                 i4, i4, 24       
     1 : spill               1, i2            
     2 : annotation:ifcstart                  
     3 : cmp                 i1, 0            
     4 : jmp_le              __loops_label_0  
     5 : cmp                 s1, 0            
     6 : jmp_le              __loops_label_0  
     7 : cmp                 i8, 0            
     8 : jmp_gt              __loops_label_1  
     9 : __loops_label_0:                     
    10 : annotation:ifcend                    
    11 : mov                 i0, 0            
    12 : ret                                  
    13 : annotation:else     1, 2             
    14 : annotation:ifcstart                  
    15 : mov                 i9, s1           
    16 : add                 i9, i9, i8       
    17 : cmp                 i1, i9           
    18 : jmp_gt              __loops_label_3  
    19 : mov                 i9, i1           
    20 : add                 i9, i9, i8       
    21 : cmp                 s1, i9           
    22 : jmp_gt              __loops_label_3  
    23 : mov                 i9, i1           
    24 : add                 i9, i9, s1       
    25 : cmp                 i8, i9           
    26 : jmp_le              __loops_label_4  
    27 : __loops_label_3:                     
    28 : annotation:ifcend                    
    29 : mov                 i0, 0            
    30 : ret                                  
    31 : annotation:else     4, 5             
    32 : annotation:ifcstart                  
    33 : cmp                 i1, s1           
    34 : jmp_ne              __loops_label_7  
    35 : cmp                 i1, i8           
    36 : jmp_ne              __loops_label_7  
    37 : annotation:ifcend                    
    38 : mov                 i0, 2            
    39 : ret                                  
    40 : annotation:else     7, 8             
    41 : annotation:ifcstart                  
    42 : cmp                 i1, s1           
    43 : jmp_eq              __loops_label_9  
    44 : cmp                 i1, i8           
    45 : jmp_eq              __loops_label_9  
    46 : cmp                 s1, i8           
    47 : jmp_ne              __loops_label_10 
    48 : __loops_label_9:                     
    49 : annotation:ifcend                    
    50 : mov                 i0, 3            
    51 : ret                                  
    52 : annotation:else     10, 11           
    53 : annotation:ifcstart                  
    54 : mov                 i9, i1           
    55 : mul                 i9, i9, i1       
    56 : mov                 i0, s1           
    57 : mul                 i0, i0, s1       
    58 : mov                 i2, i8           
    59 : mul                 i2, i2, i8       
    60 : mov                 i2, i2           
    61 : add                 i2, i2, i0       
    62 : cmp                 i9, i2           
    63 : jmp_eq              __loops_label_12 
    64 : mov                 i2, s1           
    65 : mul                 i2, i2, s1       
    66 : mov                 i9, i1           
    67 : mul                 i9, i9, i1       
    68 : mov                 i0, i8           
    69 : mul                 i0, i0, i8       
    70 : mov                 i0, i0           
    71 : add                 i0, i0, i9       
    72 : cmp                 i2, i0           
    73 : jmp_eq              __loops_label_12 
    74 : mov                 i2, i8           
    75 : mul                 i2, i2, i8       
    76 : mov                 i9, i1           
    77 : mul                 i9, i9, i1       
    78 : mov                 i0, s1           
    79 : mul                 i0, i0, s1       
    80 : mov                 i0, i0           
    81 : add                 i0, i0, i9       
    82 : cmp                 i2, i0           
    83 : jmp_ne              __loops_label_13 
    84 : __loops_label_12:                    
    85 : annotation:ifcend                    
    86 : mov                 i0, 1            
    87 : ret                                  
    88 : annotation:else     13, 14           
    89 : annotation:ifcstart                  
    90 : mov                 i2, i1           
    91 : mul                 i2, i2, i1       
    92 : mov                 i9, s1           
    93 : mul                 i9, i9, s1       
    94 : mov                 i0, i8           
    95 : mul                 i0, i0, i8       
    96 : mov                 i0, i0           
    97 : add                 i0, i0, i9       
    98 : cmp                 i2, i0           
    99 : jmp_gt              __loops_label_15 
   100 : mov                 i2, s1           
   101 : mul                 i2, i2, s1       
   102 : mov                 i9, i1           
   103 : mul                 i9, i9, i1       
   104 : mov                 i0, i8           
   105 : mul                 i0, i0, i8       
   106 : mov                 i0, i0           
   107 : add                 i0, i0, i9       
   108 : cmp                 i2, i0           
   109 : jmp_gt              __loops_label_15 
   110 : mov                 i2, i8           
   111 : mul                 i2, i2, i8       
   112 : mov                 i8, i1           
   113 : mul                 i8, i8, i1       
   114 : mov                 i1, s1           
   115 : mul                 i1, i1, s1       
   116 : mov                 i1, i1           
   117 : add                 i1, i1, i8       
   118 : cmp                 i2, i1           
   119 : jmp_le              __loops_label_16 
   120 : __loops_label_15:                    
   121 : annotation:ifcend                    
   122 : mov                 i0, 5            
   123 : ret                                  
   124 : annotation:else     16, 17           
   125 : mov                 i0, 4            
   126 : ret                                  
   127 : annotation:endif    2                
   128 : annotation:endif    5                
   129 : annotation:endif    8                
   130 : annotation:endif    11               
   131 : annotation:endif    14               
   132 : annotation:endif    17               
   133 : add                 i4, i4, 24       
