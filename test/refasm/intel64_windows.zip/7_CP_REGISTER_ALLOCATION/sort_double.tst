sort_double(i0, i1)
     0 : sub                    i4, i4, 632      
     1 : spill                  77, i13          
     2 : spill                  78, i5           
     3 : mov                    i5, i4           
     4 : add                    i5, i5, 624      
     5 : mov                    s74, i2          
     6 : shl                    s74, s74, 3      
     7 : unspill                i13, 74          
     8 : sub                    s75, i13, 8      
     9 : mov                    s76, 0           
    10 : annotation:whilecstart 0                
    11 : unspill                i13, 75          
    12 : cmp                    s76, i13         
    13 : jmp_ge                 __loops_label_2  
    14 : annotation:whilecend                    
    15 : mov                    i13, s76         
    16 : spill                  73, i13          
    17 : mov                    i13, s73         
    18 : spill                  72, i13          
    19 : add                    s72, s72, 8      
    20 : annotation:whilecstart 3                
    21 : unspill                i13, 74          
    22 : cmp                    s72, i13         
    23 : jmp_ge                 __loops_label_5  
    24 : annotation:whilecend                    
    25 : annotation:ifcstart                     
    26 : unspill                i13, 72          
    27 : load.fp64              i0, i1, i13      
    28 : unspill                i13, 73          
    29 : load.fp64              i9, i1, i13      
    30 : mov                    i8, -887485760   
    31 : call                   [i8](i8, i0, i9) 
    32 : cmp                    i8, 0            
    33 : jmp_eq                 __loops_label_7  
    34 : annotation:ifcend                       
    35 : mov                    i13, s72         
    36 : spill                  73, i13          
    37 : annotation:endif       7                
    38 : add                    s72, s72, 8      
    39 : annotation:endwhile    3, 5             
    40 : annotation:ifcstart                     
    41 : unspill                i13, 76          
    42 : cmp                    s73, i13         
    43 : jmp_eq                 __loops_label_9  
    44 : annotation:ifcend                       
    45 : unspill                i13, 76          
    46 : load.fp64              i8, i1, i13      
    47 : unspill                i13, 73          
    48 : load.fp64              i9, i1, i13      
    49 : unspill                i13, 73          
    50 : store.fp64             i1, i13, i8      
    51 : unspill                i13, 76          
    52 : store.fp64             i1, i13, i9      
    53 : annotation:endif       9                
    54 : add                    s76, s76, 8      
    55 : annotation:endwhile    0, 2             
    56 : ret                                     
    57 : unspill                i5, 78           
    58 : unspill                i13, 77          
    59 : add                    i4, i4, 632      
