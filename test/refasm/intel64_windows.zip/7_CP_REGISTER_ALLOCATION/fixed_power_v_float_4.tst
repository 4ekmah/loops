fixed_power_v_float_4(i0, i1, i2)
     0 : sub                    i4, i4, 8       
     1 : mov                    i9, 0           
     2 : mov                    i8, i8          
     3 : mul                    i8, i8, 4       
     4 : mov                    i0, i8          
     5 : annotation:whilecstart 0               
     6 : cmp                    i9, i0          
     7 : jmp_ge                 __loops_label_2 
     8 : annotation:whilecend                   
     9 : vld.fp32               v0, i1, i9      
    10 : mul.fp32               v0, v0, v0      
    11 : mul.fp32               v0, v0, v0      
    12 : vst.fp32               i2, i9, v0      
    13 : add                    i9, i9, 32      
    14 : annotation:endwhile    0, 2            
    15 : mov                    i0, 0           
    16 : ret                                    
    17 : add                    i4, i4, 8       
