fixed_power_v_double_0(i0, i1, i2)
     0 : sub                    i4, i4, 40      
     1 : mov                    i9, 0           
     2 : mov                    i8, i8          
     3 : mul                    i8, i8, 8       
     4 : spill                  4, i8           
     5 : annotation:whilecstart 0               
     6 : cmp                    i9, s4          
     7 : jmp_ge                 __loops_label_2 
     8 : annotation:whilecend                   
     9 : vld.fp64               v0, i1, i9      
    10 : mov                    i0, 0           
    11 : vdef.fp64              v0              
    12 : setlane.fp64           v0, 0, i0       
    13 : broadcast.fp64         v0, v0, 0       
    14 : vst.fp64               i2, i9, v0      
    15 : add                    i9, i9, 32      
    16 : annotation:endwhile    0, 2            
    17 : mov                    i0, 0           
    18 : ret                                    
    19 : add                    i4, i4, 40      
