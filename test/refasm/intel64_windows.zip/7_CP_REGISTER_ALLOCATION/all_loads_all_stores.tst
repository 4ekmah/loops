all_loads_all_stores(i0, i1, i2, i3, i4)
     0 : sub                    i4, i4, 88       
     1 : spill                  8, i13           
     2 : spill                  9, i14           
     3 : spill                  7, i9            
     4 : mov                    s1, 0            
     5 : mov                    s2, 0            
     6 : mov                    s3, 0            
     7 : mov                    i0, 2            
     8 : mov                    i9, 1            
     9 : cmp                    i2, 1            
    10 : select_gt              i9, i0, i9       
    11 : mov                    i0, 4            
    12 : cmp                    i2, 3            
    13 : select_gt              i9, i0, i9       
    14 : mov                    i0, 8            
    15 : cmp                    i2, 5            
    16 : select_gt              i13, i0, i9      
    17 : spill                  4, i13           
    18 : mov                    i0, 2            
    19 : mov                    i9, 1            
    20 : cmp                    s7, 1            
    21 : select_gt              i9, i0, i9       
    22 : mov                    i0, 4            
    23 : cmp                    s7, 3            
    24 : select_gt              i9, i0, i9       
    25 : mov                    i0, 8            
    26 : cmp                    s7, 5            
    27 : select_gt              i9, i0, i9       
    28 : spill                  5, i9            
    29 : annotation:whilecstart 0                
    30 : unspill                i13, 16          
    31 : cmp                    s1, i13          
    32 : jmp_ge                 __loops_label_2  
    33 : annotation:whilecend                    
    34 : def                    i13              
    35 : spill                  6, i13           
    36 : annotation:ifcstart                     
    37 : cmp                    i2, 0            
    38 : jmp_ne                 __loops_label_4  
    39 : annotation:ifcend                       
    40 : unspill                i13, 2           
    41 : load.u8                i14, i1, i13     
    42 : spill                  6, i14           
    43 : annotation:else        4, 5             
    44 : annotation:ifcstart                     
    45 : cmp                    i2, 1            
    46 : jmp_ne                 __loops_label_7  
    47 : annotation:ifcend                       
    48 : unspill                i13, 2           
    49 : load.i8                i14, i1, i13     
    50 : spill                  6, i14           
    51 : annotation:else        7, 8             
    52 : annotation:ifcstart                     
    53 : cmp                    i2, 2            
    54 : jmp_ne                 __loops_label_10 
    55 : annotation:ifcend                       
    56 : unspill                i13, 2           
    57 : load.u16               i14, i1, i13     
    58 : spill                  6, i14           
    59 : annotation:else        10, 11           
    60 : annotation:ifcstart                     
    61 : cmp                    i2, 3            
    62 : jmp_ne                 __loops_label_13 
    63 : annotation:ifcend                       
    64 : unspill                i13, 2           
    65 : load.i16               i14, i1, i13     
    66 : spill                  6, i14           
    67 : annotation:else        13, 14           
    68 : annotation:ifcstart                     
    69 : cmp                    i2, 4            
    70 : jmp_ne                 __loops_label_16 
    71 : annotation:ifcend                       
    72 : unspill                i13, 2           
    73 : load.u32               i14, i1, i13     
    74 : spill                  6, i14           
    75 : annotation:else        16, 17           
    76 : annotation:ifcstart                     
    77 : cmp                    i2, 5            
    78 : jmp_ne                 __loops_label_19 
    79 : annotation:ifcend                       
    80 : unspill                i13, 2           
    81 : load.i32               i14, i1, i13     
    82 : spill                  6, i14           
    83 : annotation:else        19, 20           
    84 : annotation:ifcstart                     
    85 : cmp                    i2, 6            
    86 : jmp_ne                 __loops_label_22 
    87 : annotation:ifcend                       
    88 : unspill                i13, 2           
    89 : load.u64               i14, i1, i13     
    90 : spill                  6, i14           
    91 : annotation:else        22, 23           
    92 : unspill                i13, 2           
    93 : load.i64               i14, i1, i13     
    94 : spill                  6, i14           
    95 : annotation:endif       5                
    96 : annotation:endif       8                
    97 : annotation:endif       11               
    98 : annotation:endif       14               
    99 : annotation:endif       17               
   100 : annotation:endif       20               
   101 : annotation:endif       23               
   102 : annotation:ifcstart                     
   103 : cmp                    s7, 0            
   104 : jmp_ne                 __loops_label_25 
   105 : annotation:ifcend                       
   106 : unspill                i13, 3           
   107 : unspill                i14, 6           
   108 : store.u8               i8, i13, i14     
   109 : annotation:else        25, 26           
   110 : annotation:ifcstart                     
   111 : cmp                    s7, 1            
   112 : jmp_ne                 __loops_label_28 
   113 : annotation:ifcend                       
   114 : unspill                i13, 3           
   115 : unspill                i14, 6           
   116 : store.i8               i8, i13, i14     
   117 : annotation:else        28, 29           
   118 : annotation:ifcstart                     
   119 : cmp                    s7, 2            
   120 : jmp_ne                 __loops_label_31 
   121 : annotation:ifcend                       
   122 : unspill                i13, 3           
   123 : unspill                i14, 6           
   124 : store.u16              i8, i13, i14     
   125 : annotation:else        31, 32           
   126 : annotation:ifcstart                     
   127 : cmp                    s7, 3            
   128 : jmp_ne                 __loops_label_34 
   129 : annotation:ifcend                       
   130 : unspill                i13, 3           
   131 : unspill                i14, 6           
   132 : store.i16              i8, i13, i14     
   133 : annotation:else        34, 35           
   134 : annotation:ifcstart                     
   135 : cmp                    s7, 4            
   136 : jmp_ne                 __loops_label_37 
   137 : annotation:ifcend                       
   138 : unspill                i13, 3           
   139 : unspill                i14, 6           
   140 : store.u32              i8, i13, i14     
   141 : annotation:else        37, 38           
   142 : annotation:ifcstart                     
   143 : cmp                    s7, 5            
   144 : jmp_ne                 __loops_label_40 
   145 : annotation:ifcend                       
   146 : unspill                i13, 3           
   147 : unspill                i14, 6           
   148 : store.i32              i8, i13, i14     
   149 : annotation:else        40, 41           
   150 : annotation:ifcstart                     
   151 : cmp                    s7, 6            
   152 : jmp_ne                 __loops_label_43 
   153 : annotation:ifcend                       
   154 : unspill                i13, 3           
   155 : unspill                i14, 6           
   156 : store.u64              i8, i13, i14     
   157 : annotation:else        43, 44           
   158 : unspill                i13, 3           
   159 : unspill                i14, 6           
   160 : store.i64              i8, i13, i14     
   161 : annotation:endif       26               
   162 : annotation:endif       29               
   163 : annotation:endif       32               
   164 : annotation:endif       35               
   165 : annotation:endif       38               
   166 : annotation:endif       41               
   167 : annotation:endif       44               
   168 : unspill                i13, 4           
   169 : add                    s2, s2, i13      
   170 : unspill                i13, 5           
   171 : add                    s3, s3, i13      
   172 : add                    s1, s1, 1        
   173 : annotation:endwhile    0, 2             
   174 : unspill                i13, 8           
   175 : unspill                i14, 9           
   176 : add                    i4, i4, 88       
