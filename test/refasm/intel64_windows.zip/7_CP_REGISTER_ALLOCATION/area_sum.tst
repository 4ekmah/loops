area_sum(i0, i1)
     0 : sub                    i4, i4, 616       
     1 : spill                  75, i13           
     2 : spill                  76, i5            
     3 : mov                    i5, i4            
     4 : add                    i5, i5, 608       
     5 : mov                    s72, 0            
     6 : annotation:whilecstart 0                 
     7 : cmp                    i2, 0             
     8 : jmp_le                 __loops_label_2   
     9 : annotation:whilecend                     
    10 : load.i8                i13, i1           
    11 : spill                  73, i13           
    12 : mov                    i0, 1071394160    
    13 : mov                    i8, 1071394464    
    14 : mov                    i9, 1071394688    
    15 : cmp                    s73, 1            
    16 : select_eq              i9, i8, i9        
    17 : cmp                    s73, 0            
    18 : select_eq              i13, i0, i9       
    19 : spill                  74, i13           
    20 : mov                    i8, 1071393840    
    21 : mov                    i0, 1071393952    
    22 : mov                    i9, 1071394016    
    23 : cmp                    s73, 1            
    24 : select_eq              i9, i0, i9        
    25 : cmp                    s73, 0            
    26 : select_eq              i9, i8, i9        
    27 : unspill                i13, 74           
    28 : call_noret             [i13](i1)         
    29 : call                   [i9](i8, i1)      
    30 : mov                    i9, 1071393760    
    31 : unspill                i13, 72           
    32 : call                   [i9](i8, i13, i8) 
    33 : mov                    s72, i8           
    34 : add                    i1, i1, 56        
    35 : sub                    i2, i2, 1         
    36 : annotation:endwhile    0, 2              
    37 : mov                    i0, s72           
    38 : ret                                      
    39 : unspill                i5, 76            
    40 : unspill                i13, 75           
    41 : add                    i4, i4, 616       
