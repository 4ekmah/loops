area_sum(i0, i1)
     0 : sub                    i4, i4, 616       
     1 : spill                  75, i13           
     2 : spill                  76, i5            
     3 : mov                    i5, i4            
     4 : add                    i5, i5, 608       
     5 : mov                    s72, 0            
     6 : annotation:whilecstart 0                 
     7 : cmp                    i2, 0             
     8 : jmp_le                 __loops_label_2   
     9 : annotation:whilecend                     
    10 : load.i8                i13, i1           
    11 : spill                  73, i13           
    12 : mov                    i0, -887480080    
    13 : mov                    i8, -887479776    
    14 : mov                    i9, -887479552    
    15 : cmp                    s73, 1            
    16 : select_eq              i9, i8, i9        
    17 : cmp                    s73, 0            
    18 : select_eq              i13, i0, i9       
    19 : spill                  74, i13           
    20 : mov                    i8, -887480400    
    21 : mov                    i0, -887480288    
    22 : mov                    i9, -887480224    
    23 : cmp                    s73, 1            
    24 : select_eq              i9, i0, i9        
    25 : cmp                    s73, 0            
    26 : select_eq              i9, i8, i9        
    27 : unspill                i13, 74           
    28 : call_noret             [i13](i1)         
    29 : spill                  74, i13           
    30 : call                   [i9](i8, i1)      
    31 : mov                    i9, -887480480    
    32 : unspill                i13, 72           
    33 : call                   [i9](i8, i13, i8) 
    34 : mov                    s72, i8           
    35 : add                    i1, i1, 56        
    36 : sub                    i2, i2, 1         
    37 : annotation:endwhile    0, 2              
    38 : mov                    i0, s72           
    39 : ret                                      
    40 : unspill                i5, 76            
    41 : unspill                i13, 75           
    42 : add                    i4, i4, 616       
