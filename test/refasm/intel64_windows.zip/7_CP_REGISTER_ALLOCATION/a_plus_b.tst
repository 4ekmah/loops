a_plus_b(i0, i1)
     0 : mov i2, i2     
     1 : add i2, i2, i1 
     2 : mov i0, i2     
     3 : ret            
