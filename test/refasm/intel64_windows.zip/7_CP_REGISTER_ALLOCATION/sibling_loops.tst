sibling_loops(i0, i1, i2)
     0 : sub                    i4, i4, 24      
     1 : spill                  1, i13          
     2 : mov                    i9, 0           
     3 : mov                    s0, 0           
     4 : annotation:whilecstart 0               
     5 : cmp                    i9, i2          
     6 : jmp_ge                 __loops_label_2 
     7 : annotation:whilecend                   
     8 : load.i32               i0, i1, i9      
     9 : add                    s0, s0, i0      
    10 : add                    i9, i9, 4       
    11 : annotation:endwhile    0, 2            
    12 : mov                    i0, 0           
    13 : annotation:whilecstart 3               
    14 : cmp                    i9, 0           
    15 : jmp_le                 __loops_label_5 
    16 : annotation:whilecend                   
    17 : add                    i0, i0, 1       
    18 : sub                    i9, i9, 4       
    19 : annotation:endwhile    3, 5            
    20 : unspill                i13, 0          
    21 : store.i32              i8, i13         
    22 : store.i32              i8, 4, i0       
    23 : mov                    i0, 0           
    24 : ret                                    
    25 : unspill                i13, 1          
    26 : add                    i4, i4, 24      
