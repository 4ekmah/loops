conditionpainter(i0)
     0 : sub                    i4, i4, 56      
     1 : spill                  5, i13          
     2 : mov                    i13, -5         
     3 : spill                  2, i13          
     4 : annotation:whilecstart 0               
     5 : cmp                    s2, 5           
     6 : jmp_gt                 __loops_label_2 
     7 : annotation:whilecend                   
     8 : mov                    i2, s2          
     9 : add                    i2, i2, 5       
    10 : mov                    i2, i2          
    11 : mul                    i2, i2, 11      
    12 : mov                    s1, i2          
    13 : unspill                i13, 1          
    14 : mul                    i13, i13, 8     
    15 : spill                  1, i13          
    16 : mov                    i13, -5         
    17 : spill                  0, i13          
    18 : annotation:whilecstart 3               
    19 : cmp                    s0, 5           
    20 : jmp_gt                 __loops_label_5 
    21 : annotation:whilecend                   
    22 : mov                    i0, s0          
    23 : add                    i0, i0, 3       
    24 : mov                    i9, 0           
    25 : cmp                    s2, i0          
    26 : iverson_ge             i9              
    27 : mov                    i0, 0           
    28 : cmp                    s2, 4           
    29 : iverson_le             i0              
    30 : mov                    i0, i0          
    31 : and                    i0, i0, i9      
    32 : mov                    i9, 0           
    33 : cmp                    s0, -2          
    34 : iverson_ge             i9              
    35 : mov                    i9, i9          
    36 : and                    i9, i9, i0      
    37 : mov                    i0, 0           
    38 : cmp                    s0, 0           
    39 : iverson_le             i0              
    40 : mov                    i0, i0          
    41 : and                    i0, i0, i9      
    42 : unspill                i13, 0          
    43 : sub                    i9, i13, 1      
    44 : mov                    i8, 0           
    45 : cmp                    s2, i9          
    46 : iverson_le             i8              
    47 : mov                    i9, 0           
    48 : cmp                    s0, 0           
    49 : iverson_ge             i9              
    50 : mov                    i9, i9          
    51 : and                    i9, i9, i8      
    52 : mov                    i8, 0           
    53 : cmp                    s2, 0           
    54 : iverson_le             i8              
    55 : mov                    i8, i8          
    56 : and                    i8, i8, i9      
    57 : mov                    i9, s0          
    58 : mul                    i9, i9, s0      
    59 : mov                    i2, s2          
    60 : mul                    i2, i2, s2      
    61 : mov                    i2, i2          
    62 : add                    i2, i2, i9      
    63 : mov                    i9, 0           
    64 : cmp                    i2, 9           
    65 : iverson_le             i9              
    66 : mov                    i9, i9          
    67 : and                    i9, i9, i8      
    68 : mov                    s3, i9          
    69 : or                     s3, s3, i0      
    70 : mov                    i2, 2           
    71 : mov                    s4, 0           
    72 : mov                    i0, 0           
    73 : cmp                    s0, 2           
    74 : iverson_ge             i0              
    75 : mov                    i9, 0           
    76 : cmp                    s0, 4           
    77 : iverson_le             i9              
    78 : mov                    i9, i9          
    79 : and                    i9, i9, i0      
    80 : mov                    i0, 0           
    81 : cmp                    s2, 1           
    82 : iverson_ge             i0              
    83 : mov                    i8, 0           
    84 : cmp                    s2, 3           
    85 : iverson_le             i8              
    86 : mov                    i8, i8          
    87 : and                    i8, i8, i0      
    88 : mov                    i8, i8          
    89 : or                     i8, i8, i9      
    90 : mov                    i9, s0          
    91 : mul                    i9, i9, s0      
    92 : mov                    i0, s2          
    93 : mul                    i0, i0, s2      
    94 : mov                    i0, i0          
    95 : add                    i0, i0, i9      
    96 : mov                    i9, 0           
    97 : cmp                    i0, 16          
    98 : iverson_le             i9              
    99 : mov                    i9, i9          
   100 : and                    i9, i9, i8      
   101 : cmp                    i9, 0           
   102 : unspill                i13, 4          
   103 : select_ne              i2, i2, i13     
   104 : mov                    i2, i2          
   105 : add                    i2, i2, s3      
   106 : annotation:ifcstart                    
   107 : mov                    i8, s2          
   108 : mul                    i8, i8, 2       
   109 : cmp                    i8, s0          
   110 : jmp_gt                 __loops_label_8 
   111 : mov                    i8, s0          
   112 : add                    i8, i8, 3       
   113 : mov                    i8, i8          
   114 : neg                    i8, i8          
   115 : mov                    i9, s0          
   116 : add                    i9, i9, 3       
   117 : mov                    i9, i9          
   118 : mul                    i9, i9, i8      
   119 : cmp                    s2, i9          
   120 : jmp_le                 __loops_label_9 
   121 : __loops_label_8:                       
   122 : mov                    i8, s0          
   123 : mul                    i8, i8, 2       
   124 : cmp                    s2, i8          
   125 : jmp_gt                 __loops_label_7 
   126 : mov                    i8, s0          
   127 : add                    i8, i8, 3       
   128 : mov                    i8, i8          
   129 : neg                    i8, i8          
   130 : mov                    i9, s0          
   131 : add                    i9, i9, 3       
   132 : mov                    i9, i9          
   133 : mul                    i9, i9, i8      
   134 : cmp                    s2, i9          
   135 : jmp_gt                 __loops_label_7 
   136 : __loops_label_9:                       
   137 : cmp                    s0, 0           
   138 : jmp_gt                 __loops_label_7 
   139 : annotation:ifcend                      
   140 : add                    i2, i2, 3       
   141 : annotation:endif       7               
   142 : mov                    i8, s0          
   143 : add                    i8, i8, 5       
   144 : mov                    i8, i8          
   145 : shl                    i8, i8, 3       
   146 : mov                    i8, i8          
   147 : add                    i8, i8, s1      
   148 : store.i64              i1, i8, i2      
   149 : add                    s0, s0, 1       
   150 : annotation:endwhile    3, 5            
   151 : add                    s2, s2, 1       
   152 : annotation:endwhile    0, 2            
   153 : ret                                    
   154 : unspill                i13, 5          
   155 : add                    i4, i4, 56      
