fixed_power_9(i0)
     0 : mov i2, i1     
     1 : mul i2, i2, i1 
     2 : mov i8, i2     
     3 : mul i8, i8, i2 
     4 : mov i2, i8     
     5 : mul i2, i2, i8 
     6 : mov i2, i2     
     7 : mul i2, i2, i1 
     8 : mov i0, i2     
     9 : ret            
