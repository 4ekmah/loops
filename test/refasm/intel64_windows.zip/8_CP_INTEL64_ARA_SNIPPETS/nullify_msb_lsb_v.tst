nullify_msb_lsb_v(i0, i1, i2, i3)
     0 : sub              i4, i4, 24      
     1 : spill            1, i13          
     2 : mov              i0, 0           
     3 : mov              i13, i9         
     4 : mul              i13, i13, 4     
     5 : spill            0, i13          
     6 : mov              i9, 1           
     7 : vdef.u32         v0              
     8 : setlane.u32      v0, 0, i9       
     9 : broadcast.u32    v0, v0, 0       
    10 : __loops_label_0:                 
    11 : cmp              i0, s0          
    12 : jmp_ge           __loops_label_2 
    13 : vld.u32          v1, i1, i0      
    14 : shr.u32          v2, v1, 1       
    15 : or               v2, v1, v2      
    16 : shr.u32          v3, v2, 2       
    17 : or               v2, v2, v3      
    18 : shr.u32          v3, v2, 4       
    19 : or               v2, v2, v3      
    20 : shr.u32          v3, v2, 8       
    21 : or               v2, v2, v3      
    22 : shr.u32          v3, v2, 16      
    23 : or               v2, v2, v3      
    24 : add.u32          v2, v2, v0      
    25 : shr.u32          v2, v2, 1       
    26 : xor              v2, v2, v1      
    27 : vst.u32          i2, i0, v2      
    28 : sub.u32          v2, v1, v0      
    29 : mov              i9, 255         
    30 : vdef.u8          v3              
    31 : setlane.u8       v3, 0, i9       
    32 : broadcast.u8     v3, v3, 0       
    33 : xor              v2, v2, v3      
    34 : and              v2, v1, v2      
    35 : xor              v1, v2, v1      
    36 : vst.u32          i8, i0, v1      
    37 : add              i0, i0, 32      
    38 : jmp              0               
    39 : __loops_label_2:                 
    40 : unspill          i13, 1          
    41 : add              i4, i4, 24      
    42 : ret                              
