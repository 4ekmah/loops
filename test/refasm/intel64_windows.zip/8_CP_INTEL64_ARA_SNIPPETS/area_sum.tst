area_sum(i0, i1)
     0 : sub              i4, i4, 616     
     1 : spill            75, i13         
     2 : spill            76, i5          
     3 : mov              i5, i4          
     4 : add              i5, i5, 608     
     5 : spill            74, i1          
     6 : spill            73, i2          
     7 : mov              s72, 0          
     8 : __loops_label_0:                 
     9 : cmp              s73, 0          
    10 : jmp_le           __loops_label_2 
    11 : unspill          i13, 74         
    12 : load.i8          i9, i13         
    13 : mov              i0, 2100734672  
    14 : mov              i8, 2100734976  
    15 : mov              i2, 2100735200  
    16 : cmp              i9, 1           
    17 : select_eq        i2, i8, i2      
    18 : cmp              i9, 0           
    19 : select_eq        i2, i0, i2      
    20 : mov              i8, 2100734352  
    21 : mov              i0, 2100734464  
    22 : mov              i1, 2100734528  
    23 : cmp              i9, 1           
    24 : select_eq        i1, i0, i1      
    25 : cmp              i9, 0           
    26 : select_eq        i1, i8, i1      
    27 : unspill          i13, 74         
    28 : spill            0, i0           
    29 : spill            1, i1           
    30 : spill            2, i2           
    31 : spill            3, i8           
    32 : spill            4, i9           
    33 : spill            5, i10          
    34 : spill            6, i11          
    35 : spill            8, v0           
    36 : spill            12, v1          
    37 : spill            16, v2          
    38 : spill            20, v3          
    39 : spill            24, v5          
    40 : spill            28, v6          
    41 : spill            32, v7          
    42 : spill            36, v8          
    43 : spill            40, v9          
    44 : spill            44, v10         
    45 : spill            48, v11         
    46 : spill            52, v12         
    47 : spill            56, v13         
    48 : spill            60, v14         
    49 : spill            64, v15         
    50 : mov              i1, i13         
    51 : sub              i4, i4, 32      
    52 : call_noret       [i2]()          
    53 : add              i4, i4, 32      
    54 : unspill          i0, 0           
    55 : unspill          i1, 1           
    56 : unspill          i2, 2           
    57 : unspill          i8, 3           
    58 : unspill          i9, 4           
    59 : unspill          i10, 5          
    60 : unspill          i11, 6          
    61 : unspill          v0, 8           
    62 : unspill          v1, 12          
    63 : unspill          v2, 16          
    64 : unspill          v3, 20          
    65 : unspill          v5, 24          
    66 : unspill          v6, 28          
    67 : unspill          v7, 32          
    68 : unspill          v8, 36          
    69 : unspill          v9, 40          
    70 : unspill          v10, 44         
    71 : unspill          v11, 48         
    72 : unspill          v12, 52         
    73 : unspill          v13, 56         
    74 : unspill          v14, 60         
    75 : unspill          v15, 64         
    76 : unspill          i13, 74         
    77 : spill            0, i0           
    78 : spill            1, i1           
    79 : spill            2, i2           
    80 : spill            3, i8           
    81 : spill            4, i9           
    82 : spill            5, i10          
    83 : spill            6, i11          
    84 : spill            8, v0           
    85 : spill            12, v1          
    86 : spill            16, v2          
    87 : spill            20, v3          
    88 : spill            24, v5          
    89 : spill            28, v6          
    90 : spill            32, v7          
    91 : spill            36, v8          
    92 : spill            40, v9          
    93 : spill            44, v10         
    94 : spill            48, v11         
    95 : spill            52, v12         
    96 : spill            56, v13         
    97 : spill            60, v14         
    98 : spill            64, v15         
    99 : mov              i1, i13         
   100 : unspill          i10, 1          
   101 : sub              i4, i4, 32      
   102 : call_noret       [i10]()         
   103 : add              i4, i4, 32      
   104 : mov              i1, i0          
   105 : unspill          i0, 0           
   106 : unspill          i2, 2           
   107 : unspill          i8, 3           
   108 : unspill          i9, 4           
   109 : unspill          i10, 5          
   110 : unspill          i11, 6          
   111 : unspill          v0, 8           
   112 : unspill          v1, 12          
   113 : unspill          v2, 16          
   114 : unspill          v3, 20          
   115 : unspill          v5, 24          
   116 : unspill          v6, 28          
   117 : unspill          v7, 32          
   118 : unspill          v8, 36          
   119 : unspill          v9, 40          
   120 : unspill          v10, 44         
   121 : unspill          v11, 48         
   122 : unspill          v12, 52         
   123 : unspill          v13, 56         
   124 : unspill          v14, 60         
   125 : unspill          v15, 64         
   126 : mov              i2, 2100734272  
   127 : unspill          i13, 72         
   128 : spill            0, i0           
   129 : spill            1, i1           
   130 : spill            2, i2           
   131 : spill            3, i8           
   132 : spill            4, i9           
   133 : spill            5, i10          
   134 : spill            6, i11          
   135 : spill            8, v0           
   136 : spill            12, v1          
   137 : spill            16, v2          
   138 : spill            20, v3          
   139 : spill            24, v5          
   140 : spill            28, v6          
   141 : spill            32, v7          
   142 : spill            36, v8          
   143 : spill            40, v9          
   144 : spill            44, v10         
   145 : spill            48, v11         
   146 : spill            52, v12         
   147 : spill            56, v13         
   148 : spill            60, v14         
   149 : spill            64, v15         
   150 : mov              i1, i13         
   151 : unspill          i2, 1           
   152 : unspill          i10, 2          
   153 : sub              i4, i4, 32      
   154 : call_noret       [i10]()         
   155 : add              i4, i4, 32      
   156 : mov              i1, i0          
   157 : unspill          i0, 0           
   158 : unspill          i2, 2           
   159 : unspill          i8, 3           
   160 : unspill          i9, 4           
   161 : unspill          i10, 5          
   162 : unspill          i11, 6          
   163 : unspill          v0, 8           
   164 : unspill          v1, 12          
   165 : unspill          v2, 16          
   166 : unspill          v3, 20          
   167 : unspill          v5, 24          
   168 : unspill          v6, 28          
   169 : unspill          v7, 32          
   170 : unspill          v8, 36          
   171 : unspill          v9, 40          
   172 : unspill          v10, 44         
   173 : unspill          v11, 48         
   174 : unspill          v12, 52         
   175 : unspill          v13, 56         
   176 : unspill          v14, 60         
   177 : unspill          v15, 64         
   178 : mov              s72, i1         
   179 : add              s74, s74, 56    
   180 : sub              s73, s73, 1     
   181 : jmp              0               
   182 : __loops_label_2:                 
   183 : mov              i0, s72         
   184 : unspill          i5, 76          
   185 : unspill          i13, 75         
   186 : add              i4, i4, 616     
   187 : ret                              
