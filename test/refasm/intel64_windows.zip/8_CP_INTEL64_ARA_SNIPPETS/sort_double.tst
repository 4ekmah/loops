sort_double(i0, i1)
     0 : sub              i4, i4, 632     
     1 : spill            75, i1          
     2 : spill            76, i13         
     3 : spill            77, i14         
     4 : spill            78, i5          
     5 : mov              i5, i4          
     6 : add              i5, i5, 624     
     7 : mov              s74, i2         
     8 : shl              s74, s74, 3     
     9 : unspill          i13, 74         
    10 : mov              s73, i13        
    11 : sub              s73, s73, 8     
    12 : mov              s72, 0          
    13 : __loops_label_0:                 
    14 : unspill          i13, 73         
    15 : cmp              s72, i13        
    16 : jmp_ge           __loops_label_2 
    17 : mov              i0, s72         
    18 : mov              i9, i0          
    19 : add              i9, i9, 8       
    20 : __loops_label_3:                 
    21 : cmp              i9, s74         
    22 : jmp_ge           __loops_label_5 
    23 : unspill          i13, 75         
    24 : load.fp64        i8, i13, i9     
    25 : unspill          i13, 75         
    26 : load.fp64        i2, i13, i0     
    27 : mov              i1, -1637073984 
    28 : spill            0, i0           
    29 : spill            1, i1           
    30 : spill            2, i2           
    31 : spill            3, i8           
    32 : spill            4, i9           
    33 : spill            5, i10          
    34 : spill            6, i11          
    35 : spill            8, v0           
    36 : spill            12, v1          
    37 : spill            16, v2          
    38 : spill            20, v3          
    39 : spill            24, v5          
    40 : spill            28, v6          
    41 : spill            32, v7          
    42 : spill            36, v8          
    43 : spill            40, v9          
    44 : spill            44, v10         
    45 : spill            48, v11         
    46 : spill            52, v12         
    47 : spill            56, v13         
    48 : spill            60, v14         
    49 : spill            64, v15         
    50 : mov              i1, i8          
    51 : unspill          i10, 1          
    52 : sub              i4, i4, 32      
    53 : call_noret       [i10]()         
    54 : add              i4, i4, 32      
    55 : mov              i1, i0          
    56 : unspill          i0, 0           
    57 : unspill          i2, 2           
    58 : unspill          i8, 3           
    59 : unspill          i9, 4           
    60 : unspill          i10, 5          
    61 : unspill          i11, 6          
    62 : unspill          v0, 8           
    63 : unspill          v1, 12          
    64 : unspill          v2, 16          
    65 : unspill          v3, 20          
    66 : unspill          v5, 24          
    67 : unspill          v6, 28          
    68 : unspill          v7, 32          
    69 : unspill          v8, 36          
    70 : unspill          v9, 40          
    71 : unspill          v10, 44         
    72 : unspill          v11, 48         
    73 : unspill          v12, 52         
    74 : unspill          v13, 56         
    75 : unspill          v14, 60         
    76 : unspill          v15, 64         
    77 : cmp              i1, 0           
    78 : jmp_eq           __loops_label_7 
    79 : mov              i0, i9          
    80 : __loops_label_7:                 
    81 : add              i9, i9, 8       
    82 : jmp              3               
    83 : __loops_label_5:                 
    84 : cmp              i0, s72         
    85 : jmp_eq           __loops_label_9 
    86 : unspill          i13, 75         
    87 : unspill          i14, 72         
    88 : load.fp64        i1, i13, i14    
    89 : unspill          i13, 75         
    90 : load.fp64        i2, i13, i0     
    91 : unspill          i13, 75         
    92 : store.fp64       i13, i0, i1     
    93 : unspill          i13, 75         
    94 : unspill          i14, 72         
    95 : store.fp64       i13, i14, i2    
    96 : __loops_label_9:                 
    97 : add              s72, s72, 8     
    98 : jmp              0               
    99 : __loops_label_2:                 
   100 : unspill          i5, 78          
   101 : unspill          i13, 76         
   102 : unspill          i14, 77         
   103 : add              i4, i4, 632     
   104 : ret                              
