helloworld_call()
     0 : sub        i4, i4, 584     
     1 : spill      72, i5          
     2 : mov        i5, i4          
     3 : add        i5, i5, 576     
     4 : mov        i1, -1637084304 
     5 : spill      0, i0           
     6 : spill      1, i1           
     7 : spill      2, i2           
     8 : spill      3, i8           
     9 : spill      4, i9           
    10 : spill      5, i10          
    11 : spill      6, i11          
    12 : spill      8, v0           
    13 : spill      12, v1          
    14 : spill      16, v2          
    15 : spill      20, v3          
    16 : spill      24, v5          
    17 : spill      28, v6          
    18 : spill      32, v7          
    19 : spill      36, v8          
    20 : spill      40, v9          
    21 : spill      44, v10         
    22 : spill      48, v11         
    23 : spill      52, v12         
    24 : spill      56, v13         
    25 : spill      60, v14         
    26 : spill      64, v15         
    27 : sub        i4, i4, 32      
    28 : call_noret [i1]()          
    29 : add        i4, i4, 32      
    30 : unspill    i0, 0           
    31 : unspill    i1, 1           
    32 : unspill    i2, 2           
    33 : unspill    i8, 3           
    34 : unspill    i9, 4           
    35 : unspill    i10, 5          
    36 : unspill    i11, 6          
    37 : unspill    v0, 8           
    38 : unspill    v1, 12          
    39 : unspill    v2, 16          
    40 : unspill    v3, 20          
    41 : unspill    v5, 24          
    42 : unspill    v6, 28          
    43 : unspill    v7, 32          
    44 : unspill    v8, 36          
    45 : unspill    v9, 40          
    46 : unspill    v10, 44         
    47 : unspill    v11, 48         
    48 : unspill    v12, 52         
    49 : unspill    v13, 56         
    50 : unspill    v14, 60         
    51 : unspill    v15, 64         
    52 : unspill    i5, 72          
    53 : add        i4, i4, 584     
    54 : ret                        
