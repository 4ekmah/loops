ten_args_to_sum(i0, i1, i2, i3, i4, i5, i6, i7, i8, i9)
     0 : sub     i4, i4, 8  
     1 : spill   0, i13     
     2 : unspill i0, 6      
     3 : mul     i1, i1, 1  
     4 : mul     i2, i2, 2  
     5 : add     i1, i1, i2 
     6 : mul     i8, i8, 3  
     7 : add     i1, i1, i8 
     8 : mul     i9, i9, 4  
     9 : add     i1, i1, i9 
    10 : mul     i0, i0, 5  
    11 : add     i1, i1, i0 
    12 : unspill i13, 7     
    13 : mov     i2, i13    
    14 : mul     i2, i2, 6  
    15 : add     i1, i1, i2 
    16 : unspill i13, 8     
    17 : mov     i2, i13    
    18 : mul     i2, i2, 7  
    19 : add     i1, i1, i2 
    20 : unspill i13, 9     
    21 : mov     i2, i13    
    22 : mul     i2, i2, 8  
    23 : add     i1, i1, i2 
    24 : unspill i13, 10    
    25 : mov     i2, i13    
    26 : mul     i2, i2, 3  
    27 : add     i1, i1, i2 
    28 : unspill i13, 11    
    29 : mov     i2, i13    
    30 : mul     i2, i2, 2  
    31 : add     i1, i1, i2 
    32 : mov     i0, i1     
    33 : unspill i13, 0     
    34 : add     i4, i4, 8  
    35 : ret                
