triangle_types(i0, i1, i2)
     0 : sub               i4, i4, 24       
     1 : spill             0, i2            
     2 : spill             1, i13           
     3 : cmp               i1, 0            
     4 : jmp_le            __loops_label_0  
     5 : cmp               s0, 0            
     6 : jmp_le            __loops_label_0  
     7 : cmp               i8, 0            
     8 : jmp_gt            __loops_label_1  
     9 : __loops_label_0:                   
    10 : mov               i0, 0            
    11 : jmp               18               
    12 : __loops_label_1:                   
    13 : unspill           i13, 0           
    14 : mov               i9, i13          
    15 : add               i9, i9, i8       
    16 : cmp               i1, i9           
    17 : jmp_gt            __loops_label_3  
    18 : mov               i9, i1           
    19 : add               i9, i9, i8       
    20 : cmp               s0, i9           
    21 : jmp_gt            __loops_label_3  
    22 : mov               i9, i1           
    23 : add               i9, i9, s0       
    24 : cmp               i8, i9           
    25 : jmp_le            __loops_label_4  
    26 : __loops_label_3:                   
    27 : mov               i0, 0            
    28 : jmp               18               
    29 : __loops_label_4:                   
    30 : cmp               i1, s0           
    31 : jmp_ne            __loops_label_7  
    32 : cmp               i1, i8           
    33 : jmp_ne            __loops_label_7  
    34 : mov               i0, 2            
    35 : jmp               18               
    36 : __loops_label_7:                   
    37 : cmp               i1, s0           
    38 : jmp_eq            __loops_label_9  
    39 : cmp               i1, i8           
    40 : jmp_eq            __loops_label_9  
    41 : cmp               s0, i8           
    42 : jmp_ne            __loops_label_10 
    43 : __loops_label_9:                   
    44 : mov               i0, 3            
    45 : jmp               18               
    46 : __loops_label_10:                  
    47 : mov               i9, i1           
    48 : mul               i9, i9, i1       
    49 : unspill           i13, 0           
    50 : mov               i0, i13          
    51 : mul               i0, i0, s0       
    52 : mov               i2, i8           
    53 : mul               i2, i2, i8       
    54 : add               i0, i0, i2       
    55 : cmp               i9, i0           
    56 : jmp_eq            __loops_label_12 
    57 : unspill           i13, 0           
    58 : mov               i2, i13          
    59 : mul               i2, i2, s0       
    60 : mov               i9, i1           
    61 : mul               i9, i9, i1       
    62 : mov               i0, i8           
    63 : mul               i0, i0, i8       
    64 : add               i9, i9, i0       
    65 : cmp               i2, i9           
    66 : jmp_eq            __loops_label_12 
    67 : mov               i2, i8           
    68 : mul               i2, i2, i8       
    69 : mov               i9, i1           
    70 : mul               i9, i9, i1       
    71 : unspill           i13, 0           
    72 : mov               i0, i13          
    73 : mul               i0, i0, s0       
    74 : add               i9, i9, i0       
    75 : cmp               i2, i9           
    76 : jmp_ne            __loops_label_13 
    77 : __loops_label_12:                  
    78 : mov               i0, 1            
    79 : jmp               18               
    80 : __loops_label_13:                  
    81 : mov               i2, i1           
    82 : mul               i2, i2, i1       
    83 : unspill           i13, 0           
    84 : mov               i9, i13          
    85 : mul               i9, i9, s0       
    86 : mov               i0, i8           
    87 : mul               i0, i0, i8       
    88 : add               i9, i9, i0       
    89 : cmp               i2, i9           
    90 : jmp_gt            __loops_label_15 
    91 : unspill           i13, 0           
    92 : mov               i2, i13          
    93 : mul               i2, i2, s0       
    94 : mov               i9, i1           
    95 : mul               i9, i9, i1       
    96 : mov               i0, i8           
    97 : mul               i0, i0, i8       
    98 : add               i9, i9, i0       
    99 : cmp               i2, i9           
   100 : jmp_gt            __loops_label_15 
   101 : mul               i8, i8, i8       
   102 : mul               i1, i1, i1       
   103 : unspill           i13, 0           
   104 : mov               i2, i13          
   105 : mul               i2, i2, s0       
   106 : add               i1, i1, i2       
   107 : cmp               i8, i1           
   108 : jmp_le            __loops_label_16 
   109 : __loops_label_15:                  
   110 : mov               i0, 5            
   111 : jmp               18               
   112 : __loops_label_16:                  
   113 : mov               i0, 4            
   114 : jmp               18               
   115 : __loops_label_2:                   
   116 : __loops_label_5:                   
   117 : __loops_label_8:                   
   118 : __loops_label_11:                  
   119 : __loops_label_14:                  
   120 : __loops_label_17:                  
   121 : __loops_label_18:                  
   122 : unspill           i13, 1           
   123 : add               i4, i4, 24       
   124 : ret                                
