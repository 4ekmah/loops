snake(i0, i1, i2)
     0 : sub              i4, i4, 664     
     1 : spill            80, i13         
     2 : spill            81, i14         
     3 : spill            82, i5          
     4 : mov              i5, i4          
     5 : add              i5, i5, 656     
     6 : spill            79, i1          
     7 : spill            78, i2          
     8 : spill            77, i8          
     9 : unspill          i13, 78         
    10 : mov              i9, i13         
    11 : add              i9, i9, s77     
    12 : mov              s76, i9         
    13 : sub              s76, s76, 1     
    14 : mov              s75, 0          
    15 : mov              s72, 1          
    16 : mov              i13, s72        
    17 : neg              i13, i13        
    18 : spill            73, i13         
    19 : mov              s74, 0          
    20 : __loops_label_0:                 
    21 : unspill          i13, 76         
    22 : cmp              s74, i13        
    23 : jmp_ge           __loops_label_2 
    24 : mov              i0, 0           
    25 : mov              i9, 0           
    26 : unspill          i13, 74         
    27 : mov              i8, i13         
    28 : and              i8, i8, 1       
    29 : cmp              i8, 0           
    30 : jmp_eq           __loops_label_4 
    31 : unspill          i13, 77         
    32 : mov              i8, i13         
    33 : sub              i8, i8, 1       
    34 : unspill          i13, 74         
    35 : mov              i0, i13         
    36 : cmp              i0, i8          
    37 : select_gt        i0, i8, i0      
    38 : unspill          i13, 74         
    39 : mov              i2, i13         
    40 : sub              i2, i2, i8      
    41 : mov              i1, 0           
    42 : cmp              s74, i8         
    43 : mov              i9, i1          
    44 : select_gt        i9, i2, i9      
    45 : jmp              5               
    46 : __loops_label_4:                 
    47 : unspill          i13, 78         
    48 : mov              i1, i13         
    49 : sub              i1, i1, 1       
    50 : unspill          i13, 74         
    51 : mov              i2, i13         
    52 : sub              i2, i2, i1      
    53 : mov              i8, 0           
    54 : cmp              s74, i1         
    55 : mov              i0, i8          
    56 : select_gt        i0, i2, i0      
    57 : unspill          i13, 74         
    58 : mov              i9, i13         
    59 : cmp              i9, i1          
    60 : select_gt        i9, i1, i9      
    61 : __loops_label_5:                 
    62 : __loops_label_6:                 
    63 : cmp              i0, 0           
    64 : jmp_gt           __loops_label_8 
    65 : cmp              i0, s77         
    66 : jmp_ge           __loops_label_8 
    67 : cmp              i9, 0           
    68 : jmp_gt           __loops_label_8 
    69 : cmp              i9, s78         
    70 : jmp_ge           __loops_label_8 
    71 : mov              i1, 2100720720  
    72 : spill            0, i0           
    73 : spill            1, i1           
    74 : spill            2, i2           
    75 : spill            3, i8           
    76 : spill            4, i9           
    77 : spill            5, i10          
    78 : spill            6, i11          
    79 : spill            8, v0           
    80 : spill            12, v1          
    81 : spill            16, v2          
    82 : spill            20, v3          
    83 : spill            24, v5          
    84 : spill            28, v6          
    85 : spill            32, v7          
    86 : spill            36, v8          
    87 : spill            40, v9          
    88 : spill            44, v10         
    89 : spill            48, v11         
    90 : spill            52, v12         
    91 : spill            56, v13         
    92 : spill            60, v14         
    93 : spill            64, v15         
    94 : mov              i1, i0          
    95 : mov              i2, i9          
    96 : unspill          i10, 1          
    97 : sub              i4, i4, 32      
    98 : call_noret       [i10]()         
    99 : add              i4, i4, 32      
   100 : unspill          i0, 0           
   101 : unspill          i1, 1           
   102 : unspill          i2, 2           
   103 : unspill          i8, 3           
   104 : unspill          i9, 4           
   105 : unspill          i10, 5          
   106 : unspill          i11, 6          
   107 : unspill          v0, 8           
   108 : unspill          v1, 12          
   109 : unspill          v2, 16          
   110 : unspill          v3, 20          
   111 : unspill          v5, 24          
   112 : unspill          v6, 28          
   113 : unspill          v7, 32          
   114 : unspill          v8, 36          
   115 : unspill          v9, 40          
   116 : unspill          v10, 44         
   117 : unspill          v11, 48         
   118 : unspill          v12, 52         
   119 : unspill          v13, 56         
   120 : unspill          v14, 60         
   121 : unspill          v15, 64         
   122 : mov              i1, i9          
   123 : mul              i1, i1, s77     
   124 : add              i1, i1, i0      
   125 : unspill          i13, 79         
   126 : unspill          i14, 75         
   127 : store.u8         i13, i1, i14    
   128 : add              s75, s75, 1     
   129 : add              i0, i0, s72     
   130 : add              i9, i9, s73     
   131 : jmp              6               
   132 : __loops_label_8:                 
   133 : neg              s72, s72        
   134 : neg              s73, s73        
   135 : add              s74, s74, 1     
   136 : jmp              0               
   137 : __loops_label_2:                 
   138 : unspill          i5, 82          
   139 : unspill          i13, 80         
   140 : unspill          i14, 81         
   141 : add              i4, i4, 664     
   142 : ret                              
