all_loads_all_stores(i0, i1, i2, i3, i4)
     0 : sub               i4, i4, 88       
     1 : spill             8, i13           
     2 : spill             9, i14           
     3 : spill             7, i9            
     4 : mov               s1, 0            
     5 : mov               s2, 0            
     6 : mov               s3, 0            
     7 : mov               i0, 2            
     8 : mov               i9, 1            
     9 : cmp               i2, 1            
    10 : select_gt         i9, i0, i9       
    11 : mov               i0, 4            
    12 : cmp               i2, 3            
    13 : select_gt         i9, i0, i9       
    14 : mov               i0, 8            
    15 : cmp               i2, 5            
    16 : mov               i13, i9          
    17 : select_gt         i13, i0, i13     
    18 : spill             4, i13           
    19 : mov               i0, 2            
    20 : mov               i9, 1            
    21 : cmp               s7, 1            
    22 : select_gt         i9, i0, i9       
    23 : mov               i0, 4            
    24 : cmp               s7, 3            
    25 : select_gt         i9, i0, i9       
    26 : mov               i0, 8            
    27 : cmp               s7, 5            
    28 : select_gt         i9, i0, i9       
    29 : spill             5, i9            
    30 : __loops_label_0:                   
    31 : unspill           i13, 16          
    32 : cmp               s1, i13          
    33 : jmp_ge            __loops_label_2  
    34 : def               i13              
    35 : spill             6, i13           
    36 : cmp               i2, 0            
    37 : jmp_ne            __loops_label_4  
    38 : unspill           i13, 2           
    39 : load.u8           i14, i1, i13     
    40 : spill             6, i14           
    41 : jmp               5                
    42 : __loops_label_4:                   
    43 : cmp               i2, 1            
    44 : jmp_ne            __loops_label_7  
    45 : unspill           i13, 2           
    46 : load.i8           i14, i1, i13     
    47 : spill             6, i14           
    48 : jmp               8                
    49 : __loops_label_7:                   
    50 : cmp               i2, 2            
    51 : jmp_ne            __loops_label_10 
    52 : unspill           i13, 2           
    53 : load.u16          i14, i1, i13     
    54 : spill             6, i14           
    55 : jmp               11               
    56 : __loops_label_10:                  
    57 : cmp               i2, 3            
    58 : jmp_ne            __loops_label_13 
    59 : unspill           i13, 2           
    60 : load.i16          i14, i1, i13     
    61 : spill             6, i14           
    62 : jmp               14               
    63 : __loops_label_13:                  
    64 : cmp               i2, 4            
    65 : jmp_ne            __loops_label_16 
    66 : unspill           i13, 2           
    67 : load.u32          i14, i1, i13     
    68 : spill             6, i14           
    69 : jmp               17               
    70 : __loops_label_16:                  
    71 : cmp               i2, 5            
    72 : jmp_ne            __loops_label_19 
    73 : unspill           i13, 2           
    74 : load.i32          i14, i1, i13     
    75 : spill             6, i14           
    76 : jmp               20               
    77 : __loops_label_19:                  
    78 : cmp               i2, 6            
    79 : jmp_ne            __loops_label_22 
    80 : unspill           i13, 2           
    81 : load.u64          i14, i1, i13     
    82 : spill             6, i14           
    83 : jmp               23               
    84 : __loops_label_22:                  
    85 : unspill           i13, 2           
    86 : load.i64          i14, i1, i13     
    87 : spill             6, i14           
    88 : __loops_label_5:                   
    89 : __loops_label_8:                   
    90 : __loops_label_11:                  
    91 : __loops_label_14:                  
    92 : __loops_label_17:                  
    93 : __loops_label_20:                  
    94 : __loops_label_23:                  
    95 : cmp               s7, 0            
    96 : jmp_ne            __loops_label_25 
    97 : unspill           i13, 3           
    98 : unspill           i14, 6           
    99 : store.u8          i8, i13, i14     
   100 : jmp               26               
   101 : __loops_label_25:                  
   102 : cmp               s7, 1            
   103 : jmp_ne            __loops_label_28 
   104 : unspill           i13, 3           
   105 : unspill           i14, 6           
   106 : store.i8          i8, i13, i14     
   107 : jmp               29               
   108 : __loops_label_28:                  
   109 : cmp               s7, 2            
   110 : jmp_ne            __loops_label_31 
   111 : unspill           i13, 3           
   112 : unspill           i14, 6           
   113 : store.u16         i8, i13, i14     
   114 : jmp               32               
   115 : __loops_label_31:                  
   116 : cmp               s7, 3            
   117 : jmp_ne            __loops_label_34 
   118 : unspill           i13, 3           
   119 : unspill           i14, 6           
   120 : store.i16         i8, i13, i14     
   121 : jmp               35               
   122 : __loops_label_34:                  
   123 : cmp               s7, 4            
   124 : jmp_ne            __loops_label_37 
   125 : unspill           i13, 3           
   126 : unspill           i14, 6           
   127 : store.u32         i8, i13, i14     
   128 : jmp               38               
   129 : __loops_label_37:                  
   130 : cmp               s7, 5            
   131 : jmp_ne            __loops_label_40 
   132 : unspill           i13, 3           
   133 : unspill           i14, 6           
   134 : store.i32         i8, i13, i14     
   135 : jmp               41               
   136 : __loops_label_40:                  
   137 : cmp               s7, 6            
   138 : jmp_ne            __loops_label_43 
   139 : unspill           i13, 3           
   140 : unspill           i14, 6           
   141 : store.u64         i8, i13, i14     
   142 : jmp               44               
   143 : __loops_label_43:                  
   144 : unspill           i13, 3           
   145 : unspill           i14, 6           
   146 : store.i64         i8, i13, i14     
   147 : __loops_label_26:                  
   148 : __loops_label_29:                  
   149 : __loops_label_32:                  
   150 : __loops_label_35:                  
   151 : __loops_label_38:                  
   152 : __loops_label_41:                  
   153 : __loops_label_44:                  
   154 : unspill           i13, 4           
   155 : add               s2, s2, i13      
   156 : unspill           i13, 5           
   157 : add               s3, s3, i13      
   158 : add               s1, s1, 1        
   159 : jmp               0                
   160 : __loops_label_2:                   
   161 : unspill           i13, 8           
   162 : unspill           i14, 9           
   163 : add               i4, i4, 88       
   164 : ret                                
