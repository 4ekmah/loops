min_max_scalar(i0, i1, i2, i3)
     0 : sub              i4, i4, 72      
     1 : spill            8, i13          
     2 : mov              s6, 0           
     3 : mov              s1, 0           
     4 : mov              s2, 0           
     5 : load.i32         i13, i1         
     6 : spill            3, i13          
     7 : mov              i13, s3         
     8 : spill            4, i13          
     9 : mul              i2, i2, 4       
    10 : spill            5, i2           
    11 : __loops_label_0:                 
    12 : unspill          i13, 5          
    13 : cmp              s6, i13         
    14 : jmp_ge           __loops_label_2 
    15 : unspill          i13, 6          
    16 : load.i32         i0, i1, i13     
    17 : cmp              i0, s3          
    18 : jmp_ge           __loops_label_4 
    19 : mov              s3, i0          
    20 : mov              i13, s6         
    21 : spill            1, i13          
    22 : __loops_label_4:                 
    23 : cmp              i0, s4          
    24 : jmp_le           __loops_label_6 
    25 : mov              s4, i0          
    26 : mov              i13, s6         
    27 : spill            2, i13          
    28 : __loops_label_6:                 
    29 : add              s6, s6, 4       
    30 : jmp              0               
    31 : __loops_label_2:                 
    32 : mov              s7, 4           
    33 : mov              i1, s1          
    34 : mov              i0, i1          
    35 : x86_cqo                          
    36 : div              i0, i0, s7      
    37 : mov              i1, i0          
    38 : mov              i0, s2          
    39 : x86_cqo                          
    40 : div              i0, i0, s7      
    41 : store.i32        i8, i1          
    42 : store.i32        i9, i0          
    43 : mov              i0, 0           
    44 : unspill          i13, 8          
    45 : add              i4, i4, 72      
    46 : ret                              
