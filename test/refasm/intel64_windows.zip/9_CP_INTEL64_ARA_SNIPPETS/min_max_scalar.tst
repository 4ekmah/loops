min_max_scalar(i0, i1, i2, i3)
     0 : sub              i4, i4, 104     
     1 : spill            11, i13         
     2 : mov              s9, 0           
     3 : mov              s4, 0           
     4 : mov              s5, 0           
     5 : load.i32         i13, i1         
     6 : spill            6, i13          
     7 : mov              i13, s6         
     8 : spill            7, i13          
     9 : mul              i2, i2, 4       
    10 : spill            8, i2           
    11 : __loops_label_0:                 
    12 : unspill          i13, 8          
    13 : cmp              s9, i13         
    14 : jmp_ge           __loops_label_2 
    15 : unspill          i13, 9          
    16 : load.i32         i0, i1, i13     
    17 : cmp              i0, s6          
    18 : jmp_ge           __loops_label_4 
    19 : mov              s6, i0          
    20 : mov              i13, s9         
    21 : spill            4, i13          
    22 : __loops_label_4:                 
    23 : cmp              i0, s7          
    24 : jmp_le           __loops_label_6 
    25 : mov              s7, i0          
    26 : mov              i13, s9         
    27 : spill            5, i13          
    28 : __loops_label_6:                 
    29 : add              s9, s9, 4       
    30 : jmp              0               
    31 : __loops_label_2:                 
    32 : mov              s10, 4          
    33 : mov              i1, s4          
    34 : mov              i0, i1          
    35 : x86_cqo                          
    36 : div              i0, i0, s10     
    37 : mov              i1, i0          
    38 : mov              i0, s5          
    39 : x86_cqo                          
    40 : div              i0, i0, s10     
    41 : store.i32        i8, i1          
    42 : store.i32        i9, i0          
    43 : mov              i0, 0           
    44 : unspill          i13, 11         
    45 : add              i4, i4, 104     
    46 : ret                              
