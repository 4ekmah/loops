nullify_msb_lsb(i0, i1, i2)
     0 : mov       i9, i1     
     1 : shr       i9, i9, 1  
     2 : or        i9, i9, i1 
     3 : mov       i0, i9     
     4 : shr       i0, i0, 2  
     5 : or        i0, i0, i9 
     6 : mov       i9, i0     
     7 : shr       i9, i9, 4  
     8 : or        i9, i9, i0 
     9 : mov       i0, i9     
    10 : shr       i0, i0, 8  
    11 : or        i0, i0, i9 
    12 : mov       i9, i0     
    13 : shr       i9, i9, 16 
    14 : or        i9, i9, i0 
    15 : mov       i0, i9     
    16 : shr       i0, i0, 32 
    17 : or        i0, i0, i9 
    18 : add       i0, i0, 1  
    19 : shr       i0, i0, 1  
    20 : xor       i0, i0, i1 
    21 : store.u64 i8, i0     
    22 : mov       i8, i1     
    23 : sub       i8, i8, 1  
    24 : not       i8, i8     
    25 : and       i8, i8, i1 
    26 : xor       i1, i1, i8 
    27 : store.u64 i2, i1     
    28 : ret                  
