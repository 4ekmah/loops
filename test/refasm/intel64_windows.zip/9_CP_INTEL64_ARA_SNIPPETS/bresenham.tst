bresenham(i0, i1, i2, i3, i4, i5, i6)
     0 : sub               i4, i4, 120      
     1 : spill             13, i13          
     2 : spill             14, i14          
     3 : spill             12, i9           
     4 : unspill           i13, 20          
     5 : mov               i0, i13          
     6 : sub               i0, i0, i8       
     7 : mov               i9, i0           
     8 : neg               i9, i9           
     9 : mov               i13, i9          
    10 : select_s          i13, i0, i13     
    11 : spill             4, i13           
    12 : unspill           i13, 20          
    13 : mov               i0, i13          
    14 : sub               i0, i0, i8       
    15 : mov               i9, i0           
    16 : sar               i0, i0, 63       
    17 : neg               i9, i9           
    18 : mov               s5, i0           
    19 : x86_adc           s5, s5, i0       
    20 : unspill           i13, 21          
    21 : mov               i0, i13          
    22 : sub               i0, i0, s12      
    23 : mov               i9, i0           
    24 : neg               i9, i9           
    25 : select_s          i9, i0, i9       
    26 : mov               s6, i9           
    27 : neg               s6, s6           
    28 : unspill           i13, 21          
    29 : mov               i0, i13          
    30 : sub               i0, i0, s12      
    31 : mov               i9, i0           
    32 : sar               i0, i0, 63       
    33 : neg               i9, i9           
    34 : mov               i9, i0           
    35 : x86_adc           i9, i9, i0       
    36 : mov               i13, s4          
    37 : spill             8, i13           
    38 : unspill           i13, 6           
    39 : add               s8, s8, i13      
    40 : spill             7, i9            
    41 : __loops_label_0:                   
    42 : cmp               i1, 0            
    43 : jmp_eq            __loops_label_2  
    44 : mov               i13, s12         
    45 : spill             9, i13           
    46 : unspill           i13, 9           
    47 : mul               i13, i13, i2     
    48 : spill             9, i13           
    49 : mov               i13, s9          
    50 : spill             10, i13          
    51 : add               s10, s10, i8     
    52 : unspill           i14, 22          
    53 : unspill           i13, 10          
    54 : store.u8          i1, i13, i14     
    55 : cmp               i8, s20          
    56 : jmp_ne            __loops_label_4  
    57 : unspill           i13, 21          
    58 : cmp               s12, i13         
    59 : jmp_ne            __loops_label_4  
    60 : jmp               2                
    61 : __loops_label_4:                   
    62 : mov               i13, s8          
    63 : spill             11, i13          
    64 : shl               s11, s11, 1      
    65 : unspill           i13, 6           
    66 : cmp               s11, i13         
    67 : jmp_gt            __loops_label_6  
    68 : cmp               i8, s20          
    69 : jmp_ne            __loops_label_8  
    70 : jmp               2                
    71 : __loops_label_8:                   
    72 : unspill           i13, 6           
    73 : add               s8, s8, i13      
    74 : add               i8, i8, s5       
    75 : __loops_label_6:                   
    76 : unspill           i13, 4           
    77 : cmp               s11, i13         
    78 : jmp_gt            __loops_label_10 
    79 : unspill           i13, 21          
    80 : cmp               s12, i13         
    81 : jmp_ne            __loops_label_12 
    82 : jmp               2                
    83 : __loops_label_12:                  
    84 : unspill           i13, 4           
    85 : add               s8, s8, i13      
    86 : unspill           i13, 7           
    87 : add               s12, s12, i13    
    88 : __loops_label_10:                  
    89 : jmp               0                
    90 : __loops_label_2:                   
    91 : unspill           i13, 13          
    92 : unspill           i14, 14          
    93 : add               i4, i4, 120      
    94 : ret                                
