bresenham(i0, i1, i2, i3, i4, i5, i6)
     0 : sub               i4, i4, 104      
     1 : spill             10, i13          
     2 : spill             11, i14          
     3 : spill             9, i9            
     4 : unspill           i13, 18          
     5 : mov               i0, i13          
     6 : sub               i0, i0, i8       
     7 : mov               i9, i0           
     8 : neg               i9, i9           
     9 : mov               i13, i9          
    10 : select_s          i13, i0, i13     
    11 : spill             1, i13           
    12 : unspill           i13, 18          
    13 : mov               i0, i13          
    14 : sub               i0, i0, i8       
    15 : mov               i9, i0           
    16 : sar               i0, i0, 63       
    17 : neg               i9, i9           
    18 : mov               s2, i0           
    19 : x86_adc           s2, s2, i0       
    20 : unspill           i13, 19          
    21 : mov               i0, i13          
    22 : sub               i0, i0, s9       
    23 : mov               i9, i0           
    24 : neg               i9, i9           
    25 : select_s          i9, i0, i9       
    26 : mov               s3, i9           
    27 : neg               s3, s3           
    28 : unspill           i13, 19          
    29 : mov               i0, i13          
    30 : sub               i0, i0, s9       
    31 : mov               i9, i0           
    32 : sar               i0, i0, 63       
    33 : neg               i9, i9           
    34 : mov               i9, i0           
    35 : x86_adc           i9, i9, i0       
    36 : mov               i13, s1          
    37 : spill             5, i13           
    38 : unspill           i13, 3           
    39 : add               s5, s5, i13      
    40 : spill             4, i9            
    41 : __loops_label_0:                   
    42 : cmp               i1, 0            
    43 : jmp_eq            __loops_label_2  
    44 : mov               i13, s9          
    45 : spill             6, i13           
    46 : unspill           i13, 6           
    47 : mul               i13, i13, i2     
    48 : spill             6, i13           
    49 : mov               i13, s6          
    50 : spill             7, i13           
    51 : add               s7, s7, i8       
    52 : unspill           i14, 20          
    53 : unspill           i13, 7           
    54 : store.u8          i1, i13, i14     
    55 : cmp               i8, s18          
    56 : jmp_ne            __loops_label_4  
    57 : unspill           i13, 19          
    58 : cmp               s9, i13          
    59 : jmp_ne            __loops_label_4  
    60 : jmp               2                
    61 : __loops_label_4:                   
    62 : mov               i13, s5          
    63 : spill             8, i13           
    64 : shl               s8, s8, 1        
    65 : unspill           i13, 3           
    66 : cmp               s8, i13          
    67 : jmp_gt            __loops_label_6  
    68 : cmp               i8, s18          
    69 : jmp_ne            __loops_label_8  
    70 : jmp               2                
    71 : __loops_label_8:                   
    72 : unspill           i13, 3           
    73 : add               s5, s5, i13      
    74 : add               i8, i8, s2       
    75 : __loops_label_6:                   
    76 : unspill           i13, 1           
    77 : cmp               s8, i13          
    78 : jmp_gt            __loops_label_10 
    79 : unspill           i13, 19          
    80 : cmp               s9, i13          
    81 : jmp_ne            __loops_label_12 
    82 : jmp               2                
    83 : __loops_label_12:                  
    84 : unspill           i13, 1           
    85 : add               s5, s5, i13      
    86 : unspill           i13, 4           
    87 : add               s9, s9, i13      
    88 : __loops_label_10:                  
    89 : jmp               0                
    90 : __loops_label_2:                   
    91 : unspill           i13, 10          
    92 : unspill           i14, 11          
    93 : add               i4, i4, 104      
    94 : ret                                
