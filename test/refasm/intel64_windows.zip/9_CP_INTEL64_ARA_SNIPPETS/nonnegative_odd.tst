nonnegative_odd(i0, i1)
     0 : sub              i4, i4, 40      
     1 : spill            4, i13          
     2 : mov              i9, 0           
     3 : mov              i13, -4         
     4 : spill            2, i13          
     5 : mov              s1, i2          
     6 : unspill          i13, 1          
     7 : mul              i13, i13, 4     
     8 : spill            1, i13          
     9 : __loops_label_0:                 
    10 : cmp              i9, s1          
    11 : jmp_ge           __loops_label_2 
    12 : load.i32         i8, i1, i9      
    13 : cmp              i8, 0           
    14 : jmp_ge           __loops_label_4 
    15 : add              i9, i9, 4       
    16 : jmp              0               
    17 : __loops_label_4:                 
    18 : mov              i0, 2           
    19 : spill            3, i0           
    20 : mov              i0, i8          
    21 : x86_cqo                          
    22 : mod              i2, i0, s3      
    23 : mov              i8, i2          
    24 : cmp              i8, 0           
    25 : jmp_eq           __loops_label_6 
    26 : mov              s2, i9          
    27 : jmp              2               
    28 : __loops_label_6:                 
    29 : add              i9, i9, 4       
    30 : jmp              0               
    31 : __loops_label_2:                 
    32 : mov              i9, 4           
    33 : mov              i1, s2          
    34 : mov              i0, i1          
    35 : x86_cqo                          
    36 : div              i0, i0, i9      
    37 : mov              i1, i0          
    38 : mov              i0, i1          
    39 : unspill          i13, 4          
    40 : add              i4, i4, 40      
    41 : ret                              
