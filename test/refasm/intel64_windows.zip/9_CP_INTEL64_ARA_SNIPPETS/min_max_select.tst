min_max_select(i0, i1, i2, i3)
     0 : sub              i4, i4, 88      
     1 : spill            10, i13         
     2 : mov              s9, 0           
     3 : mov              s4, 0           
     4 : mov              s5, 0           
     5 : load.i32         i13, i1         
     6 : spill            6, i13          
     7 : mov              i13, s6         
     8 : spill            7, i13          
     9 : shl              i2, i2, 2       
    10 : spill            8, i2           
    11 : __loops_label_0:                 
    12 : unspill          i13, 8          
    13 : cmp              s9, i13         
    14 : jmp_ge           __loops_label_2 
    15 : unspill          i13, 9          
    16 : load.i32         i0, i1, i13     
    17 : cmp              i0, s6          
    18 : unspill          i13, 4          
    19 : select_gt        i13, s9, i13    
    20 : spill            4, i13          
    21 : cmp              i0, s6          
    22 : unspill          i13, 6          
    23 : select_gt        i13, i0, i13    
    24 : spill            6, i13          
    25 : cmp              i0, s7          
    26 : unspill          i13, 5          
    27 : select_gt        i13, s9, i13    
    28 : spill            5, i13          
    29 : cmp              i0, s7          
    30 : unspill          i13, 7          
    31 : select_gt        i13, i0, i13    
    32 : spill            7, i13          
    33 : add              s9, s9, 4       
    34 : jmp              0               
    35 : __loops_label_2:                 
    36 : sar              s4, s4, 2       
    37 : sar              s5, s5, 2       
    38 : unspill          i13, 4          
    39 : store.i32        i8, i13         
    40 : unspill          i13, 5          
    41 : store.i32        i9, i13         
    42 : mov              i0, 0           
    43 : unspill          i13, 10         
    44 : add              i4, i4, 88      
    45 : ret                              
