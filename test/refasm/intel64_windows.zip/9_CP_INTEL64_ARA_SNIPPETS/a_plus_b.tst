a_plus_b(i0, i1)
     0 : add i2, i2, i1 
     1 : mov i0, i2     
     2 : ret            
