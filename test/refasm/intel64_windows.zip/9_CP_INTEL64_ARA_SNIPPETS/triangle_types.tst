triangle_types(i0, i1, i2)
     0 : sub               i4, i4, 24       
     1 : spill             1, i2            
     2 : cmp               i1, 0            
     3 : jmp_le            __loops_label_0  
     4 : cmp               s1, 0            
     5 : jmp_le            __loops_label_0  
     6 : cmp               i8, 0            
     7 : jmp_gt            __loops_label_1  
     8 : __loops_label_0:                   
     9 : mov               i0, 0            
    10 : jmp               18               
    11 : __loops_label_1:                   
    12 : mov               i9, s1           
    13 : add               i9, i9, i8       
    14 : cmp               i1, i9           
    15 : jmp_gt            __loops_label_3  
    16 : mov               i9, i1           
    17 : add               i9, i9, i8       
    18 : cmp               s1, i9           
    19 : jmp_gt            __loops_label_3  
    20 : mov               i9, i1           
    21 : add               i9, i9, s1       
    22 : cmp               i8, i9           
    23 : jmp_le            __loops_label_4  
    24 : __loops_label_3:                   
    25 : mov               i0, 0            
    26 : jmp               18               
    27 : __loops_label_4:                   
    28 : cmp               i1, s1           
    29 : jmp_ne            __loops_label_7  
    30 : cmp               i1, i8           
    31 : jmp_ne            __loops_label_7  
    32 : mov               i0, 2            
    33 : jmp               18               
    34 : __loops_label_7:                   
    35 : cmp               i1, s1           
    36 : jmp_eq            __loops_label_9  
    37 : cmp               i1, i8           
    38 : jmp_eq            __loops_label_9  
    39 : cmp               s1, i8           
    40 : jmp_ne            __loops_label_10 
    41 : __loops_label_9:                   
    42 : mov               i0, 3            
    43 : jmp               18               
    44 : __loops_label_10:                  
    45 : mov               i9, i1           
    46 : mul               i9, i9, i1       
    47 : mov               i0, s1           
    48 : mul               i0, i0, s1       
    49 : mov               i2, i8           
    50 : mul               i2, i2, i8       
    51 : add               i2, i2, i0       
    52 : cmp               i9, i2           
    53 : jmp_eq            __loops_label_12 
    54 : mov               i2, s1           
    55 : mul               i2, i2, s1       
    56 : mov               i9, i1           
    57 : mul               i9, i9, i1       
    58 : mov               i0, i8           
    59 : mul               i0, i0, i8       
    60 : add               i0, i0, i9       
    61 : cmp               i2, i0           
    62 : jmp_eq            __loops_label_12 
    63 : mov               i2, i8           
    64 : mul               i2, i2, i8       
    65 : mov               i9, i1           
    66 : mul               i9, i9, i1       
    67 : mov               i0, s1           
    68 : mul               i0, i0, s1       
    69 : add               i0, i0, i9       
    70 : cmp               i2, i0           
    71 : jmp_ne            __loops_label_13 
    72 : __loops_label_12:                  
    73 : mov               i0, 1            
    74 : jmp               18               
    75 : __loops_label_13:                  
    76 : mov               i2, i1           
    77 : mul               i2, i2, i1       
    78 : mov               i9, s1           
    79 : mul               i9, i9, s1       
    80 : mov               i0, i8           
    81 : mul               i0, i0, i8       
    82 : add               i0, i0, i9       
    83 : cmp               i2, i0           
    84 : jmp_gt            __loops_label_15 
    85 : mov               i2, s1           
    86 : mul               i2, i2, s1       
    87 : mov               i9, i1           
    88 : mul               i9, i9, i1       
    89 : mov               i0, i8           
    90 : mul               i0, i0, i8       
    91 : add               i0, i0, i9       
    92 : cmp               i2, i0           
    93 : jmp_gt            __loops_label_15 
    94 : mov               i2, i8           
    95 : mul               i2, i2, i8       
    96 : mov               i8, i1           
    97 : mul               i8, i8, i1       
    98 : mov               i1, s1           
    99 : mul               i1, i1, s1       
   100 : add               i1, i1, i8       
   101 : cmp               i2, i1           
   102 : jmp_le            __loops_label_16 
   103 : __loops_label_15:                  
   104 : mov               i0, 5            
   105 : jmp               18               
   106 : __loops_label_16:                  
   107 : mov               i0, 4            
   108 : jmp               18               
   109 : __loops_label_2:                   
   110 : __loops_label_5:                   
   111 : __loops_label_8:                   
   112 : __loops_label_11:                  
   113 : __loops_label_14:                  
   114 : __loops_label_17:                  
   115 : __loops_label_18:                  
   116 : add               i4, i4, 24       
   117 : ret                                
