fixed_power_v_double_4(i0, i1, i2)
     0 : sub              i4, i4, 40      
     1 : mov              i9, 0           
     2 : mul              i8, i8, 8       
     3 : mov              i0, i8          
     4 : __loops_label_0:                 
     5 : cmp              i9, i0          
     6 : jmp_ge           __loops_label_2 
     7 : vld.fp64         v0, i1, i9      
     8 : mul.fp64         v0, v0, v0      
     9 : mul.fp64         v0, v0, v0      
    10 : vst.fp64         i2, i9, v0      
    11 : add              i9, i9, 32      
    12 : jmp              0               
    13 : __loops_label_2:                 
    14 : mov              i0, 0           
    15 : add              i4, i4, 40      
    16 : ret                              
