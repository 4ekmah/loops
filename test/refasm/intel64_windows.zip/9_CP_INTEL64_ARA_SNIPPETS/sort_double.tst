sort_double(i0, i1)
     0 : sub              i4, i4, 632     
     1 : spill            77, i13         
     2 : spill            78, i5          
     3 : mov              i5, i4          
     4 : add              i5, i5, 624     
     5 : mov              s74, i2         
     6 : shl              s74, s74, 3     
     7 : unspill          i13, 74         
     8 : mov              s75, i13        
     9 : sub              s75, s75, 8     
    10 : mov              s76, 0          
    11 : __loops_label_0:                 
    12 : unspill          i13, 75         
    13 : cmp              s76, i13        
    14 : jmp_ge           __loops_label_2 
    15 : mov              i13, s76        
    16 : spill            73, i13         
    17 : mov              i13, s73        
    18 : spill            72, i13         
    19 : add              s72, s72, 8     
    20 : __loops_label_3:                 
    21 : unspill          i13, 74         
    22 : cmp              s72, i13        
    23 : jmp_ge           __loops_label_5 
    24 : unspill          i13, 72         
    25 : load.fp64        i0, i1, i13     
    26 : unspill          i13, 73         
    27 : load.fp64        i9, i1, i13     
    28 : mov              i8, -887485760  
    29 : spill            0, i0           
    30 : spill            1, i1           
    31 : spill            2, i2           
    32 : spill            3, i8           
    33 : spill            4, i9           
    34 : spill            5, i10          
    35 : spill            6, i11          
    36 : spill            8, v0           
    37 : spill            12, v1          
    38 : spill            16, v2          
    39 : spill            20, v3          
    40 : spill            24, v5          
    41 : spill            28, v6          
    42 : spill            32, v7          
    43 : spill            36, v8          
    44 : spill            40, v9          
    45 : spill            44, v10         
    46 : spill            48, v11         
    47 : spill            52, v12         
    48 : spill            56, v13         
    49 : spill            60, v14         
    50 : spill            64, v15         
    51 : mov              i1, i0          
    52 : mov              i2, i9          
    53 : sub              i4, i4, 32      
    54 : call_noret       [i8]()          
    55 : add              i4, i4, 32      
    56 : mov              i8, i0          
    57 : unspill          i0, 0           
    58 : unspill          i1, 1           
    59 : unspill          i2, 2           
    60 : unspill          i9, 4           
    61 : unspill          i10, 5          
    62 : unspill          i11, 6          
    63 : unspill          v0, 8           
    64 : unspill          v1, 12          
    65 : unspill          v2, 16          
    66 : unspill          v3, 20          
    67 : unspill          v5, 24          
    68 : unspill          v6, 28          
    69 : unspill          v7, 32          
    70 : unspill          v8, 36          
    71 : unspill          v9, 40          
    72 : unspill          v10, 44         
    73 : unspill          v11, 48         
    74 : unspill          v12, 52         
    75 : unspill          v13, 56         
    76 : unspill          v14, 60         
    77 : unspill          v15, 64         
    78 : cmp              i8, 0           
    79 : jmp_eq           __loops_label_7 
    80 : mov              i13, s72        
    81 : spill            73, i13         
    82 : __loops_label_7:                 
    83 : add              s72, s72, 8     
    84 : jmp              3               
    85 : __loops_label_5:                 
    86 : unspill          i13, 76         
    87 : cmp              s73, i13        
    88 : jmp_eq           __loops_label_9 
    89 : unspill          i13, 76         
    90 : load.fp64        i8, i1, i13     
    91 : unspill          i13, 73         
    92 : load.fp64        i9, i1, i13     
    93 : unspill          i13, 73         
    94 : store.fp64       i1, i13, i8     
    95 : unspill          i13, 76         
    96 : store.fp64       i1, i13, i9     
    97 : __loops_label_9:                 
    98 : add              s76, s76, 8     
    99 : jmp              0               
   100 : __loops_label_2:                 
   101 : unspill          i5, 78          
   102 : unspill          i13, 77         
   103 : add              i4, i4, 632     
   104 : ret                              
