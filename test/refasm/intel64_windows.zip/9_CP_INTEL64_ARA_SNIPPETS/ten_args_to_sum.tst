ten_args_to_sum(i0, i1, i2, i3, i4, i5, i6, i7, i8, i9)
     0 : sub     i4, i4, 40 
     1 : unspill i0, 10     
     2 : mul     i1, i1, 1  
     3 : mul     i2, i2, 2  
     4 : add     i2, i2, i1 
     5 : mul     i8, i8, 3  
     6 : add     i8, i8, i2 
     7 : mul     i9, i9, 4  
     8 : add     i9, i9, i8 
     9 : mul     i0, i0, 5  
    10 : add     i0, i0, i9 
    11 : mov     i1, s11    
    12 : mul     i1, i1, 6  
    13 : add     i1, i1, i0 
    14 : mov     i2, s12    
    15 : mul     i2, i2, 7  
    16 : add     i2, i2, i1 
    17 : mov     i1, s13    
    18 : mul     i1, i1, 8  
    19 : add     i1, i1, i2 
    20 : mov     i2, s14    
    21 : mul     i2, i2, 3  
    22 : add     i2, i2, i1 
    23 : mov     i1, s15    
    24 : mul     i1, i1, 2  
    25 : add     i1, i1, i2 
    26 : mov     i0, i1     
    27 : add     i4, i4, 40 
    28 : ret                
