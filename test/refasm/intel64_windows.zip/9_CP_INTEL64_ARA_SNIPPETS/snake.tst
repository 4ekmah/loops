snake(i0, i1, i2)
     0 : sub              i4, i4, 680     
     1 : spill            82, i13         
     2 : spill            83, i14         
     3 : spill            84, i5          
     4 : mov              i5, i4          
     5 : add              i5, i5, 672     
     6 : mov              i9, i2          
     7 : add              i9, i9, i8      
     8 : mov              s76, i9         
     9 : sub              s76, s76, 1     
    10 : mov              i9, 0           
    11 : mov              s75, 1          
    12 : mov              i13, s75        
    13 : spill            72, i13         
    14 : neg              s72, s72        
    15 : mov              s77, 0          
    16 : __loops_label_0:                 
    17 : unspill          i13, 76         
    18 : cmp              s77, i13        
    19 : jmp_ge           __loops_label_2 
    20 : mov              s73, 0          
    21 : mov              s74, 0          
    22 : mov              i0, s77         
    23 : and              i0, i0, 1       
    24 : cmp              i0, 0           
    25 : jmp_eq           __loops_label_4 
    26 : mov              i0, i8          
    27 : sub              i0, i0, 1       
    28 : cmp              i0, s77         
    29 : unspill          i13, 77         
    30 : mov              i14, i13        
    31 : select_gt        i14, i0, i14    
    32 : spill            73, i14         
    33 : unspill          i13, 77         
    34 : mov              s78, i13        
    35 : sub              s78, s78, i0    
    36 : mov              s79, 0          
    37 : cmp              s77, i0         
    38 : unspill          i13, 79         
    39 : mov              i14, i13        
    40 : select_gt        i14, s78, i14   
    41 : spill            74, i14         
    42 : jmp              5               
    43 : __loops_label_4:                 
    44 : mov              s80, i2         
    45 : sub              s80, s80, 1     
    46 : unspill          i13, 77         
    47 : mov              i0, i13         
    48 : sub              i0, i0, s80     
    49 : mov              s81, 0          
    50 : unspill          i13, 80         
    51 : cmp              s77, i13        
    52 : unspill          i13, 81         
    53 : mov              i14, i13        
    54 : select_gt        i14, i0, i14    
    55 : spill            73, i14         
    56 : unspill          i13, 77         
    57 : cmp              s80, i13        
    58 : unspill          i13, 77         
    59 : mov              i14, i13        
    60 : select_gt        i14, s80, i14   
    61 : spill            74, i14         
    62 : __loops_label_5:                 
    63 : __loops_label_6:                 
    64 : cmp              s73, 0          
    65 : jmp_gt           __loops_label_8 
    66 : cmp              s73, i8         
    67 : jmp_ge           __loops_label_8 
    68 : cmp              s74, 0          
    69 : jmp_gt           __loops_label_8 
    70 : cmp              s74, i2         
    71 : jmp_ge           __loops_label_8 
    72 : mov              i0, -887494032  
    73 : unspill          i13, 73         
    74 : unspill          i14, 74         
    75 : spill            0, i0           
    76 : spill            1, i1           
    77 : spill            2, i2           
    78 : spill            3, i8           
    79 : spill            4, i9           
    80 : spill            5, i10          
    81 : spill            6, i11          
    82 : spill            8, v0           
    83 : spill            12, v1          
    84 : spill            16, v2          
    85 : spill            20, v3          
    86 : spill            24, v5          
    87 : spill            28, v6          
    88 : spill            32, v7          
    89 : spill            36, v8          
    90 : spill            40, v9          
    91 : spill            44, v10         
    92 : spill            48, v11         
    93 : spill            52, v12         
    94 : spill            56, v13         
    95 : spill            60, v14         
    96 : spill            64, v15         
    97 : mov              i1, i13         
    98 : mov              i2, i14         
    99 : sub              i4, i4, 32      
   100 : call_noret       [i0]()          
   101 : add              i4, i4, 32      
   102 : unspill          i0, 0           
   103 : unspill          i1, 1           
   104 : unspill          i2, 2           
   105 : unspill          i8, 3           
   106 : unspill          i9, 4           
   107 : unspill          i10, 5          
   108 : unspill          i11, 6          
   109 : unspill          v0, 8           
   110 : unspill          v1, 12          
   111 : unspill          v2, 16          
   112 : unspill          v3, 20          
   113 : unspill          v5, 24          
   114 : unspill          v6, 28          
   115 : unspill          v7, 32          
   116 : unspill          v8, 36          
   117 : unspill          v9, 40          
   118 : unspill          v10, 44         
   119 : unspill          v11, 48         
   120 : unspill          v12, 52         
   121 : unspill          v13, 56         
   122 : unspill          v14, 60         
   123 : unspill          v15, 64         
   124 : mov              i0, s74         
   125 : mul              i0, i0, i8      
   126 : add              i0, i0, s73     
   127 : store.u8         i1, i0, i9      
   128 : add              i9, i9, 1       
   129 : unspill          i13, 75         
   130 : add              s73, s73, i13   
   131 : unspill          i13, 72         
   132 : add              s74, s74, i13   
   133 : jmp              6               
   134 : __loops_label_8:                 
   135 : neg              s75, s75        
   136 : neg              s72, s72        
   137 : add              s77, s77, 1     
   138 : jmp              0               
   139 : __loops_label_2:                 
   140 : unspill          i5, 84          
   141 : unspill          i13, 82         
   142 : unspill          i14, 83         
   143 : add              i4, i4, 680     
   144 : ret                              
