area_sum(i0, i1)
     0 : sub              i4, i4, 616     
     1 : spill            75, i13         
     2 : spill            76, i5          
     3 : mov              i5, i4          
     4 : add              i5, i5, 608     
     5 : mov              s72, 0          
     6 : __loops_label_0:                 
     7 : cmp              i2, 0           
     8 : jmp_le           __loops_label_2 
     9 : load.i8          i13, i1         
    10 : spill            73, i13         
    11 : mov              i0, 1071394160  
    12 : mov              i8, 1071394464  
    13 : mov              i9, 1071394688  
    14 : cmp              s73, 1          
    15 : select_eq        i9, i8, i9      
    16 : cmp              s73, 0          
    17 : mov              i13, i9         
    18 : select_eq        i13, i0, i13    
    19 : spill            74, i13         
    20 : mov              i8, 1071393840  
    21 : mov              i0, 1071393952  
    22 : mov              i9, 1071394016  
    23 : cmp              s73, 1          
    24 : select_eq        i9, i0, i9      
    25 : cmp              s73, 0          
    26 : select_eq        i9, i8, i9      
    27 : unspill          i13, 74         
    28 : spill            0, i0           
    29 : spill            1, i1           
    30 : spill            2, i2           
    31 : spill            3, i8           
    32 : spill            4, i9           
    33 : spill            5, i10          
    34 : spill            6, i11          
    35 : spill            8, v0           
    36 : spill            12, v1          
    37 : spill            16, v2          
    38 : spill            20, v3          
    39 : spill            24, v5          
    40 : spill            28, v6          
    41 : spill            32, v7          
    42 : spill            36, v8          
    43 : spill            40, v9          
    44 : spill            44, v10         
    45 : spill            48, v11         
    46 : spill            52, v12         
    47 : spill            56, v13         
    48 : spill            60, v14         
    49 : spill            64, v15         
    50 : sub              i4, i4, 32      
    51 : call_noret       [i13]()         
    52 : add              i4, i4, 32      
    53 : unspill          i0, 0           
    54 : unspill          i1, 1           
    55 : unspill          i2, 2           
    56 : unspill          i8, 3           
    57 : unspill          i9, 4           
    58 : unspill          i10, 5          
    59 : unspill          i11, 6          
    60 : unspill          v0, 8           
    61 : unspill          v1, 12          
    62 : unspill          v2, 16          
    63 : unspill          v3, 20          
    64 : unspill          v5, 24          
    65 : unspill          v6, 28          
    66 : unspill          v7, 32          
    67 : unspill          v8, 36          
    68 : unspill          v9, 40          
    69 : unspill          v10, 44         
    70 : unspill          v11, 48         
    71 : unspill          v12, 52         
    72 : unspill          v13, 56         
    73 : unspill          v14, 60         
    74 : unspill          v15, 64         
    75 : spill            0, i0           
    76 : spill            1, i1           
    77 : spill            2, i2           
    78 : spill            3, i8           
    79 : spill            4, i9           
    80 : spill            5, i10          
    81 : spill            6, i11          
    82 : spill            8, v0           
    83 : spill            12, v1          
    84 : spill            16, v2          
    85 : spill            20, v3          
    86 : spill            24, v5          
    87 : spill            28, v6          
    88 : spill            32, v7          
    89 : spill            36, v8          
    90 : spill            40, v9          
    91 : spill            44, v10         
    92 : spill            48, v11         
    93 : spill            52, v12         
    94 : spill            56, v13         
    95 : spill            60, v14         
    96 : spill            64, v15         
    97 : sub              i4, i4, 32      
    98 : call_noret       [i9]()          
    99 : add              i4, i4, 32      
   100 : mov              i8, i0          
   101 : unspill          i0, 0           
   102 : unspill          i1, 1           
   103 : unspill          i2, 2           
   104 : unspill          i9, 4           
   105 : unspill          i10, 5          
   106 : unspill          i11, 6          
   107 : unspill          v0, 8           
   108 : unspill          v1, 12          
   109 : unspill          v2, 16          
   110 : unspill          v3, 20          
   111 : unspill          v5, 24          
   112 : unspill          v6, 28          
   113 : unspill          v7, 32          
   114 : unspill          v8, 36          
   115 : unspill          v9, 40          
   116 : unspill          v10, 44         
   117 : unspill          v11, 48         
   118 : unspill          v12, 52         
   119 : unspill          v13, 56         
   120 : unspill          v14, 60         
   121 : unspill          v15, 64         
   122 : mov              i9, 1071393760  
   123 : unspill          i13, 72         
   124 : spill            0, i0           
   125 : spill            1, i1           
   126 : spill            2, i2           
   127 : spill            3, i8           
   128 : spill            4, i9           
   129 : spill            5, i10          
   130 : spill            6, i11          
   131 : spill            8, v0           
   132 : spill            12, v1          
   133 : spill            16, v2          
   134 : spill            20, v3          
   135 : spill            24, v5          
   136 : spill            28, v6          
   137 : spill            32, v7          
   138 : spill            36, v8          
   139 : spill            40, v9          
   140 : spill            44, v10         
   141 : spill            48, v11         
   142 : spill            52, v12         
   143 : spill            56, v13         
   144 : spill            60, v14         
   145 : spill            64, v15         
   146 : mov              i1, i13         
   147 : mov              i2, i8          
   148 : sub              i4, i4, 32      
   149 : call_noret       [i9]()          
   150 : add              i4, i4, 32      
   151 : mov              i8, i0          
   152 : unspill          i0, 0           
   153 : unspill          i1, 1           
   154 : unspill          i2, 2           
   155 : unspill          i9, 4           
   156 : unspill          i10, 5          
   157 : unspill          i11, 6          
   158 : unspill          v0, 8           
   159 : unspill          v1, 12          
   160 : unspill          v2, 16          
   161 : unspill          v3, 20          
   162 : unspill          v5, 24          
   163 : unspill          v6, 28          
   164 : unspill          v7, 32          
   165 : unspill          v8, 36          
   166 : unspill          v9, 40          
   167 : unspill          v10, 44         
   168 : unspill          v11, 48         
   169 : unspill          v12, 52         
   170 : unspill          v13, 56         
   171 : unspill          v14, 60         
   172 : unspill          v15, 64         
   173 : mov              s72, i8         
   174 : add              i1, i1, 56      
   175 : sub              i2, i2, 1       
   176 : jmp              0               
   177 : __loops_label_2:                 
   178 : mov              i0, s72         
   179 : unspill          i5, 76          
   180 : unspill          i13, 75         
   181 : add              i4, i4, 616     
   182 : ret                              
