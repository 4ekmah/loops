area_sum(i0, i1)
     0 : sub              i4, i4, 616     
     1 : spill            75, i13         
     2 : spill            76, i5          
     3 : mov              i5, i4          
     4 : add              i5, i5, 608     
     5 : mov              s72, 0          
     6 : __loops_label_0:                 
     7 : cmp              i2, 0           
     8 : jmp_le           __loops_label_2 
     9 : load.i8          i13, i1         
    10 : spill            73, i13         
    11 : mov              i0, -887480080  
    12 : mov              i8, -887479776  
    13 : mov              i9, -887479552  
    14 : cmp              s73, 1          
    15 : select_eq        i9, i8, i9      
    16 : cmp              s73, 0          
    17 : mov              i13, i9         
    18 : select_eq        i13, i0, i13    
    19 : spill            74, i13         
    20 : mov              i8, -887480400  
    21 : mov              i0, -887480288  
    22 : mov              i9, -887480224  
    23 : cmp              s73, 1          
    24 : select_eq        i9, i0, i9      
    25 : cmp              s73, 0          
    26 : select_eq        i9, i8, i9      
    27 : unspill          i13, 74         
    28 : spill            0, i0           
    29 : spill            1, i1           
    30 : spill            2, i2           
    31 : spill            3, i8           
    32 : spill            4, i9           
    33 : spill            5, i10          
    34 : spill            6, i11          
    35 : spill            8, v0           
    36 : spill            12, v1          
    37 : spill            16, v2          
    38 : spill            20, v3          
    39 : spill            24, v5          
    40 : spill            28, v6          
    41 : spill            32, v7          
    42 : spill            36, v8          
    43 : spill            40, v9          
    44 : spill            44, v10         
    45 : spill            48, v11         
    46 : spill            52, v12         
    47 : spill            56, v13         
    48 : spill            60, v14         
    49 : spill            64, v15         
    50 : sub              i4, i4, 32      
    51 : call_noret       [i13]()         
    52 : add              i4, i4, 32      
    53 : unspill          i0, 0           
    54 : unspill          i1, 1           
    55 : unspill          i2, 2           
    56 : unspill          i8, 3           
    57 : unspill          i9, 4           
    58 : unspill          i10, 5          
    59 : unspill          i11, 6          
    60 : unspill          v0, 8           
    61 : unspill          v1, 12          
    62 : unspill          v2, 16          
    63 : unspill          v3, 20          
    64 : unspill          v5, 24          
    65 : unspill          v6, 28          
    66 : unspill          v7, 32          
    67 : unspill          v8, 36          
    68 : unspill          v9, 40          
    69 : unspill          v10, 44         
    70 : unspill          v11, 48         
    71 : unspill          v12, 52         
    72 : unspill          v13, 56         
    73 : unspill          v14, 60         
    74 : unspill          v15, 64         
    75 : spill            74, i13         
    76 : spill            0, i0           
    77 : spill            1, i1           
    78 : spill            2, i2           
    79 : spill            3, i8           
    80 : spill            4, i9           
    81 : spill            5, i10          
    82 : spill            6, i11          
    83 : spill            8, v0           
    84 : spill            12, v1          
    85 : spill            16, v2          
    86 : spill            20, v3          
    87 : spill            24, v5          
    88 : spill            28, v6          
    89 : spill            32, v7          
    90 : spill            36, v8          
    91 : spill            40, v9          
    92 : spill            44, v10         
    93 : spill            48, v11         
    94 : spill            52, v12         
    95 : spill            56, v13         
    96 : spill            60, v14         
    97 : spill            64, v15         
    98 : sub              i4, i4, 32      
    99 : call_noret       [i9]()          
   100 : add              i4, i4, 32      
   101 : mov              i8, i0          
   102 : unspill          i0, 0           
   103 : unspill          i1, 1           
   104 : unspill          i2, 2           
   105 : unspill          i9, 4           
   106 : unspill          i10, 5          
   107 : unspill          i11, 6          
   108 : unspill          v0, 8           
   109 : unspill          v1, 12          
   110 : unspill          v2, 16          
   111 : unspill          v3, 20          
   112 : unspill          v5, 24          
   113 : unspill          v6, 28          
   114 : unspill          v7, 32          
   115 : unspill          v8, 36          
   116 : unspill          v9, 40          
   117 : unspill          v10, 44         
   118 : unspill          v11, 48         
   119 : unspill          v12, 52         
   120 : unspill          v13, 56         
   121 : unspill          v14, 60         
   122 : unspill          v15, 64         
   123 : mov              i9, -887480480  
   124 : unspill          i13, 72         
   125 : spill            0, i0           
   126 : spill            1, i1           
   127 : spill            2, i2           
   128 : spill            3, i8           
   129 : spill            4, i9           
   130 : spill            5, i10          
   131 : spill            6, i11          
   132 : spill            8, v0           
   133 : spill            12, v1          
   134 : spill            16, v2          
   135 : spill            20, v3          
   136 : spill            24, v5          
   137 : spill            28, v6          
   138 : spill            32, v7          
   139 : spill            36, v8          
   140 : spill            40, v9          
   141 : spill            44, v10         
   142 : spill            48, v11         
   143 : spill            52, v12         
   144 : spill            56, v13         
   145 : spill            60, v14         
   146 : spill            64, v15         
   147 : mov              i1, i13         
   148 : mov              i2, i8          
   149 : sub              i4, i4, 32      
   150 : call_noret       [i9]()          
   151 : add              i4, i4, 32      
   152 : mov              i8, i0          
   153 : unspill          i0, 0           
   154 : unspill          i1, 1           
   155 : unspill          i2, 2           
   156 : unspill          i9, 4           
   157 : unspill          i10, 5          
   158 : unspill          i11, 6          
   159 : unspill          v0, 8           
   160 : unspill          v1, 12          
   161 : unspill          v2, 16          
   162 : unspill          v3, 20          
   163 : unspill          v5, 24          
   164 : unspill          v6, 28          
   165 : unspill          v7, 32          
   166 : unspill          v8, 36          
   167 : unspill          v9, 40          
   168 : unspill          v10, 44         
   169 : unspill          v11, 48         
   170 : unspill          v12, 52         
   171 : unspill          v13, 56         
   172 : unspill          v14, 60         
   173 : unspill          v15, 64         
   174 : mov              s72, i8         
   175 : add              i1, i1, 56      
   176 : sub              i2, i2, 1       
   177 : jmp              0               
   178 : __loops_label_2:                 
   179 : mov              i0, s72         
   180 : unspill          i5, 76          
   181 : unspill          i13, 75         
   182 : add              i4, i4, 616     
   183 : ret                              
