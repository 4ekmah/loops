fixed_power_v_double_0(i0, i1, i2)
     0 : sub              i4, i4, 24      
     1 : mov              i9, 0           
     2 : mul              i8, i8, 8       
     3 : spill            1, i8           
     4 : __loops_label_0:                 
     5 : cmp              i9, s1          
     6 : jmp_ge           __loops_label_2 
     7 : vld.fp64         v0, i1, i9      
     8 : mov              i0, 0           
     9 : vdef.fp64        v0              
    10 : setlane.fp64     v0, 0, i0       
    11 : broadcast.fp64   v0, v0, 0       
    12 : vst.fp64         i2, i9, v0      
    13 : add              i9, i9, 32      
    14 : jmp              0               
    15 : __loops_label_2:                 
    16 : mov              i0, 0           
    17 : add              i4, i4, 24      
    18 : ret                              
