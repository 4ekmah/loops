fixed_power_v_uint32_t_9(i0, i1, i2)
     0 : sub              i4, i4, 8       
     1 : mov              i9, 0           
     2 : mul              i8, i8, 4       
     3 : mov              i0, i8          
     4 : __loops_label_0:                 
     5 : cmp              i9, i0          
     6 : jmp_ge           __loops_label_2 
     7 : vld.u32          v0, i1, i9      
     8 : mul.u32          v1, v0, v0      
     9 : mul.u32          v1, v1, v1      
    10 : mul.u32          v1, v1, v1      
    11 : mul.u32          v0, v0, v1      
    12 : vst.u32          i2, i9, v0      
    13 : add              i9, i9, 32      
    14 : jmp              0               
    15 : __loops_label_2:                 
    16 : mov              i0, 0           
    17 : add              i4, i4, 8       
    18 : ret                              
