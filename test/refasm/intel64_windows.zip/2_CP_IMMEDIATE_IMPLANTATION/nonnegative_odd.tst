nonnegative_odd(i0, i1)
     0 : mov                    i2, 0           
     1 : mov                    i3, -4          
     2 : mul                    i1, i1, 4       
     3 : annotation:whilecstart 0               
     4 : cmp                    i2, i1          
     5 : jmp_ge                 __loops_label_2 
     6 : annotation:whilecend                   
     7 : load.i32               i4, i0, i2      
     8 : annotation:ifcstart                    
     9 : cmp                    i4, 0           
    10 : jmp_ge                 __loops_label_4 
    11 : annotation:ifcend                      
    12 : add                    i2, i2, 4       
    13 : annotation:break       0               
    14 : annotation:endif       4               
    15 : mov                    i6, 2           
    16 : mod                    i5, i4, i6      
    17 : annotation:ifcstart                    
    18 : cmp                    i5, 0           
    19 : jmp_eq                 __loops_label_6 
    20 : annotation:ifcend                      
    21 : mov                    i3, i2          
    22 : annotation:break       2               
    23 : annotation:endif       6               
    24 : add                    i2, i2, 4       
    25 : annotation:endwhile    0, 2            
    26 : mov                    i7, 4           
    27 : div                    i3, i3, i7      
    28 : mov                    iR, i3          
    29 : ret                                    
