area_sum(i0, i1)
     0 : mov                    i2, 0               
     1 : annotation:whilecstart 0                   
     2 : cmp                    i1, 0               
     3 : jmp_le                 __loops_label_2     
     4 : annotation:whilecend                       
     5 : load.i8                i3, i0              
     6 : mov                    i4, -1637068304     
     7 : mov                    i5, -1637068000     
     8 : mov                    i6, -1637067776     
     9 : cmp                    i3, 1               
    10 : select_eq              i7, i5, i6          
    11 : cmp                    i3, 0               
    12 : select_eq              i8, i4, i7          
    13 : mov                    i9, -1637068624     
    14 : mov                    i10, -1637068512    
    15 : mov                    i11, -1637068448    
    16 : cmp                    i3, 1               
    17 : select_eq              i12, i10, i11       
    18 : cmp                    i3, 0               
    19 : select_eq              i13, i9, i12        
    20 : call_noret             [i8](i0)            
    21 : call                   [i13](i14, i0)      
    22 : mov                    i16, -1637068704    
    23 : call                   [i16](i15, i2, i14) 
    24 : mov                    i2, i15             
    25 : add                    i0, i0, 56          
    26 : sub                    i1, i1, 1           
    27 : annotation:endwhile    0, 2                
    28 : mov                    iR, i2              
    29 : ret                                        
