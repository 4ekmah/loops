helloworld_call()
     0 : mov        i0, 778246128 
     1 : call_noret [i0]()        
     2 : ret                      
