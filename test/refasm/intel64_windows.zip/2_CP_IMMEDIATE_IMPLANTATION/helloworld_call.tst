helloworld_call()
     0 : mov        i0, -887496080 
     1 : call_noret [i0]()         
     2 : ret                       
