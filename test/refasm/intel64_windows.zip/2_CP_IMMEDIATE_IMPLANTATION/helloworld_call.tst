helloworld_call()
     0 : mov        i0, 1071378160 
     1 : call_noret [i0]()         
     2 : ret                       
