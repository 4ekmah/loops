area_sum(i0, i1)
     0 : sub                    i4, i4, 616       
     1 : spill                  75, i13           
     2 : spill                  76, i5            
     3 : mov                    i5, i4            
     4 : add                    i5, i5, 608       
     5 : spill                  74, i1            
     6 : spill                  73, i2            
     7 : mov                    s72, 0            
     8 : annotation:whilecstart 0                 
     9 : cmp                    s73, 0            
    10 : jmp_le                 __loops_label_2   
    11 : annotation:whilecend                     
    12 : unspill                i13, 74           
    13 : load.i8                i9, i13           
    14 : mov                    i0, 2100734672    
    15 : mov                    i8, 2100734976    
    16 : mov                    i2, 2100735200    
    17 : cmp                    i9, 1             
    18 : select_eq              i2, i8, i2        
    19 : cmp                    i9, 0             
    20 : select_eq              i2, i0, i2        
    21 : mov                    i8, 2100734352    
    22 : mov                    i0, 2100734464    
    23 : mov                    i1, 2100734528    
    24 : cmp                    i9, 1             
    25 : select_eq              i1, i0, i1        
    26 : cmp                    i9, 0             
    27 : select_eq              i1, i8, i1        
    28 : unspill                i13, 74           
    29 : call_noret             [i2](i13)         
    30 : unspill                i13, 74           
    31 : call                   [i1](i1, i13)     
    32 : mov                    i2, 2100734272    
    33 : unspill                i13, 72           
    34 : call                   [i2](i1, i13, i1) 
    35 : mov                    s72, i1           
    36 : add                    s74, s74, 56      
    37 : sub                    s73, s73, 1       
    38 : annotation:endwhile    0, 2              
    39 : mov                    i0, s72           
    40 : ret                                      
    41 : unspill                i5, 76            
    42 : unspill                i13, 75           
    43 : add                    i4, i4, 616       
