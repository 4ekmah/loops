conditionpainter(i0)
     0 : sub                    i4, i4, 56      
     1 : spill                  5, i13          
     2 : spill                  1, i1           
     3 : mov                    i13, -5         
     4 : spill                  0, i13          
     5 : annotation:whilecstart 0               
     6 : cmp                    s0, 5           
     7 : jmp_gt                 __loops_label_2 
     8 : annotation:whilecend                   
     9 : unspill                i13, 0          
    10 : add                    i8, i13, 5      
    11 : mul                    i8, i8, 11      
    12 : mul                    i13, i8, 8      
    13 : spill                  3, i13          
    14 : mov                    i13, -5         
    15 : spill                  2, i13          
    16 : annotation:whilecstart 3               
    17 : cmp                    s2, 5           
    18 : jmp_gt                 __loops_label_5 
    19 : annotation:whilecend                   
    20 : unspill                i13, 2          
    21 : add                    i0, i13, 3      
    22 : mov                    i2, 0           
    23 : cmp                    s0, i0          
    24 : iverson_ge             i2              
    25 : mov                    i0, 0           
    26 : cmp                    s0, 4           
    27 : iverson_le             i0              
    28 : and                    i2, i2, i0      
    29 : mov                    i0, 0           
    30 : cmp                    s2, -2          
    31 : iverson_ge             i0              
    32 : and                    i2, i2, i0      
    33 : mov                    i0, 0           
    34 : cmp                    s2, 0           
    35 : iverson_le             i0              
    36 : and                    i2, i2, i0      
    37 : unspill                i13, 2          
    38 : sub                    i0, i13, 1      
    39 : mov                    i1, 0           
    40 : cmp                    s0, i0          
    41 : iverson_le             i1              
    42 : mov                    i0, 0           
    43 : cmp                    s2, 0           
    44 : iverson_ge             i0              
    45 : and                    i1, i1, i0      
    46 : mov                    i0, 0           
    47 : cmp                    s0, 0           
    48 : iverson_le             i0              
    49 : and                    i1, i1, i0      
    50 : unspill                i13, 2          
    51 : mul                    i0, i13, s2     
    52 : unspill                i13, 0          
    53 : mul                    i9, i13, s0     
    54 : add                    i0, i0, i9      
    55 : mov                    i9, 0           
    56 : cmp                    i0, 9           
    57 : iverson_le             i9              
    58 : and                    i1, i1, i9      
    59 : or                     s4, i2, i1      
    60 : mov                    i1, 2           
    61 : mov                    i9, 0           
    62 : mov                    i0, 0           
    63 : cmp                    s2, 2           
    64 : iverson_ge             i0              
    65 : mov                    i8, 0           
    66 : cmp                    s2, 4           
    67 : iverson_le             i8              
    68 : and                    i0, i0, i8      
    69 : mov                    i8, 0           
    70 : cmp                    s0, 1           
    71 : iverson_ge             i8              
    72 : mov                    i2, 0           
    73 : cmp                    s0, 3           
    74 : iverson_le             i2              
    75 : and                    i8, i8, i2      
    76 : or                     i0, i0, i8      
    77 : unspill                i13, 2          
    78 : mul                    i2, i13, s2     
    79 : unspill                i13, 0          
    80 : mul                    i8, i13, s0     
    81 : add                    i2, i2, i8      
    82 : mov                    i8, 0           
    83 : cmp                    i2, 16          
    84 : iverson_le             i8              
    85 : and                    i0, i0, i8      
    86 : cmp                    i0, 0           
    87 : select_ne              i9, i1, i9      
    88 : unspill                i13, 4          
    89 : add                    i9, i13, i9     
    90 : annotation:ifcstart                    
    91 : unspill                i13, 0          
    92 : mul                    i1, i13, 2      
    93 : cmp                    i1, s2          
    94 : jmp_gt                 __loops_label_8 
    95 : unspill                i13, 2          
    96 : add                    i1, i13, 3      
    97 : neg                    i1, i1          
    98 : unspill                i13, 2          
    99 : add                    i2, i13, 3      
   100 : mul                    i1, i1, i2      
   101 : cmp                    s0, i1          
   102 : jmp_le                 __loops_label_9 
   103 : __loops_label_8:                       
   104 : unspill                i13, 2          
   105 : mul                    i1, i13, 2      
   106 : cmp                    s0, i1          
   107 : jmp_gt                 __loops_label_7 
   108 : unspill                i13, 2          
   109 : add                    i1, i13, 3      
   110 : neg                    i1, i1          
   111 : unspill                i13, 2          
   112 : add                    i2, i13, 3      
   113 : mul                    i1, i1, i2      
   114 : cmp                    s0, i1          
   115 : jmp_gt                 __loops_label_7 
   116 : __loops_label_9:                       
   117 : cmp                    s2, 0           
   118 : jmp_gt                 __loops_label_7 
   119 : annotation:ifcend                      
   120 : add                    i9, i9, 3       
   121 : annotation:endif       7               
   122 : unspill                i13, 2          
   123 : add                    i1, i13, 5      
   124 : shl                    i1, i1, 3       
   125 : unspill                i13, 3          
   126 : add                    i1, i13, i1     
   127 : unspill                i13, 1          
   128 : store.i64              i13, i1, i9     
   129 : add                    s2, s2, 1       
   130 : annotation:endwhile    3, 5            
   131 : add                    s0, s0, 1       
   132 : annotation:endwhile    0, 2            
   133 : ret                                    
   134 : unspill                i13, 5          
   135 : add                    i4, i4, 56      
