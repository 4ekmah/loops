snake(i0, i1, i2)
     0 : sub                    i4, i4, 664     
     1 : spill                  80, i13         
     2 : spill                  81, i14         
     3 : spill                  82, i5          
     4 : mov                    i5, i4          
     5 : add                    i5, i5, 656     
     6 : spill                  79, i1          
     7 : spill                  78, i2          
     8 : spill                  77, i8          
     9 : unspill                i13, 78         
    10 : add                    i9, i13, s77    
    11 : sub                    s76, i9, 1      
    12 : mov                    s75, 0          
    13 : mov                    s72, 1          
    14 : neg                    i13, s72        
    15 : spill                  73, i13         
    16 : mov                    s74, 0          
    17 : annotation:whilecstart 0               
    18 : unspill                i13, 76         
    19 : cmp                    s74, i13        
    20 : jmp_ge                 __loops_label_2 
    21 : annotation:whilecend                   
    22 : mov                    i0, 0           
    23 : mov                    i9, 0           
    24 : annotation:ifcstart                    
    25 : unspill                i13, 74         
    26 : and                    i8, i13, 1      
    27 : cmp                    i8, 0           
    28 : jmp_eq                 __loops_label_4 
    29 : annotation:ifcend                      
    30 : unspill                i13, 77         
    31 : sub                    i8, i13, 1      
    32 : unspill                i13, 74         
    33 : min                    i0, i8, i13     
    34 : unspill                i13, 74         
    35 : sub                    i2, i13, i8     
    36 : mov                    i1, 0           
    37 : cmp                    s74, i8         
    38 : select_gt              i9, i2, i1      
    39 : annotation:else        4, 5            
    40 : unspill                i13, 78         
    41 : sub                    i1, i13, 1      
    42 : unspill                i13, 74         
    43 : sub                    i2, i13, i1     
    44 : mov                    i8, 0           
    45 : cmp                    s74, i1         
    46 : select_gt              i0, i2, i8      
    47 : unspill                i13, 74         
    48 : min                    i9, i1, i13     
    49 : annotation:endif       5               
    50 : annotation:whilecstart 6               
    51 : cmp                    i0, 0           
    52 : jmp_gt                 __loops_label_8 
    53 : cmp                    i0, s77         
    54 : jmp_ge                 __loops_label_8 
    55 : cmp                    i9, 0           
    56 : jmp_gt                 __loops_label_8 
    57 : cmp                    i9, s78         
    58 : jmp_ge                 __loops_label_8 
    59 : annotation:whilecend                   
    60 : mov                    i1, 2100720720  
    61 : call_noret             [i1](i0, i9)    
    62 : mul                    i1, i9, s77     
    63 : add                    i1, i1, i0      
    64 : unspill                i13, 79         
    65 : unspill                i14, 75         
    66 : store.u8               i13, i1, i14    
    67 : add                    s75, s75, 1     
    68 : add                    i0, i0, s72     
    69 : add                    i9, i9, s73     
    70 : annotation:endwhile    6, 8            
    71 : neg                    s72, s72        
    72 : neg                    s73, s73        
    73 : add                    s74, s74, 1     
    74 : annotation:endwhile    0, 2            
    75 : ret                                    
    76 : unspill                i5, 82          
    77 : unspill                i13, 80         
    78 : unspill                i14, 81         
    79 : add                    i4, i4, 664     
