bresenham(i0, i1, i2, i3, i4, i5, i6)
     0 : sub                    i4, i4, 88       
     1 : spill                  9, i13           
     2 : spill                  10, i14          
     3 : unspill                i13, 16          
     4 : sub                    i0, i13, i8      
     5 : abs                    i13, i0          
     6 : spill                  4, i13           
     7 : unspill                i13, 16          
     8 : sub                    i0, i13, i8      
     9 : sign                   i13, i0          
    10 : spill                  5, i13           
    11 : unspill                i13, 17          
    12 : sub                    i0, i13, i9      
    13 : abs                    i0, i0           
    14 : neg                    s6, i0           
    15 : unspill                i13, 17          
    16 : sub                    i0, i13, i9      
    17 : sign                   i13, i0          
    18 : spill                  8, i13           
    19 : unspill                i13, 4           
    20 : unspill                i14, 6           
    21 : add                    s7, i13, i14     
    22 : annotation:whilecstart 0                
    23 : cmp                    i1, 0            
    24 : jmp_eq                 __loops_label_2  
    25 : annotation:whilecend                    
    26 : mul                    i0, i9, i2       
    27 : add                    i0, i0, i8       
    28 : unspill                i13, 18          
    29 : store.u8               i1, i0, i13      
    30 : annotation:ifcstart                     
    31 : cmp                    i8, s16          
    32 : jmp_ne                 __loops_label_4  
    33 : cmp                    i9, s17          
    34 : jmp_ne                 __loops_label_4  
    35 : annotation:ifcend                       
    36 : annotation:break       2                
    37 : annotation:endif       4                
    38 : unspill                i13, 7           
    39 : shl                    i0, i13, 1       
    40 : annotation:ifcstart                     
    41 : cmp                    i0, s6           
    42 : jmp_gt                 __loops_label_6  
    43 : annotation:ifcend                       
    44 : annotation:ifcstart                     
    45 : cmp                    i8, s16          
    46 : jmp_ne                 __loops_label_8  
    47 : annotation:ifcend                       
    48 : annotation:break       2                
    49 : annotation:endif       8                
    50 : unspill                i13, 6           
    51 : add                    s7, s7, i13      
    52 : add                    i8, i8, s5       
    53 : annotation:endif       6                
    54 : annotation:ifcstart                     
    55 : cmp                    i0, s4           
    56 : jmp_gt                 __loops_label_10 
    57 : annotation:ifcend                       
    58 : annotation:ifcstart                     
    59 : cmp                    i9, s17          
    60 : jmp_ne                 __loops_label_12 
    61 : annotation:ifcend                       
    62 : annotation:break       2                
    63 : annotation:endif       12               
    64 : unspill                i13, 4           
    65 : add                    s7, s7, i13      
    66 : add                    i9, i9, s8       
    67 : annotation:endif       10               
    68 : annotation:endwhile    0, 2             
    69 : ret                                     
    70 : unspill                i13, 9           
    71 : unspill                i14, 10          
    72 : add                    i4, i4, 88       
