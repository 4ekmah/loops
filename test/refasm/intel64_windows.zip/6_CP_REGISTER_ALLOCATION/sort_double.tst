sort_double(i0, i1)
     0 : sub                    i4, i4, 632      
     1 : spill                  75, i1           
     2 : spill                  76, i13          
     3 : spill                  77, i14          
     4 : spill                  78, i5           
     5 : mov                    i5, i4           
     6 : add                    i5, i5, 624      
     7 : shl                    s74, i2, 3       
     8 : unspill                i13, 74          
     9 : sub                    s73, i13, 8      
    10 : mov                    s72, 0           
    11 : annotation:whilecstart 0                
    12 : unspill                i13, 73          
    13 : cmp                    s72, i13         
    14 : jmp_ge                 __loops_label_2  
    15 : annotation:whilecend                    
    16 : mov                    i0, s72          
    17 : add                    i9, i0, 8        
    18 : annotation:whilecstart 3                
    19 : cmp                    i9, s74          
    20 : jmp_ge                 __loops_label_5  
    21 : annotation:whilecend                    
    22 : annotation:ifcstart                     
    23 : unspill                i13, 75          
    24 : load.fp64              i8, i13, i9      
    25 : unspill                i13, 75          
    26 : load.fp64              i2, i13, i0      
    27 : mov                    i1, 778256448    
    28 : call                   [i1](i1, i8, i2) 
    29 : cmp                    i1, 0            
    30 : jmp_eq                 __loops_label_7  
    31 : annotation:ifcend                       
    32 : mov                    i0, i9           
    33 : annotation:endif       7                
    34 : add                    i9, i9, 8        
    35 : annotation:endwhile    3, 5             
    36 : annotation:ifcstart                     
    37 : cmp                    i0, s72          
    38 : jmp_eq                 __loops_label_9  
    39 : annotation:ifcend                       
    40 : unspill                i13, 75          
    41 : unspill                i14, 72          
    42 : load.fp64              i1, i13, i14     
    43 : unspill                i13, 75          
    44 : load.fp64              i2, i13, i0      
    45 : unspill                i13, 75          
    46 : store.fp64             i13, i0, i1      
    47 : unspill                i13, 75          
    48 : unspill                i14, 72          
    49 : store.fp64             i13, i14, i2     
    50 : annotation:endif       9                
    51 : add                    s72, s72, 8      
    52 : annotation:endwhile    0, 2             
    53 : ret                                     
    54 : unspill                i5, 78           
    55 : unspill                i13, 76          
    56 : unspill                i14, 77          
    57 : add                    i4, i4, 632      
