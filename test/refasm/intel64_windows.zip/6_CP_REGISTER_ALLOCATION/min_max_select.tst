min_max_select(i0, i1, i2, i3)
     0 : sub                    i4, i4, 56      
     1 : spill                  1, i8           
     2 : spill                  0, i9           
     3 : spill                  5, i13          
     4 : mov                    i0, 0           
     5 : mov                    s3, 0           
     6 : mov                    s2, 0           
     7 : load.i32               i8, i1          
     8 : mov                    i9, i8          
     9 : shl                    s4, i2, 2       
    10 : annotation:whilecstart 0               
    11 : cmp                    i0, s4          
    12 : jmp_ge                 __loops_label_2 
    13 : annotation:whilecend                   
    14 : load.i32               i2, i1, i0      
    15 : cmp                    i2, i8          
    16 : unspill                i13, 3          
    17 : select_gt              i13, i0, i13    
    18 : spill                  3, i13          
    19 : min                    i8, i2, i8      
    20 : cmp                    i2, i9          
    21 : unspill                i13, 2          
    22 : select_gt              i13, i0, i13    
    23 : spill                  2, i13          
    24 : max                    i9, i2, i9      
    25 : add                    i0, i0, 4       
    26 : annotation:endwhile    0, 2            
    27 : unspill                i13, 3          
    28 : sar                    i1, i13, 2      
    29 : unspill                i13, 2          
    30 : sar                    i2, i13, 2      
    31 : unspill                i13, 1          
    32 : store.i32              i13, i1         
    33 : unspill                i13, 0          
    34 : store.i32              i13, i2         
    35 : mov                    i0, 0           
    36 : ret                                    
    37 : unspill                i13, 5          
    38 : add                    i4, i4, 56      
