has_in_join_cascade(i0, i1, i2)
     0 : sub                    i4, i4, 120      
     1 : spill                  13, i13          
     2 : spill                  14, i14          
     3 : spill                  6, i1            
     4 : spill                  5, i2            
     5 : spill                  4, i8            
     6 : mov                    s0, 0            
     7 : unspill                i13, 6           
     8 : load.i64               i14, i13, 16     
     9 : spill                  3, i14           
    10 : unspill                i13, 6           
    11 : load.i64               i14, i13, 0      
    12 : spill                  2, i14           
    13 : unspill                i13, 6           
    14 : load.i64               i14, i13, 8      
    15 : spill                  1, i14           
    16 : annotation:whilecstart 0                
    17 : cmp                    s3, 0            
    18 : jmp_le                 __loops_label_2  
    19 : annotation:whilecend                    
    20 : unspill                i13, 2           
    21 : load.i32               i14, i13         
    22 : spill                  11, i14          
    23 : add                    s2, s2, 4        
    24 : unspill                i13, 1           
    25 : load.i32               i14, i13         
    26 : spill                  10, i14          
    27 : add                    s1, s1, 4        
    28 : sub                    s3, s3, 1        
    29 : unspill                i13, 6           
    30 : load.i64               i14, i13, 40     
    31 : spill                  9, i14           
    32 : unspill                i13, 6           
    33 : load.i64               i14, i13, 24     
    34 : spill                  8, i14           
    35 : unspill                i13, 6           
    36 : load.i64               i14, i13, 32     
    37 : spill                  7, i14           
    38 : annotation:whilecstart 3                
    39 : cmp                    s9, 0            
    40 : jmp_le                 __loops_label_5  
    41 : annotation:whilecend                    
    42 : unspill                i13, 8           
    43 : load.i32               i1, i13          
    44 : add                    s8, s8, 4        
    45 : unspill                i13, 7           
    46 : load.i32               i2, i13          
    47 : add                    s7, s7, 4        
    48 : sub                    s9, s9, 1        
    49 : annotation:ifcstart                     
    50 : cmp                    i2, s11          
    51 : jmp_le                 __loops_label_7  
    52 : annotation:ifcend                       
    53 : annotation:break       3                
    54 : annotation:else        7, 8             
    55 : annotation:ifcstart                     
    56 : cmp                    i2, s11          
    57 : jmp_ne                 __loops_label_10 
    58 : annotation:ifcend                       
    59 : unspill                i13, 6           
    60 : load.i64               i2, i13, 64      
    61 : unspill                i13, 6           
    62 : load.i64               i8, i13, 48      
    63 : unspill                i13, 6           
    64 : load.i64               i14, i13, 56     
    65 : spill                  12, i14          
    66 : annotation:whilecstart 11               
    67 : cmp                    i2, 0            
    68 : jmp_le                 __loops_label_13 
    69 : annotation:whilecend                    
    70 : load.i32               i9, i8           
    71 : add                    i8, i8, 4        
    72 : unspill                i13, 12          
    73 : load.i32               i0, i13          
    74 : add                    s12, s12, 4      
    75 : sub                    i2, i2, 1        
    76 : annotation:ifcstart                     
    77 : cmp                    i9, s10          
    78 : jmp_le                 __loops_label_15 
    79 : annotation:ifcend                       
    80 : annotation:break       11               
    81 : annotation:else        15, 16           
    82 : annotation:ifcstart                     
    83 : cmp                    i9, s10          
    84 : jmp_ne                 __loops_label_18 
    85 : cmp                    i1, s5           
    86 : jmp_ne                 __loops_label_18 
    87 : cmp                    i0, s4           
    88 : jmp_ne                 __loops_label_18 
    89 : annotation:ifcend                       
    90 : mov                    s0, 1            
    91 : annotation:break       2                
    92 : annotation:endif       16               
    93 : annotation:endif       18               
    94 : annotation:endwhile    11, 13           
    95 : annotation:endif       8                
    96 : annotation:endif       10               
    97 : annotation:endwhile    3, 5             
    98 : annotation:endwhile    0, 2             
    99 : mov                    i0, s0           
   100 : ret                                     
   101 : unspill                i13, 13          
   102 : unspill                i14, 14          
   103 : add                    i4, i4, 120      
