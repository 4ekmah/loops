nullify_msb_lsb(i0, i1, i2)
     0 : shr       i9, i1, 1  
     1 : or        i9, i1, i9 
     2 : shr       i0, i9, 2  
     3 : or        i9, i9, i0 
     4 : shr       i0, i9, 4  
     5 : or        i9, i9, i0 
     6 : shr       i0, i9, 8  
     7 : or        i9, i9, i0 
     8 : shr       i0, i9, 16 
     9 : or        i9, i9, i0 
    10 : shr       i0, i9, 32 
    11 : or        i9, i9, i0 
    12 : add       i9, i9, 1  
    13 : shr       i9, i9, 1  
    14 : xor       i9, i9, i1 
    15 : store.u64 i8, i9     
    16 : sub       i8, i1, 1  
    17 : not       i8, i8     
    18 : and       i8, i1, i8 
    19 : xor       i8, i8, i1 
    20 : store.u64 i2, i8     
    21 : ret                  
