triangle_types(i0, i1, i2)
     0 : sub                 i4, i4, 24       
     1 : spill               1, i13           
     2 : spill               0, i2            
     3 : annotation:ifcstart                  
     4 : cmp                 i1, 0            
     5 : jmp_le              __loops_label_0  
     6 : cmp                 s0, 0            
     7 : jmp_le              __loops_label_0  
     8 : cmp                 i8, 0            
     9 : jmp_gt              __loops_label_1  
    10 : __loops_label_0:                     
    11 : annotation:ifcend                    
    12 : mov                 i0, 0            
    13 : ret                                  
    14 : annotation:else     1, 2             
    15 : annotation:ifcstart                  
    16 : unspill             i13, 0           
    17 : add                 i9, i13, i8      
    18 : cmp                 i1, i9           
    19 : jmp_gt              __loops_label_3  
    20 : add                 i9, i1, i8       
    21 : cmp                 s0, i9           
    22 : jmp_gt              __loops_label_3  
    23 : add                 i9, i1, s0       
    24 : cmp                 i8, i9           
    25 : jmp_le              __loops_label_4  
    26 : __loops_label_3:                     
    27 : annotation:ifcend                    
    28 : mov                 i0, 0            
    29 : ret                                  
    30 : annotation:else     4, 5             
    31 : annotation:ifcstart                  
    32 : cmp                 i1, s0           
    33 : jmp_ne              __loops_label_7  
    34 : cmp                 i1, i8           
    35 : jmp_ne              __loops_label_7  
    36 : annotation:ifcend                    
    37 : mov                 i0, 2            
    38 : ret                                  
    39 : annotation:else     7, 8             
    40 : annotation:ifcstart                  
    41 : cmp                 i1, s0           
    42 : jmp_eq              __loops_label_9  
    43 : cmp                 i1, i8           
    44 : jmp_eq              __loops_label_9  
    45 : cmp                 s0, i8           
    46 : jmp_ne              __loops_label_10 
    47 : __loops_label_9:                     
    48 : annotation:ifcend                    
    49 : mov                 i0, 3            
    50 : ret                                  
    51 : annotation:else     10, 11           
    52 : annotation:ifcstart                  
    53 : mul                 i9, i1, i1       
    54 : unspill             i13, 0           
    55 : mul                 i0, i13, s0      
    56 : mul                 i2, i8, i8       
    57 : add                 i0, i0, i2       
    58 : cmp                 i9, i0           
    59 : jmp_eq              __loops_label_12 
    60 : unspill             i13, 0           
    61 : mul                 i2, i13, s0      
    62 : mul                 i9, i1, i1       
    63 : mul                 i0, i8, i8       
    64 : add                 i9, i9, i0       
    65 : cmp                 i2, i9           
    66 : jmp_eq              __loops_label_12 
    67 : mul                 i2, i8, i8       
    68 : mul                 i9, i1, i1       
    69 : unspill             i13, 0           
    70 : mul                 i0, i13, s0      
    71 : add                 i9, i9, i0       
    72 : cmp                 i2, i9           
    73 : jmp_ne              __loops_label_13 
    74 : __loops_label_12:                    
    75 : annotation:ifcend                    
    76 : mov                 i0, 1            
    77 : ret                                  
    78 : annotation:else     13, 14           
    79 : annotation:ifcstart                  
    80 : mul                 i2, i1, i1       
    81 : unspill             i13, 0           
    82 : mul                 i9, i13, s0      
    83 : mul                 i0, i8, i8       
    84 : add                 i9, i9, i0       
    85 : cmp                 i2, i9           
    86 : jmp_gt              __loops_label_15 
    87 : unspill             i13, 0           
    88 : mul                 i2, i13, s0      
    89 : mul                 i9, i1, i1       
    90 : mul                 i0, i8, i8       
    91 : add                 i9, i9, i0       
    92 : cmp                 i2, i9           
    93 : jmp_gt              __loops_label_15 
    94 : mul                 i8, i8, i8       
    95 : mul                 i1, i1, i1       
    96 : unspill             i13, 0           
    97 : mul                 i2, i13, s0      
    98 : add                 i1, i1, i2       
    99 : cmp                 i8, i1           
   100 : jmp_le              __loops_label_16 
   101 : __loops_label_15:                    
   102 : annotation:ifcend                    
   103 : mov                 i0, 5            
   104 : ret                                  
   105 : annotation:else     16, 17           
   106 : mov                 i0, 4            
   107 : ret                                  
   108 : annotation:endif    2                
   109 : annotation:endif    5                
   110 : annotation:endif    8                
   111 : annotation:endif    11               
   112 : annotation:endif    14               
   113 : annotation:endif    17               
   114 : unspill             i13, 1           
   115 : add                 i4, i4, 24       
