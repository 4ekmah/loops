fixed_power_v_int32_t_0(i0, i1, i2)
     0 : mov                    i9, 0           
     1 : mul                    i8, i8, 4       
     2 : annotation:whilecstart 0               
     3 : cmp                    i9, i8          
     4 : jmp_ge                 __loops_label_2 
     5 : annotation:whilecend                   
     6 : vld.i32                v0, i1, i9      
     7 : mov                    i0, 1           
     8 : vdef.i32               v0              
     9 : setlane.i32            v0, 0, i0       
    10 : broadcast.i32          v0, v0, 0       
    11 : vst.i32                i2, i9, v0      
    12 : add                    i9, i9, 32      
    13 : annotation:endwhile    0, 2            
    14 : mov                    i0, 0           
    15 : ret                                    
