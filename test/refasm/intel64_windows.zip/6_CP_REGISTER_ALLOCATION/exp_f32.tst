exp_f32(i0, i1, i2)
     0 : sub                    i4, i4, 488        
     1 : spill                  28, v6             
     2 : spill                  32, v7             
     3 : spill                  36, v8             
     4 : spill                  40, v9             
     5 : spill                  44, v10            
     6 : spill                  48, v11            
     7 : spill                  52, v12            
     8 : spill                  56, v13            
     9 : mov                    i9, -1028603739    
    10 : vdef.fp32              v0                 
    11 : setlane.fp32           v0, 0, i9          
    12 : broadcast.fp32         v0, v0, 0          
    13 : mov                    i9, 1118879909     
    14 : vdef.fp32              v1                 
    15 : setlane.fp32           v1, 0, i9          
    16 : broadcast.fp32         v1, v1, 0          
    17 : mov                    i9, 1056964608     
    18 : vdef.fp32              v2                 
    19 : setlane.fp32           v2, 0, i9          
    20 : broadcast.fp32         v2, v2, 0          
    21 : mov                    i9, 1065353216     
    22 : vdef.fp32              v3                 
    23 : setlane.fp32           v3, 0, i9          
    24 : broadcast.fp32         v3, v3, 0          
    25 : mov                    i9, 1069066811     
    26 : vdef.fp32              v5                 
    27 : setlane.fp32           v5, 0, i9          
    28 : broadcast.fp32         v5, v5, 0          
    29 : mov                    i9, -1087275008    
    30 : vdef.fp32              v6                 
    31 : setlane.fp32           v6, 0, i9          
    32 : broadcast.fp32         v6, v6, 0          
    33 : mov                    i9, 962494595      
    34 : vdef.fp32              v7                 
    35 : setlane.fp32           v7, 0, i9          
    36 : broadcast.fp32         v7, v7, 0          
    37 : mov                    i9, 961571175      
    38 : vdef.fp32              v8                 
    39 : setlane.fp32           v8, 0, i9          
    40 : broadcast.fp32         v8, v8, 0          
    41 : mov                    i9, 985088974      
    42 : vdef.fp32              v9                 
    43 : setlane.fp32           v9, 0, i9          
    44 : broadcast.fp32         v13, v9, 0         
    45 : spill                  24, v13            
    46 : mov                    i9, 1007192328     
    47 : vdef.fp32              v10                
    48 : setlane.fp32           v10, 0, i9         
    49 : broadcast.fp32         v13, v10, 0        
    50 : spill                  20, v13            
    51 : mov                    i9, 1026206145     
    52 : vdef.fp32              v11                
    53 : setlane.fp32           v11, 0, i9         
    54 : broadcast.fp32         v13, v11, 0        
    55 : spill                  16, v13            
    56 : mov                    i9, 1042983594     
    57 : vdef.fp32              v12                
    58 : setlane.fp32           v12, 0, i9         
    59 : broadcast.fp32         v13, v12, 0        
    60 : spill                  4, v13             
    61 : mov                    i9, 1056964608     
    62 : vdef.fp32              v12                
    63 : setlane.fp32           v12, 0, i9         
    64 : broadcast.fp32         v13, v12, 0        
    65 : spill                  8, v13             
    66 : mov                    i9, 127            
    67 : vdef.i32               v12                
    68 : setlane.i32            v12, 0, i9         
    69 : broadcast.i32          v13, v12, 0        
    70 : spill                  12, v13            
    71 : mov                    i9, 0              
    72 : annotation:whilecstart 0                  
    73 : cmp                    i8, 0              
    74 : jmp_le                 __loops_label_2    
    75 : annotation:whilecend                      
    76 : vld.fp32               v12, i2, i9        
    77 : min.fp32               v12, v12, v1       
    78 : max.fp32               v12, v12, v0       
    79 : fma.fp32               v11, v2, v12, v5   
    80 : floor.fp32_fp32        v11, v11           
    81 : cast.fp32_i32          v11, v11           
    82 : cast.i32_fp32          v10, v11           
    83 : fma.fp32               v12, v12, v10, v6  
    84 : fma.fp32               v12, v12, v10, v7  
    85 : unspill                v13, 24            
    86 : fma.fp32               v10, v13, v12, v8  
    87 : unspill                v13, 20            
    88 : fma.fp32               v10, v13, v10, v12 
    89 : unspill                v13, 16            
    90 : fma.fp32               v10, v13, v10, v12 
    91 : unspill                v13, 4             
    92 : fma.fp32               v10, v13, v10, v12 
    93 : unspill                v13, 8             
    94 : fma.fp32               v10, v13, v10, v12 
    95 : mul.fp32               v9, v12, v12       
    96 : fma.fp32               v12, v12, v10, v9  
    97 : add.fp32               v9, v12, v3        
    98 : unspill                v13, 12            
    99 : add.i32                v10, v11, v13      
   100 : sal.i32                v10, v10, 23       
   101 : mul.fp32               v9, v9, v10        
   102 : vst.fp32               i1, i9, v9         
   103 : add                    i9, i9, 32         
   104 : sub                    i8, i8, 8          
   105 : annotation:endwhile    0, 2               
   106 : ret                                       
   107 : unspill                v6, 28             
   108 : unspill                v7, 32             
   109 : unspill                v8, 36             
   110 : unspill                v9, 40             
   111 : unspill                v10, 44            
   112 : unspill                v11, 48            
   113 : unspill                v12, 52            
   114 : unspill                v13, 56            
   115 : add                    i4, i4, 488        
