helloworld_call()
     0 : sub        i4, i4, 584     
     1 : spill      72, i5          
     2 : mov        i5, i4          
     3 : add        i5, i5, 576     
     4 : mov        i1, -1637084304 
     5 : call_noret [i1]()          
     6 : ret                        
     7 : unspill    i5, 72          
     8 : add        i4, i4, 584     
