min_max_scalar(i0, i1, i2, i3)
     0 : sub                    i4, i4, 88      
     1 : spill                  5, i8           
     2 : spill                  4, i9           
     3 : spill                  9, i13          
     4 : mov                    i0, 0           
     5 : mov                    s7, 0           
     6 : mov                    s6, 0           
     7 : load.i32               i8, i1          
     8 : mov                    i9, i8          
     9 : mul                    i13, i2, 4      
    10 : spill                  8, i13          
    11 : annotation:whilecstart 0               
    12 : cmp                    i0, s8          
    13 : jmp_ge                 __loops_label_2 
    14 : annotation:whilecend                   
    15 : load.i32               i2, i1, i0      
    16 : annotation:ifcstart                    
    17 : cmp                    i2, i8          
    18 : jmp_ge                 __loops_label_4 
    19 : annotation:ifcend                      
    20 : mov                    i8, i2          
    21 : mov                    s7, i0          
    22 : annotation:endif       4               
    23 : annotation:ifcstart                    
    24 : cmp                    i2, i9          
    25 : jmp_le                 __loops_label_6 
    26 : annotation:ifcend                      
    27 : mov                    i9, i2          
    28 : mov                    s6, i0          
    29 : annotation:endif       6               
    30 : add                    i0, i0, 4       
    31 : annotation:endwhile    0, 2            
    32 : mov                    i1, 4           
    33 : unspill                i13, 7          
    34 : div                    i2, i13, i1     
    35 : unspill                i13, 6          
    36 : div                    i1, i13, i1     
    37 : unspill                i13, 5          
    38 : store.i32              i13, i2         
    39 : unspill                i13, 4          
    40 : store.i32              i13, i1         
    41 : mov                    i0, 0           
    42 : ret                                    
    43 : unspill                i13, 9          
    44 : add                    i4, i4, 88      
