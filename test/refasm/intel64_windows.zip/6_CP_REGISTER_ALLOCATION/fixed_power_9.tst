fixed_power_9(i0)
     0 : mul i2, i1, i1 
     1 : mul i2, i2, i2 
     2 : mul i2, i2, i2 
     3 : mul i1, i1, i2 
     4 : mov i0, i1     
     5 : ret            
