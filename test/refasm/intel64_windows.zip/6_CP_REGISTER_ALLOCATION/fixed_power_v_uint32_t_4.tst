fixed_power_v_uint32_t_4(i0, i1, i2)
     0 : mov                    i9, 0           
     1 : mul                    i8, i8, 4       
     2 : annotation:whilecstart 0               
     3 : cmp                    i9, i8          
     4 : jmp_ge                 __loops_label_2 
     5 : annotation:whilecend                   
     6 : vld.u32                v0, i1, i9      
     7 : mul.u32                v0, v0, v0      
     8 : mul.u32                v0, v0, v0      
     9 : vst.u32                i2, i9, v0      
    10 : add                    i9, i9, 32      
    11 : annotation:endwhile    0, 2            
    12 : mov                    i0, 0           
    13 : ret                                    
